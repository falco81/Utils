# Two servers, both answering (high availability, active/active)

Two otp servers can run side by side, both answering. A load balancer in front
of them can send any request to either one, round robin and without sticky
sessions. There are two ways to lay the database out:

- **Replicated (from 1.0.14, the usual way)** - each node has **its own
  PostgreSQL** (16 or later) and the two replicate to each other both ways.
  Either node goes on alone while the other is down, and catches up by itself
  when it is back. A node that was away too long, or was reinstalled, is
  rebuilt from the live one with one command.
- **Shared (1.0.13)** - both nodes open **one PostgreSQL**: on node 1, on its
  own server, or a PostgreSQL cluster's address.

```
              ┌─────────────── load balancer ───────────────┐
 HTTPS :443   │  round robin, no stickiness, GET /healthz   │
              └──────────────┬──────────────────┬───────────┘
                             │                  │
                       ┌─────┴─────┐      ┌─────┴─────┐
 RADIUS 1812/1813 ───► │  node 1   │      │  node 2   │ ◄─── RADIUS
 (the VPN knows both)  │ PostgreSQL│ ◄──► │ PostgreSQL│
                       └───────────┘      └───────────┘
                     logical replication, both ways (replicated)
```

## Why either node can answer any request

- **Settings, clients, realms, directories and tokens** are kept in the
  database. A change made on one node is picked up by the other within five
  seconds.
- **A sign-in to the pages** is a row in the database. So is the "Edit the
  columns" switch that belongs to it. The next page can therefore come from
  the other node.
- **Enrolling a token** across nodes works the same way: everything that is
  half done is in the database.
- **A code is used up** by a single conditional `UPDATE`. If both nodes are
  asked for the same code at the same moment, only one of them accepts it.
  The same goes for a recovery code.
- **The nightly dump** is made by one node only: whichever claims the day
  first.
- **A job's progress** (a move, an erase, giving the disk back) is kept in the
  database, so its bar keeps moving whichever node the page asks.
- **The key that seals the tokens** is the same file on both nodes. It is
  carried to the second node once, inside a bundle locked with a passphrase.

Each node writes a heartbeat every fifteen seconds. *Settings → High
availability* and `otp --ha-status` list the nodes and when each was last heard
from. In a cluster, the page header shows which node answered it.

## Building it - replicated (each node its own PostgreSQL)

1. **On the first node, move the database to PostgreSQL** if it is not there
   yet: *Settings → The database*, then *Try it → Set it up → Carry everything
   across → Start using it*. It has to be PostgreSQL 16 or later on this
   machine.
2. **On the first node**, as root:

   ```
   otp --ha-setup --ha-peer 192.0.2.12 --node-name otp1
   ```

   This:
   - sets `wal_level = logical`, `listen_addresses = '*'` and
     `max_slot_wal_keep_size = 16GB`, and restarts PostgreSQL after asking,
   - adds a `pg_hba.conf` line for the second node (this database, this
     account, `scram-sha-256`) and opens TCP 5432 in firewalld for that one
     address,
   - publishes every table (`otp_pub`) and gives the database account the
     right to replicate,
   - numbers this node's new rows odd (the second node's will be even, so the
     two never hand out the same id),
   - writes `/root/otp-join-otp1.json` and prints the passphrase, once.
3. **On the second node**, as root:

   ```
   ./install.sh --with-db postgres --yes
   scp root@otp1:/root/otp-join-otp1.json /root/
   otp --ha-join /root/otp-join-otp1.json --node-name otp2
   ```

   It installs PostgreSQL there if it is missing, prepares it the same way,
   copies every row from the first node, and sets both directions up. The
   bundle also carries the key that opens the tokens. The pages of a fresh
   node cannot do this step, because it needs root.
4. **On both nodes**, give the load balancer's address (see below):
   `otp --trusted-proxy 192.0.2.10/32`.

`otp --ha-status` (or *Settings → High availability*) then shows both nodes and
both directions of the replication.

## Watching it and stepping in

*Settings → High availability → Replication* and `otp --ha-status` show, for
each direction (coming in, going out): whether it runs, when the other side was
last heard from, how much is waiting to go over, and any errors.

| Pages                               | Command line                   | What it does |
|-------------------------------------|--------------------------------|--------------|
| *Pause it…*                         | `otp --ha-pause [both\|in\|out]` | Stops sending. Both nodes keep answering from their own database. What is written meanwhile waits (up to 16 GB) and goes over after resuming. |
| *Resume it*                         | `otp --ha-resume [both\|in\|out]`| Carries on from where it stopped. |
| *Read the tables again*             | -                              | Re-reads the list of published tables (after an upgrade that added one). |
| *Rebuild this node from the other…* | `otp --ha-resync`              | Makes a copy of this node's database, empties it, copies every row from the other node and sets both directions up afresh. |
| *Switch it off…*                    | `otp --ha-stop`                | Removes both subscriptions and their slots. Each node goes on alone; joining them again is a rebuild. |

The same guide, with the commands, is on the pages: *Settings → High
availability → Making it two, step by step* and *Looking after it from the
command line*.

## When a node is lost

- **Down for a while** (a reboot, a network cut, hours or days): nothing to do.
  The live node keeps what the other one misses in its replication slot, up to
  16 GB of changes. When the node is back, it catches up by itself.
- **Down for longer than that**, its slot is dropped by PostgreSQL. The status
  then says *lost - rebuild the other node*. Rebuild the node that came back:
  `otp --ha-resync` on it (or the button on its pages).
- **Reinstalled from scratch**: install otp, then `otp --ha-join` with a new
  bundle made on the live node (`otp --ha-bundle FILE`, or *Make the bundle…*
  on its pages). It joins the same way the second node did the first time,
  and takes the same slot number.

**Rebuild the node that was away, never the one that kept working.** A
rebuild replaces everything on the node where it runs. What was written there
and never reached the other node survives only in the safety copy the rebuild
makes first.

## Building it - shared (both nodes open one PostgreSQL)

1. **Move the database to PostgreSQL first**, as in step 1 above.
2. **On the first node**, as root:

   ```
   otp --ha-setup --ha-shared --ha-peer 192.0.2.12 --node-name otp1
   ```

   If PostgreSQL runs on this machine, this command:
   - makes it listen on the network,
   - adds a `pg_hba.conf` line for the second node (this database, this
     account, `scram-sha-256`),
   - opens TCP 5432 in firewalld for that one address,
   - and restarts PostgreSQL after asking.

   It then writes `/root/otp-join-otp1.json` and prints the passphrase, once.
   For a PostgreSQL elsewhere, give its address as the second node will reach
   it: `--ha-db-host`.
3. **On the second node**: install otp, copy the bundle over and run
   `otp --ha-join /root/otp-join-otp1.json --node-name otp2`. Instead of the
   last command you can press *Join a cluster…* on the second node's own
   pages. From then on, sign in with the cluster's accounts.
4. **On both nodes**: `otp --trusted-proxy 192.0.2.10/32`.

## The load balancer

Two ways for the pages: the built-in **web address** (one address,
active/standby, keepalived - [tls-and-vip.md](tls-and-vip.md)), or a **load
balancer of your own** - HAProxy, nginx, Apache, F5, NetScaler, LVS, with
health checks that really look at each node: [load-balancers.md](load-balancers.md).
Step-by-step procedures for every situation (a node down, lost, rebuilt,
leaving the cluster): [operations.md](operations.md).

- **HTTPS**: round robin to both nodes on 443. No stickiness is needed. For the
  health check use `GET /healthz`: it answers `200 ok NODE` while the node and
  its database work, and `503` when they do not.

  The nodes must see the address of whoever is signing in, not the
  balancer's: every sign-in limit and allow list is per address, and behind
  a balancer that hides it everybody shares one - five wrong passwords from
  anybody lock out everybody for a quarter of an hour. So either end TLS on
  the balancer and pass `X-Forwarded-For` (`mode http`, `option forwardfor`),
  or pass TLS through with the PROXY protocol. `mode tcp` alone carries no
  address at all, and `otp --trusted-proxy` then has nothing to read.

  Ending TLS on the balancer (the nodes keep their own certificate behind it):

  ```
  frontend otp_https
      bind :443 ssl crt /etc/haproxy/otp.pem
      mode http
      option forwardfor
      default_backend otp_nodes

  backend otp_nodes
      mode http
      balance roundrobin
      option httpchk GET /healthz
      http-check expect status 200
      server otp1 192.0.2.11:443 check ssl verify none
      server otp2 192.0.2.12:443 check ssl verify none
  ```

  Passing TLS through, with the PROXY protocol:

  ```
  frontend otp_https
      bind :443
      mode tcp
      default_backend otp_nodes

  backend otp_nodes
      mode tcp
      balance roundrobin
      option httpchk GET /healthz
      http-check expect status 200
      server otp1 192.0.2.11:443 send-proxy-v2 check check-ssl verify none
      server otp2 192.0.2.12:443 send-proxy-v2 check check-ssl verify none
  ```

  and on both nodes, in `/etc/nginx/conf.d/otp.conf`: `listen 443 ssl
  proxy_protocol;` (in place of `listen 443 ssl;`), `set_real_ip_from
  192.0.2.10;` and `real_ip_header proxy_protocol;`. With send-proxy the
  health check needs `check-send-proxy` as well, or it is refused by nginx.

- **RADIUS**: give the VPN both nodes as servers of one group. On a Cisco ASA
  that is two `aaa-server` hosts with the same key. You can also balance UDP
  1812 and 1813 to both nodes. In both cases each client's address and secret
  must be configured once, under *Settings → Clients*. Both nodes read them
  from the database.

## What it does not do

- **Replicated: a code is used up on one node, and the other learns of it a
  moment later** - normally well under a second. A code asked on both nodes in
  that moment, or on both halves of a split network, can be accepted twice.
  A TOTP code lives 30 seconds at most, so the risk is small, but it is there.
  The shared layout does not have it.
- **Replicated: the same row changed on both nodes at the same moment** ends up
  as whichever change arrived last on each node. Change the settings on one
  node at a time.
- **Shared: it does not make PostgreSQL highly available.** If the database runs
  on node 1, node 1 is the one machine that must stay up. Use the replicated
  layout, or a PostgreSQL cluster (Patroni, or a managed one) given with
  `--ha-db-host`.
- **Copies and dumps stay on the node that made them.** Each node lists the
  ones on its own disk. In the replicated layout each node makes its own
  nightly dump. Restoring a dump is refused while replication runs: switch it
  off, restore on one node, rebuild the other from it.
- **Upgrade both nodes to the same version** - one at a time, each taken out
  of service first: *Settings → Upgrades* does it by itself, or by hand with
  `otp --maintenance on` and `install.sh --upgrade` on each node in turn.
  [upgrades.md](upgrades.md) says how, and how to upgrade the operating
  system. The node list shows any mismatch.
