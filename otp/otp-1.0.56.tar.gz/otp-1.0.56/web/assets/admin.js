/* The time pickers (1.0.53), in place of the <select>s they replace. */
timePicker('ov-hours', {start: {k: 'rel', s: 86400}});
timePicker('rq-hours', {start: {k: 'rel', s: 86400}});
timePicker('en-since', {start: {k: 'rel', s: 604800}, all: true, unit: 's'});
if ($('ev-time')) timePicker('ev-time', {start: {k: 'all'}, all: true});
/* admin.js - the administration pages of otp, drawn the way isemon draws its
   dashboard: the same header, tabs, rail, popups and panels (core.js), over
   the otp daemon's API. The page works nothing out for itself. */
'use strict';

ADMIN = !!(ME && ME.role === 'fulladmin');
var TOKADMIN = !!(ME && (ME.role === 'fulladmin' || ME.role === 'tokenadmin'));
var LIVE = true, SERIAL = STATUS ? STATUS.serial : '', PANE = 'radius';
var SETTINGS = null, DIRTY = {};
var PAGE = {tokens: 0, requests: 0, codes: 0, events: 0, enrolment: 0};

function roleWords(role) {
  return role === 'fulladmin' ? 'full admin' : (role === 'tokenadmin' ? 'token admin' : 'read only');
}
function roleTone(role) {
  return role === 'fulladmin' ? 'violet' : (role === 'tokenadmin' ? 'warn' : 'dim');
}

/* ---- what this account may not even see ---------------------------------- */
(function roles() {
  document.querySelectorAll('.admin-only').forEach(function (n) { if (!ADMIN) n.hidden = true; });
  document.querySelectorAll('.fulladmin-only').forEach(function (n) { if (!ADMIN) n.hidden = true; });
  document.querySelectorAll('.token-admin').forEach(function (n) { if (!TOKADMIN) n.hidden = true; });
  if (!ADMIN) $('readonly-note').hidden = false;
  if (!ADMIN) $('save-bar').hidden = true;
}());
dressButtons(document);

/* ---- PHP and php2shell, said to an administrator (as on isemon) ---------- */
(function phpSafety() {
  var box = $('phpsafety'), s = PHP_SAFETY;
  if (!box || !s || s.patched) return;
  /* A distribution that backported the fix keeps the old number; the daemon
     reads the packages' changelog, and when it says the fix is in, so be it. */
  if (STATUS && STATUS.php && STATUS.php.fixed) return;
  box.hidden = false;
  box.classList.toggle('warnish', !!s.guarded);
  box.textContent = 'PHP ' + s.version + ' running this page may have php2shell '
    + '(CVE-2026-109618, CVE-2026-109619): remote code execution by anybody who can reach the '
    + 'web server. Update it - ' + (s.needs ? s.needs + ' or later, ' : '') + 'or the package '
    + 'your distribution fixed (dnf upgrade \'php*\') - and restart php-fpm; ./install.sh '
    + '--upgrade does it. A distribution that backported the fix keeps the old number: check '
    + 'rpm -q --changelog php-fpm | grep CVE-2026-109618.';
}());

/* ---- tabs ------------------------------------------------------------------ */
var TABS = ['overview', 'tokens', 'requests', 'test', 'enrolment', 'events', 'settings'];
window.optShowTab = function (name) {
  if (TABS.indexOf(name) < 0) name = 'overview';
  /* A tab this account may not use (its button is hidden) is not opened by
     the address either (1.0.15). */
  var btn = document.querySelector('.tabs button[data-tab="' + name + '"]');
  if (btn && btn.hidden) name = 'overview';
  TAB = name;
  document.querySelectorAll('.tabs button[data-tab]').forEach(function (b) {
    b.setAttribute('aria-selected', b.getAttribute('data-tab') === name ? 'true' : 'false');
  });
  TABS.forEach(function (one) { $('tab-' + one).hidden = one !== name; });
  writeHash();
  holdTheTallOnes();
  onTab(name);
};
document.querySelectorAll('.tabs button[data-tab]').forEach(function (b) {
  b.onclick = function () { showTab(b.getAttribute('data-tab')); };
});
function writeHash() {
  var want = '#' + TAB + (TAB === 'settings' ? '/' + PANE : '');
  if (location.hash !== want) try { history.replaceState(null, '', want); } catch (e) { }
}
function onTab(name) {
  explainWhatWasDrawn(document);
  if (name === 'overview') loadOverview();
  if (name === 'tokens') loadTokens();
  if (name === 'requests') loadRequests();
  if (name === 'test') loadTest();
  if (name === 'events') loadEvents();
  if (name === 'enrolment') loadEnrolment();
  /* Coming back with changes not yet saved keeps them (1.0.15). */
  if (name === 'settings') loadSettings(!Object.keys(DIRTY || {}).length);
}

/* ---- the header and the live updates -------------------------------------- */
function paintHeader(s) {
  STATUS = s;
  var pill = $('state-pill');
  var listening = s.radius && s.radius.listening && s.radius.listening.length;
  var kind = !listening ? 'crit' : (s.problems && s.problems.length ? 'warn' : 'ok');
  var inMaint = !!(s.maintenance && s.maintenance.on);
  if (inMaint && listening) kind = 'warn';
  pill.className = 'pill ' + kind;
  pill.lastChild.textContent = !listening ? 'not listening' : (inMaint ? 'in maintenance'
    : (kind === 'warn' ? 'answering, with trouble' : 'answering'));
  pill.title = listening ? 'RADIUS on ' + s.radius.listening.join(', ') : 'The RADIUS server is not listening.';
  explainWhatWasDrawn(pill.parentNode);
  var pr = $('problems');
  clear(pr);
  (s.problems || []).forEach(function (p, i) {
    if (i) pr.appendChild(el('br'));
    pr.appendChild(document.createTextNode(p));
  });
  pr.hidden = !(s.problems && s.problems.length);
  $('updated-at').textContent = clockWords(new Date());
  $('tabn-tokens').textContent = s.tokens ? num(s.tokens.all) : '';
  var rej = s.day ? s.day.reject : 0;
  $('tabn-requests').textContent = rej ? num(rej) : '';
  $('tabn-requests').classList.toggle('hot', rej > 0);
}

function tick() {
  if (!LIVE || document.hidden) return;
  api('status').then(function (s) {
    $('offline').hidden = true;
    var moved = s.serial !== SERIAL;
    SERIAL = s.serial;
    paintHeader(s);
    if (moved && (TAB === 'overview' || TAB === 'requests' || TAB === 'events')
        && !document.querySelector('.modal:not([hidden])')) onTab(TAB);
    if (TAB === 'overview') paintCards();
  }).catch(function (e) {
    var o = $('offline');
    o.hidden = false;
    o.textContent = 'The daemon is not answering: ' + (e.message || e);
  });
}
$('updated').onclick = function () {
  LIVE = !LIVE;
  $('updated').classList.toggle('paused', !LIVE);
  $('updated').querySelector('b').textContent = LIVE ? 'live' : 'paused';
  if (LIVE) tick();
};
$('signout').onclick = function () {
  api('logout', {}).then(function () { location.reload(); }, function () { location.reload(); });
};

/* ---- the account signed in --------------------------------------------- */
function showMe() {
  modal('Your account', function (body) {
    /* Who, as isemon draws it: the initials, the name, the role and where
       the account comes from (1.0.19). */
    var head = el('div', 'me-head');
    var ava = noI18n(el('div', 'me-ava' + (ME.role === 'fulladmin' ? ' admin' : ''), meInitials(ME.name, ME.display)));
    ava.setAttribute('aria-hidden', 'true');
    head.appendChild(ava);
    var who = el('div', 'me-who');
    who.appendChild(noI18n(el('div', 'me-n mono', ME.name)));
    if (ME.display && ME.display !== ME.name) who.appendChild(noI18n(el('div', 'me-d', ME.display)));
    var tags = el('div', 'me-tags');
    tags.appendChild(el('span', 'tag ' + roleTone(ME.role), roleWords(ME.role)));
    tags.appendChild(el('span', 'tag info', ME.source === 'directory' ? 'from the directory' : 'local account'));
    who.appendChild(tags);
    head.appendChild(who);
    body.appendChild(head);
    var may = el('div', 'me-sec');
    may.appendChild(el('h3', '', 'What you may do'));
    may.appendChild(el('p', '', ME.role === 'fulladmin' ? 'Anything: tokens, settings, accounts, the database.'
      : (ME.role === 'tokenadmin' ? 'Look at every page and look after people’s tokens: make, replace, switch off, take away. No setting and no account.'
         : 'Look at every page. Nothing can be changed from this account; how your own tables are laid out is yours to change.')));
    body.appendChild(may);
    if (ME.source === 'directory') {
      var dsec = el('div', 'me-sec');
      dsec.appendChild(el('h3', '', 'In the directory'));
      var dbody = el('div', 'muted', 'asking the directory…');
      dsec.appendChild(dbody);
      body.appendChild(dsec);
      api('directories', {action: 'whois', user: ME.name, kind: 'account'}).then(function (d) {
        clear(dbody);
        dbody.className = '';
        if (!d.entry) { dbody.appendChild(el('p', 'note', d.directory + ' has nobody by that name.')); return; }
        var kv = el('div', 'me-kv');
        var row = function (k, v) {
          if (!v) return;
          kv.appendChild(el('div', 'k', k));
          var c = el('div', 'v');
          if (v.nodeType) c.appendChild(v); else c.appendChild(noI18n(el('span', 'mono', v)));
          kv.appendChild(c);
        };
        row('User principal name', d.entry.upn);
        row('Mail', d.entry.mail);
        if (d.entry.dn) row('Where', placeSteps(d.entry.dn, ME.name));
        var gl = d.group_list || [];
        row('Groups (' + num(gl.length) + ')', personGroups(gl));
        dbody.appendChild(kv);
      }).catch(function (e) { dbody.textContent = String(e.message || e); });
    }
    var lsec = el('div', 'me-sec');
    lsec.appendChild(el('h3', '', 'Language'));
    body.appendChild(lsec);
    var lang = selectBox((window.OTP_LANGS || []).map(function (l) { return [l.code, l.name]; }),
                         window.OTP_LANG);
    noI18n(lang);
    lang.onchange = function () {
      api('prefs', {lang: lang.value}).then(function () { location.reload(); }).catch(oops);
    };
    lsec.appendChild(formField('The language of these pages', lang));

    /* The columns of the tables - exactly isemon's. */
    var cols = el('div', 'me-sec');
    cols.appendChild(el('h3', '', 'Columns of the tables'));
    var line = el('div', 'me-row');
    var say = el('div', 'me-say');
    say.innerHTML = '<b>Edit the columns</b><br>While this is on, the edge of any column’s '
      + 'heading can be dragged to size it and the heading itself to move it, and the right '
      + 'button on a heading hides a column, brings a hidden one back or adds an empty one '
      + 'for room; each change is kept the moment you let go. It is for this sign-in only: signing out, the sign-in '
      + 'running out or the service restarting turn it off again. Off, the tables are drawn '
      + 'as you left them and nothing can move them.';
    line.appendChild(say);
    var sw = el('label', 'sw');
    var box = el('input');
    box.type = 'checkbox';
    box.id = 'me-cols-edit';
    box.checked = COLS_EDIT;
    box.setAttribute('aria-label', 'Edit the columns');
    sw.appendChild(box);
    sw.appendChild(el('span', 'knob'));
    line.appendChild(sw);
    cols.appendChild(line);
    box.onchange = function () {
      var on = box.checked;
      box.disabled = true;
      colsSwitch(on).then(function (d) {
        box.checked = !!d.edit;
      }).catch(function (e) {
        box.checked = COLS_EDIT;
        oops(e);
      }).then(function () { box.disabled = false; });
    };
    var laid = Object.keys(COLS).length;
    cols.appendChild(el('p', '', laid ? 'You have laid out ' + num(laid) + ' table(s).'
      : 'Every table is as it comes.')).style.marginTop = '10px';
    var acts = el('div', 'me-acts');
    var back = cmdButton('Put my columns back as they come', 'undo', 'small');
    back.id = 'me-cols-reset';
    explain(back, 'Every table you have laid out goes back as it comes: the widths and the '
      + 'order of the columns, on every page. Nobody else’s change.');
    back.disabled = !laid;
    back.onclick = function () {
      back.disabled = true;
      colsReset().then(function () { showMe(); }).catch(function (e) {
        back.disabled = false;
        oops(e);
      });
    };
    acts.appendChild(back);
    cols.appendChild(acts);
    body.appendChild(cols);

    /* Your own settings, to a file and back. */
    var mine = el('div', 'me-sec');
    mine.appendChild(el('h3', '', 'Your settings in a file'));
    mine.appendChild(el('p', '', 'How you have set these pages up for yourself — the '
      + 'columns of the tables and the language — saved as a JSON file, and read back here '
      + 'or on another machine running otp. Never your password, your role or anything else '
      + 'about the account.'));
    var io = el('div', 'me-acts');
    var out = cmdButton('Export my settings', 'download', 'small');
    out.id = 'me-export';
    out.onclick = function () { meExport(out); };
    io.appendChild(out);
    var inn = cmdButton('Import settings…', 'upload', 'small');
    inn.id = 'me-import';
    inn.onclick = function () { mePick(); };
    io.appendChild(inn);
    mine.appendChild(io);
    body.appendChild(mine);

    if (ME.source !== 'directory') {
      var pwsec = el('div', 'me-sec');
      pwsec.appendChild(el('h3', '', 'A new password'));
      var old = maskBox('', '', '');
      var nw = maskBox('', '', '');
      var g = el('div', 'formgrid');
      g.appendChild(formField('The one you have now', old));
      g.appendChild(formField('The new one (8 characters at least)', nw));
      pwsec.appendChild(g);
      var go = cmdButton('Change the password', 'lock', 'primary');
      go.style.marginTop = '10px';
      go.onclick = function () {
        api('password', {old: old.value, 'new': nw.value}).then(function (d) {
          toast(d.message, 'good'); closeModal();
        }).catch(oops);
      };
      pwsec.appendChild(go);
      body.appendChild(pwsec);
    }
  }, null, 'medium');
}
$('me-btn').onclick = showMe;

/** "Edit the columns" on or off for this sign-in: the daemon holds it. */
function colsSwitch(on) {
  return api('columns', {edit: !!on}).then(function (d) {
    colsEditing(!!d.edit);
    colsCardSay();
    toast(d.edit ? 'Columns can be sized and moved now — each change is kept at once'
      : 'Columns are held as they are', 'good');
    return d;
  });
}

/** The file a person's own settings go into: one object with a mark of
    what it is, where and when it came from, and `settings` by section -
    `columns` and `prefs`; a version that does not know a section leaves it
    alone. As isemon's, with its own kind. */
var ME_FILE_KIND = 'otp-user-settings';

function meExport(button) {
  if (button) button.disabled = true;
  api('my-settings').then(function (d) {
    var file = {
      kind: ME_FILE_KIND,
      format: 1,
      from: location.host,
      version: d.version || '',
      user: d.name || (ME && ME.name) || '',
      exported: new Date().toISOString(),
      settings: d.settings || {}
    };
    var blob = new Blob([JSON.stringify(file, null, 2) + '\n'], {type: 'application/json'});
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'otp-settings-' + String(file.user || 'me').replace(/[^a-z0-9._-]/gi, '_')
      + '-' + file.exported.slice(0, 10) + '.json';
    document.body.appendChild(link);
    link.click();
    setTimeout(function () { URL.revokeObjectURL(link.href); link.remove(); }, 1500);
    var n = Object.keys((file.settings || {}).columns || {}).length;
    toast('your settings were saved to ' + link.download + ' (' + num(n)
      + ' table layout(s))', 'good');
  }).catch(oops).then(function () { if (button) button.disabled = false; });
}

function mePick() {
  var pick = el('input');
  pick.type = 'file';
  pick.accept = '.json,application/json';
  pick.hidden = true;
  pick.onchange = function () {
    var file = pick.files && pick.files[0];
    pick.remove();
    if (file) meImport(file);
  };
  document.body.appendChild(pick);
  pick.click();
}

function meImport(file) {
  if (file.size > 2 * 1024 * 1024) {
    toast('that file is far bigger than any settings file (' + bytes(file.size) + ')', 'bad');
    return;
  }
  var reader = new FileReader();
  reader.onerror = function () { toast('that file could not be read', 'bad'); };
  reader.onload = function () {
    var got;
    try { got = JSON.parse(String(reader.result || '')); } catch (e) {
      toast('that is not a settings file: it is not JSON', 'bad');
      return;
    }
    /* Our own file, or just its `settings` on their own. isemon's file is
       read as well: the columns are kept the same way in both. */
    var settings = got && (got.kind === ME_FILE_KIND || got.kind === 'opt-user-settings' || got.kind === 'isemon-user-settings')
      ? got.settings
      : (got && got.settings && typeof got.settings === 'object' ? got.settings : got);
    if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
      toast('that is not a settings file', 'bad');
      return;
    }
    var cols = settings.columns && typeof settings.columns === 'object'
      ? Object.keys(settings.columns).length : null;
    var other = Object.keys(settings).filter(function (k) {
      return k !== 'columns' && k !== 'prefs';
    });
    var at = got.exported ? Date.parse(String(got.exported)) : NaN;
    modal('Import settings', function (body) {
      body.appendChild(peekFacts([
        ['Whose', got.user ? noI18n(el('span', 'mono', String(got.user))) : '–'],
        ['From', got.from ? noI18n(el('span', 'mono', String(got.from))) : '–'],
        ['Saved', isFinite(at) ? stamp(at / 1000) : '–'],
        ['otp version', got.version ? noI18n(el('span', 'mono', String(got.version))) : '–']]));
      body.appendChild(el('p', 'note', 'This file holds:'));
      var list = el('ul', 'me-list');
      if (cols !== null) list.appendChild(el('li', '', 'the columns of ' + num(cols) + ' table(s)'));
      if (settings.prefs && typeof settings.prefs === 'object' && settings.prefs.lang) {
        list.appendChild(el('li', '', 'the language of the page'));
      }
      if (other.length) {
        list.appendChild(el('li', '', other.join(', ') + ' — not kept by this version, left alone'));
      }
      body.appendChild(list);
      body.appendChild(el('p', 'note', 'They replace yours. Your password and your account are not touched.'));
    }, [{words: 'No, leave it', close: true},
        {words: 'Import them', cls: 'primary', close: true, go: function () {
        api('my-settings', {settings: settings}).then(function (d) {
          if (settings.columns && typeof settings.columns === 'object') {
            /* What the daemon kept, not what the file said: it is the same
               less whatever a layout cannot hold. */
            return api('my-settings').then(function (now) {
              colsTake((now.settings || {}).columns || {});
              colsApplyAll();
              return d;
            });
          }
          return d;
        }).then(function (d) {
          toast('imported: the columns of ' + num((d.took || {}).columns || 0) + ' table(s)'
            + ((d.ignored || []).length ? '; left alone: ' + d.ignored.join(', ') : ''), 'good');
          var lang = settings.prefs && typeof settings.prefs === 'object'
            ? String(settings.prefs.lang || '') : '';
          if (lang && lang !== (window.OTP_LANG || 'en')
              && (window.OTP_LANGS || []).some(function (l) { return l.code === lang; })) {
            location.reload();
            return;
          }
          colsCardSay();
        }).catch(oops);
      }}], true);
  };
  reader.readAsText(file);
}

/** The card on the Accounts pane: how many tables are laid out, and the
    switch's words. */
function colsCardSay() {
  var laid = Object.keys(COLS).length;
  if ($('cols-count')) {
    $('cols-count').textContent = laid ? num(laid) + ' table(s) laid out by you'
      : 'every table as it comes';
  }
  var b = $('cols-edit-go');
  if (b) {
    setButtonIcon(b, COLS_EDIT ? 'check' : 'edit',
                  COLS_EDIT ? 'Stop editing the columns' : 'Edit the columns');
    b.classList.toggle('primary', COLS_EDIT);
  }
  if ($('cols-reset')) $('cols-reset').disabled = !laid;
}
$('cols-edit-go').onclick = function () { colsSwitch(!COLS_EDIT).catch(oops); };
$('cols-reset').onclick = function () {
  confirmThen('Put my columns back',
    'Every table you have laid out goes back as it comes: the widths and the order of the '
    + 'columns, on every page. Nobody else’s tables change.',
    'Put them back', function () { colsReset().then(function () { colsCardSay(); loadUsers(); }).catch(oops); });
};
$('cols-export').onclick = function () { meExport($('cols-export')); };
$('cols-import').onclick = function () { mePick(); };

/* ==========================================================================
   Overview
   ========================================================================== */
function paintCards() {
  var s = STATUS;
  if (!s) return;
  /* In a cluster, which node answered this page (1.0.13). */
  var hs = document.querySelector('header .host');
  if (hs) {
    if (hs._base === undefined) hs._base = hs.textContent;
    hs.textContent = hs._base + ((s.nodes || []).length > 1 ? ' · ' + s.node : '');
  }
  $('m-accept').textContent = num(s.day.accept);
  $('m-reject').textContent = num(s.day.reject);
  $('m-tokens').textContent = num(s.tokens.all);
  $('m-tokens-sub').textContent = num(s.tokens.active) + ' in use · ' + num(s.tokens.pending)
    + ' waiting · ' + num(s.tokens.disabled) + ' off · ' + num(s.tokens.used_30d) + ' used in 30 days';
  var i = s.isemon || {};
  var sent = Object.keys(i.sent || {}).reduce(function (a, k) { return a + i.sent[k]; }, 0);
  $('m-isemon').textContent = i.on ? (Object.keys(i.trouble || {}).length ? '!' : num(sent)) : 'off';
  $('m-isemon-sub').textContent = i.on ? ('as ' + i.host + ' to ' + ((i.targets || []).join(', ') || 'nowhere')
    + (i.last_sent ? ' · last ' + ago(i.last_sent) : '')) : 'not sent; Settings → isemon';
  $('card-isemon').className = 'card metric ' + (!i.on ? 'info' : (Object.keys(i.trouble || {}).length ? 'crit' : 'ok'))
    + ($('card-isemon').classList.contains('tappable') ? ' tappable' : '');
  $('m-accept-sub').textContent = s.last ? 'the last request ' + ago(s.last.ts) : 'nothing asked yet';
  paintCards2(s);
}

function codeNowTile(name) {
  var box = el('div', 'tw-fact tw-code');
  box.appendChild(el('dt', '', 'Code now'));
  var dd = el('dd', '');
  var hint = el('span', 'tw-code-hint', 'show');
  dd.appendChild(hint);
  box.appendChild(dd);
  box.title = 'The code the phone shows right now. Seeing it is written in the events. Shown, a click copies it.';
  box.setAttribute('role', 'button');
  box.tabIndex = 0;
  var st = {shown: false, code: '', next: '', ends: 0, period: 30, skew: 0, timer: null, asking: false};
  var R = 11, C = 2 * Math.PI * R;
  function ask(first) {
    if (st.asking) return;
    st.asking = true;
    api('token', {action: 'code_now', name: name, first: !!first}).then(function (d) {
      st.code = d.code; st.next = d.next; st.ends = d.ends; st.period = d.period;
      st.skew = d.now - Date.now() / 1000;
      if (!st.shown) draw();
      paint();
    }).catch(function (e) { oops(e); st.shown = false; }).then(function () { st.asking = false; });
  }
  var codeEl, ring, secs;
  function draw() {
    st.shown = true;
    clear(dd);
    var wrap = el('span', 'tw-code-row');
    codeEl = noI18n(el('span', 'tw-code-v mono', ''));
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 28 28');
    svg.setAttribute('class', 'tw-ring');
    var back = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    back.setAttribute('cx', 14); back.setAttribute('cy', 14); back.setAttribute('r', R);
    back.setAttribute('class', 'tw-ring-back');
    ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    ring.setAttribute('cx', 14); ring.setAttribute('cy', 14); ring.setAttribute('r', R);
    ring.setAttribute('class', 'tw-ring-fill');
    ring.setAttribute('stroke-dasharray', C.toFixed(2));
    svg.appendChild(back); svg.appendChild(ring);
    secs = noI18n(el('span', 'tw-ring-s', ''));
    var rw = el('span', 'tw-ring-wrap');
    rw.appendChild(svg); rw.appendChild(secs);
    wrap.appendChild(codeEl); wrap.appendChild(rw);
    dd.appendChild(wrap);
    st.timer = setInterval(tick, 200);
  }
  function paint() {
    if (!codeEl) return;
    var c = String(st.code);
    codeEl.textContent = c.length === 6 ? c.slice(0, 3) + ' ' + c.slice(3) : (c.length === 8 ? c.slice(0, 4) + ' ' + c.slice(4) : c);
    tick();
  }
  function tick() {
    /* Gone with its window, closed or not (1.0.44): a closed popup stays in
       the page and kept asking for the code every half minute. */
    if (!document.body.contains(box) || box.closest('.modal[hidden]')) { clearInterval(st.timer); return; }
    var now = Date.now() / 1000 + st.skew;
    var left = st.ends - now;
    if (left <= 0) {
      /* The next code is known already: shown at once, and the one after
         it asked for. */
      st.code = st.next; st.ends += st.period; left += st.period;
      paint();
      ask(false);
      return;
    }
    var part = Math.max(0, Math.min(1, left / st.period));
    ring.setAttribute('stroke-dashoffset', (C * (1 - part)).toFixed(2));
    ring.setAttribute('class', 'tw-ring-fill' + (left < 6 ? ' low' : ''));
    secs.textContent = Math.ceil(left);
  }
  function copyCode() { copyText(String(st.code || ''), box, 'the code was copied'); }
  function go() { if (!st.shown) ask(true); else copyCode(); }
  box.onclick = go;
  box.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } };
  return box;
}

/* The second row (1.0.37): this server, the cluster, the database, maintenance. */
function upTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  return d ? d + ' d ' + h + ' h' : (h ? h + ' h ' + m + ' min' : m + ' min');
}
function paintCards2(s) {
  if (!$('card-server')) return;
  var listening = s.radius && s.radius.listening && s.radius.listening.length;
  var probs = (s.problems || []).length;
  var maint = !!(s.maintenance && s.maintenance.on);
  $('m-server').textContent = !listening ? 'down' : (maint ? 'maintenance' : (probs ? num(probs) + ' !' : 'OK'));
  $('m-server-sub').textContent = s.node + ' · ' + s.version + ' · up ' + upTime(s.uptime);
  $('card-server').className = 'card metric ' + (!listening ? 'crit' : (maint || probs ? 'warn' : 'ok')) + ($('card-server').classList.contains('tappable') ? ' tappable' : '');
  var nodes = s.nodes || [];
  var alive = nodes.filter(function (n) { return n.alive; }).length;
  var rep = s.replication || {};
  var cl = $('card-cluster');
  var tap = cl.classList.contains('tappable') ? ' tappable' : '';
  if (nodes.length <= 1 && !rep.mode) {
    $('m-cluster').textContent = 'one server';
    $('m-cluster-sub').textContent = 'no second node; Settings → High availability';
    cl.className = 'card metric info' + tap;
  } else {
    $('m-cluster').textContent = num(alive) + ' / ' + num(nodes.length);
    var bits = [alive === nodes.length ? 'every node answers' : num(nodes.length - alive) + ' gone'];
    if (rep.mode === 'replicated') bits.push(rep.healthy ? 'replication runs both ways' : (rep.lost ? 'replication lost' : 'replication stopped'));
    else if (rep.mode) bits.push('one shared database');
    var vers = {};
    nodes.forEach(function (n) { if (n.version) vers[n.version] = 1; });
    if (Object.keys(vers).length > 1) bits.push('versions differ');
    $('m-cluster-sub').textContent = bits.join(' · ');
    var bad = alive < nodes.length || (rep.mode === 'replicated' && !rep.healthy);
    cl.className = 'card metric ' + (bad ? 'crit' : (Object.keys(vers).length > 1 ? 'warn' : 'ok')) + tap;
  }
  var db = s.db || {};
  $('m-db').textContent = ({sqlite: 'SQLite', mariadb: 'MariaDB', postgres: 'PostgreSQL'})[db.engine] || db.engine || '–';
  $('m-db-sub').textContent = (db.size ? bytes(db.size) : '') + (db.last_backup ? ' · last copy ' + ago(db.last_backup) : ' · no copy yet')
    + (db.key_there === false ? ' · KEY MISSING' : '');
  $('card-db').className = 'card metric ' + (db.key_there === false ? 'crit' : (db.last_backup && Date.now() / 1000 - db.last_backup < 2 * 86400 ? 'ok' : 'warn'))
    + ($('card-db').classList.contains('tappable') ? ' tappable' : '');
  var mn = s.maint_nodes || [];
  var up = s.upgrade || {};
  var running = up.plan && up.plan.state === 'running';
  $('m-maint').textContent = running ? 'upgrading' : (mn.length ? num(mn.length) + ' out' : 'in service');
  $('m-maint-sub').textContent = running ? 'to ' + up.plan.version
    : (mn.length ? mn.join(', ') + ' in maintenance'
    : (up.package && up.package !== s.version ? 'otp ' + up.package + ' is ready to be put in' : 'every node answers RADIUS'));
  $('card-maint').className = 'card metric ' + (running ? 'info' : (mn.length ? 'warn' : 'ok'))
    + ($('card-maint').classList.contains('tappable') ? ' tappable' : '');
}

/* The cards open what they count (1.0.37, as isemon's). */
function cardOpens(id, words, go) {
  var card = $(id);
  if (!card) return;
  card.classList.add('tappable');
  card.setAttribute('role', 'button');
  card.setAttribute('tabindex', '0');
  if (!card.querySelector('.goes')) {
    var arrow = el('span', 'goes');
    arrow.innerHTML = iconMarkup('next', 16);
    card.appendChild(arrow);
  }
  if (words) explain(card, words);
  card.onclick = function (e) {
    if (e && e.target && e.target.closest && e.target.closest('button,a,select,input')) return;
    go();
  };
  card.onkeydown = function (e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
  };
}
function peekActivity(title, result, jumpWords) {
  peek(title, function () {
    return Promise.all([api('activity&hours=24&result=' + result + '&limit=200'), api('dashboard&hours=24')])
      .then(function (two) { two[0].dash = two[1]; return two[0]; });
  }, function (body, d) {
    var rows = d.rows || [];
    var by = {};
    rows.forEach(function (r) {
      var k = result === 'accept' ? (r.name || '–') : (r.why || '–');
      var one = by[k] || (by[k] = {said: k, n: 0, last: 0});
      one.n += 1;
      one.last = Math.max(one.last, r.ts || 0);
    });
    var top = Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) { return b.n - a.n; });
    var dash = d.dash || {};
    /* Refusals counted by the server over the whole day, not out of the
       rows fetched. */
    if (result !== 'accept' && (dash.top_reasons || []).length) top = dash.top_reasons;
    body.appendChild(peekFacts([[result === 'accept' ? 'Let in' : 'Refused', num(d.total)],
      result === 'accept' ? ['People', num(top.length)] : ['Wrong codes', num(dash.otp_bad || 0)],
      ['Newest', rows.length ? ago(rows[0].ts) : '–']]));
    if (top.length) {
      body.appendChild(el('h4', '', result === 'accept' ? 'Who' : 'Why'));
      var t = el('div');
      facet(t, top.slice(0, 8), result === 'accept' ? 'good' : 'reject', function (r) {
        closeModal();
        openRequests({q: r.said, result: result});
      });
      body.appendChild(t);
    }
    body.appendChild(el('h4', '', 'The last of them'));
    body.appendChild(activityTable(rows.slice(0, 50)));
  }, {tab: 'requests', words: jumpWords, icon: 'list'});
}
function peekTokensCard() {
  peek('Tokens', function () { return api('tokens&limit=1000&sort=last_used&desc=1'); }, function (body, d) {
    var t = (STATUS || {}).tokens || {};
    body.appendChild(peekFacts([['All', num(t.all)], ['In use', num(t.active)], ['Waiting for a code', num(t.pending)],
      ['Switched off', num(t.disabled)], ['Used in 30 days', num(t.used_30d)]]));
    var rows = (d.rows || d.tokens || []);
    var locked = rows.filter(function (r) { return r.locked_until && r.locked_until * 1000 > Date.now(); });
    var never = rows.filter(function (r) { return !r.last_used; }).length;
    body.appendChild(el('p', 'note', num(never) + ' never used yet' + (locked.length ? ' · ' + num(locked.length) + ' locked out after wrong codes' : '') + '.'));
    if (locked.length) {
      body.appendChild(el('h4', '', 'Locked out now'));
      locked.forEach(function (r) {
        var p = el('div', 'fct tappable');
        p.appendChild(noI18n(el('div', 'fct-said', r.name)));
        p.onclick = function () { modalOver(function () { tokenPeek(r.name); }); };
        body.appendChild(p);
      });
    }
    var used = rows.filter(function (r) { return r.last_used; }).sort(function (a, b) { return b.last_used - a.last_used; }).slice(0, 12);
    if (used.length) {
      body.appendChild(el('h4', '', 'Used last'));
      body.appendChild(listTable(['Name', 'Used', 'From'], used, function (r) {
        var tr = el('tr');
        tr.appendChild(noI18n(el('td', 'mono', r.name)));
        tr.appendChild(el('td', 'muted', ago(r.last_used)));
        tr.appendChild(noI18n(el('td', 'mono small', r.last_from || '')));
        tr.style.cursor = 'pointer';
        tr.onclick = function () { modalOver(function () { tokenPeek(r.name); }); };
        return tr;
      }, 'plain'));
    }
  }, {tab: 'tokens', words: 'Open the tokens', icon: 'token'});
}
function peekIsemonCard() {
  var i = (STATUS || {}).isemon || {};
  peek('isemon', function () { return Promise.resolve(i); }, function (body) {
    var sent = Object.keys(i.sent || {});
    body.appendChild(peekFacts([['Sending', i.on ? 'on' : 'off'], ['As', i.host || '–'],
      ['Last line', i.last_sent ? ago(i.last_sent) : '–']]));
    if (!i.on) body.appendChild(el('p', 'note', 'Nothing is sent. Settings → isemon says where to.'));
    sent.forEach(function (k) { body.appendChild(el('p', 'small good', k + ': ' + num(i.sent[k]) + ' line(s) sent')); });
    Object.keys(i.trouble || {}).forEach(function (k) { body.appendChild(el('p', 'note bad', k + ': ' + i.trouble[k])); });
  }, {tab: 'settings', pane: 'isemon', words: 'Open Settings', icon: 'gear'});
}
function peekServerCard() {
  var s = STATUS || {};
  peek('This server: ' + s.node, function () { return Promise.resolve(s); }, function (body) {
    var r = s.radius || {};
    var m = s.maintenance || {};
    body.appendChild(peekFacts([['Version', s.version], ['Running for', upTime(s.uptime)],
      ['Started', stamp(s.started)], ['Host', s.host], ['State', m.on ? 'in maintenance' : 'in service']]));
    if (m.on) {
      var mp = el('p', 'note bad');
      mp.appendChild(el('b', '', 'In maintenance'));
      if (m.why) { mp.appendChild(document.createTextNode(' · ')); mp.appendChild(noI18n(el('span', '', m.why))); }
      if (m.by) { mp.appendChild(document.createTextNode(' · ')); mp.appendChild(noI18n(el('span', '', m.by))); }
      if (m.at) { mp.appendChild(document.createTextNode(' · ')); mp.appendChild(el('span', '', ago(m.at))); }
      body.appendChild(mp);
      body.appendChild(el('p', 'note', 'RADIUS is not answered and /healthz says 503.'));
    }
    body.appendChild(el('h4', '', 'RADIUS'));
    var kv = [['Listening on', (r.listening || []).join(', ') || 'nothing'],
              ['Clients', num(s.clients)], ['Realms', num(s.realms)], ['Directories', num(s.directories)]];
    Object.keys(r.counts || {}).forEach(function (k) { kv.push([k, num(r.counts[k])]); });
    body.appendChild(kvTable(kv));
    body.appendChild(el('h4', '', 'Problems'));
    if (!(s.problems || []).length) body.appendChild(el('p', 'note good', 'None.'));
    (s.problems || []).forEach(function (p) { body.appendChild(el('p', 'note bad', p)); });
    var php = s.php || {};
    if (php.version) body.appendChild(el('p', 'note ' + (php.fixed === false ? 'bad' : ''), 'PHP ' + php.version + (php.fixed === false ? ' - may lack the php2shell fix' : '')));
  }, {tab: 'settings', pane: 'about', words: 'Open Settings', icon: 'gear'});
}
function peekClusterCard() {
  peek('High availability', function () { return api('ha'); }, function (body, d) {
    var rep = d.replication || {};
    var nodes = d.nodes || [];
    body.appendChild(peekFacts([['Nodes', num(nodes.length)], ['Answering', num(nodes.filter(function (n) { return n.alive; }).length)],
      ['Layout', rep.mode === 'replicated' ? 'each its own PostgreSQL' : (nodes.length > 1 ? 'one shared database' : 'one server')],
      ['This page from', d.node]]));
    body.appendChild(listTable(['Node', 'Version', 'Heard from', 'State'], nodes, function (n) {
      var tr = el('tr');
      tr.appendChild(noI18n(el('td', 'mono', n.name)));
      tr.appendChild(noI18n(el('td', 'mono', n.version || '?')));
      tr.appendChild(el('td', 'muted', ago(n.at)));
      var st = el('td');
      st.appendChild(el('span', 'tag ' + (n.alive ? (n.maintenance ? 'warn' : 'ok') : 'crit'), n.alive ? (n.maintenance ? 'in maintenance' : 'answering') : 'gone'));
      tr.appendChild(st);
      return tr;
    }, 'plain'));
    if (rep.mode === 'replicated') {
      body.appendChild(el('h4', '', 'The replication'));
      body.appendChild(el('p', 'note ' + (rep.healthy ? 'good' : 'bad'), rep.healthy ? 'Running both ways.' : (rep.lost ? 'Lost: rebuild the node that was away.' : 'Not running both ways.')));
      var rows = [];
      (rep.incoming || []).forEach(function (x) { rows.push(['coming in: ' + x.name, (x.enabled ? (x.running ? 'running' : 'not running') : 'paused') + (x.apply_errors ? ' · ' + x.apply_errors + ' error(s)' : '')]); });
      (rep.outgoing || []).forEach(function (x) { rows.push(['going out: ' + x.name, (x.active ? 'taken' : 'waiting') + ' · ' + bytes(x.behind || 0) + ' to go · ' + (x.wal_status || '')]); });
      body.appendChild(kvTable(rows));
      if (rep.trouble) body.appendChild(el('p', 'note bad', rep.trouble));
    } else if (nodes.length <= 1) {
      body.appendChild(el('p', 'note', 'One server. A second one answering beside it is set up in Settings → High availability.'));
    }
  }, {tab: 'settings', pane: 'ha', words: 'Open Settings', icon: 'gear'});
}
function peekDbCard() {
  peek('The database', function () { return api('db'); }, function (body, d) {
    body.appendChild(peekFacts([['Engine', d.words || d.engine], ['Where', d.where], ['Size', bytes(d.size || 0)],
      ['Version', d.version || '–'], ['The key', d.key_there ? 'there' : 'MISSING']]));
    /* What it holds (1.0.37): one row a table - what it is, its name, how
       many rows and how much room, with a bar for the room - biggest first,
       as on Settings → The database. */
    var tables = (d.tables || []).slice().sort(function (a, b) { return (b.bytes || 0) - (a.bytes || 0) || (b.rows || 0) - (a.rows || 0); });
    if (!tables.length) {
      var c = d.counts || {};
      tables = Object.keys(c).map(function (k) { return {table: k, rows: c[k], bytes: 0}; });
    }
    var most = Math.max.apply(null, tables.map(function (t) { return t.bytes || 0; }).concat([1]));
    body.appendChild(el('h3', 'peek-h', 'What it holds'));
    body.appendChild(listTable(['What', 'Table', {words: 'Rows', cls: 'num'}, {words: 'Room', cls: 'num'}, ''], tables, function (t) {
      var tr = el('tr');
      tr.appendChild(el('td', '', TABLE_SAID[t.table] || t.table));
      tr.appendChild(noI18n(el('td', 'mono small muted', t.table)));
      tr.appendChild(el('td', 'num', num(t.rows || 0)));
      tr.appendChild(el('td', 'num', t.bytes ? bytes(t.bytes) : '–'));
      var bc = el('td', 'barcell');
      var bar = el('div', 'bar good');
      var fill = el('span');
      fill.style.width = Math.max(2, Math.round(100 * (t.bytes || 0) / most)) + '%';
      bar.appendChild(fill);
      bc.appendChild(bar);
      tr.appendChild(bc);
      return tr;
    }, 'plain dbheld'));
    var b = d.backups || [];
    body.appendChild(el('h3', 'peek-h', 'Copies'));
    if (!b.length) {
      body.appendChild(el('p', 'note bad', 'No copy has been made yet.'));
    } else {
      body.appendChild(listTable(['Copy', {words: 'Size', cls: 'num'}, 'Made', 'Key beside it'], b.slice(0, 6), function (x) {
        var tr = el('tr');
        tr.appendChild(noI18n(el('td', 'mono small', x.name)));
        tr.appendChild(el('td', 'num', bytes(x.size)));
        tr.appendChild(stampCell(x.at));
        var k = el('td');
        k.appendChild(el('span', 'tag ' + (x.key ? 'ok' : 'warn'), x.key ? 'yes' : 'no'));
        tr.appendChild(k);
        return tr;
      }, 'plain'));
      if (b.length > 6) body.appendChild(el('p', 'muted small', num(b.length - 6) + ' more in Settings → The database'));
    }
  }, {tab: 'settings', pane: 'db', words: 'Open Settings', icon: 'gear'});
}
function peekMaintCard() {
  peek('Maintenance and upgrades', function () { return ADMIN ? api('upgrade') : api('ha'); }, function (body, d) {
    var nodes = d.nodes || [];
    body.appendChild(listTable(['Node', 'Version', 'State', ''], nodes, function (n) {
      var tr = el('tr');
      tr.appendChild(noI18n(el('td', 'mono', n.name)));
      tr.appendChild(noI18n(el('td', 'mono', n.version || '?')));
      var m = n.maintenance && typeof n.maintenance === 'object' ? n.maintenance : {on: !!n.maintenance};
      var st = el('td');
      st.appendChild(el('span', 'tag ' + (!n.alive ? 'crit' : (m.on ? 'warn' : 'ok')), !n.alive ? 'gone' : (m.on ? 'in maintenance' : 'in service')));
      if (m.on && m.why) st.appendChild(el('span', 'sub', m.why));
      tr.appendChild(st);
      var tools = el('td', 'rowtools');
      if (ADMIN && n.alive) {
        var b = cmdButton(m.on ? 'Back in service' : 'Maintenance', m.on ? 'play' : 'power', 'small');
        b.onclick = function () {
          UP.last = d;
          modalOver(function () { maintenanceAsk(n, !m.on, function () { peekMaintCard(); }); }, function () { peekMaintCard(); });
        };
        tools.appendChild(b);
      }
      tr.appendChild(tools);
      return tr;
    }, 'plain'));
    var plan = d.plan;
    if (plan) {
      body.appendChild(el('h4', '', 'The last upgrade'));
      body.appendChild(el('p', 'note', 'To ' + plan.version + ' · ' + ({running: 'going on', done: 'done', failed: 'failed', cancelled: 'stopped'})[plan.state] + ' · ' + ago(plan.at)));
    }
    if (d.package) body.appendChild(el('p', 'note good', 'otp ' + d.package.version + ' is sent and checked.'));
  }, ADMIN ? {tab: 'settings', pane: 'upgrade', words: 'Open Upgrades', icon: 'up'} : null);
}
cardOpens('card-accept', 'Everybody let in during the last 24 hours.', function () { peekActivity('Let in - the last 24 hours', 'accept', 'Open the Log'); });
cardOpens('card-reject', 'Everything refused in the last 24 hours, and why.', function () { peekActivity('Refused - the last 24 hours', 'reject', 'Open the Log'); });
cardOpens('card-tokens', 'The tokens: how many, which are locked out, which were used last.', peekTokensCard);
cardOpens('card-isemon', 'What is sent to isemon, and whether it arrives.', peekIsemonCard);
cardOpens('card-server', 'This server: its version, how long it has run, RADIUS, problems.', peekServerCard);
cardOpens('card-cluster', 'The nodes and the replication between them.', peekClusterCard);
cardOpens('card-db', 'The database: where, how big, what it holds, the copies.', peekDbCard);
cardOpens('card-maint', 'Which node is in service, and the upgrades.', peekMaintCard);

function loadOverview() {
  paintCards();
  var hours = Number($('ov-hours').value || 24);
  api('dashboard&hours=' + hours + tpQuery('ov-hours', 'since', 'until')).then(function (d) {
    drawChart(d, Math.round(d.hours || hours));
    $('m-reject-sub').textContent = num(d.refused) + ' · ' + $('ov-hours')._range().words + ' · '
      + num(d.otp_bad) + ' wrong code(s)';
    /* The Log opens on the same window as the overview (1.0.53). */
    var win = function (f) { f.since = d.since; f.until = d.until; return f; };
    facet('ov-names', d.top_refused_names, 'reject', function (r) { openRequests(win({q: r.said, result: 'reject'})); });
    facet('ov-reasons', d.top_reasons, 'reject', function (r) { openRequests(win({q: r.said, result: 'reject'})); });
    facet('ov-clients', d.top_clients, 'good', function (r) { openRequests(win({client: r.said})); });
    facet('ov-places', d.top_places, 'good', function (r) { openRequests(win({q: r.said})); });
    explainWhatWasDrawn($('tab-overview'));
  }).catch(oops);
}
$('ov-hours').onchange = loadOverview;
function overWords(h) {
  return h <= 6 ? '6 hours' : (h <= 24 ? '24 hours' : (h <= 72 ? '3 days' : (h <= 168 ? 'a week' : 'a month')));
}

function facet(id, rows, tone, go) {
  var host = typeof id === 'string' ? $(id) : id;
  clear(host);
  if (!rows || !rows.length) { host.appendChild(el('p', 'muted small', 'Nothing in this window.')); return; }
  var top = rows[0].n || 1;
  /* Each one whole: the words on their own line, as long as they are, and
     under them the bar, the count and when it was last. Nothing cut short. */
  var list = el('div', 'facetlist');
  rows.forEach(function (r) {
    var row = el('div', 'fct tappable');
    var said = noI18n(el('div', 'fct-said', r.said || '–'));
    if (r.said && /\s/.test(r.said)) said.removeAttribute('data-no-i18n');
    row.appendChild(said);
    var line = el('div', 'fct-line');
    var bb = el('div', 'bar' + (tone === 'good' ? ' good' : ''));
    var fill = el('span');
    fill.style.width = Math.max(3, Math.round(100 * r.n / top)) + '%';
    bb.appendChild(fill);
    line.appendChild(bb);
    line.appendChild(el('span', 'fct-n', num(r.n)));
    line.appendChild(el('span', 'fct-when muted small', ago(r.last)));
    row.appendChild(line);
    row.onclick = function () { go(r); };
    list.appendChild(row);
  });
  host.appendChild(list);
}

function drawChart(d, hours) {
  var host = $('ov-chart');
  var tip = host.querySelector('.tip');
  clear(host);
  host.appendChild(tip);
  var series = d.series || [];
  if (!series.length) { host.appendChild(el('div', 'empty', 'Nothing has been asked yet')); return; }
  var W = host.clientWidth || 700, H = host.clientHeight || 230;
  var padL = 44, padR = 12, padT = 12, padB = 26;
  var w = Math.max(10, W - padL - padR), h = Math.max(10, H - padT - padB);
  var top = Math.max(1, series.reduce(function (m, p) { return Math.max(m, p.accept, p.reject); }, 0));
  /* Whole numbers on the axis, four steps of the same size: a top of 3
     read 0, 1, 2, 2, 3 when each step was rounded on its own. */
  var unit = Math.max(1, Math.ceil(top / 4));
  var mag = Math.pow(10, Math.floor(Math.log(unit) / Math.LN10));
  unit = [1, 2, 5, 10].map(function (x) { return x * mag; }).filter(function (x) { return x >= unit; })[0] || unit;
  var ceil = unit * 4;
  var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
  svg.setAttribute('preserveAspectRatio', 'none');
  function make(kind, attrs) {
    var n = document.createElementNS('http://www.w3.org/2000/svg', kind);
    for (var k in attrs) if (attrs.hasOwnProperty(k)) n.setAttribute(k, attrs[k]);
    return n;
  }
  for (var g = 0; g <= 4; g++) {
    var y = padT + h - (h * g / 4);
    svg.appendChild(make('line', {x1: padL, x2: W - padR, y1: y, y2: y, stroke: '#262c37', 'stroke-width': 1}));
    var label = make('text', {x: padL - 8, y: y + 4, fill: '#5b6472', 'font-size': 11, 'text-anchor': 'end'});
    label.textContent = num(unit * g);
    svg.appendChild(label);
  }
  var step = w / Math.max(1, series.length);
  var barW = Math.max(1, Math.min(18, step * 0.38));
  series.forEach(function (p, i) {
    var x = padL + step * i + step / 2;
    [['reject', '#f85149', -1], ['accept', '#3fb950', 0]].forEach(function (one) {
      var v = p[one[0]];
      if (!v) return;
      var bh = Math.max(1, h * (v / ceil));
      svg.appendChild(make('rect', {x: x + one[2] * (barW + 0.6) + 0.3, y: padT + h - bh, width: barW,
                                    height: bh, fill: one[1], rx: 2, opacity: 0.88}));
    });
  });
  var every = Math.max(1, Math.ceil(series.length / Math.max(3, Math.floor(w / 72))));
  series.forEach(function (p, i) {
    if (i % every) return;
    var dd = new Date(p.t * 1000);
    var t = make('text', {x: padL + step * i + step / 2, y: H - 8, fill: '#5b6472', 'font-size': 11,
                          'text-anchor': 'middle'});
    t.textContent = hours > 48 ? pad2(dd.getDate()) + '-' + pad2(dd.getMonth() + 1) : clockWords(dd, false);
    svg.appendChild(t);
  });
  series.forEach(function (p, i) {
    var hit = make('rect', {x: padL + step * i, y: padT, width: step, height: h, fill: 'transparent'});
    var any = p.accept || p.reject;
    hit.style.cursor = any ? 'pointer' : 'crosshair';
    if (any) hit.addEventListener('click', function () {
      openRequests({since: p.t, until: p.t + d.step});
    });
    hit.addEventListener('mousemove', function (e) {
      var box = host.getBoundingClientRect();
      tip.innerHTML = '<b>' + stamp(p.t) + '</b><br>'
        + (p.accept ? '<span style="color:#3fb950">' + num(p.accept) + ' let in</span><br>' : '')
        + (p.reject ? '<span style="color:#f85149">' + num(p.reject) + ' refused</span><br>' : '')
        + '<span style="color:#8b949e">' + (any ? 'press to open' : 'nothing') + '</span>';
      tip.style.display = 'block';
      var left = e.clientX - box.left + 12;
      if (left + tip.offsetWidth > box.width) left = e.clientX - box.left - tip.offsetWidth - 12;
      tip.style.left = Math.max(0, left) + 'px';
      tip.style.top = Math.max(0, e.clientY - box.top - 12) + 'px';
    });
    hit.addEventListener('mouseleave', function () { tip.style.display = 'none'; });
    svg.appendChild(hit);
  });
  host.appendChild(svg);
}

/* ==========================================================================
   Tokens
   ========================================================================== */
function stateTag(state) {
  var words = {active: 'in use', pending: 'waiting for a code', disabled: 'switched off'}[state] || state;
  return el('span', 'tag ' + ({active: 'ok', pending: 'warn', disabled: 'crit'}[state] || 'dim'), words);
}

function loadTokens() {
  var per = Number($('tk-per').value);
  api('tokens&q=' + encodeURIComponent($('tk-q').value) + '&state=' + $('tk-state').value
      + '&limit=' + per + '&offset=' + PAGE.tokens * per).then(function (d) {
    QS.tokens.said(d.q_error || '');
    var host = $('tk-table');
    clear(host);
    $('tk-said').textContent = num(d.counts.active) + ' in use · ' + num(d.counts.never_used)
      + ' never used';
    host.appendChild(listTable(['Name', 'State', 'Made', 'By', 'Last used', 'From',
                                {words: 'Recovery codes', cls: 'num'}, {words: 'Wrong', cls: 'num'}, 'Note', ''],
      d.rows, function (r) {
        var tr = el('tr');
        var n = el('td');
        n.appendChild(noI18n(el('span', 'mono', r.name)));
        if (r.display) n.appendChild(noI18n(el('span', 'sub', r.display)));
        tr.appendChild(n);
        var st = el('td');
        st.appendChild(stateTag(r.state));
        if (r.pending) st.appendChild(el('span', 'tag info', 'a new one waits'));
        if (r.key_lost) st.appendChild(el('span', 'tag crit', 'key lost'));
        tr.appendChild(st);
        tr.appendChild(stampCell(r.created));
        tr.appendChild(noI18n(el('td', 'muted small', r.created_by || '')));
        tr.appendChild(r.last_used ? stampCell(r.last_used) : el('td', 'muted', 'never'));
        tr.appendChild(noI18n(el('td', 'mono small', r.last_from || '')));
        tr.appendChild(el('td', 'num', num(r.scratch_left)));
        tr.appendChild(el('td', 'num', num(r.failures || 0)));
        tr.appendChild(noI18n(el('td', 'muted small', r.note || '')));
        tr.appendChild(tokenTools(r.name));
        tr.onclick = function () { tokenPeek(r.name); };
        return tr;
      }, 'rows'));
    pager('tk-pager', PAGE.tokens, per, d.total, function (p) { PAGE.tokens = p; loadTokens(); });
    explainWhatWasDrawn(host);
  }).catch(oops);
}
$('tk-q').addEventListener('input', debounce(function () { PAGE.tokens = 0; loadTokens(); }, 300));
$('tk-state').onchange = $('tk-per').onchange = function () { PAGE.tokens = 0; loadTokens(); };

/** Edit and Delete at the end of a token's row. */
function tokenTools(name) {
  var tools = el('td', 'rowtools');
  var who = iconButton('person', 'In the directory: who it is, whether the account is switched off, its groups');
  who.onclick = function (ev) { ev.stopPropagation(); whoisPeek(name, 'token'); };
  tools.appendChild(who);
  var ed = iconButton('edit', 'Edit: the QR code, the recovery codes, switching it off, the note');
  ed.onclick = function (ev) { ev.stopPropagation(); tokenPeek(name); };
  tools.appendChild(ed);
  if (TOKADMIN) {
    var x = iconButton('trash', 'Take it away');
    x.onclick = function (ev) { ev.stopPropagation(); tokenDelete(name); };
    tools.appendChild(x);
  }
  return tools;
}
function tokenShowKey(name, which) {
  confirmThen('Show the key of ' + name,
    'Whoever has this QR code or key can make the codes of this token, as its owner can. '
    + 'Show it only to its owner; that you looked is written down as an event.', 'Show it', function () {
      api('token', {action: 'show', name: name, which: which}).then(function (d) {
        /* Over the token's window, when it was asked from there (1.0.22). */
        modalOver(function () { showMade(d.made); });
      }).catch(oops);
    }, false);
}
function tokenDelete(name, then) {
  confirmThen('Take the token of ' + name + ' away',
    'They cannot sign in to the VPN until they enrol a new one.', 'Take it away', function () {
      tokenDo(name, 'delete', {}, function () { if (then) then(); });
    });
}
function tokenDo(name, action, extra, then) {
  var body = {action: action, name: name};
  for (var k in (extra || {})) body[k] = extra[k];
  return api('token', body).then(function (d) {
    if (d.message) toast(d.message, 'good');
    if (then) then(d);
    loadTokens();
    return d;
  }).catch(oops);
}

/** A section of a large popup: a card with a heading, a line saying what it
    is for, and whatever goes in it. */
function msect(title, lede, wide) {
  var box = el('section', 'msect' + (wide ? ' wide' : ''));
  box.appendChild(el('h4', '', title));
  if (lede) box.appendChild(el('p', 'msect-lede', lede));
  var body = el('div', 'msect-body');
  box.appendChild(body);
  box._body = body;
  return box;
}

function tokenPeek(name) {
  peek(name, function () { return api('token&name=' + encodeURIComponent(name)); }, function (body, d) {
    var t = d.token;
    $('modal-box').className = 'box tokwin';
    var whoBtn = cmdButton('In the directory', 'person', '');
    whoBtn.onclick = function () { modalOver(function () { whoisPeek(name, 'token'); }); };
    if (!t) {
      var none = el('div', 'msects');
      var s0 = msect('No token', name + ' has no token: they cannot sign in to the VPN until they enrol one '
        + 'on the enrolment pages, or one is made here.', true);
      var r0 = el('div', 'btnrow');
      if (TOKADMIN) {
        var m = cmdButton('Make a token', 'token', 'primary');
        m.onclick = function () { makeToken(name); };
        r0.appendChild(m);
      }
      r0.appendChild(whoBtn);
      s0._body.appendChild(r0);
      none.appendChild(s0);
      body.appendChild(none);
      body.appendChild(historyButtons(name, d));
      return;
    }
    /* The head: who, its state, and its story at a glance (1.0.20). */
    var head = el('div', 'tw-head');
    var ava = noI18n(el('div', 'me-ava', meInitials(name, t.display)));
    head.appendChild(ava);
    var hw = el('div', 'tw-who');
    hw.appendChild(noI18n(el('div', 'tw-name', t.display || name)));
    if (t.display) hw.appendChild(noI18n(el('div', 'tw-sub mono', name)));
    var tags = el('div', 'me-tags');
    tags.appendChild(stateTag(t.state));
    if (t.pending) tags.appendChild(el('span', 'tag info', 'a new one waits'));
    if (t.failures) tags.appendChild(el('span', 'tag warn', num(t.failures) + ' wrong in a row'));
    if (t.key_lost) tags.appendChild(el('span', 'tag crit', 'key cannot be opened'));
    hw.appendChild(tags);
    head.appendChild(hw);
    /* Its story beside the name rather than under it: the window fits on
       the screen without scrolling (1.0.21). */
    var facts = el('dl', 'tw-facts');
    [['Made', stamp(t.created)], ['By', t.created_by || '–'],
     ['Last used', t.last_used ? stamp(t.last_used) : 'never'],
     ['Last from', t.last_from || '–']].forEach(function (f) {
      var box = el('div', 'tw-fact');
      box.appendChild(el('dt', '', f[0]));
      var v = el('dd', '', f[1]);
      v.title = f[1];
      box.appendChild(v);
      facts.appendChild(box);
    });
    /* The code the phone shows now, with a ring counting its seconds down
       (1.0.40): a full administrator only, and only once pressed - every
       look is written in the events. */
    if (ADMIN && !t.key_lost && STATUS && STATUS.admin_show_key !== false) facts.appendChild(codeNowTile(name));
    head.appendChild(facts);
    body.appendChild(head);
    /* Four cards of the same size, two by two (1.0.21). */
    var grid = el('div', 'tw-grid');
    var colA = grid, colB = grid;
    var showKeys = ADMIN && STATUS && STATUS.admin_show_key !== false;

    /* The phone. */
    var ph = actCard('The phone', (t.issuer || '') + ' · ' + (t.label || name) + ' · ' + t.digits + ' digits, '
      + t.period + ' s, ' + t.algorithm);
    if (showKeys) {
      var sh = cmdButton(t.pending ? 'Show the current one' : 'Show', 'eye', '');
      sh.onclick = function () { modalOver(function () { tokenShowKey(name, t.pending ? 'current' : ''); }); };
      ph.add('QR code and key', 'What the phone scans. That you looked is written down.', [sh]);
    }
    if (t.pending && TOKADMIN) {
      var row = [];
      if (showKeys) {
        var sw = cmdButton('Show', 'eye', '');
        sw.onclick = function () { modalOver(function () { tokenShowKey(name, 'waiting'); }); };
        row.push(sw);
      }
      var drop = cmdButton('Throw away', 'forget', '');
      drop.onclick = function () { confirmThen('Throw the new token away', 'The token waiting for its first code is deleted; the one in use stays.', 'Throw it away', function () { tokenDo(name, 'drop_staged', {}, function () { tokenPeek(name); }); }); };
      row.push(drop);
      ph.add('A new key waits', 'For a code from it; until then the old one works.', row);
    }
    if (TOKADMIN) {
      var re = cmdButton('New QR code', 'refresh', '');
      re.onclick = function () { modalOver(function () { makeToken(name); }, function () { tokenPeek(name); }); };
      ph.add('A new key', 'The old one stops; the person scans the new one.', [re]);
    }
    if (showKeys && !t.key_lost) {
      var ex = cmdButton('Export .totp', 'download', '');
      ex.onclick = function () { modalOver(function () {
        confirmThen('Export the token of ' + name, 'A .totp file with its key and its unused recovery codes. Whoever has the file can sign in as ' + htmlText(name) + '.',
          'Export it', function () { tokenExport(name); }, false);
      }); };
      ph.add('For another server', 'As totpcgi keeps it: key, options, unused recovery codes.', [ex]);
    }
    if (TOKADMIN) {
      var code = textBox('', '123456', 'mono');
      code.inputMode = 'numeric';
      code.style.width = '120px';
      var tb = cmdButton('Try', 'check', '');
      var said = el('div', 'small muted', 'Nothing is used up and nothing is counted.');
      tb.onclick = function () {
        api('token', {action: 'test', name: name, code: code.value}).then(function (x) {
          /* "Valid code used" said of a code nothing used up read wrong (1.0.36). */
          /* Said plainly and marked, so it is seen at once (1.0.41). */
          clear(said);
          said.className = 'small';
          var mark = el('span', 'try-said ' + (x.good ? 'ok' : 'crit'));
          mark.appendChild(el('b', '', x.good ? '✓ RIGHT' : '✗ WRONG'));
          mark.appendChild(el('span', '', x.good ? 'nothing was used up'
              + (x.facts && x.facts.off ? ' (the phone is ' + x.facts.off + ' step(s) off)' : '')
            : String(x.said || '')));
          said.appendChild(mark);
          code.classList.remove('try-ok', 'try-bad');
          code.classList.add(x.good ? 'try-ok' : 'try-bad');
        }).catch(oops);
      };
      code.addEventListener('keydown', function (e) { if (e.key === 'Enter') tb.click(); });
      code.addEventListener('input', function () { code.classList.remove('try-ok', 'try-bad'); });
      ph.add('Try a code', said, [code, tb]);
    }
    if (t.key_lost) ph.note('The key of this token cannot be opened: the key file of the database is not the one it was sealed with. Make a new one.', 'bad');
    colA.appendChild(ph.card);

    /* The recovery codes. */
    var rc = actCard('Recovery codes', num(t.scratch_left || 0) + ' left · each works once, in place of a code from the phone');
    if (showKeys) {
      var sc0 = cmdButton('Show', 'eye', '');
      sc0.disabled = !t.scratch_kept || !t.scratch_left;
      sc0.onclick = function () { modalOver(function () {
        confirmThen('Show the recovery codes of ' + name, 'Each of them signs in once in place of a code '
          + 'from the phone. Show them only to their owner; that you looked is written down as an event.', 'Show them', function () {
            api('token', {action: 'codes', name: name}).then(function (x) { modalOver(function () { showCodes(name, x.scratch, true); }); }).catch(oops);
          }, false);
      }); };
      rc.add('The ones left', t.scratch_kept ? 'To read them out to their owner.' : 'Not kept to be shown again - made by an older version or brought over.', [sc0]);
    }
    if (showKeys) {      /* as the API: they are shown, so where keys may be (1.0.44) */
      var sc = cmdButton('Make new ones', 'refresh', '');
      sc.onclick = function () { modalOver(function () {
        confirmThen('New recovery codes for ' + name, 'The ones there are stop working, and new ones are shown.',
          'Make new ones', function () {
            tokenDo(name, 'scratch', {}, function (x) {
              modalOver(function () { showCodes(name, x.scratch); }, function () { tokenPeek(name); });
            });
          }, false);
      }); };
      rc.add('New ones', 'The ones there are stop working.', [sc]);
    }
    var rcCard = rc.card;

    /* Signing in. */
    if (TOKADMIN) {
      var ac = actCard('Signing in', 'Switched off it refuses every code; wrong codes in a row pause it.');
      var b;
      if (t.state === 'disabled') {
        b = cmdButton('Switch on', 'power', 'primary'); b.onclick = function () { tokenDo(name, 'enable', {}, function () { tokenPeek(name); }); };
      } else {
        b = cmdButton('Switch off', 'power', 'danger'); b.onclick = function () { confirmThen('Switch the token of ' + name + ' off', 'They cannot sign in to the VPN until it is switched on again.', 'Switch off', function () { tokenDo(name, 'disable', {}, function () { tokenPeek(name); }); }); };
      }
      ac.add('In use', t.state === 'disabled' ? 'Switched off: every code is refused.' : (t.state === 'pending' ? 'Waiting for its first code.' : 'Codes from it sign in.'), [b]);
      var un = cmdButton('Forget them', 'undo', '');
      un.disabled = !t.failures;
      un.onclick = function () { tokenDo(name, 'unlock', {}, function () { tokenPeek(name); }); };
      ac.add('Wrong codes in a row', num(t.failures || 0) + ' now.', [un]);
      var win = selectBox([['-1', 'as the setting'], ['0', 'none'], ['1', '1 step'],
                           ['2', '2 steps'], ['4', '4 steps'], ['8', '8 steps']],
                          String(t.window_steps === null ? -1 : t.window_steps));
      win.style.width = '160px';
      win.onchange = function () { tokenDo(name, 'window', {window: Number(win.value)}); };
      ac.add('Clock drift allowed', 'How far the phone’s clock may be off, in steps of ' + t.period + ' s.', [win]);
      colB.appendChild(ac.card);
      grid.appendChild(rcCard);

      /* The person. */
      var nt = actCard('The person', t.display || 'Who the token belongs to.');
      nt.add('In the directory', 'Who it is, switched off or not, the groups.', [whoBtn]);
      if (showKeys && !t.key_lost) {
        /* Its QR code by mail again (1.0.27), to where it went last time. */
        var mg = cmdButton('Send by mail', 'mail', '');
        mg.onclick = function () { modalOver(function () { tokenMailAgain(name, d.mailed || {}); }, function () { tokenPeek(name); }); };
        var ml = d.mailed && d.mailed.to ? 'Last sent to ' + d.mailed.to + ', ' + ago(d.mailed.at) + '.'
          : 'The QR code to the person’s mailbox.';
        nt.add('By mail', ml, [mg]);
      }
      var mbox = textBox(name, 'novak@example.cz', 'mono');
      noI18n(mbox);
      var rmove = cmdButton('Move', 'next', '');
      rmove.disabled = true;
      mbox.addEventListener('input', function () {
        var to = mbox.value.trim().toLowerCase();
        rmove.disabled = !to || to === name.toLowerCase();
      });
      rmove.onclick = function () {
        var to = mbox.value.trim().toLowerCase();
        var same = to.split('@')[0] === name.toLowerCase().split('@')[0];
        /* Over the token window (1.0.36): "No" went back to nothing. */
        modalOver(function () { confirmThen(same ? 'Move the token to another realm' : 'Give the token to somebody else',
          'The token <b>' + htmlText(name) + '</b> becomes <b>' + htmlText(to) + '</b>: the same key, '
          + 'the same recovery codes, the same history. '
          + (same ? 'From then on it is checked with the groups and the directory of that realm, and the VPN has to send the new name.'
                  : 'From then on it signs <b>' + htmlText(to) + '</b> in, not ' + htmlText(name) + ' - whoever has the phone it is on. Its owner\'s name is read again from the directory.'),
          'Move it', function () {
            tokenDo(name, 'rename', {to: to}, function (x) { toast(x.message, 'good'); tokenPeek(to); if (typeof loadTokens === 'function') loadTokens(); });
          }, false); });
      };
      mbox.classList.add('tw-move');
      nt.add('Move to', 'Another realm or another person.', [mbox, rmove]);
      personSuggest(mbox, {});
      var nb = textBox(t.note || '', 'a note', '');
      nb.classList.add('tw-move');
      var ns = cmdButton('Save', 'save', '');
      ns.onclick = function () { tokenDo(name, 'note', {note: nb.value}); };
      nt.add('Note', 'Seen only here.', [nb, ns]);
      colB.appendChild(nt.card);
    } else {
      grid.appendChild(rcCard);
      var nt2 = actCard('The person', t.display || '');
      nt2.add('In the directory', t.note || '', [whoBtn]);
      colB.appendChild(nt2.card);
    }
    body.appendChild(grid);
    /* The history on the left, taking the token away on the right - a
       button, not a card of its own. */
    var foot = historyButtons(name, d);
    foot.classList.add('tw-foot');
    if (TOKADMIN) {
      var del = cmdButton('Take the token away', 'forget', 'danger');
      del.title = 'They cannot sign in to the VPN until they enrol a new one.';
      del.onclick = function () { modalOver(function () { tokenDelete(name, closeModal); }); };
      del.classList.add('tw-del');
      foot.appendChild(del);
    }
    /* In the window's own foot, beside Close: the cards above then fit on
       one screen without scrolling (1.0.21). */
    var mf = $('modal-foot');
    if (mf) { foot.style.marginTop = '0'; mf.insertBefore(foot, mf.firstChild); }
    else body.appendChild(foot);
  });
  $('modal-box').className = 'box tokwin';
}

/** A token's QR code mailed again (1.0.27): the same choices as when it is
    made, starting from where it went last time - or, if it never went, the
    address the directory has. */
function tokenMailAgain(name, mailed) {
  api('mail').then(function (cfg) {
    var off = (cfg.mode || 'off') === 'off';
    var addr, codes, lang, said, list;
    modal('Send the token of ' + name + ' by mail', function (body) {
      if (off) body.appendChild(el('div', 'notice bad', 'Sending mail is switched off - Settings → Mail.'));
      addr = textBox(mailed.to || '', 'novak@example.cz', 'mono');
      addr.type = 'email';
      noI18n(addr);
      codes = switchBox(mailed.codes !== undefined ? !!mailed.codes : !!cfg.codes);
      lang = selectBox([['cs', 'Čeština'], ['en', 'English']], mailed.lang || cfg.lang || 'cs');
      noI18n(lang);
      var g = el('div', 'formgrid');
      g.appendChild(formField('To', addr, mailed.to ? 'Where it went last time' + (mailed.by ? ', sent by ' + mailed.by : '')
        + ' - ' + stamp(mailed.at) + '. It can be changed.' : 'From the directory; it can be changed.'));
      g.appendChild(formField('Language of the mail', lang));
      body.appendChild(g);
      var g2 = el('div', 'formgrid');
      g2.appendChild(formField('With the recovery codes', codes, 'The ones not used yet. Each signs in once, in place of a code from the phone.'));
      body.appendChild(g2);
      body.appendChild(el('p', 'note warn small', 'Whoever reads this mail can make the person’s codes: send it only to their own mailbox. That it was sent is written down as an event.'));
      said = el('div', 'said');
      body.appendChild(said);
      list = el('div');
      body.appendChild(list);
      if (!mailed.to) {
        api('mail', {action: 'mail_of', user: name}).then(function (x) {
          if (x.mail && !addr.value) addr.value = x.mail;
        }).catch(function () {});
      }
    }, [{words: 'Close', close: true},
        {words: 'Send it', cls: 'primary', icon: 'mail', go: function (button) {
          if (off) return;
          var to = addr.value.trim();
          if (!to) { said.className = 'said bad'; said.textContent = 'a mail address to send it to'; return; }
          busy(button, true);
          said.className = 'said'; said.textContent = 'Sending…'; said.onclick = null; said.removeAttribute('role');
          clear(list);
          api('token', {action: 'mail', name: name, mail_to: to, mail_codes: codes._get(),
                        mail_lang: lang.value, portal_url: location.origin + '/'}).then(function (x) {
            said.className = 'said ' + (x.sent ? 'good' : 'bad');
            said.textContent = x.sent ? 'Sent to ' + to + '.' : 'Not sent: ' + x.said;
            stepsUnder(said, x.steps, list);
            if (x.sent) { toast(x.message, 'good'); mailed = x.mailed || mailed; }
          }).catch(function (e) { said.className = 'said bad'; said.textContent = e.message; })
            .then(function () { busy(button, false); });
        }}]);
  }).catch(oops);
}

/** The steps of a sending, folded away under `head` (the line saying how
    it went) until that line is clicked (1.0.28). `into` is where they go;
    by default straight after it. */
function stepsUnder(head, steps, into) {
  if (!(steps || []).length) return;
  var box = el('div', 'steps-fold');
  box.hidden = true;
  box.appendChild(stepsList(steps));
  if (into) into.appendChild(box); else head.parentNode.insertBefore(box, head.nextSibling);
  head.classList.add('folds');
  var hint = el('span', 'fold-hint', 'details');
  head.appendChild(hint);
  head.tabIndex = 0;
  head.setAttribute('role', 'button');
  var flip = function () {
    box.hidden = !box.hidden;
    head.classList.toggle('open', !box.hidden);
    hint.textContent = box.hidden ? 'details' : 'hide';
  };
  head.onclick = flip;
  head.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(); } };
}

/** A card of actions, each a row: what it is and what it does on the left,
    its controls on the right, every row the same height (1.0.20). `wide`
    puts the controls under the words, for a box that needs the room. */
function actCard(title, lede) {
  var card = el('section', 'acard');
  if (title) {
    var h = el('header', 'acard-h');
    h.appendChild(el('h4', '', title));
    if (lede) h.appendChild(el('p', '', lede));
    card.appendChild(h);
  }
  var make = function (cls, what, says, controls) {
    var row = el('div', cls);
    var t = el('div', 'arow-t');
    t.appendChild(el('div', 'arow-k', what));
    if (says) {
      if (says.nodeType) t.appendChild(says); else t.appendChild(el('div', 'arow-s', says));
    }
    row.appendChild(t);
    var c = el('div', 'arow-c');
    (controls || []).forEach(function (x) { c.appendChild(x); });
    row.appendChild(c);
    card.appendChild(row);
    return row;
  };
  return {card: card,
          add: function (what, says, controls) { return make('arow', what, says, controls); },
          wide: function (what, says, controls) { return make('arow wide', what, says, controls); },
          note: function (words, tone) { card.appendChild(el('p', 'note ' + (tone || ''), words)); }};
}

/** What the directory says about somebody: an account here (`kind`
    'account') or the owner of a token. */
/* ---- a person as the directory knows them (1.0.19, isemon's person card) ---- */
function meInitials(name, display) {
  var words = String(display || name || '?').replace(/[^\p{L}\p{N}\s._-]/gu, ' ')
    .split(/[\s._@-]+/).filter(Boolean);
  var two = words.length > 1 ? words[0][0] + words[words.length - 1][0] : String(words[0] || name || '?').slice(0, 2);
  return two.toUpperCase();
}
function dnParts(dn) {
  var out = [], cur = '', i, c;
  dn = String(dn || '');
  for (i = 0; i < dn.length; i++) {
    c = dn[i];
    if (c === '\\' && i + 1 < dn.length) { cur += dn[i + 1]; i++; continue; }
    if (c === ',') { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  if (cur) out.push(cur);
  return out.map(function (one) {
    var at = one.indexOf('=');
    return at < 0 ? ['', one.trim()] : [one.slice(0, at).trim().toLowerCase(), one.slice(at + 1).trim()];
  });
}
function dnPlace(dn) {
  var parts = dnParts(dn), name = parts.length ? parts[0][1] : '', ous = [], dcs = [];
  parts.slice(1).forEach(function (p) { if (p[0] === 'dc') dcs.push(p[1]); else if (p[1]) ous.push(p[1]); });
  return {name: name, path: ous.reverse(), domain: dcs.join('.')};
}
/** Where somebody lives in the directory, as steps: the domain, each OU, them. */
function placeSteps(dn, own) {
  var place = dnPlace(dn);
  var steps = el('div', 'me-place');
  var step = function (words, cls) {
    if (steps.children.length) steps.appendChild(el('span', 'sep', '›'));
    steps.appendChild(noI18n(el('span', 'step' + (cls ? ' ' + cls : ''), words)));
  };
  if (place.domain) step(place.domain, 'dom');
  place.path.forEach(function (ou) { step(ou); });
  step(place.name || own, 'me');
  var wrap = el('div');
  wrap.appendChild(steps);
  wrap.appendChild(noI18n(el('div', 'me-dn mono', dn)));
  return wrap;
}
/** The groups: the ones that give something here as cards that say what,
    the rest as one wrapping line of names, past a few rows behind "and N more". */
function personGroups(list) {
  var cell = el('div');
  var key = list.filter(function (g) { return (g.gives || []).length; });
  var rest = list.filter(function (g) { return !(g.gives || []).length; });
  if (!list.length) { cell.appendChild(el('span', 'muted', 'in no group')); return cell; }
  if (key.length) {
    var cards = el('div', 'me-groups');
    key.forEach(function (g) {
      var role = (g.gives || []).filter(function (x) { return x.role; })[0];
      var card = el('div', 'me-group gives' + (role && role.role === 'readonly' ? ' ro' : (role ? '' : ' realm')));
      (g.gives || []).forEach(function (x) {
        card.appendChild(el('span', 'gwhy', x.role ? 'makes an administrator: ' + roleWords(x.role)
          : 'lets into the realm ' + x.realm));
      });
      card.appendChild(noI18n(el('span', 'gn', g.name)));
      var where = dnPlace(g.dn);
      var bits = where.path.slice(); if (where.domain) bits.push(where.domain);
      if (bits.length) card.appendChild(noI18n(el('span', 'gp', bits.join(' › '))));
      card.title = g.dn || '';
      cards.appendChild(card);
    });
    cell.appendChild(cards);
  }
  if (rest.length) {
    var line = el('div', 'me-chips'), SHOW = 24;
    rest.forEach(function (g, i) {
      var chip = noI18n(el('span', 'me-chip', g.name));
      chip.title = g.dn || '';
      if (i >= SHOW) chip.hidden = true;
      line.appendChild(chip);
    });
    if (rest.length > SHOW) {
      var more = el('button', 'me-chip me-chip-more', 'and ' + num(rest.length - SHOW) + ' more');
      more.type = 'button';
      more.onclick = function () {
        Array.prototype.forEach.call(line.querySelectorAll('.me-chip[hidden]'), function (c) { c.hidden = false; });
        more.remove();
      };
      line.appendChild(more);
    }
    cell.appendChild(line);
  }
  return cell;
}
/** One person's card out of a whois answer: who, the state, where, what. */
function personCard(body, d, name) {
  var e = d.entry;
  var head = el('div', 'me-head');
  var ava = el('div', 'me-ava' + (d.role === 'fulladmin' ? ' admin' : ''), meInitials(e.sam || name, e.display));
  ava.setAttribute('aria-hidden', 'true');
  noI18n(ava);
  head.appendChild(ava);
  var who = el('div', 'me-who');
  who.appendChild(noI18n(el('div', 'me-n', e.display || e.sam || name)));
  who.appendChild(noI18n(el('div', 'me-d mono', e.upn || name)));
  var tags = el('div', 'me-tags');
  tags.appendChild(el('span', 'tag ' + (e.disabled ? 'crit' : 'ok'), e.disabled ? 'switched off in the directory' : 'active in the directory'));
  if (e.locked) tags.appendChild(el('span', 'tag crit', 'locked out'));
  if (e.expires) tags.appendChild(el('span', 'tag ' + (e.expires * 1000 < Date.now() ? 'crit' : 'warn'),
                                     (e.expires * 1000 < Date.now() ? 'expired ' : 'expires ') + stamp(e.expires)));
  if (d.role) tags.appendChild(el('span', 'tag ' + roleTone(d.role), roleWords(d.role)));
  if (d.realm) tags.appendChild(noI18n(el('span', 'tag info', d.realm)));
  if (d.token_state) tags.appendChild(el('span', 'tag ' + (d.token_state === 'active' ? 'ok' : 'warn'),
                                         d.token_state === 'active' ? 'has a token' : 'token: ' + d.token_state));
  who.appendChild(tags);
  head.appendChild(who);
  body.appendChild(head);
  var sec = el('div', 'me-sec');
  sec.appendChild(el('h3', '', 'In the directory'));
  var kv = el('div', 'me-kv');
  var row = function (k, v) {
    if (!v) return;
    kv.appendChild(el('div', 'k', k));
    var c = el('div', 'v');
    if (v.nodeType) c.appendChild(v); else c.appendChild(noI18n(el('span', 'mono', v)));
    kv.appendChild(c);
  };
  row('Account name', e.sam);
  row('User principal name', e.upn);
  row('Mail', e.mail);
  row('Department', e.department);
  row('Title', e.title);
  if (e.dn) row('Where', placeSteps(e.dn, e.sam || name));
  var asked = el('span', 'muted', d.directory + ' · ' + num(d.took_ms) + ' ms');
  noI18n(asked);
  row('Asked', asked);
  sec.appendChild(kv);
  body.appendChild(sec);
  var gs = el('div', 'me-sec');
  var list = (d.group_list || (d.groups || []).map(function (g) { return {name: g, dn: '', gives: []}; }));
  var h3 = el('h3', '', 'Groups, those inside groups as well');
  h3.appendChild(noI18n(el('span', 'me-count', ' (' + num(list.length) + ')')));
  gs.appendChild(h3);
  gs.appendChild(personGroups(list));
  body.appendChild(gs);
}

function whoisPeek(name, kind) {
  peek(name + ' in the directory', function () { return api('directories', {action: 'whois', user: name, kind: kind}); }, function (body, d) {
    if (!d.entry) { body.appendChild(el('p', 'note', d.directory + ' has nobody by that name.')); return; }
    personCard(body, d, name);
  });
  $('modal-box').className = 'box medium';
}

/** The story of a token, behind a button rather than under everything
    else: the checks of a code and the requests, in a popup of their own,
    with the way back to the token. (1.0.11) */
function historyButtons(name, d) {
  var row = el('div', 'btnrow');
  row.style.marginTop = '18px';
  var n1 = (d.checks || []).length, n2 = (d.requests || []).length;
  var go = cmdButton('The history: ' + num(n1) + ' check(s) of a code, ' + num(n2) + ' request(s)', 'history', '');
  go.disabled = !n1 && !n2;
  go.onclick = function () { modalOver(function () {
    modal('The history of ' + name, function (body) { peekHistory(body, d); },
          [{words: 'Back to the token', icon: 'prev', left: true, close: true}], 'large');
  }); };
  row.appendChild(go);
  var log = cmdButton('Everything in the Log', 'log', '');
  log.onclick = function () {
    closeModal();
    openRequests({q: name});
  };
  row.appendChild(log);
  return row;
}

function peekHistory(body, d) {
    body.appendChild(el('h3', 'peek-h', 'The last checks of a code'));
    var nd = manyNodes();
    body.appendChild(listTable(['When', 'Right', 'Said', 'How', 'From'].concat(nd ? ['Node'] : []), d.checks, function (r) {
      var tr = el('tr');
      tr.appendChild(stampCell(r.ts));
      var ok = el('td'); ok.appendChild(el('span', 'tag ' + (r.ok ? 'ok' : 'crit'), r.ok ? 'yes' : 'no'));
      tr.appendChild(ok);
      tr.appendChild(el('td', '', r.said));
      tr.appendChild(el('td', 'muted', howWords(r.how)));
      tr.appendChild(noI18n(el('td', 'mono small', r.src || '')));
      if (nd) tr.appendChild(nodeCell(r.node));
      return tr;
    }));
    body.appendChild(el('h3', 'peek-h', 'The last requests'));
    body.appendChild(requestTable(d.requests));
}

function showCodes(name, codes, again) {
  modal('Recovery codes for ' + name, function (body) {
    body.appendChild(el('p', 'note', again ? 'Each works once, in place of a code from the phone. Give them only to their owner.'
      : 'Each works once, in place of a code from the phone. Give them to their owner - the old ones no longer work.'));
    var c = el('div', 'codes');
    var used = 0;
    codes.forEach(function (x) {
      var code = typeof x === 'string' ? x : x.c;
      var when = typeof x === 'string' ? null : x.used;
      var one = el('span', when ? 'used' : '');
      one.appendChild(noI18n(el('b', '', code)));
      if (!when) copyOnClick(one, code, 'the recovery code was copied');
      one.appendChild(el('small', '', when ? 'used ' + stamp(when) + (x.how ? ' · ' + howWords(x.how) : '') : 'free'));
      if (when) used++;
      c.appendChild(one);
    });
    body.appendChild(c);
    if (again) body.appendChild(el('p', 'muted small', (codes.length - used) + ' free, ' + used + ' used'));
  }, [{words: 'Print', icon: 'download', go: printModal}, {words: 'Close', close: true}], true);
}

/* The popup on top printed, and nothing else (1.0.36). */
function printModal() {
  document.body.classList.add('print-modal');
  var done = function () { document.body.classList.remove('print-modal'); window.removeEventListener('afterprint', done); };
  window.addEventListener('afterprint', done);
  window.print();
}

function showMade(made, mailed) {
  modal('The token for ' + made.name, function (body) {
    if (mailed) {
      var m = el('div', 'notice ' + (mailed.ok ? 'good' : 'bad'));
      m.appendChild(el('b', '', mailed.ok ? 'Sent by mail to ' + mailed.to : 'The mail was not sent'));
      if (!mailed.ok) m.appendChild(el('div', '', mailed.error));
      body.appendChild(m);
      /* The steps, folded under the line that says how it went (1.0.28):
         a click on it shows them. */
      stepsUnder(m, mailed.steps);
    }
    var grid = el('div', 'enrol');
    var qr = el('div', 'qrbox');
    var img = el('img'); img.src = made.qr; img.alt = 'QR code';
    qr.appendChild(img);
    grid.appendChild(qr);
    var right = el('div');
    right.appendChild(el('p', 'note', 'Scan it with the authenticator application, or type the key in.'));
    right.appendChild(kvTable([['Issuer', made.issuer], ['Account', made.label],
                               ['Key', copyOnClick(noI18n(el('span', 'keytext', made.secret_spaced)), String(made.secret_spaced || '').replace(/\s+/g, ''), 'the key was copied')]]));
    grid.appendChild(right);
    body.appendChild(grid);
    if (made.scratch && made.scratch.length) {
      body.appendChild(el('h3', 'peek-h', 'Recovery codes'));
      var c = el('div', 'codes');
      made.scratch.forEach(function (x) { c.appendChild(noI18n(el('span', '', x))); });
      body.appendChild(c);
    }
  }, [{words: 'Print', icon: 'download', go: printModal}, {words: 'Close', close: true}], 'medium');
}

/** Make a token - or replace one: for whom (found in the directory as one
    types), and whether its QR code goes to them by mail, with the recovery
    codes or without, in Czech or in English (1.0.20). */
function makeToken(name) {
  var mailOn = MAIL ? Promise.resolve(MAIL) : api('mail').then(function (d) { MAIL = d; return d; }).catch(function () { return {mode: 'off'}; });
  mailOn.then(function (mailCfg) {
  modal(name ? 'Replace the token of ' + name : 'Make a token', function (body) {
    var sec1 = el('div', 'form-sec');
    var who = textBox(name || '', 'novak@example.cz', 'mono');
    noI18n(who);
    if (name) who.disabled = true;
    sec1.appendChild(formField('For', who, 'The whole name as the VPN sends it, realm and all. Type part of a name and pick the person from the directory.'));
    var display = '';
    var g = el('div', 'formgrid');
    var pend = switchBox(false);
    g.appendChild(formField('Not in use until confirmed', pend,
      'The first code from the phone switches it on - for a token somebody scans later, on their own.'));
    var note = textBox('', '', '');
    g.appendChild(formField('A note', note));
    sec1.appendChild(g);
    body.appendChild(sec1);

    var sec2 = el('div', 'form-sec');
    sec2.appendChild(el('h3', '', 'Send it by mail'));
    var off = (mailCfg.mode || 'off') === 'off';
    var send = switchBox(false);
    var addr = textBox('', 'novak@example.cz', 'mono');
    addr.type = 'email';
    noI18n(addr);
    var codes = switchBox(!!mailCfg.codes);
    var lang = selectBox([['cs', 'Čeština'], ['en', 'English']], mailCfg.lang || 'cs');
    noI18n(lang);
    var g2 = el('div', 'formgrid');
    var f1 = formField('Send the QR code', send, off ? 'Sending mail is switched off - Settings → Mail.' : 'To the address below, as soon as the token is made.');
    g2.appendChild(f1);
    var f2 = formField('With the recovery codes', codes, 'Each signs in once, in place of a code from the phone.');
    g2.appendChild(f2);
    sec2.appendChild(g2);
    var g3 = el('div', 'formgrid');
    var fa = formField('To', addr, 'Read from the directory when the person is picked; it can be changed.');
    g3.appendChild(fa);
    var fl = formField('Language of the mail', lang);
    g3.appendChild(fl);
    sec2.appendChild(g3);
    var warn = el('p', 'note warn small', 'Whoever reads this mail can make the person’s codes: send it only to their own mailbox.');
    sec2.appendChild(warn);
    body.appendChild(sec2);
    if (off) send._input.disabled = true;
    var paint = function () {
      var on = send._get() && !off;
      [f2, fa, fl, warn].forEach(function (x) { x.classList.toggle('asleep', !on); });
      addr.disabled = codes._input.disabled = lang.disabled = !on;
    };
    send._input.addEventListener('change', paint);
    paint();
    /* The address out of the directory: when somebody is picked, or when
       the name is typed whole and the box is left. Changed by hand, it is
       left as it is. */
    var byHand = false;
    addr.addEventListener('input', function () { byHand = true; });
    var fill = function (mail, shown) {
      if (shown) display = shown;
      if (mail && (!byHand || !addr.value)) { addr.value = mail; byHand = false; }
      if (mail && !off && !send._get()) { send._input.checked = true; paint(); }
    };
    var asked = '';
    var ask = function () {
      var n = who.value.trim();
      if (!n || n === asked || n.indexOf('@') < 0) return;
      asked = n;
      api('mail', {action: 'mail_of', user: n}).then(function (d) { fill(d.mail, d.display); }).catch(function () {});
    };
    if (!name) personSuggest(who, {picked: function (p) { asked = p.name; fill(p.mail, p.display); }});
    else ask();
    who.addEventListener('blur', function () { setTimeout(ask, 200); });
    var said = el('div', 'said');
    body.appendChild(said);
    MODAL_GO = function (button) {
      if (send._get() && !addr.value.trim()) { said.className = 'said bad'; said.textContent = 'a mail address to send it to'; return; }
      busy(button, true);
      api('token', {action: 'enroll', name: who.value, pending: pend._get(), note: note.value,
                    mail: send._get() && !off, mail_to: addr.value.trim(), mail_codes: codes._get(),
                    mail_lang: lang.value, display: display,
                    portal_url: location.origin + '/'}).then(function (d) {
        loadTokens();
        var mailed = send._get() && !off ? {ok: !d.mail_error, to: addr.value.trim(), error: d.mail_error,
                                             steps: d.mail_steps} : null;
        showMade(d.made, mailed);
      }).catch(function (e) { said.className = 'said bad'; said.textContent = e.message; })
        .then(function () { busy(button, false); });
    };
  }, [{words: 'Close', close: true}, {words: name ? 'Replace it' : 'Make it', cls: 'primary', icon: 'token',
       go: function (b) { MODAL_GO(b); }}], 'medium');
  });
}
var MODAL_GO = null;
$('tk-add').onclick = function () { makeToken(''); };

/* ==========================================================================
   Requests and codes
   ========================================================================== */
var RQ_SINCE = null;
function resultTag(r) {
  var tone = {accept: 'ok', reject: 'crit', drop: 'warn', acct: 'dim'}[r] || 'dim';
  var words = {accept: 'let in', reject: 'refused', drop: 'not answered', acct: 'accounting'}[r] || r;
  return el('span', 'tag ' + tone, words);
}

/* In a cluster, which node a line of a log was written on (1.0.45). */
function manyNodes() {
  return !!(STATUS && ((STATUS.nodes || []).length > 1 || (STATUS.replication || {}).mode));
}
function nodeCell(n) {
  var td = el('td', 'small');
  if (n) td.appendChild(noI18n(el('span', 'tag dim node-tag', n)));
  else td.appendChild(el('span', 'muted', '–'));
  return td;
}

function requestTable(rows) {
  var nd = manyNodes();
  return listTable(['When', 'Name', 'Result', 'Why', 'Client', 'From', 'Device', {words: 'ms', cls: 'num'}].concat(nd ? ['Node'] : []), rows, function (r) {
    var tr = el('tr');
    if (r.result === 'reject') tr.className = 'is-banned';
    tr.appendChild(stampCell(r.ts));
    var n = el('td');
    n.appendChild(noI18n(el('span', 'mono', r.username || '–')));
    if (r.realm) n.appendChild(noI18n(el('span', 'sub', r.realm)));
    tr.appendChild(n);
    var rs = el('td'); rs.appendChild(resultTag(r.result)); tr.appendChild(rs);
    tr.appendChild(el('td', 'small', r.result === 'accept' ? (r.otp || '') : (r.reason || '')));
    tr.appendChild(noI18n(el('td', '', r.client || '')));
    tr.appendChild(noI18n(el('td', 'mono small', r.calling || '')));
    tr.appendChild(noI18n(el('td', 'small', r.device || '')));
    tr.appendChild(el('td', 'num', r.took_ms === null || r.took_ms === undefined ? '' : num(r.took_ms)));
    if (nd) tr.appendChild(nodeCell(r.node));
    tr.onclick = function () { requestPeek(r.id); };
    return tr;
  }, 'rows');
}

function openRequests(f) {
  $('rq-q').value = f.q || '';
  $('rq-result').value = f.result || '';
  if (f.client) { ensureOption($('rq-client'), f.client); $('rq-client').value = f.client; }
  else $('rq-client').value = '';
  RQ_SINCE = f.since ? f : null;
  PAGE.requests = 0;
  showTab('requests');
}
function ensureOption(sel, value) {
  if (!Array.prototype.some.call(sel.options, function (o) { return o.value === value; })) {
    var o = el('option', '', value); o.value = value; sel.appendChild(o);
  }
}

/* Where a code was checked, in words (1.0.36): "test-dry" came up raw. */
function howWords(h) {
  h = String(h || '');
  var dry = /-dry$/.test(h);
  var base = h.replace(/-dry$/, '');
  var w = ({portal: 'enrolment pages', test: 'a test', 'command line': 'command line',
            radius: 'RADIUS', admin: 'administration', code: 'code', scratch: 'recovery code'})[base] || base;
  return dry ? w + ' (nothing used up)' : w;
}

function activityTable(rows) {
  var nd = manyNodes();
  return listTable(['When', 'Name', 'Result', 'Why - what the token said', 'Where', 'From', 'Device', {words: 'ms', cls: 'num'}].concat(nd ? ['Node'] : []).concat(['']), rows, function (r) {
    var tr = el('tr');
    if (r.result === 'reject') tr.className = 'is-banned';
    tr.appendChild(stampCell(r.ts));
    var n = el('td');
    n.appendChild(noI18n(el('span', 'mono', r.name || '–')));
    if (r.realm) n.appendChild(noI18n(el('span', 'sub', r.realm)));
    tr.appendChild(n);
    var rs = el('td');
    rs.appendChild(r.kind === 'code' ? el('span', 'tag ' + (r.result === 'accept' ? 'ok' : 'crit'), r.result === 'accept' ? 'right' : 'wrong')
                                     : resultTag(r.result));
    tr.appendChild(rs);
    tr.appendChild(el('td', 'small', r.why || ''));
    var wh = el('td');
    if (r.kind === 'code') wh.appendChild(el('span', 'tag dim', howWords(r.source) || 'code'));
    else wh.appendChild(noI18n(el('span', '', r.source || '')));
    tr.appendChild(wh);
    tr.appendChild(noI18n(el('td', 'mono small', r.from || '')));
    tr.appendChild(noI18n(el('td', 'small', r.device || '')));
    tr.appendChild(el('td', 'num', r.ms === null || r.ms === undefined ? '' : num(r.ms)));
    if (nd) tr.appendChild(nodeCell(r.node));
    var tools = el('td', 'rowtools');
    if (r.name) {
      var tk = iconButton('token', 'Its token');
      tk.onclick = function (ev) { ev.stopPropagation(); tokenPeek(r.name); };
      tools.appendChild(tk);
    }
    tr.appendChild(tools);
    tr.onclick = function () { if (r.kind === 'code') codePeek(r); else requestPeek(r.id); };
    return tr;
  }, 'rows');
}

function loadRequests() {
  var per = Number($('rq-per').value);
  var hours = Number($('rq-hours').value) + 1;
  if (RQ_SINCE) hours = Math.max(1, Math.ceil((Date.now() / 1000 - RQ_SINCE.since) / 3600) + 1);
  $('rq-client').disabled = $('rq-kind').value === 'codes';
  api('activity&q=' + encodeURIComponent($('rq-q').value) + '&hours=' + hours + '&result=' + $('rq-result').value
      + '&kind=' + $('rq-kind').value + '&client=' + encodeURIComponent($('rq-client').value)
      + '&limit=' + per + '&offset=' + PAGE.requests * per
      + (RQ_SINCE ? '&since=' + Math.floor(RQ_SINCE.since) + '&until=' + Math.ceil(RQ_SINCE.until) : tpQuery('rq-hours', 'since', 'until')))
    .then(function (d) {
    QS.requests.said(d.q_error || '');
      var sel = $('rq-client');
      (d.clients || []).forEach(function (c) { ensureOption(sel, c); });
      var rows = d.rows;
      var host = $('rq-table');
      clear(host);
      if (RQ_SINCE) {
        var b = el('p', 'note');
        b.textContent = 'Only ' + stamp(RQ_SINCE.since) + ' to ' + clockWords(new Date(RQ_SINCE.until * 1000)) + '. ';
        var all = el('a', 'fgo', 'Show all');
        all.onclick = function () { RQ_SINCE = null; loadRequests(); };
        b.appendChild(all);
        host.appendChild(b);
      }
      host.appendChild(activityTable(rows));
      $('rq-said').textContent = num(d.total) + ' matching';
      pager('rq-pager', PAGE.requests, per, d.total, function (p) { PAGE.requests = p; loadRequests(); });
      explainWhatWasDrawn(host);
    }).catch(oops);
}
$('rq-q').addEventListener('input', debounce(function () { PAGE.requests = 0; loadRequests(); }, 300));
['rq-kind', 'rq-hours', 'rq-result', 'rq-client', 'rq-per'].forEach(function (id) {
  $(id).onchange = function () { PAGE.requests = 0; RQ_SINCE = null; loadRequests(); };
});

function stepsList(steps) {
  var list = el('div', 'steps');
  (steps || []).forEach(function (s) {
    var row = el('div', 'step ' + (s.ok ? 'ok' : 'bad'));
    var mark = el('span', 'step-mark');
    mark.innerHTML = iconMarkup(s.ok ? 'check' : 'cancel', 15);
    row.appendChild(mark);
    var words = el('span', 'step-words');
    words.appendChild(el('b', '', s.what));
    if (s.said) words.appendChild(el('span', 'd', s.said));
    if (s.ms !== undefined) words.appendChild(el('span', 'd', s.ms + ' ms'));
    row.appendChild(words);
    list.appendChild(row);
  });
  return list;
}

function pairsTable(pairs) {
  return listTable(['Attribute', 'Value'], pairs || [], function (p) {
    var tr = el('tr');
    tr.appendChild(noI18n(el('td', 'mono small', p[0])));
    tr.appendChild(noI18n(el('td', 'mono small', p[1])));
    return tr;
  });
}

function requestPeek(id) {
  peek('Request ' + id, function () { return api('radius-row&id=' + id); }, function (body, d) {
    var r = d.row;
    var res = el('span'); res.appendChild(resultTag(r.result));
    body.appendChild(peekFacts([['When', stamp(r.ts)], ['Name', r.username || '–'], ['Result', res],
                                ['Client', r.client || r.src], ['From', r.calling || '–'],
                                ['Took', (r.took_ms || 0) + ' ms']].concat(manyNodes() ? [['Node', r.node || '–']] : [])));
    if (r.reason) body.appendChild(el('p', 'note', r.reason));
    if (r.steps && r.steps.length) {
      body.appendChild(el('h3', 'peek-h', 'How it was decided'));
      body.appendChild(stepsList(r.steps));
    }
    body.appendChild(el('h3', 'peek-h', 'What was asked'));
    body.appendChild(pairsTable(r.attrs));
    if (r.reply && r.reply.length) {
      body.appendChild(el('h3', 'peek-h', 'What was answered'));
      body.appendChild(pairsTable(r.reply));
    }
    var row = el('div', 'btnrow');
    row.style.marginTop = '14px';
    if (r.username) {
      var tk = cmdButton('Its token', 'token', '');
      tk.onclick = function () { tokenPeek(r.username); };
      row.appendChild(tk);
    }
    body.appendChild(row);
  });
  $('modal-box').className = 'box medium';
}

function codePeek(r) {
  if (r.kind === 'code') {
    r = {id: r.id, ts: r.ts, name: r.name, ok: r.result === 'accept', said: r.why, how: r.source,
         src: r.from, rid: r.rid, node: r.node};
  }
  modal(r.name, function (body) {
    var ok = el('span'); ok.appendChild(el('span', 'tag ' + (r.ok ? 'ok' : 'crit'), r.ok ? 'yes' : 'no'));
    body.appendChild(peekFacts([['When', stamp(r.ts)], ['Right', ok], ['How', howWords(r.how) || '–'], ['From', r.src || '–']]
      .concat(manyNodes() ? [['Node', r.node || '–']] : [])));
    body.appendChild(el('p', 'note', r.said + (r.step_off ? ' (' + (r.step_off > 0 ? '+' : '') + r.step_off + ' step)' : '')));
    if (r.rid) body.appendChild(kvTable([['Request', r.rid]]));
  }, [{words: 'Its token', icon: 'token', go: function () { tokenPeek(r.name); }},
      {words: 'Its requests', icon: 'list', go: function () { closeModal(); openRequests({q: r.name}); }},
      {spacer: true}, {words: 'Close', close: true}], 'medium');
}

/* ==========================================================================
   Test
   ========================================================================== */
function loadTest() {
  /* On which node (1.0.45): in a cluster the test can be made on any node
     that answers, through the database both open. */
  var nsel = $('rt-node');
  if (nsel) {
    var was0 = nsel.value;
    clear(nsel);
    var nodes = (STATUS && STATUS.nodes) || [];
    nodes.forEach(function (n) {
      var o = el('option', '', n.name + (n.me ? ' (this one)' : '') + (n.alive ? '' : ' - not answering'));
      o.value = n.me ? '' : n.name;
      o.disabled = !n.alive && !n.me;
      nsel.appendChild(o);
    });
    $('rt-node-item').hidden = nodes.length <= 1;
    if (was0 !== undefined) nsel.value = was0;
  }
  api('clients').then(function (d) {
    var sel = $('rt-client');
    var was = sel.value;
    clear(sel);
    d.clients.forEach(function (c) {
      var o = el('option', '', c.name + ' (' + c.address + (c.realm ? ', @' + c.realm : '') + ')');
      o.value = c.id;
      sel.appendChild(o);
    });
    if (was) sel.value = was;
  }).catch(oops);
}
$('rt-how').onchange = function () { $('rt-client-item').hidden = $('rt-how').value !== 'direct'; };
$('rt-go').onclick = function () {
  var b = $('rt-go');
  busy(b, true);
  var out = $('rt-out');
  clear(out);
  out.appendChild(el('p', 'muted', 'Asking…'));
  api('radtest', {user: $('rt-user').value, password: $('rt-pass').value, how: $('rt-how').value,
                  client: $('rt-client').value, node: ($('rt-node') || {}).value || ''}).then(function (d) {
    clear(out);
    var ok = d.result === 'accept';
    out.appendChild(el('div', 'result-big ' + (ok ? 'ok' : 'bad'),
      ok ? 'Access-Accept' : (d.result === 'reject' || !d.result ? 'Access-Reject' : String(d.result))));
    if (d.node && manyNodes()) out.appendChild(el('p', 'muted small', 'Made on ' + d.node + '.'));
    if (d.how === 'udp') {
      out.appendChild(el('p', 'muted small', 'Answered in ' + d.took_ms + ' ms.'));
      out.appendChild(pairsTable(d.answer.filter(function (p) { return p[0] !== 'Message-Authenticator'; })));
      if (d.row) {
        var more = cmdButton('Every step of it', 'search', 'small');
        more.style.marginTop = '10px';
        more.onclick = function () { requestPeek(d.row); };
        out.appendChild(more);
      }
    } else {
      if (d.reason) out.appendChild(el('p', 'note', d.reason));
      out.appendChild(stepsList(d.steps));
      if (d.reply && d.reply.length) out.appendChild(pairsTable(d.reply));
    }
    explainWhatWasDrawn(out);
  }).catch(function (e) {
    clear(out);
    out.appendChild(el('p', 'bad', e.message));
  }).then(function () { busy(b, false); });
};

/* ==========================================================================
   Events
   ========================================================================== */
function loadEvents() {
  var per = 100;
  api('events&q=' + encodeURIComponent($('ev-q').value) + '&kind=' + encodeURIComponent($('ev-kind').value)
      + tpQuery('ev-time') + '&limit=' + per + '&offset=' + PAGE.events * per).then(function (d) {
    QS.events.said(d.q_error || '');
    var sel = $('ev-kind');
    (d.kinds || []).forEach(function (k) { ensureOption(sel, k); });
    var host = $('ev-table');
    clear(host);
    var nd = manyNodes();
    host.appendChild(listTable(['When', 'Kind', 'Who', 'What'].concat(nd ? ['Node'] : []), d.rows, function (r) {
      var tr = el('tr');
      tr.appendChild(stampCell(r.ts));
      var k = el('td'); k.appendChild(el('span', 'tag ' + (r.level === 'warn' || r.level === 'bad' ? 'warn' : 'dim'), r.kind));
      tr.appendChild(k);
      tr.appendChild(noI18n(el('td', '', r.who || '')));
      tr.appendChild(el('td', '', r.words));
      if (nd) tr.appendChild(nodeCell(r.node));
      return tr;
    }));
    pager('ev-pager', PAGE.events, per, d.total, function (p) { PAGE.events = p; loadEvents(); });
  }).catch(oops);
}
$('ev-q').addEventListener('input', debounce(function () { PAGE.events = 0; loadEvents(); }, 300));

/* ---- the enrolment pages, person by person (1.0.16) ---------------------- */
var EN_STEP = {signed_in: ['signed in', 'info'], enrolled: ['made a token', 'ok'],
               confirmed: ['confirmed it', 'ok'], replacing: ['replaced it', 'warn'],
               refused: ['could not sign in', 'crit'], not_allowed: ['may not enrol', 'crit'],
               stopped: ['stopped replacing', 'dim'], other: ['other', 'dim']};
function loadEnrolment() {
  var per = 100;
  api('enrolment&q=' + encodeURIComponent($('en-q').value) + '&step=' + encodeURIComponent($('en-step').value)
      + '&since=0' + tpQuery('en-since') + '&limit=' + per + '&offset=' + PAGE.enrolment * per).then(function (d) {
    QS.enrolment.said(d.q_error || '');
    var c = d.counts || {};
    $('en-said').textContent = d.on ? num(d.total) + ' matching' : 'the enrolment pages are switched off';
    var tiles = $('en-tiles');
    clear(tiles);
    [['signed_in', 'Signed in'], ['enrolled', 'Made a token'], ['confirmed', 'Confirmed'],
     ['replacing', 'Replaced'], ['refused', 'Turned away'], ['not_allowed', 'Not allowed']].forEach(function (one) {
      var f = el('div', 'fact');
      f.appendChild(el('div', 'k', one[1]));
      f.appendChild(el('div', 'v ' + (one[0] === 'refused' || one[0] === 'not_allowed' ? (c[one[0]] ? 'bad' : '') : ''), num(c[one[0]] || 0)));
      tiles.appendChild(f);
    });
    var host = $('en-table');
    clear(host);
    var nd = manyNodes();
    host.appendChild(listTable(['When', 'Who', 'Step', 'From', 'What happened'].concat(nd ? ['Node'] : []), d.rows, function (r) {
      var tr = el('tr');
      tr.appendChild(stampCell(r.ts));
      tr.appendChild(noI18n(el('td', 'mono', r.who || '')));
      var k = el('td');
      var w = EN_STEP[r.step] || EN_STEP.other;
      k.appendChild(el('span', 'tag ' + w[1], w[0] || r.step));
      tr.appendChild(k);
      tr.appendChild(noI18n(el('td', 'mono small muted', r.src || '')));
      tr.appendChild(el('td', '', r.words));
      if (nd) tr.appendChild(nodeCell(r.node));
      if (r.who) {
        tr.style.cursor = 'pointer';
        tr.onclick = function () { tokenPeek(r.who); };
      }
      return tr;
    }, 'plain|Nobody has been to the enrolment pages in this time'));
    pager('en-pager', PAGE.enrolment, per, d.total, function (p) { PAGE.enrolment = p; loadEnrolment(); });
  }).catch(oops);
}
$('en-q').addEventListener('input', debounce(function () { PAGE.enrolment = 0; loadEnrolment(); }, 300));
$('en-step').onchange = $('en-since').onchange = function () { PAGE.enrolment = 0; loadEnrolment(); };
$('ev-kind').onchange = function () { PAGE.events = 0; loadEvents(); };
if ($('ev-time')) $('ev-time').onchange = function () { PAGE.events = 0; loadEvents(); };
$('log-read').onclick = function () {
  api('log&lines=' + $('log-lines').value).then(function (d) {
    var out = $('log-out');
    out.hidden = false;
    out.textContent = d.lines.join('\n');
    out.scrollTop = out.scrollHeight;
  }).catch(oops);
};

/* ==========================================================================
   Settings: the rail, the panes, and the settings drawn from the daemon
   ========================================================================== */
var RAIL = {pinned: false, open: null, shut: null};
function showPane(name) {
  if (!$('pane-' + name)) name = 'radius';
  PANE = name;
  document.querySelectorAll('#ctl-nav button[data-pane]').forEach(function (b) {
    b.classList.toggle('on', b.dataset.pane === name);
  });
  document.querySelectorAll('.ctl-pane').forEach(function (p) { p.hidden = p.id !== 'pane-' + name; });
  writeHash();
  if (name === 'clients') loadClients();
  if (name === 'realms') loadRealms();
  if (name === 'dir') loadDirs();
  if (name === 'people') loadUsers();
  if (name === 'db') loadDb();
  if (name === 'ha') loadHa();
  if (name === 'mail') loadMail();
  if (name === 'isemon') drawIsemon();
  if (name === 'about') drawAbout();
  if (name === 'upgrade') loadUpgrade();
  if (name === 'web') loadWeb();
  if (name === 'fw') loadFw();
  if (name === 'portal') $('portal-url').textContent = location.protocol + '//' + location.host + '/';
  /* The save bar where there is a setting to save, and nowhere else - a page
     of clients or directories saves each one in its own window. */
  var pane = $('pane-' + name);
  $('save-bar').style.display = (pane && pane.querySelector('.set-item')) || Object.keys(DIRTY || {}).length
    || Object.keys(PENDING).length || name === 'fw' ? '' : 'none';
  markDirtyCount();
}
document.querySelectorAll('#ctl-nav button[data-pane]').forEach(function (b) {
  b.onclick = function () { showPane(b.dataset.pane); };
});
function pinRail(on) {
  RAIL.pinned = !!on;
  var nav = $('ctl-nav'), pin = $('ctl-pin');
  nav.classList.toggle('pinned', RAIL.pinned);
  document.querySelector('.ctl-layout').classList.toggle('nav-pinned', RAIL.pinned);
  pin.setAttribute('aria-pressed', RAIL.pinned ? 'true' : 'false');
  explain(pin, RAIL.pinned ? 'The menu is staying open. Press again to let it hide itself at the edge of the screen.'
    : 'The menu hides itself at the edge of the screen and slides out when you point at it. Press this to keep it open.');
  try { localStorage.setItem('otp-rail-pinned', RAIL.pinned ? '1' : '0'); } catch (e) { }
}
(function rail() {
  var nav = $('ctl-nav'), pin = $('ctl-pin');
  pin.innerHTML = iconMarkup('pin', 17);
  pin.onclick = function (e) { e.stopPropagation(); pinRail(!RAIL.pinned); };
  nav.addEventListener('mouseenter', function () {
    clearTimeout(RAIL.shut);
    RAIL.open = setTimeout(function () { nav.classList.add('open'); }, 60);
  });
  nav.addEventListener('mouseleave', function () {
    clearTimeout(RAIL.open);
    RAIL.shut = setTimeout(function () {
      if (document.activeElement && document.activeElement.id === 'ctl-find' && $('ctl-find').value) return;
      nav.classList.remove('open');
    }, 260);
  });
  var was = '0';
  try { was = localStorage.getItem('otp-rail-pinned') || '0'; } catch (e) { }
  pinRail(was === '1');
}());
$('ctl-find').addEventListener('input', function () {
  var want = $('ctl-find').value.trim().toLowerCase();
  var box = $('ctl-found');
  clear(box);
  if (!want || !SETTINGS) { box.hidden = true; return; }
  var hits = SETTINGS.settings.filter(function (s) {
    return (s.name + ' ' + s.key + ' ' + s.says).toLowerCase().indexOf(want) >= 0;
  }).slice(0, 12);
  if (!hits.length) box.appendChild(el('div', 'ctl-none', 'Nothing by that name'));
  hits.forEach(function (s) {
    var b = el('button', 'ctl-hit');
    b.type = 'button';
    b.appendChild(el('span', 'ctl-hit-t', s.name));
    var pane = Object.keys(SETTINGS.panes).filter(function (p) { return SETTINGS.panes[p].indexOf(s.key) >= 0; })[0];
    var where = document.querySelector('.ctl-nav [data-pane="' + (pane || 'about') + '"]');
    b.appendChild(el('span', 'ctl-hit-w', where ? where.textContent.trim() : (pane || '')));
    b.onclick = function () {
      showPane(pane || 'about');
      $('ctl-find').value = '';
      box.hidden = true;
      var item = document.querySelector('.set-item[data-key="' + s.key + '"]');
      if (item) {
        item.scrollIntoView({block: 'center'});
        item.classList.remove('found');
        void item.offsetWidth;
        item.classList.add('found');
        item.addEventListener('animationend', function () { item.classList.remove('found'); }, {once: true});
      }
    };
    box.appendChild(b);
  });
  box.hidden = !hits.length;
});

function loadSettings(redraw) {
  api('settings').then(function (d) {
    SETTINGS = d;
    if (redraw !== false) { DIRTY = {}; drawSettings(); markDirtyCount(); }
    var h = (location.hash || '').split('/');
    showPane(PANE || (h[1] || 'radius'));
  }).catch(oops);
}
function settingByKey(key) {
  return ((SETTINGS && SETTINGS.settings) || []).filter(function (s) { return s.key === key; })[0];
}
function isBool(s) {
  return typeof s.default === 'boolean' || (s.min === 0 && s.max === 1 && typeof s.default === 'number');
}
var TALL = {portal_help: 1, portal_groups: 1, isemon_targets: 1, admin_group_full: 1,
            admin_group_token: 1, admin_group_readonly: 1};

function drawSettings() {
  var shown = {};
  Object.keys(SETTINGS.panes).forEach(function (pane) {
    var host = $('sect-' + pane);
    if (!host) return;
    clear(host);
    var grid = el('div', 'set-grid');
    SETTINGS.panes[pane].forEach(function (key) {
      var s = settingByKey(key);
      if (!s) return;
      shown[key] = true;
      grid.appendChild(settingItem(s));
    });
    host.appendChild(grid);
  });
  var rest = SETTINGS.settings.filter(function (s) { return !shown[s.key]; });
  var host = $('sect-rest');
  clear(host);
  $('rest-card').hidden = !rest.length;
  if (rest.length) {
    var g = el('div', 'set-grid');
    rest.forEach(function (s) { g.appendChild(settingItem(s)); });
    host.appendChild(g);
  }
  applyOnlyWhen();
  explainWhatWasDrawn($('tab-settings'));
}

/* Name, control, then the words, each in its own row of the grid, so every
   box on a row starts at the same height even where one name takes two
   lines (1.0.20). */
function settingItem(s) {
  var item = settingItemBare(s);
  var tail = el('div', 'set-tail');
  Array.prototype.slice.call(item.children, 2).forEach(function (c) { tail.appendChild(c); });
  item.appendChild(tail);
  return item;
}
function settingItemBare(s) {
  var item = el('div', 'set-item' + (isBool(s) ? ' set-bool' : ''));
  item.dataset.key = s.key;
  var label = el('label', '', s.name || s.key);
  label.setAttribute('for', 'set-' + s.key);
  var info = el('span', 'iinfo', 'i');
  info.setAttribute('role', 'button');
  info.tabIndex = 0;
  var asText = function (v) { return richText(Array.isArray(v) ? v.join(', ') : String(v)); };
  var where = s.source;
  var story = '<span class="k">on the command line this one is <b>otp --set ' + richText(s.key)
    + '=…</b> · running: ' + (s.secret ? (s.set ? 'set' : 'not set') : asText(s.value))
    + '<br><span class="' + (where === 'default' ? 'same' : 'diff') + '">' + richText(s.source_says || '')
    + (s.saved_by ? ' (by ' + richText(s.saved_by) + (s.saved_at ? ', ' + ago(s.saved_at) : '') + ')' : '')
    + '</span>'
    + (s.file_only ? '<br><span class="same">kept in ' + richText(SETTINGS.config_file)
       + ' - a database cannot hold its own address</span>' : '')
    + (where !== 'default' && !s.secret && String(s.value) !== String(s.default)
       ? '<br><span class="same">the built-in default is ' + asText(s.default) + '</span>' : '') + '</span>';
  var whole = s.says || 'No words have been written for this one yet.';
  if (s.node_key && SETTINGS.cluster) {
    story += '<br><span class="diff">' + richText('this node’s own - every node of the cluster has one of its own; the others’ are in Settings → High availability') + '</span>';
  }
  explain(info, whole, story);
  explain(label, whole, story);
  label.appendChild(info);
  /* A node's own setting, in a cluster (1.0.37): said beside its name. */
  if (s.node_key && SETTINGS.cluster) {
    label.appendChild(document.createTextNode(' '));
    var nt = el('span', 'tag info', 'this node');
    nt.title = SETTINGS.node;
    label.appendChild(nt);
    label.appendChild(document.createTextNode(' '));
    label.appendChild(noI18n(el('span', 'tag dim', SETTINGS.node)));
  }
  item.appendChild(label);
  var input;
  if (isBool(s)) {
    input = switchBox(s.value === true || String(s.value) === '1');
    input._input.disabled = !ADMIN;
    input._input.addEventListener('change', function () { markDirty(item, s); });
    input.id = 'set-' + s.key;
    /* The name is a label for the checkbox itself, so a click on it flips
       the switch (1.0.15); the wrapper keeps the id the readers look up. */
    input._input.id = 'set-' + s.key + '-sw';
    label.setAttribute('for', input._input.id);
    item.appendChild(input);
    if (s.says) item.appendChild(saysBlock(s.says));
    return item;
  }
  if (s.choices && s.choices.some(function (c) {
    return String((s.choice_words && s.choice_words[c]) || c).length > 30;
  })) item.classList.add('wide');
  if (s.choices) {
    input = selectBox(s.choices.map(function (c) { return [c, (s.choice_words && s.choice_words[c]) || c]; }), s.value);
  } else if (s.key === 'default_realm' || s.key === 'portal_realm') {
    var rl = (SETTINGS.realms || []).slice();
    if (s.value && rl.indexOf(s.value) < 0) rl.push(s.value);
    input = selectBox([['', s.key === 'default_realm' ? 'none - a name has to be written whole'
                                                      : 'as the default realm']]
      .concat(rl.map(function (d) { return [d, '@' + d]; })), s.value);
  } else if (s.key === 'admin_directory') {
    input = selectBox([['', 'none - only the accounts made here']].concat((SETTINGS.directories || []).map(function (d) { return [d, d]; })), s.value);
  } else if (typeof s.min === 'number') {
    input = el('input');
    input.type = 'number';
    input.min = s.min;
    input.max = s.max;
    input.value = s.value;
  } else if (TALL[s.key]) {
    item.classList.add('tall');
    input = el('textarea');
    input.value = s.value === null || s.value === undefined ? '' : String(s.value);
    input.rows = s.key === 'portal_help' ? 6 : 2;
  } else {
    input = s.secret ? maskBox(s.value, '', '') : textBox(s.value, '', '');
    if (s.secret) {
      input.placeholder = s.set ? 'set - leave as it is to keep it' : 'not set';
      input.addEventListener('focus', function () { if (input.value.indexOf('•') === 0) input.select(); });
    }
  }
  input.id = 'set-' + s.key;
  input.disabled = !ADMIN;
  input.addEventListener('input', function () { markDirty(item, s); });
  input.addEventListener('change', function () { markDirty(item, s); });
  item.appendChild(input);
  if (s.key === 'portal_groups' && ADMIN) {
    /* The groups found in the directory and picked, rather than typed - the
       same list as for a realm and for the administrators' groups. */
    var pickRow = el('div', 'btnrow');
    pickRow.style.marginTop = '8px';
    var pickGo = cmdButton('Find and pick the groups', 'search', 'small');
    pickGo.id = 'portal-groups-find';
    pickGo.onclick = function () { portalGroupsPick(input, item, s); };
    pickRow.appendChild(pickGo);
    item.appendChild(pickRow);
  }
  if (s.says) item.appendChild(saysBlock(s.says));
  return item;
}

/** The groups that may enrol, found in the directory: each one's button
    puts it into the box or takes it out, and the box is saved with the
    other settings as before. */
function portalGroupsPick(input, item, s) {
  var dirs = SETTINGS.directories || [];
  if (!dirs.length) { toast('there is no directory to look in: Settings → Active Directory', 'bad'); return; }
  var names = function () {
    return input.value.split(/[;\n]+/).map(function (x) { return x.trim(); }).filter(Boolean);
  };
  var put = function (list) {
    input.value = list.join('\n');
    markDirty(item, s);
  };
  var has = function (g) {
    var cn = String(g.cn).toLowerCase(), dn = String(g.dn).toLowerCase();
    return names().filter(function (v) { v = v.toLowerCase(); return v === cn || v === dn; });
  };
  modal('Groups that may enrol', function (body) {
    body.appendChild(el('p', 'note', 'Find the groups in the directory and press May enrol beside each one that may: it goes into the box, and pressed again it comes out. Nested groups count - a member of a group inside one of these may enrol as well. Nothing is kept until Save the changes.'));
    var dir = selectBox(dirs.map(function (d) { return [d, d]; }), dirs[0]);
    noI18n(dir);
    /* The directory the enrolment pages sign people in against: the one of
       their realm, or of the default realm. */
    api('realms').then(function (d) {
      var want = String(readValue(settingByKey('portal_realm') || {key: 'portal_realm'}) || '')
        || String(readValue(settingByKey('default_realm') || {key: 'default_realm'}) || '');
      var r = (d.realms || []).filter(function (x) {
        return x.name === want || x.suffix === want;
      })[0] || (d.realms || []).filter(function (x) { return x.directory && x.enabled; })[0];
      if (r && r.directory && dirs.indexOf(r.directory) >= 0) {
        dir.value = r.directory;
        dir.dispatchEvent(new Event('change'));
      }
    }).catch(function () { /* the first one, then */ });
    if (dirs.length > 1) body.appendChild(formField('Look in the directory', dir));
    var chosen = el('div', 'chips');
    chosen.style.margin = '6px 0 12px';
    var drawChosen = function () {
      clear(chosen);
      var list = names();
      if (!list.length) { chosen.appendChild(el('span', 'muted small', 'No group yet: nobody may enrol.')); return; }
      list.forEach(function (n) {
        var c = el('span', 'chip');
        c.appendChild(noI18n(el('span', 'mono', n)));
        var x = iconButton('close', 'Take it out');
        x.onclick = function () {
          put(names().filter(function (v) { return v !== n; }));
          drawChosen();
          if (gb._paint) gb._paint();
        };
        c.appendChild(x);
        chosen.appendChild(c);
      });
    };
    body.appendChild(el('h3', 'peek-h', 'Chosen'));
    body.appendChild(chosen);
    drawChosen();
    var gb = groupBrowser({
      dir: function () { return dir._get ? dir._get() : dir.value; },
      buttons: [{words: 'May enrol', icon: 'check',
                 on: function (g) { return has(g).length > 0; },
                 toggle: function (g) {
                   var hit = has(g);
                   if (hit.length) put(names().filter(function (v) { return hit.indexOf(v) < 0; }));
                   else put(names().concat([g.cn]));
                   drawChosen();
                 }}]
    });
    body.appendChild(gb);
  }, [{words: 'Done', cls: 'primary', icon: 'check', close: true}], 'large');
}

function readValue(s) {
  var input = $('set-' + s.key);
  if (!input) return undefined;
  if (input._get) return input._get();
  if (typeof s.min === 'number' && !s.choices) return String(input.value).trim() === '' ? '' : Number(input.value);
  return input.value;
}
function markDirty(item, s) {
  var now = readValue(s);
  var was = isBool(s) ? ((s.value === true || String(s.value) === '1') ? '1' : '0') : String(s.value);
  var changed = was !== String(now);
  item.classList.toggle('changed', changed);
  /* The database's address is what the steps below it ask about, never
     saved by the save bar (1.0.37): saved, the next restart opened a
     database nothing had been carried into. */
  if (/^db_(engine|host|port|name|user|password)$/.test(s.key)) { delete DIRTY[s.key]; markDirtyCount(); applyOnlyWhen(); return; }
  if (changed) DIRTY[s.key] = now; else delete DIRTY[s.key];
  markDirtyCount();
  applyOnlyWhen();
}
/* Changes that are not settings (1.0.56) - the firewall, the web address,
   a certificate authority pasted in - wait for the same save bar:
   PENDING[key] = {save: function () -> Promise (false: not done), reset}. */
var PENDING = {};
function pendingSet(key, p) { PENDING[key] = p; markDirtyCount(); }
function markDirtyCount() {
  var n = Object.keys(DIRTY).length + Object.keys(PENDING).length;
  $('set-said').textContent = n ? n + ' change(s) not saved yet' : '';
  $('save-bar').classList.toggle('dirty', n > 0);
  if (n && ADMIN) $('save-bar').style.display = '';
}
/* A question as a promise: true for the button, false for anything else. */
function askThen(title, words, buttonWords, danger) {
  return new Promise(function (done) {
    var said = false;
    var end = function (v) { if (!said) { said = true; done(v); } };
    confirmThen(title, words, buttonWords, function () { end(true); }, danger);
    var gen = MODAL_GEN;
    var watch = setInterval(function () {
      if (said) { clearInterval(watch); return; }
      if ($('modal').hidden || MODAL_GEN > gen + 1) { clearInterval(watch); setTimeout(function () { end(false); }, 50); }
    }, 300);
  });
}
function applyOnlyWhen() {
  var rules = (SETTINGS && SETTINGS.only_when) || {};
  Object.keys(rules).forEach(function (key) {
    var item = document.querySelector('.set-item[data-key="' + key + '"]');
    var master = $('set-' + rules[key][0]);
    if (!item || !master) return;
    var now = master._get ? String(master._get()) : String(master.value);
    var want = rules[key][1];
    var live = want === '*' ? !!now.trim() : (want.slice(-4) === '-not' ? now !== want.slice(0, -4) : now === want);
    item.classList.toggle('asleep', !live);
    var says = item.querySelector('.asleep-why');
    if (!live && !says) {
      var other = settingByKey(rules[key][0]) || {};
      (item.querySelector('.set-tail') || item).appendChild(el('div', 'says asleep-why', want === '*' ? 'Not in use until ' + other.name + ' is filled in.'
        : (isBool(other) ? 'Not in use while ' + other.name + ' is off.'
           : 'Not in use while ' + other.name + ' is “' + ((other.choice_words || {})[now] || now) + '”.')));
    } else if (live && says) says.remove();
  });
}
$('set-save').onclick = function () {
  var want = {};
  Object.keys(DIRTY).forEach(function (k) {
    var s = settingByKey(k);
    if (s && s.secret && String(DIRTY[k]).indexOf('•') === 0) return;
    want[k] = DIRTY[k];
  });
  var keys = Object.keys(PENDING);
  if (!Object.keys(want).length && !keys.length) { toast('nothing has changed'); return; }
  busy($('set-save'), true);
  document.querySelectorAll('.set-item.refused').forEach(function (n) { n.classList.remove('refused'); });
  var chain = Promise.resolve(true);
  if (Object.keys(want).length) {
    chain = api('settings', {settings: want}).then(function (d) {
      toast(d.message, 'good');
      loadSettings();
      tick();
      return true;
    }).catch(function (e) {
      var said = String(e.message || e);
      var hit = SETTINGS.settings.filter(function (one) { return said.indexOf(one.key) === 0; })[0];
      if (hit) {
        var item = document.querySelector('.set-item[data-key="' + hit.key + '"]');
        if (item) { item.classList.add('refused'); item.scrollIntoView({block: 'center'}); }
        said = '“' + hit.name + '”' + said.slice(hit.key.length);
      }
      toast(said, 'bad');
      return false;
    });
  }
  /* Then the rest, one after the other; the first that fails stops it. */
  keys.forEach(function (k) {
    chain = chain.then(function (ok) {
      if (!ok || !PENDING[k]) return ok;
      return Promise.resolve(PENDING[k].save()).then(function (r) {
        if (r === false) return false;
        delete PENDING[k];
        return true;
      }).catch(function (e) { oops(e); return false; });
    });
  });
  chain.then(function () { markDirtyCount(); busy($('set-save'), false); });
};
$('set-reset').onclick = function () {
  var keys = Object.keys(PENDING);
  keys.forEach(function (k) { try { PENDING[k].reset(); } catch (e) { /* drawn again anyway */ } });
  PENDING = {};
  loadSettings(); toast('put back as the daemon has them');
};
window.addEventListener('beforeunload', function (e) {
  if (Object.keys(DIRTY).length || Object.keys(PENDING).length) { e.preventDefault(); e.returnValue = ''; }
});

/* ---- the clients ---------------------------------------------------------- */
var CLIENTS = null;
function loadClients() {
  api('clients').then(function (d) {
    CLIENTS = d;
    var host = $('cl-table');
    clear(host);
    if (!d.clients.length) host.appendChild(el('p', 'note', 'No client yet: nothing can ask this server. Add the VPN concentrator, and 127.0.0.1 for testing.'));
    host.appendChild(listTable(['Name', 'Address', 'Realm added', 'Secret', 'Message-Authenticator', 'State', 'Last asked', 'Note', ''],
      d.clients, function (c) {
        var tr = el('tr');
        tr.appendChild(noI18n(el('td', '', c.name)));
        tr.appendChild(noI18n(el('td', 'mono', c.address)));
        tr.appendChild(noI18n(el('td', 'mono', c.realm ? '@' + c.realm : '–')));
        var sec = el('td');
        sec.appendChild(c.secret_lost ? el('span', 'tag crit', 'cannot be opened') : noI18n(el('span', 'mono muted', c.secret)));
        tr.appendChild(sec);
        tr.appendChild(el('td', 'muted', c.require_ma ? 'required' : 'checked when sent'));
        var st = el('td'); st.appendChild(el('span', 'tag ' + (c.enabled ? 'ok' : 'dim'), c.enabled ? 'on' : 'off'));
        tr.appendChild(st);
        tr.appendChild(c.last_seen ? stampCell(c.last_seen) : el('td', 'muted', 'never'));
        tr.appendChild(noI18n(el('td', 'muted small', c.note || '')));
        var tools = el('td', 'rowtools');
        if (ADMIN) {
          var e = iconButton('edit', 'Edit');
          e.onclick = function (ev) { ev.stopPropagation(); editClient(c); };
          var x = iconButton('trash', 'Take it away');
          x.onclick = function (ev) {
            ev.stopPropagation();
            confirmThen('Take the client ' + c.name + ' away',
              'Requests from ' + htmlText(c.address) + ' are not answered any more.', 'Take it away', function () {
                api('clients', {action: 'delete', id: c.id}).then(function (d2) { toast(d2.message, 'good'); loadClients(); }).catch(oops);
              });
          };
          tools.appendChild(e); tools.appendChild(x);
        }
        tr.appendChild(tools);
        if (ADMIN) tr.onclick = function () { editClient(c); };
        return tr;
      }, 'rows'));
    explainWhatWasDrawn(host);
  }).catch(oops);
}
$('cl-add').onclick = function () { editClient(null); };

function editClient(c) {
  c = c || {enabled: 1, require_ma: 0};
  modal(c.id ? 'The client ' + c.name : 'A new client', function (body) {
    var g = el('div', 'formgrid');
    var name = textBox(c.name, 'ASA', '');
    var addr = textBox(c.address, '192.0.2.1 or 192.0.2.0/24', 'mono');
    var secret = secretBox(c.id ? c.secret : '', c.id ? 'set - leave as it is to keep it' : 'something long', 'mono');
    var realm = textBox(c.realm, 'example.cz', 'mono');
    var ma = switchBox(c.require_ma);
    var on = switchBox(c.enabled);
    var note = textBox(c.note, '', '');
    g.appendChild(formField('Name', name, 'What it is called here and in the logs.'));
    g.appendChild(formField('Address', addr, 'The address the requests come from, or a range of them. The narrowest range that holds an address wins.'));
    g.appendChild(formField('Shared secret', secret, 'The same as on the client. Up to 128 characters.'));
    g.appendChild(formField('Realm added to names without one', realm,
      'A name that comes as novak becomes novak@ this - what FreeRADIUS’s hints file did. Empty: names are taken as they come.'));
    g.appendChild(formField('Must send a Message-Authenticator', ma,
      'Refuse a request without one. Every current ASA sends it; requiring it closes the BlastRADIUS forgery for good.'));
    g.appendChild(formField('In use', on));
    /* The realms it may use (1.0.33): ticked, only those; none, any. */
    var rbox = el('div', 'realmpick');
    var picks = [];
    var picksLoaded = false;
    var have = String(c.realms || '').split(/[,;\n]+/).map(function (x) { return x.trim().toLowerCase(); }).filter(Boolean);
    api('realms').then(function (d) {
      (d.realms || []).forEach(function (r) {
        var lab = el('label', 'realmpick-one');
        var cb = el('input'); cb.type = 'checkbox'; cb.value = r.name;
        cb.checked = have.indexOf(r.name.toLowerCase()) >= 0;
        lab.appendChild(cb);
        lab.appendChild(noI18n(el('span', '', r.name)));
        lab.appendChild(noI18n(el('span', 'muted small', r.suffix === '*' ? ' every name' : (r.suffix ? ' @' + r.suffix : ' without a realm'))));
        picks.push(cb);
        rbox.appendChild(lab);
      });
      if (!picks.length) rbox.appendChild(el('span', 'muted small', 'No realm yet.'));
      picksLoaded = true;
    }).catch(function () {
      rbox.appendChild(el('span', 'muted small bad', 'The realms could not be read: the ones it may use stay as they are.'));
    });
    var rf = formField('Realms it may use', rbox, 'None ticked: any. Ticked: a name in any other realm is refused from this client - so nobody signs in to the VPN through the realm of the Wi-Fi, which asks for less.');
    rf.classList.add('wide');
    g.appendChild(rf);
    var nf = formField('Note', note); nf.classList.add('wide');
    g.appendChild(nf);
    body.appendChild(g);
    if (c.id) {
      var show = cmdButton('Show the secret', 'eye', 'small');
      show.style.marginTop = '10px';
      show.onclick = function () {
        api('clients', {action: 'secret', id: c.id}).then(function (d) { secret.value = d.secret; secret._show(); }).catch(oops);
      };
      body.appendChild(show);
    }
    MODAL_GO = function (b) {
      busy(b, true);
      api('clients', {action: 'save', client: {id: c.id, name: name.value, address: addr.value,
        secret: secret.value === c.secret ? undefined : secret.value, realm: realm.value,
        require_ma: ma._get(), enabled: on._get(), note: note.value,
        /* Not sent before the list is there (1.0.44): an empty one would
           have let the client use every realm. */
        realms: picksLoaded ? picks.filter(function (x) { return x.checked; }).map(function (x) { return x.value; }) : undefined}}).then(function (d) {
        toast(d.message, 'good'); closeModal(); loadClients();
      }).catch(oops).then(function () { busy(b, false); });
    };
  }, [{words: 'Close', close: true}, {words: 'Save', cls: 'primary', icon: 'save', go: function (b) { MODAL_GO(b); }}], 'medium');
}

/* ---- the realms ----------------------------------------------------------- */
var REALMS = null;
var MODE_WORDS = {otp: 'the code alone', password_otp: 'the directory password, then the code',
                  password: 'the directory password alone'};
var LOOKUP_WORDS = {upn: 'the whole name, as userPrincipalName', sam: 'the part before the @, as sAMAccountName',
                    none: 'by the form of the name (with an @: userPrincipalName)'};
function loadRealms() {
  api('realms').then(function (d) {
    REALMS = d;
    var host = $('rl-table');
    clear(host);
    if (!d.realms.length) host.appendChild(el('p', 'note', 'No realm yet: every request is refused. Add one for what comes after the @ in your names.'));
    host.appendChild(listTable(['Name', 'Takes', 'The password is', 'Directory', 'Groups', 'Answer', 'State', ''],
      d.realms, function (r) {
        var tr = el('tr');
        tr.appendChild(noI18n(el('td', '', r.name)));
        var tk = el('td');
        if (r.suffix && r.suffix !== '*') tk.appendChild(noI18n(el('span', 'mono', '@' + r.suffix)));
        else tk.appendChild(el('span', '', r.suffix === '*' ? 'every name' : 'names without a realm'));
        if (r.suffix && STATUS && STATUS.default_realm === r.suffix) {
          tk.appendChild(el('br'));
          tk.appendChild(el('span', 'tag info', 'default - also without @'));
        }
        tr.appendChild(tk);
        tr.appendChild(el('td', '', MODE_WORDS[r.auth_mode]));
        var dc = el('td');
        if (r.directory) {
          dc.appendChild(noI18n(el('span', '', r.directory)));
          dc.appendChild(el('span', 'muted small', ' (' + ({upn: 'UPN', sam: 'sAMAccountName'}[r.lookup] || 'by the form of the name') + ')'));
        } else dc.textContent = '–';
        tr.appendChild(dc);
        var g = el('td');
        if (!r.groups.length) g.appendChild(el('span', 'muted', 'anybody it finds'));
        r.groups.slice(0, 6).forEach(function (x) { g.appendChild(noI18n(el('span', 'tag namepill', x.group))); g.appendChild(document.createTextNode(' ')); });
        if (r.groups.length > 6) g.appendChild(el('span', 'muted small', '+' + (r.groups.length - 6)));
        tr.appendChild(g);
        tr.appendChild(noI18n(el('td', 'mono small', (r.reply || '').split('\n').join(' · '))));
        var st = el('td'); st.appendChild(el('span', 'tag ' + (r.enabled ? 'ok' : 'dim'), r.enabled ? 'on' : 'off'));
        tr.appendChild(st);
        var tools = el('td', 'rowtools');
        if (ADMIN) {
          var ed = iconButton('edit', 'Edit');
          ed.onclick = function (ev) { ev.stopPropagation(); editRealm(r); };
          tools.appendChild(ed);
          var x = iconButton('trash', 'Take it away');
          x.onclick = function (ev) {
            ev.stopPropagation();
            confirmThen('Take the realm ' + r.name + ' away', 'Names in it are refused from now on.', 'Take it away', function () {
              api('realms', {action: 'delete', id: r.id}).then(function (d2) { toast(d2.message, 'good'); loadRealms(); }).catch(oops);
            });
          };
          tools.appendChild(x);
          tr.onclick = function () { editRealm(r); };
        }
        tr.appendChild(tools);
        return tr;
      }, 'rows'));
    explainWhatWasDrawn(host);
  }).catch(oops);
}
$('rl-add').onclick = function () {
  if (!REALMS) return;
  editRealm({enabled: 1, check_disabled: 1, nested: 1, auth_mode: 'otp', lookup: 'upn', token_name: 'whole',
             groups: [], directory: (REALMS.directories || [])[0] || ''});
};

function editRealm(r) {
  modal(r.id ? 'The realm ' + r.name : 'A new realm', function (body) {
    var g = el('div', 'formgrid');
    var name = textBox(r.name, 'example.cz', '');
    var suffix = textBox(r.suffix, 'example.cz', 'mono');
    var mode = selectBox(Object.keys(MODE_WORDS).map(function (k) { return [k, MODE_WORDS[k]]; }), r.auth_mode);
    var dir = selectBox([['', 'none']].concat((REALMS.directories || []).map(function (d) { return [d, d]; })), r.directory);
    var lookup = selectBox(Object.keys(LOOKUP_WORDS).map(function (k) { return [k, LOOKUP_WORDS[k]]; }), r.lookup);
    var tname = selectBox([['whole', 'the whole name: novak@example.cz'], ['bare', 'the part before the @: novak']], r.token_name || 'whole');
    var dis = switchBox(r.check_disabled);
    var nested = switchBox(r.nested);
    var on = switchBox(r.enabled);
    var reply = el('textarea'); reply.value = r.reply || ''; reply.rows = 3; reply.placeholder = 'Class = VPN_USERS';
    var secs = el('div', 'msects');
    var s1 = msect('What it takes', 'The names this realm answers for, and what the password is.');
    var g1 = el('div', 'formgrid');
    g1.appendChild(formField('Name', name));
    g1.appendChild(formField('Takes the names ending in @', suffix,
      'What follows the @, such as example.cz. <code>*</code> takes every name no other realm does; empty takes names written without a realm.'));
    s1._body.appendChild(g1);
    s1._body.appendChild(formField('The password is', mode,
      'The code alone is how the old token server worked: the VPN asks the directory password itself, somewhere else. The password followed by the code makes this the only server the VPN asks.'));
    /* The naming has long words to choose from: a row of its own, so none
       of them is cut short (1.0.15). */
    s1._body.appendChild(formField('The tokens are named by', tname));
    s1._body.appendChild(formField('In use', on));
    secs.appendChild(s1);
    var s2 = msect('Looking the person up', 'Where the person is found, and what makes the directory refuse them.');
    var g2 = el('div', 'formgrid');
    g2.appendChild(formField('Look the person up in', dir));
    g2.appendChild(formField('Names looked up by', lookup));
    s2._body.appendChild(g2);
    var g2b = el('div', 'formgrid');
    g2b.appendChild(formField('Refuse an account switched off in the directory', dis));
    g2b.appendChild(formField('Groups inside groups count', nested,
      'A member of a group that is itself a member of one below lets in. Off: only direct members, which is what the old handler did.'));
    s2._body.appendChild(g2b);
    secs.appendChild(s2);
    body.appendChild(secs);
    var s3 = msect('The groups that let in', 'Any one of them lets in; none at all lets in anybody the directory finds. Each may add its own lines to the answer - the first group in this list that the person is in is the one whose lines are sent. A name (VPN_USERS) or a whole DN.', true);
    var groupsHost = s3._body;
    var rows = el('div');
    function addRow(one) {
      var row = el('div', 'grouprow');
      var gname = textBox(one.group, 'VPN_USERS', 'mono');
      var gr = el('textarea'); gr.value = one.reply || ''; gr.rows = 1; gr.placeholder = 'Class = VPN_FULL';
      var x = iconButton('trash', 'Take it out');
      x.onclick = function () { row.remove(); };
      row.appendChild(gname); row.appendChild(gr); row.appendChild(x);
      row._get = function () { return {group: gname.value.trim(), reply: gr.value}; };
      rows.appendChild(row);
    }
    (r.groups || []).forEach(addRow);
    groupsHost.appendChild(rows);
    var gb = el('div', 'btnrow');
    var add = cmdButton('Add a group', 'add', 'small');
    add.onclick = function () { addRow({group: '', reply: ''}); };
    gb.appendChild(add);
    groupsHost.appendChild(gb);
    /* The groups, found rather than typed - the same list as the
       administrators' groups under Accounts, isemon's. */
    var findName = function (gg) {
      var cn = String(gg.cn).toLowerCase(), dn = String(gg.dn).toLowerCase();
      return Array.prototype.filter.call(rows.children, function (x) {
        var v = x._get().group.toLowerCase();
        return v === cn || v === dn;
      });
    };
    groupsHost.appendChild(groupBrowser({
      dir: function () { return dir._get ? dir._get() : dir.value; },
      buttons: [{words: 'Lets in', icon: 'check',
                 on: function (gg) { return findName(gg).length > 0; },
                 toggle: function (gg) {
                   var have = findName(gg);
                   if (have.length) { have.forEach(function (x) { x.remove(); }); return false; }
                   addRow({group: gg.cn, reply: ''});
                   return true;
                 }}]
    }));
    var secs2 = el('div', 'msects');
    secs2.appendChild(s3);
    var s4 = msect('The answer to everybody let in', 'Lines that go back to the VPN with every Access-Accept, Name = value.', true);
    s4._body.appendChild(formField('Lines of the answer, Name = value', reply,
      'What goes back to the VPN with every Access-Accept: <code>Class = VPN</code>, <code>ASA-Group-Policy = GP_FULL</code>, '
      + '<code>Session-Timeout = 43200</code>. Known: ' + (REALMS.reply_attrs || []).join(', ') + '.'));
    var nt = textBox(r.note, '', '');
    s4._body.appendChild(formField('Note', nt));
    secs2.appendChild(s4);
    body.appendChild(secs2);
    MODAL_GO = function (b) {
      busy(b, true);
      api('realms', {action: 'save', realm: {id: r.id, name: name.value, suffix: suffix.value, auth_mode: mode.value,
        directory: dir.value, lookup: lookup.value, token_name: tname.value, check_disabled: dis._get(),
        nested: nested._get(), enabled: on._get(), reply: reply.value, note: nt.value,
        groups: Array.prototype.map.call(rows.children, function (x) { return x._get(); })
          .filter(function (x) { return x.group; })}}).then(function (d) {
        toast(d.message, 'good'); closeModal(); loadRealms();
      }).catch(oops).then(function () { busy(b, false); });
    };
  }, [{words: 'Close', close: true}, {words: 'Save', cls: 'primary', icon: 'save', go: function (b) { MODAL_GO(b); }}], 'large');
}

/* ---- the directories ------------------------------------------------------ */
function loadDirs() {
  api('directories').then(function (d) {
    var host = $('ad-table');
    clear(host);
    if (!d.directories.length) host.appendChild(el('p', 'note', 'No directory yet. A realm without one checks the code and nothing else.'));
    var list = el('div', 'cardlist');
    d.directories.forEach(function (a) {
      var card = el('div', 'itemcard');
      var head = el('div', 'ic-head');
      var title = el('div', 'ic-title');
      title.appendChild(noI18n(el('b', '', a.name)));
      title.appendChild(el('span', 'tag ' + (a.tls === 'none' ? 'warn' : 'dim'),
        a.tls === 'none' ? 'plain LDAP, ' + a.port : (a.tls === 'ldaps' ? 'LDAPS, ' : 'StartTLS, ') + a.port));
      title.appendChild(el('span', 'tag ' + (a.tls === 'none' ? 'dim' : (a.verify ? 'ok' : 'warn')),
        a.tls === 'none' ? 'no certificate' : (a.verify ? (a.ca_says ? 'checked against ' + a.ca_says.subject : 'checked') : 'NOT checked')));
      if (!a.enabled) title.appendChild(el('span', 'tag dim', 'off'));
      head.appendChild(title);
      var tools = el('div', 'ic-tools');
      var chk = cmdButton('Check it', 'pulse', 'small');
      chk.onclick = function (ev) { ev.stopPropagation(); checkDir(a.name); };
      var who = cmdButton('Look a name up', 'search', 'small');
      who.onclick = function (ev) { ev.stopPropagation(); lookupDir(a.name); };
      if (TOKADMIN) { tools.appendChild(chk); tools.appendChild(who); }
      if (ADMIN) {
        var ed = iconButton('edit', 'Edit');
        ed.onclick = function (ev) { ev.stopPropagation(); editDir(a); };
        tools.appendChild(ed);
        var x = iconButton('trash', 'Take it away');
        x.onclick = function (ev) {
          ev.stopPropagation();
          confirmThen('Take the directory ' + a.name + ' away', 'Nothing is looked up in it any more.', 'Take it away', function () {
            api('directories', {action: 'delete', id: a.id}).then(function (d2) { toast(d2.message, 'good'); loadDirs(); }).catch(oops);
          });
        };
        tools.appendChild(x);
      }
      head.appendChild(tools);
      card.appendChild(head);
      var facts = el('div', 'ic-facts');
      var fact = function (k, v, mono) {
        var f = el('div', 'ic-fact');
        f.appendChild(el('span', 'k', k));
        var vv = el('span', 'v' + (mono ? ' mono' : ''));
        if (typeof v === 'string') vv.textContent = v; else vv.appendChild(v);
        noI18n(vv);
        f.appendChild(vv);
        facts.appendChild(f);
      };
      var hosts = el('span', 'chips');
      String(a.hosts || '').split(/\s*,\s*/).filter(Boolean).forEach(function (h) { hosts.appendChild(el('span', 'chip mono', h)); });
      fact('Servers, in order', hosts);
      fact('Where to look (the base)', a.base || '–', true);
      fact('The account it reads with', a.bind_dn || 'nobody', true);
      fact('A short name is', a.user_attr || 'sAMAccountName', true);
      card.appendChild(facts);
      if (ADMIN) card.onclick = function () { editDir(a); };
      list.appendChild(card);
    });
    host.appendChild(list);
    DIRS = d.directories;
    drawCaPick();
    explainWhatWasDrawn(host);
  }).catch(oops);
}
$('ad-add').onclick = function () { editDir({tls: 'ldaps', port: 636, verify: 1, nested: 1, enabled: 1, timeout_s: 10, user_attr: 'sAMAccountName'}); };

function editDir(a) {
  modal(a.id ? 'The directory ' + a.name : 'A new directory', function (body) {
    var g = el('div', 'formgrid');
    var name = textBox(a.name, 'AD', '');
    var hosts = textBox(a.hosts, 'dc1.example.local, dc2.example.local', 'mono');
    var tls = selectBox([['ldaps', 'LDAPS (636)'], ['starttls', 'StartTLS (389)'], ['none', 'plain LDAP (389) - a test only']], a.tls);
    var port = textBox(a.port, '636', 'mono');
    tls.onchange = function () { port.value = tls.value === 'ldaps' ? '636' : '389'; };
    var verify = switchBox(a.verify);
    var base = textBox(a.base, 'DC=example,DC=local', 'mono');
    var bind = textBox(a.bind_dn, 'otp@example.local', 'mono');
    var pw = secretBox(a.id ? a.bind_pw : '', a.id ? 'set - leave as it is to keep it' : '', 'mono');
    var attr = textBox(a.user_attr || 'sAMAccountName', '', 'mono');
    var to = textBox(a.timeout_s || 10, '', 'mono');
    var on = switchBox(a.enabled);
    var ca = el('textarea'); ca.rows = 4; ca.placeholder = '-----BEGIN CERTIFICATE-----'; ca.value = a.ca || '';
    var secs = el('div', 'msects');
    var s1 = msect('How it is reached', 'The domain controllers, in the order they are asked, and how.');
    var g1 = el('div', 'formgrid');
    g1.appendChild(formField('Name', name, 'What the realms call it.'));
    g1.appendChild(formField('In use', on));
    s1._body.appendChild(g1);
    s1._body.appendChild(formField('Servers, in the order to ask them', hosts, 'Separated by commas. One that cannot be reached is passed over for the next.'));
    var g1b = el('div', 'formgrid');
    g1b.appendChild(formField('How it is reached', tls));
    g1b.appendChild(formField('Port', port));
    g1b.appendChild(formField('Check its certificate', verify, 'Off is for a test: a directory reached without checking its certificate is one anybody on the path can pretend to be.'));
    g1b.appendChild(formField('Wait for an answer (s)', to));
    s1._body.appendChild(g1b);
    secs.appendChild(s1);
    var s2 = msect('Reading it', 'The account it reads with - it needs nothing but to read - and where it looks.');
    s2._body.appendChild(formField('The account it reads with', bind, 'A user principal name (otp@example.local) or a whole DN. It needs nothing but to read.'));
    s2._body.appendChild(formField('Its password', pw));
    s2._body.appendChild(formField('Where to look (the base)', base));
    s2._body.appendChild(formField('A short name is', attr, 'The attribute a name without its realm is looked up by.'));
    secs.appendChild(s2);
    body.appendChild(secs);
    if (!a.id) {
      var cf = formField('The certificate authority that signed its certificate (PEM)', ca,
        'Needed when the domain controllers’ certificates come from an authority of your own that this machine does not already trust.');
      body.appendChild(cf);
    } else {
      body.appendChild(el('p', 'note', a.ca_says
        ? 'The certificate authority: ' + (a.ca_says.subject || 'imported') + ', good until '
          + (a.ca_says.until || '–') + '. It is imported, read from a file or taken away under '
          + 'The certificate authority, below the list of directories.'
        : 'No certificate authority is imported for it. That is done under The certificate '
          + 'authority, below the list of directories.'));
    }
    MODAL_GO = function (b) {
      busy(b, true);
      api('directories', {action: 'save', directory: {id: a.id, name: name.value, hosts: hosts.value, tls: tls.value,
        port: Number(port.value), verify: verify._get(), base: base.value, bind_dn: bind.value,
        bind_pw: pw.value === a.bind_pw ? undefined : pw.value, user_attr: attr.value, timeout_s: Number(to.value),
        enabled: on._get(), nested: 1, ca: a.id ? undefined : ca.value, note: a.note || ''}}).then(function (d) {
        toast(d.message, 'good'); closeModal(); loadDirs();
      }).catch(oops).then(function () { busy(b, false); });
    };
  }, [{words: 'Close', close: true}, {words: 'Save', cls: 'primary', icon: 'save', go: function (b) { MODAL_GO(b); }}], 'large');
}

function checkDir(name) {
  peek('Checking ' + name, function () { return api('directories', {action: 'check', name: name}); }, function (body, d) {
    var c = d.check;
    body.appendChild(peekFacts([['How', c.tls === 'none' ? 'plain LDAP' : c.tls], ['Certificate', c.tls === 'none' ? 'not used' : (c.verify ? 'checked' : 'NOT checked')],
                                ['Took', num(c.took_ms) + ' ms']]));
    c.servers.forEach(function (s) {
      body.appendChild(el('h3', 'peek-h', s.host + ':' + s.port));
      body.appendChild(stepsList(s.steps));
    });
  });
}
/** A question in the page's own popup - never the browser's. `fields` are
    {label, type, placeholder, says}; `go(values, button)` gets what was typed. */
function askInModal(title, lede, fields, words, icon, go) {
  var boxes = [];
  modal(title, function (body) {
    if (lede) body.appendChild(el('p', 'note', lede));
    var g = el('div', 'formgrid');
    fields.forEach(function (f) {
      var input = f.type === 'password' ? maskBox('', '', '') : el('input');
      if (f.type !== 'password') input.type = f.type || 'text';
      input.placeholder = f.placeholder || '';
      input.autocomplete = 'off';
      if (f.mono) input.className = 'mono';
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); $('modal-foot').querySelector('.btn.primary').click(); }
      });
      boxes.push(input);
      g.appendChild(formField(f.label, input, f.says));
      if (f.people) personSuggest(input, f.people);
    });
    body.appendChild(g);
    setTimeout(function () { if (boxes[0]) boxes[0].focus(); }, 60);
  }, [{words: 'Close', close: true}, {words: words, cls: 'primary', icon: icon, go: function (b) {
    go(boxes.map(function (x) { return x.value; }), b);
  }}], 'medium');
}

function lookupDir(name) {
  askInModal('Look a name up in ' + name, 'What the directory says about one person: who they are, whether the '
    + 'account is switched off or has run out, and every group they are in, those inside groups as well.',
    [{label: 'Who', placeholder: 'novak@example.cz or novak', mono: true, people: {directory: name},
      says: 'A name as the VPN sends it, or a short one - or part of a name, and pick one.'}], 'Look it up', 'search', function (v) {
      var who = v[0].trim();
      if (!who) { toast('type a name first', 'bad'); return; }
      lookupDirShow(name, who);
    });
}
function lookupDirShow(name, who) {
  peek(who + ' in ' + name, function () { return api('directories', {action: 'lookup', name: name, user: who}); }, function (body, d) {
    if (!d.entry) { body.appendChild(el('p', 'note', 'The directory has nobody by that name.')); return; }
    var e = d.entry;
    body.appendChild(peekFacts([['Who', e.display || e.sam], ['Switched off', e.disabled ? 'yes' : 'no'],
                                ['Expires', e.expires ? stamp(e.expires) : 'never'], ['Took', d.took_ms + ' ms']]));
    body.appendChild(kvTable([['DN', e.dn], ['userPrincipalName', e.upn], ['sAMAccountName', e.sam], ['Mail', e.mail],
                              ['Department', e.department]]));
    body.appendChild(el('h3', 'peek-h', 'Groups, those inside groups as well'));
    var box = el('div', 'namesrow');
    (d.groups || []).slice().sort().forEach(function (gname) { box.appendChild(noI18n(el('span', 'tag namepill', gname))); });
    body.appendChild(box);
  });
}

/* ---- bringing tokens over ------------------------------------------------- */
$('imp-drop').onclick = function () { $('imp-files').click(); };
['dragover', 'dragenter'].forEach(function (k) {
  $('imp-drop').addEventListener(k, function (e) { e.preventDefault(); $('imp-drop').classList.add('over'); });
});
$('imp-drop').addEventListener('dragleave', function () { $('imp-drop').classList.remove('over'); });
$('imp-drop').addEventListener('drop', function (e) {
  e.preventDefault();
  $('imp-drop').classList.remove('over');
  importFiles(e.dataTransfer.files);
});
$('imp-files').onchange = function () { importFiles(this.files); this.value = ''; };
function importFiles(list) {
  if (!ADMIN) { toast('only a full administrator may bring tokens over', 'bad'); return; }
  var files = Array.prototype.slice.call(list || []);
  if (!files.length) return;
  Promise.all(files.map(function (f) {
    /* A ZIP goes as it is, and is opened by the daemon (1.0.33). */
    if (/\.zip$/i.test(f.name)) {
      if (f.size > 5 * 1024 * 1024) return Promise.reject(new Error(f.name + ' is bigger than 5 MB: split it'));
      return f.arrayBuffer().then(function (buf) {
        var bytes = new Uint8Array(buf), bin = '';
        for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        return {name: f.name, zip: btoa(bin)};
      });
    }
    return f.text().then(function (t) { return {name: f.name, text: t}; });
  })).then(function (got) {
    return api('token-import', {files: got, replace: $('imp-replace').checked});
  }).then(function (d) {
    var host = $('imp-out');
    clear(host);
    host.appendChild(listTable(['Token', 'What happened'], d.done || [], function (r) {
      var tr = el('tr');
      tr.appendChild(noI18n(el('td', 'mono', r.name)));
      tr.appendChild(el('td', /^imported/.test(r.said) ? 'good' : 'muted', r.said));
      return tr;
    }));
    toast((d.done || []).length + ' file(s) read', 'good');
  }).catch(oops);
}

/* ---- isemon --------------------------------------------------------------- */
function drawIsemon() {
  var host = $('isemon-state');
  clear(host);
  var i = (STATUS && STATUS.isemon) || (SETTINGS && SETTINGS.isemon) || {};
  host.appendChild(el('h2', '', 'What is being sent'));
  host.appendChild(peekFacts([['Sending', i.on ? 'yes' : 'no'], ['As the host', i.host || '–'],
                              ['To', (i.targets || []).join(', ') || '–'],
                              ['Last sent', i.last_sent ? ago(i.last_sent) : 'never'],
                              ['Waiting', num(i.queued || 0)], ['Files here', i.files ? i.file_dir : 'no']]));
  Object.keys(i.sent || {}).forEach(function (k) {
    host.appendChild(el('p', 'small good', k + ': ' + num(i.sent[k]) + ' line(s) sent'));
  });
  Object.keys(i.trouble || {}).forEach(function (k) {
    host.appendChild(el('p', 'small bad', k + ': ' + i.trouble[k]));
  });
  var guide = el('div', 'guide');
  guide.appendChild(el('h3', 'peek-h', 'On the isemon machine'));
  guide.appendChild(el('p', 'note', 'isemon reads a token server from two files under /var/log/remote/HOST/: totp.cgi.log and radius-detail.log. Its rsyslog needs a rule for both program names - deploy/isemon/11-otp.conf in this package, copied to /etc/rsyslog.d/ there - and in isemon: Settings → The OTP logs switched on, the folder of this host in it, and RADIUS detail switched on.'));
  var pre = el('pre', 'wrap mono');
  pre.textContent = 'if ($programname == "totp.cgi" or $programname == "radius-detail") then {\n'
    + '    action(type="omfile" dynaFile="OTPFile" fileOwner="root" fileGroup="isemon" fileCreateMode="0640")\n    stop\n}';
  guide.appendChild(pre);
  host.appendChild(guide);
  if (ADMIN) {
    var t = cmdButton('Send a test line', 'pulse', 'small');
    t.style.marginTop = '10px';
    t.onclick = function () {
      api('isemon', {}).then(function (d) { STATUS.isemon = d.isemon; drawIsemon(); toast('sent - see above whether it went', 'good'); }).catch(oops);
    };
    host.appendChild(t);
  }
}

/* ---- accounts ------------------------------------------------------------- */
function loadUsers() {
  colsCardSay();
  api('users').then(function (d) {
    var host = $('us-table');
    clear(host);
    host.appendChild(listTable(['Name', 'Role', 'Signs in', 'State', 'Last signed in', 'From', 'Columns', 'Note', ''], d.users, function (u) {
      var tr = el('tr');
      var n = el('td'); n.appendChild(noI18n(el('span', 'mono', u.name)));
      if (u.display) n.appendChild(noI18n(el('span', 'sub', u.display)));
      tr.appendChild(n);
      var r = el('td'); r.appendChild(el('span', 'tag ' + roleTone(u.role), roleWords(u.role))); tr.appendChild(r);
      tr.appendChild(el('td', 'muted', u.source === 'directory' ? 'against the directory' : 'a password here'));
      var st = el('td'); st.appendChild(el('span', 'tag ' + (u.disabled ? 'crit' : 'ok'), u.disabled ? 'off' : 'on')); tr.appendChild(st);
      tr.appendChild(u.last_in ? stampCell(u.last_in) : el('td', 'muted', 'never'));
      tr.appendChild(noI18n(el('td', 'mono small', u.last_from || '')));
      tr.appendChild(el('td', 'muted small', u.cols_tables ? num(u.cols_tables) + ' table(s) laid out' : 'as they come'));
      tr.appendChild(noI18n(el('td', 'muted small', u.note || '')));
      var tools = el('td', 'rowtools');
      /* Every row has the same buttons in the same places (1.0.18): one
         that does not apply to this account is there, dimmed, and says why -
         an invisible gap looked like a mistake. */
      var info = iconButton('person', u.source === 'directory'
        ? 'In the directory: who it is, whether the account is switched off, its groups'
        : 'An account kept here, not in a directory');
      if (u.source === 'directory') info.onclick = function (ev) { ev.stopPropagation(); whoisPeek(u.name, 'account'); };
      else info.disabled = true;
      if (ADMIN) {
        /* The role first, the buttons as one group after it. */
        var role = selectBox(d.roles.map(function (x) { return [x.role, x.words]; }), u.role);
        role.onchange = function () { userDo({action: 'role', name: u.name, role: role.value}); };
        role.style.marginRight = '10px';
        tools.appendChild(role);
      }
      tools.appendChild(info);
      if (ADMIN) {
        if (u.source !== 'directory') {
          var pw = iconButton('lock', 'Set a new password');
          pw.onclick = function () {
            askInModal('A new password for ' + u.name, 'They choose their own at the next sign-in.',
              [{label: 'The new one (8 characters at least)', type: 'password'},
               {label: 'Again', type: 'password'}], 'Set it', 'lock', function (v) {
                if (v[0].length < 8) { toast('8 characters at least', 'bad'); return; }
                if (v[0] !== v[1]) { toast('the two are not the same', 'bad'); return; }
                closeModal();
                userDo({action: 'password', name: u.name, password: v[0], must_change: 1});
              });
          };
          tools.appendChild(pw);
        } else {
          var gap = iconButton('lock', 'The password is the directory’s: it is changed there');
          gap.disabled = true;
          tools.appendChild(gap);
        }
        var off = iconButton('power', u.disabled ? 'Let it sign in again' : 'Stop it signing in');
        off.onclick = function () { userDo({action: u.disabled ? 'enable' : 'disable', name: u.name}); };
        var x = iconButton('trash', 'Remove it');
        x.onclick = function () {
          confirmThen('Remove the account ' + u.name, 'It cannot sign in any more.', 'Remove it', function () {
            userDo({action: 'delete', name: u.name});
          });
        };
        tools.appendChild(off); tools.appendChild(x);
        /* Somebody's own layout of the tables, put back as it comes. */
        var cb = iconButton('undo', u.cols_tables
          ? u.name + ' has laid out ' + num(u.cols_tables) + ' table(s) by hand. Put every one of them back as it comes: the widths, the order and the hidden columns. Nothing else of theirs changes.'
          : u.name + ' has every table as it comes: nothing to put back.');
        cb.classList.add('cols-back');
        if (u.cols_tables) {
          cb.onclick = function (ev) {
            ev.stopPropagation();
            confirmThen('The columns of ' + u.name,
              'Every table ' + htmlText(u.name) + ' has laid out goes back as it comes. They see it '
              + 'the next time a page loads.',
              'Put them back', function () {
                colsReset(u.name).then(function () {
                  if (ME && u.name === ME.name) colsCardSay();
                  loadUsers();
                }).catch(oops);
              });
          };
        } else {
          cb.disabled = true;
        }
        tools.appendChild(cb);
      }
      tr.appendChild(tools);
      return tr;
    }));
    explainWhatWasDrawn(host);
  }).catch(oops);
  if (ADMIN) api('sessions').then(function (d) {
    var host = $('se-table');
    clear(host);
    host.appendChild(listTable(['Who', 'Where', 'From', 'Since', 'Last asked', ''], d.sessions, function (s) {
      var tr = el('tr');
      tr.appendChild(noI18n(el('td', 'mono', s.name)));
      tr.appendChild(el('td', '', s.kind === 'admin' ? 'these pages' : 'the enrolment pages'));
      tr.appendChild(noI18n(el('td', 'mono small', s.ip)));
      tr.appendChild(stampCell(s.created));
      tr.appendChild(el('td', 'muted', ago(s.last)));
      var tools = el('td', 'rowtools');
      var x = cmdButton('End it', 'cancel', 'small');
      x.onclick = function () { api('sessions', {id: s.id}).then(function () { loadUsers(); }).catch(oops); };
      tools.appendChild(x);
      tr.appendChild(tools);
      return tr;
    }));
  }).catch(oops);
}
function userDo(body) {
  /* Drawn again either way (1.0.44): a refused change stayed in its box. */
  api('users', body).then(function (d) { toast(d.message, 'good'); loadUsers(); })
    .catch(function (e) { oops(e); loadUsers(); });
}
$('us-add').onclick = function () {
  modal('A new account', function (body) {
    var g = el('div', 'formgrid');
    var name = textBox('', '', 'mono');
    var role = selectBox([['readonly', 'read only'], ['tokenadmin', 'token admin'], ['fulladmin', 'full admin']], 'tokenadmin');
    var pw = secretBox('', '8 characters at least', 'mono');
    var note = textBox('', '', '');
    g.appendChild(formField('Name', name));
    g.appendChild(formField('Role', role));
    g.appendChild(formField('A first password', pw, 'They choose their own at the first sign-in.'));
    g.appendChild(formField('Note', note));
    body.appendChild(g);
    MODAL_GO = function () {
      api('users', {action: 'add', name: name.value, role: role.value, password: pw.value, note: note.value, must_change: 1})
        .then(function (d) { toast(d.message, 'good'); closeModal(); loadUsers(); }).catch(oops);
    };
  }, [{words: 'Close', close: true}, {words: 'Make it', cls: 'primary', icon: 'add', go: function (b) { MODAL_GO(b); }}], true);
};

/* ---- the database --------------------------------------------------------- */
/* ==========================================================================
   The database - as isemon's Settings → The database (1.10.160 - 1.10.218)
   ========================================================================== */
var DBSTATE = null;
var ENGINE_SAID = {sqlite: 'the file on this machine', mariadb: 'MariaDB', postgres: 'PostgreSQL'};
var DUMP_SAID = {sqlite: 'a copy of the file', mariadb: 'a MariaDB dump',
                 postgres: 'a PostgreSQL dump', copy: 'a portable copy'};
var TABLE_SAID = {tokens: 'tokens', radius_log: 'RADIUS requests', otp_log: 'checks of a code',
                  events: 'events', accounts: 'accounts', sessions: 'sign-ins',
                  clients: 'clients', realms: 'realms', directories: 'directories',
                  settings: 'settings', meta: 'notes of its own'};

function loadDb() {
  api('db').then(function (d) {
    DBSTATE = d;
    $('db-size').textContent = bytes(d.size) + ' · ' + d.where;
    drawEngine(d);
    drawDisk(d);
    drawCounts(d);
    keptTable($('db-backups'), d.copies || [], {
      kind: 'copy', head: 'Copies kept (' + d.keep + ' at most)',
      where: 'They are files on this machine, under ' + d.backup_dir + ', each with the key '
        + 'that opens the tokens beside it. Copy them off it if they are to survive the machine.'
    });
    keptTable($('db-dumps'), d.dumps || [], {
      kind: 'dump', head: 'Dumps kept (' + d.keep + ' at most)',
      where: 'They are files on this machine, under ' + d.dump_dir + ', each with the key '
        + 'that opens the tokens beside it. Copy them off it if they are to survive the machine.'
    });
    dumpCard(d);
    drawTune(d);
    drawErasable(d.erasable || {});
    if (d.job && d.job.running) dbWatch();
    explainWhatWasDrawn($('pane-db'));
  }).catch(oops);
}

/* ---- which database everything is kept in -------------------------------- */
function dbAsked() {
  var out = {};
  ['db_engine', 'db_host', 'db_port', 'db_name', 'db_user', 'db_password', 'db_timeout_s'].forEach(function (k) {
    var input = $('set-' + k);
    if (!input) return;
    var v = input._get ? input._get() : input.value;
    if (k === 'db_password' && (v === '' || String(v).indexOf('•') === 0)) return;
    out[k] = (k === 'db_port' || k === 'db_timeout_s') ? (String(v).trim() === '' ? 0 : Number(v)) : v;
  });
  return out;
}
function engineChosen() { return String(dbAsked().db_engine || (DBSTATE && DBSTATE.engine) || 'sqlite'); }
function engineWord(name) { return ENGINE_SAID[name] || name; }

function drawEngine(d) {
  $('db-engine-file').textContent = d.config_file || 'the config file';
  $('db-engine-now').textContent = (ENGINE_SAID[d.engine] || d.engine) + ' · ' + d.where;
  var host = $('db-engine-says');
  clear(host);
  var c = d.counts || {};
  host.appendChild(peekFacts([
    ['In use now', d.version],
    ['Where', noI18n(el('span', 'mono', d.where))],
    ['Holding', num(c.tokens || 0) + ' token(s), ' + num(c.radius_log || 0) + ' RADIUS request(s)'],
    ['Room it takes', bytes(d.size || 0)]
  ]));
  Object.keys(d.drivers || {}).forEach(function (name) {
    var one = d.drivers[name];
    host.appendChild(el('p', 'btnhelp', engineWord(name) + ': '
      + (one.ready ? 'the driver is installed'
         : (one.says || 'no driver') + ' — install ' + one.package)));
  });
  engineButtons();
}
function engineButtons() {
  var chosen = engineChosen();
  var live = String((DBSTATE && DBSTATE.engine) || 'sqlite');
  var same = chosen === live;
  if ($('db-engine-setup')) $('db-engine-setup').disabled = chosen === 'sqlite';
  if ($('db-engine-move')) $('db-engine-move').disabled = same;
  if ($('db-engine-empty')) $('db-engine-empty').disabled = same;
  if ($('db-engine-use')) $('db-engine-use').disabled = same;
}
document.addEventListener('change', function (e) {
  if (e.target && e.target.id === 'set-db_engine') engineButtons();
});

function engineFacts(d) {
  var facts = [['Reached', d.reached ? 'yes' : 'no'], ['Where', d.where || '']];
  if (d.version) facts.push(['It says it is', d.version]);
  if (d.reached) {
    facts.push(['Tables there', num((d.tables || []).length) + ' of ours']);
    facts.push(['Records in it', num(d.rows || 0)]);
    facts.push(['May this account write', d.writable ? 'yes' : 'NO']);
  }
  return peekFacts(facts);
}

/* ---- the job going on, and the bar that says how far ---------------------- */
var DB_WATCHING = null;
function dbBusyButtons(on) {
  ['db-backup', 'db-dump-make', 'db-optimize', 'db-check', 'db-prune', 'db-tidy',
   'db-restore', 'dump-restore', 'db-engine-move', 'erase-go'].forEach(function (id) {
    var b = $(id);
    if (b) b.disabled = on || (id === 'erase-go' && !erasePicked().length)
      || ((id === 'db-restore' || id === 'dump-restore') && !b._held);
  });
}
function dbWatch(done) {
  if (DB_WATCHING) return;
  var box = $('db-going');
  box.hidden = false;
  dbBusyButtons(true);
  var step = function () {
    api('db', {action: 'job'}).then(function (d) {
      var j = d.job || {};
      var pct = j.whole ? Math.min(100, Math.round(100 * j.done / j.whole)) : (j.running ? 5 : 100);
      $('db-going-fill').style.width = pct + '%';
      $('db-going-says').textContent = (j.what || '') + (j.says ? ' — ' + j.says : '')
        + (j.whole ? ' (' + num(j.done) + ' of ' + num(j.whole) + ')' : '');
      /* Every second while the pane is open; every five once it is left, so
         the job's end is still told and the daemon is not asked for nothing. */
      if (j.running) { DB_WATCHING = setTimeout(step, TAB === 'settings' && PANE === 'db' ? 1000 : 5000); return; }
      DB_WATCHING = null;
      dbBusyButtons(false);
      if (j.error) { toast(j.what + ' failed: ' + j.error, 'bad'); $('db-going-says').textContent = j.error; return; }
      var r = j.result || {};
      if (r.rows !== undefined) {
        toast('everything is in ' + r.where + ': ' + num(r.rows) + ' row(s) — now Start using it', 'good');
        $('db-going-says').textContent = 'done: ' + num(r.rows) + ' row(s) in ' + r.where
          + ' · a copy made first: ' + r.copy;
      } else if (r.erased) {
        toast('erased; a copy was made first: ' + r.copy, 'good');
        $('db-going-says').textContent = 'done · a copy made first: ' + r.copy;
      } else if (r.before !== undefined) {
        toast('the disk is given back: ' + bytes(r.before) + ' → ' + bytes(r.after), 'good');
        $('db-going-says').textContent = 'done: ' + bytes(r.before) + ' → ' + bytes(r.after);
      }
      if (done) done(r);
      loadDb();
    }).catch(function (e) { DB_WATCHING = null; dbBusyButtons(false); oops(e); });
  };
  step();
}

/* ---- the disk under it ----------------------------------------------------- */
function drawDisk(d) {
  var host = $('db-disk');
  clear(host);
  var disk = d.disk || {};
  var grew = d.growth || {};
  var cache = d.cache;
  if (cache && cache.low) {
    var slow = el('p', 'note bad');
    slow.appendChild(el('b', '', cache.engine));
    slow.appendChild(document.createTextNode(' keeps '));
    slow.appendChild(el('b', '', bytes(cache.cache)));
    slow.appendChild(document.createTextNode(' of its own in memory ('));
    slow.appendChild(noI18n(el('span', 'mono', cache.setting)));
    slow.appendChild(document.createTextNode(') for a database of '));
    slow.appendChild(el('b', '', bytes(cache.size)));
    slow.appendChild(document.createTextNode('. Its indexes do not fit, so a busy minute waits for the disk. A quarter of the machine’s memory is the usual setting.'));
    host.appendChild(slow);
    if (ADMIN) {
      var go = cmdButton('Tune it for this machine…', 'gear', '');
      go.onclick = openTune;
      host.appendChild(go);
    }
  }
  if (!disk.total) {
    host.appendChild(el('p', 'note', 'The disk this is on could not be measured.'));
    return;
  }
  var share = Number(disk.share || 0);
  var line = el('div', 'disk-bar ' + (share >= 92 ? 'crit' : (share >= 80 ? 'warn' : 'ok')));
  var fill = el('span');
  fill.style.width = Math.max(1, Math.min(100, share)) + '%';
  line.appendChild(fill);
  host.appendChild(line);
  var says = el('p', 'note');
  says.appendChild(el('b', '', bytes(disk.free)));
  says.appendChild(document.createTextNode(' free of ' + bytes(disk.total) + ' on '));
  says.appendChild(noI18n(el('span', 'mono', disk.where || '')));
  says.appendChild(document.createTextNode(' — '));
  says.appendChild(el('span', '', share + '% of it is used'));
  if (grew.a_day) {
    says.appendChild(document.createTextNode(', and this database has been growing '));
    says.appendChild(el('b', '', bytes(grew.a_day)));
    says.appendChild(document.createTextNode(' a day over the last ' + grew.over_days + ' day(s).'));
  } else {
    says.appendChild(document.createTextNode('. How fast it is growing is not known yet: the size is noted once a day, and two are needed.'));
  }
  host.appendChild(says);
  host.appendChild(el('p', 'note', 'That disk holds ' + (disk.holds || '') + '.'));
  if (disk.days_left !== null && disk.days_left !== undefined) {
    host.appendChild(el('p', 'note ' + (disk.days_left < 45 ? 'bad' : ''), disk.days_left > 3650
      ? 'At that rate the disk has years left.'
      : 'At that rate the disk has about ' + num(disk.days_left) + ' day(s) left. Forgetting old records, under the keep-for numbers above, is what shortens it.'));
  }
  var parts = d.parts || [];
  if (parts.length) {
    var wrap = listTable([d.engine !== 'sqlite' ? 'Where' : 'File', 'What it is', {words: 'Size', cls: 'num'}],
      parts, function (one) {
        var tr = el('tr');
        tr.appendChild(noI18n(el('td', 'mono', one.name)));
        tr.appendChild(el('td', 'muted', one.what));
        tr.appendChild(el('td', 'num', bytes(one.bytes)));
        return tr;
      });
    wrap.style.marginTop = '10px';
    host.appendChild(wrap);
  }
}

/* ---- what is in it ----------------------------------------------------------- */
function drawCounts(d) {
  var host = $('db-counts');
  clear(host);
  var rows = (d.tables || []).slice().sort(function (a, b) {
    return (b.bytes || 0) - (a.bytes || 0) || b.rows - a.rows;
  });
  var known = rows.some(function (t) { return t.bytes !== null && t.bytes !== undefined; });
  host.appendChild(listTable(['What', 'Table', {words: 'Rows', cls: 'num'}]
      .concat(known ? [{words: 'Size', cls: 'num'}] : []), rows, function (t) {
    var tr = el('tr');
    tr.appendChild(el('td', '', TABLE_SAID[t.table] || t.table));
    tr.appendChild(noI18n(el('td', 'mono muted small', t.table)));
    tr.appendChild(el('td', 'num', num(t.rows)));
    if (known) tr.appendChild(el('td', 'num', t.bytes === null || t.bytes === undefined ? '–' : bytes(t.bytes)));
    return tr;
  }));
  var key = el('p', 'note ' + (d.key_there ? '' : 'bad'));
  key.appendChild(document.createTextNode(d.key_there ? 'The key that opens the tokens: ' : 'The key that opens the tokens is MISSING: '));
  key.appendChild(noI18n(el('span', 'mono', d.key)));
  host.appendChild(key);
  if (d.free) {
    host.appendChild(el('p', 'btnhelp', d.engine === 'postgres'
      ? num(d.free) + ' row(s) deleted and not yet given back to the disk.'
      : bytes(d.free) + ' free inside it, which the engine uses again; Give the disk back hands it to the operating system.'));
  }
}

/* ---- the two lists of files kept beside it --------------------------------- */
function keptTable(into, rows, opts) {
  clear(into);
  if (!into || !rows || !rows.length) return;
  var dump = opts.kind === 'dump';
  into.appendChild(el('h4', '', opts.head));
  into.appendChild(listTable(['Name', dump ? 'What it is' : 'Taken off', {words: 'Size', cls: 'num'},
                              'Made', 'Key beside it', {words: '', cls: 'act'}], rows, function (b) {
    var line = el('tr');
    line.appendChild(noI18n(el('td', 'mono', b.name)));
    var came = (dump ? DUMP_SAID[b.kind] : ENGINE_SAID[b.from]) || '';
    var mine = !dump || b.mine !== false;
    var off = el('td', came ? (mine ? '' : 'muted') : 'muted', came || 'not said');
    if (!mine) explain(off, 'This dump was taken off a different engine from the one this '
      + 'installation is on now, so it cannot be put back here. Put that engine back on, or '
      + 'use a copy — a copy goes into any of the three.');
    else if (dump && b.kind === 'copy') explain(off, 'Made on a night when the program that '
      + 'dumps this engine was not on the machine, so a portable copy was made instead. It is '
      + 'a whole copy and goes back into any of the three.');
    line.appendChild(off);
    line.appendChild(el('td', 'num', bytes(b.bytes)));
    line.appendChild(stampCell(b.at));
    line.appendChild(el('td', b.key ? 'good' : 'bad', b.key ? 'yes' : 'no'));
    var act = el('td', 'rowtools');
    if (ADMIN) {
      var take = cmdButton('Download', 'down', 'small');
      explain(take, dump
        ? 'Save this dump to the machine you are sitting at. It is what the engine’s own program '
          + 'wrote, so its own tools read it: pg_restore, or the mariadb client. The key that '
          + 'opens the tokens is not in it: it is the .key file beside it.'
        : 'Save this copy to the machine you are sitting at. It is the whole database as it was '
          + 'when the copy was made, and it can be put back here. The key that opens the tokens '
          + 'is not in it: it is the .key file beside it.');
      take.onclick = function () {
        window.location.href = '?api=db-download&name=' + encodeURIComponent(b.name)
          + (dump ? '&kind=dump' : '');
      };
      act.appendChild(take);
      var back = cmdButton('Restore', 'undo', 'small danger');
      explain(back, 'Put <b>this</b> one back, without downloading it and uploading it again: '
        + 'everything in the live database is replaced by what is in this file. You are shown '
        + 'what is in it and asked first, and a copy of what is being replaced is made before '
        + 'anything changes.');
      back.disabled = !mine;
      if (mine) back.onclick = function () { restoreKept(b, opts.kind); };
      act.appendChild(back);
      var gone = cmdButton('Delete', 'trash', 'small danger');
      explain(gone, 'Delete this file, and the key beside it, from the server. The live database is not touched.');
      gone.onclick = function () {
        confirmThen(dump ? 'Delete this dump?' : 'Delete this copy?', 'The file ' + htmlText(b.name)
          + ' and the key beside it are deleted from this machine. The live database is '
          + 'not touched, and the others stay where they are.', 'Delete it', function () {
            api('db', {action: 'delete', name: b.name, kind: opts.kind}).then(function (x) {
              toast(x.message, 'good');
              loadDb();
            }).catch(oops);
          });
      };
      act.appendChild(gone);
    }
    line.appendChild(act);
    return line;
  }));
  into.appendChild(el('p', 'btnhelp', opts.where));
}

function dumpCard(d) {
  var says = $('db-dump-says');
  clear(says);
  var info = d.dump || {};
  $('db-dump-now').textContent = info.words || '';
  $('db-dump-make').disabled = false;
  $('db-dump-get').disabled = false;
  if (info.ready) {
    var line = el('p', 'note good');
    line.appendChild(document.createTextNode('Tonight’s will be '));
    line.appendChild(el('b', '', info.words || 'a dump'));
    if (info.suffix) {
      line.appendChild(document.createTextNode(', written as '));
      line.appendChild(noI18n(el('code', '', info.suffix)));
    }
    line.appendChild(document.createTextNode('.'));
    says.appendChild(line);
  } else {
    says.appendChild(el('p', 'note bad', info.why || 'A dump cannot be made on this machine.'));
    var fix = el('p', 'note');
    fix.appendChild(document.createTextNode('Until it is there, the nightly one is made as a portable copy instead — a whole copy, which goes back into any engine, but several times the size of a dump. To have dumps: '));
    fix.appendChild(noI18n(el('code', '', info.install || '')));
    says.appendChild(fix);
  }
}

/* ---- putting one back ------------------------------------------------------- */
function restoreKept(b, kind) {
  api('db', {action: 'restore_kept', name: b.name, kind: kind, check: true}).then(function (d) {
    askBeforeRestoring(d.says, b.name, function () {
      return api('db', {action: 'restore_kept', name: b.name, kind: kind});
    });
  }).catch(oops);
}

function askBeforeRestoring(says, what, go) {
  var n = (says && says.counts) || {};
  var kind = (says && says.kind) || '';
  modal('Put this database back?', function (body) {
    var facts = [['File', noI18n(el('span', 'mono', String(what)))],
                 ['What it is', DUMP_SAID[kind] || kind], ['Size', bytes(says.bytes || 0)],
                 ['Tables', num(says.tables || 0)], ['Accounts', num(n.accounts || 0)],
                 ['Full administrators', num(says.admins || 0)]];
    if (n.tokens !== undefined) facts.push(['Tokens', num(n.tokens)]);
    if (n.radius_log !== undefined) facts.push(['RADIUS requests', num(n.radius_log)]);
    if (n.otp_log !== undefined) facts.push(['Checks of a code', num(n.otp_log)]);
    if (says.version) facts.push(['Made by otp', says.version]);
    body.appendChild(peekFacts(facts));
    if (kind === 'mariadb' || kind === 'postgres') {
      body.appendChild(el('p', 'note', 'How many records are in a dump is not read from it — that is what putting it back is for.'));
    }
    var warn = el('p', 'note bad');
    warn.textContent = 'Putting it back replaces everything in the live database with what is in that file. A copy of what is being replaced is made first and kept with the others, so this can be undone — but everything recorded since that file was made will only be in that copy.';
    body.appendChild(warn);
    body.appendChild(el('p', 'btnhelp', 'You will probably be signed out: who is signed in came with the file like everything else. The key that opens the tokens is taken from beside the file, or from inside a downloaded copy; where there is none, the key in use stays.'));
  }, [
    {words: 'No, leave it', close: true},
    {words: 'Restore it', cls: 'danger', icon: 'undo', close: true, go: function () {
      go().then(function (done) {
        toast('the database was restored; what it replaced is in ' + done.safety + ' — ' + done.key, 'good');
        setTimeout(function () { window.location.reload(); }, 2500);
      }).catch(oops);
    }}], true);
}

function dbSend(file, check) {
  return fetch('?api=db-restore' + (check ? '&check=1' : ''),
               {method: 'POST', body: file, credentials: 'same-origin',
                headers: {'X-Otp-Restore': '1', 'Content-Type': 'application/octet-stream'}})
    .then(function (r) {
      return r.json().catch(function () {
        throw new Error('the server did not answer with anything readable (HTTP ' + r.status + ')');
      }).then(function (d) {
        if (!r.ok || d.ok === false) throw new Error(d.error || ('the server said ' + r.status));
        return d;
      });
    });
}

function dropBox(ids, empty) {
  var box = $(ids.drop);
  if (!box) return;
  var go = $(ids.go);
  function picked(file) {
    go._held = file || null;
    var says = $(ids.what);
    clear(says);
    says.hidden = !go._held;
    go.disabled = !go._held;
    $(ids.says).textContent = go._held ? go._held.name + ' · ' + bytes(go._held.size) : empty;
    if (!go._held) return;
    says.appendChild(el('p', 'btnhelp', 'Nothing has happened yet. Press Restore from this file and it will be read first — if it is not one of ours, if it is a dump of a different engine, or if it has no administrator in it, it is refused and nothing here changes.'));
  }
  box.onclick = function () { $(ids.file).click(); };
  $(ids.file).onchange = function () { picked(this.files && this.files[0]); this.value = ''; };
  ['dragenter', 'dragover'].forEach(function (name) {
    box.addEventListener(name, function (e) { e.preventDefault(); box.classList.add('over'); });
  });
  ['dragleave', 'drop'].forEach(function (name) {
    box.addEventListener(name, function (e) {
      e.preventDefault();
      box.classList.remove('over');
      if (name === 'drop' && e.dataTransfer && e.dataTransfer.files) picked(e.dataTransfer.files[0]);
    });
  });
  go.onclick = function () {
    var held = go._held;
    if (!held) return;
    busy(go, true);
    dbSend(held, true).then(function (d) {
      askBeforeRestoring(d.says, held.name, function () { return dbSend(held, false); });
    }).catch(oops).then(function () { busy(go, false); });
  };
}

/* ---- the database server's own settings ---------------------------------- */
function drawTune(d) {
  var host = $('db-tune-says');
  clear(host);
  var t = d.tune || {};
  var file = d.engine === 'sqlite';
  $('db-tune').hidden = file;
  var last = t.last;
  $('db-tune-undo').hidden = file || !last || !!last.undone || last.engine !== d.engine;
  $('db-tune-restart').hidden = true;
  if (file) {
    host.appendChild(el('p', 'note', 'The file on this machine has no server to tune: this program sets it up itself.'));
    return;
  }
  if (last && last.engine === d.engine) {
    var p = el('p', 'note');
    if (last.undone) {
      p.appendChild(document.createTextNode('Put back as it was before'));
      p.appendChild(document.createTextNode(' ' + stamp(last.undone) + (last.undone_by ? ' · ' + last.undone_by : '') + '.'));
    } else {
      p.appendChild(document.createTextNode('Tuned for its machine'));
      p.appendChild(document.createTextNode(' ' + stamp(last.at) + (last.by ? ' · ' + last.by : '') + ':'));
      var set = last.set || {};
      Object.keys(set).sort().forEach(function (n, i) {
        p.appendChild(document.createTextNode(i ? ', ' : ' '));
        p.appendChild(noI18n(el('span', 'mono', n + ' = ' + set[n])));
      });
    }
    host.appendChild(p);
  } else {
    host.appendChild(el('p', 'note', 'Not tuned from this page yet.'));
  }
  if ((t.pending || []).length) {
    var w = el('p', 'note bad');
    w.appendChild(document.createTextNode('Waiting for the server’s next start:'));
    t.pending.forEach(function (n, i) {
      w.appendChild(document.createTextNode(i ? ', ' : ' '));
      w.appendChild(noI18n(el('span', 'mono', n)));
    });
    host.appendChild(w);
    if (t.restart && t.restart.may) {
      $('db-tune-restart').hidden = false;
    } else {
      if (t.restart && t.restart.why) host.appendChild(el('p', 'note', 'This program cannot restart it from here: ' + t.restart.why + '.'));
      host.appendChild(el('p', 'note', 'On the server, as root:'));
      host.appendChild(noI18n(el('pre', 'mono small', 'systemctl restart ' + ((t.restart && t.restart.unit) || 'postgresql'))));
      host.appendChild(el('p', 'btnhelp', 'Or let these pages do it: install.sh --upgrade puts in the rule that lets otp restart PostgreSQL on this machine, and nothing else (--no-db-restart takes it away).'));
    }
  }
  if ((t.lost || []).length) {
    var l = el('p', 'note bad');
    l.appendChild(document.createTextNode('MariaDB has been started again since, and these are back as they were:'));
    t.lost.forEach(function (n, i) {
      l.appendChild(document.createTextNode(i ? ', ' : ' '));
      l.appendChild(noI18n(el('span', 'mono', n)));
    });
    host.appendChild(l);
    host.appendChild(el('p', 'note', 'The file the popup gives keeps them over a restart.'));
  }
}

var TUNE = null;
function tuneAdminBoxes(body, engine) {
  var g = el('div', 'formgrid');
  var who = textBox(TUNE && TUNE.user || '', engine === 'postgres' ? 'postgres' : 'root', '');
  who.autocomplete = 'off';
  who.setAttribute('data-lpignore', 'true');
  var word = maskBox('', '', '');
  word.setAttribute('data-lpignore', 'true');
  word.value = TUNE && TUNE.pass || '';
  g.appendChild(formField('An administrator on that server', who, 'Only where otp’s own account may not change them. Used for this one request and stored nowhere: not in the settings, not in the database, not in any log.'));
  g.appendChild(formField('Its password', word));
  body.appendChild(g);
  return {who: who, word: word};
}
function tuneForget() {
  TUNE = null;
  Array.prototype.forEach.call(document.querySelectorAll('#modal-body input'), function (i) { i.value = ''; });
}
function tuneAsked() {
  var out = {machine: {}};
  if (!TUNE) return out;
  if (TUNE.boxes) { TUNE.user = TUNE.boxes.who.value.trim(); TUNE.pass = TUNE.boxes.word.value; }
  if (TUNE.hw) {
    TUNE.ram = TUNE.hw.ram.value.replace(',', '.').trim();
    TUNE.cpus = TUNE.hw.cpus.value.trim();
    TUNE.disk = TUNE.hw.disk.value;
  }
  if (TUNE.ram) out.machine.ram_gb = TUNE.ram;
  if (TUNE.cpus) out.machine.cpus = TUNE.cpus;
  if (TUNE.disk) out.machine.disk = TUNE.disk;
  out.admin_user = TUNE.user || '';
  out.admin_password = TUNE.pass || '';
  return out;
}
function openTune() {
  TUNE = {user: '', pass: '', ram: '', cpus: '', disk: '', plan: null};
  modal('Tuning the database server for its machine', function (body) {
    body.appendChild(el('p', 'note', 'Reading what the machine has and what the server is set to, and timing a few small writes…'));
  }, [{words: 'Close', close: true}], 'tune');
  MODAL_CLOSE = tuneForget;
  tuneLook();
}
function tuneLook(button) {
  var ask = tuneAsked();
  var ticket = modalTicket();
  if (button) busy(button, true);
  api('db', {action: 'tune_plan', machine: ask.machine}).then(function (d) {
    if (!modalStill(ticket)) return;
    TUNE.plan = d;
    tuneDraw(d);
  }).catch(function (e) {
    if (!modalStill(ticket)) return;
    if (button) busy(button, false);
    oops(e);
  });
}
function tuneValue(v) { return v === null || v === undefined || v === '' ? '–' : String(v); }
function tuneDraw(d, done) {
  var changes = (d.items || []).filter(function (it) { return it.change; });
  var buttons = [
    {words: 'Read again', icon: 'refresh', left: true, go: function (b) { tuneLook(b); }},
    {words: 'Close', close: true}
  ];
  if (changes.length) {
    buttons.splice(1, 0, {words: 'Put it in', cls: 'primary', icon: 'gear', admin: true,
                          go: function (b) { tuneApply(b); }});
  }
  /* What waits for the server's next start, started from here - as isemon
     does - where install.sh let this program restart it. */
  var waiting = (d.items || []).some(function (it) { return it.waiting || it.pending; });
  if (waiting && d.restart && d.restart.may) {
    buttons.splice(1, 0, {words: 'Restart the server…', cls: changes.length ? '' : 'primary',
                          icon: 'power', admin: true, go: function () { tuneRestartAsk(); }});
  }
  modal('Tuning ' + d.words + ' for its machine', function (body) {
    var f = d.facts || {};
    body.appendChild(peekFacts([
      ['Server', String(d.version || d.words).replace(/\s*\(.*\)\s*$/, '')],
      ['Where', d.where],
      ['Database', bytes(d.size)],
      f.ram ? ['Memory', bytes(f.ram)] : null,
      f.avail ? ['Free now', bytes(f.avail)] : null,
      f.cpus ? ['Processors', num(f.cpus)] : null,
      ['Disk', f.disk === 'hdd' ? 'a disk that spins' : 'SSD'],
      f.commit_ms !== null && f.commit_ms !== undefined
        ? ['A write made safe in', Number(f.commit_ms).toFixed(1).replace('.', numDecimal()) + ' ms'] : null,
      d.connections ? ['Connections allowed', num(d.connections)] : null
    ]));
    var from = {'this machine': 'Read from this machine, which the server runs on.',
                'typed': 'As typed below.'}[f.source || ''];
    if (from) body.appendChild(el('p', 'note', from));
    if (f.why && f.why !== 'chosen') body.appendChild(el('p', 'note', 'The disk: ' + f.why));
    if (d.need_facts) {
      body.appendChild(el('p', 'note bad', 'The server is on another machine and what it has could not be read from here. Type its memory and processors below and press Read again.'));
    }
    var row = el('div', 'tune-machine');
    var hw = {};
    [['ram', 'Memory, GB', f.ram ? String(Math.round(f.ram / 1073741824 * 10) / 10) : ''],
     ['cpus', 'Processors', f.cpus ? String(f.cpus) : '']].forEach(function (one) {
      var box = el('div', 'set-item');
      box.appendChild(el('label', '', one[1]));
      var input = el('input');
      input.type = 'text';
      input.inputMode = 'decimal';
      input.value = TUNE[one[0]] || one[2];
      box.appendChild(input);
      row.appendChild(box);
      hw[one[0]] = input;
    });
    var dbox = el('div', 'set-item');
    dbox.appendChild(el('label', '', 'Disk'));
    var sel = selectBox([['ssd', 'SSD'], ['hdd', 'a disk that spins']], TUNE.disk || f.disk || 'ssd');
    dbox.appendChild(sel);
    row.appendChild(dbox);
    hw.disk = sel;
    body.appendChild(row);
    TUNE.hw = hw;
    body.appendChild(el('p', 'btnhelp', 'Change any of these and press Read again: the settings are worked out afresh for what is typed.'));
    if (done) {
      if ((done.done || []).length || (done.later || []).length) {
        body.appendChild(el('p', 'note good', 'Put in: ' + ((done.done || []).join(', ') || 'nothing at once')
          + ((done.later || []).length ? ' · at the next start: ' + done.later.join(', ') : '')));
      }
      if ((done.failed || []).length) body.appendChild(el('p', 'note bad', 'Refused: ' + done.failed.join('; ')));
    }
    if ((d.items || []).length) {
      body.appendChild(el('h4', '', changes.length
        ? 'What would change' : 'Nothing to change: every setting is right for this machine'));
      var wrap = listTable(['Setting', 'Now', 'For this machine', 'Takes', 'Why'], d.items, function (it) {
        var tr = el('tr', it.change ? 'tune-change' : '');
        tr.appendChild(noI18n(el('td', 'mono', it.name)));
        tr.appendChild(noI18n(el('td', 'mono', tuneValue(it.now))));
        var want = el('td', 'mono ' + (it.change ? 'good' : 'muted'));
        want.appendChild(noI18n(el('span', '', tuneValue(it.want))));
        if (it.waiting) { want.appendChild(document.createTextNode(' ')); want.appendChild(el('span', 'tag warn', 'waiting for a start')); }
        tr.appendChild(want);
        tr.appendChild(el('td', it.restart ? 'warn' : 'muted', it.takes));
        tr.appendChild(el('td', 'muted small', it.why));
        return tr;
      }, 'plain tune-table');
      body.appendChild(wrap);
    }
    if (d.engine === 'postgres' && waiting && d.restart && !d.restart.may && d.restart.why) {
      body.appendChild(el('p', 'note bad', 'This program cannot restart it from here: ' + d.restart.why + '.'));
    }
    if (d.engine === 'postgres') {
      body.appendChild(el('p', 'btnhelp', d.restart && d.restart.may
        ? 'What takes effect only at the next start waits for it: Restart the server, under this popup, does that when you say so.'
        : 'What takes effect only at the next start waits for it: on the server, as root, systemctl restart ' + ((d.restart && d.restart.unit) || 'postgresql') + '.'));
    }
    if (d.engine === 'mariadb' && d.cnf) {
      body.appendChild(el('h4', '', 'To keep them over a restart'));
      body.appendChild(el('p', 'note', 'SET GLOBAL lasts until MariaDB is next started, and otp may not write in /etc. Put this in /etc/my.cnf.d/zz-otp-tuning.cnf on the server; the ones marked at the next start take effect only from there.'));
      body.appendChild(noI18n(el('pre', 'mono small', d.cnf)));
    }
    body.appendChild(el('h4', '', 'Who changes them'));
    TUNE.boxes = tuneAdminBoxes(body, d.engine);
  }, buttons, 'tune');
  MODAL_CLOSE = tuneForget;
}
function tuneApply(button) {
  var ask = tuneAsked();
  busy(button, true);
  api('db', {action: 'tune_apply', machine: ask.machine, admin_user: ask.admin_user,
             admin_password: ask.admin_password}).then(function (d) {
    TUNE.plan = d;
    tuneDraw(d, d);
    loadDb();
  }).catch(function (e) { busy(button, false); oops(e); });
}

/* ---- erasing what was collected ----------------------------------------- */
function drawErasable(d) {
  var host = $('erase-list');
  var was = {};
  Array.prototype.forEach.call(host.querySelectorAll('input[type=checkbox]'),
    function (b) { was[b.dataset.group] = b.checked; });
  clear(host);
  $('erase-size').textContent = bytes(d.bytes || 0) + ' in all';
  (d.groups || []).forEach(function (g) {
    var row = el('label', 'erase-one' + (g.rows ? '' : ' empty'));
    var box = document.createElement('input');
    box.type = 'checkbox';
    box.dataset.group = g.key;
    box.checked = !!was[g.key];
    box.disabled = !ADMIN || !g.rows;
    box.onchange = markErase;
    row.appendChild(box);
    var words = el('div', 'erase-words');
    var top = el('div', 'erase-top');
    top.appendChild(el('span', 'erase-name', g.name));
    top.appendChild(el('span', 'tag ' + (g.rows ? 'info' : 'dim'), g.rows ? num(g.rows) + ' row(s)' : 'already empty'));
    words.appendChild(top);
    words.appendChild(el('div', 'erase-says', g.says));
    row.appendChild(words);
    host.appendChild(row);
  });
  markErase();
}
function erasePicked() {
  return Array.prototype.filter.call(document.querySelectorAll('#erase-list input[type=checkbox]'),
    function (b) { return b.checked; }).map(function (b) { return b.dataset.group; });
}
function markErase() {
  var picked = erasePicked();
  var go = $('erase-go');
  go.disabled = !ADMIN || !picked.length || !!DB_WATCHING;
  setButtonIcon(go, 'forget', picked.length ? 'Erase ' + picked.length + ' of these…' : 'Erase what is ticked…');
}

if ($('db-engine-test')) {
  $('db-engine-test').onclick = function () {
    busy($('db-engine-test'), true);
    api('db', {action: 'try', settings: dbAsked()}).then(function (d) {
      modal('Trying ' + d.words, function (body) {
        body.appendChild(el('p', 'note', 'Nothing was saved and nothing was written: this opened it, asked what it is, counted what is in it and closed it again.'));
        body.appendChild(engineFacts(d));
        if (!d.reached) body.appendChild(el('p', 'note bad', String(d.trouble || '')));
        else if (d.in_use) body.appendChild(el('p', 'note', 'This is the database in use.'));
        else if (!d.writable) body.appendChild(el('p', 'note bad', 'It answers, but this account may not make anything in it. Set it up, or give the account rights on that database.'));
        else if (!d.rows) body.appendChild(el('p', 'note good', 'It is reachable and empty of ours, which is exactly what something to carry everything into should look like.'));
      }, [{words: 'Close', close: true}], true);
    }).catch(oops).then(function () { busy($('db-engine-test'), false); });
  };

  $('db-engine-setup').onclick = function () {
    var want = dbAsked();
    var who, word;
    modal('Setting up ' + engineWord(want.db_engine), function (body) {
      body.appendChild(el('p', 'note', 'This makes the database and the account on that server, and gives the account rights on that one database and no other. The first time, it needs an administrator on the server to do it — root on MariaDB, postgres on PostgreSQL, or anyone who may create a database.'));
      body.appendChild(el('p', 'note', 'That administrator is used for this one connection and is stored nowhere: not in the settings, not in the database, not in any log.'));
      body.appendChild(el('p', 'note', 'The account this program will use is made with a password of its own, generated here — you do not have to invent one. It is written into the config file, and shown once when this is done so you can keep a copy.'));
      body.appendChild(el('p', 'note', 'Press this again later and it does the other half of the job: if the account already gets in, nothing is made and no administrator is wanted — it opens the database and puts its tables right. Leave the two boxes empty for that.'));
      var g = el('div', 'formgrid');
      who = textBox('', want.db_engine === 'postgres' ? 'postgres' : 'root', '');
      who.autocomplete = 'off';
      word = maskBox('', '', '');
      g.appendChild(formField('An administrator on that server', who, 'Only needed the first time, or if the account cannot get in.'));
      g.appendChild(formField('Its password', word));
      body.appendChild(g);
    }, [{words: 'Close', close: true}, {words: 'Set it up', cls: 'primary', icon: 'key', go: function (b) {
      var ticket = modalTicket();
      busy(b, true);
      api('db', {action: 'setup', settings: want, admin_user: who.value.trim(), admin_password: word.value}).then(function (d) {
        if (!modalStill(ticket)) modal('The database, set up', function () {}, [{words: 'Close', close: true}]);
        var body = $('modal-body');
        clear(body);
        (d.made || []).forEach(function (line) { body.appendChild(el('p', 'note good', line)); });
        body.appendChild(engineFacts(d.try || {}));
        if (d.password) {
          body.appendChild(el('h4', '', 'The password made for ' + (want.db_user || 'it')));
          var pw = el('input');
          pw.type = 'text'; pw.readOnly = true; pw.className = 'mono'; pw.value = d.password;
          pw.onclick = function () { pw.select(); };
          noI18n(pw);
          body.appendChild(pw);
          var copy = cmdButton('Copy it', 'copy', 'small');
          copy.style.marginTop = '8px';
          copy.onclick = function () {
            pw.select();
            var ok = false;
            try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
            toast(ok ? 'copied' : 'press Ctrl+C — it is selected', ok ? 'good' : 'warn');
          };
          body.appendChild(copy);
          body.appendChild(el('p', 'note', 'It is saved in ' + (d.kept_in || 'the config file') + ' and nowhere else, so nothing has to be typed in above. This is the only time it is shown — keep a copy if you want one, though nothing here needs it again.'));
        }
        body.appendChild(el('p', 'note', 'The address is saved. Nothing has moved yet: carry everything across when you are ready.'));
        clear($('modal-foot'));
        var close = cmdButton('Close', 'close', '');
        close.onclick = closeModal;
        $('modal-foot').appendChild(close);
        loadSettings();
      }).catch(function (e) { busy(b, false); oops(e); });
    }}], 'medium');
  };

  $('db-engine-move').onclick = function () {
    var want = dbAsked();
    var word = engineWord(want.db_engine);
    modal('Carrying everything into ' + word, function (body) {
      body.appendChild(el('p', 'note', 'Every token, every request, every setting and every account is copied into ' + word + '. On a large database this takes minutes; you can close this and it carries on.'));
      body.appendChild(el('p', 'note', 'What is here is not touched, and a copy of it is made first in any case. Nothing starts using the other database until you say so afterwards.'));
    }, [{words: 'Leave it', close: true}, {words: 'Carry it across', cls: 'primary', icon: 'save', close: true, go: function () {
      api('db', {action: 'move', settings: want}).then(function () { dbWatch(); }).catch(oops);
    }}], true);
  };

  $('db-engine-empty').onclick = function () {
    var want = dbAsked();
    var word = engineWord(want.db_engine);
    modal('Emptying ' + word, function (body) {
      body.appendChild(el('p', 'note bad', 'This throws away everything of otp in the OTHER database — the ' + word + ' above, not the one in use. It is for when a first attempt at moving left something in it and the move will not go on.'));
      body.appendChild(el('p', 'note', 'Nothing in the database this installation is running on is touched, and this is refused outright if the two are the same.'));
    }, [{words: 'Leave it', close: true}, {words: 'Empty it', cls: 'danger', icon: 'forget', close: true, go: function () {
      api('db', {action: 'empty', settings: want}).then(function (d) { toast(d.message, 'good'); loadDb(); }).catch(oops);
    }}], true);
  };

  $('db-engine-use').onclick = function () {
    var want = dbAsked();
    var word = engineWord(want.db_engine);
    modal('Start using ' + word, function (body) {
      body.appendChild(el('p', 'note', 'This writes the address into ' + ((DBSTATE && DBSTATE.config_file) || 'the config file') + ' and restarts the daemon, which takes a few seconds. Nothing in either database is touched.'));
      body.appendChild(el('p', 'note', want.db_engine === 'sqlite'
        ? 'Everything will be read out of the file on this machine from then on, and the server may be uninstalled once you are happy.'
        : 'Everything will be read out of ' + word + ' from then on, and the file on this machine may be deleted once you are happy. Carry everything across first if you have not — this does not move anything.'));
    }, [{words: 'Not yet', close: true}, {words: 'Start using it', cls: 'primary', icon: 'power', close: true, go: function () {
      api('db', {action: 'use', settings: want}).then(function (d) {
        toast(d.message, 'good');
        setTimeout(function () { location.reload(); }, 9000);
      }).catch(oops);
    }}], true);
  };

  $('db-backup').onclick = function () {
    busy($('db-backup'), true);
    api('db', {action: 'backup'}).then(function (x) { toast(x.message, 'good'); loadDb(); })
      .catch(oops).then(function () { busy($('db-backup'), false); });
  };
  $('db-download').onclick = function () {
    toast('the copy is being made; the download starts when it is ready', 'good');
    window.location.href = '?api=db-download';
  };
  $('db-dump-make').onclick = function () {
    busy($('db-dump-make'), true);
    toast('dumping — this takes as long as the database is big');
    api('db', {action: 'dump'}).then(function (d) {
      toast('a dump was made: ' + d.name + ' (' + bytes(d.bytes) + ')', 'good');
      loadDb();
    }).catch(oops).then(function () { busy($('db-dump-make'), false); });
  };
  $('db-dump-get').onclick = function () {
    toast('the dump is being made; the download starts when it is ready', 'good');
    window.location.href = '?api=db-download&kind=dump';
  };
  $('db-tidy').onclick = function () {
    busy($('db-tidy'), true);
    api('db', {action: 'tidy'}).then(function (x) { toast(x.message, 'good'); loadDb(); })
      .catch(oops).then(function () { busy($('db-tidy'), false); });
  };
  $('db-check').onclick = function () {
    busy($('db-check'), true);
    api('db', {action: 'check'}).then(function (d) {
      modal(d.ok ? 'Nothing in it is broken' : 'Something in it is broken', function (body) {
        var ul = el('ul', 'note');
        (d.said || []).forEach(function (one) { ul.appendChild(noI18n(el('li', 'mono small', one))); });
        body.appendChild(ul);
      }, [{words: 'Close', close: true}], true);
    }).catch(oops).then(function () { busy($('db-check'), false); });
  };
  $('db-optimize').onclick = function () {
    confirmThen('Give the disk back', 'Each table is rebuilt and held shut while it is — the RADIUS server '
      + 'waits for its own table meanwhile. It needs room for a second copy of the biggest table. Worth '
      + 'doing after throwing a lot away, and not otherwise.', 'Give it back',
      function () { api('db', {action: 'give_back'}).then(function () { dbWatch(); }).catch(oops); }, false);
  };
  $('db-prune').onclick = function () {
    var days, everything;
    modal('Forget records older than…', function (body) {
      body.appendChild(el('p', 'note', 'The RADIUS requests and the checks of a code older than this are '
        + 'deleted now, whatever the keep-for numbers say. The tokens, the accounts, the settings and the events are not touched.'));
      days = el('input'); days.type = 'number'; days.min = 1; days.value = 90;
      body.appendChild(formField('Older than (days)', days));
      everything = switchBox(false);
      everything._input.addEventListener('change', function () { days.disabled = !!everything._get(); });
      body.appendChild(formField('Every line, whatever its age — the whole log emptied', everything));
    }, [{words: 'Close', close: true}, {words: 'Forget them', cls: 'danger', icon: 'forget', go: function (b) {
      busy(b, true);
      api('db', {action: 'prune', days: Number(days.value), everything: !!everything._get()}).then(function (d) {
        toast(d.message, 'good'); closeModal(); loadDb();
      }).catch(oops).then(function () { busy(b, false); });
    }}], 'medium');
  };
  $('db-tune').onclick = openTune;
  $('db-tune-restart').onclick = function () { tuneRestartAsk(); };
}
function tuneRestartAsk() {
  {
    var unit = ((DBSTATE && DBSTATE.tune && DBSTATE.tune.restart) || {}).unit || 'postgresql';
    modal('Restart ' + unit, function (body) {
      body.appendChild(el('p', 'note', 'PostgreSQL is stopped and started again so that the settings waiting for its next start take effect. It takes a few seconds; the RADIUS server waits for it meanwhile, and the requests in that moment are answered as soon as it is back.'));
      body.appendChild(el('p', 'note', 'Not done when it might not come back: a shared_buffers larger than the memory free now, or huge pages.'));
    }, [{words: 'Not now', close: true}, {words: 'Restart it', cls: 'primary', icon: 'power', go: function (b) {
      busy(b, true);
      api('db', {action: 'tune_restart'}).then(function (d) {
        toast(d.message, 'good'); closeModal(); loadDb();
      }).catch(function (e) { busy(b, false); oops(e); });
    }}], true);
  }
}
if ($('db-tune-undo')) {
  $('db-tune-undo').onclick = function () {
    var user, pass;
    modal('Put back as it was', function (body) {
      body.appendChild(el('p', 'note', 'Every setting this page changed goes back to what it was before. Empty: otp’s own account, where it has that right.'));
      var g = el('div', 'formgrid');
      user = textBox('', DBSTATE && DBSTATE.engine === 'postgres' ? 'postgres' : 'root', '');
      pass = maskBox('', '', '');
      g.appendChild(formField('An administrator on that server', user));
      g.appendChild(formField('Its password', pass, 'Used for this one request; kept nowhere.'));
      body.appendChild(g);
    }, [{words: 'Close', close: true}, {words: 'Put it back', cls: 'primary', icon: 'undo', go: function (b) {
      busy(b, true);
      api('db', {action: 'tune_undo', admin_user: user.value.trim(), admin_password: pass.value}).then(function (d) {
        toast('put back: ' + (d.done || []).join(', '), 'good'); closeModal(); loadDb();
      }).catch(oops).then(function () { busy(b, false); });
    }}], 'medium');
  };
  $('erase-go').onclick = function () {
    var picked = erasePicked();
    if (!picked.length) return;
    var names = Array.prototype.filter.call(document.querySelectorAll('#erase-list input[type=checkbox]'),
      function (b) { return b.checked; }).map(function (b) {
        return b.closest('.erase-one').querySelector('.erase-name').textContent;
      });
    modal(picked.length === 1 ? 'Erase this?' : 'Erase these ' + picked.length + '?', function (body) {
      body.appendChild(el('p', 'note', 'This erases, for good:'));
      var ul = el('ul', 'ask-list');
      names.forEach(function (n) { ul.appendChild(el('li', '', n)); });
      body.appendChild(ul);
      body.appendChild(el('p', 'note', 'The tokens, the accounts and every setting are not touched.'));
      body.appendChild(el('p', 'muted', 'A copy of the database is made first, so this can be undone by restoring it.'));
    }, [{words: 'No, leave it', close: true}, {words: 'Erase it', cls: 'danger', icon: 'forget', close: true, go: function () {
      api('db', {action: 'erase', groups: picked, tidy: $('erase-tidy').checked}).then(function () {
        dbWatch();
      }).catch(oops);
    }}], true);
  };
  dropBox({drop: 'db-drop', file: 'db-file', says: 'db-drop-says', what: 'db-upload-what', go: 'db-restore'},
          'Drop a database file here, or press to choose one');
  dropBox({drop: 'dump-drop', file: 'dump-file', says: 'dump-drop-says', what: 'dump-upload-what', go: 'dump-restore'},
          'Drop a dump here, or press to choose one');
}

/* ---- export and import ---------------------------------------------------- */
function saveFile(name, text) {
  var a = el('a');
  a.href = URL.createObjectURL(new Blob([text], {type: 'application/json'}));
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
$('ex-plain').onclick = function () {
  api('export').then(function (d) { saveFile('otp-config-' + Date.now() + '.json', JSON.stringify(d.config, null, 2)); }).catch(oops);
};
$('ex-whole').onclick = function () {
  confirmThen('Export with the secrets', 'The shared secrets of the clients and the passwords of the directories go into the file, readable. Keep it somewhere safe.',
    'Export them', function () {
      api('export&secrets=1').then(function (d) { saveFile('otp-config-complete-KEEP-SAFE-' + Date.now() + '.json', JSON.stringify(d.config, null, 2)); }).catch(oops);
    });
};
$('ex-load').onclick = function () { $('ex-file').click(); };
$('ex-file').onchange = function () {
  var f = this.files && this.files[0];
  this.value = '';
  if (!f) return;
  f.text().then(function (t) {
    var conf = JSON.parse(t);
    confirmThen('Import ' + f.name, 'Clients, realms and directories of the same name are replaced, and the settings in it are saved.',
      'Import it', function () {
        api('import', {config: conf}).then(function (d) { toast(d.message, 'good'); loadSettings(); }).catch(oops);
      }, false);
  }).catch(oops);
};

/* ---- about ---------------------------------------------------------------- */
function drawAbout() {
  var s = STATUS || {};
  var host = $('about-state');
  clear(host);
  host.appendChild(el('h2', '', 'otp ' + (s.version || '')));
  host.appendChild(peekFacts([['Running for', span(s.uptime || 0)], ['RADIUS', ((s.radius || {}).listening || []).join(', ') || 'not listening'],
                              ['Clients', num(s.clients)], ['Realms', num(s.realms)], ['Directories', num(s.directories)],
                              ['Database', ({sqlite: 'SQLite', mariadb: 'MariaDB', postgres: 'PostgreSQL'})[(s.database || {}).engine] || (s.database || {}).engine]]));
  var c = (s.radius || {}).counts || {};
  host.appendChild(kvTable(Object.keys(c).sort().map(function (k) { return [k, num(c[k])]; })));
  host.appendChild(el('p', 'muted small', 'One Python file (/usr/local/lib/otp/otp.py), the standard library, and these PHP pages that ask it. On the server: otp --help.'));
}

/* ---- a directory's groups, searched and picked (isemon's list) ----------- */
/** opts: {dir: () => directory name, buttons: [{words, icon, on(g), toggle(g)}]} -
    a box to type part of a name into, Find the groups, and the list with a
    button per role beside every group, lit where the group has it. */
function groupBrowser(opts) {
  var box = el('div', 'groupbrowser');
  var bar = el('div', 'btnrow');
  bar.style.alignItems = 'center';
  var like = el('input');
  like.type = 'search';
  like.placeholder = 'part of a group’s name (empty: all)';
  like.style.maxWidth = '420px';
  like.style.minWidth = '320px';
  var go = cmdButton('Find the groups', 'search', 'small');
  bar.appendChild(like);
  bar.appendChild(go);
  box.appendChild(bar);
  var list = el('div');
  list.style.marginTop = '10px';
  box.appendChild(list);
  var st = {groups: [], q: '', page: 0, per: 15};
  function paint() {
    Array.prototype.forEach.call(list.querySelectorAll('tr.dgroup'), function (tr) {
      var any = false;
      opts.buttons.forEach(function (b, i) {
        var on = !!b.on(tr._g);
        any = any || on;
        var btn = tr.querySelectorAll('.rowtools .btn')[i];
        if (btn) btn.classList.toggle('on', on);
      });
      tr.classList.toggle('is-read', any);
    });
  }
  function draw() {
    clear(list);
    if (!st.groups.length) { list.appendChild(el('p', 'note', 'The directory has no groups under that base matching that.')); return; }
    var low = st.q.toLowerCase();
    var rows = !low ? st.groups : st.groups.filter(function (g) {
      return (g.cn + ' ' + g.dn + ' ' + (g.description || '')).toLowerCase().indexOf(low) >= 0;
    });
    var fb = el('div', 'btnrow');
    fb.style.alignItems = 'center';
    var f = el('input');
    f.type = 'search';
    f.placeholder = 'narrow this list…';
    f.value = st.q;
    f.style.maxWidth = '420px';
    f.style.minWidth = '320px';
    f.oninput = function () {
      st.q = f.value; st.page = 0;
      var at = f.selectionStart;
      draw();
      var again = list.querySelector('input[type=search]');
      if (again) { again.focus(); try { again.setSelectionRange(at, at); } catch (e) { } }
    };
    fb.appendChild(f);
    fb.appendChild(el('span', 'muted small', num(rows.length) + ' of ' + num(st.groups.length)));
    list.appendChild(fb);
    var pages = Math.max(1, Math.ceil(rows.length / st.per));
    if (st.page >= pages) st.page = pages - 1;
    list.appendChild(listTable(['Group', 'What it is for', ''], rows.slice(st.page * st.per, st.page * st.per + st.per), function (g) {
      var tr = el('tr', 'dgroup');
      tr._g = g;
      var n = el('td');
      n.appendChild(noI18n(el('div', '', g.cn)));
      n.appendChild(noI18n(el('div', 'mono small muted', g.dn)));
      tr.appendChild(n);
      tr.appendChild(noI18n(el('td', 'muted small', g.description || '')));
      var t = el('td', 'rowtools');
      opts.buttons.forEach(function (b) {
        var btn = cmdButton(b.words, b.icon, 'small');
        btn.onclick = function (e) { e.stopPropagation(); b.toggle(g); paint(); };
        t.appendChild(btn);
      });
      tr.appendChild(t);
      return tr;
    }, 'rows'));
    if (pages > 1) {
      var nav = el('div', 'btnrow');
      nav.style.marginTop = '8px';
      var prev = cmdButton('Back', 'prev', 'small');
      prev.disabled = st.page === 0;
      prev.onclick = function () { st.page--; draw(); };
      var next = cmdButton('Next', 'next', 'small');
      next.disabled = st.page >= pages - 1;
      next.onclick = function () { st.page++; draw(); };
      nav.appendChild(prev);
      nav.appendChild(el('span', 'muted small', 'page ' + (st.page + 1) + ' of ' + pages));
      nav.appendChild(next);
      list.appendChild(nav);
    }
    paint();
    explainWhatWasDrawn(list);
  }
  function find() {
    var d = opts.dir();
    if (!d) { toast('choose the directory first', 'bad'); return; }
    busy(go, true);
    api('directories', {action: 'groups', name: d, like: like.value.trim()}).then(function (r) {
      st.groups = r.groups || []; st.q = ''; st.page = 0;
      draw();
      toast(num(st.groups.length) + ' group(s) found', 'good');
    }).catch(function (e) {
      /* The groups of the directory asked before must not stay to be added
         to a realm of another one (1.0.36). */
      st.groups = []; st.q = ''; st.page = 0; draw(); oops(e);
    }).then(function () { busy(go, false); });
  }
  go.onclick = find;
  like.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); find(); } });
  box._paint = paint;
  return box;
}

/* ---- the certificate authority of a directory (as isemon) --------------- */
var DIRS = [];
function caDir() {
  var pick = $('ca-dir');
  var id = pick ? String(pick._get ? pick._get() : pick.value) : '';
  return DIRS.filter(function (x) { return String(x.id) === id; })[0] || DIRS[0];
}
function drawCaPick() {
  var host = $('ca-pick');
  if (!host) return;
  var was = $('ca-dir') ? String($('ca-dir')._get ? $('ca-dir')._get() : $('ca-dir').value) : '';
  clear(host);
  $('ca-card').hidden = !DIRS.length;
  if (!DIRS.length) return;
  var pick = selectBox(DIRS.map(function (x) { return [String(x.id), x.name]; }),
                       was && DIRS.some(function (x) { return String(x.id) === was; }) ? was : String(DIRS[0].id));
  pick.id = 'ca-dir';
  pick.addEventListener('change', drawCaState);
  if (DIRS.length > 1) host.appendChild(formField('For the directory', pick));
  else { pick.hidden = true; host.appendChild(pick); }
  drawCaState();
}
function drawCaState() {
  var d = caDir();
  var host = $('ca-state');
  if (!host || !d) return;
  clear(host);
  var list = d.ca_list || [];
  $('ca-when').textContent = list.length ? num(list.length) + ' certificate(s) kept' : 'none imported';
  $('ca-drop').hidden = !list.length;
  if (!list.length) {
    host.appendChild(el('p', 'note', 'Nothing is imported for ' + d.name + ', so the domain '
      + 'controllers’ certificates have to be signed by an authority this machine already '
      + 'trusts' + (d.tls === 'none' ? ' - and plain LDAP checks no certificate at all.' : '.')));
    return;
  }
  host.appendChild(el('p', 'note', 'Every certificate kept for ' + d.name + ' is trusted for its domain controllers - '
    + 'one chain for each domain or authority they come from. Each can be taken out by itself.'));
  host.appendChild(certTable(list, function (c) {
    confirmThen('Take this certificate out', '<b>' + htmlText(c.subject || 'this certificate') + '</b> is no longer trusted for '
      + htmlText(d.name) + '. The others stay.', 'Take it out', function () {
        api('directories', {action: 'ca', id: d.id, mode: 'drop', fingerprint: c.fingerprint}).then(function (r) {
          toast(r.message, 'good'); loadDirs();
        }).catch(oops);
      });
  }));
}
/** Kept certificates as a table: who, signed by whom, from when to when, the
    whole fingerprint, and a button to take each out (1.0.20: shared by the
    directories and the mail server). */
function certTable(list, drop) {
  return listTable(['It is', 'Signed by', 'Good from', 'Good until', 'Fingerprint (SHA-256)', ''], list, function (c) {
    var tr = el('tr');
    tr.appendChild(noI18n(el('td', '', c.subject || '–')));
    var by = el('td');
    if (c.self_signed) by.appendChild(el('span', 'tag info', 'itself - a root'));
    else by.appendChild(noI18n(el('span', '', c.issuer || '–')));
    tr.appendChild(by);
    var when = function (t) { var ms = Date.parse(t || ''); return isNaN(ms) ? (t || '–') : dayWords(new Date(ms)); };
    tr.appendChild(el('td', 'muted small', when(c.from)));
    var left = c.until ? (Date.parse(c.until) - Date.now()) / 86400000 : null;
    var tone = left === null || isNaN(left) ? '' : (left < 0 ? 'bad' : (left < 60 ? 'warn' : 'good'));
    tr.appendChild(el('td', 'small ' + tone, when(c.until)));
    var fp = noI18n(el('td', 'mono small muted fp-full'));
    var hex = (c.fingerprint || '').replace(/[^0-9a-fA-F]/g, '').toLowerCase();
    var half = Math.ceil(hex.length / 4) * 2;
    [hex.slice(0, half), hex.slice(half)].forEach(function (part) {
      if (part) fp.appendChild(el('div', '', part.replace(/(..)(?=.)/g, '$1:')));
    });
    fp.title = hex.replace(/(..)(?=.)/g, '$1:');
    tr.appendChild(fp);
    var tools = el('td', 'rowtools');
    if (ADMIN) {
      var x = iconButton('trash', 'Take this certificate out');
      x.onclick = function () { drop(c); };
      tools.appendChild(x);
    }
    tr.appendChild(tools);
    return tr;
  });
}
/** A certificate file read into a box: PEM as it is, a DER .cer written out as PEM. */
function readCertFile(file, box) {
  var reader = new FileReader();
  reader.onload = function () {
    var bytes = new Uint8Array(reader.result || new ArrayBuffer(0));
    var text = '';
    try { text = new TextDecoder('utf-8').decode(bytes); } catch (e) { text = ''; }
    if (text.indexOf('-----BEGIN CERTIFICATE-----') < 0 && bytes.length && bytes[0] === 0x30) {
      var bin = '';
      for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      text = '-----BEGIN CERTIFICATE-----\n' + btoa(bin).replace(/(.{64})/g, '$1\n').replace(/\n$/, '')
        + '\n-----END CERTIFICATE-----';
    }
    var ok = text.indexOf('-----BEGIN CERTIFICATE-----') >= 0;
    box.value = ok ? text.trim() : '';
    box.dispatchEvent(new Event('input'));
    toast(ok ? 'read ' + file.name + ' - Save the changes adds it' : file.name + ' is not a certificate', ok ? 'good' : 'bad');
  };
  reader.readAsArrayBuffer(file);
}
/** The box to paste one into is always there: what is added joins the ones
    kept rather than replacing them (1.0.11). */
if ($('ca-save')) {
  var caSend = function (pem, done) {
    var d = caDir();
    if (!d) return Promise.resolve();
    return api('directories', {action: 'ca', id: d.id, ca: pem, mode: pem ? 'add' : 'clear'}).then(function (r) {
      toast(r.message, 'good');
      if (done) done();
      loadDirs();
    }).catch(oops);
  };
  $('ca-save').onclick = function () {
    var pem = $('ca-pem').value.trim();
    if (!pem) { toast('paste the certificate first, or read it from a file', 'bad'); return; }
    busy($('ca-save'), true);
    /* The button comes back when the daemon has answered, not on a timer:
       a slow import could be pressed twice (1.0.15). */
    caSend(pem, function () { $('ca-pem').value = ''; }).then(function () { busy($('ca-save'), false); });
  };
  /* Pasted or read, it waits for the save bar (1.0.56). */
  $('ca-save').hidden = true;
  $('ca-pem').addEventListener('input', function () {
    var pem = $('ca-pem').value.trim();
    if (!pem) { delete PENDING.ca; markDirtyCount(); return; }
    pendingSet('ca', {save: function () {
      var got = false;
      return caSend($('ca-pem').value.trim(), function () { got = true; $('ca-pem').value = ''; }).then(function () { return got; });
    }, reset: function () { $('ca-pem').value = ''; }});
  });
  $('ca-file').onclick = function () { $('ca-input').click(); };
  $('ca-input').onchange = function () {
    var file = this.files && this.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var bytes = new Uint8Array(reader.result || new ArrayBuffer(0));
      var text = '';
      try { text = new TextDecoder('utf-8').decode(bytes); } catch (e) { text = ''; }
      if (text.indexOf('-----BEGIN CERTIFICATE-----') < 0 && bytes.length && bytes[0] === 0x30) {
        /* A .cer in DER, as Windows exports it by default: the same bytes
           written out as PEM here, so nobody has to run openssl for it. */
        var bin = '';
        for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
        text = '-----BEGIN CERTIFICATE-----\n' + btoa(bin).replace(/(.{64})/g, '$1\n').replace(/\n$/, '')
          + '\n-----END CERTIFICATE-----';
      }
      var ok = text.indexOf('-----BEGIN CERTIFICATE-----') >= 0;
      $('ca-pem').value = ok ? text.trim() : '';
      $('ca-pem').dispatchEvent(new Event('input'));
      toast(ok ? 'read ' + file.name + ' - Save the changes adds it' : file.name + ' is not a certificate', ok ? 'good' : 'bad');
    };
    reader.readAsArrayBuffer(file);
    this.value = '';
  };
  $('ca-drop').onclick = function () {
    var d = caDir();
    if (!d) return;
    confirmThen('Take every certificate of ' + d.name + ' away',
      'The domain controllers’ certificates will then have to be signed by an authority this '
      + 'machine already trusts, or the check has to be switched off.',
      'Take them all away', function () { caSend(''); });
  };
}

/* ---- tokens out as .totp files (1.0.20) --------------------------------- */
if ($('exp-go')) {
  qSuggest($('exp-q'), 'tokens');
  $('exp-go').onclick = function () {
    var q = $('exp-q').value.trim(), st = $('exp-state').value;
    confirmThen('Export the tokens as .totp files', 'A ZIP of ' + (q || st ? 'the tokens that match' : '<b>every</b> token')
      + ', each with its key and its unused recovery codes. Whoever has the file can sign in as any of them.',
      'Export them', function () {
        window.location.href = '?api=tokens-export&q=' + encodeURIComponent(q) + '&state=' + encodeURIComponent(st);
      }, false);
  };
}
function tokenExport(name) {
  window.location.href = '?api=tokens-export&name=' + encodeURIComponent(name);
}

/* ---- mail (1.0.20) ------------------------------------------------------- */
var MAIL = null;
function loadMail() {
  return api('mail').then(function (d) {
    MAIL = d;
    var list = d.ca_list || [];
    if (!$('mca-state')) return d;
    $('mca-when').textContent = list.length ? num(list.length) + ' certificate(s) kept' : 'none imported';
    $('mca-drop').hidden = !list.length;
    var host = $('mca-state');
    clear(host);
    if (list.length) {
      host.appendChild(certTable(list, function (c) {
        confirmThen('Take this certificate out', '<b>' + htmlText(c.subject || 'this certificate')
          + '</b> is no longer trusted for the mail server. The others stay.', 'Take it out', function () {
            api('mail', {action: 'ca', mode: 'drop', fingerprint: c.fingerprint}).then(function (r) {
              toast(r.message, 'good'); loadMail();
            }).catch(oops);
          });
      }));
    }
    $('mail-said').textContent = {off: 'switched off', smtp: 'through a mail server', direct: 'straight to the recipients'}[d.mode] || '';
    return d;
  }).catch(oops);
}
function mailSteps(host, d) {
  clear(host);
  host.appendChild(el('p', 'note ' + (d.sent ? 'good' : 'bad'), (d.sent ? 'Sent: ' : 'Not sent: ') + d.said
    + (d.took_ms !== undefined ? ' · ' + num(d.took_ms) + ' ms' : '')));
  if ((d.steps || []).length) host.appendChild(stepsList(d.steps));
}
if ($('mail-test')) {
  $('mail-test').onclick = function () {
    var b = $('mail-test');
    /* Only a change to the mail settings stops the test (1.0.36), not one
       left on another page. */
    if (Object.keys(DIRTY || {}).some(function (k) { return /^(mail_|smtp_)/.test(k); })) {
      toast('save the mail settings first', 'bad'); return;
    }
    busy(b, true);
    api('mail', {action: 'test', to: $('mail-to').value.trim(), lang: $('mail-test-lang').value, kind: $('mail-test-kind') ? $('mail-test-kind').value : 'short'}).then(function (d) {
      mailSteps($('mail-steps'), d);
    }).catch(oops).then(function () { busy(b, false); });
  };
  $('mca-save').onclick = function () {
    var pem = $('mca-pem').value.trim();
    if (!pem) { toast('paste the certificate first, or read it from a file', 'bad'); return; }
    busy($('mca-save'), true);
    api('mail', {action: 'ca', mode: 'add', ca: pem}).then(function (r) {
      toast(r.message, 'good'); $('mca-pem').value = ''; loadMail();
    }).catch(oops).then(function () { busy($('mca-save'), false); });
  };
  $('mca-save').hidden = true;
  $('mca-pem').addEventListener('input', function () {
    var pem = $('mca-pem').value.trim();
    if (!pem) { delete PENDING.mca; markDirtyCount(); return; }
    pendingSet('mca', {save: function () {
      return api('mail', {action: 'ca', mode: 'add', ca: $('mca-pem').value.trim()}).then(function (r) {
        toast(r.message, 'good'); $('mca-pem').value = ''; loadMail(); return true;
      });
    }, reset: function () { $('mca-pem').value = ''; }});
  });
  $('mca-file').onclick = function () { $('mca-input').click(); };
  $('mca-input').onchange = function () {
    var file = this.files && this.files[0];
    if (file) readCertFile(file, $('mca-pem'));
    this.value = '';
  };
  $('mca-drop').onclick = function () {
    confirmThen('Take every certificate of the mail server away',
      'The mail server’s certificate will then have to be signed by an authority this machine already trusts, or the check has to be switched off.',
      'Take them all away', function () {
        api('mail', {action: 'ca', mode: 'clear'}).then(function (r) { toast(r.message, 'good'); loadMail(); }).catch(oops);
      });
  };
}

/* ---- the administrators' groups, found rather than typed (as isemon) ---- */
var AG_ROLES = [['admin_group_full', 'Full admin', 'shield', 'is-admin'],
                ['admin_group_token', 'Token admin', 'key', 'is-token'],
                ['admin_group_readonly', 'Read only', 'eye', 'is-read']];
var AG = {groups: [], q: '', page: 0, per: 25, capped: false};

/** The directory chosen in the editor right now - saved or not. */
function agDirectory() {
  var input = $('set-admin_directory');
  return input ? String(input._get ? input._get() : input.value || '') : '';
}
/** What a role's groups are set to right now, in the editor, lower-cased. */
function agWanted(key) {
  var input = $('set-' + key);
  var said = input ? (input._get ? input._get() : input.value) : '';
  return String(said || '').split(/[;\n]/).map(function (x) {
    return x.trim().toLowerCase();
  }).filter(Boolean);
}
/** Put a group into a role, or take it out, in the settings editor. Saved
    with the rest of the page - nothing happens until then. */
function agToggle(key, dn, name) {
  var input = $('set-' + key);
  if (!input) { toast('the settings are not drawn yet'); return; }
  var have = String(input.value || '').split(/[;\n]/).map(function (x) { return x.trim(); })
    .filter(Boolean);
  var same = function (one) {
    var low = one.toLowerCase();
    return low === String(dn).toLowerCase() || (name && low === String(name).toLowerCase());
  };
  var was = have.some(same);
  if (was) have = have.filter(function (one) { return !same(one); }); else have.push(dn);
  input.value = have.join('; ');
  input.dispatchEvent(new Event('input', {bubbles: true}));
  input.dispatchEvent(new Event('change', {bubbles: true}));
  toast(was ? 'taken out — save to keep it' : 'put in — save to keep it');
}
function agPaint() {
  var want = {};
  AG_ROLES.forEach(function (r) { want[r[0]] = agWanted(r[0]); });
  Array.prototype.forEach.call(document.querySelectorAll('#ag-groups tr.dgroup'), function (row) {
    var dn = String(row.dataset.dn || '').toLowerCase();
    var name = String(row.dataset.name || '').toLowerCase();
    AG_ROLES.forEach(function (r, i) {
      var on = want[r[0]].indexOf(dn) >= 0 || want[r[0]].indexOf(name) >= 0;
      row.classList.toggle(r[3], on);
      var b = row.querySelectorAll('.rowtools .btn')[i];
      if (b) b.classList.toggle('on', on);
    });
  });
}
function agDraw() {
  var host = $('ag-groups');
  clear(host);
  var all = AG.groups;
  if (!all.length) {
    host.appendChild(el('p', 'note', 'The directory has no groups under that base matching '
      + 'that - or the base is not where they live.'));
    return;
  }
  var low = AG.q.toLowerCase();
  var rows = !low ? all : all.filter(function (g) {
    return (g.cn + ' ' + g.dn + ' ' + (g.description || '')).toLowerCase().indexOf(low) >= 0;
  });
  var lead = el('p', 'note');
  lead.innerHTML = '<b>' + num(all.length) + '</b> group(s). Press a role beside one to put it '
    + 'in that role; press it again to take it out. More than one group may hold a role, and '
    + 'somebody in several gets the highest.'
    + (AG.capped ? ' This is as many as are fetched at once — there may be more: type part of '
       + 'a name above and press <i>Find the groups</i> again.' : '');
  host.appendChild(lead);
  var bar = el('div', 'filterbar btnrow');
  var find = el('input');
  find.type = 'search';
  find.placeholder = 'narrow this list…';
  find.value = AG.q;
  find.style.maxWidth = '320px';
  var found = el('span', 'muted small', num(rows.length) + ' shown');
  find.oninput = function () {
    AG.q = find.value;
    AG.page = 0;
    var at = find.selectionStart;
    agDraw();
    var again = $('ag-groups').querySelector('input[type=search]');
    if (again) { again.focus(); try { again.setSelectionRange(at, at); } catch (e) { } }
  };
  bar.appendChild(find);
  bar.appendChild(found);
  host.appendChild(bar);
  var pages = Math.max(1, Math.ceil(rows.length / AG.per));
  if (AG.page >= pages) AG.page = pages - 1;
  var page = rows.slice(AG.page * AG.per, AG.page * AG.per + AG.per);
  host.appendChild(listTable(['Group', 'What it is for', ''], page, function (g) {
    var tr = el('tr', 'dgroup');
    tr.dataset.dn = g.dn;
    tr.dataset.name = g.cn;
    var n = el('td');
    n.appendChild(noI18n(el('div', '', g.cn)));
    n.appendChild(noI18n(el('div', 'mono small muted', g.dn)));
    tr.appendChild(n);
    tr.appendChild(noI18n(el('td', 'muted small', g.description || '')));
    var pick = el('td', 'rowtools');
    if (ADMIN) {
      AG_ROLES.forEach(function (r) {
        var b = cmdButton(r[1], r[2], 'small');
        b.onclick = function (e) { e.stopPropagation(); agToggle(r[0], g.dn, g.cn); agPaint(); };
        explain(b, 'Put <b>' + wordsIn(g.cn) + '</b> in this role, or take it out of it. It is a '
          + 'change like any other on this page — nothing happens until you save.');
        pick.appendChild(b);
      });
    }
    tr.appendChild(pick);
    return tr;
  }, 'rows'));
  if (pages > 1) {
    var nav = el('div', 'btnrow');
    nav.style.marginTop = '10px';
    var prev = cmdButton('Back', 'prev', 'small');
    prev.disabled = AG.page === 0;
    prev.onclick = function () { AG.page--; agDraw(); };
    var next = cmdButton('Next', 'next', 'small');
    next.disabled = AG.page >= pages - 1;
    next.onclick = function () { AG.page++; agDraw(); };
    nav.appendChild(prev);
    nav.appendChild(el('span', 'muted small', 'page ' + (AG.page + 1) + ' of ' + pages));
    nav.appendChild(next);
    host.appendChild(nav);
  }
  agPaint();
  explainWhatWasDrawn(host);
}
if ($('ag-find')) {
  var agFind = function () {
    var dir = agDirectory();
    if (!dir) {
      toast('choose the directory first - "Sign administrators in against the directory" above', 'bad');
      var item = document.querySelector('.set-item[data-key="admin_directory"]');
      if (item) item.scrollIntoView({block: 'center'});
      return;
    }
    busy($('ag-find'), true);
    api('directories', {action: 'groups', name: dir, like: $('ag-like').value.trim()}).then(function (d) {
      AG.groups = d.groups || [];
      AG.capped = !!d.capped;
      AG.q = '';
      AG.page = 0;
      agDraw();
      toast(num(AG.groups.length) + ' group(s) found', 'good');
    }).catch(oops).then(function () { busy($('ag-find'), false); });
  };
  $('ag-find').onclick = agFind;
  $('ag-like').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); agFind(); } });
  /* A role typed or changed by hand shows in the list at once. */
  document.addEventListener('input', function (e) {
    if (e.target && /^set-admin_group_/.test(e.target.id || '')) agPaint();
  });
  $('ag-try').onclick = function () {
    var name, pass;
    modal('Try a sign-in', function (body) {
      body.appendChild(el('p', 'note', 'Nothing is signed in and no session is made. This asks '
        + 'the directory the same question a real sign-in asks, and shows the whole answer - '
        + 'including which groups came back and what role they earn. It uses the settings as '
        + 'they are saved.'));
      var one = el('div', 'set-item');
      one.appendChild(el('label', '', 'The name they would type'));
      name = el('input');
      name.type = 'text';
      name.placeholder = 'novak, novak@example.cz or EXAMPLE\\novak';
      one.appendChild(name);
      body.appendChild(one);
      var two = el('div', 'set-item');
      two.appendChild(el('label', '', 'Their password'));
      pass = maskBox('', '', '');
      two.appendChild(pass);
      body.appendChild(two);
      setTimeout(function () { name.focus(); }, 60);
    }, [{words: 'Try it', cls: 'primary', icon: 'person', go: function (b) {
      busy(b, true);
      api('directories', {action: 'try', user: name.value, password: pass.value}).then(function (d) {
        var said = d.tried || {};
        /* Under the boxes, not in their place (1.0.36): a typo could not be
           put right without closing the window. */
        var body = $('modal-body');
        var res = body.querySelector('.try-res');
        if (!res) { res = el('div', 'try-res'); res.style.marginTop = '12px'; body.appendChild(res); }
        clear(res);
        body = res;
        if (said.ok) {
          body.appendChild(kvTable([
            ['They are', said.display || said.name],
            ['Role here', said.role ? ({fulladmin: 'full admin', tokenadmin: 'token admin',
                                         readonly: 'read only'}[said.role] || said.role)
                                    : 'none - they cannot sign in'],
            ['In the directory', said.dn || ''],
            ['Asked', said.directory]]));
          var g = el('p', 'note');
          g.appendChild(el('b', '', 'Groups the directory gave back:'));
          (said.groups || []).forEach(function (one) {
            g.appendChild(el('br'));
            g.appendChild(noI18n(el('span', 'mono small', one)));
          });
          body.appendChild(g);
        } else {
          body.appendChild(el('p', said.missing ? 'note' : 'note bad', said.said || 'it did not work'));
          if (said.missing) {
            body.appendChild(el('p', 'note', 'That is not a fault: a name the directory has '
              + 'never heard of is looked for in the local accounts instead.'));
          }
        }
      }).catch(oops).then(function () { busy(b, false); });
    }}, {words: 'Close', close: true}]);
  };
}

/* ---- every list's search box offers its fields and values (1.0.19) ---- */
if ($('rt-user')) personSuggest($('rt-user'));
var QS = {
  tokens: qSuggest($('tk-q'), 'tokens'),
  requests: qSuggest($('rq-q'), 'radius', function () { return 'hours=' + $('rq-hours').value; }),
  events: qSuggest($('ev-q'), 'events'),
  enrolment: qSuggest($('en-q'), 'enrolment', function () {
    var s = Number($('en-since').value); return s ? 'hours=' + Math.ceil(s / 3600) : '';
  })
};

/* ---- starting ------------------------------------------------------------ */
(function start() {
  var h = (location.hash || '#overview').slice(1).split('/');
  if (h[0] === 'codes') h = ['requests'];
  if (h[1]) PANE = h[1];
  if (STATUS) paintHeader(STATUS);
  showTab(h[0] || 'overview');
  setInterval(tick, 5000);
  explainWhatWasDrawn(document);
  /* A link to #settings/dir, or Back: the page follows the address. */
  window.addEventListener('hashchange', function () {
    var g = (location.hash || '#overview').slice(1).split('/');
    if (TABS.indexOf(g[0]) < 0) return;
    if (g[0] === 'settings' && g[1] && g[1] !== PANE && typeof showPane === 'function'
        && TAB === 'settings') { showPane(g[1]); return; }
    if (g[1]) PANE = g[1];
    if (g[0] !== TAB) showTab(g[0]);
  });
}());


/* ==========================================================================
   High availability (1.0.13)
   ========================================================================== */
var HA = null;
/* Each node's own settings (1.0.37): one row a setting, one column a node. */
function drawNodeSettings(nodes) {
  var card = $('ha-own-card');
  if (!card) return;
  var names = (nodes || []).map(function (n) { return n.name; });
  card.hidden = names.length < 2 && !(SETTINGS && SETTINGS.cluster);
  if (card.hidden) return;
  api('settings').then(function (d) {
    var host = $('ha-own');
    clear(host);
    var own = (d.settings || []).filter(function (s) { return s.node_key; });
    host.appendChild(listTable(['Setting', 'The cluster’s'].concat(names), own, function (s) {
      var tr = el('tr');
      tr.appendChild(el('td', '', s.name || s.key));
      tr.appendChild(noI18n(el('td', 'mono small muted', String(s.shared))));
      names.forEach(function (n) {
        var has = s.per_node && Object.prototype.hasOwnProperty.call(s.per_node, n);
        var td = el('td');
        var v = noI18n(el('span', 'mono small' + (has ? '' : ' muted'), has ? String(s.per_node[n]) : '–'));
        td.appendChild(v);
        if (ADMIN) {
          var b = iconButton('edit', 'Change it for ' + n);
          b.onclick = function () {
            var box;
            modal(s.name + ' · ' + n, function (body) {
              body.appendChild(el('p', 'note', s.says || ''));
              box = textBox(has ? String(s.per_node[n]) : '', String(s.shared), 'mono');
              body.appendChild(formField('For ' + n + ' only', box, 'Empty: the cluster’s value.'));
            }, [{words: 'Close', close: true}, {words: 'Save', cls: 'primary', icon: 'save', go: function () {
              var val = box.value.trim() === '' ? s.shared : box.value.trim();
              var want = {};
              want[s.key] = typeof s.default === 'number' ? Number(val)
                : (typeof s.default === 'boolean' ? (val === true || val === 'true' || val === '1' || val === 1) : val);
              api('settings', {settings: want, node: n}).then(function (r) {
                toast(r.message, 'good'); closeModal(); drawNodeSettings(nodes);
              }).catch(oops);
            }}], true);
          };
          td.appendChild(document.createTextNode(' '));
          td.appendChild(b);
        }
        tr.appendChild(td);
      });
      return tr;
    }, 'plain'));
  }).catch(oops);
}

function loadHa() {
  loadVip();
  api('ha').then(function (d) {
    drawNodeSettings(d.nodes);
    HA = d;
    var rep = !!(d.replication && d.replication.mode === 'replicated');
    if ($('ha-lede-shared')) { $('ha-lede-shared').hidden = rep; $('ha-lede-replicated').hidden = !rep; }
    var nodes = d.nodes || [];
    var alive = nodes.filter(function (n) { return n.alive; }).length;
    $('ha-said').textContent = num(alive) + ' of ' + num(nodes.length) + ' answering · this page from ' + d.node;
    var host = $('ha-nodes');
    clear(host);
    host.appendChild(listTable(['Node', 'Address', 'Version', 'RADIUS', 'Heard from', 'State', ''], nodes, function (n) {
      var tr = el('tr');
      var nm = el('td');
      nm.appendChild(noI18n(el('b', '', n.name)));
      if (n.me) { nm.appendChild(document.createTextNode(' ')); nm.appendChild(el('span', 'tag info', 'this page')); }
      tr.appendChild(nm);
      tr.appendChild(noI18n(el('td', 'mono small', n.address || '')));
      var v = el('td', n.version !== d.version ? 'warn' : '', n.version || '?');
      if (n.version !== d.version) explain(v, 'Not the version this node runs (' + d.version + '): both nodes should run the same one.');
      tr.appendChild(v);
      tr.appendChild(noI18n(el('td', 'mono small', (n.radius || []).join(', '))));
      tr.appendChild(el('td', 'muted', ago(n.at)));
      var st = el('td');
      st.appendChild(el('span', 'tag ' + (n.alive ? 'ok' : 'crit'), n.alive ? 'answering' : 'gone'));
      tr.appendChild(st);
      var tools = el('td', 'rowtools');
      if (ADMIN && !n.me) {
        var x = iconButton('trash', 'Take it off the list');
        x.onclick = function () {
          confirmThen('Take ' + n.name + ' off the list', 'For a node taken away for good. If it is still running it writes itself back within fifteen seconds.', 'Take it off', function () {
            api('ha', {action: 'forget', name: n.name}).then(function (r) { toast(r.message, 'good'); loadHa(); }).catch(oops);
          });
        };
        tools.appendChild(x);
      }
      tr.appendChild(tools);
      return tr;
    }));
    var ch = $('ha-checks');
    clear(ch);
    (d.checks || []).forEach(function (c) {
      var p = el('p', 'note ' + (c.ok ? 'good' : (c.warn ? 'warn' : 'bad')));
      p.appendChild(noI18n(el('b', '', c.ok ? '✓ ' : (c.warn ? '! ' : '✗ '))));
      p.appendChild(el('span', '', c.says));
      ch.appendChild(p);
    });
    $('ha-bundle').disabled = d.engine !== 'postgres';
    /* Made two already (1.0.43): the steps folded away, a click away. */
    var made = !!d.mode;
    $('ha-make-open').hidden = !made;
    if (!made || !HA_MAKE_OPEN) $('ha-make-body').hidden = made;
    drawHaRep(d);
    drawHaLb(d);
    explainWhatWasDrawn($('pane-ha'));
  }).catch(oops);
}

/* The load balancer guides (1.0.52): one per kind, folded, filled in with
   this installation's own names, addresses and ports - and with what is
   typed in at the top - the real values marked where they stand. */
var LB_UI = (function () {
  var st = {};
  try { st = JSON.parse(localStorage.getItem('otp.lb') || '{}') || {}; } catch (e) { st = {}; }
  return st;
})();
function lbKeep() { try { localStorage.setItem('otp.lb', JSON.stringify(LB_UI)); } catch (e) { /* not kept */ } }
function lbCode(tpl, v) {
  /* {key} in the text is a value: put in, and marked. */
  var pre = noI18n(el('pre', 'mono small lb-code'));
  tpl.split(/(\{[a-z0-9_]+\})/).forEach(function (part) {
    var m = /^\{([a-z0-9_]+)\}$/.exec(part);
    if (m && v[m[1]] !== undefined) pre.appendChild(el('span', 'lbv', String(v[m[1]])));
    else pre.appendChild(document.createTextNode(part));
  });
  return pre;
}
function lbBlock(tpl, v, title) {
  var box = el('div', 'lb-block');
  var head = el('div', 'lb-block-h' + (title ? '' : ' solo'));
  if (title) head.appendChild(el('span', 'arow-s', title));
  var cp = cmdButton('Copy', 'copy', 'small');
  var pre = lbCode(tpl, v);
  cp.onclick = function () { copyText(pre.textContent, cp); };
  head.appendChild(cp);
  box.appendChild(head);
  box.appendChild(pre);
  return box;
}
function lbServers(v, fmt) {
  return v.nodes.map(function (n, i) { return fmt(n, i); }).join('\n');
}
var LB_GUIDES = [
  ['haproxy', 'HAProxy', 'pages', function (v) {
    var out = [];
    if (v.tls === 'end') {
      out.push(['/etc/haproxy/haproxy.cfg - TLS ended on HAProxy',
        'frontend otp_https\n    bind {lb}:443 ssl crt /etc/haproxy/{name}.pem alpn h2,http/1.1\n    bind {lb}:80\n    mode http\n'
        + '    http-request redirect scheme https unless { ssl_fc }\n    option forwardfor\n    timeout client 900s\n    default_backend otp_nodes\n\n'
        + 'backend otp_nodes\n    mode http\n    balance roundrobin\n    timeout server 900s\n    option httpchk\n'
        + '    http-check send meth GET uri {hc} ver HTTP/1.1 hdr Host {name}\n    http-check expect status 200\n'
        + '    default-server inter 3s fall 2 rise 2 check ssl verify none\n'
        + lbServers(v, function (n, i) { return '    server {n' + i + '} {a' + i + '}:443'; })]);
    } else {
      out.push(['/etc/haproxy/haproxy.cfg - TLS passed through, the client\'s address in the PROXY protocol',
        'frontend otp_https\n    bind {lb}:443\n    mode tcp\n    timeout client 900s\n    default_backend otp_nodes\n\n'
        + 'backend otp_nodes\n    mode tcp\n    balance roundrobin\n    timeout server 900s\n    option httpchk\n'
        + '    http-check send meth GET uri {hc} ver HTTP/1.1 hdr Host {name}\n    http-check expect status 200\n'
        + '    default-server inter 3s fall 2 rise 2 check check-ssl verify none check-send-proxy send-proxy-v2\n'
        + lbServers(v, function (n, i) { return '    server {n' + i + '} {a' + i + '}:443'; })]);
    }
    out.push(['RADIUS: the open-source HAProxy does not balance UDP - give the VPN both nodes (Cisco ASA, FortiGate below) or use LVS.', '']);
    return out;
  }],
  ['nginx', 'nginx', 'pages + RADIUS', function (v) {
    return [['/etc/nginx/conf.d/otp-lb.conf - open-source nginx checks passively; nginx Plus can ask /healthz (the commented lines)',
      'upstream otp_nodes {\n' + lbServers(v, function (n, i) { return '    server {a' + i + '}:443 max_fails=2 fail_timeout=10s;'; })
      + '\n    keepalive 16;\n}\nserver {\n    listen {lb}:80;\n    server_name {name};\n    return 301 https://$host$request_uri;\n}\n'
      + 'server {\n    listen {lb}:443 ssl;\n    http2 on;\n    server_name {name};\n'
      + '    ssl_certificate     /etc/nginx/certs/{name}.pem;\n    ssl_certificate_key /etc/nginx/certs/{name}.key;\n'
      + '    client_max_body_size 4g;\n    location / {\n        proxy_pass https://otp_nodes;\n        proxy_http_version 1.1;\n'
      + '        proxy_set_header Connection "";\n        proxy_set_header Host $host;\n'
      + '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n        proxy_set_header X-Forwarded-Proto https;\n'
      + '        proxy_read_timeout 900s;\n        proxy_next_upstream error timeout http_502 http_503 http_504;\n'
      + '        # nginx Plus: health_check uri={hc} interval=3 fails=2 passes=2 match=otp_ok;\n    }\n}\n'
      + '# nginx Plus: match otp_ok { status 200; body ~ "^ok "; }'],
      ['/etc/nginx/nginx.conf - RADIUS over UDP (stream, outside http { })',
      'stream {\n    upstream otp_radius {\n' + lbServers(v, function (n, i) { return '        server {a' + i + '}:{auth} max_fails=2 fail_timeout=10s;'; })
      + '\n    }\n' + (v.acct ? '    upstream otp_accounting {\n' + lbServers(v, function (n, i) { return '        server {a' + i + '}:{acct};'; }) + '\n    }\n' : '')
      + '    server { listen {lb}:{auth} udp; proxy_pass otp_radius; proxy_responses 1; proxy_timeout 10s; }\n'
      + (v.acct ? '    server { listen {lb}:{acct} udp; proxy_pass otp_accounting; proxy_responses 1; proxy_timeout 10s; }\n' : '')
      + '}\n# the nodes then see {lb} as the RADIUS client: add it in Clients, with the shared secret']];
  }],
  ['apache', 'Apache httpd', 'pages', function (v) {
    return [['/etc/httpd/conf.d/otp-lb.conf - mod_proxy_balancer with mod_proxy_hcheck asking /healthz',
      'ProxyHCExpr otp_ok {%{REQUEST_STATUS} == 200 && hc(\'body\') =~ /^ok /}\n\n<VirtualHost {lb}:443>\n    ServerName {name}\n'
      + '    SSLEngine on\n    SSLCertificateFile    /etc/pki/tls/certs/{name}.crt\n    SSLCertificateKeyFile /etc/pki/tls/private/{name}.key\n'
      + '    SSLProxyEngine on\n    SSLProxyVerify none\n    SSLProxyCheckPeerName off\n\n    <Proxy "balancer://otp">\n'
      + lbServers(v, function (n, i) { return '        BalancerMember https://{a' + i + '} hcmethod=GET hcuri={hc} hcexpr=otp_ok hcinterval=3 hcpasses=2 hcfails=2'; })
      + '\n        ProxySet lbmethod=byrequests\n    </Proxy>\n    ProxyPreserveHost On\n'
      + '    ProxyPass        "/" "balancer://otp/" timeout=900\n    ProxyPassReverse "/" "balancer://otp/"\n    LimitRequestBody 0\n</VirtualHost>']];
  }],
  ['f5', 'F5 BIG-IP', 'pages + RADIUS', function (v) {
    return [['tmsh - a monitor that reads /healthz, the pool, the virtual server (SSL offload, X-Forwarded-For)',
      'create ltm monitor https otp_healthz defaults-from https interval 3 timeout 10 send "GET {hc} HTTP/1.1\\r\\nHost: {name}\\r\\nConnection: close\\r\\n\\r\\n" recv "^ok " recv-disable "maintenance"\n'
      + 'create ltm monitor https otp_radius_health defaults-from https interval 3 timeout 10 send "GET /healthz?check=radius HTTP/1.1\\r\\nHost: {name}\\r\\nConnection: close\\r\\n\\r\\n" recv "^ok "\n'
      + 'create ltm pool otp_https monitor otp_healthz load-balancing-mode round-robin members add { '
      + v.nodes.map(function (n, i) { return '{a' + i + '}:443'; }).join(' ') + ' }\n'
      + 'create ltm pool otp_radius monitor otp_radius_health members add { '
      + v.nodes.map(function (n, i) { return '{a' + i + '}:{auth}'; }).join(' ') + ' }\n'
      + 'create ltm profile http otp_http insert-xforwarded-for enabled\n'
      + 'create ltm virtual otp_vs destination {lb}:443 ip-protocol tcp pool otp_https profiles add { otp_http clientssl serverssl } source-address-translation { type automap }\n'
      + 'create ltm virtual otp_radius_vs destination {lb}:{auth} ip-protocol udp pool otp_radius profiles add { udp } source-address-translation { type none }'],
      ['Put your certificate for {name} into the clientssl profile. RADIUS without address translation keeps the concentrators\' addresses (their route back must go through the F5); with automap, add the self IPs in Clients.', '']];
  }],
  ['netscaler', 'Citrix ADC / NetScaler', 'pages + RADIUS', function (v) {
    return [['NetScaler CLI',
      'add lb monitor otp_healthz HTTP-ECV -send "GET {hc}" -recv "ok " -secure YES -interval 3 -resptimeout 2 -downTime 5\n'
      + lbServers(v, function (n, i) { return 'add server {n' + i + '} {a' + i + '}'; }) + '\n'
      + 'add serviceGroup otp_https SSL -cip ENABLED X-Forwarded-For\n'
      + lbServers(v, function (n, i) { return 'bind serviceGroup otp_https {n' + i + '} 443'; }) + '\n'
      + 'bind serviceGroup otp_https -monitorName otp_healthz\n'
      + 'add lb vserver otp_vs SSL {lb} 443 -lbMethod ROUNDROBIN -persistenceType NONE\n'
      + 'bind lb vserver otp_vs otp_https\nbind ssl vserver otp_vs -certkeyName {name}\n\n'
      + 'add lb monitor otp_radius_health HTTP-ECV -send "GET /healthz?check=radius" -recv "ok " -secure YES -destPort 443 -interval 3\n'
      + 'add serviceGroup otp_radius RADIUS -usip YES\n'
      + lbServers(v, function (n, i) { return 'bind serviceGroup otp_radius {n' + i + '} {auth}'; }) + '\n'
      + 'bind serviceGroup otp_radius -monitorName otp_radius_health\n'
      + 'add lb vserver otp_radius_vs RADIUS {lb} {auth} -lbMethod ROUNDROBIN\nbind lb vserver otp_radius_vs otp_radius']];
  }],
  ['lvs', 'keepalived + LVS', 'RADIUS', function (v) {
    var vs = function (port) {
      return 'virtual_server {lb} ' + port + ' {\n    delay_loop 3\n    lb_algo rr\n    lb_kind NAT\n    protocol UDP\n'
        + lbServers(v, function (n, i) {
          return '    real_server {a' + i + '} ' + port + ' {\n        SSL_GET {\n            url { path /healthz?check=radius status_code 200 }\n'
            + '            connect_port 443\n            connect_timeout 3\n            retry 2\n        }\n    }';
        }) + '\n}';
    };
    return [['/etc/keepalived/keepalived.conf on the balancer (two Linux machines, not the otp nodes)',
      vs('{auth}') + (v.acct ? '\n' + vs('{acct}') : '')],
      ['With lb_kind NAT the nodes see the concentrators\' own addresses; their route back must go through the balancer.', '']];
  }],
  ['asa', 'Cisco ASA', 'RADIUS, no balancer', function (v) {
    return [['Both nodes in one server group: the ASA asks the first, and the second when it does not answer',
      'aaa-server OTP protocol radius\n max-failed-attempts 2\n reactivation-mode timed\n dead-time 1\n'
      + lbServers(v, function (n, i) {
        return 'aaa-server OTP (inside) host {a' + i + '}\n key {secret}\n authentication-port {auth}\n'
          + (v.acct ? ' accounting-port {acct}\n' : '') + ' timeout 5';
      })]];
  }],
  ['forti', 'FortiGate', 'RADIUS, no balancer', function (v) {
    return [['FortiOS CLI - the second node as the secondary server',
      'config user radius\n    edit "otp"\n        set server "{a0}"\n        set secret {secret}\n'
      + (v.nodes[1] ? '        set secondary-server "{a1}"\n        set secondary-secret {secret}\n' : '')
      + '        set auth-type pap\n        set radius-port {auth}\n        set timeout 5\n    next\nend']];
  }]
];

function drawHaLb(d) {
  var host = $('ha-lb');
  var open = {};
  host.querySelectorAll('details.lb-guide').forEach(function (x) { open[x.dataset.k] = x.open; });
  if (host.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return;
  clear(host);
  var lb = d.lb || {};
  var nodes = (d.nodes || []).map(function (n) { return {name: n.name, address: n.address || ''}; });
  if (nodes.length < 2) nodes.push({name: 'otp2', address: '192.0.2.12'});
  var trusted = (lb.trusted || [])[0] || '';
  var v0 = {
    lb: LB_UI.lb || trusted.replace(/\/(32|128)$/, '') || '192.0.2.5',
    name: LB_UI.name || (lb.vip && lb.vip.fqdn) || lb.server_name || location.hostname,
    tls: LB_UI.tls || 'end', hc: LB_UI.hc || '/healthz', secret: LB_UI.secret || '<the shared secret>'};
  host.appendChild(el('p', 'note', 'Both nodes answer everything, so any balancer spreads the pages round robin, without sticky sessions. Each node says GET /healthz: 200 "ok NODE" while it really works (the daemon, its database), 503 in maintenance or an upgrade - so the balancer takes it out by itself. Pick yours below: the configuration is filled in with this cluster\'s own names, addresses and ports, marked in colour, and follows what you type here.'));
  if (lb.vip && lb.vip.on) {
    host.appendChild(el('p', 'note warn', 'The built-in web address (VIP) ' + lb.vip.address + ' is on: the pages need no balancer of yours. Use one or the other.'));
  }
  /* The values. */
  var form = el('div', 'lb-form');
  var field = function (words, key, ph, help) {
    var f = el('label', 'lb-f');
    f.appendChild(el('span', 'lb-f-k', words));
    var i = textBox('', '', 'mono'); i.value = v0[key]; i.placeholder = ph; i.spellcheck = false;
    i.oninput = function () { LB_UI[key] = i.value.trim(); lbKeep(); paint(); };
    f.appendChild(i);
    if (help) f.appendChild(el('span', 'arow-s', help));
    form.appendChild(f);
  };
  field('The balancer\'s address', 'lb', '192.0.2.5', 'its virtual address, the one people go to');
  field('The name people use', 'name', 'otp.example.cz', 'in its certificate');
  field('RADIUS shared secret', 'secret', '<the shared secret>', 'only put into the text here, never sent anywhere');
  var segOf = function (words, key, opts) {
    var f = el('div', 'lb-f');
    f.appendChild(el('span', 'lb-f-k', words));
    var seg = el('div', 'seg');
    opts.forEach(function (o) {
      var b = el('button', '', o[1]); b.type = 'button';
      if (v0[key] === o[0]) b.classList.add('on');
      b.onclick = function () { v0[key] = LB_UI[key] = o[0]; lbKeep(); Array.prototype.forEach.call(seg.children, function (x) { x.classList.toggle('on', x === b); }); paint(); };
      seg.appendChild(b);
    });
    f.appendChild(seg);
    form.appendChild(f);
  };
  segOf('TLS', 'tls', [['end', 'Ended on the balancer'], ['pass', 'Passed through (PROXY)']]);
  segOf('Health check', 'hc', [['/healthz', 'The pages'], ['/healthz?check=radius', '+ RADIUS listening']]);
  host.appendChild(form);
  /* The nodes as they are. */
  var facts = el('div', 'lb-facts');
  nodes.forEach(function (n) {
    var c = el('span', 'cchip');
    c.appendChild(noI18n(el('b', '', n.name)));
    c.appendChild(noI18n(document.createTextNode(' ' + (n.address || '?'))));
    facts.appendChild(c);
  });
  facts.appendChild(noI18n(el('span', 'cchip', 'RADIUS ' + (lb.auth_port || 1812) + (lb.acct_port ? ' / ' + lb.acct_port : ''))));
  host.appendChild(facts);
  var trust = el('div', 'lb-trust');
  host.appendChild(trust);
  var list = el('div', 'lb-list');
  host.appendChild(list);
  function values() {
    var v = {lb: LB_UI.lb || v0.lb, name: LB_UI.name || v0.name, hc: v0.hc, tls: v0.tls,
             secret: LB_UI.secret || v0.secret, auth: lb.auth_port || 1812, acct: lb.acct_port || 0, nodes: nodes};
    nodes.forEach(function (n, i) { v['n' + i] = n.name; v['a' + i] = n.address || '192.0.2.1' + (i + 1); });
    return v;
  }
  function paint() {
    var v = values();
    /* The client's own address: are the nodes told the balancer's? */
    clear(trust);
    var ok = (lb.trusted || []).some(function (t) { return t.replace(/\/(32|128)$/, '') === v.lb; });
    if (v.tls === 'end') {
      trust.appendChild(el('div', 'note ' + (ok ? 'good' : 'warn'), ok
        ? 'The nodes already take the client\'s own address from X-Forwarded-For sent by ' + v.lb + '.'
        : 'Tell both nodes the balancer\'s address, so that the allow lists, the sign-in pause and every log see the client and not the balancer - as root on each node:'));
      if (!ok) trust.appendChild(lbBlock('otp --trusted-proxy {lb}/' + (v.lb.indexOf(':') >= 0 ? '128' : '32'), v, ''));
    } else {
      trust.appendChild(el('div', 'note', 'Passed through: in /etc/nginx/conf.d/otp.conf on both nodes, the PROXY protocol from the balancer only:'));
      trust.appendChild(lbBlock('listen 443 ssl proxy_protocol;        # in place of: listen 443 ssl;\nset_real_ip_from {lb};\nreal_ip_header proxy_protocol;\n\nnginx -t && systemctl reload nginx', v, ''));
    }
    clear(list);
    LB_GUIDES.concat([['check', 'Check it', 'after', function () {
      return [['From any machine: each node, then through the balancer; maintenance must take a node out',
        lbServers(v, function (n, i) { return 'curl -sk https://{a' + i + '}{hc}            # ok {n' + i + '}'; })
        + '\ncurl -sk https://{name}{hc}\n\n# on {n0}, as root:\notp --maintenance on --why "balancer test"\n'
        + 'curl -sk https://{a0}/healthz             # 503 maintenance {n0} - the balancer sends everything to {n1}\notp --maintenance off']];
    }]]).forEach(function (g) {
      var det = el('details', 'lb-guide');
      det.dataset.k = g[0];
      var sum = el('summary', '');
      sum.appendChild(el('b', '', g[1]));
      sum.appendChild(el('span', 'tag dim', g[2]));
      det.appendChild(sum);
      g[3](v).forEach(function (part) {
        if (part[1]) det.appendChild(lbBlock(part[1], v, part[0].replace(/\{name\}/g, v.name)));
        else det.appendChild(el('p', 'note', part[0].replace(/\{name\}/g, v.name)));
      });
      det.open = !!open[g[0]];
      det.ontoggle = function () { open[g[0]] = det.open; };
      list.appendChild(det);
    });
  }
  paint();
  host.appendChild(el('p', 'note', 'More, with the reasons: docs/load-balancers.md in the package.'));
}

if ($('ha-bundle')) {
  $('ha-bundle').onclick = function () {
    var host;
    modal('The bundle for the second node', function (body) {
      body.appendChild(el('p', 'note', 'What the second node needs and nothing else: the database’s address and password and the key that opens the tokens - locked with a passphrase made here and shown once. Keep the two apart: the file over scp or a USB stick, the passphrase typed.'));
      if (HA && HA.replication && HA.replication.mode === 'replicated') {
        body.appendChild(el('p', 'note', 'This node replicates with its own PostgreSQL: the bundle makes the other node of the two - or makes it again, after it was lost or reinstalled.'));
        host = {value: ''};
        return;
      }
      host = textBox((HA && HA.db_host && ['localhost', '127.0.0.1', '::1', ''].indexOf(HA.db_host) < 0) ? HA.db_host : (HA && HA.address) || '', 'the address the second node reaches PostgreSQL at', 'mono');
      body.appendChild(formField('PostgreSQL, as the second node reaches it', host, 'This machine’s address when PostgreSQL runs here - which then has to listen on the network and let the second node in (otp --ha-setup does it, as root).'));
    }, [{words: 'Close', close: true}, {words: 'Make it', cls: 'primary', icon: 'key', go: function (b) {
      busy(b, true);
      api('ha', {action: 'bundle', db_host: host.value.trim()}).then(function (d) {
        var blob = new Blob([JSON.stringify(d.bundle, null, 1) + '\n'], {type: 'application/json'});
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = d.name;
        document.body.appendChild(link);
        link.click();
        setTimeout(function () { URL.revokeObjectURL(link.href); link.remove(); }, 1500);
        var body = $('modal-body');
        clear(body);
        body.appendChild(el('p', 'note good', 'The bundle was saved as ' + d.name + '. Its passphrase, shown only now:'));
        var pw = el('input'); pw.type = 'text'; pw.readOnly = true; pw.className = 'mono'; pw.value = d.passphrase;
        pw.style.fontSize = '18px';
        pw.onclick = function () { pw.select(); };
        noI18n(pw);
        body.appendChild(pw);
        var on2 = el('p', 'note', 'On the second node, as root:'); on2.style.marginTop = '14px'; body.appendChild(on2);
        body.appendChild(noI18n(el('pre', 'mono small', 'otp --ha-join /root/' + d.name)));
        body.appendChild(el('p', 'note', d.mode === 'replicated'
          ? 'It sets PostgreSQL up there, copies every row from this node and starts both directions of the replication.'
          : 'or sign in to its pages and press Join a cluster… there. The database it will open: ' + d.db_host + '.'));
        clear($('modal-foot'));
        var c = cmdButton('Close', 'close', ''); c.onclick = closeModal; $('modal-foot').appendChild(c);
      }).catch(function (e) { busy(b, false); oops(e); });
    }}], 'medium');
  };
  $('ha-join').onclick = function () {
    var file = null, phrase, name, even;
    modal('Join a cluster', function (body) {
      body.appendChild(el('p', 'note bad', 'This node then opens the cluster’s database and takes its key: what this node holds now - its own database, its own accounts and tokens - is no longer used. Do it on a node just installed.'));
      var pick = el('input'); pick.type = 'file'; pick.accept = '.json,application/json';
      pick.onchange = function () { file = pick.files && pick.files[0]; };
      body.appendChild(formField('The bundle (otp-join-….json)', pick));
      phrase = secretBox('', 'xxxxx-xxxxx-xxxxx-xxxxx-xxxxx', 'mono');
      noI18n(phrase);
      body.appendChild(formField('Its passphrase', phrase));
      name = textBox((HA && HA.node) || '', '', '');
      body.appendChild(formField('This node’s name', name, 'How it is called among the nodes.'));
      even = switchBox(false);
      body.appendChild(formField('Even though this node has tokens of its own (they are left behind)', even));
    }, [{words: 'Close', close: true}, {words: 'Join', cls: 'danger', icon: 'net', go: function (b) {
      if (!file) { toast('choose the bundle first', 'bad'); return; }
      busy(b, true);
      var reader = new FileReader();
      reader.onload = function () {
        api('ha', {action: 'join', bundle: String(reader.result || ''), passphrase: phrase.value.trim(),
                   name: name.value.trim(), even_if_data: !!even._get()}).then(function (d) {
          toast(d.message, 'good');
          closeModal();
          setTimeout(function () { location.reload(); }, 9000);
        }).catch(function (e) { busy(b, false); oops(e); });
      };
      reader.readAsText(file);
    }}], 'medium');
  };
}


/* ---- the replication between the two PostgreSQLs (1.0.14) ---- */
function drawHaRep(d) {
  var r = d.replication || {};
  var card = $('ha-rep-card');
  card.hidden = r.mode !== 'replicated';
  if (r.mode !== 'replicated') return;
  $('ha-rep-said').textContent = r.healthy ? 'both directions running' : 'needs a look';
  $('ha-rep-said').className = 'right ' + (r.healthy ? 'good' : 'bad');
  var host = $('ha-rep');
  clear(host);
  var rows = [];
  (r.incoming || []).forEach(function (x) {
    var base = (d.errbase || {})[x.name] || {};
    var all = (x.apply_errors || 0) + (x.sync_errors || 0);
    rows.push({dir: 'in', from: r.peer, to: d.node, state: !x.enabled ? 'paused' : (x.running ? 'running' : 'not running'),
               ok: x.enabled && x.running, when: x.last_msg, errors: Math.max(0, all - (base.apply || 0) - (base.sync || 0)),
               before: all});
  });
  if (!(r.incoming || []).length) rows.push({dir: 'in', from: r.peer, to: d.node, state: 'not set up', ok: false});
  (r.outgoing || []).forEach(function (x) {
    rows.push({dir: 'out', from: d.node, to: r.peer, state: x.wal_status === 'lost' ? 'lost - rebuild the other node'
               : (x.active ? 'taken' : 'waiting for the other node'), ok: x.active && x.wal_status !== 'lost',
               behind: x.behind, wal: x.wal_status});
  });
  if (!(r.outgoing || []).length) rows.push({dir: 'out', from: d.node, to: r.peer, state: 'not set up', ok: false});
  host.appendChild(listTable(['Direction', 'From', 'To', 'State', 'Last heard', {words: 'Waiting to go over', cls: 'num'}, 'Errors'], rows, function (x) {
    var tr = el('tr');
    tr.appendChild(el('td', '', x.dir === 'in' ? 'coming in' : 'going out'));
    tr.appendChild(noI18n(el('td', 'mono small', x.from || '')));
    tr.appendChild(noI18n(el('td', 'mono small', x.to || '')));
    var st = el('td'); st.appendChild(el('span', 'tag ' + (x.ok ? 'ok' : (x.state === 'paused' ? 'warn' : 'crit')), x.state)); tr.appendChild(st);
    tr.appendChild(el('td', 'muted', x.when ? ago(x.when) : '–'));
    tr.appendChild(el('td', 'num', x.behind !== undefined ? bytes(x.behind) : '–'));
    var ec = el('td');
    if (x.errors) {
      /* A click says what they were (1.0.52). */
      var eb = el('button', 'linkish bad', num(x.errors) + ' - what?');
      eb.type = 'button';
      eb.title = 'What PostgreSQL said, and clearing them';
      eb.onclick = haErrors;
      ec.appendChild(eb);
    } else {
      ec.appendChild(el('span', 'muted', x.dir === 'in' && x.before ? '– (cleared)' : '–'));
    }
    tr.appendChild(ec);
    return tr;
  }));
  if (r.lost) host.appendChild(el('p', 'note bad', 'The other node was away longer than what is kept for it: rebuild it from this one - on the other node, Rebuild this node from the other.'));
  if (r.trouble) host.appendChild(el('p', 'note bad', r.trouble));
  var paused = (r.incoming || []).some(function (x) { return !x.enabled; });
  $('ha-pause').disabled = paused;
  $('ha-resume').disabled = !paused && r.healthy;
  if (d.job && d.job.running) haWatch();
}
function haDo(act, words) {
  return api('ha', {action: act}).then(function (x) { toast(x.message || words, 'good'); loadHa(); }).catch(oops);
}
var HA_WATCHING = null;
function haWatch() {
  if (HA_WATCHING) return;
  $('ha-going').hidden = false;
  var step = function () {
    api('db', {action: 'job'}).then(function (d) {
      var j = d.job || {};
      $('ha-going-fill').style.width = (j.whole ? Math.round(100 * j.done / j.whole) : 5) + '%';
      $('ha-going-says').textContent = (j.what || '') + (j.says ? ' — ' + j.says : '');
      if (j.running) { HA_WATCHING = setTimeout(step, TAB === 'settings' && PANE === 'ha' ? 1000 : 5000); return; }
      HA_WATCHING = null;
      if (j.error) { toast(j.error, 'bad'); return; }
      if (j.result && j.result.rows !== undefined) toast('rebuilt from the other node: ' + num(j.result.rows) + ' row(s)', 'good');
      loadHa();
    }).catch(function (e) { HA_WATCHING = null; oops(e); });
  };
  step();
}
var HA_MAKE_OPEN = false;
if ($('ha-make-btn')) {
  $('ha-make-btn').onclick = function () {
    HA_MAKE_OPEN = !HA_MAKE_OPEN;
    $('ha-make-body').hidden = !HA_MAKE_OPEN;
    setButtonIcon($('ha-make-btn'), HA_MAKE_OPEN ? 'close' : 'eye', HA_MAKE_OPEN ? 'Fold the steps away' : 'Show how it was made');
  };
}
if ($('ha-pause')) {
  $('ha-pause').onclick = function () {
    modal('Pause the replication', function (body) {
      body.appendChild(el('p', 'note', 'Both nodes go on answering, each with its own database; neither sends the other anything until it is resumed. What is written meanwhile waits on each node for the other - up to 16 GB of it - and goes over when it is resumed.'));
      body.appendChild(el('p', 'note', 'Or only one direction:'));
    }, [{words: 'Close', close: true},
        {words: 'Only what comes in', icon: 'power', close: true, go: function () { haDo('pause_in'); }},
        {words: 'Only what goes out', icon: 'power', close: true, go: function () { haDo('pause_out'); }},
        {words: 'Pause both', cls: 'primary', icon: 'power', close: true, go: function () { haDo('pause'); }}], 'medium');
  };
  $('ha-resume').onclick = function () { haDo('resume'); };
  $('ha-refresh').onclick = function () { haDo('refresh'); };
  $('ha-resync').onclick = function () {
    confirmThen('Rebuild this node from the other', 'Everything in <b>this</b> node’s database is replaced by what the other holds: its tables emptied and every row copied over, and both directions made afresh. A copy of what is here is made first. What was written here and never reached the other is only in that copy. You will be signed out.', 'Rebuild it', function () {
      api('ha', {action: 'resync'}).then(function () { haWatch(); }).catch(oops);
    });
  };
  $('ha-stop').onclick = function () {
    confirmThen('Switch the replication off', 'Both subscriptions and their slots are taken away. Each node goes on alone with what it has, and from then on they drift apart. Putting them together again is a rebuild of one from the other.', 'Switch it off', function () { haDo('stop'); });
  };
}

if ($('tk-names')) {
  $('tk-names').onclick = function () {
    var b = $('tk-names');
    busy(b, true);
    api('token', {action: 'fill_names'}).then(function (d) {
      toast(d.message, d.filled ? 'good' : '');
      if (typeof loadTokens === 'function') loadTokens();
    }).catch(oops).then(function () { busy(b, false); });
  };
}

/* The Test tab's password box, masked like every other (1.0.22). */
(function () {
  var old = $('rt-pass');
  if (!old || old.classList.contains('masked')) return;
  var box = maskBox('', '', 'mono');
  box.id = 'rt-pass';
  old.parentNode.replaceChild(box, old);
})();

/* Signed out after the idle time even with the page left open (1.0.33): the
   live refresh asks the daemon every few seconds, which kept the sign-in
   fresh for ever. What counts is a person using the page. */
(function () {
  var last = Date.now(), limit = 0;
  ['mousemove', 'keydown', 'click', 'scroll', 'touchstart', 'wheel'].forEach(function (e) {
    document.addEventListener(e, function () { last = Date.now(); }, {passive: true, capture: true});
  });
  api('whoami').then(function (d) { limit = (d.idle_min || 120) * 60000; }).catch(function () {});
  setInterval(function () {
    if (limit && Date.now() - last > limit) {
      limit = 0;
      api('logout', {}).then(function () { location.reload(); }, function () { location.reload(); });
    }
  }, 30000);
})();


/* ---- upgrades and maintenance (1.0.37) ------------------------------------ */
var UP = {timer: null, held: null, misses: 0};
var UP_STATE = {waiting: ['waiting', 'dim'], none: ['waiting', 'dim'], draining: ['taken out of service', 'warn'],
                installing: ['being put in', 'info'], checking: ['checking', 'info'],
                done: ['done', 'ok'], failed: ['failed', 'crit']};
function upgradeSend(file) {
  return fetch('?api=upgrade-package', {method: 'POST', body: file, credentials: 'same-origin',
               headers: {'X-Otp-Restore': '1', 'Content-Type': 'application/octet-stream'}})
    .then(function (r) {
      return r.json().catch(function () {
        throw new Error('the server did not answer with anything readable (HTTP ' + r.status + ')');
      }).then(function (d) {
        if (!r.ok || d.ok === false) throw new Error(d.error || ('the server said ' + r.status));
        return d;
      });
    });
}
function upgradeAgain(ms) {
  clearTimeout(UP.timer);
  UP.timer = setTimeout(function () { if (PANE === 'upgrade' && !$('pane-upgrade').hidden) loadUpgrade(); }, ms);
}
function maintenanceAsk(n, on, then) {
  var alone = (UP.last && (UP.last.nodes || []).filter(function (x) { return x.alive; }).length) <= 1;
  if (!on) {
    api('upgrade', {action: 'maintenance', node: n.name, on: false}).then(function (r) { toast(r.message, 'good'); then(r); }).catch(oops);
    return;
  }
  modal('Take ' + n.name + ' out of service', function (body) {
    var p = el('p', 'note');
    p.textContent = alone
      ? 'This is the only server: while it is in maintenance nobody can sign in to the VPN. Its pages go on working.'
      : 'It stops answering RADIUS and its /healthz says 503: the VPN and the load balancer go to the other node. Its pages go on working.';
    if (alone) p.className = 'note bad';
    body.appendChild(p);
    var why = textBox('', 'why - for the events', '');
    why.id = 'maint-why';
    body.appendChild(formField('Why', why));
  }, [{words: 'No, leave it', close: true},
      {words: 'Take it out', cls: alone ? 'danger' : 'primary', icon: 'power', close: true, go: function () {
        api('upgrade', {action: 'maintenance', node: n.name, on: true, why: ($('maint-why') || {}).value || ''})
          .then(function (r) { toast(r.message, 'good'); then(r); }).catch(oops);
      }}], true);
}
function drawUpgrade(d) {
  UP.last = d;
  /* The nodes. */
  var host = $('up-nodes');
  clear(host);
  host.appendChild(listTable(['Node', 'Version', 'Heard from', 'State', ''], d.nodes || [], function (n) {
    var tr = el('tr');
    var nm = el('td');
    nm.appendChild(noI18n(el('b', '', n.name)));
    if (n.me) { nm.appendChild(document.createTextNode(' ')); nm.appendChild(el('span', 'tag info', 'this page')); }
    tr.appendChild(nm);
    tr.appendChild(noI18n(el('td', 'mono', n.version || '?')));
    tr.appendChild(el('td', 'muted', n.at ? ago(n.at) : '–'));
    var st = el('td');
    var m = n.maintenance || {};
    if (!n.alive) st.appendChild(el('span', 'tag crit', 'gone'));
    else if (m.on) st.appendChild(el('span', 'tag warn', 'in maintenance'));
    else st.appendChild(el('span', 'tag ok', 'in service'));
    if (m.on && m.why) st.appendChild(el('span', 'sub', m.why + (m.by ? ' · ' + m.by : '') + (m.at ? ' · ' + ago(m.at) : '')));
    tr.appendChild(st);
    var tools = el('td', 'rowtools');
    if (ADMIN && n.alive) {
      var b = cmdButton(m.on ? 'Back in service' : 'Maintenance', m.on ? 'play' : 'power', 'small');
      b.onclick = function (ev) { ev.stopPropagation(); maintenanceAsk(n, !m.on, drawUpgrade); };
      tools.appendChild(b);
    }
    tr.appendChild(tools);
    return tr;
  }, 'plain'));
  /* The package. */
  var pk = $('up-pkg');
  clear(pk);
  var plan = d.plan;
  var running = !!(plan && plan.state === 'running');
  if (d.package) {
    var p = d.package;
    var box = el('div', 'notice good');
    box.style.marginTop = '12px';
    box.appendChild(el('b', '', 'otp ' + p.version));
    box.appendChild(el('div', 'small', 'signed by ' + (p.signed_by || '?') + ' · ' + bytes(p.bytes) + ' · sent by ' + (p.by || '?') + ' · ' + ago(p.at)));
    pk.appendChild(box);
    if (p.changelog) {
      var det = el('details', 'fold');
      det.appendChild(el('summary', '', 'What changed in ' + p.version));
      var pre = el('pre', 'lines', p.changelog);
      noI18n(pre);
      det.appendChild(pre);
      pk.appendChild(det);
    }
  }
  $('up-forget').hidden = !d.package || running;
  $('up-start').disabled = !d.package || !d.ready || running;
  var many = (d.nodes || []).length > 1;
  setButtonIcon($('up-start'), 'play', many ? 'Upgrade every node, one at a time' : 'Upgrade this server');
  var rd = $('up-ready');
  clear(rd);
  if (d.package && !d.ready && !running) {
    (d.not_ready || []).forEach(function (w) { rd.appendChild(el('p', 'note bad', w)); });
  }
  if (!d.helper || !d.path_unit) {
    rd.appendChild(el('p', 'note bad', 'This server cannot put a version in by itself yet: otp-upgrade.path is not installed. Upgrade it once on the command line (install.sh --upgrade), which puts it in.'));
  }
  /* The plan. */
  $('up-plan-card').hidden = !plan;
  var ph = $('up-plan');
  clear(ph);
  if (plan) {
    ph.appendChild(el('p', 'note', 'To ' + plan.version + ' · started by ' + (plan.by || '?') + ' · ' + ago(plan.at) + ' · '
      + ({running: 'going on', done: 'done', failed: 'failed', cancelled: 'stopped'})[plan.state]));
    ph.appendChild(listTable(['Node', 'Step', 'What happened', 'When'], plan.steps || [], function (st) {
      var tr = el('tr');
      tr.appendChild(noI18n(el('td', 'mono', st.name)));
      var w = UP_STATE[st.state] || UP_STATE.waiting;
      var c = el('td');
      c.appendChild(el('span', 'tag ' + w[1], w[0]));
      tr.appendChild(c);
      var said = el('td', 'small', st.said || '');
      if ((st.tail || []).length) {
        var more = el('details', 'fold');
        more.appendChild(el('summary', '', 'what install.sh said'));
        more.appendChild(noI18n(el('pre', 'lines', st.tail.join('\n'))));
        said.appendChild(more);
      }
      tr.appendChild(said);
      tr.appendChild(el('td', 'muted', st.at ? ago(st.at) : '–'));
      return tr;
    }, 'plain'));
    if (plan.state === 'done' && d.version !== VERSION_LOADED) {
      var r = el('p', 'note good');
      r.appendChild(document.createTextNode('This page is still the one of ' + VERSION_LOADED + '. '));
      var a = el('a', 'fgo', 'Load it again');
      a.onclick = function () { location.reload(); };
      r.appendChild(a);
      ph.appendChild(r);
    }
  }
  $('up-cancel').hidden = !running;
  var lg = $('up-log');
  lg.textContent = (d.log || []).length ? d.log.join('\n') : '–';
  noI18n(lg);
  if (running) upgradeAgain(3000);
}
/* The version these pages came with: what the script was asked for as. */
var VERSION_LOADED = (function () {
  var sc = document.querySelector('script[src*="admin.js"]');
  var m = sc && /[?&]v=([0-9.]+)/.exec(sc.getAttribute('src') || '');
  return m ? m[1] : '';
}());
function loadUpgrade() {
  api('upgrade').then(function (d) {
    UP.misses = 0;
    if (!VERSION_LOADED) VERSION_LOADED = d.version;
    drawUpgrade(d);
  }).catch(function (e) {
    /* The node that answers these pages may be the one being restarted. */
    if (UP.last && UP.last.plan && UP.last.plan.state === 'running' && UP.misses++ < 100) {
      var ph = $('up-plan');
      if (ph && !ph.querySelector('.restarting')) ph.appendChild(el('p', 'note restarting', 'The server is restarting - asking again…'));
      upgradeAgain(3000);
      return;
    }
    oops(e);
  });
}
if ($('up-drop')) {
  (function () {
    var box = $('up-drop');
    function send(file) {
      if (!file) return;
      $('up-drop-says').textContent = 'checking ' + file.name + ' (' + bytes(file.size) + ')…';
      upgradeSend(file).then(function (d) {
        toast(d.message || 'checked', 'good');
        $('up-drop-says').textContent = 'Drop the otp-X.Y.Z.tar.gz here, or press to choose it';
        drawUpgrade(d);
      }).catch(function (e) {
        $('up-drop-says').textContent = 'Drop the otp-X.Y.Z.tar.gz here, or press to choose it';
        modal('The package was not taken', function (body) {
          body.appendChild(el('p', 'note bad', String(e.message || e)));
        }, null, true);
      });
    }
    box.onclick = function () { $('up-file').click(); };
    $('up-file').onchange = function () { send(this.files && this.files[0]); this.value = ''; };
    ['dragenter', 'dragover'].forEach(function (name) {
      box.addEventListener(name, function (e) { e.preventDefault(); box.classList.add('over'); });
    });
    ['dragleave', 'drop'].forEach(function (name) {
      box.addEventListener(name, function (e) {
        e.preventDefault();
        box.classList.remove('over');
        if (name === 'drop' && e.dataTransfer && e.dataTransfer.files) send(e.dataTransfer.files[0]);
      });
    });
    $('up-start').onclick = function () {
      var d = UP.last || {};
      var p = d.package || {};
      var names = (d.nodes || []).filter(function (n) { return n.alive; }).map(function (n) { return n.name; });
      var many = names.length > 1;
      confirmThen(many ? 'Upgrade every node to ' + p.version : 'Upgrade this server to ' + p.version,
        many ? 'One node at a time: it is taken out of service, upgraded, checked and brought back, and only then the next one. The VPN and the load balancer use the other node meanwhile.'
             : 'This server is the only one: while it is put in and restarted - a minute or two - nobody can sign in to the VPN, and these pages stop answering for a moment.',
        'Upgrade', function () {
          api('upgrade', {action: 'start'}).then(function (r) { toast(r.message, 'good'); drawUpgrade(r); }).catch(oops);
        }, !many);
    };
    $('up-forget').onclick = function () {
      confirmThen('Throw the package away', 'The uploaded package is deleted; upload it again to upgrade.', 'Throw it away', function () {
        api('upgrade', {action: 'forget'}).then(function (r) { toast(r.message, 'good'); drawUpgrade(r); }).catch(oops);
      });
    };
    $('up-cancel').onclick = function () {
      confirmThen('Stop the upgrade', 'A node being put in right now is finished; the ones not begun stay as they are.', 'Stop it', function () {
        api('upgrade', {action: 'cancel'}).then(function (r) { toast(r.message, 'good'); drawUpgrade(r); }).catch(oops);
      });
    };
  }());
}

/* ==========================================================================
   Certificates and the web address (1.0.47)
   ========================================================================== */
var WEB = {last: null, timer: null};
function loadWeb() {
  api('web').then(drawWeb).catch(oops);
  clearInterval(WEB.timer);
  WEB.timer = setInterval(function () {
    if (PANE !== 'web' || !$('pane-web') || $('pane-web').hidden) { clearInterval(WEB.timer); return; }
    if ($('modal') && !$('modal').hidden) return;
    api('web').then(drawWeb).catch(function () {});
  }, 5000);
}
function daysLeft(ts) { return ts ? Math.floor((ts - Date.now() / 1000) / 86400) : null; }
function certTone(days) { return days === null ? 'dim' : (days < 0 ? 'crit' : (days < 21 ? 'warn' : 'ok')); }
function webTargetWords(t) { return t === 'vip' ? 'the web address' : t; }

function certCard(d, target) {
  var prof = d.tls[target];
  var node = (d.nodes || []).filter(function (n) { return n.name === target; })[0];
  var w = target === 'vip' ? null : ((node || {}).web || {});
  var info = (prof && prof.info) || (w && w.cert_now) || null;
  if (target === 'vip' && !info) {
    var holder = (d.nodes || []).filter(function (n) { return (n.web || {}).vip_cert_now; })[0];
    if (holder && prof) info = holder.web.vip_cert_now;
  }
  var card = el('section', 'cert-card');
  var head = el('header', 'cert-h');
  var title = el('div', 'cert-title');
  title.appendChild(el('span', 'cert-target', target === 'vip' ? 'The web address (VIP) of the cluster' : 'Node'));
  title.appendChild(noI18n(el('b', '', target === 'vip' ? (d.vip.fqdn || d.vip.address || '–') : target)));
  if (target === 'vip') {
    /* Said plainly what this card is (1.0.50). */
    title.appendChild(el('span', 'cert-for', d.vip.address
      ? 'the certificate answered on the VIP ' + String(d.vip.address).split('/')[0] + ', whichever node holds it'
      : 'the certificate of the VIP - the address is set on Settings → High availability'));
  }
  if (node && node.me) title.appendChild(el('span', 'tag dim', 'this one'));
  if (target !== 'vip') {
    /* The same line under every name, so the cards stand level (1.0.51). */
    title.appendChild(el('span', 'cert-for', 'the certificate answered on ' + target + '\'s own name and address' +
      (node && node.address ? ' (' + node.address + ')' : '')));
  }
  head.appendChild(title);
  var days = info ? daysLeft(info.not_after) : null;
  var badge = el('span', 'tag ' + certTone(days), days === null ? 'no certificate' :
    (days < 0 ? 'ran out' : (days < 21 ? days + ' days left' : 'valid')));
  head.appendChild(badge);
  card.appendChild(head);
  if (info) {
    var b = el('div', 'cert-body');
    b.appendChild(noI18n(el('div', 'cert-cn', info.cn || info.subject || '')));
    var bar = el('div', 'cert-life');
    var span = info.not_after && info.not_before ? (info.not_after - info.not_before) : 1;
    var used = info.not_before ? Math.max(0, Math.min(1, (Date.now() / 1000 - info.not_before) / span)) : 0;
    var fill = el('span', 'cert-life-fill ' + certTone(days));
    fill.style.width = Math.round(used * 100) + '%';
    bar.appendChild(fill);
    b.appendChild(bar);
    var facts = [['Issued by', noI18n(el('span', '', info.self_signed ? 'itself (self-signed)' : (info.issuer || '').replace(/^CN=/, '')))],
                 ['Valid until', info.not_after ? stamp(info.not_after) : '–'],
                 ['Key', info.key || '–']];
    if (info.san && info.san.length) facts.push(['Names', noI18n(el('span', '', info.san.join(', ')))]);
    if (prof) {
      facts.push(['Chain', prof.chain_info ? (prof.chain_info.length + ' between it and the root') : '–']);
      facts.push(['Root', prof.root_info && prof.root_info.length ? noI18n(el('span', '', prof.root_info[0].cn || 'given')) : 'not given']);
      if (prof.verify) facts.push(['Checked', prof.verify === 'ok' ? el('span', 'good', 'the chain leads to the root') : el('span', 'bad', prof.verify)]);
    }
    var kv = el('dl', 'cert-kv');
    facts.forEach(function (f) {
      kv.appendChild(el('dt', '', f[0]));
      var dd = el('dd');
      if (f[1] && f[1].nodeType) dd.appendChild(f[1]); else dd.textContent = f[1];
      kv.appendChild(dd);
    });
    b.appendChild(kv);
    card.appendChild(b);
  } else {
    card.appendChild(el('p', 'note', target === 'vip'
      ? 'None of its own: the web address answers with the certificate of the node it is on.'
      : 'Not known yet.'));
  }
  /* How TLS is spoken, as chips. */
  var chips = el('div', 'cert-chips');
  var preset = (prof && prof.preset) || 'standard';
  chips.appendChild(el('span', 'cchip', {standard: 'TLS 1.2 + 1.3, ECDHE', intermediate: 'Mozilla intermediate', modern: 'TLS 1.3 only', custom: 'custom'}[preset] || preset));
  if (prof && prof.dh && prof.dh !== 'none') chips.appendChild(noI18n(el('span', 'cchip', 'DH ' + prof.dh)));
  if (prof && prof.hsts) chips.appendChild(el('span', 'cchip', 'HSTS ' + Math.round(prof.hsts / 86400) + ' days'));
  if (prof && prof.pending) chips.appendChild(el('span', 'cchip warn', 'a request waits for its certificate'));
  if (!prof && target !== 'vip') chips.appendChild(el('span', 'cchip dim', 'as install.sh made it'));
  card.appendChild(chips);
  /* Is it in place on the node? */
  if (target === 'vip' && prof && d.vip && d.vip.on) {
    /* The web address's certificate is put in on every node (1.0.51). */
    (d.nodes || []).forEach(function (n) {
      var nw = n.web || {};
      if (nw.progress) { card.appendChild(certProgress(nw.progress, n.name)); return; }
      var st2 = el('div', 'cert-state');
      st2.appendChild(el('span', 'dot ' + (nw.state === 'failed' ? 'crit' : (nw.current ? 'ok' : 'warn'))));
      st2.appendChild(el('span', '', nw.state === 'failed' ? n.name + ': ' + ((nw.said || []).slice(-1)[0] || 'failed')
        : (nw.current ? 'in place on ' + n.name : 'being put in on ' + n.name + '…')));
      card.appendChild(st2);
    });
  } else if (target === 'vip' && prof && d.vip && !d.vip.on) {
    card.appendChild(el('p', 'note small', 'Put in on the nodes once the web address is turned on (Settings → High availability).'));
  }
  if (target !== 'vip' && w && w.progress) {
    card.appendChild(certProgress(w.progress, target));
  } else if (prof && target !== 'vip' && w) {
    var st = el('div', 'cert-state');
    st.appendChild(el('span', 'dot ' + (w.state === 'failed' ? 'crit' : (w.current ? 'ok' : 'warn'))));
    st.appendChild(el('span', '', w.state === 'failed' ? 'root could not put it in: ' + ((w.said || []).slice(-1)[0] || '')
      : (w.current ? 'in place on ' + target : 'being put in on ' + target + '…')));
    card.appendChild(st);
  }
  if (d.may) {
    var tools = el('div', 'cert-tools');
    var up = cmdButton('Upload', 'upload', 'small');
    up.onclick = function () { certUpload(target, prof); };
    tools.appendChild(up);
    var req = cmdButton(prof && prof.pending ? 'The waiting request' : 'Request (CSR)', 'list', 'small');
    req.onclick = function () { certRequest(target, prof); };
    tools.appendChild(req);
    var ss = cmdButton('Self-signed', 'key', 'small');
    ss.onclick = function () { certSelf(target, d); };
    tools.appendChild(ss);
    var pol = cmdButton('TLS settings', 'gear', 'small');
    pol.onclick = function () { certPolicy(target, prof, d); };
    tools.appendChild(pol);
    if (prof && prof.cert) {
      var dl = cmdButton('Download', 'download', 'small');
      dl.title = 'The certificate and its chain, as PEM - without the key';
      dl.onclick = function () {
        api('web', {action: 'tls_pem', target: target}).then(function (x) {
          saveFile((target === 'vip' ? 'web-address' : target) + '.pem', x.pem);
        }).catch(oops);
      };
      tools.appendChild(dl);
      var fg = cmdButton('Let go', 'forget', 'small danger-soft');
      fg.title = 'otp stops looking after it (nginx keeps what it has)';
      fg.onclick = function () {
        confirmThen('Stop looking after the TLS of ' + webTargetWords(target), 'nginx keeps the files it has now; otp no longer changes them.', 'Stop', function () {
          api('web', {action: 'tls_forget', target: target}).then(function (x) { toast(x.message, 'good'); loadWeb(); }).catch(oops);
        });
      };
      tools.appendChild(fg);
    }
    card.appendChild(tools);
  }
  return card;
}

/* What root is doing on a node, as a bar (1.0.50): the steps done, and in
   the long one - making DH parameters - the time gone against the time it
   usually takes (never shown as more than 95 % before it is done). */
function certProgress(p, target) {
  var box = el('div', 'cert-prog');
  var total = Number(p.total) || 6, step = Math.max(1, Number(p.step) || 1);
  var gone = Math.max(0, (Number(p.now) || 0) - (Number(p.at) || 0));
  var part = p.expect_s ? Math.min(0.95, gone / Number(p.expect_s)) : 0.5;
  var pct = Math.min(99, Math.round(((step - 1) + part) / total * 100));
  var head = el('div', 'cert-prog-h');
  head.appendChild(el('span', '', p.words || 'working'));
  head.appendChild(noI18n(el('b', '', pct + ' %')));
  box.appendChild(head);
  var bar = el('div', 'cert-prog-bar');
  var fill = el('span', '');
  fill.style.width = pct + '%';
  bar.appendChild(fill);
  box.appendChild(bar);
  var mm = function (sec) { sec = Math.round(sec); return Math.floor(sec / 60) + ':' + ('0' + (sec % 60)).slice(-2); };
  box.appendChild(el('div', 'cert-prog-s', p.expect_s
    ? 'on ' + target + ' - ' + mm(gone) + ' so far, usually about ' + Math.round(p.expect_s / 60 || 1) + ' min'
    : 'on ' + target + ' - step ' + step + ' of ' + total));
  return box;
}

/* Files read in the browser: PEM as text, a PFX as base64. */
function readCertFiles(files) {
  return Promise.all(Array.prototype.map.call(files, function (f) {
    return new Promise(function (ok, bad) {
      if (f.size > 200000) { bad(new Error(f.name + ' is far bigger than any certificate file')); return; }
      var r = new FileReader();
      r.onload = function () {
        var bytesArr = new Uint8Array(r.result);
        var head = String.fromCharCode.apply(null, bytesArr.slice(0, Math.min(bytesArr.length, 4096)));
        if (/-----BEGIN /.test(head) || /-----BEGIN /.test(new TextDecoder().decode(bytesArr))) {
          ok({name: f.name, pem: new TextDecoder().decode(bytesArr)});
        } else {
          var bin = '';
          for (var i = 0; i < bytesArr.length; i++) bin += String.fromCharCode(bytesArr[i]);
          ok({name: f.name, pfx: btoa(bin)});
        }
      };
      r.onerror = function () { bad(new Error(f.name + ' could not be read')); };
      r.readAsArrayBuffer(f);
    });
  }));
}

var CERT_PASTE_HINT = '-----BEGIN CERTIFICATE-----\n' +
  '1. the certificate of this name (the server\'s own)\n' +
  '-----END CERTIFICATE-----\n' +
  '-----BEGIN CERTIFICATE-----\n' +
  '2. the intermediate certificate(s), if there are any - one block each\n' +
  '-----END CERTIFICATE-----\n' +
  '-----BEGIN CERTIFICATE-----\n' +
  '3. the root certificate (optional)\n' +
  '-----END CERTIFICATE-----\n' +
  '-----BEGIN PRIVATE KEY-----\n' +
  '4. its private key (not needed when the request was made here)\n' +
  '-----END PRIVATE KEY-----\n\n' +
  'Any order is taken: they are sorted by themselves.';
function certUpload(target, prof) {
  var got = [];
  modal('A certificate for ' + webTargetWords(target), function (body) {
    body.appendChild(el('p', 'note', 'PEM files - the certificate, its key, the chain, the root, in any order or all in one - or one PFX / PKCS#12 file. ' +
      (prof && prof.pending ? 'A request waits here: the certificate the authority sent back is enough, its key is here.' : 'The key has to come with it.')));
    var drop = el('div', 'drop');
    var inp = el('input'); inp.type = 'file'; inp.multiple = true; inp.hidden = true;
    inp.accept = '.pem,.crt,.cer,.key,.pfx,.p12,.chain,.ca,.txt';
    var says = el('span', '', 'Drop the files here, or press to choose them');
    drop.appendChild(inp); drop.appendChild(says);
    var list = el('div', 'cert-files');
    function take(files) {
      readCertFiles(files).then(function (r) {
        got = got.concat(r);
        clear(list);
        got.forEach(function (x) { list.appendChild(noI18n(el('span', 'cchip', x.name + (x.pfx ? ' (PFX)' : ' (PEM)')))); });
        says.textContent = 'Read: ' + got.length + ' file(s). More can be added.';
      }).catch(oops);
    }
    drop.onclick = function () { inp.click(); };
    inp.onchange = function () { take(inp.files); inp.value = ''; };
    drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', function () { drop.classList.remove('over'); });
    drop.addEventListener('drop', function (e) { e.preventDefault(); drop.classList.remove('over'); take(e.dataTransfer.files); });
    body.appendChild(drop);
    body.appendChild(list);
    var paste = el('textarea', 'mono cert-paste');
    paste.id = 'cu-paste';
    paste.rows = 16;
    /* The usual order shown in the box itself (1.0.50); any order is taken. */
    paste.placeholder = CERT_PASTE_HINT;
    paste.spellcheck = false;
    body.appendChild(formField('Or paste PEM here', paste));
    var pw = secretBox('', 'only for a PFX or a key with a passphrase', 'mono');
    pw.id = 'cu-pw';
    body.appendChild(formField('Password', pw, 'Used here to open it, and not kept.'));
    body.appendChild(el('div', 'said', '')).id = 'cu-said';
  }, [{words: 'Cancel', close: true},
      {words: 'Put it in', cls: 'primary', icon: 'save', go: function (b) {
        var pem = got.filter(function (x) { return x.pem; }).map(function (x) { return x.pem; }).join('\n') + '\n' + ($('cu-paste').value || '');
        var pfx = got.filter(function (x) { return x.pfx; });
        if (pfx.length > 1) { toast('one PFX / PKCS#12 file at a time', 'bad'); return; }
        if (!pfx.length && !/-----BEGIN /.test(pem)) { toast('choose the files first, or paste the PEM', 'bad'); return; }
        busy(b, true);
        api('web', {action: 'tls_upload', target: target, cert: pem, pfx: pfx.length ? pfx[0].pfx : '',
                    password: ($('cu-pw') || {}).value || ''}).then(function (x) {
          toast(x.message, 'good'); closeModal(); loadWeb();
        }).catch(function (e) { $('cu-said').className = 'said bad'; $('cu-said').textContent = e.message; }).then(function () { busy(b, false); });
      }}], 'medium');
}

function certNamesDefault(target, d) {
  if (target === 'vip') return d.vip.fqdn || '';
  var n = (d.nodes || []).filter(function (x) { return x.name === target; })[0];
  return n && /\./.test(n.host || '') ? n.host : '';
}
function certSubjectFields(body, target, d, withDays) {
  var g = el('div', 'formgrid');
  var cn = textBox(certNamesDefault(target, d), 'otp.example.cz', 'mono'); cn.id = 'cs-cn';
  var names = textBox('', 'otp1.example.cz, 192.0.2.11', 'mono'); names.id = 'cs-names';
  var kind = selectBox([['rsa2048', 'RSA 2048'], ['rsa3072', 'RSA 3072'], ['rsa4096', 'RSA 4096'], ['ec', 'EC P-256']], 'rsa2048'); kind.id = 'cs-kind';
  g.appendChild(formField('The name (CN)', cn, 'What people type in the browser.'));
  g.appendChild(formField('Other names', names, 'More names or addresses it is good for, by commas.'));
  g.appendChild(formField('The key', kind));
  var org = textBox('', 'Krajský úřad'); org.id = 'cs-org';
  g.appendChild(formField('Organisation', org));
  if (withDays) {
    var days = selectBox([['365', '1 year'], ['825', '27 months'], ['1825', '5 years'], ['3650', '10 years']], '825'); days.id = 'cs-days';
    g.appendChild(formField('Valid for', days));
  } else {
    var unit = textBox('', 'IT'); unit.id = 'cs-unit';
    var city = textBox('', 'Olomouc'); city.id = 'cs-city';
    var country = textBox('CZ', 'CZ'); country.id = 'cs-country'; country.maxLength = 2;
    g.appendChild(formField('Unit', unit));
    g.appendChild(formField('City', city));
    g.appendChild(formField('Country', country));
  }
  body.appendChild(g);
}
function certSubjectValues() {
  var v = function (id) { return ($(id) || {}).value || ''; };
  return {cn: v('cs-cn').trim(), names: v('cs-names'), kind: v('cs-kind'), org: v('cs-org'),
          unit: v('cs-unit'), city: v('cs-city'), country: v('cs-country'), days: v('cs-days')};
}

function certRequest(target, prof) {
  if (prof && prof.pending && prof.csr) { showCsr(target, prof.csr, prof); return; }
  modal('A certificate request for ' + webTargetWords(target), function (body) {
    body.appendChild(el('p', 'note', 'A new key is made here and stays here; the request (CSR) goes to your certificate authority. Upload what it sends back - the certificate alone is enough.'));
    certSubjectFields(body, target, WEB.last || {vip: {}}, false);
  }, [{words: 'Cancel', close: true},
      {words: 'Make the request', cls: 'primary', icon: 'list', go: function (b) {
        busy(b, true);
        api('web', Object.assign({action: 'tls_csr', target: target}, certSubjectValues())).then(function (x) {
          closeModal(); loadWeb(); showCsr(target, x.csr, x.tls);
        }).catch(oops).then(function () { busy(b, false); });
      }}], 'medium');
}
function showCsr(target, csr, prof) {
  modal('The request for ' + webTargetWords(target), function (body) {
    body.appendChild(el('p', 'note', 'Give this to your certificate authority. The key waits here; once the certificate comes back, upload it.'));
    var pre = noI18n(el('pre', 'mono cert-csr', csr));
    copyOnClick(pre, csr, 'the request was copied');
    body.appendChild(pre);
  }, [{words: 'Drop the request', icon: 'trash', go: function () {
        confirmThen('Drop the request', 'Its waiting key goes too; a certificate made for it can then not be used.', 'Drop it', function () {
          api('web', {action: 'tls_csr_drop', target: target}).then(function (x) { toast(x.message, 'good'); loadWeb(); }).catch(oops);
        }, true);
      }},
      {words: 'Download .csr', icon: 'download', go: function () { saveFile((target === 'vip' ? 'web-address' : target) + '.csr', csr); }},
      {spacer: true},
      {words: 'Upload the certificate…', cls: 'primary', icon: 'upload', go: function () { closeModal(); certUpload(target, {pending: true}); }},
      {words: 'Close', close: true}], 'medium');
}

function certSelf(target, d) {
  modal('A self-signed certificate for ' + webTargetWords(target), function (body) {
    body.appendChild(el('p', 'note warn', 'Browsers warn about a self-signed certificate until it is trusted by hand. Good for a test, or until the real one comes.'));
    certSubjectFields(body, target, d, true);
  }, [{words: 'Cancel', close: true},
      {words: 'Make it and put it in', cls: 'primary', icon: 'key', go: function (b) {
        busy(b, true);
        api('web', Object.assign({action: 'tls_selfsigned', target: target}, certSubjectValues())).then(function (x) {
          toast(x.message, 'good'); closeModal(); loadWeb();
        }).catch(oops).then(function () { busy(b, false); });
      }}], 'medium');
}

function certPolicy(target, prof, d) {
  prof = prof || {};
  var st = {preset: prof.preset || 'standard',
            protocols: (prof.protocols || ['TLSv1.2', 'TLSv1.3']).slice(),
            ciphers: prof.ciphers || (d.presets.standard || {}).ciphers || '',
            dh: prof.dh || 'none', prefer: !!prof.prefer, hsts: Number(prof.hsts || 0)};
  var PRESETS = [
    ['standard', 'Standard', 'TLS 1.2 + 1.3', 'ECDHE with AES-GCM and ChaCha20. Every browser of the last ten years.', 'recommended'],
    ['intermediate', 'Mozilla intermediate', 'TLS 1.2 + 1.3', 'Adds the DHE ciphers, for old clients. Wants DH parameters.', ''],
    ['modern', 'Mozilla modern', 'TLS 1.3 only', 'The strongest; old systems and some scanners cannot connect.', ''],
    ['custom', 'Custom', 'chosen here', 'The protocols and an OpenSSL cipher list of your own.', '']];
  modal('How ' + webTargetWords(target) + ' speaks TLS', function (body) {
    /* The protocols and ciphers: one tile each. */
    body.appendChild(el('h4', 'tls-h', 'Protocols and ciphers'));
    var tiles = el('div', 'tls-tiles');
    var custom = el('div', 'tls-custom');
    var used = el('details', 'tls-used');
    function paint() {
      Array.prototype.forEach.call(tiles.children, function (t) { t.classList.toggle('on', t.dataset.k === st.preset); });
      custom.hidden = st.preset !== 'custom';
      used.hidden = st.preset === 'custom';
      var p = d.presets[st.preset];
      if (p) {
        clear(used);
        used.appendChild(el('summary', '', 'The ciphers it uses'));
        used.appendChild(noI18n(el('code', 'tls-cipherlist', p.ciphers ? p.ciphers.split(':').join('\n') : 'TLS 1.3 chooses its own: TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256, TLS_AES_128_GCM_SHA256')));
      }
      dhRow.classList.toggle('dim', st.preset === 'modern' || (st.preset === 'standard' && st.dh === 'none'));
    }
    PRESETS.forEach(function (p) {
      var t = el('button', 'tls-tile');
      t.type = 'button';
      t.dataset.k = p[0];
      var top = el('div', 'tls-tile-top');
      top.appendChild(el('b', '', p[1]));
      if (p[4]) top.appendChild(el('span', 'tag ok', p[4]));
      t.appendChild(top);
      t.appendChild(el('div', 'tls-tile-prot', p[2]));
      t.appendChild(el('div', 'tls-tile-s', p[3]));
      t.onclick = function () { st.preset = p[0]; paint(); };
      tiles.appendChild(t);
    });
    body.appendChild(tiles);
    /* Custom: the protocols as switches, the cipher list. */
    var prow = el('div', 'tls-prot');
    ['TLSv1.2', 'TLSv1.3'].forEach(function (v) {
      var b = el('button', 'tls-pill');
      b.type = 'button';
      b.textContent = v.replace('TLSv', 'TLS ');
      noI18n(b);
      var sync = function () { b.classList.toggle('on', st.protocols.indexOf(v) >= 0); };
      b.onclick = function () {
        var i = st.protocols.indexOf(v);
        if (i >= 0 && st.protocols.length > 1) st.protocols.splice(i, 1); else if (i < 0) st.protocols.push(v);
        sync();
      };
      sync();
      prow.appendChild(b);
    });
    custom.appendChild(el('div', 'tls-sub', 'Protocols'));
    custom.appendChild(prow);
    var ciphers = el('textarea', 'mono tls-ciphers');
    ciphers.rows = 4; ciphers.spellcheck = false; ciphers.value = st.ciphers;
    ciphers.oninput = function () { st.ciphers = ciphers.value; };
    custom.appendChild(el('div', 'tls-sub', 'Ciphers for TLS 1.2 (an OpenSSL list; TLS 1.3 chooses its own)'));
    custom.appendChild(ciphers);
    body.appendChild(custom);
    body.appendChild(used);
    /* The rest, row by row. */
    body.appendChild(el('h4', 'tls-h', 'More'));
    var rows = el('div', 'tls-rows');
    var dh = selectBox(Object.keys(d.dh).map(function (k) { return [k, d.dh[k]]; }), st.dh);
    dh.onchange = function () { st.dh = dh.value; paint(); };
    var dhRow = tlsRow('DH parameters', 'Only the DHE ciphers use them (Mozilla intermediate, or your own). An RFC 7919 group is ready at once; made here takes from seconds to minutes.', dh);
    rows.appendChild(dhRow);
    var prefer = switchBox(st.prefer);
    prefer._input.onchange = function () { st.prefer = !!prefer._get(); };
    rows.appendChild(tlsRow('The server chooses the cipher', 'Off is right for these lists: every cipher in them is strong, and the client knows best which is fast for it.', prefer));
    var seg = el('div', 'seg');
    [[0, 'off'], [15768000, '6 months'], [31536000, '1 year'], [63072000, '2 years']].forEach(function (o) {
      var b = el('button', '', o[1]);
      b.type = 'button';
      b.onclick = function () { st.hsts = o[0]; Array.prototype.forEach.call(seg.children, function (x) { x.classList.toggle('on', x === b); }); };
      if (st.hsts === o[0]) b.classList.add('on');
      seg.appendChild(b);
    });
    if (!seg.querySelector('.on')) seg.children[0].classList.add('on');
    rows.appendChild(tlsRow('HSTS', 'A browser that saw it comes back only over HTTPS for that long. Turn it on once HTTPS is surely staying.', seg));
    body.appendChild(rows);
    paint();
  }, [{words: 'Cancel', close: true},
      {words: 'Save', cls: 'primary', icon: 'save', go: function (b) {
        busy(b, true);
        api('web', {action: 'tls_policy', target: target, preset: st.preset, protocols: st.protocols,
                    ciphers: String(st.ciphers || '').trim(), dh: st.dh, prefer: st.prefer ? 1 : 0,
                    hsts: st.hsts}).then(function (x) {
          toast(x.message, 'good'); closeModal(); loadWeb();
        }).catch(oops).then(function () { busy(b, false); });
      }}], 'medium');
}
function tlsRow(words, says, control) {
  var row = el('div', 'arow');
  var t = el('div', 'arow-t');
  t.appendChild(el('div', 'arow-k', words));
  t.appendChild(el('div', 'arow-s', says));
  row.appendChild(t);
  var c = el('div', 'arow-c');
  c.appendChild(control);
  row.appendChild(c);
  return row;
}

function drawWeb(d) {
  WEB.last = d;
  var host = $('web-certs');
  clear(host);
  Object.keys(d.tls).forEach(function (t) {
    if (t === 'vip' && !d.cluster) return;
    host.appendChild(certCard(d, t));
  });
  explainWhatWasDrawn($('pane-web'));
}

/* The web address lives on the High availability pane (1.0.49), kept up to
   date there every five seconds while it is open. */
var VIP_TIMER = null;
function loadVip() {
  if (!$('web-vip')) return;
  api('web').then(function (d) { WEB.last = d; drawVip(d); explainWhatWasDrawn($('ha-vip-card')); }).catch(oops);
  clearInterval(VIP_TIMER);
  VIP_TIMER = setInterval(function () {
    if (PANE !== 'ha' || !$('pane-ha') || $('pane-ha').hidden) { clearInterval(VIP_TIMER); return; }
    if ($('modal') && !$('modal').hidden) return;
    if (document.activeElement && $('web-vip').contains(document.activeElement)) return;
    api('web').then(function (d) { WEB.last = d; drawVip(d); explainWhatWasDrawn($('ha-vip-card')); }).catch(function () {});
  }, 5000);
}
var VIPD = null;
function vipFromServer(v, d) {
  var names = (d.nodes || []).map(function (n) { return n.name; });
  return {address: v.address || '', fqdn: v.fqdn || '', vrid: String(v.vrid || 51),
          ifaces: Object.assign({}, v.ifaces || {}), mode: v.mode === 'stays' ? 'stays' : 'back',
          prefer: v.prefer || v.prefer_now || names[0] || '', on: !!v.on};
}
function vipDirty() {
  pendingSet('vip', {save: vipSave, reset: function () { VIPD = null; loadVip(); }});
}
function vipSave() {
  var dr = VIPD, d = WEB.last || {}, v = d.vip || {};
  if (!dr) return Promise.resolve(true);
  var was = vipFromServer(v, d);
  var steps = [];
  if (dr.address !== was.address || dr.fqdn !== was.fqdn || String(dr.vrid) !== String(was.vrid)
      || JSON.stringify(dr.ifaces) !== JSON.stringify(was.ifaces)) {
    steps.push(function () { return api('web', {action: 'vip_save', address: dr.address, fqdn: dr.fqdn, vrid: Number(dr.vrid || 51), ifaces: dr.ifaces}); });
  }
  if (dr.mode !== was.mode || (dr.mode === 'back' && dr.prefer !== was.prefer)) {
    steps.push(function () { return api('web', {action: 'vip_mode', mode: dr.mode, prefer: dr.prefer}); });
  }
  var ask = Promise.resolve(true);
  if (dr.on !== was.on) {
    if (dr.on) steps.push(function () { return api('web', {action: 'vip_on'}); });
    else {
      ask = askThen('Turn the web address off', 'keepalived stops on both nodes and the address is on neither. The nodes keep answering on their own addresses, and a load balancer of your own works as before.', 'Turn it off');
      steps.push(function () { return api('web', {action: 'vip_off'}); });
    }
  }
  return ask.then(function (yes) {
    if (!yes) return false;
    var chain = Promise.resolve();
    var last = null;
    steps.forEach(function (f) { chain = chain.then(f).then(function (x) { last = x; }); });
    return chain.then(function () {
      toast((last && last.message) || 'saved', 'good');
      VIPD = null;
      setTimeout(loadVip, 1500);
      return true;
    });
  });
}
function drawVip(d) {
  var host = $('web-vip');
  clear(host);
  if (!d.cluster) {
    host.appendChild(el('p', 'note', 'The web address is for a cluster of two: make this node one of two first (High availability).'));
    return;
  }
  var v = d.vip || {};
  /* What is set waits for the save bar (1.0.56): a draft of it. */
  if (!VIPD) VIPD = vipFromServer(v, d);
  var dr = VIPD;
  /* The big line: where it is now. */
  var top = el('div', 'vip-top');
  var holder = (v.holder || [])[0];
  var big = el('div', 'vip-big ' + (!v.on ? 'off' : (holder ? 'ok' : 'crit')));
  big.appendChild(noI18n(el('div', 'vip-addr', v.address || '–')));
  big.appendChild(el('div', 'vip-where', !v.on ? 'off' : (holder ? 'on ' + holder : 'on no node')));
  if (v.fqdn) big.appendChild(noI18n(el('div', 'vip-fqdn', v.fqdn)));
  top.appendChild(big);
  /* Where it goes back to (1.0.52): a node chosen, or wherever it is. */
  var ret = el('div', 'vip-return');
  ret.appendChild(el('div', 'lb-f-k', 'When the node it left is well again'));
  var stays = dr.mode === 'stays';
  var rseg = el('div', 'seg');
  var names = (d.nodes || []).map(function (n) { return n.name; });
  var prefNow = stays ? '' : (dr.prefer || names[0] || '');
  names.forEach(function (nm) {
    var b = el('button', '', 'always back to ' + nm); b.type = 'button';
    if (!stays && prefNow === nm) b.classList.add('on');
    b.disabled = !d.may;
    b.onclick = function () { dr.mode = 'back'; dr.prefer = nm; vipDirty(); drawVip(d); };
    rseg.appendChild(b);
  });
  var sb = el('button', '', 'it stays where it is'); sb.type = 'button';
  if (stays) sb.classList.add('on');
  sb.disabled = !d.may;
  sb.onclick = function () { dr.mode = 'stays'; vipDirty(); drawVip(d); };
  rseg.appendChild(sb);
  ret.appendChild(rseg);
  ret.appendChild(el('div', 'arow-s', stays
    ? 'No preference: the node that holds it keeps it. It moves only when that node fails (maintenance, an upgrade, unhealthy, gone) or when moved by hand - and stays where it went.'
    : 'Preferred node: the address is on ' + (prefNow || '?') + ' whenever it is healthy, and goes back to it by itself (within a few seconds) after a failover. Moving it by hand makes the other node the preferred one.'));
  top.appendChild(ret);
  if ((v.holder || []).length > 1) top.appendChild(el('p', 'note bad', 'On both nodes at once: they do not hear each other (VRRP between them is blocked, or the network is split). See docs/tls-and-vip.md.'));
  host.appendChild(top);
  /* The nodes. */
  host.appendChild(listTable(['Node', 'Now', 'May hold it', 'Interface', 'Put in place', ''], d.nodes || [], function (n) {
    var w = n.web || {};
    var hl = w.health || {};
    var tr = el('tr');
    var nm = el('td');
    nm.appendChild(noI18n(el('b', '', n.name)));
    if (v.on && v.mode !== 'stays' && (v.prefer_now === n.name)) nm.appendChild(el('span', 'tag dim', 'preferred'));
    tr.appendChild(nm);
    var role = el('td');
    var r = w.vip_here ? 'holds it' : ({MASTER: 'holds it', BACKUP: 'standby', FAULT: 'not well'}[w.role] || (v.on ? '–' : 'off'));
    role.appendChild(el('span', 'tag ' + (w.vip_here ? 'ok' : (w.role === 'FAULT' ? 'crit' : 'dim')), r));
    tr.appendChild(role);
    var h = el('td', 'small');
    if (!v.on) h.appendChild(el('span', 'muted', '–'));
    else if (!n.alive) h.appendChild(el('span', 'bad', 'not answering'));
    else h.appendChild(el('span', hl.ok ? 'good' : 'bad', hl.ok ? 'yes' : 'no - ' + (hl.why || '?')));
    tr.appendChild(h);
    var ifc = el('td');
    var opts = [['', 'the one with ' + (n.address || 'its address')]].concat((w.ifaces || []).filter(function (x) { return x !== 'lo'; }).map(function (x) { return [x, x]; }));
    var sel = selectBox(opts, (dr.ifaces || {})[n.name] || '');
    sel.dataset.node = n.name;
    sel.className = 'vip-iface';
    sel.disabled = !d.may;
    sel.onchange = function () { if (sel.value) dr.ifaces[n.name] = sel.value; else delete dr.ifaces[n.name]; vipDirty(); };
    ifc.appendChild(sel);
    tr.appendChild(ifc);
    var rt = el('td', 'small');
    rt.appendChild(el('span', w.state === 'failed' ? 'bad' : 'muted', w.state ? (w.state === 'done' ? (w.current ? 'in place' : 'being put in…') : 'failed: ' + ((w.said || []).slice(-1)[0] || '')) : '–'));
    tr.appendChild(rt);
    var tools = el('td', 'rowtools');
    if (d.may && v.on && n.alive && !w.vip_here) {
      var mv = cmdButton('Move it here', 'next', 'small');
      mv.onclick = function () {
        confirmThen('Move the web address to ' + n.name, 'Whoever is on the pages through it is answered by ' + n.name + ' within a few seconds; sign-ins stay (they are in the database). ' + (v.mode === 'stays' ? 'It then stays on ' + n.name + '.' : n.name + ' becomes the preferred node: the address goes back to it after a failover.'), 'Move it', function () {
          api('web', {action: 'vip_move', to: n.name}).then(function (x) { toast(x.message, 'good'); setTimeout(loadVip, 4000); }).catch(oops);
        });
      };
      tools.appendChild(mv);
    }
    if (d.may && w.state === 'failed') {
      var again = iconButton('refresh', 'Try again');
      again.onclick = function () { api('web', {action: 'retry', node: n.name}).then(function (x) { toast(x.message, 'good'); }).catch(oops); };
      tools.appendChild(again);
    }
    tr.appendChild(tools);
    return tr;
  }));
  if (!d.may) return;
  /* The settings. */
  var g = el('div', 'formgrid');
  g.style.marginTop = '14px';
  var addr = textBox(dr.address, '192.0.2.10/24', 'mono'); addr.id = 'vip-addr';
  var fqdn = textBox(dr.fqdn, 'otp.example.cz', 'mono'); fqdn.id = 'vip-fqdn';
  var vrid = textBox(dr.vrid, '51', 'mono'); vrid.id = 'vip-vrid'; vrid.inputMode = 'numeric';
  addr.oninput = function () { dr.address = addr.value.trim(); vipDirty(); };
  fqdn.oninput = function () { dr.fqdn = fqdn.value.trim(); vipDirty(); };
  vrid.oninput = function () { dr.vrid = vrid.value.trim(); vipDirty(); };
  g.appendChild(formField('The address, with its prefix', addr, 'A third address in the nodes\' network - not either node\'s.'));
  g.appendChild(formField('Its name', fqdn, 'What people type. With a certificate of its own (Settings → Certificates and TLS), it is answered with that one.'));
  g.appendChild(formField('VRRP id', vrid, '1 to 255; one no other VRRP (keepalived, a router) on that network uses.'));
  host.appendChild(g);
  /* On or off: a switch, kept with the rest until saved. */
  var onrow = el('label', 'fw-master vip-onoff');
  var sw = switchBox(dr.on);
  sw._input.disabled = !dr.address && !dr.on;
  sw._input.onchange = function () { dr.on = !!sw._get(); vipDirty(); drawVip(d); };
  onrow.appendChild(sw);
  onrow.appendChild(el('span', '', dr.on ? 'the web address is on' : 'the web address is off'));
  host.appendChild(onrow);
  host.appendChild(el('p', 'muted small', 'Each node needs keepalived (put in by itself from AlmaLinux\'s own repository), VRRP (IP protocol 112) let in from the other node, and the address in the same network as its own - docs/tls-and-vip.md says what to open in a firewall.'));
}


/* ---- Firewall and access (1.0.52) ---------------------------------------------------
   Who may reach which pages (nginx, page by page) and the machine's firewall:
   otp's own chain OTP-IN, the rules of your own first, then what otp's
   functions need. Every node puts it in through its root helper. */
var FW = {last: null, timer: null, node: null, fam: '4', draft: null, dirty: false};
/* Changes wait for the save bar (1.0.54), as everywhere else in Settings:
   what is shown is the draft, the nodes' state comes live. */
function fwFromServer(d) {
  return JSON.parse(JSON.stringify({on: !!d.conf.on, off: d.conf.off || [], rules: d.conf.rules || [],
                                    access: d.access, access_changed: false}));
}
function fwDirty() {
  fwMarkBar();
  if (FW.last) drawFw(FW.last);
}
function fwMarkBar() {
  if (!FW.dirty) FW.dirty = true;
  pendingSet('fw', {save: fwSave, reset: function () { FW.dirty = false; FW.draft = null; loadFw(); }});
}
function fwSave() {
  if (!FW.draft) return Promise.resolve(true);
  var dr = FW.draft, was = FW.last ? !!FW.last.conf.on : false;
  var go = function () {
    var body = {action: 'save', on: dr.on, off: dr.off, rules: dr.rules};
    if (dr.access_changed) body.access = dr.access;
    return api('firewall', body).then(function (x) {
      toast(x.message, 'good');
      FW.dirty = false; FW.draft = null;
      loadFw();
      return true;
    });
  };
  var ask = Promise.resolve(true);
  if (dr.on && !was) {
    ask = askThen('Let otp look after the firewall',
      'otp puts a chain of its own, OTP-IN, first in INPUT on every node, for IPv4 and IPv6, and keeps it in /etc/sysconfig/iptables and ip6tables. Your own rules stay as they are; OTP-IN only lets in - what it does not let in goes on to them. SSH stays open (a rule of otp\'s, which you can turn off).',
      'Turn it on', false);
  } else if (!dr.on && was) {
    ask = askThen('Take otp\'s rules away', 'The chain OTP-IN and its jump go, on every node; the rest of the firewall stays exactly as it is. ' +
      'Whatever only OTP-IN let in (RADIUS clients, the other node, the pages) is then up to your own rules.', 'Take them away');
  }
  return ask.then(function (yes) { return yes ? go() : false; });
}
function loadFw() {
  api('firewall').then(drawFw).catch(oops);
  clearInterval(FW.timer);
  FW.timer = setInterval(function () {
    if (PANE !== 'fw' || !$('pane-fw') || $('pane-fw').hidden) { clearInterval(FW.timer); return; }
    if ($('modal') && !$('modal').hidden) return;
    if (document.activeElement && document.activeElement.closest && document.activeElement.closest('#fw-access')) return;
    api('firewall').then(drawFw).catch(function () {});
  }, 5000);
}
function fwFam(f) {
  f = Number(f) || 0;
  return noI18n(el('span', 'fam fam' + (f || 'x'), f ? 'IPv' + f : 'IPv4 + IPv6'));
}
function fwWhat(r) {
  var proto = r.proto === 'any' ? 'everything' : (r.proto === 'icmp' && Number(r.family) === 6 ? 'ICMPv6' : r.proto.toUpperCase());
  return proto + (r.port ? ' ' + r.port : '');
}
function fwAction(a) {
  return el('span', 'fwact fwact-' + a, {accept: 'ACCEPT', drop: 'DROP', reject: 'REJECT'}[a] || a);
}
function fwRuleLine(r) {
  var line = el('div', 'fw-rl');
  line.appendChild(fwFam(r.family));
  line.appendChild(noI18n(el('code', 'fw-what', fwWhat(r))));
  line.appendChild(el('span', 'fw-from', r.source ? 'from ' : 'from anywhere'));
  if (r.source) line.lastChild.appendChild(noI18n(el('code', '', r.source)));
  return line;
}

function drawFw(d) {
  FW.last = d;
  if (!FW.dirty || !FW.draft) FW.draft = fwFromServer(d);
  var dr = FW.draft;
  if (FW.dirty) fwMarkBar();
  /* What is drawn is the draft; the auto rules follow what is turned off in it. */
  d = Object.assign({}, d, {conf: Object.assign({}, d.conf, {on: dr.on, off: dr.off, rules: dr.rules}), access: dr.access});
  d.nodes = d.nodes.map(function (n) {
    return Object.assign({}, n, {auto: (n.auto || []).map(function (a) {
      return Object.assign({}, a, {on: a.fixed || dr.off.indexOf(a.key) < 0});
    })});
  });
  if (!FW.node || !d.nodes.some(function (n) { return n.name === FW.node; })) {
    FW.node = (d.nodes.filter(function (n) { return n.me; })[0] || d.nodes[0] || {}).name;
  }
  drawFwAccess(d);
  /* The switch: otp looks after its rules, or leaves the firewall alone. */
  var master = $('fw-master');
  clear(master);
  var sw = switchBox(d.conf.on);
  sw.classList.add('big');
  sw._input.disabled = !d.may;
  sw._input.onchange = function () { FW.draft.on = !!sw._get(); fwDirty(); };
  var lab = el('label', 'fw-master');
  lab.appendChild(sw);
  lab.appendChild(el('span', '', d.conf.on ? 'otp looks after its rules' : 'otp leaves the firewall alone'));
  master.appendChild(lab);
  $('fw-lede').textContent = d.conf.on
    ? 'In INPUT first: the chain OTP-IN - the other node of the cluster, your own rules in their order, then what otp\'s functions need. What it does not let in goes on to the rules that were there before.'
    : 'Off: nothing is changed in the firewall. Turned on, what otp\'s functions need is let in by itself, and the rules of your own with it.';
  /* The nodes, each with what its root says. */
  var nodes = $('fw-nodes');
  clear(nodes);
  d.nodes.forEach(function (n) {
    var b = el('button', 'fw-node' + (n.name === FW.node ? ' on' : ''));
    b.type = 'button';
    var top = el('div', 'fw-node-top');
    top.appendChild(noI18n(el('b', '', n.name)));
    if (n.me) top.appendChild(el('span', 'tag dim', 'this one'));
    b.appendChild(top);
    var be = (n.fw || {}).backend;
    var st = el('div', 'fw-node-s');
    var tone, words;
    if (!n.alive) { tone = 'crit'; words = 'not answering'; }
    else if (be === 'firewalld') { tone = 'warn'; words = 'firewalld - otp leaves it alone'; }
    else if (n.progress) { tone = 'warn'; words = 'putting it in…'; }
    else if (n.state === 'failed' && !n.current) { tone = 'crit'; words = 'failed - see below'; }
    else if (n.waiting || !n.current) { tone = 'warn'; words = 'waiting for root'; }
    else { tone = 'ok'; words = d.conf.on ? 'in place' : 'nothing of otp\'s'; }
    st.appendChild(el('span', 'dot ' + tone));
    st.appendChild(el('span', '', words));
    b.appendChild(st);
    if (n.address) b.appendChild(noI18n(el('div', 'fw-node-a', n.address)));
    b.onclick = function () { FW.node = n.name; drawFw(FW.last); };
    nodes.appendChild(b);
  });
  nodes.hidden = d.nodes.length < 2;
  drawFwBody(d);
  explainWhatWasDrawn($('pane-fw'));
}

function drawFwAccess(d) {
  var host = $('fw-access');
  if (host.contains(document.activeElement)) return;
  clear(host);
  var st = {};
  var rows = el('div', 'fw-acc');
  var me = d.nodes.filter(function (n) { return n.name === FW.node; })[0] || d.nodes[0] || {};
  var inner = (d.inner || {})[me.name] || [];
  [['portal', 'The enrolment pages', 'https://…/ - where people make their token', 'people'],
   ['admin', 'The administration', 'https://…/admin/ - these pages', 'gear'],
   ['health', 'The health check', '/healthz - for a load balancer or monitoring (Zabbix, Nagios…)', 'pulse']].forEach(function (p) {
    var acc = FW.draft.access;
    if (!acc[p[0]]) acc[p[0]] = {any: true, from: []};
    st[p[0]] = acc[p[0]];
    st[p[0]].any = !!st[p[0]].any;
    st[p[0]].from = (st[p[0]].from || []).slice();
    var row = el('div', 'fw-acc-row');
    var t = el('div', 'fw-acc-t');
    t.appendChild(el('b', '', p[1]));
    t.appendChild(el('div', 'arow-s', p[2]));
    row.appendChild(t);
    var c = el('div', 'fw-acc-c');
    var seg = el('div', 'seg');
    var box = el('textarea', 'mono fw-nets');
    box.rows = 2; box.spellcheck = false;
    box.placeholder = '10.0.0.0/8, 192.168.10.0/24, 2001:db8::/32';
    box.value = st[p[0]].from.join(', ');
    box.disabled = !d.may;
    box.oninput = function () {
      st[p[0]].from = box.value.split(/[\s,;]+/).filter(Boolean);
      FW.draft.access_changed = true; FW.dirty = true; fwMarkBar();
    };
    [[true, 'Everybody'], [false, 'Only from']].forEach(function (o) {
      var b = el('button', '', o[1]);
      b.type = 'button';
      b.disabled = !d.may;
      b.onclick = function () {
        st[p[0]].any = o[0];
        Array.prototype.forEach.call(seg.children, function (x) { x.classList.toggle('on', x === b); });
        box.hidden = o[0];
        FW.draft.access_changed = true; FW.dirty = true; fwMarkBar();
      };
      if (st[p[0]].any === o[0]) b.classList.add('on');
      seg.appendChild(b);
    });
    box.hidden = st[p[0]].any;
    c.appendChild(seg);
    c.appendChild(box);
    row.appendChild(c);
    rows.appendChild(row);
  });
  host.appendChild(rows);
  var foot = el('div', 'fw-acc-foot');
  var always = el('div', 'fw-always');
  always.appendChild(el('span', 'arow-s', 'Always let in:'));
  ['127.0.0.1', '::1'].concat(inner.filter(function (a) { return a !== '127.0.0.1' && a !== '::1'; })).forEach(function (a) { always.appendChild(noI18n(el('code', 'cchip', a))); });
  foot.appendChild(always);
  if (d.access.from_nginx && !FW.draft.access_changed) foot.appendChild(el('span', 'tag dim', 'as install.sh wrote it - not set here yet'));
  host.appendChild(foot);
}

function drawFwBody(d) {
  var body = $('fw-body');
  clear(body);
  var n = d.nodes.filter(function (x) { return x.name === FW.node; })[0] || {};
  var fw = n.fw || {};
  if (fw.backend === 'firewalld') {
    body.appendChild(el('p', 'note warn', 'firewalld looks after the firewall of ' + n.name + ': otp leaves it to it. ' +
      'To manage it here: dnf install iptables-services; systemctl disable --now firewalld; systemctl enable --now iptables ip6tables. ' +
      'What firewalld must let in is in docs/tls-and-vip.md.'));
  } else if (fw.backend === '' && n.state) {
    body.appendChild(el('p', 'note warn', 'There is no iptables on ' + n.name + '.'));
  }
  if (n.progress) body.appendChild(certProgress(n.progress, n.name));
  if (n.state === 'failed' && (n.said || []).length) {
    var bad = el('div', 'note bad');
    bad.appendChild(el('b', '', 'Root on ' + n.name + ' did not put it in: '));
    bad.appendChild(noI18n(el('span', '', n.said[n.said.length - 1])));
    if (d.may) {
      var again = cmdButton('Try again', 'refresh', 'small');
      again.onclick = function () { api('web', {action: 'retry', node: n.name}).then(function (x) { toast(x.message, 'good'); }).catch(oops); };
      bad.appendChild(again);
    }
    body.appendChild(bad);
  }
  /* How a packet goes: one line, so the order is plain. */
  var flow = el('div', 'fw-flow' + (d.conf.on ? '' : ' off'));
  [['INPUT', ''], ['OTP-IN: the other node', 'auto'], ['your rules', 'mine'], ['what otp needs', 'auto'], ['the rest of INPUT', 'rest']].forEach(function (s, i) {
    if (i) flow.appendChild(el('span', 'fw-arrow', '→'));
    flow.appendChild(el('span', 'fw-step ' + s[1], s[0]));
  });
  body.appendChild(flow);

  /* Your own rules. */
  var h1 = el('div', 'fw-h');
  h1.appendChild(el('h3', '', 'Rules of your own'));
  if (d.may) {
    var add = cmdButton('Add a rule', 'add', 'small primary');
    add.onclick = function () { fwRuleEdit(d, null); };
    h1.appendChild(add);
  }
  body.appendChild(h1);
  body.appendChild(el('p', 'note', 'Looked at in this order, right after the other node of the cluster (which nothing can shut out): a DROP or REJECT here wins over what otp lets in below. For all nodes, or for one.'));
  var mine = (d.conf.rules || []);
  body.appendChild(listTable(['', 'Action', 'IP', 'What', 'From', 'Node', 'Note', ''], mine, function (r, i) {
    var tr = el('tr', r.disabled ? 'dim' : '');
    tr.appendChild(el('td', 'num muted', String(i + 1)));
    var a = el('td'); a.appendChild(fwAction(r.action)); tr.appendChild(a);
    var f = el('td'); f.appendChild(fwFam(r.family)); tr.appendChild(f);
    tr.appendChild(noI18n(el('td', 'mono', fwWhat(r))));
    tr.appendChild(r.source ? noI18n(el('td', 'mono', r.source)) : el('td', 'muted', 'anywhere'));
    var sc = el('td'); sc.appendChild(r.scope === 'all' ? el('span', 'tag dim', 'all nodes') : noI18n(el('span', 'tag', r.scope))); tr.appendChild(sc);
    tr.appendChild(noI18n(el('td', 'muted', r.note || '')));
    var tools = el('td', 'acts');
    if (d.may) {
      var up = iconButton('up', 'Earlier'); up.disabled = i === 0;
      up.onclick = function () { fwMove(i, -1); };
      var dn = iconButton('down', 'Later'); dn.disabled = i === mine.length - 1;
      dn.onclick = function () { fwMove(i, 1); };
      var ed = iconButton('edit', 'Change it'); ed.onclick = function () { fwRuleEdit(d, r); };
      var rm = iconButton('trash', 'Take it away');
      rm.onclick = function () { FW.draft.rules.splice(i, 1); fwDirty(); };
      [up, dn, ed, rm].forEach(function (b) { tools.appendChild(b); });
    }
    tr.appendChild(tools);
    return tr;
  }, 'plain fw-table|None yet - otp\'s own rules below are enough for what it does'));

  /* What otp lets in by itself, on this node. */
  var h2 = el('div', 'fw-h');
  h2.appendChild(el('h3', '', 'What otp lets in by itself'));
  h2.appendChild(noI18n(el('span', 'tag dim', n.name || '')));
  body.appendChild(h2);
  body.appendChild(el('p', 'note', 'Worked out from what is set up, and changed with it: a RADIUS client added, the cluster made, the web address turned on. What keeps the cluster working cannot be turned off.'));
  var grid = el('div', 'fw-auto');
  (n.auto || []).forEach(function (item) {
    var card = el('div', 'fw-auto-card' + (item.on ? '' : ' off'));
    var top = el('div', 'fw-auto-top');
    var t = el('div', '');
    t.appendChild(el('b', '', item.title));
    t.appendChild(el('div', 'arow-s', item.why));
    top.appendChild(t);
    if (item.fixed) {
      top.appendChild(el('span', 'tag ok', 'always'));
    } else {
      var sw = switchBox(item.on);
      sw._input.disabled = !d.may;
      sw._input.onchange = function () {
        var off = FW.draft.off.filter(function (k) { return k !== item.key; });
        if (!sw._get()) off.push(item.key);
        FW.draft.off = off;
        fwDirty();
      };
      top.appendChild(sw);
    }
    card.appendChild(top);
    var list = el('div', 'fw-auto-rules');
    if (!item.rules.length) list.appendChild(el('span', 'muted', item.key === 'radius' ? 'no RADIUS client yet' : 'nothing'));
    item.rules.slice(0, 12).forEach(function (r) { list.appendChild(fwRuleLine(r)); });
    if (item.rules.length > 12) list.appendChild(el('span', 'muted', '… and ' + (item.rules.length - 12) + ' more'));
    card.appendChild(list);
    grid.appendChild(card);
  });
  body.appendChild(grid);

  /* Everything else: read only. */
  var other = el('details', 'fw-other');
  other.appendChild(el('summary', '', 'The rest of the firewall on ' + (n.name || 'this node') + ' (read only)'));
  var seg = el('div', 'seg');
  var pre = noI18n(el('pre', 'fw-pre'));
  var now = fw.now || {};
  var paint = function () {
    var lines = now[FW.fam] || [];
    pre.textContent = lines.length ? lines.join('\n') : '(nothing - or not known yet)';
    Array.prototype.forEach.call(seg.children, function (x) { x.classList.toggle('on', x.dataset.f === FW.fam); });
  };
  [['4', 'IPv4 (iptables)'], ['6', 'IPv6 (ip6tables)']].forEach(function (o) {
    var b = el('button', '', o[1]); b.type = 'button'; b.dataset.f = o[0];
    b.onclick = function () { FW.fam = o[0]; paint(); };
    seg.appendChild(b);
  });
  other.appendChild(seg);
  other.appendChild(pre);
  other.appendChild(el('p', 'note', 'INPUT as iptables-save shows it, without OTP-IN. These lines are yours: otp never changes them.'));
  paint();
  if (FW.otherOpen) other.open = true;
  other.ontoggle = function () { FW.otherOpen = other.open; };
  body.appendChild(other);
}

function fwMove(i, dir) {
  var list = FW.draft.rules, j = i + dir;
  if (j < 0 || j >= list.length) return;
  var t = list[i]; list[i] = list[j]; list[j] = t;
  fwDirty();
}
function fwRuleEdit(d, r) {
  var st = Object.assign({family: 0, proto: 'tcp', port: '', source: '', action: 'accept', scope: 'all', note: '', disabled: false}, r || {});
  modal(r ? 'Change the rule' : 'A rule of your own', function (body) {
    var rows = el('div', 'tls-rows');
    var segOf = function (opts, key, after) {
      var seg = el('div', 'seg');
      opts.forEach(function (o) {
        var b = el('button', '', o[1]); b.type = 'button';
        b.onclick = function () { st[key] = o[0]; Array.prototype.forEach.call(seg.children, function (x) { x.classList.toggle('on', x === b); }); if (after) after(); };
        if (String(st[key]) === String(o[0])) b.classList.add('on');
        seg.appendChild(b);
      });
      return seg;
    };
    rows.appendChild(tlsRow('Action', 'ACCEPT lets it in; DROP says nothing; REJECT answers that it is closed.',
      segOf([['accept', 'Accept'], ['drop', 'Drop'], ['reject', 'Reject']], 'action')));
    rows.appendChild(tlsRow('IP version', 'Taken from the address when one is given.',
      segOf([[0, 'Both'], [4, 'IPv4'], [6, 'IPv6']], 'family')));
    var port = textBox('', '', 'mono'); port.value = st.port; port.placeholder = '443 · 8000-8100 · 80,443';
    port.oninput = function () { st.port = port.value.trim(); };
    var portRow = tlsRow('Port', 'One, a range, or several by commas. Empty: every port.', port);
    var paintPort = function () { portRow.classList.toggle('dim', ['tcp', 'udp'].indexOf(st.proto) < 0); port.disabled = ['tcp', 'udp'].indexOf(st.proto) < 0; if (port.disabled) { port.value = ''; st.port = ''; } };
    rows.appendChild(tlsRow('Protocol', '', segOf([['tcp', 'TCP'], ['udp', 'UDP'], ['icmp', 'ICMP'], ['vrrp', 'VRRP'], ['any', 'Any']], 'proto', paintPort)));
    rows.appendChild(portRow);
    var src = textBox('', '', 'mono'); src.value = st.source; src.placeholder = '192.0.2.0/24 · 2001:db8::/32 · empty = anywhere';
    src.oninput = function () { st.source = src.value.trim(); };
    rows.appendChild(tlsRow('From', 'An address or a network.', src));
    var scope = selectBox([['all', 'All nodes']].concat(d.nodes.map(function (n) { return [n.name, n.name + (n.me ? ' (this one)' : '')]; })), st.scope);
    scope.onchange = function () { st.scope = scope.value; };
    rows.appendChild(tlsRow('On', 'Every node, or only one.', scope));
    var note = textBox('', ''); note.value = st.note; note.placeholder = 'Zabbix agent'; note.maxLength = 80;
    note.oninput = function () { st.note = note.value; };
    rows.appendChild(tlsRow('Note', 'Shown here and as the comment of the rule in iptables.', note));
    var dis = switchBox(!st.disabled);
    dis._input.onchange = function () { st.disabled = !dis._get(); };
    rows.appendChild(tlsRow('In force', 'Off keeps it here without putting it in.', dis));
    body.appendChild(rows);
    paintPort();
  }, [{words: 'Cancel', close: true},
      {words: r ? 'Change it' : 'Add it', cls: 'primary', icon: 'check', go: function (b) {
        /* Checked by the daemon now, kept in the draft until Save (1.0.54). */
        busy(b, true);
        api('firewall', {action: 'rule_check', rule: st}).then(function (x) {
          var got = Object.assign({}, x.rule, {id: r ? r.id : 'n' + Date.now().toString(36)});
          var list = FW.draft.rules;
          var i = r ? list.findIndex(function (y) { return y.id === r.id; }) : -1;
          if (i >= 0) list[i] = got; else list.push(got);
          closeModal(); fwDirty();
        }).catch(oops).then(function () { busy(b, false); });
      }}], 'medium');
}


/* ---- Replication's errors and the cluster's history (1.0.52) ------------------------ */
function haErrors() {
  var host = el('div', 'ha-err');
  host.appendChild(el('p', 'muted', 'Asking PostgreSQL\'s log…'));
  modal('Replication errors on ' + ((HA && HA.node) || 'this node'), host, [
    {words: 'Close', close: true},
    {words: 'Clear them', icon: 'check', cls: 'danger', admin: true, go: function (b) {
      busy(b, true);
      api('ha', {action: 'errors_clear'}).then(function (x) { toast(x.message, 'good'); closeModal(); loadHa(); }).catch(oops).then(function () { busy(b, false); });
    }}], 'large');
  api('ha', {action: 'errors'}).then(function (d) { drawHaErrors(host, d); }).catch(function (e) { clear(host); host.appendChild(el('p', 'note bad', e.message || String(e))); });
}
function haErrorWhy(text) {
  /* What the commonest ones mean, in a sentence. */
  var t = String(text || '');
  if (/duplicate key value violates unique constraint/i.test(t)) return 'A row that came over already exists here - it was written on both nodes (or this node was rebuilt without its slot cleared). Replication retries it until it gives way; usually a rebuild of this node from the other, or the row taken away, ends it.';
  if (/could not connect to the publisher|connection to server .* failed|could not receive data from WAL stream|terminating logical replication worker due to/i.test(t)) return 'The other node or its PostgreSQL was not reached for a while (a restart, a network cut). Nothing to do when it went on by itself afterwards.';
  if (/replication slot .* does not exist/i.test(t)) return 'The other node\'s slot for this one is gone (it was rebuilt or reinstalled): rebuild this node from the other, or make replication again.';
  if (/replication slot .* is active for PID/i.test(t)) return 'An old connection still held the slot; it goes by itself within a minute.';
  if (/relation .* does not exist|logical replication target relation .* does not exist/i.test(t)) return 'A table the other node sends is not here - the nodes run different versions: upgrade this one, then Read the tables again.';
  if (/publication .* does not exist/i.test(t)) return 'The other node no longer publishes: make replication again from there.';
  if (/out of memory|could not extend file|No space left/i.test(t)) return 'The machine ran out of memory or disk.';
  if (/canceling statement due to statement timeout|lock timeout/i.test(t)) return 'A lock or a timeout - it is retried by itself.';
  return '';
}
function drawHaErrors(host, d) {
  clear(host);
  var subs = d.subs || [];
  var grid = el('div', 'ha-err-sum');
  subs.forEach(function (s) {
    var c = el('div', 'ha-err-card');
    c.appendChild(noI18n(el('b', 'mono', s.name)));
    var line = el('div', 'ha-err-n');
    line.appendChild(el('span', 'big ' + (s.apply_new + s.sync_new ? 'bad' : 'good'), num(s.apply_new + s.sync_new)));
    line.appendChild(el('span', 'muted', s.cleared ? 'since cleared ' + stamp(s.cleared) + (s.cleared_by ? ' by ' + s.cleared_by : '') : 'since PostgreSQL started counting'));
    c.appendChild(line);
    c.appendChild(el('div', 'arow-s', 'applying rows: ' + num(s.apply_new) + ' · first copy of a table: ' + num(s.sync_new) + ' · in all ' + num(s.apply + s.sync)));
    c.appendChild(el('span', 'tag ' + (s.running ? 'ok' : (s.enabled ? 'crit' : 'warn')), s.running ? 'running now' : (s.enabled ? 'not running now' : 'paused')));
    grid.appendChild(c);
  });
  host.appendChild(grid);
  host.appendChild(el('p', 'note', 'An error stops what comes in for a moment; PostgreSQL then tries the same again, every few seconds, until it goes through - so a count that went up and then stopped growing, with replication running now, was a passing thing (a restart, the other node away). One that keeps growing needs a look: what PostgreSQL said is below.'));
  var head = el('div', 'fw-h');
  head.appendChild(el('h3', '', 'What PostgreSQL said'));
  if (d.log_file) head.appendChild(noI18n(el('span', 'tag dim', d.log_file)));
  host.appendChild(head);
  if (!d.fresh) host.appendChild(el('p', 'note warn', 'Root did not answer in time (otp-web.path) - this is what it read last' + (d.log_at ? ', ' + ago(d.log_at) : '') + '.'));
  if (d.log_said) host.appendChild(el('p', 'note warn', d.log_said));
  var list = el('div', 'ha-err-log');
  var all = (d.log || []).slice().reverse();
  var seg = el('div', 'seg');
  [[true, 'Errors and warnings'], [false, 'Everything about replication']].forEach(function (o) {
    var b = el('button', '', o[1]); b.type = 'button';
    if (HA_ERR_ONLY === o[0]) b.classList.add('on');
    b.onclick = function () { HA_ERR_ONLY = o[0]; drawHaErrors(host, d); };
    seg.appendChild(b);
  });
  host.appendChild(seg);
  var rows = all.filter(function (e) { return !HA_ERR_ONLY || e.level !== 'LOG'; });
  if (!rows.length) list.appendChild(el('p', 'muted', !d.log_at ? 'Nothing read yet.' : (HA_ERR_ONLY ? 'No error or warning about replication in the log' : 'Nothing about replication in the log') + (subs[0] && subs[0].cleared ? ' since it was cleared' : '') + (HA_ERR_ONLY && all.length ? ' - ' + all.length + ' ordinary line(s) under Everything.' : '.')));
  rows.forEach(function (e) {
    var item = el('div', 'ha-err-item ' + String(e.level || '').toLowerCase());
    var top = el('div', 'ha-err-top');
    top.appendChild(el('span', 'tag ' + ({ERROR: 'crit', FATAL: 'crit', PANIC: 'crit', WARNING: 'warn'}[e.level] || 'dim'), e.level));
    top.appendChild(el('span', 'muted', e.ts ? stamp(e.ts) : ''));
    item.appendChild(top);
    item.appendChild(noI18n(el('div', 'mono ha-err-text', e.text)));
    (e.more || []).forEach(function (m) { item.appendChild(noI18n(el('div', 'mono ha-err-more', m))); });
    var why = haErrorWhy(e.text + ' ' + (e.more || []).join(' '));
    if (why) item.appendChild(el('div', 'ha-err-why', why));
    list.appendChild(item);
  });
  host.appendChild(list);
  host.appendChild(el('p', 'note', 'Clear them once dealt with: from then on only new ones are counted here and shown red on the page (PostgreSQL\'s own count goes on). On the command line: journalctl -u postgresql-16, or the files in the data folder\'s log/.'));
}

var HA_HIST_FILTER = 'all';
var HA_ERR_ONLY = true;
function haHistory() {
  var host = el('div', 'ha-hist');
  host.appendChild(el('p', 'muted', 'Reading…'));
  modal('What happened to the cluster', host, [
    {words: 'Clear the history', icon: 'forget', cls: 'danger', left: true, admin: true, go: function (b) {
      busy(b, true);
      api('ha', {action: 'history_clear'}).then(function (x) {
        toast(x.message, 'good');
        return api('ha-history&limit=2000').then(function (d) { drawHaHistory(host, d); });
      }).catch(oops).then(function () { busy(b, false); });
    }},
    {words: 'Close', close: true}], 'large');
  api('ha-history&limit=2000').then(function (d) { drawHaHistory(host, d); if ($('ha-hist-time') && $('ha-hist-time')._range().from) $('ha-hist-time').onchange(); }).catch(oops);
}
function drawHaHistory(host, d) {
  clear(host);
  var rows = d.rows || [];
  var KINDS = [['all', 'Everything'], ['vip', 'The web address'], ['node', 'Nodes and health'], ['replication', 'Replication'], ['maintenance', 'Maintenance and upgrades']];
  var bar = el('div', 'ha-hist-bar');
  var tph = el('span'); tph.id = 'ha-hist-time';
  var seg = el('div', 'seg');
  var counts = el('div', 'ha-hist-counts');
  var bad = rows.filter(function (r) { return r.level === 'bad'; }).length;
  var moved = rows.filter(function (r) { return r.what === 'vip' && r.kind === 'ha' && /came to/.test(r.words); }).length;
  counts.appendChild(el('span', 'cchip', moved + ' × the web address moved'));
  counts.appendChild(el('span', 'cchip' + (bad ? ' warn' : ''), bad + ' × trouble'));
  var list = el('div', 'ha-hist-list');
  var paint = function () {
    clear(list);
    var shown = rows.filter(function (r) { return HA_HIST_FILTER === 'all' || r.what === HA_HIST_FILTER; });
    if (!shown.length) list.appendChild(el('p', 'muted', 'Nothing yet - it is written down from version 1.0.52 on, as it happens.'));
    var day = '';
    shown.forEach(function (r) {
      var dd = String(stamp(r.ts)).slice(0, 10);
      if (dd !== day) { day = dd; list.appendChild(noI18n(el('div', 'ha-hist-day', dd))); }
      var it = el('div', 'ha-hist-item ' + (r.level || 'info'));
      it.appendChild(el('span', 'ha-hist-dot'));
      var t = el('div', 'ha-hist-t');
      var top = el('div', 'ha-hist-top');
      top.appendChild(noI18n(el('span', 'mono muted', String(stamp(r.ts)).slice(11))));
      top.appendChild(el('span', 'tag dim', {vip: 'web address', node: 'node', replication: 'replication', maintenance: 'maintenance'}[r.what] || r.what));
      if (r.node) top.appendChild(noI18n(el('span', 'tag', r.node)));
      top.appendChild(el('span', 'muted', r.kind === 'ha' ? 'seen by itself' : 'done by ' + (r.who || 'hand')));
      t.appendChild(top);
      t.appendChild(noI18n(el('div', '', r.words)));
      it.appendChild(t);
      list.appendChild(it);
    });
  };
  KINDS.forEach(function (k) {
    var b = el('button', '', k[1]); b.type = 'button';
    if (k[0] === HA_HIST_FILTER) b.classList.add('on');
    b.onclick = function () { HA_HIST_FILTER = k[0]; Array.prototype.forEach.call(seg.children, function (x) { x.classList.toggle('on', x === b); }); paint(); };
    seg.appendChild(b);
  });
  bar.appendChild(seg);
  bar.appendChild(tph);
  bar.appendChild(counts);
  host.appendChild(bar);
  var p = timePicker('ha-hist-time', {start: {k: 'all'}, all: true});
  p.onchange = function () { api('ha-history' + tpQuery('ha-hist-time') + '&limit=2000').then(function (x) { drawHaHistory(host, x); }).catch(oops); };
  host.appendChild(list);
  paint();
}
if ($('ha-history')) $('ha-history').onclick = haHistory;
if ($('ha-errors')) $('ha-errors').onclick = haErrors;
