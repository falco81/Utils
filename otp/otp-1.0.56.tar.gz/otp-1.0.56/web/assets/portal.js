/* portal.js - the enrolment pages: somebody making their own token.
   Drawn with isemon's pieces (core.js); every answer comes from the daemon. */
'use strict';

function drawLangPick() {
  var host = $('langpick');
  if (!host || !window.OTP_LANGS || window.OTP_LANGS.length < 2) return;
  clear(host);
  window.OTP_LANGS.forEach(function (l) {
    var b = el('button', l.code === window.OTP_LANG ? 'on' : '', l.code.toUpperCase());
    b.type = 'button';
    b.setAttribute('data-no-i18n', '');
    b.title = l.name;
    b.onclick = function () {
      document.cookie = 'otp_lang=' + encodeURIComponent(l.code) + '; path=/; max-age=31536000; '
        + 'samesite=strict' + (location.protocol === 'https:' ? '; secure' : '');
      location.reload();
    };
    host.appendChild(b);
  });
}

/** The help an administrator wrote, as paragraphs, text and nothing else. */
function drawHelp(host, text) {
  if (!host || !text) return;
  clear(host);
  String(text).split(/\n\s*\n/).forEach(function (para) {
    var p = el('p', '');
    para.split('\n').forEach(function (line, i) {
      if (i) p.appendChild(el('br'));
      p.appendChild(document.createTextNode(line));
    });
    host.appendChild(p);
  });
}

function portalDoor() {
  drawLangPick();
  var h = $('help-text');
  if (h) drawHelp(h, h.getAttribute('data-help'));
  var form = $('signin-form'), said = $('in-said'), go = $('in-go');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    said.className = 'said';
    said.textContent = '';
    go.disabled = true;
    var words = go.querySelector('span');
    words.textContent = 'Signing in…';
    api('login', {name: $('in-name').value, password: $('in-pass').value}).then(function () {
      said.className = 'said good';
      said.textContent = 'Welcome.';
      location.reload();
    }).catch(function (e) {
      said.className = 'said bad';
      said.textContent = String(e.message || e);
      go.disabled = false;
      words.textContent = 'Sign in';
      $('in-pass').value = '';
      $('in-pass').focus();
    });
  });
  $('in-name').focus();
}

var ME = null;

function portalApp(me) {
  ME = me;
  drawLangPick();
  dressButtons(document);
  $('signout').onclick = function () {
    api('logout', {}).then(function () { location.reload(); }, function () { location.reload(); });
  };
  drawPortal();
}

function stateCard(kind, title, words) {
  var box = el('div', 'bigstate');
  var mark = el('div', 'mark ' + kind);
  mark.innerHTML = iconMarkup(kind === 'ok' ? 'check' : (kind === 'warn' ? 'clock' : 'token'), 24);
  box.appendChild(mark);
  var w = el('div', 'words');
  w.appendChild(el('b', '', title));
  if (words) w.appendChild(el('span', '', words));
  box.appendChild(w);
  return box;
}

function drawPortal() {
  var host = $('portal');
  clear(host);
  var tok = ME.token;
  var card = el('div', 'card');
  host.appendChild(card);
  if (!tok) {
    card.appendChild(stateCard('crit', 'You have no token yet',
      'A token is the application on your phone that shows a new six-digit code every '
      + 'thirty seconds. The VPN asks for that code.'));
    card.appendChild(howTo());
    var go = cmdButton('Make my token', 'add', 'primary');
    go.onclick = function () { enrol(go); };
    card.appendChild(go);
  } else if (tok.state === 'pending') {
    card.appendChild(stateCard('warn', 'Your token is waiting for a code',
      'It was made, and it is not in use until a code from it is typed here. If you scanned '
      + 'it, type the code your phone shows now. If you did not, make it again.'));
    card.appendChild(confirmForm(false));
    var again = cmdButton('Make it again', 'refresh', '');
    again.onclick = function () {
      api('cancel', {}).then(function (d) { ME = d.me; enrol(again); }).catch(oops);
    };
    var row = el('div', 'btnrow');
    row.style.marginTop = '14px';
    row.appendChild(again);
    card.appendChild(row);
  } else {
    card.appendChild(stateCard(tok.state === 'disabled' ? 'crit' : 'ok',
      tok.state === 'disabled' ? 'Your token is switched off' : 'You have a token',
      tok.state === 'disabled' ? 'The administrator has switched it off; ask them.'
        : 'Made ' + stamp(tok.created) + ' · ' + (tok.last_used ? 'last used ' + stamp(tok.last_used)
        : 'never used') + ' · ' + tok.scratch_left + ' recovery code(s) left'));
    if (tok.pending) {
      card.appendChild(el('p', 'note', 'A new token was made and is waiting for a code from it. '
        + 'Until then the old one goes on working.'));
      card.appendChild(confirmForm(true));
      var keep = cmdButton('Keep the old one', 'undo', '');
      keep.onclick = function () {
        api('cancel', {}).then(function (d) { ME = d.me; drawPortal(); toast('the old token stays', 'good'); }).catch(oops);
      };
      var r2 = el('div', 'btnrow');
      r2.style.marginTop = '14px';
      r2.appendChild(keep);
      card.appendChild(r2);
    } else if (ME.reissue && tok.state !== 'disabled') {
      host.appendChild(reissueCard());
    }
  }
  if (ME.help) {
    var help = el('div', 'card help');
    var inner = el('div');
    drawHelp(inner, ME.help);
    help.appendChild(inner);
    host.appendChild(help);
  }
  explainWhatWasDrawn(host);
}

function howTo() {
  var ol = el('ol', 'howto');
  [['Install an authenticator application on your phone', ' - Google Authenticator, '
    + 'Microsoft Authenticator, or any other that reads a QR code.'],
   ['Press Make my token below', ' - a QR code appears.'],
   ['In the application, add an account and scan the QR code', ' - it starts showing '
    + 'codes at once.'],
   ['Type the code it shows here', ' - and the token is ready for the VPN.']].forEach(function (one) {
    var li = el('li');
    li.appendChild(el('b', '', one[0]));
    li.appendChild(document.createTextNode(one[1]));
    ol.appendChild(li);
  });
  return ol;
}

function enrol(button) {
  busy(button, true);
  api('enroll', {}).then(function (d) {
    showMade(d.made, d.confirm, false);
  }).catch(oops).then(function () { busy(button, false); });
}

/** The new token: the QR code, the key as text, the recovery codes, and the
    box the first code goes into. */
function showMade(made, confirm, replacing) {
  var host = $('portal');
  clear(host);
  var card = el('div', 'card');
  card.appendChild(el('h2', '', replacing ? 'Your new token' : 'Your token'));
  var grid = el('div', 'enrol');
  var left = el('div');
  var qr = el('div', 'qrbox');
  var img = el('img');
  img.src = made.qr;
  img.alt = 'QR code';
  qr.appendChild(img);
  left.appendChild(qr);
  grid.appendChild(left);
  var right = el('div');
  right.appendChild(el('p', 'lede', 'Scan this with the authenticator application on your '
    + 'phone: add an account, then choose to scan a QR code.'));
  right.appendChild(kvTable([['Issuer', made.issuer], ['Account', made.label],
                             ['Codes', made.digits + ' digits, a new one every ' + made.period
                              + ' s']]));
  if (made.secret_spaced) {
    right.appendChild(el('p', 'muted small', 'No camera? Type this key into the application '
      + 'instead (time based):'));
    var key = el('div', 'keytext', made.secret_spaced);
    noI18n(key);
    copyOnClick(key, String(made.secret_spaced || '').replace(/\s+/g, ''), 'the key was copied');
    right.appendChild(key);
  }
  grid.appendChild(right);
  card.appendChild(grid);
  if (made.scratch && made.scratch.length) {
    var sc = el('div');
    sc.style.marginTop = '18px';
    sc.appendChild(el('h3', 'peek-h', 'Recovery codes'));
    sc.appendChild(el('p', 'note', 'Each works once, instead of a code from the phone, for '
      + 'the day the phone is lost or flat. Print them or write them down and keep them '
      + 'somewhere safe: they are not shown again.'));
    var codes = el('div', 'codes');
    made.scratch.forEach(function (c) {
      codes.appendChild(copyOnClick(noI18n(el('span', '', c)), c, 'the recovery code was copied'));
    });
    sc.appendChild(codes);
    var pr = cmdButton('Print them', 'download', 'small noprint');
    pr.onclick = function () { window.print(); };
    sc.appendChild(pr);
    card.appendChild(sc);
  }
  host.appendChild(card);
  if (confirm) {
    var c2 = el('div', 'card noprint');
    c2.appendChild(el('h2', '', 'Type the code your phone shows now'));
    c2.appendChild(el('p', 'note', replacing
      ? 'Until you do, the old token goes on working and this one does not.'
      : 'Until you do, the token is not in use.'));
    c2.appendChild(confirmForm(replacing));
    host.appendChild(c2);
  } else {
    var done = el('div', 'card');
    done.appendChild(stateCard('ok', 'The token is ready', 'Sign in to the VPN with the code '
      + 'your phone shows.'));
    var back = cmdButton('Done', 'check', 'primary');
    back.onclick = function () { location.reload(); };
    done.appendChild(back);
    host.appendChild(done);
  }
  explainWhatWasDrawn(host);
}

function confirmForm(replacing) {
  var f = el('form', 'btnrow');
  var box = textBox('', '000000', 'codein');
  box.inputMode = 'numeric';
  box.maxLength = 8;
  box.autocomplete = 'one-time-code';
  noI18n(box);
  var go = cmdButton(replacing ? 'Use the new token' : 'Confirm', 'check', 'primary');
  go.type = 'submit';
  f.appendChild(box);
  f.appendChild(go);
  var said = el('div', 'said');
  var wrap = el('div');
  wrap.appendChild(f);
  wrap.appendChild(said);
  f.addEventListener('submit', function (e) {
    e.preventDefault();
    busy(go, true);
    said.className = 'said';
    said.textContent = '';
    var typed = box.value.replace(/\s/g, '');
    /* Not digits, or too few: said here, not counted as a wrong code there
       (1.0.36). */
    if (!/^[0-9]{6,8}$/.test(typed)) {
      said.className = 'said bad';
      said.textContent = 'Type the code the application shows: its digits only.';
      busy(go, false);
      box.select();
      return;
    }
    api('confirm', {code: typed}).then(function (d) {
      if (d.good) {
        ME = d.me;
        var host = $('portal');
        clear(host);
        var card = el('div', 'card');
        card.appendChild(stateCard('ok', 'The token is ready', 'Sign in to the VPN with the '
          + 'code your phone shows. Each code works once.'));
        var back = cmdButton('Done', 'check', 'primary');
        back.onclick = function () { drawPortal(); };
        card.appendChild(back);
        host.appendChild(card);
      } else {
        said.className = 'said bad';
        clear(said);
        /* The daemon says "Not a valid token. " and then why: two sentences,
           each translated on its own (1.0.36). */
        var why = String(d.said || '');
        if (why.indexOf('Not a valid token') === 0) {
          why = why.replace(/^Not a valid token\.?\s*/, '');
          said.appendChild(el('div', '', 'That is not the code the token shows now.'));
          said.appendChild(el('div', '', why || 'Wait for the next one and type it.'));
        } else {
          said.textContent = why;
        }
        box.select();
      }
    }).catch(function (e) {
      said.className = 'said bad';
      said.textContent = String(e.message || e);
    }).then(function () { busy(go, false); });
  });
  setTimeout(function () { box.focus(); }, 50);
  return wrap;
}

function reissueCard() {
  var card = el('div', 'card');
  card.appendChild(el('h2', '', 'A new phone, or a new token'));
  card.appendChild(el('p', 'note', 'To replace your token, type your password and a code from '
    + 'the token you have now - or one of your recovery codes. If you have lost both, ask the '
    + 'administrator.'));
  var pw = el('input');
  pw.type = 'password';
  pw.placeholder = 'password';
  pw.autocomplete = 'current-password';
  /* Not .mono: that would leave its hint untranslated. */
  var code = textBox('', 'a code from the old token', '');
  code.style.fontFamily = 'ui-monospace,SFMono-Regular,Menlo,Consolas,monospace';
  code.inputMode = 'numeric';
  var grid = el('div', 'formgrid');
  grid.appendChild(formField('Your password', pw));
  grid.appendChild(formField('A code from the old token', code));
  card.appendChild(grid);
  var go = cmdButton('Make a new token', 'refresh', 'primary');
  go.style.marginTop = '12px';
  var said = el('div', 'said');
  go.onclick = function () {
    busy(go, true);
    said.className = 'said';
    said.textContent = '';
    api('reissue', {password: pw.value, code: code.value.replace(/\s/g, '')}).then(function (d) {
      showMade(d.made, d.confirm, true);
    }).catch(function (e) {
      said.className = 'said bad';
      said.textContent = String(e.message || e);
    }).then(function () { busy(go, false); });
  };
  card.appendChild(go);
  card.appendChild(said);
  return card;
}
