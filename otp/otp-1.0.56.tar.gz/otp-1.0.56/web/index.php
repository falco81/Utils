<?php
/**
 * index.php — the enrolment pages: where people make their own token.
 *
 * Signed in with their directory name and password, somebody sees whether
 * they have a token, makes one (a QR code to scan and the recovery codes to
 * keep), proves it was scanned by typing a code from it, and can replace it
 * with a code from the old one. Nothing is decided here: every answer comes
 * from the otp daemon, and this page holds nothing but a cookie the browser
 * cannot read.
 */
declare(strict_types=1);

define('OTP_COOKIE', 'otp_portal');
define('OTP_COOKIE_PATH', '/');
require_once __DIR__ . '/otp-page.php';
require_once __DIR__ . '/otp-api.php';

if (isset($_GET['api'])) {
    $what = (string) $_GET['api'];
    $post = $_SERVER['REQUEST_METHOD'] === 'POST';
    if ($what === 'lang' && !$post) {
        otp_serve_lang();
    }
    if ($post) {
        otp_guard_post();
    }
    if ($what === 'login' && $post) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $sent = sent_body();
        [$status, $body] = otp_call('/api/portal/login', 'POST', [
            'name'     => (string) ($sent['name'] ?? ''),
            'password' => (string) ($sent['password'] ?? ''),
        ], 30.0);
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' => 'the server is not answering - try again in a while']);
            exit;
        }
        $data = json_decode($body, true);
        if ($status === 200 && is_array($data) && !empty($data['token'])) {
            otp_set_session((string) $data['token']);
            unset($data['token']);
            echo json_encode($data);
            exit;
        }
        http_response_code($status === 200 ? 400 : $status);
        echo json_encode(is_array($data) ? $data : ['ok' => false, 'error' => 'sign-in failed']);
        exit;
    }
    if ($what === 'logout' && $post) {
        otp_call('/api/portal/logout', 'POST', [], 10.0);
        otp_clear_session();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => true]);
        exit;
    }
    $reads = ['me' => '/api/portal/me', 'info' => '/api/portal/info'];
    $writes = ['enroll' => '/api/portal/enroll', 'confirm' => '/api/portal/confirm',
               'reissue' => '/api/portal/reissue', 'cancel' => '/api/portal/cancel'];
    if ($post && isset($writes[$what])) {
        otp_relay($writes[$what], 'POST', sent_body(), 60.0);
        exit;
    }
    if (!$post && isset($reads[$what])) {
        otp_relay($reads[$what], 'GET', null, 30.0);
        exit;
    }
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'unknown endpoint']);
    exit;
}

/* ---- the page ------------------------------------------------------------ */
$info  = otp_get('/api/portal/info', 5.0);
$alive = is_array($info);
$me    = null;
if ($alive && otp_session() !== '') {
    $got = otp_get('/api/portal/me', 8.0);
    $me = is_array($got) ? ($got['me'] ?? null) : null;
}
$lang = otp_lang_pick(null, (string) ($info['lang'] ?? 'cs'));
$load = $lang !== 'en' && otp_lang_pack($lang) !== null;
$title = (string) ($info['title'] ?? '');
// No title of the site's own: a heading of the page's own, in the page's language.
$title_ours = $title === '';
if ($title_ours) {
    $title = 'One-time passwords';
}
?>
<!doctype html>
<html lang="<?= h($lang) ?>" class="app-shell-root<?= $load ? ' i18n-wait' : '' ?>">
<head>
<?php otp_head($title, $lang, $load, $nonce, '/'); ?>
</head>
<body class="app-shell">
<div class="wrap portal">
<?php if (!$me): ?>
<div class="signin">
  <div class="signbox">
    <!-- What this is, in one picture: the phone, the code, the way in. -->
    <svg class="signart" viewBox="0 0 420 188" role="img" aria-labelledby="sa-title">
      <title id="sa-title">A code from the phone is the second key</title>
      <defs>
        <radialGradient id="sa-glow" cx="50%" cy="42%" r="62%">
          <stop offset="0" stop-color="var(--info)" stop-opacity=".30"/>
          <stop offset="1" stop-color="var(--info)" stop-opacity=".04"/>
        </radialGradient>
      </defs>
      <rect class="plate" x=".75" y=".75" width="418.5" height="186.5" rx="14"/>
      <text class="lbl" x="70" y="32" text-anchor="middle">THE PHONE</text>
      <rect x="44" y="44" width="52" height="96" rx="9" fill="none" stroke="var(--tx-mut)" stroke-width="2"/>
      <rect x="51" y="58" width="38" height="64" rx="3" fill="var(--panel2)"/>
      <circle cx="70" cy="131" r="3" fill="var(--tx-mut)"/>
      <text x="70" y="94" text-anchor="middle" font-size="9.5" font-weight="700" fill="var(--ok)"
            font-family="ui-monospace,Menlo,monospace">482 913</text>
      <rect x="55" y="101" width="30" height="3" rx="1.5" fill="var(--info)" opacity=".7"/>
      <path class="flow" d="M112 92 H158"/>
      <circle class="spark dot" r="2.6" cx="0" cy="0"/>
      <circle class="spark dot dot2" r="2.6" cx="0" cy="0"/>
      <circle class="spark dot dot3" r="2.6" cx="0" cy="0"/>
      <text class="lbl" x="210" y="32" text-anchor="middle">CHECKED</text>
      <path class="halo" d="M210 40 l52 18 v38c0 30-21 50-52 60c-31-10-52-30-52-60V58z"
            fill="var(--info)" opacity=".35"/>
      <path class="shield" d="M210 44 l48 17 v35c0 28-19 46-48 55c-29-9-48-27-48-55V61z"/>
      <rect x="191" y="92" width="38" height="28" rx="5" fill="none" stroke="var(--ok)" stroke-width="3"/>
      <path d="M198 92 v-7a12 12 0 0 1 24 0 v7" fill="none" stroke="var(--ok)" stroke-width="3"/>
      <text class="lbl" x="350" y="32" text-anchor="middle">THE VPN</text>
      <path class="through" d="M264 100 h66 m-7-6 l7 6 -7 6" stroke-linecap="round" stroke-linejoin="round"/>
      <rect class="brick" x="336" y="70" width="44" height="60" rx="6"/>
      <text class="lbl" x="210" y="172" text-anchor="middle">PASSWORD · CODE · IN</text>
    </svg>
    <div class="card">
      <h1<?= $title_ours ? '' : ' data-no-i18n' ?>><?= h($title) ?></h1>
      <p class="lede">Sign in to make the token for your phone, or to replace it.</p>
      <?php if (!$alive): ?>
        <div class="offline">The server is not answering just now. Try again in a while, or tell
          the administrator.</div>
      <?php elseif (empty($info['on'])): ?>
        <div class="offline">Making a token here is switched off. Ask the administrator.</div>
      <?php endif; ?>
      <form id="signin-form" autocomplete="on">
        <input type="text" id="in-name" name="username" placeholder="name" autocomplete="username"
               autocapitalize="none" spellcheck="false" required>
        <input type="password" id="in-pass" name="password" placeholder="password"
               autocomplete="current-password" required>
        <?php if (!empty($info['hint'])): ?>
          <p class="muted small" style="margin:-4px 0 10px">Your name is written as <b class="mono" data-no-i18n><?= h($info['hint']) ?></b></p>
        <?php endif; ?>
        <button class="btn primary cmd" type="submit" id="in-go"><svg
          viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor"
          stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"
          ><path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/><path d="M14 12h7"/><path
          d="M18 9l3 3-3 3"/></svg><span>Sign in</span></button>
        <div class="said" id="in-said"></div>
      </form>
      <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center">
        <span class="muted small">otp <?= h(OTP_VERSION) ?> · <a class="muted" href="/admin/">Administration</a></span>
        <span class="langpick" id="langpick"></span>
      </div>
    </div>
    <?php if (!empty($info['help'])): ?>
    <div class="card help" id="help-card"><div id="help-text" data-help="<?= h($info['help']) ?>"></div></div>
    <?php endif; ?>
  </div>
</div>
<script nonce="<?= h($nonce) ?>" src="/assets/core.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>" src="/assets/portal.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>">portalDoor();</script>
<?php else: ?>
<header>
  <h1<?= $title_ours ? '' : ' data-no-i18n' ?>><?= h($title) ?></h1>
  <div class="spacer"></div>
  <div class="btnrow">
    <span class="langpick" id="langpick"></span>
    <span class="btn small mebtn" data-no-i18n><?= h($me['display'] ?: $me['name']) ?></span>
    <button class="btn small" id="signout" data-icon="out">Sign out</button>
  </div>
</header>
<div id="portal"></div>
<div class="modal" id="modal" hidden>
  <div class="box" id="modal-box">
    <div class="head"><h3 id="modal-title">…</h3>
      <button class="xbtn" id="modal-x" data-icon="close" aria-label="Close"></button></div>
    <div class="body" id="modal-body"></div>
    <div class="foot" id="modal-foot"></div>
  </div>
</div>
<div class="toast" id="toast"></div>
<script nonce="<?= h($nonce) ?>">var PORTAL_ME = <?= json_encode($me, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;</script>
<script nonce="<?= h($nonce) ?>" src="/assets/core.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>" src="/assets/portal.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>">portalApp(PORTAL_ME);</script>
<?php endif; ?>
</div>
</body>
</html>
