# otp — what changed

Every change is a new version: the number is in `otp.py` (`otp --version`),
on the pages (bottom of the enrolment page, Settings → About), in the name of
the folder and of the archive.

## 1.0.56 — 23 October 2026

- Every card of Settings saves through the bar at the bottom, as the
  settings themselves do - checked card by card:
  - High availability → the web address: its address, name, VRRP id, each
    node's interface, where it goes back to, and on/off (now a switch) are a
    draft until **Save the changes**; **Put them back** throws it away.
    Turning it off asks when saved (twice). *Move it here* stays a button:
    it is something done now, not a setting.
  - Active Directory and Mail → the certificate authority: pasted or read
    from a file, it is added on Save the changes (no Add it button).
  - The firewall (1.0.54) goes through the same: one bar for everything
    changed on the page, saved one after the other, stopping at the first
    that is refused.
  Lists edited in a window of their own (clients, realms, directories,
  accounts, a rule) and actions (backups, upgrades, replication) are as
  they were.
- The cluster's History can be cleared (asked twice): what the nodes wrote
  down by themselves is deleted; what was done by hand stays in Events and is
  no longer shown in the History.

## 1.0.55 — 23 October 2026

- The web address showed "holds it" on both nodes, with "On both nodes at
  once: they do not hear each other", though only one held it. Whether a
  node holds the address was asked by binding to it, and since 1.0.51 the
  web address turns net.ipv4.ip_nonlocal_bind on (so nginx can listen on
  it) - with that, the bind succeeds anywhere. It is now read from the
  kernel's own list of the machine's addresses (/proc/net/fib_trie,
  /proc/net/if_inet6). The cluster's History no longer says the address
  came to a node that never had it, and "it stays where it is" follows the
  node that really has it.

## 1.0.54 — 23 October 2026

- Firewall and access waits for the save bar, as the rest of Settings does:
  who may reach the pages, otp's firewall on or off, its rules turned on or
  off, the rules of your own (added, changed, moved, taken away) are a draft
  until **Save the changes**, and **Put them back** throws the draft away.
  A rule is checked by the daemon as soon as it is added or changed. Turning
  otp's firewall on or off still asks first when saved (off asks twice).
  One event says everything that was saved.

## 1.0.53 — 23 October 2026

- A time picker everywhere a list has a time window, as in isemon: the
  Overview (the chart and everything under it), the Log, Enrolment, Events
  (new there - all time by default) and the cluster's History.
  - Quick ranges: the last 15 minutes, hour, 6 and 24 hours, 3 days, week,
    month, 3 months, year (and all time where it makes sense).
  - By the calendar: today, yesterday, this week, last week, this month,
    last month.
  - The last N minutes, hours, days or weeks, typed in.
  - From - to by date and time (to empty: up to now).
  - ‹ and › move the window back and forth by its own length.
  - Each list remembers its window in the browser.
- The Overview's names, reasons, clients and places open the Log on the
  same window as the Overview.
- The API takes the window as `from` and `to` (seconds since 1970) on
  /api/events, /api/enrolment and /api/ha/history, and `since`/`until` on
  /api/dashboard and /api/activity.

## 1.0.52 — 23 October 2026

- Settings → Firewall and access, new:
  - **Who may reach the pages** - the enrolment pages, the administration and
    the health check (/healthz) each for everybody or only from the networks
    given (IPv4 and IPv6). nginx says it page by page (the allow lists of
    otp.conf, the web address's server with them); the other node, the web
    address and the machine itself are always let in.
  - **The firewall** (iptables and ip6tables): turned on, otp keeps a chain
    of its own, OTP-IN, first in INPUT on every node, and in
    /etc/sysconfig/iptables and ip6tables between marks of its own, so it is
    there after a reboot (the file is checked with iptables-restore --test
    before it is written; the rest of it, comments included, is left as it
    was). Turned off, the chain and its jump go and nothing else changes.
  - What otp's functions need is let in by itself and changes with them:
    HTTP/HTTPS (to the networks of the page lists), RADIUS only from the
    RADIUS clients set up, SSH, ICMP/ICMPv6, DHCPv6, and inside the cluster
    always the other node (PostgreSQL replication, its pages) and VRRP once
    the web address is on. The optional ones can be turned off one by one.
  - Rules of your own: accept, drop or reject; TCP, UDP, ICMP, VRRP or any;
    a port, a range or several; from an address or a network; IPv4, IPv6 or
    both; for all nodes or one; in an order of your own, looked at right
    after the other node of the cluster (which nothing can shut out) and
    before the rest of otp's.
  - Each node's state (in place, waiting, failed with root's words, with
    Try again) and the rest of its firewall, read only, IPv4 and IPv6.
  - firewalld running: otp leaves the firewall to it and says what to do.
- docs/firewall.md: the same, and how to do it by hand.
- Settings → High availability → The load balancer: a guide for each kind,
  folded until opened - HAProxy, nginx (with RADIUS over UDP), Apache, F5
  BIG-IP, Citrix NetScaler, keepalived + LVS, Cisco ASA, FortiGate, and how
  to check it. Filled in with this cluster's real node names, addresses,
  RADIUS ports and name, marked in colour, and with what is typed in above
  them (the balancer's address, the name, TLS ended or passed through, the
  health check, the shared secret - which only goes into the text); each
  block has Copy. Whether the nodes already trust the balancer's
  X-Forwarded-For is said, with the command when they do not.
- Replication's errors: the count in the table is a button - what PostgreSQL
  said about it, from its own log (root reads only the lines about logical
  replication), each with a sentence on what it usually means and what to
  do; errors and warnings or everything about replication. **Clear them**
  counts from then on (PostgreSQL's own count goes on).
- **History** (High availability, top): what happened to the cluster, day by
  day - the web address coming and going, a node's health, a node stopping
  and answering again, maintenance, replication paused, stopped, running
  again, new errors, a slot about to be lost - written by the nodes as they
  see it - and what was done by hand, filtered by kind.
- The web address: **where it goes back to** - always back to a node chosen
  (as before; the default is the first node), or **it stays where it is**:
  after a failover it does not come back by itself, only when the node that
  holds it fails or it is moved by hand. On the command line:
  `otp --vip-return NODE|stay`.
- Anything that destroys something is asked twice: the button in the popup
  turns into "Really? This cannot be taken back" with the button again.
  Switching a token off, throwing a new token or an uploaded package away
  now ask first too.

## 1.0.51 — 23 October 2026

- The web address's own certificate is answered on its IP address too, and
  to a client that sends no name - not only for its name. nginx listens on
  the address on both nodes (net.ipv4.ip_nonlocal_bind), so the node that
  takes the address over answers on it at once.
- DH parameters the node has made for itself serve the web address as well
  when the same are chosen: made once, not twice.
- The certificate cards stand level: each says under its name which
  certificate it is, the badge always top right.
- The web address's card shows, node by node, whether its certificate is in
  place, and how far root is when it is still being put in.

## 1.0.50 — 23 October 2026

- The buttons of a certificate's card are all the same size, two by two;
  *Download* and *Stop managing…* are buttons of the same size as the
  others, not two small icons.
- What root is doing on a node shows as a bar with a percentage on its card:
  the steps done, and while DH parameters are made, the time gone against
  the time it usually takes (2048 bits seconds, 4096 bits up to ten minutes).
- DH parameters are made before nginx's file is read, so an upgrade that
  runs while they are being made is never written over with an older copy
  of the file.
- Nothing in the settings menu or on the buttons is cut short any more: an
  open menu wraps a long name; the certificate buttons are named shorter
  (Upload, Request (CSR), Self-signed, TLS settings, Download, Let go) and wrap if they must.
- The box for pasting PEM is much bigger and shows the usual order in it:
  the certificate, the intermediates, the root, the key (any order is taken).
- The web address's card says what it is: the certificate of the cluster's
  VIP, answered on that address whichever node holds it.

## 1.0.49 — 23 October 2026

- The web address (VIP) is set, watched and moved on *Settings → High
  availability*, beside the nodes and the replication; *Settings →
  Certificates and TLS* keeps the certificates (the web address's own
  among them).
- *How it speaks TLS* made clearer: the four choices as tiles that say what
  each means and who can connect, the ciphers each uses shown on demand,
  the protocols of your own as switches, HSTS as one row of choices.

## 1.0.48 — 23 October 2026

- A node renamed (node_name) carries over, at its next start, everything
  kept under its old name: its own settings, its maintenance, its
  certificate and TLS settings, its place in the web address; the old name
  leaves the list of nodes. A rename made before this version: once
  `otp --ha-renamed OLD` on that node.
- docs/operations.md: how to rename a node, and that *What to call this
  installation* is the cluster's name, not a node's.

## 1.0.47 — 23 October 2026

Certificates and TLS
- *Settings → Certificates and the web address*: a card per node and one for
  the web address - the certificate, who issued it, until when (a bar that
  turns orange three weeks before), its names, key, chain and root, whether
  the chain leads to the root, the TLS settings, and whether it is in place.
- Upload a certificate as PEM files (certificate, key, chain, root - any
  order, or all in one) or as PFX / PKCS#12, with a password or without
  (old PFX files too, and keys with a passphrase); or make the request (CSR)
  here - the key stays here - and upload only what the authority sends
  back; or make a self-signed one. The certificates are sorted by
  themselves and the chain checked against the root.
- TLS per node and for the web address: Standard, Mozilla intermediate,
  Mozilla modern or custom protocols and ciphers; DH parameters (RFC 7919
  groups, or made on the node); the server choosing the cipher; HSTS.
- Root puts it in through a new helper (otp_web.py, otp-web.path): every
  value checked, nginx asked before it is reloaded and every file put back
  when it says no.
- Command line: otp --web-status, --tls-import, --tls-preset, --tls-dh,
  --tls-hsts, --tls-for.

The web address (VIP)
- In a cluster, one more address for the pages, on one node at a time,
  held by keepalived (installed by itself). It leaves a node that goes into
  maintenance, is upgraded or rebuilt, whose own /healthz (nginx, PHP, the
  daemon, the database) fails, whose RADIUS stops listening, or that is gone;
  and returns to the node it is meant to be on once that is well. Moved by
  hand on the pages (*Move it here*) or with otp --vip-move; on and off with
  otp --vip. Its own name and certificate (nginx answers it by SNI). RADIUS
  stays active/active on the nodes' own addresses.
- With it off, a load balancer of your own works as before.
- keepalived's check is put in /usr/libexec/keepalived, where SELinux lets
  keepalived run it.

Health checks
- /healthz?check=radius also says whether RADIUS listens (for a balancer of
  UDP 1812/1813); /healthz?check=all also whether replication runs (for
  monitoring).

The cluster on the command line
- otp --ha-compare: every table counted on both nodes, side by side.
- otp --ha-standalone: leave the cluster and go on alone keeping everything -
  replication and its slots taken away, the other node forgotten,
  config.json a single server's again.
- otp --ha-forget NAME: a node off the list.
- otp --ha-resync stops otp on the node while it is rebuilt (its heartbeat met
  the rows coming over) and makes a copy of what was there first.
- otp --ha-status: errors counted earlier no longer mark a running direction
  as failed.

Documents (docs/)
- operations.md - the runbook: a fresh install, PostgreSQL 16 on AlmaLinux 9,
  moving from SQLite, building the cluster, every-day checks, upgrades,
  OS updates, a node down for a while, a split network, a node lost for good,
  "lost" replication, leaving the cluster, changing an address, copies,
  back to SQLite, the key, a lost password, troubleshooting.
- tls-and-vip.md - certificates, TLS, the web address, and what to open in
  firewalld, iptables and nftables.
- load-balancers.md - HAProxy, nginx (and nginx Plus), Apache, F5 BIG-IP,
  Citrix NetScaler, keepalived/LVS, Cisco ASA, with health checks that look
  at the whole node.

Other
- install.sh keeps its copies of nginx's file in /etc/nginx/otp-backups (the
  last ten), no longer beside it in conf.d.

## 1.0.46 — 23 October 2026

- A click on a recovery code that is still free copies it to the
  clipboard, and so does a click on the key beside the QR code (without
  its spaces) - in the administration and on the enrolment pages. The tile
  flashes green and a message says what was copied.

## 1.0.45 — 23 October 2026

- High availability: every line of the Log (requests and checks of a code),
  of the events and of the enrolment pages says which node wrote it - a
  *Node* column in a cluster, in the details of a request or a check, and
  the field `node:` in the search box (`node:otp2`). Lines written before
  this version have none.
- Test: in a cluster the test can be made on any node that answers (*On
  the node*). It is asked through the database both nodes open, the
  password sealed with the key both have, and answered by that node as if
  asked on its own pages; the answer says where it was made.
- Upgrading a cluster: the new column has to be on a node before the other
  sends it rows that carry it. Upgraded from the pages that is so by itself
  (the other node goes first); by hand, upgrade the node that is not
  answering the pages first - until both are, replication waits and then
  goes on by itself.

## 1.0.44 — 23 October 2026

A review of the whole application for bugs; what it found, put right.

Security
- Enrolment pages: somebody with only the directory password could get a
  second token for the same person by signing in under another spelling
  (DOMAIN\\name, another realm on the same directory, other letters' case).
  The token the person has already is the one the session is about now.
- The sign-in limit per name counts the person, not the spelling: DOMAIN\\ro,
  ro@anything and Ro are one name.
- *Code now* needs "show the key of a token" switched on, as the key itself
  does, and every look is written down by the server whatever the page
  says (once per five minutes per person and token).
- Upgrades from the pages: root's helper works on the upgrade folder through
  one descriptor opened once, so the otp account cannot swap the folder for
  a link between two of root's steps; a FIFO put in a file's place no longer
  holds it up; a package's headers are counted as they are read, not all
  read first. install.sh makes the folders inside /var/lib/otp as the otp
  account (root's install -d followed a link there). Release keys a new
  version no longer ships are no longer trusted.
- MariaDB: names are compared byte for byte, as SQLite and PostgreSQL
  compare them; novák@x.cz and novak@x.cz were one token, and one person's
  token was written over the other's. Existing tables are changed once.
- A wrong code on the confirm page counts toward the lockout, not only the
  short pause.
- The replication password never reaches PostgreSQL's log: the other node's
  database is tried first, and a subscription that would fail is not sent.

RADIUS and the directory
- Proxy-State is sent back in every answer (RFC 2865): behind a RADIUS
  proxy every answer was thrown away.
- Status-Server on the accounting port is answered (RFC 5997).
- An answer too long for a packet (too many reply attributes) is a logged
  refusal instead of no answer at all.
- A directory given as [IPv6]:port works.
- A connection to a domain controller that drops during a sign-in is "could
  not be reached", and the next one is asked - not "wrong password".
- Directories reloaded no longer vanish for a moment under a request.
- Wrong codes are counted in the database itself, so two nodes do not lose
  each other's counts.

The database, upgrades, high availability
- Putting back the oldest kept copy works; the safety copy made first
  rotated that very copy away.
- Putting a copy back keeps this machine's maintenance, heartbeats, upgrades
  and jobs (and, in a cluster, the other node's).
- In a cluster a copy sealed with another key is refused before anything is
  replaced.
- A cancelled upgrade finishes the node that had begun: one that drained
  goes back into service, one that installs is checked.
- A node waits for the other to be alive and in service before it leaves
  for its upgrade - never both out at once.
- A node whose install.sh does not finish in 10 minutes is marked failed,
  not done.
- *Forget the package* removes its pieces from the database (it removed
  none), and a new package removes every older one's.
- Rebuilding a node from the other: nothing of its own is written while the
  rows come over (it answers nothing meanwhile), so the copy no longer stops
  on a duplicate key.
- A daily backup set as 3:30 runs (only 03:30 did).
- The disk speed probe measures a real write.
- install.sh --upgrade: a machine installed without the pages is upgraded
  without them; a failed upgrade starts the daemon again and brings the node
  back into service; it never moves the machine's PHP to Remi by itself; a
  retry keeps the first copy of the nginx configuration. --uninstall waits
  for an upgrade going on and says what it leaves (certificate, firewall).

The pages
- A popup over a popup that opened nothing (Back in service, a failed
  request) froze the page; it cannot now.
- *Code now* stops asking once its window is closed.
- *Make new ones* (recovery codes), *Check it* and *Look a name up* are
  shown only to who may use them.
- Saving a client before its realms were read no longer clears the realms
  it may use.
- A role the server refused is not left showing in Accounts.
- The Test tab names an answer that is neither accept nor reject as it is.
- Directory buttons and long buttons wrap at phone width.
- A few untranslated texts translated.

The API and the command line
- Imports check every realm's directory before saving anything, and what
  was saved is in use even when something after it was refused.
- A field of the wrong kind is a 400 with a reason, not a 500.
- Renaming a token follows the same rule for names as a new token.
- /api/portal/me says nothing once the enrolment pages are switched off.
- otp --set-role needs --role and keeps the last full administrator;
  otp --passwd ends the account's sign-ins; otp --restore takes every kind
  of copy, makes a safety copy and uses the key that came with it; bare
  otp shows the status again; --delete-token removes what was kept beside
  the token; --scratch is written down; --tokens --limit is honoured;
  ordinary mistakes are one line, not a trace.

## 1.0.43 — 23 October 2026

- High availability: on a node that is one of two already, *Making it two*
  no longer warns that PostgreSQL is on this machine (127.0.0.1) - with
  replication each node has its own and the other never opens it. The
  check says so in green, and the steps are folded away behind *Show how
  it was made*.

## 1.0.42 — 23 October 2026

- *Try a code*: the marked answer takes the place of the line under the
  row at the same height, so the token window does not grow and gets no
  scroll bar after a try.

## 1.0.41 — 23 October 2026

- *Code now* keeps its size: the tile is as big with the code shown as
  before it, and the other tiles beside it do not move.
- Shown, a click on *Code now* copies the code (without the space) to the
  clipboard; the tile flashes green and a message says so.
- *Try a code* marks its answer: a green "✓ RIGHT" or a red "✗ WRONG"
  label with the reason, and the code box goes green or red until it is
  typed in again.

## 1.0.40 — 23 October 2026

- The token window has a tile *Code now*: pressed, it shows the code the
  phone shows at this moment, with a ring counting down its seconds, and
  goes on to the next code by itself. A full administrator only; every look
  is written in the events.

## 1.0.39 — 23 October 2026

- The buttons at the end of a row in Tokens, the Log and the other lists are
  a cell of the row like any other, as in Settings: no colour or place of
  their own. A table wider than its card scrolls sideways.

## 1.0.38 — 23 October 2026

**Small things on the pages.**
- The database card's window shows what the database holds as a table: what
  each table is, its name, its rows and its room with a bar, biggest first;
  and the copies with their size, when they were made and whether the key is
  beside them.
- *Open Upgrades* (and every card's button to its settings) opens that very
  page of Settings, not whichever one was open last.

## 1.0.37 — 23 October 2026

**The program is called otp - everywhere.**
- Until now it was installed as "opt". From this version on everything is
  otp: the service `otp.service` (`systemctl status otp`), the command `otp`,
  `/usr/local/lib/otp/otp.py`, `/var/lib/otp`, `/etc/otp/config.json`,
  `/var/log/otp/otp.log`, `/var/www/otp`, the accounts `otp`, `otp-web` and
  `otp-www`, nginx's `/etc/nginx/conf.d/otp.conf`, the php-fpm pool, the
  logrotate and polkit files, the SQLite file `otp.db`, the copies and dumps
  (`otp-…`), the package `otp-X.Y.Z.tar.gz`.
- `install.sh --upgrade` from an opt installation renames all of it once,
  keeping every setting, token, account and log: the accounts are renamed
  (so every file keeps its owner), the folders moved, nginx's file kept with
  its host name and allow lists, the certificate kept.
- The databases too: a PostgreSQL or MariaDB on the same machine has its
  database and account opt renamed otp (pg_hba.conf with them). One on
  another machine keeps its names, written into config.json. Replicated, the
  publication, the subscriptions and the slots become `otp_pub` and
  `otp_from_N` on both nodes without stopping or losing a row - whichever
  node is upgraded first, the second finishes it.
- Copies and dumps made under the old name are still listed and put back.
  Nothing else answers to "opt" any more.

**Upgrades from the pages, one node at a time.**
- *Settings → Upgrades*: send the released `.tar.gz` and press *Upgrade*.
  One server is put in and restarted; a cluster is upgraded node by node -
  each taken out of service, upgraded, checked (its database, RADIUS, the
  replicated tables read again) and brought back before the next begins. A
  failure stops it there with what `install.sh` said; *Stop it* leaves the
  rest as they are. `otp --upgrade-status`, `otp --upgrade-cancel`.
- Nothing is installed by the service itself: root does it, through
  `otp-upgrade.path` and `otp-upgrade.service`, after checking the package
  again from a copy of its own. Every release is now **signed** (`MANIFEST`,
  `MANIFEST.sig`, Ed25519): a package changed or signed by a key the server
  does not know is refused, as is one older than what runs.
- The command line works as it always has. This version has to go in on the
  command line once - that installs the units and the release key.
- docs/upgrades.md: both ways, and the operating system too.

**Maintenance.**
- A node in maintenance answers no RADIUS request and its `/healthz` says 503,
  so the VPN and the load balancer use the other one; its pages go on
  working. *Settings → Upgrades*, the Overview, or `otp --maintenance on|off|status`.
- `install.sh --upgrade` takes the node out of service while it works and
  puts it back once the new version answers.

**A cluster: each node's own settings.**
- The address RADIUS listens on, the API port, the mail HELO name, the isemon
  host name and the debug switches are now kept per node (*Settings → High
  availability → Each node's own settings*); before, one node's address was
  given to the other too. Everything else is the cluster's, as before.

**The Overview.**
- The four cards open what they count, as isemon's do: who was let in, why
  people were refused, the tokens (locked out, used last), isemon.
- Four more: this server (version, uptime, RADIUS, problems), high
  availability (nodes, replication), the database (size, the last copy, the
  key) and maintenance and upgrades - each opening its details.

**Moving between databases.**
- After a move, making a copy or a dump was refused for ever: the copy made
  at the start of the move held the move as "going on", and the new database
  kept showing it. Such notes are no longer carried over, and a job whose
  process has gone is taken as ended.
- After *Set it up*, the steps after it did not find the password it had just
  made ("no password supplied").
- The database's address can no longer be saved with the save bar: saved,
  the next restart opened a database nothing had been carried into. The four
  steps are the only way.
- *Start using it* refuses a database that holds an older copy (left by an
  earlier move): empty it and carry everything across first.

**Smaller.**
- `systemctl status otp` works: the unit has the alias `otp.service`.
- Fact tiles wrap long words and addresses instead of running over their
  border.

## 1.0.36 — 23 October 2026

A second detailed pass over the whole program - the server, the pages, the
enrolment pages, PHP and the installer - and what it found.

**RADIUS.**
- On a server listening on `::`, answers to IPv4 clients go back to the
  address the request came from (`::ffff:a.b.c.d`); they were lost.
- A delayed refusal (*Wait before a refusal*) is waited out by one thread for
  all of them, not in a worker: a flood of wrong codes no longer ties the
  workers up sleeping. A delayed answer is not kept as the answer to a repeat.
- A client's allowed realms may have names with spaces, and follow a realm
  that is renamed or taken away.

**Tokens.**
- A wrong code for a token deleted at that moment no longer writes an empty
  token back under its name; switching off, notes, clock drift and *Forget
  them* refuse a name with no token instead of making one.
- Making a token again, or importing one over it, ends a lockout; an import
  also drops a waiting replacement.
- A confirmed replacement no longer shows the old key's last use.
- A new QR code keeps the token's note.
- A `.totp` file must hold a key of at least 80 bits; a file of rubbish was
  imported as a token. A counter (HOTP) file is refused.
- Export with *Steps of clock drift* 0 writes `WINDOW_SIZE 1`.
- `otp --restore` and a configuration read again seal restored tokens to their
  names; `otp --unlock` says so when there is no such token; `otp --check`
  shows each realm's way of signing in.

**The database and the directory.**
- TLS to MariaDB/MySQL checks the certificate when asked to; the dump and
  restore tools use the same TLS settings. A server address may be IPv6.
- A connection lost in the middle of a restore is not quietly reopened
  half-way through the transaction.
- A directory connection used again no longer fails at once on a deadline
  left over from the last question; every page of a search has its own.
- An unreachable directory is asked about a signed-in administrator again in
  a minute, not on every click.
- An error answered to somebody signed in no longer keeps their session alive.

**The administration pages.**
- *Move to* → *No* goes back to the token window.
- *Try* results are green or red; *Try sign-in* keeps its boxes after a
  failure, so a typo can be put right.
- *Print* prints the popup alone, black on white - not the page under it
  eight times.
- A bar of the overview chart shows that hour from the server: right count,
  and every page of it.
- The group finder of a realm empties after an error, so groups of another
  directory cannot be added.
- The mail test is held back only by unsaved mail settings.
- The buttons at the end of a row stay in sight in a narrow window; on a
  phone the pager no longer covers the rows and the tabs stay on one line.
- Every settings page has an icon of its own.
- Czech: some two hundred more answers, events and errors translated; plurals
  right; "Odebrat … away" and "realm je gone" gone.

**The enrolment pages.**
- A code that is not 6-8 digits is said so before it is sent; the reason a
  code was wrong is translated.
- nginx's own answers (too many attempts, server down) are said in words.
- The page's title, the disabled-token text and the hints are translated;
  the key breaks only between its groups on a phone.

**PHP, the installer, the documents.**
- The php2shell check asks php-fpm itself, not the command-line PHP, and reads
  the changelog whole (a `| grep -q` under pipefail could miss the CVE and
  move a fixed PHP to Remi). On Debian the pool goes to the php-fpm that is
  installed, not to the first folder by name.
- php-fpm is reloaded only when otp's pool or the guard changed - other sites
  on the machine are left alone.
- Installing again keeps the nginx file (`--rewrite-nginx` writes it afresh).
- `--dry-run --import-legacy` changes nothing; a copy that broke off is not
  imported. `--uninstall` also removes the polkit rule.
- `/healthz` says when the pages cannot read the API token; a download after
  signing out goes back to the sign-in.
- High availability: how the balancer must pass the client's address
  (`option forwardfor` or the PROXY protocol); with plain `mode tcp` every
  sign-in limit was shared by everybody.

## 1.0.35 — 23 October 2026

**The offer under a box low on the screen is seen.**
- A box near the bottom of the screen - *Move to* in a token's window -
  opens its list of people upwards, as it was meant to. It was pushed below
  the edge of the screen instead, leaving a sliver nobody could see, so the
  list seemed never to come.

## 1.0.34 — 23 October 2026

**Move to offers people as Make a token does.**
- Typing part of a name in a token's *Move to* offers the people of every
  realm's directory, with their full name, mail and whether they have a
  token - as *Make a token* does. It offered nobody: it asked for the realm
  by what comes after the @, and the directories are asked by the realm's
  name. The same slip hid the people in any box once a whole @domain was
  typed after a name.

## 1.0.33 — 23 October 2026

A security review of the whole program (the RADIUS server and the code
check; the pages, the API and PHP; the database, the directory, mail, high
availability and files), load tests, and what they found.

**Signing in to the administration from the directory.**
- With no group given a role, nobody from the directory gets in. Before,
  anybody in the directory could then read every log, token and account.
- A directory administrator is asked about again every ten minutes: switched
  off there, or out of every group with a role, and every sign-in of theirs
  ends; a role that changed changes. Changing the role groups or the
  directory signs everybody from the directory out.
- A password changed or set ends the other sign-ins of that account.
- An unknown name takes as long to refuse as a known one.

**RADIUS.**
- The order is now realm, directory (the account, in use, its groups), the
  password, and the code last. Somebody without the password can no longer
  guess codes or lock a token out; a code is used up only by a request that
  would be let in. In "password then code" realms one wrong attempt counts
  once (the probes that find where the password ends counted three times and
  paused the person after one typo), and one password costs the directory
  one try.
- A client can be limited to the realms it may use (Clients → Realms it may
  use). Without it the name typed chose the realm - and with it how strictly
  the person was checked: user@wifi at the VPN, password alone.
- A realm written with a dot at the end is the same realm; a name with
  nothing before its @ is refused.
- Lockout: after 10 wrong codes in a row, however slowly, a token takes no
  code for 15 minutes (Settings → The tokens). The short pause alone let a
  patient guesser try thousands of codes a day. *Forget them* ends it.
- A refusal goes back without its reason (Settings → RADIUS → Say why in a
  refusal): the VPN could show strangers whether a name has a token, or that
  the code was right and the password not.
- Message-Authenticator: a client that has sent one must go on sending one;
  one of the wrong length is wrong, not missing; answers carry it first.
- The answer goes out before anything is written down: a slow database
  delays the log, not the person, and no longer leaves a request let in
  without its answer. A refusal's delay waits on a timer, not in a worker.
- Junk from anywhere is counted, not written down a row each, and summed up
  once a minute; unknown addresses at most 30 rows a minute.
- The duplicate cache has a hard limit and no longer rebuilds itself.
- Only digits 0-9 are a code (Arabic-Indic digits left a request unanswered
  and unwritten); recovery codes work also when as long as phone codes.
- A realm's reply may carry only reply attributes.
- Two thread races (the client list, the unknown-address table) are gone.

**Tokens.**
- New recovery codes for somebody else follow the rule for showing a key: a
  full administrator, where showing keys is allowed, written down as a
  warning. A token administrator could get working codes for anybody.
- Confirming a new token is throttled like a sign-in, and done one at a time.
- A replacement with a longer period no longer refuses every code after it.
- Every token's sealed key, recovery codes and waiting replacement are tied
  to its name: copied into another person's row in the database, they no
  longer open. Existing tokens are sealed again at the first start (20 000
  in about 4 seconds), and after a restore.

**The pages and the API.**
- `?api=lo%67in` no longer slips past nginx's count of sign-ins; the count
  in the daemon is taken before the password is checked (thirty at once got
  thirty tries, now five) and also per name.
- Details such as a domain controller's name or a bind DN go only to
  somebody signed in; an error inside goes to the log, not to the page.
- A read-only account no longer sees the last characters of secrets.
- The enrolment pages switched off sign out whoever is on them; a wrong
  password or code when replacing a token no longer signs the page out.
- The link in a token's mail is built from the address the pages were
  reached by, not taken from the page.
- An open page signs out after the idle time even while it refreshes itself.
- Events for throwing away a waiting replacement, a note changed, a sign-in
  ended (whose), and the enrolment page's cancel.
- The first password file of the installer is deleted once that password is
  changed.
- Search-as-you-type for numbers (recovery codes) no longer breaks on
  PostgreSQL.

**The database, mail, the directory.**
- Database name, account and host are checked: a name like
  `--result-file=…` was an option to mariadb-dump; control characters in a
  password could add lines to its option file.
- Database TLS: Settings → The database → Encryption (require, verify-ca,
  verify-full and the authority's file), also for the link to the other node.
- A restore is all or nothing: one that broke off half-way left the tokens
  empty.
- A connection lost is retried only for reads, or where nothing was sent: a
  write retried could have used a code twice, then refused it as used.
- Plain searches treat % and _ as themselves; very deep NOT/brackets refused.
- The key that seals the secrets is read once and kept, made with O_EXCL,
  and never made anew where the database already holds secrets sealed with
  a missing one.
- The directory: one deadline for a whole answer, and an answer that does
  not read is a directory error, not a crash.
- Mail straight to the recipients: answers to its DNS questions only from
  the server asked and for the question asked, within one deadline; an
  answer that does not read fails cleanly. TLS to the recipients' servers can
  be required (Settings → Mail).

**Speed.**
- New indexes: the events by kind, the log by packet and by client, the
  sign-ins by kind (the enrolment tab 38 → 0.7 ms, the kinds offered 98 →
  0.2 ms). The overview's chart is counted by the database (1.3 s for a
  month before). Old rows are deleted 5 000 at a time. A client's last-seen
  time is written once a minute, not on every packet; the last address of a
  token in one statement. The API takes 256 connections waiting at once (20
  pages asking at the same moment lost one).
- Measured on one machine (SQLite, 20 000 tokens, 50 clients, 30 realms):
  RADIUS about 630 sign-ins a second with 50 clients at once, p99 104 ms, no
  answer lost; with 30 % wrong codes 580/s; 1 000 enrolments at 40 at once
  beside 10 000 sign-ins, no error, sign-ins p99 230 ms.

**Import.** A ZIP of .totp files can be dropped on *Bringing tokens over* -
a totpcgi folder zipped, or another otp's export (read in memory, with
limits on size and number; names inside are never used as paths).

**The pages.** *Your account* is wider.

**Known and left as it is, for now.**
- Replicated high availability (two databases) cannot make a code strictly
  one-time across both nodes while they are apart; shared mode (one
  database) can. Wrong codes are also counted per node there.
- A group named by its name alone (VPN_USERS) matches any group of that name
  anywhere under the base: pick groups from the directory (whole DN).
- Two realms both naming tokens without the realm share the tokens of
  people of the same name.
- MySQL 8 is not tested (MariaDB is); an account locked in Active Directory
  is refused by its password in password realms, not in code-only realms.

## 1.0.32 — 23 October 2026

**A token replaced on the enrolment pages could not be confirmed when the
settings had changed since it was made.**
- Every token keeps its own digits, period and hash: imported totpcgi tokens
  (SHA-1, 6 digits, 30 s) go on working beside tokens made later with other
  settings - that was always so. But a replacement waiting beside an old
  token was made with today's settings and checked with the old token's:
  an imported SHA-1 six-digit token replaced while the settings said
  SHA-512 and eight digits could never be confirmed. The waiting key now
  keeps its own shape, is confirmed with it, and the token takes it on once
  confirmed. *Show* on the waiting key shows it in its own shape too.
- Checked end to end: an imported SHA-1/6 token signs in, a new token is
  SHA-512/8, the old one replaced is confirmed with an 8-digit SHA-512 code
  and is SHA-512/8 from then on.

**What the hash and the length do, said where they are set.**
- *The hash*, *Digits in a code* and *A code lasts* now say that they are for
  tokens made from now on, and that Microsoft Authenticator and Google
  Authenticator on Android ignore SHA-256/SHA-512 (and Microsoft
  Authenticator eight digits) - their codes would be refused.

## 1.0.31 — 23 October 2026

**The step numbers in a token's mail are pictures.**
- Outlook's own circles (1.0.30) put the digit at the bottom edge, cut in
  half. Each number is now a small picture of the circle with its digit -
  drawn sharp for high-resolution screens, sent inside the mail like the QR
  code (about 2 KB each) - so it looks the same in Outlook, on the web and
  on a phone. With pictures blocked, the number itself is shown instead.

## 1.0.30 — 23 October 2026

**Round step numbers in Outlook as well.**
- Outlook on Windows draws mail with Word, which knows no rounded corners,
  so the numbered steps were squares there. In Outlook they are now drawn
  as VML circles - Outlook's own shapes - and every other mail program gets
  the same circles as before from CSS.
- The blue band at the top is one solid colour in Outlook too: its lighter
  stripes above and below the title are gone.

## 1.0.29 — 23 October 2026

**A token's mail that looks right in Outlook too.**
- Laid out in tables with sizes as attributes, which is all Outlook (it draws
  mail with Word) understands: the numbered steps are round badges beside
  their words instead of a sliver of blue, the QR code sits in a frame, the
  key is one line in a grey box, and the recovery codes are each in a box
  of their own, five to a row - they ran together into one long number.
- The account and the name under the QR code are plain text, not links
  that Outlook made of every name@domain, and are never broken in two.
- The plain-text copy of the mail is unchanged.

## 1.0.28 — 23 October 2026

**The steps of a sending folded away.**
- After making a token with its mail, and after *Send by mail* in a token's
  window, only the line saying how it went is shown - *Sent by mail to …*
  or why not. A click on it (or Enter) unfolds the steps: the MX records,
  the addresses, the server reached, TLS, what the server answered.
  *Settings → Mail → Try it*, which is there for the steps, still shows them.

## 1.0.27 — 23 October 2026

**A token's mail sent again.**
- *The person → By mail → Send by mail* in a token's window: the same
  choices as when it is made - the address, the recovery codes (the ones
  not used yet), Czech or English - and the steps of the sending.
- The address is remembered: wherever the token's mail went last time
  (when it was made, or sent again) is filled in, also when it was not the
  one in the directory; the row says where and when. It goes with the token
  when the token moves to another realm; given to somebody else, it does not.
- The key leaves the machine as when it is shown, so the same rule: a full
  administrator, with showing keys allowed. Every sending is a warning event.

**Where a mail went once it left.**
- *Handed the message over* now says what the receiving server answered -
  `250 2.0.0 Ok: queued as 4Xy…` - after making a token as well as when it
  failed, and the event keeps it: that id is what the receiving side's log
  (an IronPort's message tracking, say) is searched by when a mail never
  turns up although it left.
- *Settings → Mail → Try it* can send *a sample token mail* - the real
  layout, picture and codes, with a made-up key that opens nothing - next to
  the short message: a filter that lets a line of text through can still
  stop a mail with a QR code in it.

## 1.0.26 — 23 October 2026

**An upgrade leaves a good PHP alone.**
- `install.sh` (and `--upgrade`) no longer installs PHP again, switches its
  stream or restarts php-fpm when the PHP there already has the php2shell
  fix: it says so and goes on. Nothing pins a version - newer builds and
  streams come with the system's own `dnf upgrade` / `apt upgrade`.
- A PHP that is there but not fixed only has its own packages upgraded, on
  the stream it is on. Before, the stream was reset to `php:8.3` - which
  would have taken a machine already on `php:8.4` back down.
- A machine with no PHP gets `php:8.3` (`--php-stream`) only when no stream
  is enabled yet.

## 1.0.25 — 23 October 2026

**A popup closes only when told to.**
- A click beside a popup - on the darkened page, or on the window under a
  popup over it - no longer closes it; a stray click used to throw away a
  half-filled form. It closes with its own buttons (Save, Close, No, Back…),
  its ×, or Escape.

## 1.0.24 — 23 October 2026

**The window underneath stays still.**
- With a popup open over a token's window, the window underneath no longer
  jumps: its foot (the history, the Log, *Take the token away*, *Close*)
  lost its layout while it was underneath, wrapped onto two lines and gave
  the cards a scroll bar. Its look no longer depends on being on top.

## 1.0.23 — 23 October 2026

**Mail straight to the recipients: their servers' addresses too.**
- With *DNS servers for the recipients' domains* (`mail_dns`) set, the
  address of each recipient's mail server (A and AAAA, a CNAME followed) is
  asked of those servers as well, not only its MX record - before, only the
  MX went there and the address still came from the system's resolver.
  The connection goes to that address; the certificate is still checked
  against the server's name.
- With `mail_dns` empty, the address comes from the system's resolver
  (/etc/hosts, nsswitch) as before; only the MX question - which the system
  has no call for - is otp's own, sent to the servers in /etc/resolv.conf.
- Nothing else uses `mail_dns`: Active Directory, the SMTP relay, isemon,
  the database and the other node are looked up by the system as always.
- The step says what the address is and who gave it.

## 1.0.22 — 23 October 2026

**Mail straight to the recipients finds their mail servers.**
- The MX lookup asks with EDNS0, takes a cut-short answer again over TCP,
  follows a CNAME and knows a null MX. A DNS server that refuses or fails
  (SERVFAIL) is no longer taken for "this domain has no MX" - which sent
  the mail to the domain's own address (merit.cz:25) and timed out. It goes
  on to the next DNS server, and if none can answer it says which and why.
- The step says which DNS server gave the MX records.
- New setting *DNS servers for the recipients' domains* (`mail_dns`) for a
  machine whose own resolver will not answer; empty means /etc/resolv.conf.
  dnspython is used when it is installed.

**A window over a window.**
- In a token's window, *Show* (QR code and key, recovery codes), *In the
  directory*, the history, *New QR code*, new recovery codes, *Export .totp*
  and *Take the token away* open over it; closing them goes back to the
  token, drawn afresh where something changed. Esc closes only the top one.

**Passwords as isemon shows them.**
- Every password and secret box in the administration - the settings, the
  directory's account, a client's secret, accounts, the database, the Test
  tab, high availability - shows dots and its last two characters, both a
  kept one and one being typed. The sign-in pages keep the browser's own
  password box, so password managers still fill them.

**A person picked stays picked.**
- Once somebody is picked from the offer (or a box comes filled in), the
  offer does not pop up again when the box is clicked or focused - only
  once something is typed or deleted.

## 1.0.21 — 23 October 2026

**A token's window on one screen.**
- Four cards of exactly the same size, two by two: the phone, signing in,
  the recovery codes, the person. Their rows are lower, *Move to* and the
  note sit on one line each.
- When it was made, by whom, last used and from where sit beside the name
  instead of under it.
- The history, *Everything in the Log* and *Take the token away* are in the
  window's foot beside *Close* - no card of their own, and no scrolling on
  an ordinary screen.

## 1.0.20 — 23 October 2026

**Mail: a token's QR code sent to the person it is for.**
- *Settings → Mail*: through your mail server (STARTTLS 587, SMTPS 465, or
  none for a relay inside your network) with no sign-in, the best the server
  offers, PLAIN, LOGIN, CRAM-MD5 or XOAUTH2 (Microsoft 365, Google) - or
  straight to each recipient's domain by its MX record, with no server at
  all. The password is kept sealed with the tokens' key.
- The server's certificate is checked; a private authority is imported the
  same way as for Active Directory (paste or a .crt/.pem/.cer file, one or a
  chain, each listed with its whole fingerprint and removable on its own).
- *Try it* sends a short mail by the same road and shows every step:
  connection, TLS, sign-in, hand-over.

**Make a token: find the person, send it by mail.**
- *For* offers the people of the realms' directories as one types; picked,
  their mail address is read from the directory into *To* (it can be
  changed).
- *Send it by mail*: the QR code, the key, how to set the phone up, and -
  if ticked - the recovery codes, in Czech or English, as a tidy HTML mail
  with a plain-text copy. Every mail sent is in the events.
- The owner's full name is read from the directory as soon as the token is
  made - no need to press *Names from the directory* afterwards.

**Tokens out as .totp files.**
- *Settings → Export and import*: every token, or the ones a search picks
  (`realm:example.cz`, `name:novak*`, a state), as totpcgi .totp files in
  one ZIP - for totpcgi or another otp. A single token from its window:
  *For another server → Export .totp*. Full administrators only, with
  showing keys allowed, and each export is in the events as a warning.

**The pages made over.**
- One height for every box and button, one grid for the tiles, the token's
  window rebuilt as cards of actions, the settings laid on one grid so every
  name, box and explanation on a row starts at the same height.
- The list of suggestions floats above windows instead of being cut off
  inside them with its own scroll bars.
- Czech for everything new and for the titles still left in English.

## 1.0.19 — 23 October 2026

**Every search box offers its fields and values as one types (as isemon).**
- Tokens, the Log, Enrolment and Events read `field:value` besides plain
  words: `result:reject client:ASA`, `name:novak*`, `-state:active`,
  `realm:dpmo.cz,corpnet.cz`, `ms:>500`, `reason~ldap`, `from:10.1.0.0/16`,
  `(client:ASA OR client:localhost)`, `NOT …`. A name the list does not have
  is a word, so `10.1.2.3:1812` is searched as before.
- Under the box, as one types: the list's fields with what each means and an
  example; after `field:` what that field holds, busiest first, narrowed by
  what is typed. ↑ ↓ choose, Tab or Enter take, Esc closes. A search that
  cannot be read says why under the box. `GET /api/suggest` behind it.

**People and realms offered as one types.**
- *Make a token*, the token's *Move to*, *Look a name up* and the Test tab:
  type part of a name and the people of the realm's directory are offered,
  with their full name, mail, whether they are switched off and whether
  they have a token already; after an @ the realms are offered.

**A token can be given to another person, not only moved to another realm.**
- *Move to* takes any name; given to somebody else, the owner's name is read
  again from the directory. Key, recovery codes and history go with it.

**The person card, as isemon's.**
- The directory card (Accounts, a token's *In the directory*) and *Your
  account*: initials, name, principal name, tags (active / switched off /
  locked out / expires, role, realm, token), where the account lives as
  steps (domain › OU › person) with the DN, and the groups - the ones that
  make an administrator or let into a realm first, as cards saying so, the
  rest as chips (and N more).

**Fixes**
- The administration sign-in page said "the database will not open" to
  anyone not on the server itself, though it opened and signing in worked.
- Tiles never break a value in the middle of a word; a value too long ends
  in an ellipsis with the whole under the pointer.

## 1.0.18 — 22 October 2026

- Settings → Accounts: every row has the same buttons in the same places -
  the role first, then the directory lookup, the password, switching off,
  removing, the columns. A button that does not apply to an account (the
  directory for a local one, the password for a directory one) is there,
  dimmed, and says why; the invisible gaps that stood in for them made the
  rows look broken.

## 1.0.17 — 22 October 2026

**Long lists keep their search and their pager in place (as isemon).**

- Tokens, the Log, Enrolment and Events: the card is a column of heading,
  note, filters, the rows and the pager; only the rows scroll, the table's
  heading stays stuck to the top of them, and the search box and the pager
  never leave the window. A note longer than two lines is cut, and opens
  with a press on it. The daemon's own log under the events stays reachable.
  On a window too short or too narrow to frame, the page scrolls as one.

## 1.0.16 — 22 October 2026

**A tab for the enrolment pages: who came and what they did.**

- *Enrolment*, between Test and Events: every step a person took on the
  enrolment pages, newest first - signed in, made a token, confirmed it with
  a code, replaced an old one, could not sign in (and why), may not enrol
  (not in the groups). Six tiles count them for the chosen window (24 hours,
  a week, a month, all time); the list is searched by name or address and
  narrowed by step. A click on a row opens the person's token.
- `GET /api/enrolment` behind it (`q`, `step`, `since`, `limit`, `offset`).

## 1.0.15 — 22 October 2026

**A review of the whole program: security, bugs, the pages.**

Security - the daemon:
- A token an administrator switched off could be switched back on by its
  owner on the enrolment pages: confirming a code did not look at the state.
  Only a token that waits (new, or with a replacement staged) is confirmed
  now, and confirming never moves `last_step` back, so a code already used
  stays used.
- A test of a code in the Test tab ("dry") counted nothing and logged
  nothing: a token administrator could try codes without limit. Dry checks
  are logged (`test-dry`) and wrong ones count towards the pause.
- Recovery codes were kept as a plain SHA-256 of the code: a copy of the
  database without its key could be brute-forced offline in a minute. They
  are now keyed with the sealing key (HMAC); old rows are read and rewritten
  on their next use.
- The admin sign-in no longer says whether the name exists in the
  directory, or that the account there is locked or expired (that stays in
  the events).
- An account marked "must change the password" could call every endpoint;
  it may now only change the password, ask who it is, or sign out.
- A Reply-Message with non-ASCII characters longer than 253 bytes made the
  RADIUS server throw instead of answering and the request was never logged.
- `--trusted-proxy` wrote the real_ip block into the port-80 server, not the
  HTTPS one: behind a load balancer the sign-in pause was keyed on the
  balancer's address.
- HA: database passwords no longer pass on psql's command line nor reach
  PostgreSQL's log; an error text with a connection string is scrubbed
  before it is stored. The peer has to be one address (not a range); IPv6
  peers get /128. The `pg_hba.conf` line is prepended, so no earlier reject
  line wins.
- The per-name lock table and the "unknown client" table could grow without
  bound under a flood of made-up names and addresses.
- `--radtest` no longer prints the password.

Security - the pages:
- A restore upload (up to 4 GB) was read into a temp file before anyone was
  identified; now a full administrator's sign-in is checked first.
- The sign-in rate limit in nginx could be bypassed with a doubled or
  percent-encoded `api` parameter.
- `/healthz` is rate-limited; the pre-sign-in page tells its operator
  details (php-fpm user, token path, "no account yet") only from localhost;
  PHP errors are never displayed into a response.

The pages:
- Fields side by side in a popup started on different lines (the labels
  of a row were staggered); the tuning popup's memory field as well.
- Switching tabs with unsaved settings threw them away.
- The name of a switch setting did not flip it when clicked.
- Names with an apostrophe or an ampersand showed `&#39;` / `&amp;` in
  popup titles.
- Settings search: results are styled and say when nothing is found.
- Export and the Test tab are hidden from roles that may not use them.
- "Add it" under the certificate authority came back on a timer, so a slow
  import could be sent twice.
- The job progress is asked every five seconds when its pane is left (was
  every second, for ever).
- Escape over the column menu closed the popup under it too.
- Column layouts from a file are checked (no absurd widths, no junk).
- Shared secrets, bind passwords, first passwords and the HA passphrase
  are typed unseen; every popup label is linked to its box.
- Edit/person/lock buttons no longer turn red on hover; only the destructive
  ones do. Empty tables say "Nothing here". Several Czech texts that were
  still in English (the DB tooltips, HA buttons, token verdicts in the log,
  disk words in the tuning popup, the isemon rule note); `<this>` in the
  isemon hint was shown as `&lt;this&gt;`.
- The realm list no longer wraps its name, suffix and directory; the
  replication table's numbers have room; the import pane's checkbox is dark.
- The sign-in page of the administration shows the version and the language
  switch, as the enrolment pages do.
- The HA pane describes building and looking after the cluster with the
  exact commands, step by step, and has a table of every `--ha-*` command
  and when to use it. The intro follows the mode (replicated or shared).
- Sign-ins that sat untouched longer than allowed were still listed under
  "Signed in now"; they are tidied.
- About a third of the stylesheet was rules carried over from isemon for
  things these pages never draw; they are gone, as is a block that was in
  the file twice.

## 1.0.14 — 22 October 2026

**High availability, replicated: each node its own PostgreSQL, both answering**
- see docs/high-availability.md.

- `otp --ha-setup --ha-peer ADDRESS` now builds the replicated layout by
  default: logical replication both ways (publication `otp_pub`, subscriptions
  with `origin = none`, so nothing goes round in circles), odd ids on the first
  node and even on the second, `max_slot_wal_keep_size = 16GB`. The shared
  layout of 1.0.13 is `--ha-setup --ha-shared`.
- `otp --ha-join FILE` on the second node installs PostgreSQL if it is missing,
  copies every row from the first node and sets both directions up. The same
  command rejoins a reinstalled node.
- A node that was down catches up by itself. A node that was away longer than
  what is kept for it is rebuilt from the live one: `otp --ha-resync`, or
  *Rebuild this node from the other…* (a safety copy is made first).
- Watching and stepping in, on the pages (*Settings → High availability →
  Replication*) and on the command line: status of each direction (running,
  last heard from, waiting to go over, errors), `--ha-pause [both|in|out]`,
  `--ha-resume`, `--ha-stop`, `--ha-resync`, *Read the tables again*.
- Per-node things stay per node: the tuning record, the disk sizes, a job's
  progress, the nightly dump. The settings serial is a time and node mark, so
  both nodes' changes are seen.
- A new PostgreSQL database is created as UTF8 and every connection speaks
  UTF8 (an SQL_ASCII database failed on names with diacritics).

**Names from the directory after an import**
- Tokens brought in from another system get their owner's name from the
  directory, the same way as tokens enrolled here: right after the import, then
  every hour for any still without a name (100 at a time; a directory that does
  not answer is skipped for that round).
- A *Names from the directory* button on the Tokens tab does it at once for every
  token without a name; `otp --fill-names` on the command line.

**Settings → Active Directory → The certificate authority**
- The SHA-256 fingerprint is shown whole (two lines of 16 bytes) instead of
  cut short; a click selects it.

## 1.0.13 — 22 October 2026

**High availability: two servers, both answering (active/active), over one
PostgreSQL** - see docs/high-availability.md.

- Anything may go to either node, round robin and without stickiness: the
  "Edit the columns" switch is now kept with the sign-in in the database (it
  was in one daemon's memory), a job's progress is in the database too, and
  every setting changed on one node is read by the other within five seconds.
- A code - or a recovery code - is used up with one conditional UPDATE: two
  nodes asked for the same code at the same moment cannot both accept it.
- The nightly dump is claimed by one node.
- Each node writes a heartbeat; *Settings → High availability* lists the nodes
  (address, version, RADIUS, when last heard from), and the header says which
  node answered the page when there are two.
- The wizard: `otp --ha-setup --ha-peer ADDRESS` on the first node (opens a
  local PostgreSQL to the second node - listen_addresses, pg_hba.conf,
  firewalld - and writes the bundle), `otp --ha-join FILE` on the second; or
  *Make the bundle…* and *Join a cluster…* on the pages. The bundle carries
  the database's address and password and the key that opens the tokens,
  locked with a passphrase (scrypt + HMAC-SHA256) shown once.
  `otp --ha-status` lists the nodes.
- `GET /healthz` for the load balancer: 200 "ok NODE" while the node and its
  database answer, 503 when not.
- `otp --trusted-proxy CIDR`: nginx takes the client's address from
  X-Forwarded-For when it comes from the load balancer.
- `node_name` in config.json: this node's name (Settings → High availability).
- `install.sh --upgrade` now brings an existing nginx configuration up to the
  version (the 4 GB body for putting a database back, which 1.0.10 needed, and
  /healthz), keeping its allow lists and a copy of what it was.
- A token window's history, cleaner popups: a grid of two fields no longer has
  the second one pushed down.

## 1.0.12 — 22 October 2026

- **Several certificate authorities per directory.** A directory whose
  domain controllers come from several domains or authorities keeps a chain
  for each: *Add it* adds what is pasted or read from a file (a whole chain at
  once, and a certificate already kept is not added twice) instead of
  replacing it; every certificate is listed - who it is, who signed it, valid
  from and until (coloured as it nears its end), its SHA-256 fingerprint - and
  each has its own bin. *Take them all away* empties it.
- **A token's window is wide and needs no scrolling**: four cards side by
  side - the phone (with *Try a code* under it), the recovery codes, signing
  in (with *Take it away* under it) and the person (directory, realm, note) -
  and the history behind its button below them.

## 1.0.11 — 22 October 2026

**The whole interface gone over.**

- A token's window: the buttons of each card are one under another, all the
  same size; *Try a code* and *Note* take the whole width; the history (the
  checks of a code and the requests) is no longer drawn under everything but
  behind **The history** - a popup of its own with the way back - and
  **Everything in the Log** opens the Log searched for that name.
- **A token can be moved to another realm** (*The person → Realm → Move it*):
  its name changes to name@realm (or the bare name), with the same key, the
  same history and its recovery codes made again under the new name.
- Settings whose choices are long (*Who may enrol a token*, *Token names are
  kept*) are two columns wide, so the choice is not cut off.
- Fields in popups have room between them; the group searches are wide enough
  for their hint; the certificate authority's *Load a file…* has the upload
  icon and *Import* the save one; the phone on the enrolment page shows its
  code inside the screen.
- Realms: "default - also without @" and how a name is looked up are in the
  page's language; "/var/log/remote/<host>/" reads "HOST"; About says the
  engine by its name.
- Czech: the database pane, the reasons of the token engine (*Not a valid
  token*, *Scratch-token used*…), "From"/"Since" as *Odkud*/*Od kdy*, the new
  events.
- The database's restart: the tuning popup has **Restart the server…** itself
  when something waits for PostgreSQL's next start, and where it may not, says
  why (another machine, no single postgresql service, or install.sh's rule
  missing).
- The installer installs the database client only for the engine in the
  config file: `--with-db both` no longer puts the MariaDB client on a machine
  that runs on PostgreSQL.
- Events of copies and dumps read better ("made a PostgreSQL dump (every
  night): …").

## 1.0.10 — 22 October 2026

**Settings → The database, rebuilt to be isemon's.**

- **The dumps it keeps** (new): every night the database in use is dumped by
  its engine's own program - `pg_dump` (custom format, `.pgc`),
  `mariadb-dump` (`.sql.gz`), SQLite's own backup (`.db`) - into
  `/var/lib/otp/dumps`, with the key that opens the tokens beside each one.
  Where the program is missing, a portable copy is made instead and the card
  says what to install. *Make one now*, *Download one*, and per dump
  *Download*, *Restore* and *Delete*; *Put a dump back* takes one from
  elsewhere. A dump goes back only into the engine it came off.
- **Copies**: the same list for the portable copies (any engine), with
  *Download*, *Restore* and *Delete*, plus *Download it* (a copy made now,
  with the key inside it) and *Put a copy back* (drop a file). Everything put
  back is read and shown first - what it is, how many tokens, accounts and
  full administrators - and refused if it is not otp's, is a dump of another
  engine or has no full administrator. A copy of what is replaced is always
  made first. The file goes up as the request body itself (never multipart,
  php2shell), a lump at a time, up to 4 GB.
- **Which one it is**: the facts as isemon shows them, whether each driver is
  installed; *Try it*, *Set it up…*, *Carry everything across…*, *Empty it…*,
  *Start using it…* each in its own popup with what will happen.
- **The disk it is on** (new): free space, how fast the database grows (noted
  daily, the slope of the last fortnight), days left, the files it is made of
  (`otp.db`, `-wal`, `-shm`, the copies, the dumps); a warning when the
  server's own cache is smaller than the database.
- **The database server's own settings**: the popup shows the server, the
  machine (memory, free memory, processors), how the disk was judged - a
  virtual machine's disk always says it spins, so the time a small write takes
  decides, as on isemon - and per setting *Now / For this machine / Takes /
  Why*. Memory settings within a tenth are the same, so it no longer asks to
  change shared_buffers back and forth. What was tuned and when, and what is
  waiting for the server's next start, is said on the card.
- **Restart the server…**: PostgreSQL on this machine restarted from the page
  for the settings waiting for its start, refused when the memory free would
  not hold the new shared_buffers or huge pages are on, then waited for. The
  installer puts in a polkit rule that lets the `otp` account restart
  `postgresql*.service` and nothing else (`--no-db-restart` takes it away).
- **Erase the collected data** (new): the RADIUS requests, the checks of a
  code and the event log, each with its count, ticked and erased as a job
  with a copy made first and the disk given back afterwards. Tokens, accounts
  and settings are not in the list at all.
- The installer installs the database clients (`postgresql`, `mariadb`) with
  `--with-db`, for the dumps.

## 1.0.9 — 22 October 2026

**The columns of every table, laid out by whoever is looking - exactly as on isemon.**

- Every table in the administration (tokens, the log, events, realms,
  clients, accounts, sign-ins, groups, the database…) can be laid out per
  account: drag the edge of a heading to size a column (its width is shown
  in a pill at the foot of the window, twice on the edge puts that table's
  widths back), drag the heading itself to move the column, and the right
  button on a heading or a row opens the menu: hide this column, bring a
  hidden one back (a tick by each column), add an empty column to the left
  or right for room, take an empty one away, put this table back as it comes.
- Only while **Edit the columns** is switched on - under your name at the
  top right, or on Settings → Accounts. The switch is held by the daemon for
  that one sign-in: signing out, the sign-in running out or a restart of the
  service turn it off. Off, the layout is drawn just the same and nothing can
  move it; a change sent with it off is refused (409) and the page says so.
- The layout is kept with the account in the database (`accounts.cols`),
  not in the browser, so it follows you to any machine; widths are kept as
  shares of the table so it always fits its card. Laid out before the
  browser paints, so a table is never seen in its old order first.
- **Put my columns back as they come** (under your name and on Accounts).
  A full admin can put anybody's back: the new *Columns* column on Accounts
  says how many tables each person has laid out, and the button beside it
  resets them (logged as an event).
- **Your settings in a file**: *Export my settings* saves your column layout
  and language as `otp-settings-<you>-<date>.json` (kind
  `otp-user-settings`); *Import settings…* shows whose file it is, where and
  when it was saved and what it holds before replacing yours. isemon's own
  settings file is read too. Never a password, a role or anything else about
  the account.
- New API: `POST /api/auth/columns` (`{edit}`, `{cols}`, `{reset}`),
  `GET|POST /api/auth/settings`; `/api/users` action `reset_cols`;
  `whoami` carries `cols` and `cols_edit`.

**Who may enrol a token: the groups found and picked.**

- Settings → The enrolment pages → *Groups that may enrol* has a
  **Find and pick the groups** button: the same directory group search as
  for realms and administrators, with *May enrol* beside each group to put
  it in or take it out, the chosen ones shown as chips. It looks in the
  directory of the enrolment pages' realm (or the default realm) first.

## 1.0.8 — 22 October 2026

**Security: the groups of a realm are now always checked.**

- A realm whose *By* was "not looked up anywhere" skipped the directory
  entirely - its groups, a switched-off account - and let anybody with a right
  code in. A realm with a directory now always asks it: the way is chosen by
  the form of the name (with an @ by userPrincipalName, without it by
  sAMAccountName) when none is set. A realm that names groups and has no
  directory refuses everybody, saying so.
- **Enrolment** checks the realm's groups always: nobody enrols a token the VPN
  would refuse. *Who may enrol* can only narrow that further.
- Every refusal says why, with names: `account does not pass LDAP group
  filter(s): novak@example.cz is in none of VPN_USERS, VPN_ADMINS`, and on the
  enrolment pages the same goes into the log and the events.
- Groups inside groups (nested) count everywhere a group is asked about - the
  realms, enrolment, the administrators' roles - with Active Directory's
  in-chain rule; a realm can switch it off.
- A request that could not be decided because of an error inside gets a
  refusal with the reason, never silence.

**The default realm** (Settings → Realms): names written without a realm
belong to it - `novak` is `novak@example.cz` - on the enrolment pages and in
RADIUS requests from a client that adds no realm of its own; `novak@example.cz`
works as well, and every other realm still needs its @domain. The realm list
marks it.

**One log**: *Requests* and *Codes* are one tab, *Log* - every RADIUS request
with what the token said about its code, and every code checked anywhere else
(the enrolment pages, a test, the command line), filtered by kind, time,
result and client. A log is not edited from the pages any more: old lines go
by themselves after the days set under Settings → The database, which is also
where they can be cleared (*Forget records older than…*, or every line).

**Tokens**

- The token window is large and in sections: *The phone* (show the QR code and
  key, a new QR code with a new key, the waiting one), *Recovery codes* (show
  them - which are free and which were used, and when - or make new ones),
  *Signing in* (switch off, forget the wrong codes, clock drift), *Try a code*,
  *The person* (what the directory says, the note), *Take it away*.
- Recovery codes are kept sealed beside their hashes, so a full administrator
  can show them again; a used one stays, struck through, with when it was
  used. Tokens made before 1.0.8 have only the hashes: make new ones to have
  them shown. Every look is an event; *Administrators may show a token's QR
  code and key* switches it off.

**The pages**

- A pencil for every Edit, everywhere.
- *In the directory* beside every token and every account signed in from the
  directory: who it is, whether it is switched off or has run out, the DN, its
  groups (nested ones too).
- Active Directory: each directory a card - its servers as chips, how it is
  reached, its certificate, the base, the reading account - and its editor in
  two sections. The certificate authority as tiles, *Good until* coloured as
  it nears its end, the paste box behind *Import another…* once one is there.
- The realm editor in sections: what it takes, looking the person up, the
  groups that let in, the answer.
- The overview's lists keep their words whole - the name or the reason on its
  own line, the bar, the count and when under it - and the chart counts in
  whole numbers.
- The save bar shows only on a page with settings to save.

Upgrading: unpack 1.0.8 and run `./install.sh --upgrade`. Check *By* of every
realm afterwards: what was "not looked up anywhere" now looks the name up.

## 1.0.7 — 22 October 2026

- **Aligned.** A row with buttons at its end is centred top to bottom, so the
  name, its tags and its buttons stand on one line. In Accounts every row's
  buttons stand in the same columns - an account signed in from the directory,
  which has no password here to set, keeps an empty place where the lock is -
  and the role choice has one width in every row. A setting as wide as the
  page (the groups of the roles, the help text) has its (i) at its right edge
  like every other.

Upgrading: unpack 1.0.7 and run `./install.sh --upgrade`.

## 1.0.6 — 22 October 2026

- **No browser dialogs anywhere.** *Look a name up* (Active Directory) and
  *Set a new password* (Accounts) asked through the browser's own prompt box;
  both are now the pages' own popup, like everything else - the password asked
  twice and checked for length before it is sent. Nothing on the pages uses
  prompt, alert or confirm any more.

Upgrading: unpack 1.0.6 and run `./install.sh --upgrade`.

## 1.0.5 — 22 October 2026

The administration pages, gone through as a whole.

- **The tables no longer draw their buttons over the columns before them.**
  The cell holding a row's buttons was made a flex box, which takes it out of
  the table: in Active Directory the Base and the account were covered, in
  Accounts the role. Long names (servers, DNs) wrap in their own column.
- **Every row has its Edit and its Delete**: tokens (open it, take it away),
  clients, realms, directories (a gear to change it, a bin to take it away),
  the checks of a code and the RADIUS requests (see below).
- **Codes**: a line opens what it was (when, right or not, what was said, how,
  from where, which request) with *Its token*, *Its requests* and *Forget this
  line*; a bin on every line; *Forget these…* takes out every line the filters
  match. The same on **Requests**. Full administrators only, and every
  forgetting is written down as an event; what went to isemon stays there.
- **A name without a token** opens with *Make a token* and its history,
  instead of a window saying only that there is none.
- **A token's QR code and key can be shown again** by a full administrator
  (*Show the QR code and key*, and *Show the waiting one* for a replacement
  not yet confirmed) - after a warning, and every look written down. The
  setting *Administrators may show a token's QR code and key* (Settings → The
  tokens) switches it off.
- **A wrong code when confirming a new token says why**: the phone's clock is
  off by so many seconds, or the code is not from this token at all - usually
  an older entry of the same name in the application.
- **Signing administrators in against Active Directory, as isemon does it**
  (Settings → Accounts): *The groups, and what each one may do* - *Find the
  groups* (all, or those whose name holds what is typed), the list searchable
  and paged, and *Full admin* / *Token admin* / *Read only* beside every
  group, lit where it holds the role; *Try a sign-in…* asks the directory as a
  real sign-in would and shows the role and the groups, signing nobody in.
  Names may be typed as `novak`, `novak@example.cz` or `EXAMPLE\novak`. With
  no group given a role at all, anybody in the directory may read (isemon's
  rule); naming one closes that.
- **The same group list in the realm editor**: *Find the groups*, search, and
  *Lets in* beside every group, in place of a prompt that added every match.
- **The certificate authority of a directory, as isemon's**: its own card
  under Active Directory - what is imported (who it is, who signed it, from
  and until when), paste it or *Read a file…* (.pem, .crt, and a .cer in DER
  as Windows exports it), *Import it*, *Take it away*. It is checked for being
  a certificate before it is stored.
- **The database page, as isemon's**:
  - *Which one it is*: *Try it* (the address in the editor, unsaved), *Set it
    up…* (makes the database and the account on MariaDB or PostgreSQL with an
    administrator of that server used once and kept nowhere; a password made
    and shown once), *Carry everything across…* (a copy first, then every
    row, with a progress bar), *Empty it…* (only ever the other one), *Start
    using it…* (writes the address and starts the daemon again on it).
  - *What is in it*: rows and size of every table, the room free inside,
    *Make a copy now*, *Check it* (integrity check / CHECK TABLE / every table
    read), *Optimise it* (fresh statistics), *Apply what is kept, now*,
    *Forget records older than…*, *Give the disk back* (VACUUM / OPTIMIZE
    TABLE / VACUUM FULL).
  - *The database server's own settings* (MariaDB, PostgreSQL): what the
    machine has, the settings worked out for it beside what is there now, put
    in with ALTER SYSTEM or SET GLOBAL (the ones that need a restart said so,
    and for MariaDB the lines for `/etc/my.cnf.d/`), and *Put back as it was*.
- Copying into another database is batched: a transaction per thousand rows
  rather than one per row.
- A link to `#settings/dir` (or Back in the browser) opens that page.

Upgrading: unpack 1.0.5 and run `./install.sh --upgrade`.

## 1.0.4 — 22 October 2026

The command line, and the enrolment page.

- **`otp` (or `otp`) with nothing after it, typed at a terminal, says what it
  is doing** - the same as `--status` - instead of starting a second daemon
  that failed on the port the running one holds. The daemon itself is now
  `otp --daemon`; `otp.service` starts it so (under systemd, or anything else
  that is not a terminal, a bare `otp` is still the daemon).
- **Only one daemon at a time**: a second one stops at once and says which one
  is running (`/var/lib/otp/otp.lock`). And the RADIUS sockets no longer set
  SO_REUSEADDR, which on UDP let a second process bind the very same port
  and take half the packets.
- A daemon started by hand as root becomes the account `otp`, as the rest of
  the command line already did.
- **Colour as in isemon**: colorama when it is installed (the installer puts
  `python3-colorama` in place, or takes it from pip), the same escape
  sequences written by hand when it is not. `--help` is isemon's: two
  columns, the options green, their values yellow, the headings cyan, and
  THINGS PEOPLE ACTUALLY TYPE at the end. `NO_COLOR=1` and `--no-color` turn
  it off; a pipe gets none.
- **`--check` checks more than `--status` shows**: the key of the tokens, the
  age of the latest copy, PHP and php2shell, every client, every realm and
  whether its directory exists, every domain controller step by step, and
  where isemon's lines go.
- **The enrolment page** is headed *One-time passwords* (*Jednorázová hesla*)
  unless `portal_title` says otherwise - it said *Google Authenticator*. It
  links to the administration pages at the bottom, and while no realm with a
  directory is set up it says that nobody can enrol yet and that
  administrators sign in at `/admin/` - instead of "the name or the password
  is not right" to the administrator who has just installed it.

- The daemon's answers on the pages ("the directory cannot be reached just now" and
  the rest) are in Czech as well, not half-translated.

Upgrading: unpack 1.0.4 and run `./install.sh --upgrade` - it puts the new
`otp.service` in place, with `--daemon`.

## 1.0.3 — 22 October 2026

- **`otp` works as well as `otp`.** The installer links the command under both
  names, `/usr/local/bin/otp` and `/usr/local/bin/otp` — `otp --status`,
  `otp --log`, `otp --radtest falco 135830`. A different `otp` already on the
  machine is left alone, with a warning. `--uninstall` takes the link away.

Upgrading: unpack 1.0.3 and run `./install.sh --upgrade`.

## 1.0.2 — 22 October 2026

The installer.

- With firewalld not running, the firewall step was skipped without a word.
  It now says so, and what has to be let through by whatever filters the
  machine instead: TCP 443 (and 80), UDP 1812 and 1813 from the VPN
  concentrators.
- `--radius-from 127.0.0.1` (or `::1`) no longer becomes a firewalld rule:
  the machine's own packets never meet the firewall.

Upgrading from 1.0.0 or 1.0.1: unpack 1.0.2 and run `./install.sh --upgrade`.
The daemon, the pages and the database are unchanged; the version number on
them moves to 1.0.2.

## 1.0.1 — 22 October 2026

The installer.

- **It ended without a word at "PHP, and php2shell" on a machine that never
  had PHP.** `dnf module list --enabled php` exits 1 when no PHP stream is
  enabled, and under `set -euo pipefail` that ended the script. Its output is
  now taken first and read afterwards; PHP goes onto `php:8.3` as intended.
- The same kind of trap in two more places that had not been reached yet:
  the check for FreeRADIUS holding UDP 1812, and the list of PHP packages on
  Debian / Ubuntu.
- Nothing ends silently any more: whatever stops the installer prints
  `ERROR: line N: "command" ended with X`.

Upgrading from 1.0.0: unpack 1.0.1 and run `./install.sh` again (or
`./install.sh --upgrade` where 1.0.0 finished installing). The daemon, the
pages and the database are the same as in 1.0.0.

## 1.0.0 — 22 October 2026

The first version: the RADIUS server, TOTP, the QR codes, Active Directory,
realms and groups, the enrolment and administration pages, isemon's syslog
lines, SQLite / MariaDB / PostgreSQL, the import of a totpcgi + FreeRADIUS
server, the installer with PHP fixed against php2shell, Czech.
