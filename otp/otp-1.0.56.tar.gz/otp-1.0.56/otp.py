#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
otp - a one-time password server: RADIUS, TOTP and the enrolment of tokens,
in one Python file.

A VPN concentrator asks over RADIUS whether somebody may come in. otp answers:
it checks the six digits against the token the person enrolled, looks the
person up in Active Directory, holds them against the groups the realm asks
for, and says yes or no - with the reasons written down, every one of them,
and sent on to isemon in the very shape isemon already reads from a token
server.

Everything is here: the RADIUS server, the token arithmetic (RFC 4226 / 6238),
the QR codes the phones scan, the one-off recovery codes, Active Directory over
LDAP, the database, the JSON API the web pages ask and the command line. The
web pages (PHP) only relay to the API; they hold nothing and decide nothing.

    otp --status              what it is doing, in one screen
    otp --tokens              who has a token
    otp --enroll NAME         make one, and show the QR code in the terminal
    otp --radtest NAME CODE   ask this server the way the VPN does
    otp --log                 the RADIUS requests, newest first
    otp --help                all of it

With nothing at all on the command line it runs the daemon in the foreground.

The Python standard library and nothing else, except the driver of a database
server where one is chosen instead of the file on this machine.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import collections
import getpass
import hashlib
import heapq
import hmac
import html

import io
import ipaddress
import json
import os
import queue
import re
import secrets

import shutil
import signal
import smtplib
import socket

import sqlite3
import ssl
import string
import struct
import subprocess
import sys
import tempfile

import threading
import time
import traceback
import urllib.error
import urllib.request
import zipfile
import zlib
from datetime import datetime, timezone
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

__version__ = '1.0.56'

# ---------------------------------------------------------------------------
# Paths and defaults
# ---------------------------------------------------------------------------
CONFIG_FILE = Path(os.environ.get('OTP_CONFIG', '/etc/otp/config.json'))
STATE_DIR = Path(os.environ.get('OTP_STATE', '/var/lib/otp'))
DB_FILE = STATE_DIR / 'otp.db'
BACKUP_DIR = STATE_DIR / 'backups'
RUN_DIR = Path(os.environ.get('OTP_RUN', '/run/otp'))
TOKEN_FILE = RUN_DIR / 'api-token'
LOG_DIR = Path(os.environ.get('OTP_LOGDIR', '/var/log/otp'))
SERVICE_USER = 'otp'
WEB_GROUP = 'otp-web'

# Who may do what on the administration pages. `tokenadmin` is the help
# desk: it may look at everything and look after people's tokens - make one,
# switch one off, give new recovery codes, take one away - and nothing else:
# no setting, no RADIUS client, no realm, no account.
ROLES_ALL = ('fulladmin', 'tokenadmin', 'readonly')
ROLE_WORDS = {'fulladmin': 'full admin', 'tokenadmin': 'token admin',
              'readonly': 'read only'}

DEFAULTS = {
    # --- the RADIUS server ------------------------------------------------
    'radius_bind': '0.0.0.0',
    'radius_auth_port': 1812,
    'radius_acct_port': 1813,
    'radius_status_server': 1,
    'radius_reply_ma': 1,
    'radius_dup_window_s': 30,
    'radius_workers': 16,
    'radius_unknown_log': 1,
    'radius_reject_delay_ms': 0,
    'radius_reject_reason': 0,
    'radius_ma_sticky': 1,
    # --- the tokens ---------------------------------------------------------
    'totp_issuer': 'OTP',
    'totp_label': '{user}',
    'totp_digits': 6,
    'totp_period': 30,
    'totp_algorithm': 'SHA1',
    'totp_window': 1,
    'admin_show_key': 1,
    'totp_disallow_reuse': 1,
    'rate_limit_tries': 3,
    'lockout_after': 10,
    'lockout_min': 15,
    'rate_limit_s': 30,
    'scratch_count': 5,
    'scratch_digits': 8,
    'token_names_case': 'lower',
    # --- the enrolment pages -------------------------------------------------
    'portal': 1,
    'portal_title': '',
    'portal_realm': '',
    'default_realm': '',
    'portal_hint': '',
    'portal_who': 'realm_groups',
    'portal_groups': '',
    'portal_confirm': 1,
    'portal_reissue': 1,
    'portal_show_secret': 1,
    'portal_scratch': 1,
    'portal_session_min': 15,
    'portal_help': '',
    'portal_tries': 5,
    'portal_wait_min': 15,
    # --- the administration pages -------------------------------------------
    'session_hours': 12,
    'session_idle_min': 120,
    'login_tries': 5,
    'login_wait_min': 15,
    'admin_directory': '',
    'admin_group_full': '',
    'admin_group_token': '',
    'admin_group_readonly': '',
    # --- isemon ---------------------------------------------------------------
    'isemon': 0,
    'isemon_targets': '',
    'isemon_hostname': '',
    'isemon_detail': 1,
    'isemon_events': 0,
    'isemon_max_bytes': 1800,
    'ship_files': 1,
    # --- sending mail (1.0.20) ----------------------------------------------
    'mail_mode': 'off',
    'smtp_host': '',
    'smtp_port': 0,
    'smtp_security': 'starttls',
    'smtp_auth': 'auto',
    'smtp_user': '',
    'smtp_password': '',
    'smtp_verify': 1,
    'smtp_timeout_s': 20,
    'mail_from': '',
    'mail_from_name': '',
    'mail_reply_to': '',
    'mail_helo': '',
    'mail_direct_port': 25,
    'mail_direct_tls': 'if-offered',
    'mail_dns': '',
    'mail_lang': 'cs',
    'mail_codes': 1,
    # --- keeping things -------------------------------------------------------
    'retain_radius_days': 180,
    'retain_otp_days': 180,
    'retain_events_days': 365,
    'backup_daily': 1,
    'backup_keep': 14,
    'backup_at': '03:30',
    # --- the database ---------------------------------------------------------
    'db_engine': 'sqlite',
    'db_host': '',
    'db_port': 0,
    'db_name': 'otp',
    'db_user': 'otp',
    'db_password': '',
    'db_timeout_s': 10,
    'db_tls': '',
    'db_tls_ca': '',
    # --- this installation ----------------------------------------------------
    'node_name': '',
    'ha_mode': '',
    'ha_slot': 0,
    'ha_peer': '',
    'ha_peer_port': 5432,
    'ha_address': '',
    'site_name': '',
    'ui_lang': 'cs',
    'api_port': 9861,
    'debug': False,
    'debug_radius': 1,
    'debug_ldap': 1,
    'debug_api': 0,
}

# The settings that are a database's own address. A database cannot hold the
# address of itself, so these live in config.json and are written there.
DB_KEYS = ('db_engine', 'db_host', 'db_port', 'db_name', 'db_user', 'db_password',
           'db_timeout_s', 'db_tls', 'db_tls_ca')

# ...and the name of this node of a cluster, which is this machine's own.
FILE_ONLY_KEYS = DB_KEYS + ('node_name', 'ha_mode', 'ha_slot', 'ha_peer', 'ha_peer_port',
                             'ha_address')

# Settings of one node of a cluster, not of the cluster (1.0.37): saved as
# `key@node` and read only by that node; without one it takes the cluster's.
# The address RADIUS listens on is this machine's own, and so are the port
# the pages ask the daemon on, the name it greets mail servers with, the
# name isemon files its lines under and the debug switches.
NODE_KEYS = ('radius_bind', 'api_port', 'mail_helo', 'isemon_hostname', 'debug',
             'debug_radius', 'debug_ldap', 'debug_api')


def this_node_name(conf=None):
    said = str((conf or CONFIG).get('node_name') or '').strip()
    return said or (socket.gethostname().split('.')[0] or 'otp')


SECRET_KEYS = ('db_password', 'smtp_password')
# Secrets kept in the database, sealed with the key that seals the tokens.
SEALED_KEYS = ('smtp_password',)

# What each setting may be: a list of words, or the lowest and highest number.
TUNABLE = {
    'radius_auth_port': (1, 65535), 'radius_acct_port': (0, 65535),
    'radius_status_server': (0, 1), 'radius_reply_ma': (0, 1),
    'radius_dup_window_s': (0, 600), 'radius_workers': (1, 256),
    'radius_unknown_log': (0, 1), 'radius_reject_delay_ms': (0, 10000),
    'totp_digits': (6, 8), 'totp_period': (15, 120),
    'totp_algorithm': ('SHA1', 'SHA256', 'SHA512'),
    'totp_window': (0, 10), 'admin_show_key': (0, 1), 'totp_disallow_reuse': (0, 1),
    'rate_limit_tries': (0, 100), 'rate_limit_s': (1, 86400),
    'lockout_after': (0, 1000), 'lockout_min': (1, 10080),
    'radius_reject_reason': (0, 1), 'radius_ma_sticky': (0, 1),
    'scratch_count': (0, 20), 'scratch_digits': (6, 12),
    'token_names_case': ('lower', 'as-typed'),
    'portal': (0, 1), 'portal_who': ('realm_groups', 'groups', 'anyone'),
    'portal_confirm': (0, 1), 'portal_reissue': (0, 1), 'portal_show_secret': (0, 1),
    'portal_scratch': (0, 1), 'portal_session_min': (1, 240),
    'portal_tries': (1, 100), 'portal_wait_min': (1, 1440),
    'session_hours': (1, 168), 'session_idle_min': (5, 1440),
    'login_tries': (1, 100), 'login_wait_min': (1, 1440),
    'isemon': (0, 1), 'isemon_detail': (0, 1), 'isemon_events': (0, 1),
    'isemon_max_bytes': (480, 65000), 'ship_files': (0, 1),
    'retain_radius_days': (0, 36500), 'retain_otp_days': (0, 36500),
    'retain_events_days': (0, 36500), 'backup_daily': (0, 1), 'backup_keep': (1, 365),
    'db_engine': ('sqlite', 'mariadb', 'postgres'), 'db_port': (0, 65535),
    'db_timeout_s': (1, 300), 'ui_lang': ('cs', 'en'), 'api_port': (1024, 65535),
    'debug_radius': (0, 1), 'debug_ldap': (0, 1), 'debug_api': (0, 1),
    'mail_mode': ('off', 'smtp', 'direct'), 'smtp_port': (0, 65535),
    'smtp_security': ('starttls', 'tls', 'starttls-if', 'none'),
    'db_tls': ('', 'require', 'verify-ca', 'verify-full'),
    'mail_direct_tls': ('if-offered', 'required'),
    'smtp_auth': ('none', 'auto', 'plain', 'login', 'cram-md5', 'xoauth2'),
    'smtp_verify': (0, 1), 'smtp_timeout_s': (3, 300), 'mail_direct_port': (1, 65535),
    'mail_lang': ('cs', 'en'), 'mail_codes': (0, 1),
}

CHOICE_WORDS = {
    'mail_mode': {'off': 'off - no mail is sent',
                  'smtp': 'through a mail server (SMTP relay)',
                  'direct': 'straight to the recipient’s mail server (MX), no relay'},
    'mail_direct_tls': {'if-offered': 'encrypted where the server offers it',
                        'required': 'encrypted, or not sent at all'},
    'smtp_security': {'starttls': 'STARTTLS - plain, then encrypted (587)',
                      'tls': 'TLS from the start - SMTPS (465)',
                      'starttls-if': 'STARTTLS if the server offers it',
                      'none': 'none - plain text (25)'},
    'smtp_auth': {'none': 'none - the server lets this machine send',
                  'auto': 'whatever the server offers best (PLAIN, LOGIN, CRAM-MD5)',
                  'plain': 'PLAIN', 'login': 'LOGIN', 'cram-md5': 'CRAM-MD5',
                  'xoauth2': 'XOAUTH2 - an OAuth access token as the password'},
    'mail_lang': {'cs': 'Čeština', 'en': 'English'},
    'totp_algorithm': {'SHA1': 'SHA-1 (what every phone app understands)',
                       'SHA256': 'SHA-256', 'SHA512': 'SHA-512'},
    'token_names_case': {'lower': 'small letters - Novak and novak are one person',
                         'as-typed': 'exactly as written'},
    'portal_who': {'realm_groups': 'whoever passes the realm’s group filter',
                   'groups': 'members of the groups named below',
                   'anyone': 'anybody the directory lets sign in'},
    'db_engine': {'sqlite': 'a file on this machine (SQLite)', 'mariadb': 'MariaDB / MySQL',
                  'postgres': 'PostgreSQL'},
    'ui_lang': {'cs': 'Čeština', 'en': 'English'},
}

NAMES = {
    'mail_mode': 'Sending mail',
    'smtp_host': 'Mail server',
    'smtp_port': 'Port',
    'smtp_security': 'Encryption',
    'smtp_auth': 'Signing in',
    'smtp_user': 'Account',
    'smtp_password': 'Password',
    'smtp_verify': 'Check the server’s certificate',
    'smtp_timeout_s': 'Wait for the server (s)',
    'mail_from': 'From (address)',
    'mail_from_name': 'From (name)',
    'mail_reply_to': 'Replies to',
    'mail_helo': 'This machine calls itself (EHLO)',
    'mail_direct_port': 'Port of the recipients’ servers',
    'mail_direct_tls': 'Encryption to the recipients’ servers',
    'mail_dns': 'DNS servers for the recipients’ domains',
    'mail_lang': 'Language of the mail',
    'mail_codes': 'Recovery codes in the mail',
    'radius_bind': 'Listen on the address',
    'radius_auth_port': 'Authentication port',
    'radius_acct_port': 'Accounting port',
    'radius_status_server': 'Answer Status-Server',
    'radius_reply_ma': 'Sign every answer (Message-Authenticator)',
    'radius_dup_window_s': 'A repeated request is the same one for (s)',
    'radius_workers': 'Requests answered at once',
    'radius_unknown_log': 'Write down requests from unknown clients',
    'radius_reject_delay_ms': 'Wait before a refusal (ms)',
    'totp_issuer': 'The issuer, as the phone shows it',
    'totp_label': 'The account name, as the phone shows it',
    'totp_digits': 'Digits in a code',
    'totp_period': 'A code lasts (s)',
    'totp_algorithm': 'The hash',
    'totp_window': 'Steps of clock drift allowed',
    'admin_show_key': 'Administrators may show a token\'s QR code and key',
    'totp_disallow_reuse': 'A code works only once',
    'rate_limit_tries': 'Wrong codes before a pause',
    'lockout_after': 'Wrong codes in a row before a lockout',
    'lockout_min': 'Locked out for (min)',
    'radius_reject_reason': 'Say why in a refusal',
    'radius_ma_sticky': 'Hold a client to the Message-Authenticator',
    'rate_limit_s': '...counted over (s)',
    'scratch_count': 'Recovery codes per token',
    'scratch_digits': 'Digits in a recovery code',
    'token_names_case': 'Names of tokens are kept in',
    'portal': 'The enrolment pages are open',
    'portal_title': 'The title of the enrolment pages',
    'portal_realm': 'Realm added to a name signed in without one',
    'default_realm': 'The default realm',
    'portal_hint': 'What to type as the name (shown on the sign-in)',
    'portal_who': 'Who may enrol a token',
    'portal_groups': 'Groups that may enrol',
    'portal_confirm': 'A new token must be confirmed with a code',
    'portal_reissue': 'People may replace their own token',
    'portal_show_secret': 'Show the key as text beside the QR code',
    'portal_scratch': 'Show the recovery codes',
    'portal_session_min': 'An enrolment sign-in lasts (min)',
    'portal_help': 'Help text on the enrolment pages',
    'portal_tries': 'Wrong passwords on the enrolment pages before a pause',
    'portal_wait_min': '...and the pause (min)',
    'session_hours': 'A sign-in lasts (h)',
    'session_idle_min': '...and may sit untouched (min)',
    'login_tries': 'Wrong passwords before a pause',
    'login_wait_min': '...and the pause (min)',
    'admin_directory': 'Sign administrators in against the directory',
    'admin_group_full': 'Group of full administrators',
    'admin_group_token': 'Group of token administrators',
    'admin_group_readonly': 'Group of read-only accounts',
    'isemon': 'Send the logs to isemon',
    'isemon_targets': 'isemon’s syslog receivers',
    'isemon_hostname': 'The name this machine is written under',
    'isemon_detail': 'Send the RADIUS packets as well (radius-detail)',
    'isemon_events': 'Send this daemon’s own events as well',
    'isemon_max_bytes': 'Longest message (bytes)',
    'ship_files': 'Write the same lines into files here too',
    'retain_radius_days': 'Keep the RADIUS requests (days)',
    'retain_otp_days': 'Keep the token checks (days)',
    'retain_events_days': 'Keep the events (days)',
    'backup_daily': 'A copy of the database every day',
    'backup_keep': 'Copies kept',
    'backup_at': 'At',
    'db_engine': 'The database',
    'db_host': 'Server',
    'db_port': 'Port',
    'db_name': 'Database name',
    'db_user': 'Account',
    'db_password': 'Password',
    'db_timeout_s': 'Connect timeout (s)',
    'db_tls': 'Encryption to the database server',
    'db_tls_ca': 'Its certificate authority (file)',
    'node_name': 'The name of this node',
    'site_name': 'What to call this installation',
    'ui_lang': 'Language of the pages',
    'api_port': 'API port (localhost)',
    'debug': 'Debug log',
    'debug_radius': '...every RADIUS request step by step',
    'debug_ldap': '...every question asked of the directory',
    'debug_api': '...every API call',
}

SAYS = {
    'mail_mode': 'How a token’s mail leaves this machine: through your mail server, or '
                 'straight to the server of each recipient’s domain (its MX record) with no '
                 'relay - which only works where port 25 may go out and the receiving side '
                 'trusts this machine (SPF, a reverse DNS name).',
    'smtp_host': 'The mail server’s name or address: smtp.example.cz, or a relay in your '
                 'network. Its name is what its certificate is checked against.',
    'smtp_port': '0 picks the usual one for the encryption: 587 for STARTTLS, 465 for TLS, '
                 '25 for none.',
    'smtp_security': 'STARTTLS on 587 is what most servers want; SMTPS on 465 is TLS from '
                     'the first byte; none sends everything - the password too - in the '
                     'clear, for a relay inside your own network only.',
    'smtp_auth': 'How this machine signs in to the server. None where the relay lets this '
                 'address send by itself. XOAUTH2 (Microsoft 365, Google): the password is '
                 'an access token.',
    'smtp_user': 'The account it signs in with - often the whole address.',
    'smtp_password': 'Its password (or the OAuth access token for XOAUTH2). Kept in the '
                     'database sealed with the key that seals the tokens.',
    'smtp_verify': 'Off is for a test: a server whose certificate is not checked is one '
                   'anybody on the path can pretend to be. A certificate signed by your own '
                   'authority is trusted once that authority is added below.',
    'smtp_timeout_s': 'How long to wait for the server to answer.',
    'mail_from': 'The sender’s address. Your mail server may allow only its own '
                 'addresses; going direct, the domain should have this machine in its SPF.',
    'mail_from_name': 'The name beside it, as the recipient sees it. Empty: the name of '
                      'this installation.',
    'mail_reply_to': 'Where a reply goes - a helpdesk, say. Empty: back to the sender.',
    'mail_helo': 'The name this machine greets the server with. Empty: its own full name. '
                 'Going direct, it should be the name its address resolves back to.',
    'mail_dns': 'Going direct: the DNS servers asked where each recipient’s domain takes its mail '
                '(its MX record), separated by commas - 1.1.1.1, 8.8.8.8. Empty: the ones in '
                '/etc/resolv.conf. Only for a machine whose own resolver will not answer that.',
    'mail_direct_tls': 'Going direct: whether a server that offers no STARTTLS still gets the '
                       'mail, in the clear. Required is safer - a token\'s mail holds its key, '
                       'and anybody on the way can strip the offer - but a domain whose server '
                       'has no TLS then gets nothing.',
    'mail_direct_port': 'Going direct: the port of the recipients’ servers. It is 25 '
                        'everywhere; another only to test against a server of your own.',
    'mail_lang': 'The language a token’s mail is written in unless it is chosen when the '
                 'token is made.',
    'mail_codes': 'Whether the recovery codes go in the mail as well unless chosen when '
                  'the token is made. Each signs in once in place of a code from the phone.',
    'default_realm': 'The realm a name written without one belongs to: novak is taken as '
                     'novak@ this, on the enrolment pages and in RADIUS requests from a client '
                     'that adds no realm of its own - and novak@this works as well. Every other '
                     'realm still needs its @domain. Empty: a name has to be written whole.',
    'admin_show_key': 'A full administrator may open a token and show its QR code and key - '
                      'for somebody whose phone cannot scan the page, or to set the same '
                      'token up again. Whoever has the key can make the codes, so every look '
                      'is written down as an event. Off: nobody sees a key after it is made.',
    'radius_bind': 'The address the RADIUS server listens on. <code>0.0.0.0</code> is every '
                   'IPv4 address this machine has; <code>::</code> every IPv6 one as well. '
                   'Changed, the server starts listening on the new one at once.',
    'radius_auth_port': 'UDP port for Access-Request. 1812 is the standard one; the old '
                        '1645 still turns up on Cisco kit.',
    'radius_acct_port': 'UDP port for Accounting-Request. The records are written down and '
                        'sent to isemon with the rest; 0 does not listen for them at all.',
    'radius_status_server': 'Answer Status-Server (RFC 5997), which is how an ASA or a '
                            'load balancer asks whether this server is alive without signing '
                            'anybody in.',
    'radius_reply_ma': 'Put a Message-Authenticator on every answer. It protects the answer '
                       'against the BlastRADIUS forgery (CVE-2024-3596) and costs nothing; '
                       'only a client too old to know the attribute minds it.',
    'radius_dup_window_s': 'A client that hears nothing sends the same request again, with '
                           'the same identifier. Within this window it gets the same answer '
                           'again rather than a second check of the code - which would '
                           'fail, because a code works only once.',
    'radius_workers': 'How many requests are worked on side by side. A request that waits '
                      'for a slow domain controller does not hold up the others.',
    'radius_unknown_log': 'A request from an address that is not one of the clients is '
                          'dropped without an answer, as RADIUS says it must be. Switched '
                          'on, it is also written down - once a minute per address - so '
                          'that a VPN pointed here before it was added says so.',
    'radius_reject_delay_ms': 'How long to wait before sending a refusal. A little slows '
                              'down somebody guessing; 0 answers at once.',
    'totp_issuer': 'The name above the code in the phone application - the company, usually. '
                   'Only a token enrolled after a change carries the new one.',
    'totp_label': 'The account name under it. <code>{user}</code> is the whole name as it '
                  'was enrolled (<code>novak@example.cz</code>), <code>{name}</code> the part '
                  'before the @.',
    'totp_digits': 'Six is what everybody expects and what every application shows. Only for '
                   'tokens made from now on: each token keeps the length it was made with, so '
                   'imported and older ones go on working beside new ones. Microsoft '
                   'Authenticator shows six whatever this says - with 8 its codes are refused.',
    'totp_period': 'Thirty seconds is the standard, and Google Authenticator knows no other. '
                   'Only for tokens made from now on; each keeps its own.',
    'totp_algorithm': 'SHA-1 is what RFC 6238 says and what every application implements - and '
                      'it is not weak here: the key is 160 random bits. Only for tokens made '
                      'from now on; each keeps its own, so imported SHA-1 tokens go on working '
                      'beside new ones. Microsoft Authenticator and Google Authenticator on '
                      'Android ignore SHA-256 and SHA-512 and make SHA-1 codes, which are then '
                      'refused: those two are for hardware tokens and applications that take '
                      'them (FreeOTP, Google Authenticator on iPhone).',
    'totp_window': 'How many periods either side of now a code is still taken in. 1 is '
                   'thirty seconds of a phone’s clock being wrong either way; 0 takes '
                   'only the code of this very period. A code from a neighbouring period '
                   'is written down as such, so a phone whose clock is drifting shows up.',
    'totp_disallow_reuse': 'Once a code has been used it is refused if it comes again - even '
                           'inside its thirty seconds. This is what makes the code one-time; '
                           'switched off it can be replayed by anybody who saw it.',
    'rate_limit_tries': 'This many wrong codes for one token inside the time below, and every '
                        'code - right ones included - is refused until it has passed. 0 '
                        'switches it off.',
    'lockout_after': 'Wrong codes one after another - however slowly they come - after which '
                     'the token takes no code at all for the time below, and again after each '
                     'further one. The pause above stops a quick guesser; this one stops a slow '
                     'one, who would otherwise get thousands of guesses a day. A right code '
                     'starts the count again; Forget them on the token ends it at once. 0 '
                     'switches it off.',
    'lockout_min': 'How long a token takes no code once it has been locked out.',
    'radius_reject_reason': 'Off: a refusal goes back with no reason in it, and the reason is '
                            'only in the log here. On: the reason goes back as a Reply-Message, '
                            'which a VPN may show to whoever is signing in - telling a '
                            'stranger whether a name has a token, or that the code was right '
                            'and the password not.',
    'radius_ma_sticky': 'A client that has once sent a right Message-Authenticator must send '
                        'one with every request from then on: one that arrives without is '
                        'dropped (BlastRADIUS, CVE-2024-3596). Remembered until the service '
                        'restarts; Must send a Message-Authenticator on the client holds it '
                        'always.',
    'rate_limit_s': 'The time over which the wrong codes are counted, and which has to pass '
                    'before the token takes codes again.',
    'scratch_count': 'One-off codes made with each token, for the day the phone is lost. '
                     'Each works once, in place of a code from the phone. 0 makes none.',
    'scratch_digits': 'How long a recovery code is. Longer than a code from the phone, so '
                      'the two are never mistaken for each other.',
    'token_names_case': 'Whether <code>Novak@example.cz</code> and <code>novak@example.cz'
                        '</code> are one token. Active Directory does not care, and neither '
                        'should this, unless something else forces it to.',
    'portal': 'The pages where people enrol their own token. Switched off they say so and '
              'let nobody in; administrators can still enrol anybody here.',
    'portal_title': 'The heading on every enrolment page and the title of the browser tab. Empty: One-time passwords, in the language of the page.',
    'portal_realm': 'A name typed without an @ gets this added before it is looked up: '
                    '<code>novak</code> becomes <code>novak@example.cz</code>. Empty: the '
                    'name has to be typed whole.',
    'portal_hint': 'One line under the sign-in boxes saying what to type, such as '
                   '<code>login@example.cz</code>.',
    'portal_who': 'Who may enrol a token. <b>The realm’s group filter</b> is the same '
                  'test the VPN applies, so nobody can enrol a token they could never use.',
    'portal_groups': 'With <i>members of the groups named below</i>: the groups, by name '
                     '(<code>VPN_USERS</code>) or by whole DN, separated by semicolons or new '
                     'lines.',
    'portal_confirm': 'A token made on the enrolment page is not in use until the person has '
                      'typed a code from it. Without this a QR code scanned badly - or not '
                      'at all - is a token that locks its owner out on the next sign-in.',
    'portal_reissue': 'Somebody who already has a token may replace it themselves, with '
                      'their password and a code from the old one (or a recovery code). '
                      'Somebody who lost both has to ask an administrator.',
    'portal_show_secret': 'The key written out as letters as well, for typing into an '
                          'application on a machine with no camera.',
    'portal_scratch': 'Show the recovery codes to the person who enrolled. Off: they are '
                      'still made, and only an administrator can see new ones.',
    'portal_session_min': 'How long somebody stays signed in on the enrolment pages. Short, '
                          'because the page holds a key that is somebody’s second factor.',
    'portal_help': 'Words shown on the enrolment pages under the title: where to get the '
                   'application, whom to ring. Plain text; an empty line starts a new '
                   'paragraph.',
    'portal_tries': 'Wrong passwords from one address on the enrolment pages before it has '
                    'to wait.',
    'portal_wait_min': 'How long it waits.',
    'session_hours': 'How long an administrator stays signed in, however busy.',
    'session_idle_min': 'How long a sign-in may sit without anything being asked before it '
                        'has to be done again.',
    'login_tries': 'Wrong passwords from one address before it has to wait.',
    'login_wait_min': 'How long it waits.',
    'admin_directory': 'The directory (by its name under <i>Active Directory</i>) the '
                       'administration pages sign people in against. Empty: only the '
                       'accounts made here. Whoever signs in from it gets the role of the '
                       'first group below they are in, and nobody in none of them gets in.',
    'admin_group_full': 'Members may change everything. By name or by whole DN.',
    'admin_group_token': 'Members may look at everything and look after people’s tokens.',
    'admin_group_readonly': 'Members may look at everything and change nothing.',
    'isemon': 'Send every check of a code and every RADIUS packet to isemon, as syslog, in '
              'the very shape a totpcgi token server and its FreeRADIUS write - so isemon '
              'reads it with what it already has (<i>Settings → The OTP logs</i>, with '
              '<i>RADIUS detail</i> switched on).',
    'isemon_targets': 'Where to send them: <code>host</code>, <code>host:port</code>, '
                      'and <code>/udp</code> or <code>/tcp</code> after it - '
                      '<code>10.1.2.3:514/tcp</code>. Several, separated by commas. UDP is the '
                      'default; TCP does not lose a line when the network does.',
    'isemon_hostname': 'The host name on every line, which is the folder isemon’s rsyslog '
                       'files them under: <code>/var/log/remote/<this>/totp.cgi.log</code>. '
                       'isemon looks in <code>/var/log/remote/otp</code> unless told otherwise, '
                       'so <code>otp</code> needs nothing changed there. Empty: this machine’s '
                       'own short name.',
    'isemon_detail': 'The RADIUS packet behind every check - the person’s own address, '
                     'the device, the tunnel group - as <code>radius-detail</code> lines. isemon '
                     'puts them beside the check of the code.',
    'isemon_events': 'This daemon’s own events as well (a token made, a setting '
                     'changed), as <code>otp</code> lines. isemon does not read those; they '
                     'are for whatever else collects the syslog.',
    'isemon_max_bytes': 'A message longer than this is cut, with <code>...TRUNCATED</code> at '
                        'the end. rsyslog cuts at 2048 bytes over UDP unless '
                        '<code>$MaxMessageSize</code> says more on both machines.',
    'ship_files': 'The very same lines go into <code>/var/log/otp/totp.cgi.log</code> and '
                  '<code>/var/log/otp/radius-detail.log</code> as well, whether or not they are '
                  'sent. Something on this machine can then forward them, and they are there '
                  'to read when the network is not.',
    'retain_radius_days': 'How long every RADIUS request is kept. 0 keeps them for ever.',
    'retain_otp_days': 'How long every check of a code is kept. 0 keeps them for ever.',
    'retain_events_days': 'How long the events are kept. 0 keeps them for ever.',
    'backup_daily': 'A copy of the database once a day, into <code>/var/lib/otp/backups'
                    '</code>, with the key that opens the tokens beside it.',
    'backup_keep': 'How many of those copies are kept; the oldest goes first.',
    'backup_at': 'When, as <code>HH:MM</code> on this machine’s clock.',
    'db_engine': 'Where everything is kept: the tokens, the clients, the realms, the '
                 'settings, the logs. A file on this machine needs nothing; MariaDB and '
                 'PostgreSQL need their server and their Python driver.',
    'db_host': 'The database server’s address.',
    'db_port': '0 is the engine’s usual one: 3306 or 5432.',
    'db_name': 'The database on that server. It has to exist; the tables are made in it.',
    'db_user': 'The account this daemon signs in to the database with.',
    'db_password': 'Its password.',
    'db_timeout_s': 'How long to wait for the server before saying it cannot be reached.',
    'db_tls': 'TLS to a database on another machine, and to the other node. Empty: as the '
              'driver decides - encrypted where the server offers it, and nothing stops '
              'somebody on the way from saying it does not. require: always encrypted. '
              'verify-full: encrypted, and the server\'s certificate checked against the '
              'authority below and the host name - the only one that stops somebody in '
              'between. The server must have TLS switched on.',
    'db_tls_ca': 'The file of the authority that signed the database server\'s certificate, '
                 'for verify-ca and verify-full: /etc/otp/db-ca.pem.',
    'node_name': 'What this server is called among the nodes of a cluster - in the list of nodes, in its events and on the pages it answers. Kept in config.json, since it belongs to this machine and not to the database both share. Empty: the machine\'s own name.',
    'site_name': 'The name at the top of the administration pages. Empty: the machine’s '
                 'own name.',
    'ui_lang': 'The language every page opens in until somebody chooses another for '
               'themselves.',
    'api_port': 'The port on 127.0.0.1 the web pages ask this daemon on. It has to be the '
                'same in <code>otp-api.php</code>.',
    'debug': 'Write everything into <code>/var/log/otp/otp.log</code>. Loud: for finding '
             'something out, not for leaving on.',
    'debug_radius': 'Every request, every step of its decision.',
    'debug_ldap': 'Every question asked of a directory and how many answers came back. Never '
                  'a password.',
    'debug_api': 'Every API call the web pages make.',
}

# Which settings sit on which page of Settings, in order. A setting the
# daemon knows and this does not name lands on "Everything else".
PANES = {
    'realms': ['default_realm'],
    'radius': ['radius_bind', 'radius_auth_port', 'radius_acct_port', 'radius_status_server',
               'radius_reply_ma', 'radius_dup_window_s', 'radius_workers',
               'radius_unknown_log', 'radius_reject_delay_ms', 'radius_reject_reason',
               'radius_ma_sticky'],
    'tokens': ['totp_issuer', 'totp_label', 'totp_digits', 'totp_period', 'totp_algorithm',
               'totp_window', 'totp_disallow_reuse', 'rate_limit_tries', 'rate_limit_s',
               'lockout_after', 'lockout_min', 'admin_show_key',
               'scratch_count', 'scratch_digits', 'token_names_case'],
    'portal': ['portal', 'portal_title', 'portal_realm', 'portal_hint', 'portal_who',
               'portal_groups', 'portal_confirm', 'portal_reissue', 'portal_show_secret',
               'portal_scratch', 'portal_session_min', 'portal_tries', 'portal_wait_min',
               'portal_help'],
    'isemon': ['isemon', 'isemon_targets', 'isemon_hostname', 'isemon_detail',
               'isemon_events', 'isemon_max_bytes', 'ship_files'],
    'people': ['session_hours', 'session_idle_min', 'login_tries', 'login_wait_min',
               'admin_directory', 'admin_group_full', 'admin_group_token',
               'admin_group_readonly'],
    'db': ['db_engine', 'db_host', 'db_port', 'db_name', 'db_user', 'db_password',
           'db_timeout_s', 'db_tls', 'db_tls_ca', 'backup_daily', 'backup_keep', 'backup_at',
           'retain_radius_days', 'retain_otp_days', 'retain_events_days'],
    'ha': ['node_name'],
    'mail': ['mail_mode', 'smtp_host', 'smtp_port', 'smtp_security', 'smtp_auth', 'smtp_user',
             'smtp_password', 'smtp_verify', 'smtp_timeout_s', 'mail_direct_port', 'mail_direct_tls', 'mail_dns', 'mail_from',
             'mail_from_name', 'mail_reply_to', 'mail_helo', 'mail_lang', 'mail_codes'],
    'about': ['site_name', 'ui_lang', 'api_port', 'debug', 'debug_radius', 'debug_ldap',
              'debug_api'],
}

# A setting that only means something while another one says so. Shown
# greyed out with the reason beside it, as on isemon.
ONLY_WHEN = {
    'portal_title': ['portal', '1'], 'portal_realm': ['portal', '1'],
    'portal_hint': ['portal', '1'], 'portal_who': ['portal', '1'],
    'portal_groups': ['portal_who', 'groups'], 'portal_confirm': ['portal', '1'],
    'portal_reissue': ['portal', '1'], 'portal_show_secret': ['portal', '1'],
    'portal_scratch': ['portal', '1'], 'portal_session_min': ['portal', '1'],
    'portal_help': ['portal', '1'], 'portal_tries': ['portal', '1'],
    'portal_wait_min': ['portal', '1'],
    'isemon_targets': ['isemon', '1'], 'isemon_hostname': ['isemon', '1'],
    'isemon_detail': ['isemon', '1'], 'isemon_events': ['isemon', '1'],
    'isemon_max_bytes': ['isemon', '1'],
    'admin_group_full': ['admin_directory', '*'], 'admin_group_token': ['admin_directory', '*'],
    'admin_group_readonly': ['admin_directory', '*'],
    'db_host': ['db_engine', 'sqlite-not'], 'db_port': ['db_engine', 'sqlite-not'],
    'db_name': ['db_engine', 'sqlite-not'], 'db_user': ['db_engine', 'sqlite-not'],
    'db_password': ['db_engine', 'sqlite-not'], 'db_timeout_s': ['db_engine', 'sqlite-not'],
    'backup_keep': ['backup_daily', '1'], 'backup_at': ['backup_daily', '1'],
    'debug_radius': ['debug', '1'], 'debug_ldap': ['debug', '1'], 'debug_api': ['debug', '1'],
    'smtp_host': ['mail_mode', 'smtp'], 'smtp_port': ['mail_mode', 'smtp'],
    'smtp_security': ['mail_mode', 'smtp'], 'smtp_auth': ['mail_mode', 'smtp'],
    'smtp_user': ['smtp_auth', 'none-not'], 'smtp_password': ['smtp_auth', 'none-not'],
    'smtp_verify': ['mail_mode', 'off-not'], 'smtp_timeout_s': ['mail_mode', 'off-not'],
    'mail_direct_port': ['mail_mode', 'direct'], 'mail_dns': ['mail_mode', 'direct'], 'mail_direct_tls': ['mail_mode', 'direct'], 'mail_from': ['mail_mode', 'off-not'],
    'mail_from_name': ['mail_mode', 'off-not'], 'mail_reply_to': ['mail_mode', 'off-not'],
    'mail_helo': ['mail_mode', 'off-not'], 'mail_lang': ['mail_mode', 'off-not'],
    'mail_codes': ['mail_mode', 'off-not'],
}

CONFIG = dict(DEFAULTS)
FILE_CONFIG = dict(DEFAULTS)
FILE_KEYS = set()
FROM_ARGV = {}
BAD_CONFIG = []


class BadSetting(ValueError):
    """A value that cannot be read as the setting it was given for."""


def _coerce(current, value):
    """A value made to look like the default beside it - or refused.

    Refused rather than quietly replaced, as on isemon: a setting nobody can
    read must be a setting nobody accepts, so that what runs is either what
    was asked for or plainly said to be otherwise.
    """
    if isinstance(current, bool):
        if isinstance(value, str):
            said = value.strip().lower()
            if said in ('1', 'true', 'yes', 'on'):
                return True
            if said in ('0', 'false', 'no', 'off', ''):
                return False
            raise BadSetting('%r is not yes or no' % value)
        if value is None:
            raise BadSetting('a yes-or-no setting cannot be nothing')
        return bool(value)
    if isinstance(current, int):
        if value is None or (isinstance(value, str) and not value.strip()):
            raise BadSetting('a number is needed, and nothing was given')
        if isinstance(value, bool):
            return int(value)
        try:
            return int(float(value))
        except (TypeError, ValueError, OverflowError):
            raise BadSetting('%r is not a number' % (value,))
    if isinstance(current, list):
        if isinstance(value, str):
            return [p.strip() for p in re.split(r'[,;\n\r]', value) if p.strip()]
        if isinstance(value, (list, tuple)):
            return list(value)
        raise BadSetting('%r is not a list' % (value,))
    if isinstance(current, str):
        if value is None:
            raise BadSetting('nothing was given')
        if isinstance(value, (list, tuple)):
            return ', '.join(str(one).strip() for one in value if str(one).strip())
        if isinstance(value, (dict, set)):
            raise BadSetting('%r is not something this setting can hold' % (value,))
        if isinstance(value, bool):
            return 'yes' if value else ''
        return str(value)
    return value


def check_setting(key, value):
    """The value as it will be kept, or BadSetting saying why not."""
    if key not in DEFAULTS:
        raise BadSetting('%s is not a setting this version knows' % key)
    got = _coerce(DEFAULTS[key], value)
    shape = TUNABLE.get(key)
    if isinstance(shape, tuple) and shape and isinstance(shape[0], str):
        if str(got) not in shape:
            raise BadSetting('%s: %r is not one of %s' % (key, got, ', '.join(shape)))
    elif isinstance(shape, tuple) and len(shape) == 2:
        if not (shape[0] <= int(got) <= shape[1]):
            raise BadSetting('%s must be between %d and %d' % (key, shape[0], shape[1]))
    if key == 'backup_at' and not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', str(got).strip()):
        raise BadSetting('backup_at is a time of day, written HH:MM')
    # What reaches a command line, an option file or pg_hba.conf (1.0.33):
    # a database name like --result-file=/x was an option to mariadb-dump,
    # and a new line in a password a line of its own in the option file.
    if key in ('db_name', 'db_user') and str(got).strip() and \
            not re.match(r'^[A-Za-z_][A-Za-z0-9_]{0,62}$', str(got).strip()):
        raise BadSetting('%s: letters, digits and _ only, starting with a letter' % key)
    if key in ('db_host', 'ha_address', 'ha_peer') and str(got).strip() and \
            not re.match(r'^[A-Za-z0-9_:\[][A-Za-z0-9_.:%\[\]-]{0,252}$|^/[A-Za-z0-9/._-]{1,200}$',
                         str(got).strip()):
        raise BadSetting('%s: a host name, an address, or the path of a socket' % key)
    if key in SECRET_KEYS and any(ord(ch) < 32 or ord(ch) == 127 for ch in str(got or '')):
        raise BadSetting('%s: no line breaks or other control characters' % key)
    if key == 'radius_bind':
        try:
            ipaddress.ip_address(str(got).strip())
        except ValueError:
            raise BadSetting('radius_bind: %r is not an address' % got)
    if key == 'mail_dns':
        for one in [w for w in re.split(r'[\s,;]+', str(got)) if w]:
            try:
                ipaddress.ip_address(one)
            except ValueError:
                raise BadSetting('mail_dns: %r is not the address of a DNS server' % one)
    if key == 'isemon_targets':
        for one in syslog_targets(str(got), strict=True):
            pass
    if key == 'totp_label' and '{user}' not in str(got) and '{name}' not in str(got):
        raise BadSetting('totp_label needs {user} or {name} in it, or every token on a '
                         'phone has the same name')
    if key in ('isemon_hostname',) and str(got).strip() \
            and not re.match(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,62}$', str(got).strip()):
        raise BadSetting('isemon_hostname: a host name has letters, digits, dots and '
                         'dashes and nothing else')
    return got


def load_config(path=None, saved=None):
    """The defaults, with config.json over them and anything saved over that."""
    global CONFIG, FILE_CONFIG, FILE_KEYS
    where = Path(path) if path else CONFIG_FILE
    fresh = dict(DEFAULTS)
    named, refused, unknown = set(), [], []
    try:
        with open(where, encoding='utf-8') as f:
            given = json.load(f)
        if not isinstance(given, dict):
            raise ValueError('the config file is not an object')
        for key, value in given.items():
            if key in fresh:
                try:
                    fresh[key] = _coerce(fresh[key], value)
                    named.add(key)
                except BadSetting as bad:
                    refused.append('%s (%s)' % (key, bad))
            elif not key.startswith('_'):
                unknown.append(key)
    except FileNotFoundError:
        pass
    except (ValueError, OSError) as e:
        sys.stderr.write('otp: %s could not be read (%s); the defaults are in use\n'
                         % (where, e))
    FILE_CONFIG = dict(fresh)
    FILE_KEYS = named
    whole = dict(fresh)
    if saved:
        for key, value in saved.items():
            if key in DEFAULTS and key not in FILE_ONLY_KEYS:
                try:
                    whole[key] = _coerce(DEFAULTS[key], value)
                except BadSetting:
                    pass
        me = this_node_name(fresh)
        for key in NODE_KEYS:
            if key + '@' + me in saved:
                try:
                    whole[key] = _coerce(DEFAULTS[key], saved[key + '@' + me])
                except BadSetting:
                    pass
    whole.update(FROM_ARGV)
    CONFIG = whole
    if unknown:
        sys.stderr.write('otp: %s holds settings this version does not know: %s\n'
                         % (where, ', '.join(sorted(unknown)[:12])))
    BAD_CONFIG[:] = sorted(refused)
    return CONFIG


def write_replacing(path, text, mode=0o640):
    """A file written beside itself and renamed over: never half of one."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(text)
        os.chmod(tmp, mode)
        os.replace(tmp, str(path))
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path


def write_file_settings(changes, path=None):
    """Change a few settings in config.json and leave the rest of it alone.
    Only the database's own address lives there; everything else is saved
    in the database."""
    where = Path(path) if path else CONFIG_FILE
    had = {}
    try:
        with open(where, encoding='utf-8') as f:
            got = json.load(f)
        if not isinstance(got, dict):
            raise ValueError('it is not an object')
        had = got
    except FileNotFoundError:
        had = {}
    except ValueError as e:
        raise OSError('%s is there but cannot be read (%s); put it right first - nothing '
                      'was written to it' % (where, str(e)[:120]))
    for key, value in changes.items():
        if key not in DEFAULTS:
            continue
        if value == DEFAULTS[key]:
            had.pop(key, None)
        else:
            had[key] = value
    try:
        was = os.stat(where)
        mode = (was.st_mode & 0o770) or 0o640
    except OSError:
        mode = 0o640
    write_replacing(where, json.dumps(had, indent=2, sort_keys=True, ensure_ascii=False)
                    + '\n', mode)
    return where


# ---------------------------------------------------------------------------
# Secrets kept in the database, sealed
# ---------------------------------------------------------------------------
# The tokens' keys, the RADIUS clients' shared secrets and the directories'
# passwords are kept in the database - sealed, with a key in a file of its
# own in the state directory, exactly as isemon seals its passwords. A copy of
# the database alone opens none of them; the daily copy is made with the key
# beside it, because a database of tokens without the key that opens them is
# a database of nothing, and every person in it would have to enrol again.
# Built from HMAC-SHA256 alone - a keystream and a tag - because the standard
# library has no cipher and this must not need anything installed.
SEALED = 'sealed:1:'


def scrub_secret(text):
    """Words that may carry a database password (a conninfo in an error, say)
    with the password taken out, before they are logged or shown."""
    # A quoted value whole, up to the quote a space or the end follows (so
    # one with spaces, \' or SQL's '' inside goes too); otherwise up to the
    # next space - taking a quote with it rather than leaving a letter of
    # the password behind.
    return re.sub(r"(password\s*=\s*)('.*?'(?=\s|$)|\S+)", r'\1***', str(text or ''),
                  flags=re.I | re.S)


def sealing_key_path():
    return Path(STATE_DIR) / 'secrets.key'


_KEY_CACHE = {}
_KEY_LOCK = threading.Lock()


def sealing_key(make=False):
    """The key every secret in the database is sealed with. Read once and
    kept while the file is unchanged (1.0.33) - it was read from disk for
    every secret opened, every token in a list of thousands. Made only where
    there is none, and then with O_EXCL, so two processes starting at once
    cannot each make one of their own."""
    path = sealing_key_path()
    try:
        st = os.stat(str(path))
        stamp = (st.st_mtime_ns, st.st_size, st.st_ino)
    except FileNotFoundError:
        stamp = None
    except OSError:
        stamp = 'unreadable'
    if stamp is not None and stamp != 'unreadable':
        got = _KEY_CACHE.get(str(path))
        if got and got[0] == stamp:
            return got[1]
    try:
        key = bytes.fromhex(path.read_text(encoding='ascii').strip())
    except FileNotFoundError:
        key = None
    except (OSError, ValueError):
        key = b''
    if key and len(key) == 32:
        if stamp and stamp != 'unreadable':
            _KEY_CACHE[str(path)] = (stamp, key)
        return key
    if not make:
        return b''
    if key is not None:
        raise OSError('%s is there but cannot be read as a key - it is never replaced, '
                      'because every token sealed with it would be lost' % path)
    with _KEY_LOCK:
        key = secrets.token_bytes(32)
        try:
            fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            # Made by somebody else a moment ago: theirs is the key.
            return sealing_key(make=False) or b''
        with os.fdopen(fd, 'w', encoding='ascii') as f:
            f.write(key.hex() + '\n')
            f.flush()
            os.fsync(f.fileno())
        try:
            if os.geteuid() == 0:
                st = os.stat(str(path.parent))
                os.chown(str(path), st.st_uid, st.st_gid)
        except OSError:
            pass
        log('a new key to seal secrets with was made: %s - keep a copy of it beside every '
            'copy of the database' % path, 'warn')
    return key


def _seal_stream(key, nonce, size):
    out = bytearray()
    block = 0
    while len(out) < size:
        out += hmac.new(key, b'stream' + nonce + block.to_bytes(8, 'big'),
                        hashlib.sha256).digest()
        block += 1
    return bytes(out[:size])


SEALED2 = 'sealed:2:'
# Set once every token's secrets carry the name they belong to (1.0.33): from
# then on a secret of a token sealed the old way, without it, is not opened.
BIND_STRICT = {'tokens': False}


def token_bind(name):
    """What a token's sealed secrets are tied to: its name. Copied into
    another token's row, they no longer open (1.0.33)."""
    return 'token:' + str(name or '').strip().lower()


def seal_secret(text, bind=None):
    """Sealed with the key of this installation: a keystream from HMAC-SHA256,
    then a tag over it. With `bind`, the tag covers that too (sealed:2:), so
    the value opens only where it was sealed for."""
    key = sealing_key(make=True)
    if not key:
        raise OSError('no key to seal with')
    data = str(text).encode('utf-8')
    nonce = secrets.token_bytes(16)
    hide = hmac.new(key, b'hide', hashlib.sha256).digest()
    sign = hmac.new(key, b'sign', hashlib.sha256).digest()
    body = bytes(a ^ b for a, b in zip(data, _seal_stream(hide, nonce, len(data))))
    if bind is not None:
        tag = hmac.new(sign, b'2|' + str(bind).encode('utf-8') + b'|' + nonce + body,
                       hashlib.sha256).digest()[:16]
        return SEALED2 + base64.urlsafe_b64encode(nonce + body + tag).decode('ascii')
    tag = hmac.new(sign, nonce + body, hashlib.sha256).digest()[:16]
    return SEALED + base64.urlsafe_b64encode(nonce + body + tag).decode('ascii')


def unseal_secret(value, bind=None):
    """The secret back, or None where this machine's key is not the one it was
    sealed with - or, for one bound to a place, where it is not that place. A
    value never sealed is given back as it is."""
    if not isinstance(value, str):
        return value
    if value.startswith(SEALED2):
        v2, prefix = True, SEALED2
    elif value.startswith(SEALED):
        v2, prefix = False, SEALED
    else:
        return value
    if not v2 and bind is not None and str(bind).startswith('token:') and \
            BIND_STRICT.get('tokens'):
        return None
    if v2 and bind is None:
        return None
    key = sealing_key()
    try:
        raw = base64.urlsafe_b64decode(value[len(prefix):].encode('ascii'))
    except (ValueError, TypeError):
        return None
    if not key or len(raw) < 32:
        return None
    nonce, body, tag = raw[:16], raw[16:-16], raw[-16:]
    sign = hmac.new(key, b'sign', hashlib.sha256).digest()
    signed = (b'2|' + str(bind).encode('utf-8') + b'|' if v2 else b'') + nonce + body
    if not hmac.compare_digest(tag, hmac.new(sign, signed, hashlib.sha256).digest()[:16]):
        return None
    hide = hmac.new(key, b'hide', hashlib.sha256).digest()
    try:
        return bytes(a ^ b for a, b in zip(body, _seal_stream(hide, nonce, len(body)))
                     ).decode('utf-8')
    except UnicodeDecodeError:
        return None


# ---------------------------------------------------------------------------
# The log this daemon writes about itself
# ---------------------------------------------------------------------------
_LOG_FILE = None
_LOG_LOCK = threading.Lock()
_LOG_TO_STDERR = True


def log_open():
    global _LOG_FILE
    with _LOG_LOCK:
        try:
            if _LOG_FILE:
                _LOG_FILE.close()
        except OSError:
            pass
        _LOG_FILE = None
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            _LOG_FILE = open(LOG_DIR / 'otp.log', 'a', encoding='utf-8')
        except OSError:
            _LOG_FILE = None


def log(words, level='info'):
    line = '%s %-5s %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), level, words)
    with _LOG_LOCK:
        if _LOG_FILE:
            try:
                _LOG_FILE.write(line + '\n')
                _LOG_FILE.flush()
            except OSError:
                pass
        if _LOG_TO_STDERR and (level != 'debug' or CONFIG.get('debug')):
            try:
                sys.stderr.write(line + '\n')
                sys.stderr.flush()
            except (OSError, ValueError):
                pass


def debugging(what):
    return bool(CONFIG.get('debug')) and bool(CONFIG.get('debug_' + what, 1))


def log_tail(lines=400):
    path = LOG_DIR / 'otp.log'
    try:
        with open(path, 'rb') as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 400 * 1024))
            got = f.read().decode('utf-8', 'replace').splitlines()
        return got[-int(lines):]
    except OSError as e:
        return ['%s cannot be read: %s' % (path, e)]


# ---------------------------------------------------------------------------
# Small things, said once
# ---------------------------------------------------------------------------
def now():
    return time.time()


def human_span(seconds):
    s = max(0, int(seconds or 0))
    if s < 60:
        return '%d s' % s
    if s < 3600:
        return '%d min' % (s // 60)
    if s < 86400:
        return '%d h %d min' % (s // 3600, (s % 3600) // 60)
    days = s // 86400
    return '%s %d h' % ('1 day' if days == 1 else '%d days' % days, (s % 86400) // 3600)


def stamp(ts):
    if not ts:
        return '-'
    return datetime.fromtimestamp(float(ts)).strftime('%d-%m-%Y %H:%M:%S')


def short_host():
    try:
        return socket.gethostname().split('.')[0] or 'otp'
    except OSError:
        return 'otp'


def dn_list(text):
    """Group names or DNs out of one setting: split on semicolons and new
    lines, never on commas - a DN is mostly commas."""
    if isinstance(text, (list, tuple)):
        pieces = list(text)
    else:
        pieces = re.split(r'[;\n]', str(text or ''))
    return [p.strip() for p in pieces if str(p).strip()]


def cn_of(dn):
    """`CN=VPN Users,OU=Groups,...` as `VPN Users`; a plain name as itself."""
    said = str(dn or '').strip()
    m = re.match(r'(?i)^cn=((?:\\.|[^,])*)', said)
    if m:
        return re.sub(r'\\(.)', r'\1', m.group(1)).strip()
    return said


def password_hash(password, salt=None, rounds=310000):
    salt = salt or secrets.token_bytes(16)
    got = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), salt, rounds)
    return 'pbkdf2_sha256$%d$%s$%s' % (rounds, base64.b64encode(salt).decode('ascii'),
                                       base64.b64encode(got).decode('ascii'))


def password_ok(password, stored):
    try:
        kind, rounds, salt, want = str(stored or '').split('$')
        if kind != 'pbkdf2_sha256':
            return False
        got = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'),
                                  base64.b64decode(salt), int(rounds))
        return hmac.compare_digest(got, base64.b64decode(want))
    except (ValueError, TypeError):
        return False


def password_problem(password):
    """Why a password for an account here will not do, or ''."""
    p = str(password or '')
    if len(p) < 8:
        return 'a password needs at least eight characters'
    if len(p) > 200:
        return 'that password is longer than anybody types'
    return ''


# ---------------------------------------------------------------------------
# One-time passwords: RFC 4226 (HOTP) and RFC 6238 (TOTP)
# ---------------------------------------------------------------------------
# What the phone does, done again here: the key and the number of thirty-
# second periods since 1970 go through HMAC, and six digits are cut out of the
# answer. Nothing in this needs anything but hashlib and hmac.
HASHES = {'SHA1': hashlib.sha1, 'SHA256': hashlib.sha256, 'SHA512': hashlib.sha512}


def b32_clean(text):
    """A base32 key as somebody may have written it - small letters, spaces,
    dashes, no padding - as the bytes it stands for. ValueError if it is not
    base32 at all."""
    said = re.sub(r'[\s\-]', '', str(text or '')).upper().rstrip('=')
    if not said or not re.match(r'^[A-Z2-7]+$', said):
        raise ValueError('that is not a base32 key (A-Z and 2-7)')
    pad = '=' * ((8 - len(said) % 8) % 8)
    return base64.b32decode(said + pad)


def b32_new(size=20):
    """A fresh key: 160 bits, the size RFC 4226 recommends, as base32."""
    return base64.b32encode(secrets.token_bytes(size)).decode('ascii').rstrip('=')


def hotp(key, counter, digits=6, algorithm='SHA1'):
    """The code for one counter value, as a string of `digits` digits."""
    if isinstance(key, str):
        key = b32_clean(key)
    mac = hmac.new(key, struct.pack('>Q', int(counter)),
                   HASHES.get(str(algorithm).upper(), hashlib.sha1)).digest()
    at = mac[-1] & 0x0F
    code = struct.unpack('>I', mac[at:at + 4])[0] & 0x7FFFFFFF
    return str(code % (10 ** int(digits))).zfill(int(digits))


def totp_step(when=None, period=30):
    return int((time.time() if when is None else float(when)) // int(period))


def totp(key, when=None, digits=6, period=30, algorithm='SHA1'):
    return hotp(key, totp_step(when, period), digits, algorithm)


def totp_match(key, code, when=None, digits=6, period=30, algorithm='SHA1', window=1):
    """Which period the code belongs to - its step number - or None.

    Looked for in this period first and then outwards, one step either side
    at a time, so that when two would do the nearest one is the answer.
    Compared in constant time, every one of them.
    """
    code = re.sub(r'\s', '', str(code or ''))
    if not re.fullmatch(r'[0-9]+', code, re.ASCII) or len(code) != int(digits):
        return None
    if isinstance(key, str):
        key = b32_clean(key)
    here = totp_step(when, period)
    found = None
    for off in [0] + [d for i in range(1, int(window) + 1) for d in (-i, i)]:
        if hmac.compare_digest(hotp(key, here + off, digits, algorithm), code) and found is None:
            found = here + off
    return found


def otpauth_uri(secret, label, issuer, digits=6, period=30, algorithm='SHA1'):
    """What the QR code holds: the Key URI Format every phone application
    reads (otpauth://totp/Issuer:label?secret=...&issuer=...)."""
    from urllib.parse import quote
    issuer = str(issuer or '').strip()
    who = (quote(issuer, safe='') + ':' if issuer else '') + quote(str(label), safe='@.')
    args = ['secret=' + str(secret).upper().replace('=', '')]
    if issuer:
        args.append('issuer=' + quote(issuer, safe=''))
    if str(algorithm).upper() != 'SHA1':
        args.append('algorithm=' + str(algorithm).upper())
    if int(digits) != 6:
        args.append('digits=%d' % int(digits))
    if int(period) != 30:
        args.append('period=%d' % int(period))
    return 'otpauth://totp/%s?%s' % (who, '&'.join(args))


def scratch_new(count, digits=8):
    """Recovery codes: `count` of them, `digits` long, none twice."""
    out = []
    while len(out) < int(count):
        one = ''.join(secrets.choice('0123456789') for _ in range(int(digits)))
        if one[0] != '0' and one not in out:
            out.append(one)
    return out


def _scratch_text(user, code):
    return ('%s|%s' % (str(user).lower(), str(code).strip())).encode('utf-8')


def scratch_hash(user, code, key=None):
    """A recovery code as it is kept: an HMAC of the name it belongs to and
    the code, keyed with the key the token secrets are sealed with, so the
    database holds nothing that could be typed - and nothing that a copy of
    the database alone lets anybody try codes against."""
    if key is None:
        key = sealing_key(make=True)
    return 'hmac:' + hmac.new(key, _scratch_text(user, code), hashlib.sha256).hexdigest()


def scratch_hash_old(user, code):
    """The shape before 1.0.14: a plain hash, without the key. Only read,
    never written: a hit is rewritten in the new shape."""
    return 'sha256:' + hashlib.sha256(_scratch_text(user, code)).hexdigest()


def scratch_find(user, code, kept, key=None):
    """The entry of `kept` (the list a token row holds) that is `code`, or
    None - and how that entry should be written now, which differs from the
    entry when it was kept in the old shape."""
    if key is None:
        key = sealing_key()
    new = scratch_hash(user, code, key) if key else None
    old = scratch_hash_old(user, code)
    for k in kept:
        k = str(k)
        if new is not None and hmac.compare_digest(k, new):
            return k, new
        if hmac.compare_digest(k, old):
            return k, new if new is not None else old
    return None, None


# ---------------------------------------------------------------------------
# QR codes
# ---------------------------------------------------------------------------
# The picture the phone scans, made here rather than by a package: the
# standard (ISO/IEC 18004) in byte mode, every version, every level of error
# correction, the mask chosen the way the standard says. It comes out as SVG
# for the pages and as half-block characters for a terminal.
_QR_ECC_PER_BLOCK = {
    'L': (-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28,
          28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
    'M': (-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26,
          26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28),
    'Q': (-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30,
          28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
    'H': (-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28,
          30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
}
_QR_BLOCKS = {
    'L': (-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12,
          12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25),
    'M': (-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20,
          21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49),
    'Q': (-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25,
          27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68),
    'H': (-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30,
          32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81),
}
_QR_FORMAT = {'L': 1, 'M': 0, 'Q': 3, 'H': 2}


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(len(result)):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < len(result):
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _qr_raw_modules(ver):
    result = (16 * ver + 128) * ver + 64
    if ver >= 2:
        align = ver // 7 + 2
        result -= (25 * align - 10) * align - 55
        if ver >= 7:
            result -= 36
    return result


def _qr_data_codewords(ver, ecl):
    return (_qr_raw_modules(ver) // 8
            - _QR_ECC_PER_BLOCK[ecl][ver] * _QR_BLOCKS[ecl][ver])


class QrCode(object):
    """One QR code: `modules[y][x]` is True where the square is dark."""

    def __init__(self, text, ecl='M'):
        data = text.encode('utf-8') if isinstance(text, str) else bytes(text)
        self.ecl = ecl
        for ver in range(1, 41):
            count_bits = 8 if ver <= 9 else 16
            need = 4 + count_bits + 8 * len(data)
            if need <= _qr_data_codewords(ver, ecl) * 8:
                break
        else:
            raise ValueError('that is too long for a QR code')
        self.version = ver
        self.size = ver * 4 + 17
        bits = []

        def put(value, n):
            for i in reversed(range(n)):
                bits.append((value >> i) & 1)
        put(0x4, 4)
        put(len(data), count_bits)
        for b in data:
            put(b, 8)
        capacity = _qr_data_codewords(ver, ecl) * 8
        put(0, min(4, capacity - len(bits)))
        put(0, (8 - len(bits) % 8) % 8)
        pad = 0xEC
        while len(bits) < capacity:
            put(pad, 8)
            pad ^= 0xEC ^ 0x11
        words = [int(''.join(str(b) for b in bits[i:i + 8]), 2) for i in range(0, len(bits), 8)]
        all_words = self._with_ecc(words)
        size = self.size
        self.modules = [[False] * size for _ in range(size)]
        self.function = [[False] * size for _ in range(size)]
        self._function_patterns()
        self._codewords(all_words)
        best, best_penalty = 0, None
        for mask in range(8):
            self._mask(mask)
            self._format(mask)
            penalty = self._penalty()
            if best_penalty is None or penalty < best_penalty:
                best, best_penalty = mask, penalty
            self._mask(mask)
        self._mask(best)
        self._format(best)
        self.mask = best

    # ---- the pieces ------------------------------------------------------
    def _set(self, x, y, dark):
        self.modules[y][x] = bool(dark)
        self.function[y][x] = True

    def _function_patterns(self):
        size = self.size
        for i in range(size):
            self._set(6, i, i % 2 == 0)
            self._set(i, 6, i % 2 == 0)
        for x, y in ((3, 3), (size - 4, 3), (3, size - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < size and 0 <= yy < size:
                        self._set(xx, yy, max(abs(dx), abs(dy)) not in (2, 4))
        places = self._alignment_places()
        last = len(places) - 1
        for i, a in enumerate(places):
            for j, b in enumerate(places):
                if (i == 0 and j == 0) or (i == 0 and j == last) or (i == last and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self._set(a + dx, b + dy, max(abs(dx), abs(dy)) != 1)
        self._format(0)
        if self.version >= 7:
            rem = self.version
            for _ in range(12):
                rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
            value = self.version << 12 | rem
            for i in range(18):
                bit = (value >> i) & 1
                a, b = size - 11 + i % 3, i // 3
                self._set(a, b, bit)
                self._set(b, a, bit)

    def _alignment_places(self):
        ver = self.version
        if ver == 1:
            return []
        count = ver // 7 + 2
        step = (ver * 8 + count * 3 + 5) // (count * 4 - 4) * 2
        result = [self.size - 7 - i * step for i in range(count - 1)] + [6]
        return list(reversed(result))

    def _format(self, mask):
        data = _QR_FORMAT[self.ecl] << 3 | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412
        bit = lambda i: (bits >> i) & 1
        size = self.size
        for i in range(0, 6):
            self._set(8, i, bit(i))
        self._set(8, 7, bit(6))
        self._set(8, 8, bit(7))
        self._set(7, 8, bit(8))
        for i in range(9, 15):
            self._set(14 - i, 8, bit(i))
        for i in range(0, 8):
            self._set(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self._set(8, size - 15 + i, bit(i))
        self._set(8, size - 8, True)

    def _with_ecc(self, data):
        ver, ecl = self.version, self.ecl
        blocks_n = _QR_BLOCKS[ecl][ver]
        ecc_len = _QR_ECC_PER_BLOCK[ecl][ver]
        raw = _qr_raw_modules(ver) // 8
        short_n = blocks_n - raw % blocks_n
        short_len = raw // blocks_n
        divisor = _rs_divisor(ecc_len)
        blocks = []
        k = 0
        for i in range(blocks_n):
            take = short_len - ecc_len + (0 if i < short_n else 1)
            dat = data[k:k + take]
            k += take
            ecc = _rs_remainder(dat, divisor)
            if i < short_n:
                dat = dat + [0]
            blocks.append(dat + ecc)
        out = []
        for i in range(len(blocks[0])):
            for j, blk in enumerate(blocks):
                if i != short_len - ecc_len or j >= short_n:
                    out.append(blk[i])
        return out

    def _codewords(self, data):
        size = self.size
        i = 0
        right = size - 1
        total = len(data) * 8
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(size):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = size - 1 - vert if upward else vert
                    if not self.function[y][x] and i < total:
                        self.modules[y][x] = bool((data[i >> 3] >> (7 - (i & 7))) & 1)
                        i += 1
            right -= 2

    def _mask(self, mask):
        test = (lambda x, y: (x + y) % 2 == 0,
                lambda x, y: y % 2 == 0,
                lambda x, y: x % 3 == 0,
                lambda x, y: (x + y) % 3 == 0,
                lambda x, y: (x // 3 + y // 2) % 2 == 0,
                lambda x, y: x * y % 2 + x * y % 3 == 0,
                lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
                lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0)[mask]
        for y in range(self.size):
            row, fn = self.modules[y], self.function[y]
            for x in range(self.size):
                if not fn[x] and test(x, y):
                    row[x] = not row[x]

    def _penalty(self):
        size, m = self.size, self.modules
        score = 0
        lines = [m[y] for y in range(size)] + [[m[y][x] for y in range(size)]
                                                for x in range(size)]
        finder = ([True, False, True, True, True, False, True, False, False, False, False],
                  [False, False, False, False, True, False, True, True, True, False, True])
        for line in lines:
            run, last = 0, None
            for v in line:
                if v == last:
                    run += 1
                else:
                    if run >= 5:
                        score += 3 + run - 5
                    run, last = 1, v
            if run >= 5:
                score += 3 + run - 5
            for i in range(len(line) - 10):
                seg = line[i:i + 11]
                if seg == finder[0] or seg == finder[1]:
                    score += 40
        for y in range(size - 1):
            for x in range(size - 1):
                v = m[y][x]
                if v == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    score += 3
        dark = sum(sum(1 for v in row if v) for row in m)
        total = size * size
        k = (abs(dark * 20 - total * 10) + total - 1) // total - 1
        score += k * 10
        return score

    # ---- drawn -------------------------------------------------------------
    def svg(self, scale=6, border=4, dark='#000', light='#fff'):
        """The code as an SVG picture, light squares and all - a phone needs
        the quiet zone round it, so it is part of the picture."""
        size = self.size + border * 2
        path = []
        for y in range(self.size):
            x = 0
            while x < self.size:
                if self.modules[y][x]:
                    start = x
                    while x < self.size and self.modules[y][x]:
                        x += 1
                    path.append('M%d %dh%dv1h-%dz' % (start + border, y + border,
                                                      x - start, x - start))
                else:
                    x += 1
        return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" '
                'height="%d" shape-rendering="crispEdges"><rect width="100%%" height="100%%" '
                'fill="%s"/><path d="%s" fill="%s"/></svg>'
                % (size, size, size * scale, size * scale, light, ''.join(path), dark))

    def terminal(self, border=2, invert=False):
        """The code as half-block characters, two rows of squares a line.
        Drawn for a dark terminal: a dark square is the terminal's own dark
        and a light one is a full block. `invert` for a light terminal."""
        size = self.size
        out = []
        def light(x, y):
            if x < 0 or y < 0 or x >= size or y >= size:
                return not invert
            return (not self.modules[y][x]) != invert
        for y in range(-border, size + border, 2):
            row = []
            for x in range(-border, size + border):
                top, bottom = light(x, y), light(x, y + 1)
                row.append('█' if top and bottom else
                           '▀' if top else '▄' if bottom else ' ')
            out.append(''.join(row))
        return '\n'.join(out)


def qr_svg(text, scale=6):
    return QrCode(text, 'M').svg(scale=scale)


def qr_data_uri(text, scale=6):
    return 'data:image/svg+xml;base64,' + base64.b64encode(
        qr_svg(text, scale).encode('ascii')).decode('ascii')


# ---------------------------------------------------------------------------
# The database
# ---------------------------------------------------------------------------
# One of three, as on isemon: a SQLite file on this machine unless somebody
# says otherwise, or a MariaDB or a PostgreSQL. The SQL below is written once,
# with `?` for every value, and said in each engine's own words where they
# differ - the types, the numbering of rows, the placeholders.
#
# One connection, behind one lock. A token server answers a few requests a
# second at its busiest; what costs time is the directory, and that is asked
# outside the lock.

class DbError(Exception):
    pass


SCHEMA_VERSION = 1

SCHEMA = [
    ('meta', '''CREATE TABLE IF NOT EXISTS meta (
        k {K} PRIMARY KEY, v {B})'''),
    ('settings', '''CREATE TABLE IF NOT EXISTS settings (
        k {K} PRIMARY KEY, v {B}, at {N}, by_who {K})'''),
    ('accounts', '''CREATE TABLE IF NOT EXISTS accounts (
        id {ID}, name {K} NOT NULL UNIQUE, role {K}, pw {T}, source {K}, disabled {I},
        must_change {I}, note {T}, created {N}, last_in {N}, last_from {K}, prefs {T},
        display {T}, dn {T}, group_list {T}, cols {B}, cols_at {N})'''),
    ('sessions', '''CREATE TABLE IF NOT EXISTS sessions (
        id {ID}, token_hash {K} NOT NULL UNIQUE, kind {K}, name {K}, role {K}, created {N},
        last {N}, expires {N}, ip {K}, data {B})'''),
    ('tokens', '''CREATE TABLE IF NOT EXISTS tokens (
        id {ID}, name {K} NOT NULL UNIQUE, secret {T}, digits {I}, period {I}, algorithm {K},
        window_steps {I}, state {K}, last_step {I}, scratch {B}, scratch_left {I},
        created {N}, created_by {K}, activated {N}, last_used {N}, last_from {K},
        last_how {K}, failures {I}, fail_times {T}, note {T}, issuer {K}, label {K},
        pending_secret {T}, pending_scratch {B}, pending_at {N}, pending_by {K},
        display {T}, scratch_sealed {T}, locked_until {N})'''),
    ('clients', '''CREATE TABLE IF NOT EXISTS clients (
        id {ID}, name {K} NOT NULL UNIQUE, address {K}, secret {T}, realm {K},
        require_ma {I}, enabled {I}, note {T}, created {N}, last_seen {N}, nas_type {K},
        position {I}, realms {T})'''),
    ('realms', '''CREATE TABLE IF NOT EXISTS realms (
        id {ID}, name {K} NOT NULL UNIQUE, suffix {K}, directory {K}, lookup {K},
        auth_mode {K}, group_list {B}, check_disabled {I}, reply {T}, enabled {I},
        position {I}, note {T}, created {N}, token_name {K}, nested {I})'''),
    ('directories', '''CREATE TABLE IF NOT EXISTS directories (
        id {ID}, name {K} NOT NULL UNIQUE, hosts {T}, port {I}, tls {K}, verify {I},
        ca {B}, base {T}, bind_dn {T}, bind_pw {T}, user_attr {K}, nested {I},
        timeout_s {I}, enabled {I}, note {T}, created {N})'''),
    ('radius_log', '''CREATE TABLE IF NOT EXISTS radius_log (
        id {ID}, ts {N}, client {K}, nas_ip {K}, src {K}, packet {K}, username {K},
        realm {K}, calling {K}, called {K}, result {K}, reason {T}, otp {K}, rid {K},
        took_ms {I}, attrs {B}, reply {B}, steps {B}, device {K}, tunnel {K}, node {K})'''),
    ('otp_log', '''CREATE TABLE IF NOT EXISTS otp_log (
        id {ID}, ts {N}, name {K}, ok {I}, said {T}, how {K}, src {K}, rid {K},
        step_off {I}, node {K})'''),
    ('events', '''CREATE TABLE IF NOT EXISTS events (
        id {ID}, ts {N}, kind {K}, level {K}, who {K}, words {T}, node {K})'''),
]

INDEXES = [
    'CREATE INDEX IF NOT EXISTS radius_log_ts ON radius_log (ts)',
    'CREATE INDEX IF NOT EXISTS radius_log_user ON radius_log (username, ts)',
    'CREATE INDEX IF NOT EXISTS radius_log_result ON radius_log (result, ts)',
    'CREATE INDEX IF NOT EXISTS otp_log_ts ON otp_log (ts)',
    'CREATE INDEX IF NOT EXISTS otp_log_name ON otp_log (name, ts)',
    'CREATE INDEX IF NOT EXISTS events_ts ON events (ts)',
    'CREATE INDEX IF NOT EXISTS sessions_expires ON sessions (expires)',
    # 1.0.33: the events by kind (the enrolment tab, the kinds offered as one
    # types), the log by packet and by client, the sign-ins by kind.
    'CREATE INDEX IF NOT EXISTS events_kind_ts ON events (kind, ts)',
    'CREATE INDEX IF NOT EXISTS radius_log_packet_ts ON radius_log (packet, ts, result)',
    'CREATE INDEX IF NOT EXISTS radius_log_client_ts ON radius_log (client, ts)',
    'CREATE INDEX IF NOT EXISTS sessions_kind_last ON sessions (kind, last)',
]

TYPES = {
    'sqlite': {'ID': 'INTEGER PRIMARY KEY AUTOINCREMENT', 'K': 'TEXT', 'T': 'TEXT',
               'B': 'TEXT', 'N': 'REAL', 'I': 'INTEGER'},
    # Compared byte for byte, as SQLite and PostgreSQL compare (1.0.44): with
    # the default collation novák@x.cz was novak@x.cz, and one person's
    # token was written over another's.
    'mariadb': {'ID': 'BIGINT AUTO_INCREMENT PRIMARY KEY', 'K': 'VARCHAR(190) COLLATE utf8mb4_bin',
                'T': 'TEXT', 'B': 'MEDIUMTEXT', 'N': 'DOUBLE', 'I': 'BIGINT'},
    'postgres': {'ID': 'BIGSERIAL PRIMARY KEY', 'K': 'TEXT', 'T': 'TEXT', 'B': 'TEXT',
                 'N': 'DOUBLE PRECISION', 'I': 'BIGINT'},
}

TABLES = [name for name, _ in SCHEMA]


def _qmarks(sql):
    """`?` as `%s`, for the two engines whose drivers want that. Nothing in
    the SQL this program writes has a `?` or a `%` inside a quoted string."""
    return sql.replace('%', '%%').replace('?', '%s')


def db_tls_args(engine, mode=None, ca=None):
    """How the connection to the database server is encrypted (1.0.33):
    as the driver decides, unless `db_tls` says otherwise. The settings of
    the connection asked for, not the running ones (1.0.36): a change was
    tried with the old values, then the service could not start."""
    mode = str((CONFIG.get('db_tls') if mode is None else mode) or '')
    ca = str((CONFIG.get('db_tls_ca') if ca is None else ca) or '')
    if not mode:
        return {}
    if engine == 'postgres':
        out = {'sslmode': mode}
        if ca:
            out['sslrootcert'] = ca
        return out
    import ssl as _ssl
    if mode == 'require':
        return {'ssl': {'check_hostname': False, 'verify_mode': _ssl.CERT_NONE}}
    # verify_mode True, not CERT_REQUIRED (1.0.36): pymysql took the number
    # with no authority file for "check nothing". True with no file checks
    # against the system's authorities.
    got = {'ssl': {'check_hostname': mode == 'verify-full', 'verify_mode': True}}
    if ca:
        got['ssl']['ca'] = ca
    return got


class Db(object):
    """One database, of whichever engine."""

    def __init__(self, engine='sqlite', host='', port=0, name='otp', user='otp',
                 password='', timeout=10, path=None, tls=None, tls_ca=None):
        self.engine = engine if engine in TYPES else 'sqlite'
        # [fd00::1] as written in a URL is fd00::1 to the drivers. (1.0.36)
        host = str(host or '').strip()
        if host.startswith('[') and host.endswith(']'):
            host = host[1:-1]
        self.host, self.port, self.name = host, int(port or 0), name
        self.user, self.password, self.timeout = user, password, int(timeout or 10)
        self.path = Path(path) if path else DB_FILE
        self.lock = threading.RLock()
        self.tls, self.tls_ca = tls, tls_ca
        self.conn = None
        self.connect()

    # ---- the connection ----------------------------------------------------
    def where(self):
        if self.engine == 'sqlite':
            return str(self.path)
        return '%s@%s:%s/%s' % (self.user, self.host or 'localhost',
                                self.port or {'mariadb': 3306, 'postgres': 5432}[self.engine],
                                self.name)

    def connect(self):
        with self.lock:
            if self.engine == 'sqlite':
                self.path.parent.mkdir(parents=True, exist_ok=True)
                conn = sqlite3.connect(str(self.path), check_same_thread=False,
                                       isolation_level=None, timeout=30)
                conn.row_factory = sqlite3.Row
                try:
                    conn.execute('PRAGMA journal_mode=WAL')
                    conn.execute('PRAGMA synchronous=NORMAL')
                except sqlite3.Error:
                    pass
                self.conn = conn
            elif self.engine == 'mariadb':
                try:
                    import pymysql
                    import pymysql.cursors
                except ImportError:
                    raise DbError('MariaDB is chosen and its Python driver is not installed: '
                                  'dnf install python3-PyMySQL (or pip install PyMySQL)')
                try:
                    self.conn = pymysql.connect(
                        host=self.host or 'localhost', port=self.port or 3306,
                        user=self.user, password=self.password, database=self.name,
                        charset='utf8mb4', autocommit=True,
                        connect_timeout=self.timeout,
                        cursorclass=pymysql.cursors.DictCursor,
                        **db_tls_args('mariadb', self.tls, self.tls_ca))
                except Exception as e:
                    raise DbError('MariaDB at %s could not be reached: %s' % (self.where(), e))
            else:
                try:
                    import psycopg2
                    import psycopg2.extras
                except ImportError:
                    raise DbError('PostgreSQL is chosen and its Python driver is not installed: '
                                  'dnf install python3-psycopg2 (or pip install psycopg2-binary)')
                try:
                    self.conn = psycopg2.connect(
                        host=self.host or 'localhost', port=self.port or 5432,
                        user=self.user, password=self.password, dbname=self.name,
                        connect_timeout=self.timeout,
                        **db_tls_args('postgres', self.tls, self.tls_ca))
                    self.conn.autocommit = True
                    self.conn.set_client_encoding('UTF8')
                except Exception as e:
                    raise DbError('PostgreSQL at %s could not be reached: %s' % (self.where(), e))

    def close(self):
        with self.lock:
            try:
                if self.conn:
                    self.conn.close()
            except Exception:
                pass
            self.conn = None

    # ---- asking --------------------------------------------------------------
    def _run(self, sql, args, fetch):
        if self.engine == 'sqlite':
            cur = self.conn.execute(sql, tuple(args or ()))
            rows = [dict(r) for r in cur.fetchall()] if fetch else None
            return rows, cur.rowcount, cur.lastrowid
        if self.engine == 'mariadb':
            cur = self.conn.cursor()
            try:
                cur.execute(_qmarks(sql), tuple(args or ()))
                rows = [dict(r) for r in cur.fetchall()] if fetch else None
                return rows, cur.rowcount, cur.lastrowid
            finally:
                cur.close()
        import psycopg2.extras
        cur = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        try:
            cur.execute(_qmarks(sql), tuple(args or ()))
            rows = [dict(r) for r in cur.fetchall()] if (fetch or cur.description) else None
            return rows, cur.rowcount, rows[0].get('id') if (rows and not fetch) else None
        finally:
            cur.close()

    def _gone(self, e):
        """Whether an error is the server having gone away, which one new
        connection mends."""
        said = str(e).lower()
        return any(w in said for w in ('gone away', 'lost connection', 'server closed',
                                       'connection already closed', 'terminating connection',
                                       'broken pipe', 'connection reset', 'not connected',
                                       'interfaceerror', 'cursor already closed',
                                       'connection has been closed',
                                       'connection is closed', 'ssl connection has been closed'))

    def query(self, sql, args=(), fetch=True):
        with self.lock:
            if self.conn is None:
                self.connect()
            try:
                return self._run(sql, args, fetch)
            except Exception as e:
                if self.engine == 'sqlite' or not (self._gone(e) or
                                                   type(e).__name__ == 'InterfaceError'):
                    raise
                if getattr(self, 'in_tx', False):
                    # Half a transaction is gone with the connection; going on
                    # on a new one would commit the second half alone. (1.0.36)
                    self.close()
                    raise
                # A connection that is gone is made again - and the statement
                # run once more only where that cannot do it twice (1.0.33): a
                # read, or a connection known closed before it was sent. A
                # write whose answer was lost may have been done; done again,
                # a code just used up would be refused as used.
                self.close()
                self.connect()
                said = str(e).lower()
                unsent = type(e).__name__ == 'InterfaceError' or any(
                    w in said for w in ('connection already closed', 'not connected',
                                        'cursor already closed'))
                if sql.lstrip()[:6].upper() in ('SELECT', 'WITH  ', 'SHOW  ') or \
                        sql.lstrip().upper().startswith(('SELECT', 'WITH', 'SHOW', 'EXPLAIN')) \
                        or unsent:
                    return self._run(sql, args, fetch)
                raise

    def rows(self, sql, args=()):
        return self.query(sql, args, True)[0]

    def row(self, sql, args=()):
        got = self.rows(sql, args)
        return got[0] if got else None

    def value(self, sql, args=(), default=None):
        got = self.row(sql, args)
        if not got:
            return default
        return list(got.values())[0]

    def run(self, sql, args=()):
        return self.query(sql, args, False)[1]

    def insert(self, table, row):
        keys = list(row.keys())
        sql = 'INSERT INTO %s (%s) VALUES (%s)' % (table, ', '.join(keys),
                                                   ', '.join('?' for _ in keys))
        if self.engine == 'postgres':
            sql += ' RETURNING id'
            return self.query(sql, [row[k] for k in keys], False)[2]
        return self.query(sql, [row[k] for k in keys], False)[2]

    def update(self, table, ident, row):
        keys = list(row.keys())
        if not keys:
            return 0
        return self.run('UPDATE %s SET %s WHERE id = ?' % (table, ', '.join('%s = ?' % k
                                                                          for k in keys)),
                        [row[k] for k in keys] + [ident])

    # ---- the tables ----------------------------------------------------------
    def make_tables(self):
        types = TYPES[self.engine]
        for _name, ddl in SCHEMA:
            sql = ddl.format(**types)
            if self.engine == 'mariadb':
                sql += ' DEFAULT CHARSET=utf8mb4'
            self.run(sql)
        for sql in INDEXES:
            if self.engine == 'mariadb':
                # MariaDB knows IF NOT EXISTS on an index from 10.1.4 on, and
                # wants a length on nothing here: every indexed column is a
                # VARCHAR(190) or a number.
                try:
                    self.run(sql)
                except Exception as e:
                    if 'Duplicate key name' in str(e):
                        continue
                    # MySQL has no IF NOT EXISTS on an index (1.0.44).
                    if '1064' not in str(e) and 'syntax' not in str(e).lower():
                        raise
                    try:
                        self.run(sql.replace(' IF NOT EXISTS', ''))
                    except Exception as e2:
                        if 'Duplicate key name' not in str(e2):
                            raise
            else:
                self.run(sql)
        if self.engine == 'mariadb':
            self._mariadb_bin_names()
        self.add_missing_columns()
        if self.value('SELECT v FROM meta WHERE k = ?', ('schema',)) is None:
            self.run('INSERT INTO meta (k, v) VALUES (?, ?)', ('schema', str(SCHEMA_VERSION)))

    def _mariadb_bin_names(self):
        """Tables made before 1.0.44 compared names ignoring case and
        accents: their VARCHAR columns made byte for byte, once."""
        try:
            rows = self.rows("SELECT TABLE_NAME AS t, COLUMN_NAME AS c, IS_NULLABLE AS n, "
                             "CHARACTER_MAXIMUM_LENGTH AS l FROM information_schema.COLUMNS "
                             "WHERE TABLE_SCHEMA = DATABASE() AND DATA_TYPE = 'varchar' "
                             "AND COLLATION_NAME <> 'utf8mb4_bin'")
        except Exception as e:                          # noqa: BLE001
            log('the names could not be checked for their collation: %s' % e, 'warn')
            return
        for r in rows:
            r = {k.lower(): v for k, v in r.items()}
            if r['t'] not in TABLES:
                continue
            try:
                self.run('ALTER TABLE %s MODIFY %s VARCHAR(%d) CHARACTER SET utf8mb4 '
                         'COLLATE utf8mb4_bin%s' % (r['t'], r['c'], int(r['l'] or 190),
                                                    ' NOT NULL' if r['n'] == 'NO' else ''))
            except Exception as e:                      # noqa: BLE001
                log('%s.%s stays compared without case: %s' % (r['t'], r['c'], e), 'warn')

    def tables(self):
        """The tables that are there, whatever made them."""
        if self.engine == 'sqlite':
            return [r['name'] for r in self.rows(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")]
        if self.engine == 'mariadb':
            return [list(r.values())[0] for r in self.rows(
                'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()')]
        return [r['tablename'] for r in self.rows(
            "SELECT tablename FROM pg_tables WHERE schemaname = current_schema()")]

    def insert_many(self, table, keys, rows):
        """Many rows at once, in one transaction - a copy of a million rows
        is minutes this way and hours a row at a time."""
        if not rows:
            return 0
        sql = 'INSERT INTO %s (%s) VALUES (%s)' % (table, ', '.join(keys),
                                                   ', '.join('?' for _ in keys))
        with self.lock:
            if self.conn is None:
                self.connect()
            if self.engine == 'sqlite' and getattr(self, 'in_tx', False):
                self.conn.executemany(sql, rows)
            elif self.engine == 'sqlite':
                self.conn.execute('BEGIN')
                try:
                    self.conn.executemany(sql, rows)
                    self.conn.execute('COMMIT')
                except Exception:
                    self.conn.execute('ROLLBACK')
                    raise
            elif self.engine == 'mariadb':
                cur = self.conn.cursor()
                try:
                    cur.executemany(_qmarks(sql), rows)
                finally:
                    cur.close()
            else:
                import psycopg2.extras
                cur = self.conn.cursor()
                try:
                    psycopg2.extras.execute_batch(cur, _qmarks(sql), rows, page_size=500)
                finally:
                    cur.close()
        return len(rows)

    def columns(self, table):
        if self.engine == 'sqlite':
            return [r['name'] for r in self.rows('PRAGMA table_info(%s)' % table)]
        if self.engine == 'mariadb':
            return [r.get('COLUMN_NAME') or r.get('column_name') for r in self.rows(
                'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '
                'DATABASE() AND TABLE_NAME = ?', (table,))]
        return [r['column_name'] for r in self.rows(
            'SELECT column_name FROM information_schema.columns WHERE table_name = ?',
            (table,))]

    def add_missing_columns(self):
        """A column added in a later version, added to a database made by an
        earlier one. Read off the CREATE statements above, so there is one
        place a column is declared."""
        types = TYPES[self.engine]
        for name, ddl in SCHEMA:
            have = set(c.lower() for c in self.columns(name))
            body = ddl.format(**types).split('(', 1)[1].rsplit(')', 1)[0]
            for piece in re.split(r',\s*(?=[a-z_]+ )', body):
                piece = piece.strip()
                col = piece.split(' ', 1)[0].lower()
                if not col or col in have or col == 'id':
                    continue
                kind = piece.split(' ', 2)[1] if ' ' in piece else 'TEXT'
                kind = re.sub(r'\s*(NOT NULL|UNIQUE|PRIMARY KEY).*$', '', piece.split(' ', 1)[1])
                try:
                    self.run('ALTER TABLE %s ADD COLUMN %s %s' % (name, col, kind))
                except Exception as e:
                    log('could not add the column %s.%s: %s' % (name, col, e), 'warn')

    def size(self):
        try:
            if self.engine == 'sqlite':
                return sum(os.path.getsize(str(self.path) + s) for s in ('', '-wal')
                           if os.path.exists(str(self.path) + s))
            if self.engine == 'mariadb':
                return int(self.value(
                    'SELECT SUM(data_length + index_length) FROM information_schema.TABLES '
                    'WHERE table_schema = DATABASE()') or 0)
            return int(self.value('SELECT pg_database_size(current_database())') or 0)
        except Exception:
            return 0

    def version(self):
        try:
            if self.engine == 'sqlite':
                return 'SQLite ' + sqlite3.sqlite_version
            if self.engine == 'mariadb':
                return 'MariaDB ' + str(self.value('SELECT VERSION()'))
            return str(self.value('SELECT version()')).split(' on ')[0]
        except Exception as e:
            return '? (%s)' % e


def open_db(conf=None):
    """The database the settings name."""
    c = conf or CONFIG
    return Db(c.get('db_engine') or 'sqlite', c.get('db_host') or '', c.get('db_port') or 0,
              c.get('db_name') or 'otp', c.get('db_user') or 'otp', c.get('db_password') or '',
              c.get('db_timeout_s') or 10, tls=c.get('db_tls') or '',
              tls_ca=c.get('db_tls_ca') or '')


# ---------------------------------------------------------------------------
# A copy of everything, in a shape any of the three engines takes back
# ---------------------------------------------------------------------------
def dump_tables(db, out, tables=None):
    """Every row of every table, as JSON a line, gzipped. The first line says
    what it is; each table starts with a line naming it."""
    import gzip
    with gzip.open(str(out), 'wt', encoding='utf-8') as f:
        f.write(json.dumps({'otp': __version__, 'schema': SCHEMA_VERSION,
                            'made': time.time(), 'engine': db.engine}) + '\n')
        for table in (tables or TABLES):
            f.write(json.dumps({'table': table}) + '\n')
            last = 0
            while True:
                if table in ('meta', 'settings'):
                    rows = db.rows('SELECT * FROM %s' % table) if last == 0 else []
                    last = 1
                else:
                    rows = db.rows('SELECT * FROM %s WHERE id > ? ORDER BY id LIMIT 2000'
                                   % table, (last,))
                    if rows:
                        last = rows[-1]['id']
                for r in rows:
                    f.write(json.dumps(r, default=str) + '\n')
                if not rows or table in ('meta', 'settings'):
                    break
    return out


def load_tables(db, src, keep_logs=True, say=None):
    """Put a copy made by `dump_tables` back, over whatever is there.
    `say(table, done)` hears how far it has got, a batch at a time."""
    import gzip
    db.make_tables()
    # All of it or none of it (1.0.33): a copy that broke off half-way left
    # the tokens empty, and everybody locked out. The database is held for
    # the whole of it - a restore is not something done while people sign in.
    with db.lock:
        if db.conn is None:
            db.connect()
        db.run('START TRANSACTION' if db.engine == 'mariadb' else 'BEGIN')
        db.in_tx = True
        try:
            counts = _load_tables(db, src, keep_logs, say, gzip)
            db.in_tx = False
            db.run('COMMIT')
        except BaseException:
            db.in_tx = False
            try:
                db.run('ROLLBACK')
            except Exception:                           # noqa: BLE001
                pass
            raise
    if db.engine == 'postgres':
        for table in TABLES:
            if table in ('meta', 'settings'):
                continue
            try:
                db.run("SELECT setval(pg_get_serial_sequence('%s', 'id'), "
                       "COALESCE((SELECT MAX(id) FROM %s), 0) + 1, false)" % (table, table))
            except Exception:
                pass
    return counts


META_TRANSIENT = ('db_job:', 'node:', 'maint:', 'upgrade:', 'radtest:')


def _load_tables(db, src, keep_logs, say, gzip):
    counts = {}
    batch, keys, table, have = [], None, None, set()

    def flush():
        if table and batch:
            db.insert_many(table, keys, batch)
            counts[table] += len(batch)
            if say:
                say(table, counts[table])
        del batch[:]

    with gzip.open(str(src), 'rt', encoding='utf-8') as f:
        head = json.loads(f.readline() or '{}')
        if 'otp' not in head and 'opt' not in head:      # 'opt': before 1.0.37's new name
            raise DbError('%s is not a copy made by otp' % src)
        for line in f:
            got = json.loads(line)
            if set(got.keys()) == {'table'}:
                flush()
                keys = None
                table = got['table']
                if table not in TABLES or (not keep_logs and table in ('radius_log', 'otp_log')):
                    table = None
                    continue
                if table == 'meta':
                    # What is going on here now stays (1.0.44): maintenance,
                    # heartbeats, upgrades and jobs are this machine's, not
                    # the copy's - and in a cluster the delete would reach
                    # the other node too.
                    db.run('DELETE FROM meta WHERE ' + ' AND '.join(
                        "k NOT LIKE '%s%%'" % p.replace("'", "") for p in META_TRANSIENT))
                else:
                    db.run('DELETE FROM %s' % table)
                have = set(c.lower() for c in db.columns(table))
                counts[table] = 0
                if say:
                    say(table, 0)
                continue
            if not table:
                continue
            row = {k: v for k, v in got.items() if k.lower() in have}
            if table == 'meta':
                # What only the running service means is not carried over
                # (1.0.37): the copy made at the start of a move held the
                # move itself as "going on", and the database moved into
                # showed it going on for ever - every button that waits for
                # a job stayed grey. Heartbeats, maintenance and upgrades
                # are of the machine that wrote them, too.
                if str(row.get('k') or '').startswith(META_TRANSIENT):
                    continue
                db.run('DELETE FROM meta WHERE k = ?', (row.get('k'),))
            these = sorted(row.keys())
            if keys is not None and these != keys:
                flush()
            keys = these
            batch.append([row[k] for k in keys])
            if len(batch) >= 1000:
                flush()
        flush()
    return counts


# ---------------------------------------------------------------------------
# Active Directory, over LDAP
# ---------------------------------------------------------------------------
# Taken whole from isemon, where it has been signing people in against Active
# Directory for a long time: enough of LDAP to bind, search and page, written
# out so that nothing has to be installed, and refusing on the wire to send
# anything that would change a directory.
LDAP_TIMEOUT = 12.0
LDAP_MAX_MESSAGE = 8 * 1024 * 1024

# The result codes worth telling apart.
LDAP_OK = 0
LDAP_NO_SUCH_OBJECT = 32
LDAP_BAD_CREDENTIALS = 49
LDAP_SAYS = {
    0: 'success',
    1: 'the directory had an operations error',
    32: 'there is no such object under that base',
    34: 'the distinguished name is not well formed',
    48: 'that server will not take this kind of authentication',
    49: 'the name or the password was not accepted',
    50: 'that account may not read what was asked for',
    53: 'the server is unwilling to do that (a blank password, or an account '
        'that must change it)',
}

# Active Directory answers every one of these with the same code 49 and the
# same sentence, with the reason hidden in a hex number at the end of it:
# "data 52e" is a wrong password and "data 533" is a disabled account, and
# telling somebody to check their password when their account is disabled is
# how an afternoon gets wasted.
AD_REASONS = {
    '525': 'there is no such account',
    '52e': 'the password is not right',
    '530': 'that account may not sign in at this time of day',
    '531': 'that account may not sign in from this machine',
    '532': 'the password has expired',
    '533': 'the account is disabled',
    '568': 'the directory ran out of room for the groups this account is in',
    '701': 'the account has expired',
    '773': 'the password must be changed before this account can be used',
    '775': 'the account is locked out',
}


def ad_reason(said):
    """What Active Directory meant, in plain words - or what it said, when
    the hex number is not one of the known ones. What it said in full
    travels beside this as the error's `detail`, for whoever hovers over
    the sentence and wants the whole of it."""
    m = re.search(r'data ([0-9a-fA-F]{3})', str(said or ''))
    if not m:
        return str(said or '')
    return AD_REASONS.get(m.group(1).lower()) or str(said)


class Refused(ValueError):
    """A plain sentence for the person, with the whole of what happened
    kept beside it. The sentence is what the sign-in page shows; the detail
    is what appears when somebody hovers over it - "the password is not
    right" first, and the directory's own "80090308: LdapErr: DSID-..."
    only for whoever wants to read it."""

    def __init__(self, words, detail=''):
        super(Refused, self).__init__(words)
        self.detail = str(detail or '')


# The matching rule Active Directory uses for "in this group, or in a group
# inside it". It is the only way to see nested membership without walking
# the tree, and walking the tree over a slow link is how a sign-in takes ten
# seconds.
LDAP_IN_CHAIN = '1.2.840.113556.1.4.1941'


def _ber_len(n):
    if n < 0x80:
        return bytes([n])
    body = b''
    while n:
        body = bytes([n & 0xFF]) + body
        n >>= 8
    return bytes([0x80 | len(body)]) + body


def _ber(tag, body):
    return bytes([tag]) + _ber_len(len(body)) + body


def _ber_int(value, tag=0x02):
    value = int(value)
    if value == 0:
        return _ber(tag, b'\x00')
    body = b''
    negative = value < 0
    n = value if not negative else -value - 1
    while n:
        body = bytes([(n & 0xFF) ^ (0xFF if negative else 0)]) + body
        n >>= 8
    if not body:
        body = b'\x00'
    top = body[0]
    if negative and not top & 0x80:
        body = b'\xff' + body
    elif not negative and top & 0x80:
        body = b'\x00' + body
    return _ber(tag, body)


def _ber_str(text, tag=0x04):
    if isinstance(text, bytes):
        return _ber(tag, text)
    return _ber(tag, str(text or '').encode('utf-8'))


def _ber_bool(value, tag=0x01):
    return _ber(tag, b'\xff' if value else b'\x00')


def _ber_read(data, at=0):
    """One tag, its body, and where the next one starts."""
    if at + 2 > len(data):
        raise ValueError('the answer stopped in the middle')
    tag = data[at]
    length = data[at + 1]
    at += 2
    if length & 0x80:
        count = length & 0x7F
        if count == 0 or at + count > len(data):
            raise ValueError('the answer has a length this does not understand')
        length = int.from_bytes(data[at:at + count], 'big')
        at += count
    if length > LDAP_MAX_MESSAGE or at + length > len(data):
        raise ValueError('the answer is longer than it says it is')
    return tag, data[at:at + length], at + length


def _ber_int_of(body):
    if not body:
        return 0
    value = int.from_bytes(body, 'big')
    if body[0] & 0x80:
        value -= 1 << (8 * len(body))
    return value


def ldap_escape(text):
    r"""A value going into a TEXT filter, with the four characters that mean
    something else written the way RFC 4515 says to write them.

    Not for the filters this program sends. Those are built as BER, where an
    assertion value goes on the wire as raw bytes and nothing in it means
    anything else - so there is nothing to escape, and escaping anyway
    CORRUPTS the value: `CN=Novak\, Jan` became `CN=Novak\5c, Jan`, which
    read as a distinguished name is a different name, and somebody who was an
    administrator only through a group inside a group was refused. A name
    with a bracket in it - `(VPN)`, which Active Directory allows - was never
    found at all. Kept for the debug log, which is text.
    """
    out = []
    for ch in str(text or ''):
        if ch in '\\*()' or ch == '\x00':
            out.append('\\%02x' % ord(ch))
        else:
            out.append(ch)
    return ''.join(out)


def ldap_equal(attr, value):
    """(attr=value), as BER."""
    return _ber(0xA3, _ber_str(attr) + _ber_str(value))


def ldap_present(attr):
    """(attr=*)"""
    return _ber_str(attr, tag=0x87)


def ldap_contains(attr, value):
    """(attr=*value*)"""
    return _ber(0xA4, _ber_str(attr) + _ber(0x30, _ber_str(value, tag=0x81)))


def ldap_and(*parts):
    return _ber(0xA0, b''.join(parts))


def ldap_or(*parts):
    return _ber(0xA1, b''.join(parts))


# Active Directory's "this bit is set in this number" rule, which is the
# only way to ask it for the accounts whose pre-authentication is off or
# whose account is disabled.
LDAP_BITS = '1.2.840.113556.1.4.803'


def ldap_bits(attr, value):
    """(attr:1.2.840.113556.1.4.803:=value)"""
    return _ber(0xA9, _ber_str(LDAP_BITS, tag=0x81)
                + _ber_str(attr, tag=0x82) + _ber_str(str(int(value)), tag=0x83))


def ldap_in_chain(attr, value):
    """(attr:1.2.840.113556.1.4.1941:=value) - Active Directory's "or in a
    group inside it"."""
    return _ber(0xA9, _ber_str(LDAP_IN_CHAIN, tag=0x81)
                + _ber_str(attr, tag=0x82) + _ber_str(value, tag=0x83))


# What each filter tag is, in the words RFC 4515 writes them in. Used for
# nothing but the debug log.
LDAP_FILTER_JOIN = {0xA0: '&', 0xA1: '|', 0xA2: '!'}
LDAP_FILTER_SIGN = {0xA3: '=', 0xA5: '>=', 0xA6: '<=', 0xA8: '~='}


def ldap_filter_words(ber, deep=0):
    """A filter that has been built as BER, written back out as text.

    Only ever for the log. The filters go on to the wire as BER and are
    built that way, so a debug line saying what was asked has either to be
    passed down through every caller - a second argument on a dozen
    functions, which would go out of step with the real one the first time
    somebody changed a filter and forgot the words beside it - or read back
    off the thing that was actually sent. This reads it back: what appears
    in the log is what went to the directory, and it cannot say otherwise.

    Nothing secret is ever in a filter - a name, a group, a flag - and the
    one thing that is secret, the password on a bind, is not a filter and
    never reaches this.
    """
    try:
        tag, body, _ = _ber_read(ber)
    except (ValueError, IndexError):
        return '(?)'
    if deep > 12:
        return '(…)'
    if tag in LDAP_FILTER_JOIN:
        out, at = [], 0
        while at < len(body):
            try:
                _t, one, nxt = _ber_read(body, at)
            except (ValueError, IndexError):
                break
            # Put the tag and the length back on the piece that was read
            # out, so each one goes round again as a filter in its own
            # right rather than as a body with no head.
            out.append(ldap_filter_words(_ber(_t, one), deep + 1))
            at = nxt
        return '(%s%s)' % (LDAP_FILTER_JOIN[tag], ''.join(out))
    if tag == 0x87:                                    # present
        return '(%s=*)' % body.decode('utf-8', 'replace')
    if tag in LDAP_FILTER_SIGN:
        try:
            _t, attr, at = _ber_read(body)
            _t, value, _ = _ber_read(body, at)
        except (ValueError, IndexError):
            return '(?)'
        return '(%s%s%s)' % (attr.decode('utf-8', 'replace'), LDAP_FILTER_SIGN[tag],
                             value.decode('utf-8', 'replace'))
    if tag == 0xA4:                                    # substrings
        try:
            _t, attr, at = _ber_read(body)
            _t, parts, _ = _ber_read(body, at)
        except (ValueError, IndexError):
            return '(?)'
        bits, where, first, last = [], 0, '', ''
        while where < len(parts):
            try:
                _t, one, where = _ber_read(parts, where)
            except (ValueError, IndexError):
                break
            text = one.decode('utf-8', 'replace')
            if _t == 0x80:
                first = text
            elif _t == 0x82:
                last = text
            else:
                bits.append(text)
        return '(%s=%s*%s%s)' % (attr.decode('utf-8', 'replace'), first,
                                 '*'.join(bits) + ('*' if bits else ''), last)
    if tag == 0xA9:                                    # extensible match
        rule, attr, value = '', '', ''
        where = 0
        while where < len(body):
            try:
                _t, one, where = _ber_read(body, where)
            except (ValueError, IndexError):
                break
            text = one.decode('utf-8', 'replace')
            if _t == 0x81:
                rule = text
            elif _t == 0x82:
                attr = text
            elif _t == 0x83:
                value = text
        return '(%s:%s:=%s)' % (attr, rule, value)
    return '(?)'


LDAP_SCOPE_WORDS = {0: 'that entry only', 1: 'one level down', 2: 'everything below'}

# Attributes never written to the log, whatever the debug switches say. None
# of these is ever asked for by this program; they are named here because a
# debug log is a file somebody copies into a ticket, and "it cannot happen"
# is not a reason to leave the door open. See the rule the FreeRADIUS reading
# follows for the same reason: a password never reaches a row or a log.
LDAP_NEVER_LOG = ('userpassword', 'unicodepwd', 'dbcspwd', 'lmpwdhistory',
                  'ntpwdhistory', 'supplementalcredentials', 'msds-keycredentiallink',
                  'clearpassword', 'currentvalue', 'msds-managedpassword',
                  'trustauthincoming', 'trustauthoutgoing')


def ldap_entry_words(entries, most=6, wide=400):
    """What came back, short enough to be a line in a log.

    A search for the disabled accounts on a big domain is a thousand entries
    and nobody wants a thousand lines; a search that found one is exactly
    what somebody turned the debug on to see. So: the first few, whole, and
    a count of the rest.
    """
    out = []
    for one in list(entries)[:max(1, int(most))]:
        said = []
        for name in sorted((one.get('attrs') or {})):
            if name.lower() in LDAP_NEVER_LOG:
                said.append('%s=(not logged)' % name)
                continue
            values = (one.get('attrs') or {}).get(name) or []
            said.append('%s=%s' % (name, '|'.join(str(v) for v in values)))
        line = one.get('dn') or '(no dn)'
        if said:
            line += ' [' + '; '.join(said) + ']'
        out.append(line[:wide] + ('…' if len(line) > wide else ''))
    rest = len(entries) - len(out)
    if rest > 0:
        out.append('and %d more' % rest)
    return ' · '.join(out)


def describe_certificate(pem):
    """What a pasted certificate is, in words, or None if it is not one.

    Somebody importing a certificate authority wants to see that the right
    one landed - the name on it and when it runs out - and not a green tick
    that means "the text was saved". Python can read a certificate without
    any package being installed; what it cannot do without one is read it
    from a string, so it goes through a file that exists for a moment.
    """
    text = str(pem or '').strip()
    if '-----BEGIN CERTIFICATE-----' not in text:
        return None
    folder = None
    try:
        folder = tempfile.mkdtemp(prefix='otp-ca-')
        where = os.path.join(folder, 'ca.pem')
        with open(where, 'w', encoding='utf-8') as f:
            f.write(text if text.endswith('\n') else text + '\n')
        said = ssl._ssl._test_decode_cert(where)     # noqa: SLF001 - the only way in
        def one(pairs):
            out = {}
            for row in pairs or ():
                for key, value in row:
                    out[key] = value
            return out
        subject, issuer = one(said.get('subject')), one(said.get('issuer'))
        return {
            'subject': subject.get('commonName') or subject.get('organizationName') or '',
            'issuer': issuer.get('commonName') or issuer.get('organizationName') or '',
            'from': said.get('notBefore') or '',
            'until': said.get('notAfter') or '',
            'self_signed': subject == issuer,
            'count': text.count('-----BEGIN CERTIFICATE-----'),
        }
    except Exception:
        return None
    finally:
        if folder:
            shutil.rmtree(folder, ignore_errors=True)


PEM_BLOCK = re.compile(r'-----BEGIN CERTIFICATE-----\s+[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----')


def split_certificates(pem):
    """Each certificate of a bundle, as its own PEM block, in order."""
    return [m.group(0).strip() for m in PEM_BLOCK.finditer(str(pem or ''))]


def describe_certificates(pem):
    """Every certificate of a bundle, one by one: who it is, who signed it,
    when it runs out and its fingerprint - so that one of several chains can
    be told apart from another and taken out by itself. (1.0.11)"""
    out = []
    for block in split_certificates(pem):
        said = describe_certificate(block) or {}
        try:
            fp = hashlib.sha256(ssl.PEM_cert_to_DER_cert(block)).hexdigest()
        except Exception:                               # noqa: BLE001
            fp = hashlib.sha256(block.encode()).hexdigest()
        said = dict(said, fingerprint=fp, readable=bool(said))
        said.pop('count', None)
        out.append(said)
    return out


class LdapError(RuntimeError):
    """Something the person setting this up needs to read."""

    def __init__(self, said, code=None, detail=''):
        # The directory ends its own error text with a NUL. It means nothing
        # to anybody, and a database server refuses to store it.
        said = str(said).replace('\x00', '')
        super(LdapError, self).__init__(said)
        self.code = code
        # What the directory said, word for word, when `said` is the plain
        # reading of it. Empty when `said` already is the whole of it.
        self.detail = str(detail or '').replace('\x00', '')

    def whole(self):
        """Everything known about this, for a tooltip: the detail when there
        is one, the sentence itself otherwise."""
        return self.detail or str(self)


class LdapUnreachable(LdapError):
    """The directory could not be asked at all.

    Different from the directory saying no, and the difference decides
    whether a sign-in may fall back to a local account. A domain controller
    being rebooted must not lock everybody out of this dashboard; a domain
    account being disabled must not be got round by an old local password.
    Anything that happens before there is an answer about the person - the
    connection, the TLS, the account this reads the directory with - is this
    one.
    """


class Ldap(object):
    """One conversation with a directory.

    Opened, asked, closed. Nothing is kept between sign-ins: a pooled
    connection to a domain controller that has been restarted is a sign-in
    that fails for no reason anybody can see.
    """

    # How many pages one search may take. A directory of a hundred thousand
    # groups at a thousand a page is a hundred; two hundred is room to spare
    # and a floor under a server whose paging cookie never empties.
    PAGES_MOST = 200

    def __init__(self, host, port=389, tls='none', ca_pem='', verify=True,
                 timeout=LDAP_TIMEOUT):
        self.host = str(host or '').strip()
        self.port = int(port or 389)
        self.tls = str(tls or 'none').strip().lower()
        self.ca_pem = str(ca_pem or '')
        self.verify = bool(verify)
        self.timeout = float(timeout or LDAP_TIMEOUT)
        self.sock = None
        self.next_id = 1
        self.buffer = b''
        # The controls that came with the last message read; the paging
        # cookie is taken out of them.
        self.last_controls = b''

    # ---- the wire ---------------------------------------------------------
    def open(self):
        if not self.host:
            raise LdapError('no directory server has been given')
        try:
            self.sock = socket.create_connection((self.host, self.port), self.timeout)
        except OSError as e:
            raise LdapError('%s:%d could not be reached: %s'
                            % (self.host, self.port, str(e)[:120]))
        self.sock.settimeout(self.timeout)
        if self.tls == 'ldaps':
            self.sock = self._wrap(self.sock)
        elif self.tls == 'starttls':
            self._start_tls()
        if debugging('ldap'):
            log('ldap %s:%d open, %s' % (self.host, self.port,
                                         {'ldaps': 'over TLS',
                                          'starttls': 'over TLS after STARTTLS'}
                                         .get(self.tls, 'in the clear')), 'debug')
        return self

    def _context(self):
        ctx = ssl.create_default_context()
        if self.ca_pem.strip():
            try:
                ctx.load_verify_locations(cadata=self.ca_pem)
            except (ssl.SSLError, ValueError) as e:
                raise LdapError('the certificate authority could not be read: %s'
                                % str(e)[:120])
        if not self.verify:
            # Deliberate, and said out loud wherever it is switched on: a
            # directory reached without checking its certificate is a
            # directory anybody on the path can pretend to be.
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        return ctx

    def _wrap(self, sock):
        try:
            return self._context().wrap_socket(sock, server_hostname=self.host)
        except ssl.SSLCertVerificationError as e:
            raise LdapError('the server’s certificate was not accepted: %s. Import the '
                            'certificate authority that signed it, or switch the check off '
                            'if this is a test.' % str(e.verify_message or e)[:120])
        except (ssl.SSLError, OSError) as e:
            raise LdapError('TLS to %s:%d did not start: %s'
                            % (self.host, self.port, str(e)[:120]))

    def _start_tls(self):
        """The extended operation that turns a plain connection into a
        secure one, on the same port."""
        body = _ber_str(self.START_TLS_OID, tag=0x80)
        tag, answer = self._ask(_ber(0x77, body))
        if tag != 0x78:
            raise LdapError('the server did not answer the StartTLS request')
        code, said = self._result_of(answer)
        if code != LDAP_OK:
            raise LdapError('StartTLS was refused: %s' % (said or LDAP_SAYS.get(code, code)),
                            code)
        # Nothing may be left in the read buffer from BEFORE the connection
        # was made secure. Whatever arrived in plain text after the StartTLS
        # reply used to sit there and be read back as if it had come over
        # TLS - so somebody on the path could append a forged "bind
        # succeeded" to the server's reply, the real handshake would then
        # complete, and the next bind - a person signing in with any
        # password at all - would be answered by the forgery. RFC 4511
        # says the same thing: a client MUST NOT have outstanding data at
        # this point, and the honest thing to do with any is to refuse.
        if self.buffer:
            many = len(self.buffer)
            # Thrown away, and the connection with it: nothing may ever be
            # read off this socket again.
            self.buffer = b''
            try:
                self.sock.close()
            except Exception:
                pass
            raise LdapError('%s sent %d byte(s) in the clear after agreeing to TLS, '
                            'which is not something a directory does' % (self.host, many))
        self.sock = self._wrap(self.sock)
        self.buffer = b''

    def close(self):
        if self.sock:
            try:
                self._send(_ber(0x42, b''))          # unbindRequest, politely
            except Exception:
                pass
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.close()

    # The only four things this program may ever say to a directory, as the
    # tags they go on to the wire as.
    #
    #   0x60 bind      - sign in
    #   0x63 search    - ask
    #   0x42 unbind    - go away
    #   0x77 extended  - StartTLS, and nothing else is sent
    #
    # THIS PROGRAM NEVER CHANGES ANYTHING IN ACTIVE DIRECTORY. Not an
    # attribute, not a group, not a password, not an account: it reads, and
    # that is the whole of it. That is not a promise about what the code
    # happens to do today - it is checked here, on the way out, on every
    # message: an add (0x68), a modify (0x66), a delete (0x4A), a rename
    # (0x6C) or a compare (0x6E) cannot leave this program even if somebody
    # writes the code to build one. A check reads this list and another
    # proves the socket refuses each of them.
    MAY_SAY = (0x60, 0x63, 0x42, 0x77)
    START_TLS_OID = '1.3.6.1.4.1.1466.20037'
    WRITES = {0x66: 'modify', 0x68: 'add', 0x4A: 'delete', 0x6C: 'rename',
              0x6D: 'rename', 0x6E: 'compare'}

    def _send(self, op, controls=b''):
        tag = op[0] if op else 0
        if tag not in self.MAY_SAY:
            raise LdapError(
                'this program only ever READS a directory, and something tried to '
                'send it a %s. Nothing was sent.'
                % self.WRITES.get(tag, 'message of kind 0x%02X' % tag))
        # An extended operation is a door to anything the server offers -
        # a password change is one of them (1.3.6.1.4.1.4203.1.11.1). The
        # only one this program has any business sending is StartTLS, so
        # the only one it may send is StartTLS, by name.
        # The whole message, byte for byte: the name being somewhere inside
        # it let a password change through that carried it as its value.
        if tag == 0x77 and op != _ber(0x77, _ber_str(self.START_TLS_OID, tag=0x80)):
            raise LdapError('this program only ever READS a directory, and something '
                            'tried to send it an extended operation that is not '
                            'StartTLS. Nothing was sent.')
        mid = self.next_id
        self.next_id += 1
        try:
            self.sock.sendall(_ber(0x30, _ber_int(mid) + op + controls))
        except OSError as e:
            # The line gone, not the directory saying no (1.0.44).
            raise LdapUnreachable('the connection to %s failed: %s' % (self.host, str(e)[:100]))
        return mid

    def _read_message(self):
        """One whole LDAP message off the wire.

        The controls come back too. Only one is read here and it is the one
        that matters on a real domain: how to ask for the next page.
        """
        while True:
            try:
                tag, body, end = _ber_read(self.buffer)
                self.buffer = self.buffer[end:]
                if tag != 0x30:
                    raise LdapError('the server sent something that is not an LDAP message')
                _mid_tag, mid_body, at = _ber_read(body)
                op_tag, op_body, after = _ber_read(body, at)
                self.last_controls = body[after:]
                return _ber_int_of(mid_body), op_tag, op_body
            except ValueError:
                pass                                  # not all here yet
            # One deadline for the whole answer (1.0.33): a server that sends
            # a byte at a time, or answers to other message IDs, kept the
            # worker that asked for as long as it liked.
            left = getattr(self, '_deadline', 0) - time.time()
            if getattr(self, '_deadline', 0) and left <= 0:
                raise LdapUnreachable('%s did not finish answering within %d s'
                                % (self.host, int(self.timeout * 3)))
            try:
                if getattr(self, '_deadline', 0):
                    self.sock.settimeout(max(0.05, min(self.timeout, left)))
                more = self.sock.recv(65536)
            except socket.timeout:
                raise LdapUnreachable('%s did not answer within %d s'
                                      % (self.host, int(self.timeout)))
            except OSError as e:
                raise LdapUnreachable('the connection to %s failed: %s'
                                      % (self.host, str(e)[:100]))
            if not more:
                raise LdapUnreachable('%s closed the connection' % self.host)
            if len(self.buffer) + len(more) > LDAP_MAX_MESSAGE:
                raise LdapError('the server sent more than this will read')
            self.buffer += more

    def _ask(self, op):
        mid = self._send(op)
        self._deadline = time.time() + self.timeout * 3
        try:
            while True:
                got_id, tag, body = self._read_message()
                if got_id == mid:
                    return tag, body
        finally:
            # Left set, the old deadline ran out under the next search on the
            # same connection, which then failed at once. (1.0.36)
            self._deadline = 0

    @staticmethod
    def _result_of(body):
        """resultCode and the message beside it, out of any LDAPResult."""
        tag, code_body, at = _ber_read(body)
        code = _ber_int_of(code_body)
        said = ''
        try:
            _t, _matched, at = _ber_read(body, at)
            _t, message, _ = _ber_read(body, at)
            said = message.decode('utf-8', 'replace').strip()
        except ValueError:
            pass
        return code, said

    # ---- what it is asked -------------------------------------------------
    def bind(self, dn='', password=''):
        try:
            return self._bind(dn, password)
        except (ValueError, IndexError) as e:
            # An answer that does not read is the directory failing, not this
            # program (1.0.33).
            raise LdapError('%s sent an answer that does not read: %s' % (self.host, e))

    def _bind(self, dn='', password=''):
        """A simple bind. An empty password is refused here rather than on
        the server: many directories take one as an anonymous bind and
        answer "yes", which would turn a blank password into a sign-in."""
        if dn and not str(password or ''):
            raise LdapError('a password is needed', LDAP_BAD_CREDENTIALS)
        # The name only. The password is the one thing in this program that
        # is never written anywhere, debug or no debug, and a bind is where
        # it would be easiest to write by accident.
        if debugging('ldap'):
            log('ldap %s: signing in as %s (the password is never logged)'
                % (self.host, dn or 'nobody — anonymous'), 'debug')
        op = _ber(0x60, _ber_int(3) + _ber_str(dn)
                  + _ber_str(password, tag=0x80))
        tag, body = self._ask(op)
        if tag != 0x61:
            raise LdapError('the server did not answer the sign-in')
        code, said = self._result_of(body)
        if code != LDAP_OK:
            plain = ad_reason(said) or LDAP_SAYS.get(code, 'the directory said %d' % code)
            raise LdapError(plain, code,
                            detail='%s (result %d)' % (said, code) if said else '')
        return True

    # Simple paged results: the control every directory of any size needs.
    # Active Directory will not hand back more than its MaxPageSize - a
    # thousand entries by default - however large a size limit is asked for.
    # It answers with a cookie instead, and the next page is asked for by
    # handing that cookie back. Without it, a domain with three thousand
    # groups looked like a domain with a thousand, and nobody could tell
    # which thousand.
    PAGED_OID = '1.2.840.113556.1.4.319'
    PAGE_SIZE = 500

    def _paging_control(self, cookie=b'', size=None):
        # `size=0` with the cookie is how a paged search is given up on
        # (RFC 2696): the server lets the result set go. Anything else with
        # the cookie asks for the next page.
        inner = _ber(0x30, _ber_int(self.PAGE_SIZE if size is None else int(size))
                     + _ber_str(cookie))
        return _ber(0xA0, _ber(0x30, _ber_str(self.PAGED_OID) + _ber_str(inner)))

    def _paging_cookie(self, controls):
        """The cookie out of a searchResDone, or b'' when there is no more."""
        if not controls:
            return b''
        try:
            tag, body, _ = _ber_read(controls)         # [0] controls
            at = 0
            while at < len(body):
                _t, one, at = _ber_read(body, at)
                _t, oid, where = _ber_read(one)
                if oid.decode('utf-8', 'replace') != self.PAGED_OID:
                    continue
                while where < len(one):
                    _t, value, where = _ber_read(one, where)
                    if _t != 0x04:                     # criticality, skip it
                        continue
                    _t, inner, _ = _ber_read(value)
                    _t, _size, deep = _ber_read(inner)
                    _t, cookie, _ = _ber_read(inner, deep)
                    return cookie
        except (ValueError, IndexError):
            return b''
        return b''

    def search(self, base, filter_ber, attrs=(), scope=2, limit=200, paged=False):
        try:
            return self._search(base, filter_ber, attrs, scope, limit, paged)
        except (ValueError, IndexError) as e:
            raise LdapError('%s sent an answer that does not read: %s' % (self.host, e))
        finally:
            self._deadline = 0

    def _search(self, base, filter_ber, attrs=(), scope=2, limit=200, paged=False):
        """Entries under `base` matching `filter_ber`.

        scope 0 = that entry, 1 = one level down, 2 = everything below.
        Referrals are skipped: Active Directory answers a search at the
        domain root with one per other partition, and following them needs
        credentials for those partitions.

        `paged` asks the directory for it a page at a time and keeps going
        until it says there is no more, which is the only way to see past a
        thousand of anything on Active Directory. `limit` is then how many
        this will hold rather than how many the directory will send.
        """
        want = b''.join(_ber_str(a) for a in attrs)
        cap = max(0, int(limit))
        out = []
        cookie = b''
        # With the LDAP debug on, what is being asked and what came back.
        # Two lines rather than one - the question goes into the log BEFORE
        # the directory is asked, so a search that never answers is still in
        # there with the question that hung it, which is the whole reason
        # anybody turns this on.
        loud = debugging('ldap')
        began = time.time()
        if loud:
            log('ldap %s: %s under %s, %s, wanting %s%s'
                % (self.host, ldap_filter_words(filter_ber), base or '(root)',
                   LDAP_SCOPE_WORDS.get(int(scope), 'scope %d' % scope),
                   ', '.join(attrs) if attrs else 'everything',
                   ', a page at a time' if paged else ''), 'debug')
        # A page count as well as the two exits below. A directory that hands
        # back a cookie with no entries in it - broken, or hostile - would
        # otherwise keep this thread here for ever.
        pages = 0
        while True:
            pages += 1
            if pages > self.PAGES_MOST:
                # What was read so far is the answer, said to be cut short -
                # NOT nothing. This used to fall out of the loop with no
                # return at all, so a search over more than a hundred
                # thousand entries came back as `None`, the caller read that
                # as "nought of them", and a big domain's count of switched-
                # off accounts was written down as zero.
                log('%s: one search ran to %d pages (%s entries) and was cut short there'
                    % (self.host, pages - 1, len(out)), 'warn')
                self._let_go(base, scope, filter_ber, want, cookie)
                return out
            asked = 0 if paged else cap
            op = _ber(0x63,
                      _ber_str(base) + _ber_int(scope, tag=0x0A) + _ber_int(0, tag=0x0A)
                      + _ber_int(asked) + _ber_int(int(self.timeout))
                      + _ber_bool(False) + filter_ber + _ber(0x30, want))
            mid = self._send(op, self._paging_control(cookie) if paged else b'')
            self._deadline = time.time() + self.timeout * 3   # per page (1.0.36)
            done = False
            while not done:
                got_id, tag, body = self._read_message()
                if got_id != mid:
                    continue
                if tag == 0x64:                        # searchResEntry
                    if not cap or len(out) < cap:
                        out.append(self._entry_of(body))
                elif tag == 0x73:                      # searchResRef
                    continue
                elif tag == 0x65:                      # searchResDone
                    code, said = self._result_of(body)
                    if code not in (LDAP_OK, 4, LDAP_NO_SUCH_OBJECT):
                        raise LdapError(said or LDAP_SAYS.get(
                            code, 'the directory said %d' % code), code)
                    cookie = self._paging_cookie(self.last_controls) if paged else b''
                    done = True
                else:
                    raise LdapError('the server sent an answer this does not understand')
            self._deadline = 0
            if not paged or not cookie or (cap and len(out) >= cap):
                # A search that is being given up on mid-way is abandoned
                # properly, so the directory is not left holding the page.
                if paged and cookie:
                    self._let_go(base, scope, filter_ber, want, cookie)
                if loud:
                    log('ldap %s: %d entr%s in %d ms%s%s'
                        % (self.host, len(out), 'y' if len(out) == 1 else 'ies',
                           int((time.time() - began) * 1000),
                           ' over %d pages' % pages if pages > 1 else '',
                           (' — ' + ldap_entry_words(out)) if out else ''), 'debug')
                return out

    def _let_go(self, base, scope, filter_ber, want, cookie):
        """Tell the directory to drop a paged search that will not be finished.

        RFC 2696: the same search again, with the cookie and a page size of
        NOUGHT. Sent with the ordinary page size - which is what this did -
        it is not an abandon at all but a request for another five hundred
        entries, whose reply then sits unread on the connection; and a
        directory allows only so many open result sets per connection, so
        the tenth search that stopped early made the eleventh fail.
        """
        try:
            mid = self._send(_ber(0x63,
                                  _ber_str(base) + _ber_int(scope, tag=0x0A)
                                  + _ber_int(0, tag=0x0A) + _ber_int(0)
                                  + _ber_int(int(self.timeout)) + _ber_bool(True)
                                  + filter_ber + _ber(0x30, want)),
                             self._paging_control(cookie, size=0))
            # ...and its one-line answer read, so it is not left lying on
            # the connection for the next search to trip over.
            self._deadline = time.time() + self.timeout
            for _ in range(50):
                got_id, tag, _body = self._read_message()
                if got_id == mid and tag == 0x65:
                    break
        except (OSError, LdapError, ValueError):
            pass
        finally:
            self._deadline = 0

    @staticmethod
    def _entry_of(body):
        tag, dn_body, at = _ber_read(body)
        entry = {'dn': dn_body.decode('utf-8', 'replace'), 'attrs': {}}
        tag, attrs_body, _ = _ber_read(body, at)
        inner = 0
        while inner < len(attrs_body):
            _t, one, inner = _ber_read(attrs_body, inner)
            _t, name, where = _ber_read(one)
            _t, values, _ = _ber_read(one, where)
            got = []
            deep = 0
            while deep < len(values):
                _t, value, deep = _ber_read(values, deep)
                got.append(value.decode('utf-8', 'replace'))
            entry['attrs'][name.decode('utf-8', 'replace')] = got
        return entry



# ---------------------------------------------------------------------------
# RADIUS, the protocol (RFC 2865, 2866, 2869, 3579, 5997)
# ---------------------------------------------------------------------------
# A packet is a code, an identifier, a length, sixteen bytes of authenticator
# and a run of attributes, each a type, a length and a value. The dictionary
# below names the attributes a VPN concentrator and a token server actually
# use; anything else is kept and written down by its number, the way
# FreeRADIUS writes an attribute it has no name for.

ACCESS_REQUEST, ACCESS_ACCEPT, ACCESS_REJECT = 1, 2, 3
ACCOUNTING_REQUEST, ACCOUNTING_RESPONSE = 4, 5
ACCESS_CHALLENGE, STATUS_SERVER = 11, 12
CODE_WORDS = {1: 'Access-Request', 2: 'Access-Accept', 3: 'Access-Reject',
              4: 'Accounting-Request', 5: 'Accounting-Response', 11: 'Access-Challenge',
              12: 'Status-Server'}

# number: (name, type) - types: string, octets, integer, ipaddr, date, ipv6addr
RADIUS_ATTRS = {
    1: ('User-Name', 'string'), 2: ('User-Password', 'octets'),
    3: ('CHAP-Password', 'octets'), 4: ('NAS-IP-Address', 'ipaddr'),
    5: ('NAS-Port', 'integer'), 6: ('Service-Type', 'integer'),
    7: ('Framed-Protocol', 'integer'), 8: ('Framed-IP-Address', 'ipaddr'),
    9: ('Framed-IP-Netmask', 'ipaddr'), 10: ('Framed-Routing', 'integer'),
    11: ('Filter-Id', 'string'), 12: ('Framed-MTU', 'integer'),
    13: ('Framed-Compression', 'integer'), 14: ('Login-IP-Host', 'ipaddr'),
    18: ('Reply-Message', 'string'), 22: ('Framed-Route', 'string'),
    24: ('State', 'octets'), 25: ('Class', 'string'), 26: ('Vendor-Specific', 'octets'),
    27: ('Session-Timeout', 'integer'), 28: ('Idle-Timeout', 'integer'),
    29: ('Termination-Action', 'integer'), 30: ('Called-Station-Id', 'string'),
    31: ('Calling-Station-Id', 'string'), 32: ('NAS-Identifier', 'string'),
    33: ('Proxy-State', 'octets'), 40: ('Acct-Status-Type', 'integer'),
    41: ('Acct-Delay-Time', 'integer'), 42: ('Acct-Input-Octets', 'integer'),
    43: ('Acct-Output-Octets', 'integer'), 44: ('Acct-Session-Id', 'string'),
    45: ('Acct-Authentic', 'integer'), 46: ('Acct-Session-Time', 'integer'),
    47: ('Acct-Input-Packets', 'integer'), 48: ('Acct-Output-Packets', 'integer'),
    49: ('Acct-Terminate-Cause', 'integer'), 50: ('Acct-Multi-Session-Id', 'string'),
    52: ('Acct-Input-Gigawords', 'integer'), 53: ('Acct-Output-Gigawords', 'integer'),
    55: ('Event-Timestamp', 'date'), 60: ('CHAP-Challenge', 'octets'),
    61: ('NAS-Port-Type', 'integer'), 62: ('Port-Limit', 'integer'),
    64: ('Tunnel-Type', 'tagint'), 65: ('Tunnel-Medium-Type', 'tagint'),
    66: ('Tunnel-Client-Endpoint', 'tagstr'), 67: ('Tunnel-Server-Endpoint', 'tagstr'),
    77: ('Connect-Info', 'string'), 79: ('EAP-Message', 'octets'),
    80: ('Message-Authenticator', 'octets'), 81: ('Tunnel-Private-Group-Id', 'tagstr'),
    85: ('Acct-Interim-Interval', 'integer'), 87: ('NAS-Port-Id', 'string'),
    88: ('Framed-Pool', 'string'), 95: ('NAS-IPv6-Address', 'ipv6addr'),
    101: ('Error-Cause', 'integer'),
}
RADIUS_NUMBERS = {v[0].lower(): (k, v[1]) for k, v in RADIUS_ATTRS.items()}

# The values worth naming. Everything else is written as its number.
RADIUS_VALUES = {
    'Service-Type': {1: 'Login-User', 2: 'Framed-User', 5: 'Outbound-User',
                     6: 'Administrative-User', 7: 'NAS-Prompt-User', 8: 'Authenticate-Only',
                     10: 'Call-Check'},
    'NAS-Port-Type': {0: 'Async', 5: 'Virtual', 15: 'Ethernet', 19: 'Wireless-802.11'},
    'Acct-Status-Type': {1: 'Start', 2: 'Stop', 3: 'Interim-Update', 7: 'Accounting-On',
                         8: 'Accounting-Off'},
    'Framed-Protocol': {1: 'PPP', 2: 'SLIP'},
    'Tunnel-Type': {3: 'L2TP', 13: 'VLAN'},
    'Tunnel-Medium-Type': {1: 'IPv4', 6: '802'},
    'Acct-Authentic': {1: 'RADIUS', 2: 'Local', 3: 'Remote'},
    'Acct-Terminate-Cause': {1: 'User-Request', 2: 'Lost-Carrier', 4: 'Idle-Timeout',
                             5: 'Session-Timeout', 6: 'Admin-Reset', 10: 'NAS-Request'},
}

# Vendor attributes: (vendor, number) -> (name, type).
VENDORS = {9: 'Cisco', 311: 'Microsoft', 3076: 'Cisco-VPN3000'}
VSA_ATTRS = {
    (9, 1): ('Cisco-AVPair', 'string'),
    (3076, 25): ('ASA-Group-Policy', 'string'),
    (3076, 85): ('ASA-Tunnel-Group-Lock', 'string'),
    (3076, 146): ('ASA-TunnelGroupName', 'string'),
    (3076, 150): ('ASA-ClientType', 'integer'),
    (3076, 151): ('ASA-SessionType', 'integer'),
    (3076, 152): ('ASA-SessionSubtype', 'integer'),
}
VSA_NUMBERS = {v[0].lower(): (k, v[1]) for k, v in VSA_ATTRS.items()}

# What may be put into an answer by name, with how it is written. Listed so
# that a realm's reply lines are checked when they are saved rather than when
# somebody first signs in.
REPLY_ATTRS = ('Reply-Message', 'Class', 'Filter-Id', 'Session-Timeout', 'Idle-Timeout',
               'Service-Type', 'Framed-IP-Address', 'Framed-IP-Netmask', 'Framed-Pool',
               'Acct-Interim-Interval', 'Tunnel-Type', 'Tunnel-Medium-Type',
               'Tunnel-Private-Group-Id', 'Cisco-AVPair', 'ASA-Group-Policy',
               'ASA-Tunnel-Group-Lock')


class RadiusError(ValueError):
    pass


def _value_words(name, kind, raw):
    """One attribute's value, as FreeRADIUS writes it in a detail file."""
    try:
        if kind == 'string':
            return raw.decode('utf-8', 'replace')
        if kind in ('integer', 'date'):
            if len(raw) != 4:
                return '0x' + raw.hex()
            n = struct.unpack('>I', raw)[0]
            return RADIUS_VALUES.get(name, {}).get(n, str(n))
        if kind == 'ipaddr':
            return socket.inet_ntoa(raw) if len(raw) == 4 else '0x' + raw.hex()
        if kind == 'ipv6addr':
            return socket.inet_ntop(socket.AF_INET6, raw) if len(raw) == 16 else '0x' + raw.hex()
        if kind == 'tagint':
            if len(raw) == 4:
                n = struct.unpack('>I', b'\x00' + raw[1:])[0]
                return RADIUS_VALUES.get(name, {}).get(n, str(n))
        if kind == 'tagstr':
            if raw and raw[0] < 0x20:
                raw = raw[1:]
            return raw.decode('utf-8', 'replace')
    except (ValueError, OSError, struct.error):
        pass
    return '0x' + raw.hex()


def _value_bytes(name, kind, value):
    text = str(value).strip()
    if kind == 'string':
        return text.encode('utf-8')
    if kind == 'integer' or kind == 'date':
        names = {v.lower(): k for k, v in RADIUS_VALUES.get(name, {}).items()}
        n = names.get(text.lower())
        if n is None:
            try:
                n = int(text)
            except ValueError:
                raise RadiusError('%s takes a number%s, not %r' % (
                    name, (' or one of ' + ', '.join(RADIUS_VALUES[name].values()))
                    if name in RADIUS_VALUES else '', text))
        return struct.pack('>I', n)
    if kind == 'ipaddr':
        try:
            return socket.inet_aton(str(ipaddress.IPv4Address(text)))
        except ValueError:
            raise RadiusError('%s takes an IPv4 address, not %r' % (name, text))
    if kind == 'tagint':
        names = {v.lower(): k for k, v in RADIUS_VALUES.get(name, {}).items()}
        n = names.get(text.lower())
        if n is None:
            try:
                n = int(text)
            except ValueError:
                raise RadiusError('%s takes a number, not %r' % (name, text))
        return b'\x00' + struct.pack('>I', n)[1:]
    if kind == 'tagstr':
        return text.encode('utf-8')
    if kind == 'octets':
        if text.lower().startswith('0x'):
            return bytes.fromhex(text[2:])
        return text.encode('utf-8')
    return text.encode('utf-8')


def attr_bytes(name, value):
    """`Name = value` as the bytes of one attribute (a vendor one wrapped in
    Vendor-Specific)."""
    key = str(name).strip().lower()
    if key in RADIUS_NUMBERS:
        num, kind = RADIUS_NUMBERS[key]
        body = _value_bytes(RADIUS_ATTRS[num][0], kind, value)
        if len(body) > 253:
            raise RadiusError('%s is longer than one attribute may be (253 bytes)' % name)
        return bytes([num, len(body) + 2]) + body
    if key in VSA_NUMBERS:
        (vendor, num), kind = VSA_NUMBERS[key]
        body = _value_bytes(VSA_ATTRS[(vendor, num)][0], kind, value)
        if len(body) > 247:
            raise RadiusError('%s is longer than one attribute may be' % name)
        sub = bytes([num, len(body) + 2]) + body
        inner = struct.pack('>I', vendor) + sub
        return bytes([26, len(inner) + 2]) + inner
    raise RadiusError('%s is not an attribute this server knows how to send. It knows: %s'
                      % (name, ', '.join(REPLY_ATTRS)))


def reply_lines(text):
    """A realm's or a group's reply, `Name = value` a line, as pairs. Raises
    RadiusError naming the line that will not do."""
    out = []
    for n, line in enumerate(str(text or '').splitlines(), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        m = re.match(r'^([A-Za-z0-9-]+)\s*:?\+?=\s*(.*)$', line)
        if not m:
            raise RadiusError('line %d, %r: write it as Name = value' % (n, line[:60]))
        value = m.group(2).strip()
        if len(value) >= 2 and value[0] == value[-1] == '"':
            value = value[1:-1]
        # Only what an answer may carry (1.0.33): not a Message-Authenticator,
        # a User-Password or a State written into a realm's reply.
        if m.group(1) not in REPLY_ATTRS:
            raise RadiusError('line %d: %s is not something an answer carries here - one of %s'
                              % (n, m.group(1), ', '.join(REPLY_ATTRS)))
        try:
            attr_bytes(m.group(1), value)
        except (struct.error, ValueError) as e:
            raise RadiusError('line %d: %s' % (n, e))
        out.append((m.group(1), value))
    return out


class Packet(object):
    """One RADIUS packet, read or being made."""

    def __init__(self, code=0, ident=0, authenticator=b'\x00' * 16, raw=b''):
        self.code = code
        self.ident = ident
        self.authenticator = authenticator
        self.attrs = []                       # [(number, bytes)] as they came
        self.raw = raw

    @classmethod
    def parse(cls, data):
        if len(data) < 20:
            raise RadiusError('shorter than a RADIUS packet can be')
        code, ident, length = struct.unpack('>BBH', data[:4])
        if length < 20 or length > 4096 or length > len(data):
            raise RadiusError('the length it gives (%d) is not the length it has' % length)
        pkt = cls(code, ident, data[4:20], data[:length])
        at = 20
        while at < length:
            if at + 2 > length:
                raise RadiusError('an attribute is cut off')
            kind, size = data[at], data[at + 1]
            if size < 2 or at + size > length:
                raise RadiusError('an attribute says it is %d bytes long' % size)
            pkt.attrs.append((kind, data[at + 2:at + size]))
            at += size
        return pkt

    def get(self, number):
        for k, v in self.attrs:
            if k == number:
                return v
        return None

    def all(self, number):
        return [v for k, v in self.attrs if k == number]

    def text(self, number):
        got = self.get(number)
        return got.decode('utf-8', 'replace') if got is not None else ''

    def vsa(self):
        """[(vendor, number, bytes)] out of every Vendor-Specific."""
        out = []
        for raw in self.all(26):
            if len(raw) < 6:
                continue
            vendor = struct.unpack('>I', raw[:4])[0]
            at = 4
            while at + 2 <= len(raw):
                num, size = raw[at], raw[at + 1]
                if size < 2 or at + size > len(raw):
                    break
                out.append((vendor, num, raw[at + 2:at + size]))
                at += size
        return out

    def words(self, secret=None):
        """Every attribute as (Name, value), in order, the way FreeRADIUS
        writes them in a detail file. Passwords are never in it."""
        out = []
        for num, raw in self.attrs:
            if num == 26:
                continue
            name, kind = RADIUS_ATTRS.get(num, ('Attr-%d' % num, 'octets'))
            if num in (2, 3):
                out.append((name, '<suppressed>'))
                continue
            if num == 80:
                out.append((name, '0x' + raw.hex()))
                continue
            out.append((name, _value_words(name, kind, raw)))
        for vendor, num, raw in self.vsa():
            name, kind = VSA_ATTRS.get((vendor, num), (None, 'octets'))
            if name and (vendor, num) != (3076, 146):
                out.append((name, _value_words(name, kind, raw)))
            else:
                # As FreeRADIUS 2 writes an attribute it has no name for -
                # which is also how isemon reads the ASA's tunnel group.
                out.append(('Vendor-%d-Attr-%d' % (vendor, num), '0x' + raw.hex()))
        return out

    # ---- the passwords and the signatures ------------------------------------
    def password(self, secret):
        """User-Password, undone (RFC 2865 5.2)."""
        raw = self.get(2)
        if raw is None:
            return None
        if len(raw) % 16 or not raw:
            raise RadiusError('the User-Password is not a multiple of sixteen bytes')
        out = b''
        last = self.authenticator
        for at in range(0, len(raw), 16):
            block = raw[at:at + 16]
            pad = hashlib.md5(secret + last).digest()
            out += bytes(a ^ b for a, b in zip(block, pad))
            last = block
        return out.rstrip(b'\x00').decode('utf-8', 'replace')

    def message_authenticator_ok(self, secret):
        """True where it is right, False where it is wrong, None where there is
        none. Over the packet with the attribute's value as sixteen noughts."""
        at = 20
        data = bytearray(self.raw)
        found = None
        while at < len(data):
            kind, size = data[at], data[at + 1]
            if kind == 80:
                # One, of the one right length - anything else is wrong, not
                # missing (1.0.33): a mangled one was taken for none at all.
                if size != 18 or found is not None:
                    return False
                found = bytes(data[at + 2:at + 18])
                data[at + 2:at + 18] = b'\x00' * 16
            at += size
        if found is None:
            return None
        want = hmac.new(secret, bytes(data), hashlib.md5).digest()
        return hmac.compare_digest(found, want)

    def accounting_ok(self, secret):
        """An Accounting-Request's authenticator (RFC 2866 3)."""
        data = self.raw[:4] + b'\x00' * 16 + self.raw[20:]
        return hmac.compare_digest(hashlib.md5(data + secret).digest(), self.authenticator)


def build_reply(request, code, pairs, secret, with_ma=True):
    """An answer to `request`: its identifier, the attributes in `pairs`
    (already bytes), a Message-Authenticator where asked for (RFC 3579 3.2),
    and the Response Authenticator over all of it."""
    body = b''.join(pairs)
    # Every Proxy-State of the request back, unchanged and in order (RFC 2865
    # 5.33; 1.0.44): a proxy in between throws away an answer without it.
    for ps in (request.all(33) or []):
        body += bytes([33, len(ps) + 2]) + bytes(ps)
    if with_ma:
        # First, as the BlastRADIUS advice has it (1.0.33).
        body = bytes([80, 18]) + b'\x00' * 16 + body
    length = 20 + len(body)
    if length > 4096:
        raise RadiusError('the answer is longer than a RADIUS packet may be')
    head = struct.pack('>BBH', code, request.ident, length)
    if with_ma:
        ma = hmac.new(secret, head + request.authenticator + body, hashlib.md5).digest()
        body = body[:2] + ma + body[18:]
    auth = hashlib.md5(head + request.authenticator + body + secret).digest()
    return head + auth + body


def build_request(code, ident, pairs, secret, password=None, with_ma=True):
    """A request, as a client sends one - for `otp --radtest` and the test
    page. `password` goes in as User-Password, hidden the RFC 2865 way."""
    authenticator = secrets.token_bytes(16) if code != ACCOUNTING_REQUEST else b'\x00' * 16
    body = b''.join(pairs)
    if password is not None:
        pw = str(password).encode('utf-8')
        pw += b'\x00' * ((16 - len(pw) % 16) % 16 or (16 if not pw else 0))
        out, last = b'', authenticator
        for at in range(0, len(pw), 16):
            pad = hashlib.md5(secret + last).digest()
            block = bytes(a ^ b for a, b in zip(pw[at:at + 16], pad))
            out += block
            last = block
        body += bytes([2, len(out) + 2]) + out
    if with_ma and code in (ACCESS_REQUEST, STATUS_SERVER):
        body += bytes([80, 18]) + b'\x00' * 16
    head = struct.pack('>BBH', code, ident, 20 + len(body))
    if code == ACCOUNTING_REQUEST:
        authenticator = hashlib.md5(head + b'\x00' * 16 + body + secret).digest()
    elif with_ma and code in (ACCESS_REQUEST, STATUS_SERVER):
        ma = hmac.new(secret, head + authenticator + body, hashlib.md5).digest()
        body = body[:-16] + ma
    return head + authenticator + body, authenticator


def reply_ok(reply, request_auth, secret):
    """Whether an answer really came from a server holding the secret."""
    if len(reply) < 20:
        return False
    want = hashlib.md5(reply[:4] + request_auth + reply[20:] + secret).digest()
    return hmac.compare_digest(want, reply[4:20])


def radius_ask(server, port, secret, user, password, nas_ip='127.0.0.1', timeout=5.0,
               tries=2, extra=(), code=ACCESS_REQUEST):
    """Ask a RADIUS server, the way radtest does. Returns (code, [(Name,
    value)], took_ms) or raises RadiusError."""
    secret_b = str(secret).encode('utf-8')
    pairs = []
    if user is not None:
        pairs.append(attr_bytes('User-Name', user))
    pairs.append(bytes([4, 6]) + socket.inet_aton(nas_ip))
    pairs.append(bytes([5, 6]) + struct.pack('>I', 0))
    for name, value in extra:
        pairs.append(attr_bytes(name, value))
    ident = secrets.randbelow(256)
    data, auth = build_request(code, ident, pairs, secret_b,
                               password=password if code == ACCESS_REQUEST else None)
    family = socket.AF_INET6 if ':' in str(server) else socket.AF_INET
    sock = socket.socket(family, socket.SOCK_DGRAM)
    sock.settimeout(float(timeout))
    began = time.time()
    try:
        for _ in range(max(1, int(tries))):
            sock.sendto(data, (server, int(port)))
            try:
                while True:
                    reply, _ = sock.recvfrom(4096)
                    if len(reply) >= 20 and reply[1] == ident:
                        break
            except socket.timeout:
                continue
            if not reply_ok(reply, auth, secret_b):
                raise RadiusError('an answer came, and it was not signed with that secret')
            pkt = Packet.parse(reply)
            return pkt.code, pkt.words(), int((time.time() - began) * 1000)
        raise RadiusError('no answer from %s:%s in %d tries of %.0f s - wrong secret, a '
                          'firewall, or this address is not one of its clients'
                          % (server, port, tries, timeout))
    finally:
        sock.close()


# ---------------------------------------------------------------------------
# What is kept, and how it is asked for
# ---------------------------------------------------------------------------
def secret_shown(value):
    """A secret as the page may see it: dots and its last two characters, so
    that "the one I set" can be told from "something else"."""
    said = str(value or '')
    if not said:
        return ''
    return '•' * min(10, max(4, len(said) - 2)) + said[-2:] if len(said) > 4 else '•' * 6


def is_masked(value):
    return isinstance(value, str) and value.startswith('•')


def norm_name(name):
    said = str(name or '').strip()
    if CONFIG.get('token_names_case', 'lower') == 'lower':
        said = said.lower()
    return said[:190]


def address_net(text):
    """An address or a range of them, as a network - ValueError if neither."""
    said = str(text or '').strip()
    if not said:
        raise ValueError('an address is needed')
    return ipaddress.ip_network(said, strict=False)



# ---------------------------------------------------------------------------
# `field:value` in every search box (1.0.19, as isemon's ListQuery)
# ---------------------------------------------------------------------------
# What is typed into a list's search box is read as isemon reads it: words
# as before, and besides them `field:value` - `result:reject client:ASA`,
# `name:novak*`, `-state:active`, `realm:dpmo.cz,corpnet.cz`, `ms:>500`,
# `(client:ASA OR client:localhost) reason~ldap`. A name the list does not
# have is not a field at all - `10.1.2.3:1812` is a word - and a box with no
# field in it searches exactly as it did.
#
# kind: text (folded; `*` a wildcard), num (a number, a range, > <), ip (an
# address or the start of one; `/24` a range), ok (accept/reject as 1/0),
# realm (what follows the @ in the name), none (not in this list: no row).
LIST_FIELDS = {
    'tokens': {
        'name': ('name', 'text'), 'user': ('name', 'text'), 'token': ('name', 'text'),
        'owner': ('display', 'text'), 'who': ('display', 'text'),
        'state': ('state', 'text'), 'realm': ('name', 'realm'),
        'by': ('created_by', 'text'), 'made_by': ('created_by', 'text'),
        'note': ('note', 'text'), 'from': ('last_from', 'ip'), 'ip': ('last_from', 'ip'),
        'how': ('last_how', 'text'), 'recovery': ('scratch_left', 'num'),
        'wrong': ('failures', 'num'), 'digits': ('digits', 'num'),
    },
    'radius': {
        'name': ('username', 'text'), 'user': ('username', 'text'),
        'result': ('result', 'text'), 'client': ('client', 'text'),
        'where': ('client', 'text'), 'from': ('calling', 'ip'), 'ip': ('calling', 'ip'),
        'address': ('calling', 'ip'), 'nas': ('nas_ip', 'ip'),
        'reason': ('reason', 'text'), 'why': ('reason', 'text'), 'realm': ('realm', 'text'),
        'device': ('device', 'text'), 'machine': ('device', 'text'),
        'tunnel': ('tunnel', 'text'), 'group': ('tunnel', 'text'),
        'packet': ('packet', 'text'), 'ms': ('took_ms', 'num'), 'code': ('otp', 'text'),
        'how': ('', 'none'), 'node': ('node', 'text'), 'server': ('node', 'text'),
    },
    'otp': {
        'name': ('name', 'text'), 'user': ('name', 'text'), 'result': ('ok', 'ok'),
        'why': ('said', 'text'), 'reason': ('said', 'text'), 'code': ('said', 'text'),
        'from': ('src', 'ip'), 'ip': ('src', 'ip'), 'address': ('src', 'ip'),
        'how': ('how', 'text'), 'where': ('how', 'text'),
        'client': ('', 'none'), 'realm': ('name', 'realm'), 'device': ('', 'none'),
        'tunnel': ('', 'none'), 'nas': ('', 'none'), 'packet': ('', 'none'),
        'ms': ('', 'none'), 'machine': ('', 'none'), 'group': ('', 'none'),
        'node': ('node', 'text'), 'server': ('node', 'text'),
    },
    'events': {
        'kind': ('kind', 'text'), 'who': ('who', 'text'), 'by': ('who', 'text'),
        'what': ('words', 'text'), 'level': ('level', 'text'), 'node': ('node', 'text'),
        'server': ('node', 'text'),
    },
    'enrolment': {
        'who': ('who', 'text'), 'name': ('who', 'text'), 'what': ('words', 'text'),
        'step': ('words', 'step'), 'from': ('words', 'fromip'), 'ip': ('words', 'fromip'),
        'node': ('node', 'text'), 'server': ('node', 'text'),
    },
}
# What each field means, with an example - what the box offers as one types.
LIST_FIELD_SAYS = {
    'tokens': [('name', 'the name of the token', 'name:novak*'),
               ('owner', 'the owner\'s name from the directory', 'owner:"Jan Novak"'),
               ('state', 'active, pending or disabled', 'state:pending'),
               ('realm', 'what follows the @', 'realm:example.cz'),
               ('by', 'who or what made it', 'by:import*'),
               ('note', 'the note', 'note~totpcgi'),
               ('from', 'the address it was last used from', 'from:10.1.*'),
               ('recovery', 'recovery codes left', 'recovery:<2'),
               ('wrong', 'wrong codes in a row', 'wrong:>0')],
    'radius': [('name', 'the name the VPN sent', 'name:novak*'),
               ('result', 'accept, reject, drop or acct', 'result:reject'),
               ('client', 'the client that asked', 'client:ASA'),
               ('reason', 'why - what the token said', 'reason~ldap'),
               ('from', 'the person\'s own address', 'from:203.0.113.*'),
               ('realm', 'the realm it fell in', 'realm:example.cz'),
               ('device', 'the computer name the VPN passed', 'device:DESKTOP*'),
               ('tunnel', 'the tunnel group', 'tunnel:VPN*'),
               ('nas', 'the address of the client', 'nas:192.0.2.1'),
               ('ms', 'how long the answer took', 'ms:>500'),
               ('how', 'where a code was checked besides RADIUS', 'how:portal'),
               ('node', 'the node that answered (high availability)', 'node:otp2')],
    'events': [('kind', 'the kind of event', 'kind:tokens'),
               ('who', 'who did it', 'who:admin'),
               ('what', 'what it says', 'what~realm'),
               ('level', 'info or warn', 'level:warn'),
               ('node', 'the node it happened on (high availability)', 'node:otp2')],
    'enrolment': [('who', 'the person', 'who:novak*'),
                  ('step', 'signed_in, enrolled, confirmed, replacing, stopped, refused, not_allowed',
                   'step:refused'),
                  ('from', 'the address they came from', 'from:10.*'),
                  ('what', 'what happened', 'what~groups'),
                  ('node', 'the node it happened on (high availability)', 'node:otp2')],
}
LIST_WORD_COLUMNS = {
    'tokens': ('name', 'note', 'display'),
    'radius': ('username', 'calling', 'reason', 'client', 'device', 'otp'),
    'otp': ('name', 'said', 'src'),
    'events': ('words', 'who', 'kind'),
    'enrolment': ('words', 'who'),
}
LIST_TOKEN = re.compile(r'\s*(\(|\)|[-!]?(?:[A-Za-z_][\w.]*(?:!=|>=|<=|[:~=<>]))?'
                        r'(?:"[^"]*"?|[^\s()"]+)|"[^"]*"?)')
LIST_TERM = re.compile(r'^([-!]?)([A-Za-z_][\w]*)(!=|>=|<=|[:~=<>])(.*)$', re.S)


class ListQueryError(ValueError):
    pass


def log_node():
    """The node a log line is written on (1.0.45) - whose it is, in a
    cluster."""
    try:
        return node_name()[:190]
    except Exception:                                   # noqa: BLE001
        return ''


def like_pattern(text):
    """`*` a wildcard, everything else itself; `!` is the escape."""
    out = ''
    for c in str(text):
        if c == '*':
            out += '%'
        elif c in '%_!':
            out += '!' + c
        else:
            out += c
    return out


class ListQuery(object):
    """`sql`/`args` is the piece of the WHERE the fields make (empty where
    there are none); `words` is what goes to the list's own word search."""

    def __init__(self, listname, text):
        self.list = listname
        self.fields = LIST_FIELDS.get(listname, {})
        self.text = str(text or '').strip()
        self.sql, self.args, self.words = '', [], self.text
        if len(self.text) > 2000:
            raise ListQueryError('that search is too long - 2000 characters at most')
        self.tokens = [m.group(1) for m in LIST_TOKEN.finditer(self.text) if m.group(1)]
        if not any(self._field(t) for t in self.tokens):
            return
        if len(self.tokens) > 300:
            raise ListQueryError('that search has too many parts')
        # NOT on NOT on NOT, or bracket in bracket, a few hundred deep, made
        # SQLite give up parsing (1.0.33): twenty is more than anybody writes.
        if sum(1 for t in self.tokens if t in ('NOT', '!', '(')) > 40:
            raise ListQueryError('that search has too many NOTs and brackets in it')
        self.at, self.top_words = 0, []
        node = self._or(True)
        if self.at < len(self.tokens):
            raise ListQueryError('a closing bracket with nothing open before it')
        words = [w.strip('"') for w in self.top_words if w.strip('"')]
        self.words = words[0] if words else ''
        node = self._join('AND', [node] + [self._word(w) for w in words[1:]])
        if node:
            self.sql, self.args = node

    def _field(self, token):
        m = LIST_TERM.match(token or '')
        return m if m and m.group(2).lower() in self.fields else None

    def _peek(self):
        return self.tokens[self.at] if self.at < len(self.tokens) else None

    @staticmethod
    def _join(op, parts):
        parts = [p for p in parts if p]
        if not parts:
            return None
        if len(parts) == 1:
            return parts[0]
        return ('(' + (' %s ' % op).join(p[0] for p in parts) + ')',
                [a for p in parts for a in p[1]])

    def _or(self, top=False):
        parts, alone = [self._and(top)], True
        while self._peek() in ('OR', '|', '||'):
            alone = False
            self.at += 1
            if self._peek() in (None, ')'):
                raise ListQueryError('OR with nothing after it')
            parts.append(self._and(False))
        if not alone and top and self.top_words:
            raise ListQueryError('a word on its own beside OR - write it as a field, or put '
                                 'the OR in brackets')
        return self._join('OR', parts)

    def _and(self, top):
        parts = [self._not(top)]
        while self._peek() not in (None, ')', 'OR', '|', '||'):
            if self._peek() in ('AND', '&', '&&'):
                self.at += 1
                continue
            parts.append(self._not(top))
        return self._join('AND', parts)

    def _not(self, top):
        t = self._peek()
        if t in ('NOT', '!'):
            self.at += 1
            inner = self._not(False)
            return ('NOT COALESCE((%s), 1=0)' % inner[0], inner[1]) if inner else None
        if t == '(':
            self.at += 1
            inner = self._or(False)
            if self._peek() != ')':
                raise ListQueryError('a bracket opened and never closed')
            self.at += 1
            return inner
        if t == ')':
            raise ListQueryError('a closing bracket with nothing open before it')
        self.at += 1
        return self._leaf(t, top)

    def _word(self, word):
        cols = LIST_WORD_COLUMNS.get(self.list, ())
        like = '%' + like_pattern(word.lower()) + '%'
        return ('(' + ' OR '.join("LOWER(COALESCE(%s, '')) LIKE ? ESCAPE '!'" % c
                                  for c in cols) + ')', [like] * len(cols))

    def _leaf(self, token, top):
        m = self._field(token)
        if not m:
            lead = token[:1] if token[:1] in '-!' and len(token) > 1 else ''
            word = token[len(lead):].strip('"')
            if not word:
                return None
            if top and not lead:
                self.top_words.append(token)
                return None
            w = self._word(word)
            return ('NOT (%s)' % w[0], w[1]) if lead else w
        lead, name, op, value = m.groups()
        column, kind = self.fields[name.lower()]
        self._name = name.lower()
        quoted = value.startswith('"')
        value = value.strip('"')
        if value == '':
            return None                      # still being typed
        neg = bool(lead) != (op == '!=')
        if kind == 'none':
            clause = ('1=0', [])
        else:
            items = [value] if quoted else [v for v in value.split(',') if v.strip()]
            clause = self._join('OR', [self._one(column, kind, op, v.strip()) for v in items])
        if neg:
            return ('NOT COALESCE((%s), 1=0)' % clause[0], clause[1])
        return clause

    def _one(self, col, kind, op, item):
        low = item.lower()
        cmp = (op in (':', '=')) and re.match(r'^(>=|<=|>|<)\s*(.+)$', low)
        if cmp:
            op, low = cmp.group(1), cmp.group(2)
        if kind == 'num':
            rng = re.match(r'^(-?[\d.]+)\s*-\s*(-?[\d.]+)$', low)
            try:
                if rng:
                    return ('(%s BETWEEN ? AND ?)' % col, [float(rng.group(1)),
                                                           float(rng.group(2))])
                n = float(low)
            except ValueError:
                raise ListQueryError('%s is a number - %r is not one' % (getattr(self, '_name', col), item))
            sign = {'>': '>', '<': '<', '>=': '>=', '<=': '<='}.get(op, '=')
            return ('(%s %s ?)' % (col, sign), [n])
        if op in ('>', '<', '>=', '<='):
            raise ListQueryError('only a number can be more or less than something')
        if kind == 'ok':
            v = {'accept': 1, 'accepted': 1, 'right': 1, 'yes': 1, 'ok': 1, 'reject': 0,
                 'rejected': 0, 'wrong': 0, 'no': 0, 'refused': 0}.get(low)
            if v is None:
                return ('1=0', [])
            return ('ok = ?', [v])
        if kind == 'realm':
            pat = '%@' + like_pattern(low.lstrip('@'))
            return ("LOWER(%s) LIKE ? ESCAPE '!'" % col, [pat if op != '~' else pat + '%'])
        if kind == 'step':
            marks = dict(Storage.ENROL_STEPS)
            if low not in marks:
                return ('1=0', [])
            return ("%s LIKE ? ESCAPE '!'" % col, ['%' + like_pattern(marks[low]) + '%'])
        if kind == 'fromip':
            return ("LOWER(%s) LIKE ? ESCAPE '!'" % col,
                    ['% from ' + like_pattern(low.rstrip('*')) + '%'])
        if kind == 'node':
            return ("LOWER(%s) LIKE ? ESCAPE '!'" % col, ['% on ' + like_pattern(low) + '%'])
        if kind == 'ip' and '/' in low and op != '~':
            try:
                net = ipaddress.ip_network(low, strict=False)
            except ValueError:
                raise ListQueryError('%r is not an address or a range of them' % item)
            if net.version == 4 and net.prefixlen % 8 == 0:
                keep = '.'.join(str(net.network_address).split('.')[:net.prefixlen // 8])
                return ("LOWER(%s) LIKE ? ESCAPE '!'" % col,
                        [like_pattern(keep) + ('.%' if keep else '%')])
            raise ListQueryError('a range is /8, /16 or /24 here')
        c = "LOWER(COALESCE(%s, ''))" % col
        if op == '~':
            return ("%s LIKE ? ESCAPE '!'" % c, ['%' + like_pattern(low) + '%'])
        if kind == 'ip' and '*' not in low:
            # An address as it was written down may carry its port.
            return ("(%s = ? OR %s LIKE ? ESCAPE '!')" % (c, c), [low, like_pattern(low) + ':%'])
        if '*' in low:
            return ("%s LIKE ? ESCAPE '!'" % c, [like_pattern(low)])
        return ('%s = ?' % c, [low])

class Storage(object):
    """Everything this daemon keeps, over whichever database it is."""

    def __init__(self, db):
        self.db = db
        self.db.make_tables()
        self.lock = threading.RLock()
        self._clients = None
        self._realms = None
        self._dirs = None

    # ---- meta, settings, events ------------------------------------------
    def get_meta(self, k, default=None):
        got = self.db.value('SELECT v FROM meta WHERE k = ?', (k,))
        return default if got is None else got

    def set_meta(self, k, v):
        with self.lock:
            if self.db.value('SELECT k FROM meta WHERE k = ?', (k,)) is None:
                self.db.run('INSERT INTO meta (k, v) VALUES (?, ?)', (k, str(v)))
            else:
                self.db.run('UPDATE meta SET v = ? WHERE k = ?', (str(v), k))

    def settings_saved(self):
        out = {}
        for r in self.db.rows('SELECT k, v FROM settings'):
            try:
                out[r['k']] = json.loads(r['v'])
            except (TypeError, ValueError):
                continue
        return out

    def settings_written(self):
        return {r['k']: {'at': r['at'], 'by': r['by_who']}
                for r in self.db.rows('SELECT k, at, by_who FROM settings')}

    def save_setting(self, k, v, by=''):
        with self.lock:
            self.db.run('DELETE FROM settings WHERE k = ?', (k,))
            self.db.run('INSERT INTO settings (k, v, at, by_who) VALUES (?, ?, ?, ?)',
                        (k, json.dumps(v), time.time(), str(by or '')[:190]))

    def drop_setting(self, k):
        self.db.run('DELETE FROM settings WHERE k = ?', (k,))

    def add_event(self, kind, words, level='info', who=''):
        if HA_REBUILDING.is_set():
            log('(not written while the node is rebuilt) %s: %s' % (kind, words))
            return None
        try:
            self.db.insert('events', {'ts': time.time(), 'kind': str(kind)[:60],
                                      'node': log_node(),
                                      'level': level, 'who': str(who or '')[:190],
                                      'words': str(words)[:4000]})
        except Exception as e:
            log('the event could not be written down: %s (%s)' % (words, e), 'warn')
        log('%s: %s%s' % (kind, words, (' (%s)' % who) if who else ''),
            'warn' if level in ('warn', 'bad') else 'info')
        hook = getattr(self, 'on_event', None)
        if hook:
            try:
                hook(kind, words, level, who)
            except Exception:
                pass

    def events(self, limit=100, offset=0, q='', kind='', extra=None):
        where, args = [], []
        if extra and extra[0]:
            where.append(extra[0])
            args += list(extra[1])
        if q:
            where.append("(LOWER(words) LIKE ? ESCAPE '!' OR LOWER(who) LIKE ? ESCAPE '!' OR LOWER(kind) LIKE ? ESCAPE '!')")
            like = '%' + like_pattern(str(q).lower()) + '%'
            args += [like, like, like]
        if kind:
            where.append('kind = ?')
            args.append(kind)
        sql = ' WHERE ' + ' AND '.join(where) if where else ''
        total = self.db.value('SELECT COUNT(*) AS n FROM events' + sql, args, 0)
        rows = self.db.rows('SELECT * FROM events' + sql + ' ORDER BY ts DESC, id DESC '
                            'LIMIT %d OFFSET %d' % (int(limit), int(offset)), args)
        return rows, int(total or 0)

    # ---- the enrolment pages: who came, what they did (1.0.16) ------------
    # The events of kind 'enrolment' tell the whole story of a person making
    # their own token; here they are read back as steps, so the pages can
    # draw them as a card of their own and count them.
    ENROL_STEPS = (('signed_in', ' signed in to the enrolment pages'),
                   ('enrolled', ' enrolled a token for themselves'),
                   ('confirmed', ' confirmed their token'),
                   ('replacing', ' is replacing their token'),
                   ('refused', ' could not sign in to the enrolment pages'),
                   ('not_allowed', ' may not enrol a token'),
                   ('stopped', ' stopped replacing their token'))

    @classmethod
    def enrol_step(cls, words):
        for step, mark in cls.ENROL_STEPS:
            if mark in words:
                return step
        return 'other'

    def enrolment(self, limit=100, offset=0, q='', step='', since_s=0, extra=None):
        where, args = ["kind = 'enrolment'"], []
        if extra and extra[0]:
            where.append(extra[0])
            args += list(extra[1])
        if since_s:
            where.append('ts > ?')
            args.append(time.time() - float(since_s))
        if q:
            where.append("(LOWER(words) LIKE ? ESCAPE '!' OR LOWER(who) LIKE ? ESCAPE '!')")
            like = '%' + like_pattern(str(q).lower()) + '%'
            args += [like, like]
        marks = dict(self.ENROL_STEPS)
        if step in marks:
            where.append('words LIKE ?')
            args.append('%' + marks[step] + '%')
        sql = ' WHERE ' + ' AND '.join(where)
        total = self.db.value('SELECT COUNT(*) AS n FROM events' + sql, args, 0)
        rows = self.db.rows('SELECT * FROM events' + sql + ' ORDER BY ts DESC, id DESC '
                            'LIMIT %d OFFSET %d' % (int(limit), int(offset)), args)
        out = []
        for r in rows:
            words = str(r.get('words') or '')
            m = re.search(r' from (\S+?)(?::|$)', words)
            out.append({'id': r['id'], 'ts': r['ts'], 'who': r.get('who') or '',
                        'step': self.enrol_step(words), 'src': m.group(1) if m else '',
                        'words': words, 'level': r.get('level') or 'info',
                        'node': r.get('node') or ''})
        return out, int(total or 0)

    def enrolment_counts(self, since_s=0, since=0, until=0):
        """How many of each step in the window - the tiles over the list."""
        counts = {}
        for step, mark in self.ENROL_STEPS:
            args = ['%' + mark + '%']
            sql = "SELECT COUNT(*) AS n FROM events WHERE kind = 'enrolment' AND words LIKE ?"
            if since_s:
                sql += ' AND ts > ?'
                args.append(time.time() - float(since_s))
            if since:
                sql += ' AND ts >= ?'
                args.append(float(since))
            if until:
                sql += ' AND ts < ?'
                args.append(float(until))
            counts[step] = int(self.db.value(sql, args, 0) or 0)
        return counts

    def list_values(self, listname, field, typed='', since=0, most=15):
        """What one field of one list holds, busiest first, for the search
        box over it to offer as somebody types (1.0.19, as isemon)."""
        spec = LIST_FIELDS.get(listname, {}).get(field)
        if not spec:
            return []
        column, kind = spec
        typed = str(typed or '').strip().lower()
        if kind == 'step':
            return [{'val': k, 'n': 0} for k, _ in self.ENROL_STEPS if typed in k]
        if kind == 'ok':
            return [{'val': v, 'n': 0} for v in ('accept', 'reject') if v.startswith(typed)]
        if kind == 'none' or not column:
            return []
        table = {'tokens': 'tokens', 'radius': 'radius_log', 'otp': 'otp_log',
                 'events': 'events', 'enrolment': 'events'}[listname]
        where, args = [], []
        if since and table != 'tokens':
            where.append('ts >= ?')
            args.append(since)
        if listname == 'enrolment':
            where.append("kind = 'enrolment'")
        # A number is compared as a number (1.0.33): PostgreSQL refuses
        # COALESCE(a number, '') - the suggestions for "recovery codes" broke.
        if kind == 'num':
            where.append('%s IS NOT NULL' % column)
        else:
            where.append("COALESCE(%s, '') <> ''" % column)
        sql = ' WHERE ' + ' AND '.join(where)
        rows = self.db.rows('SELECT %s AS val, COUNT(*) AS n FROM %s%s GROUP BY %s '
                            'ORDER BY n DESC LIMIT 2000' % (column, table, sql, column), args)
        got = collections.Counter()
        for r in rows:
            v = str(r['val'])
            if kind == 'realm':
                v = v.rsplit('@', 1)[1] if '@' in v else ''
            elif kind == 'ip':
                v = re.sub(r':\d+$', '', v) if v.count(':') == 1 else v
            elif kind == 'fromip':
                m = re.search(r' from (\S+?)(?::|$)', v)
                v = m.group(1) if m else ''
            elif kind == 'node':
                m = re.search(r' on (\S+)', v)
                v = m.group(1).rstrip(',') if m else ''
            elif kind == 'text' and column == 'words':
                continue
            if v:
                got[v] += int(r['n'] or 0)
        out = [{'val': v, 'n': n} for v, n in got.items()
               if not typed or typed.strip('*') in v.lower()]
        out.sort(key=lambda x: (not x['val'].lower().startswith(typed.strip('*')), -x['n'],
                                x['val'].lower()))
        return out[:most]

    def event_kinds(self):
        return [r['kind'] for r in self.db.rows('SELECT DISTINCT kind FROM events ORDER BY kind')]

    # ---- accounts of the administration pages ----------------------------
    def accounts(self):
        rows = self.db.rows('SELECT * FROM accounts ORDER BY name')
        for r in rows:
            r.pop('pw', None)
            # How somebody laid out their tables is theirs and can be big:
            # only whether there is any, for the Accounts list.
            r['cols_tables'] = len(self._cols_of(r.pop('cols', None)))
            r.pop('cols_at', None)
        return rows

    def account(self, name):
        return self.db.row('SELECT * FROM accounts WHERE LOWER(name) = ?',
                           (str(name or '').strip().lower(),))

    def add_account(self, name, role, password=None, source='local', note='', must_change=0,
                    display='', dn='', groups=''):
        name = str(name or '').strip()
        if not re.match(r'^[A-Za-z0-9][A-Za-z0-9._@\\-]{0,120}$', name):
            raise ValueError('a name has letters, digits, dots, dashes, @ and nothing else')
        if role not in ROLES_ALL:
            raise ValueError('the role is one of %s' % ', '.join(ROLES_ALL))
        if self.account(name):
            raise ValueError('there is an account called %s already' % name)
        if source == 'local':
            bad = password_problem(password)
            if bad:
                raise ValueError(bad)
        return self.db.insert('accounts', {
            'name': name, 'role': role, 'pw': password_hash(password) if password else '',
            'source': source, 'disabled': 0, 'must_change': int(bool(must_change)),
            'note': str(note or '')[:400], 'created': time.time(), 'last_in': None,
            'last_from': '', 'prefs': '{}', 'display': display, 'dn': dn,
            'group_list': groups})

    def set_account(self, name, **fields):
        one = self.account(name)
        if not one:
            raise ValueError('there is no account called %s' % name)
        if 'password' in fields:
            bad = password_problem(fields['password'])
            if bad:
                raise ValueError(bad)
            fields['pw'] = password_hash(fields.pop('password'))
        if 'role' in fields and fields['role'] not in ROLES_ALL:
            raise ValueError('the role is one of %s' % ', '.join(ROLES_ALL))
        self.db.update('accounts', one['id'], fields)

    def drop_account(self, name):
        one = self.account(name)
        if not one:
            raise ValueError('there is no account called %s' % name)
        self.db.run('DELETE FROM accounts WHERE id = ?', (one['id'],))
        self.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ?',
                    ('admin', one['name'].lower()))

    # ---- how somebody laid out the tables (as on isemon, 1.10.146 on) -------
    COLS_MOST_TABLES = 300
    COLS_MOST_COLUMNS = 60
    COLS_MOST_BYTES = 60000

    @staticmethod
    def _cols_of(text):
        if not text:
            return {}
        try:
            got = json.loads(text)
        except (TypeError, ValueError):
            return {}
        return got if isinstance(got, dict) else {}

    @classmethod
    def clean_cols(cls, cols):
        """A layout as the page sent it, reduced to what a layout can hold:
        `{table: {"w": {column: pixels}, "o": [order], "h": [hidden],
        "v": [optional shown], "s": [empty columns], "t": when}}` and nothing
        else. Anything not understood is dropped rather than kept."""
        if cols == [] or cols is None:
            cols = {}                       # PHP passes an empty object on as []
        if not isinstance(cols, dict):
            raise ValueError('a layout of the columns is an object of tables')
        out = {}

        def names(v, most):
            return [str(c)[:80] for c in v[:most] if isinstance(c, (str, int))] \
                if isinstance(v, list) else []

        for key, one in list(cols.items())[:cls.COLS_MOST_TABLES]:
            key = str(key)[:160]
            if not key or not isinstance(one, dict):
                continue
            kept = {}
            widths = one.get('w')
            if isinstance(widths, dict):
                w = {}
                for col, px in list(widths.items())[:cls.COLS_MOST_COLUMNS]:
                    try:
                        px = int(round(float(px)))
                    except (TypeError, ValueError, OverflowError):
                        continue
                    w[str(col)[:80]] = max(24, min(3000, px))
                if w:
                    kept['w'] = w
            for k in ('o', 'h', 'v'):
                got = names(one.get(k), cls.COLS_MOST_COLUMNS)
                if got:
                    kept[k] = got
            sp = [c for c in names(one.get('s'), 20) if re.match(r'^~\d{1,4}$', c)]
            if sp:
                kept['s'] = sp
            if kept:
                try:
                    kept['t'] = int(float(one.get('t') or 0))
                except (TypeError, ValueError, OverflowError):
                    kept['t'] = 0
                out[key] = kept
        if len(json.dumps(out, separators=(',', ':'))) > cls.COLS_MOST_BYTES:
            raise ValueError('that layout of the columns is too big to keep (more than %d '
                             'characters)' % cls.COLS_MOST_BYTES)
        return out

    def user_cols(self, name):
        """How this person has laid out the tables, or {} for as they come."""
        try:
            one = self.account(name)
        except Exception:                               # noqa: BLE001
            return {}
        return self._cols_of(one.get('cols')) if one else {}

    def put_user_cols(self, name, cols):
        """Keep this person's layout; an empty one puts every table back."""
        one = self.account(name)
        if not one:
            raise ValueError('there is no account called %s' % name)
        cols = self.clean_cols(cols or {})
        self.db.update('accounts', one['id'], {
            'cols': json.dumps(cols, separators=(',', ':')) if cols else None,
            'cols_at': time.time()})
        return cols

    @staticmethod
    def clean_prefs(prefs):
        if prefs == [] or prefs is None:
            prefs = {}
        if not isinstance(prefs, dict):
            raise ValueError('the choices are an object')
        out = {}
        if 'lang' in prefs:
            if str(prefs['lang']) not in ('cs', 'en'):
                raise ValueError('no such language here: %s' % prefs['lang'])
            out['lang'] = str(prefs['lang'])
        return out

    def user_prefs(self, name):
        one = self.account(name)
        return self._cols_of(one.get('prefs')) if one else {}

    def put_user_prefs(self, name, prefs):
        one = self.account(name)
        if not one:
            raise ValueError('there is no account called %s' % name)
        kept = dict(self._cols_of(one.get('prefs')))
        kept.update(self.clean_prefs(prefs))
        self.db.update('accounts', one['id'], {'prefs': json.dumps(kept)})
        return kept

    def fulladmins_left(self, but=''):
        return sum(1 for a in self.accounts() if a['role'] == 'fulladmin' and not a['disabled']
                   and a['name'].lower() != str(but).lower())

    # ---- sessions ----------------------------------------------------------
    def session_new(self, kind, name, role, ip, hours, data=None):
        token = secrets.token_urlsafe(32)
        t = time.time()
        self.db.insert('sessions', {
            'token_hash': hashlib.sha256(token.encode()).hexdigest(), 'kind': kind,
            'name': name, 'role': role, 'created': t, 'last': t,
            'expires': t + float(hours) * 3600, 'ip': str(ip or '')[:60],
            'data': json.dumps(data or {})})
        return token

    def session_get(self, token, kind, idle_s, touch=True):
        if not token:
            return None
        row = self.db.row('SELECT * FROM sessions WHERE token_hash = ? AND kind = ?',
                          (hashlib.sha256(str(token).encode()).hexdigest(), kind))
        if not row:
            return None
        t = time.time()
        if row['expires'] < t or t - float(row['last'] or 0) > idle_s:
            self.db.run('DELETE FROM sessions WHERE id = ?', (row['id'],))
            return None
        if touch and t - float(row['last'] or 0) > 20:
            self.db.run('UPDATE sessions SET last = ? WHERE id = ?', (t, row['id']))
        try:
            row['data'] = json.loads(row.get('data') or '{}')
        except ValueError:
            row['data'] = {}
        return row

    def session_set_data(self, ident, data):
        self.db.run('UPDATE sessions SET data = ? WHERE id = ?', (json.dumps(data), ident))

    def session_end(self, token):
        self.db.run('DELETE FROM sessions WHERE token_hash = ?',
                    (hashlib.sha256(str(token or '').encode()).hexdigest(),))

    def sessions(self, kind=None):
        sql, args = 'SELECT id, kind, name, role, created, last, expires, ip FROM sessions', []
        if kind:
            sql += ' WHERE kind = ?'
            args.append(kind)
        return self.db.rows(sql + ' ORDER BY last DESC', args)

    def session_drop(self, ident):
        self.db.run('DELETE FROM sessions WHERE id = ?', (int(ident),))

    def sessions_tidy(self, idle_admin_s=None, idle_portal_s=None):
        """Sign-ins that have run out go; so do the ones that sat untouched
        longer than they may (1.0.15: they stayed on the list of who is
        signed in, though a request from them would have been refused)."""
        t = time.time()
        self.db.run('DELETE FROM sessions WHERE expires < ?', (t,))
        for kind, idle in (('admin', idle_admin_s), ('portal', idle_portal_s)):
            if idle:
                self.db.run('DELETE FROM sessions WHERE kind = ? AND last < ?', (kind, t - float(idle)))

    # ---- RADIUS clients ----------------------------------------------------
    def _client_rows(self):
        """The clients as read, secrets opened - one list, never None, even
        when a save empties the cache between two lines (1.0.33)."""
        rows = self._clients
        if rows is None:
            rows = self.db.rows('SELECT * FROM clients ORDER BY position, name')
            for r in rows:
                r['_secret'] = unseal_secret(r.get('secret') or '')
                try:
                    r['_net'] = address_net(r['address'])
                except ValueError:
                    r['_net'] = None
            self._clients = rows
        return rows

    def clients(self, with_secret=False):
        out = []
        for r in self._client_rows():
            one = {k: v for k, v in r.items() if not k.startswith('_') and k != 'secret'}
            one['secret_set'] = bool(r['_secret'])
            one['secret_lost'] = r['_secret'] is None
            one['secret'] = r['_secret'] if with_secret else secret_shown(r['_secret'])
            out.append(one)
        return out

    def client_for(self, ip):
        """The client a packet from this address belongs to: the narrowest
        range holding it, and of two the same width the one named first."""
        rows = self._client_rows()
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return None
        best = None
        for r in rows:
            net = r['_net']
            if not net or not r.get('enabled') or addr.version != net.version or addr not in net:
                continue
            if best is None or net.prefixlen > best['_net'].prefixlen:
                best = r
        return best

    def client_save(self, data, by=''):
        """A client made or changed. Returns its id."""
        name = str(data.get('name') or '').strip()
        if not re.match(r'^[A-Za-z0-9][A-Za-z0-9._ -]{0,63}$', name):
            raise ValueError('a client needs a name: letters, digits, dots, dashes and spaces')
        try:
            net = address_net(data.get('address'))
        except ValueError:
            raise ValueError('%r is not an address or a range of them'
                             % str(data.get('address') or '')[:60])
        secret = data.get('secret')
        ident = data.get('id')
        old = self.db.row('SELECT * FROM clients WHERE id = ?', (int(ident),)) if ident else None
        clash = self.db.row('SELECT id FROM clients WHERE LOWER(name) = ?', (name.lower(),))
        if clash and (not old or clash['id'] != old['id']):
            raise ValueError('there is a client called %s already' % name)
        row = {'name': name, 'address': str(net) if net.num_addresses > 1 else
               str(net.network_address),
               'realm': str(data.get('realm') or '').strip().lstrip('@')[:190],
               'require_ma': int(bool(int(data.get('require_ma') or 0))),
               'enabled': int(bool(int(data.get('enabled', 1) if data.get('enabled')
                                       is not None else 1))),
               'note': str(data.get('note') or '')[:400],
               'nas_type': str(data.get('nas_type') or '')[:60],
               'position': int(data.get('position') or 0)}
        # The realms it may use (1.0.33): none named, any.
        if 'realms' in data or not old:
            raw = data.get('realms') or ''
            # Split on commas only (1.0.36): a realm's name may have spaces.
            want = [str(x).strip() for x in (raw if isinstance(raw, (list, tuple))
                                             else re.split(r'[,;\n]+', str(raw)))
                    if str(x).strip()]
            known = {r['name'].lower(): r['name'] for r in self.realms()}
            bad = [x for x in want if x.lower() not in known]
            if bad:
                raise ValueError('there is no realm called %s' % ', '.join(bad))
            row['realms'] = ', '.join(known[x.lower()] for x in want)
        if secret is not None and not is_masked(secret):
            secret = str(secret)
            if not secret.strip():
                raise ValueError('a client needs a shared secret')
            if len(secret) > 128:
                raise ValueError('a shared secret of more than 128 characters is more than '
                                 'RADIUS hides properly')
            row['secret'] = seal_secret(secret)
        elif not old:
            raise ValueError('a client needs a shared secret')
        with self.lock:
            if old:
                self.db.update('clients', old['id'], row)
                ident = old['id']
            else:
                row['created'] = time.time()
                ident = self.db.insert('clients', row)
            self._clients = None
        return ident

    def client_drop(self, ident):
        self.db.run('DELETE FROM clients WHERE id = ?', (int(ident),))
        self._clients = None

    _SEEN_AT = {}

    def client_seen(self, ident):
        """When a client was last heard from - written at most once a minute
        a client (1.0.33), not on every packet."""
        t = time.time()
        if t - self._SEEN_AT.get(ident, 0) < 60:
            return
        self._SEEN_AT[ident] = t
        self.db.run('UPDATE clients SET last_seen = ? WHERE id = ?', (t, ident))

    # ---- realms --------------------------------------------------------------
    def realms(self):
        if self._realms is None:
            rows = self.db.rows('SELECT * FROM realms ORDER BY position, name')
            for r in rows:
                try:
                    r['groups'] = json.loads(r.get('group_list') or '[]')
                except ValueError:
                    r['groups'] = []
                r.pop('group_list', None)
            self._realms = rows
        return [dict(r) for r in self._realms]

    def realm_for(self, user):
        """The realm a name belongs to: by what follows its @, else the realm
        for names with none, else the one that takes everything (`*`)."""
        suffix = user.rsplit('@', 1)[1].lower() if '@' in user else ''
        realms = [r for r in self.realms() if r.get('enabled')]
        for r in realms:
            if str(r.get('suffix') or '').lower() == suffix and r.get('suffix') != '*':
                return r
        for r in realms:
            if r.get('suffix') == '*':
                return r
        return None

    def realm_save(self, data, by=''):
        name = str(data.get('name') or '').strip()
        if not re.match(r'^[A-Za-z0-9][A-Za-z0-9._ -]{0,63}$', name):
            raise ValueError('a realm needs a name: letters, digits, dots, dashes and spaces')
        suffix = str(data.get('suffix') or '').strip().lstrip('@').lower()
        if suffix and suffix != '*' and not re.match(r'^[a-z0-9][a-z0-9.-]*$', suffix):
            raise ValueError('the realm is what comes after the @ - example.cz - or * for '
                             'every name, or nothing for names written without one')
        lookup = str(data.get('lookup') or 'upn')
        if lookup not in ('upn', 'sam', 'none'):
            raise ValueError('lookup is upn, sam or none')
        mode = str(data.get('auth_mode') or 'otp')
        if mode not in ('otp', 'password_otp', 'password'):
            raise ValueError('auth_mode is otp, password_otp or password')
        token_name = str(data.get('token_name') or 'whole')
        if token_name not in ('whole', 'bare'):
            raise ValueError('token_name is whole or bare')
        directory = str(data.get('directory') or '').strip()
        if directory and not self.directory(directory):
            raise ValueError('there is no directory called %s' % directory)
        if lookup != 'none' and not directory:
            lookup = 'none'
        if mode in ('password', 'password_otp') and lookup == 'none':
            raise ValueError('a password can only be checked against a directory: choose one, '
                             'and how names are looked up in it')
        groups = []
        for one in data.get('groups') or []:
            if isinstance(one, str):
                one = {'group': one, 'reply': ''}
            g = str(one.get('group') or '').strip()
            if not g:
                continue
            try:
                reply_lines(one.get('reply') or '')
            except RadiusError as e:
                raise ValueError('the answer for the group %s: %s' % (g, e))
            groups.append({'group': g, 'reply': str(one.get('reply') or '').strip()})
        try:
            reply_lines(data.get('reply') or '')
        except RadiusError as e:
            raise ValueError('the answer for everybody in the realm: %s' % e)
        ident = data.get('id')
        old = self.db.row('SELECT * FROM realms WHERE id = ?', (int(ident),)) if ident else None
        for other in self.realms():
            if old and other['id'] == old['id']:
                continue
            if other['name'].lower() == name.lower():
                raise ValueError('there is a realm called %s already' % name)
            if str(other.get('suffix') or '').lower() == suffix:
                raise ValueError('the realm %s takes %s already' % (
                    other['name'], ('@' + suffix) if suffix not in ('', '*') else
                    ('every name' if suffix == '*' else 'names written without a realm')))
        row = {'name': name, 'suffix': suffix, 'directory': directory, 'lookup': lookup,
               'auth_mode': mode, 'group_list': json.dumps(groups),
               'check_disabled': int(bool(int(data.get('check_disabled', 1)))),
               'nested': int(bool(int(data.get('nested', 1)))),
               'reply': str(data.get('reply') or '').strip(),
               'enabled': int(bool(int(data.get('enabled', 1)))),
               'position': int(data.get('position') or 0),
               'note': str(data.get('note') or '')[:400], 'token_name': token_name}
        with self.lock:
            if old:
                self.db.update('realms', old['id'], row)
                ident = old['id']
                if old.get('name') and row.get('name') and old['name'] != row['name']:
                    # The clients that may use it, told its new name (1.0.36).
                    self._client_realms_rename(old['name'], row['name'])
            else:
                row['created'] = time.time()
                ident = self.db.insert('realms', row)
            self._realms = None
        return ident

    def realm_drop(self, ident):
        one = self.db.row('SELECT name FROM realms WHERE id = ?', (int(ident),))
        self.db.run('DELETE FROM realms WHERE id = ?', (int(ident),))
        self._realms = None
        if one:
            # ...and out of the clients' lists: a name left there made every
            # later save of the client fail (1.0.36).
            self._client_realms_rename(one['name'], None)

    def _client_realms_rename(self, was, now):
        for c in self.db.rows("SELECT id, realms FROM clients WHERE COALESCE(realms, '') <> ''"):
            names = [x.strip() for x in re.split(r'[,;\n]+', c['realms'] or '') if x.strip()]
            if not any(x.lower() == str(was).lower() for x in names):
                continue
            names = [(now if x.lower() == str(was).lower() else x) for x in names]
            names = [x for x in names if x]
            self.db.update('clients', c['id'], {'realms': ', '.join(names)})
        self._clients = None

    # ---- directories -------------------------------------------------------
    def directories(self, with_secret=False):
        if self._dirs is None:
            rows = self.db.rows('SELECT * FROM directories ORDER BY name')
            for r in rows:
                r['_pw'] = unseal_secret(r.get('bind_pw') or '')
            self._dirs = rows
        out = []
        for r in self._dirs:
            one = {k: v for k, v in r.items() if not k.startswith('_') and k != 'bind_pw'}
            one['bind_pw_set'] = bool(r['_pw'])
            one['bind_pw_lost'] = r['_pw'] is None
            one['bind_pw'] = r['_pw'] if with_secret else secret_shown(r['_pw'])
            one['ca_says'] = describe_certificate(r.get('ca') or '') if r.get('ca') else None
            one['ca_list'] = describe_certificates(r.get('ca') or '') if r.get('ca') else []
            out.append(one)
        return out

    def directory(self, name, with_secret=False):
        for one in self.directories(with_secret):
            if one['name'].lower() == str(name or '').strip().lower():
                return one
        return None

    def directory_set_ca(self, ident, pem, mode='set', fingerprint=''):
        """The certificate authorities of one directory, and nothing else of
        it: several chains may be kept - one per domain the directory's
        controllers come from - each added and taken out by itself."""
        pem = str(pem or '').strip()
        row = self.db.row('SELECT ca FROM directories WHERE id = ?', (int(ident),))
        have = split_certificates((row or {}).get('ca') or '')
        if mode in ('add', 'set') and pem:
            new = split_certificates(pem)
            if not new or not all(describe_certificate(b) for b in new):
                raise ValueError('that is not a certificate this can read: a PEM certificate '
                                 'starts -----BEGIN CERTIFICATE-----')
            if mode == 'add':
                seen = {c['fingerprint'] for c in describe_certificates('\n'.join(have))}
                have += [b for b, c in zip(new, describe_certificates('\n'.join(new)))
                         if c['fingerprint'] not in seen]
            else:
                have = new
        elif mode == 'drop':
            keep = [b for b, c in zip(have, describe_certificates('\n'.join(have)))
                    if c['fingerprint'] != fingerprint]
            if len(keep) == len(have):
                raise ValueError('that certificate is not among the ones kept')
            have = keep
        else:
            have = []
        pem = '\n'.join(have)
        with self.lock:
            self.db.run('UPDATE directories SET ca = ? WHERE id = ?', (pem, int(ident)))
            self._dirs = None

    def directory_save(self, data, by=''):
        name = str(data.get('name') or '').strip()
        if not re.match(r'^[A-Za-z0-9][A-Za-z0-9._ -]{0,63}$', name):
            raise ValueError('a directory needs a name: letters, digits, dots, dashes and spaces')
        hosts = [h.strip() for h in re.split(r'[,;\s]+', str(data.get('hosts') or ''))
                 if h.strip()]
        clean = []
        for h in hosts:
            h = re.sub(r'^ldaps?://', '', h, flags=re.I).rstrip('/')
            if not re.match(r'^[A-Za-z0-9.\-:\[\]]+$', h):
                raise ValueError('%r is not a server name or address' % h)
            clean.append(h)
        if not clean:
            raise ValueError('a directory needs at least one server')
        tls = str(data.get('tls') or 'ldaps')
        if tls not in ('none', 'ldaps', 'starttls'):
            raise ValueError('tls is none, ldaps or starttls')
        port = int(data.get('port') or (636 if tls == 'ldaps' else 389))
        base = str(data.get('base') or '').strip()
        if not re.match(r'(?i)^(dc|ou|o|cn)=', base):
            raise ValueError('the base is a distinguished name: DC=example,DC=local')
        ca = str(data.get('ca') or '').strip()
        if ca and '-----BEGIN CERTIFICATE-----' not in ca:
            raise ValueError('the certificate authority is a PEM certificate, starting '
                             '-----BEGIN CERTIFICATE-----')
        ident = data.get('id')
        old = self.db.row('SELECT * FROM directories WHERE id = ?',
                          (int(ident),)) if ident else None
        clash = self.db.row('SELECT id FROM directories WHERE LOWER(name) = ?', (name.lower(),))
        if clash and (not old or clash['id'] != old['id']):
            raise ValueError('there is a directory called %s already' % name)
        row = {'name': name, 'hosts': ', '.join(clean), 'port': port, 'tls': tls,
               'verify': int(bool(int(data.get('verify', 1)))), 'base': base,
               'bind_dn': str(data.get('bind_dn') or '').strip(),
               'user_attr': str(data.get('user_attr') or 'sAMAccountName').strip(),
               'nested': int(bool(int(data.get('nested', 1)))),
               'timeout_s': max(2, min(60, int(data.get('timeout_s') or 10))),
               'enabled': int(bool(int(data.get('enabled', 1)))),
               'note': str(data.get('note') or '')[:400]}
        if 'ca' in data:
            row['ca'] = ca
        pw = data.get('bind_pw')
        if pw is not None and not is_masked(pw):
            row['bind_pw'] = seal_secret(pw) if str(pw) else ''
        with self.lock:
            if old:
                if old['name'] != name:
                    self.db.run('UPDATE realms SET directory = ? WHERE directory = ?',
                                (name, old['name']))
                    self._realms = None
                self.db.update('directories', old['id'], row)
                ident = old['id']
            else:
                row['created'] = time.time()
                ident = self.db.insert('directories', row)
            self._dirs = None
        return ident

    def directory_drop(self, ident):
        one = self.db.row('SELECT name FROM directories WHERE id = ?', (int(ident),))
        if one:
            used = [r['name'] for r in self.realms()
                    if str(r.get('directory') or '').lower() == one['name'].lower()]
            if used:
                raise ValueError('the realm(s) %s look people up in it; change them first'
                                 % ', '.join(used))
        self.db.run('DELETE FROM directories WHERE id = ?', (int(ident),))
        self._dirs = None

    # ---- tokens --------------------------------------------------------------
    TOKEN_SORTS = {'name': 'name', 'created': 'created', 'last_used': 'last_used',
                   'state': 'state', 'failures': 'failures', 'scratch_left': 'scratch_left'}

    def token(self, name):
        return self.db.row('SELECT * FROM tokens WHERE name = ?', (norm_name(name),))

    def tokens(self, q='', state='', limit=100, offset=0, sort='name', desc=False, extra=None):
        where, args = [], []
        if extra and extra[0]:
            where.append(extra[0])
            args += list(extra[1])
        if q:
            where.append("(LOWER(name) LIKE ? ESCAPE '!' OR LOWER(note) LIKE ? ESCAPE '!' OR LOWER(display) LIKE ? ESCAPE '!')")
            like = '%' + like_pattern(str(q).lower()) + '%'
            args += [like, like, like]
        if state:
            where.append('state = ?')
            args.append(state)
        sql = ' WHERE ' + ' AND '.join(where) if where else ''
        total = self.db.value('SELECT COUNT(*) AS n FROM tokens' + sql, args, 0)
        col = self.TOKEN_SORTS.get(sort, 'name')
        rows = self.db.rows('SELECT * FROM tokens%s ORDER BY %s %s, name LIMIT %d OFFSET %d'
                            % (sql, col, 'DESC' if desc else 'ASC', int(limit), int(offset)),
                            args)
        return [self.token_shown(r) for r in rows], int(total or 0)

    @staticmethod
    def token_shown(r):
        """A token as the pages may see it: never its key, never its codes."""
        if not r:
            return None
        out = {k: r.get(k) for k in ('id', 'name', 'digits', 'period', 'algorithm',
                                     'window_steps', 'state', 'scratch_left', 'created',
                                     'created_by', 'activated', 'last_used', 'last_from',
                                     'last_how', 'failures', 'note', 'issuer', 'label',
                                     'pending_at', 'pending_by', 'display')}
        out['key_lost'] = unseal_secret(r.get('secret') or '', token_bind(r.get('name'))) is None
        out['pending'] = bool(r.get('pending_secret'))
        out['scratch_kept'] = bool(r.get('scratch_sealed'))
        return out

    def token_counts(self):
        out = {'all': 0, 'active': 0, 'pending': 0, 'disabled': 0}
        for r in self.db.rows('SELECT state, COUNT(*) AS n FROM tokens GROUP BY state'):
            out[r['state'] or 'active'] = int(r['n'])
            out['all'] += int(r['n'])
        out['used_30d'] = int(self.db.value('SELECT COUNT(*) AS n FROM tokens WHERE '
                                            'last_used > ?', (time.time() - 30 * 86400,), 0))
        out['never_used'] = int(self.db.value('SELECT COUNT(*) AS n FROM tokens WHERE '
                                              'last_used IS NULL', (), 0))
        return out

    def token_write(self, name, fields):
        """A token made, or the fields given changed on the one there is."""
        name = norm_name(name)
        with self.lock:
            old = self.token(name)
            if old:
                self.db.update('tokens', old['id'], fields)
                return old['id']
            row = {'name': name, 'state': 'active', 'last_step': 0, 'failures': 0,
                   'fail_times': '[]', 'scratch': '[]', 'scratch_left': 0,
                   'created': time.time(), 'window_steps': -1}
            row.update(fields)
            return self.db.insert('tokens', row)

    def token_update(self, ident, fields):
        """Fields changed on the token that was read, by its id, and never a
        token made: a check whose token was deleted meanwhile wrote a new,
        empty one back under the name (1.0.36)."""
        return self.db.update('tokens', ident, fields)

    def token_drop(self, name):
        return self.db.run('DELETE FROM tokens WHERE name = ?', (norm_name(name),))

    # ---- the logs ------------------------------------------------------------
    def radius_add(self, row):
        if HA_REBUILDING.is_set():
            return None
        row.setdefault('node', log_node())
        return self.db.insert('radius_log', row)

    def radius_rows(self, hours=24, q='', result='', client='', limit=100, offset=0,
                    since=None, sort='ts', desc=True, user='', where_only=False, extra=None):
        where, args = ['ts >= ?'], [since if since is not None else
                                    time.time() - float(hours) * 3600]
        if extra and extra[0]:
            where.append(extra[0])
            args += list(extra[1])
        if q:
            like = '%' + like_pattern(str(q).lower()) + '%'
            where.append("(LOWER(username) LIKE ? ESCAPE '!' OR LOWER(calling) LIKE ? ESCAPE '!' OR LOWER(reason) "
                         "LIKE ? ESCAPE '!' OR LOWER(client) LIKE ? ESCAPE '!' OR LOWER(device) LIKE ? ESCAPE '!' OR "
                         "LOWER(otp) LIKE ? ESCAPE '!')")
            args += [like] * 6
        if result:
            if result == 'access':
                where.append("packet = 'Access-Request'")
            else:
                where.append('result = ?')
                args.append(result)
        if client:
            where.append('client = ?')
            args.append(client)
        if user:
            where.append('username = ?')
            args.append(user)
        sql = ' WHERE ' + ' AND '.join(where)
        if where_only:
            return sql, args
        total = self.db.value('SELECT COUNT(*) AS n FROM radius_log' + sql, args, 0)
        col = {'ts': 'ts', 'username': 'username', 'result': 'result', 'client': 'client',
               'calling': 'calling', 'took_ms': 'took_ms', 'reason': 'reason',
               'node': 'node'}.get(sort, 'ts')
        rows = self.db.rows('SELECT id, ts, client, nas_ip, src, packet, username, realm, '
                            'calling, called, result, reason, otp, rid, took_ms, device, tunnel, '
                            'node '
                            'FROM radius_log%s ORDER BY %s %s, id DESC LIMIT %d OFFSET %d'
                            % (sql, col, 'DESC' if desc else 'ASC', int(limit), int(offset)),
                            args)
        return rows, int(total or 0)

    def radius_row(self, ident):
        r = self.db.row('SELECT * FROM radius_log WHERE id = ?', (int(ident),))
        if r:
            for k in ('attrs', 'reply', 'steps'):
                try:
                    r[k] = json.loads(r.get(k) or '[]')
                except ValueError:
                    r[k] = []
        return r

    def otp_add(self, row):
        row.setdefault('node', log_node())
        return self.db.insert('otp_log', row)

    def log_forget(self, table, ids=None, where_sql='', args=()):
        """Lines of a log taken away - by id, or every line a filter matches."""
        if table not in ('radius_log', 'otp_log', 'events'):
            raise ValueError('not a log')
        if ids is not None:
            ids = [int(i) for i in ids][:5000]
            if not ids:
                return 0
            return self.db.run('DELETE FROM %s WHERE id IN (%s)'
                               % (table, ', '.join('?' for _ in ids)), ids)
        return self.db.run('DELETE FROM %s%s' % (table, where_sql), list(args))

    def otp_where(self, hours=24, q='', ok=None, name='', not_how='', extra=None):
        where, args = ['ts >= ?'], [time.time() - float(hours) * 3600]
        if extra and extra[0]:
            where.append(extra[0])
            args += list(extra[1])
        if not_how:
            where.append('(how IS NULL OR how <> ?)')
            args.append(not_how)
        if q:
            like = '%' + like_pattern(str(q).lower()) + '%'
            where.append("(LOWER(name) LIKE ? ESCAPE '!' OR LOWER(said) LIKE ? ESCAPE '!' OR LOWER(src) LIKE ? ESCAPE '!')")
            args += [like] * 3
        if ok is not None:
            where.append('ok = ?')
            args.append(1 if ok else 0)
        if name:
            where.append('name = ?')
            args.append(name)
        return ' WHERE ' + ' AND '.join(where), args

    def otp_rows(self, hours=24, q='', ok=None, limit=100, offset=0, name='', not_how='',
                 extra=None):
        if not_how or extra:
            sql, args = self.otp_where(hours, q, ok, name, not_how, extra)
            total = self.db.value('SELECT COUNT(*) AS n FROM otp_log' + sql, args, 0)
            rows = self.db.rows('SELECT * FROM otp_log%s ORDER BY ts DESC, id DESC LIMIT %d '
                                'OFFSET %d' % (sql, int(limit), int(offset)), args)
            return rows, int(total or 0)
        where, args = ['ts >= ?'], [time.time() - float(hours) * 3600]
        if q:
            like = '%' + like_pattern(str(q).lower()) + '%'
            where.append("(LOWER(name) LIKE ? ESCAPE '!' OR LOWER(said) LIKE ? ESCAPE '!' OR LOWER(src) LIKE ? ESCAPE '!')")
            args += [like] * 3
        if ok is not None:
            where.append('ok = ?')
            args.append(1 if ok else 0)
        if name:
            where.append('name = ?')
            args.append(name)
        sql = ' WHERE ' + ' AND '.join(where)
        total = self.db.value('SELECT COUNT(*) AS n FROM otp_log' + sql, args, 0)
        rows = self.db.rows('SELECT * FROM otp_log%s ORDER BY ts DESC, id DESC LIMIT %d OFFSET %d'
                            % (sql, int(limit), int(offset)), args)
        return rows, int(total or 0)

    def overview(self, hours=24, since=None, until=None):
        """What the front page counts: per hour, what was let in and what was
        refused, and the names, reasons and clients behind the refusals.
        `since`/`until` (1.0.53): a window of its own, from the time picker."""
        now = time.time()
        until = float(until) if until else now
        since = float(since) if since else until - float(hours) * 3600
        hours = max(1.0, (until - since) / 3600)
        step = 3600 if hours <= 72 else (6 * 3600 if hours <= 24 * 31 else 86400)
        start = int(since // step) * step
        # Counted by the database, hour by hour (1.0.33): every request of
        # the window was read into Python - over a second for a month.
        slot = ('CAST((ts - ?) / ? AS INTEGER)' if self.db.engine == 'sqlite'
                else 'FLOOR((ts - ?) / ?)')
        rows = self.db.rows("SELECT %s AS b, result, COUNT(*) AS n FROM radius_log "
                            "WHERE ts >= ? AND ts < ? AND packet = 'Access-Request' "
                            "AND result IN ('accept', 'reject', 'drop') GROUP BY 1, 2"
                            % slot, (start, step, since, until))
        buckets = collections.OrderedDict()
        t = start
        while t <= min(until, now):
            buckets[t] = {'t': t, 'accept': 0, 'reject': 0}
            t += step
        acc = rej = 0
        for r in rows:
            b = start + int(r['b'] or 0) * step
            if b not in buckets:
                buckets[b] = {'t': b, 'accept': 0, 'reject': 0}
            n = int(r['n'] or 0)
            if r['result'] == 'accept':
                buckets[b]['accept'] += n
                acc += n
            else:
                buckets[b]['reject'] += n
                rej += n

        def top(col, where, n=10):
            return self.db.rows(
                "SELECT %s AS said, COUNT(*) AS n, MAX(ts) AS last FROM radius_log WHERE ts >= ? "
                "AND ts < ? AND packet = 'Access-Request' AND %s GROUP BY %s ORDER BY n DESC "
                "LIMIT %d" % (col, where, col, n), (since, until))
        return {
            'hours': hours, 'step': step, 'since': since, 'until': until, 'series': list(buckets.values()),
            'accepted': acc, 'refused': rej,
            'people': int(self.db.value(
                "SELECT COUNT(DISTINCT username) AS n FROM radius_log WHERE ts >= ? AND "
                "ts < ? AND result = 'accept'", (since, until), 0) or 0),
            'top_refused_names': top('username', "result = 'reject'"),
            'top_reasons': top('reason', "result = 'reject'"),
            'top_clients': top('client', '1 = 1'),
            'top_places': top('calling', "calling <> ''"),
            'otp_bad': int(self.db.value('SELECT COUNT(*) AS n FROM otp_log WHERE ts >= ? AND '
                                         'ts < ? AND ok = 0', (since, until), 0) or 0),
            'otp_good': int(self.db.value('SELECT COUNT(*) AS n FROM otp_log WHERE ts >= ? AND '
                                          'ts < ? AND ok = 1', (since, until), 0) or 0),
        }

    def tidy(self):
        """What has been kept long enough, deleted."""
        said = {}
        for table, key in (('radius_log', 'retain_radius_days'), ('otp_log', 'retain_otp_days'),
                           ('events', 'retain_events_days')):
            days = int(CONFIG.get(key) or 0)
            if days > 0:
                # In batches (1.0.33): one DELETE of a million rows held the
                # database - and every RADIUS request waiting on it - for as
                # long as it took.
                cut, gone = time.time() - days * 86400, 0
                for _ in range(10000):
                    if self.db.engine == 'mariadb':
                        n = self.db.run('DELETE FROM %s WHERE ts < ? LIMIT 5000' % table, (cut,))
                    else:
                        n = self.db.run('DELETE FROM %s WHERE id IN (SELECT id FROM %s WHERE '
                                        'ts < ? LIMIT 5000)' % (table, table), (cut,))
                    gone += int(n or 0)
                    if not n or n < 5000:
                        break
                said[table] = gone
        self.sessions_tidy(int(CONFIG.get('session_idle_min') or 120) * 60,
                           int(CONFIG.get('portal_session_min') or 15) * 60)
        return said

    def counts(self):
        return {t: int(self.db.value('SELECT COUNT(*) AS n FROM %s' % t, (), 0) or 0)
                for t in TABLES if t not in ('meta',)}


# ---------------------------------------------------------------------------
# A directory, as the realms and the sign-ins use it
# ---------------------------------------------------------------------------
# Several servers, asked in the order given: one that cannot be reached is
# passed over for the next, one that answers is believed. Two questions are
# asked of it all day - who is this, and which groups are they in - and
# their answers are kept for a minute, because a VPN asks twice in a row for
# the same person more often than not.

AD_UAC_DISABLED = 0x2
AD_NEVER = (0, 0x7FFFFFFFFFFFFFFF)
USER_ATTRS = ('distinguishedName', 'sAMAccountName', 'userPrincipalName', 'displayName',
              'mail', 'userAccountControl', 'accountExpires', 'memberOf', 'lockoutTime',
              'pwdLastSet', 'department', 'title')


def ad_time(value):
    """A Windows time (hundreds of nanoseconds since 1601) as seconds since
    1970, or None for never."""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None
    if n in AD_NEVER or n <= 0:
        return None
    return n / 10000000.0 - 11644473600


class Directory(object):
    """One directory from the table, made usable."""

    CACHE_S = 60

    def __init__(self, row):
        self.row = row
        self.name = row['name']
        self.hosts = [h.strip() for h in str(row.get('hosts') or '').split(',') if h.strip()]
        self.port = int(row.get('port') or 636)
        self.tls = row.get('tls') or 'ldaps'
        self.verify = bool(row.get('verify', 1))
        self.ca = row.get('ca') or ''
        self.base = row.get('base') or ''
        self.bind_dn = row.get('bind_dn') or ''
        self.bind_pw = row.get('bind_pw') or ''
        self.timeout = float(row.get('timeout_s') or 10)
        self.cache = {}
        self.lock = threading.Lock()
        self.last_good = None

    def _hostport(self, host):
        host = str(host).strip()
        # [fd00::1]:636 and [fd00::1] as well (1.0.44); a bare IPv6 address
        # has no port of its own.
        m = re.match(r'^\[([^\]]+)\](?::(\d+))?$', host)
        if m:
            return m.group(1), int(m.group(2) or self.port)
        m = re.match(r'^([^:]+)(?::(\d+))?$', host)
        if m:
            return m.group(1), int(m.group(2) or self.port)
        return host, self.port

    def link(self, bind=True):
        """A conversation with the first server that answers, signed in as the
        reading account. LdapUnreachable where none of them can be."""
        tried = []
        order = list(self.hosts)
        if self.last_good in order:
            order.remove(self.last_good)
            order.insert(0, self.last_good)
        for host in order:
            h, p = self._hostport(host)
            one = Ldap(h, p, self.tls, self.ca, self.verify, self.timeout)
            try:
                one.open()
                if bind and self.bind_dn:
                    try:
                        one.bind(self.bind_dn, self.bind_pw)
                    except LdapError as e:
                        one.close()
                        # The reading account refused is the same on every
                        # server: no point going round them all.
                        raise LdapUnreachable('the account this reads the directory with '
                                              '(%s) was refused by %s: %s'
                                              % (self.bind_dn, h, e), e.code, e.detail)
                self.last_good = host
                return one
            except LdapUnreachable:
                raise
            except (LdapError, OSError, ValueError) as e:
                one.close()
                tried.append('%s: %s' % (h, e))
        raise LdapUnreachable('no server of %s could be reached (%s)'
                              % (self.name, '; '.join(tried) or 'none is set'))

    def find_user(self, name, how='upn'):
        """The entry of one account, or None. `how` is upn (the whole
        name@realm against userPrincipalName), sam (the part before the @
        against sAMAccountName) or mail."""
        key = ('u', how, str(name).lower())
        with self.lock:
            got = self.cache.get(key)
            if got and time.time() - got[0] < self.CACHE_S:
                return got[1]
        said = str(name or '').strip()
        if how == 'sam':
            said = said.split('@', 1)[0].split('\\')[-1]
            want = ldap_equal(self.row.get('user_attr') or 'sAMAccountName', said)
        elif how == 'mail':
            want = ldap_equal('mail', said)
        else:
            want = ldap_equal('userPrincipalName', said)
        flt = ldap_and(ldap_equal('objectClass', 'user'), want)
        link = self.link()
        try:
            rows = link.search(self.base, flt, USER_ATTRS, scope=2, limit=2)
        finally:
            link.close()
        entry = None
        if rows:
            r = rows[0]
            a = {k.lower(): v for k, v in r['attrs'].items()}
            first = lambda k: (a.get(k.lower()) or [''])[0]
            uac = 0
            try:
                uac = int(first('userAccountControl') or 0)
            except ValueError:
                pass
            entry = {'dn': r['dn'], 'sam': first('sAMAccountName'),
                     'upn': first('userPrincipalName'), 'display': first('displayName'),
                     'mail': first('mail'), 'uac': uac,
                     'disabled': bool(uac & AD_UAC_DISABLED),
                     'expires': ad_time(first('accountExpires')),
                     'locked': bool(ad_time(first('lockoutTime'))),
                     'member_of': a.get('memberof') or [],
                     'department': first('department'), 'title': first('title'),
                     'many': len(rows) > 1}
        with self.lock:
            self.cache[key] = (time.time(), entry)
            if len(self.cache) > 5000:
                self.cache.clear()
        return entry

    def groups_of(self, entry, nested=True):
        """[(dn, cn)] of every group the account is in - with the groups
        inside groups where `nested`, which on Active Directory is one search
        with the in-chain matching rule rather than a walk of the tree."""
        if not entry:
            return []
        if not nested:
            return [(g, cn_of(g)) for g in entry.get('member_of') or []]
        key = ('g', entry['dn'].lower())
        with self.lock:
            got = self.cache.get(key)
            if got and time.time() - got[0] < self.CACHE_S:
                return got[1]
        link = self.link()
        try:
            rows = link.search(self.base, ldap_and(ldap_equal('objectClass', 'group'),
                                                   ldap_in_chain('member', entry['dn'])),
                               ('cn',), scope=2, limit=5000, paged=True)
        finally:
            link.close()
        out = [(r['dn'], (r['attrs'].get('cn') or [cn_of(r['dn'])])[0]) for r in rows]
        with self.lock:
            self.cache[key] = (time.time(), out)
        return out

    def password_ok(self, entry, password):
        """True, or LdapError with the directory's reason in words."""
        if not str(password or ''):
            raise LdapError('a password is needed')
        tried = []
        for host in ([self.last_good] if self.last_good else []) + self.hosts:
            if not host:
                continue
            h, p = self._hostport(host)
            one = Ldap(h, p, self.tls, self.ca, self.verify, self.timeout)
            try:
                one.open()
            except (LdapError, OSError) as e:
                tried.append(str(e))
                continue
            try:
                one.bind(entry['dn'], password)
                return True
            except LdapUnreachable as e:
                # The line dropped mid-bind: the next server is asked, the
                # password is not called wrong (1.0.44).
                tried.append(str(e))
                continue
            finally:
                one.close()
        raise LdapUnreachable('no server of %s could be reached (%s)'
                              % (self.name, '; '.join(tried)))

    def find_users(self, like, limit=25):
        """People whose name, account, principal name or mail holds what is
        typed - for the boxes that offer a person as one types (1.0.19)."""
        like = str(like or '').strip()
        if len(like) < 2:
            return []
        attr = self.row.get('user_attr') or 'sAMAccountName'
        want = ldap_and(ldap_equal('objectClass', 'user'),
                        ldap_or(ldap_contains(attr, like), ldap_contains('userPrincipalName', like),
                                ldap_contains('displayName', like), ldap_contains('mail', like)))
        link = self.link()
        try:
            rows = link.search(self.base, want, ('sAMAccountName', 'userPrincipalName',
                                                 'displayName', 'mail', 'userAccountControl',
                                                 attr), scope=2, limit=limit + 10)
        finally:
            link.close()
        out = []
        for r in rows:
            a = {k.lower(): v for k, v in r['attrs'].items()}
            first = lambda k: (a.get(k.lower()) or [''])[0]
            if str(first('sAMAccountName')).endswith('$'):
                continue                         # a computer, not a person
            try:
                uac = int(first('userAccountControl') or 0)
            except ValueError:
                uac = 0
            out.append({'dn': r['dn'], 'sam': first(attr) or first('sAMAccountName'),
                        'upn': first('userPrincipalName'), 'display': first('displayName'),
                        'mail': first('mail'), 'disabled': bool(uac & AD_UAC_DISABLED)})
        low = like.lower()
        out.sort(key=lambda u: (not (u['sam'] or '').lower().startswith(low),
                                not (u['display'] or '').lower().startswith(low),
                                (u['display'] or u['sam'] or '').lower()))
        return out[:limit]

    def find_groups(self, like='', limit=300):
        """Group names for a picker."""
        want = ldap_equal('objectClass', 'group')
        if like.strip():
            want = ldap_and(want, ldap_contains('cn', like.strip()))
        link = self.link()
        try:
            rows = link.search(self.base, want, ('cn', 'description'), scope=2,
                               limit=limit, paged=True)
        finally:
            link.close()
        out = [{'dn': r['dn'], 'cn': (r['attrs'].get('cn') or [cn_of(r['dn'])])[0],
                'description': (r['attrs'].get('description') or [''])[0]} for r in rows]
        return sorted(out, key=lambda g: g['cn'].lower())

    def check(self):
        """Every server, step by step, the way isemon's directory check reads."""
        out = []
        began = time.time()
        for host in self.hosts:
            h, p = self._hostport(host)
            steps = []
            one = Ldap(h, p, self.tls, self.ca, self.verify, self.timeout)
            t = time.time()
            try:
                one.open()
                steps.append({'what': 'reached %s:%d%s' % (h, p, {
                    'ldaps': ' over TLS', 'starttls': ' and started TLS'}.get(self.tls, '')),
                    'ok': True, 'said': '%d ms' % int((time.time() - t) * 1000)})
            except (LdapError, OSError) as e:
                steps.append({'what': 'reach the server %s:%d' % (h, p), 'ok': False, 'said': str(e)})
                out.append({'host': h, 'port': p, 'steps': steps, 'ok': False})
                continue
            try:
                if self.bind_dn:
                    one.bind(self.bind_dn, self.bind_pw)
                    steps.append({'what': 'signed in as %s' % self.bind_dn, 'ok': True,
                                  'said': ''})
                rows = one.search(self.base, ldap_present('objectClass'), ('objectClass',),
                                  scope=0, limit=1)
                steps.append({'what': 'read the base %s' % self.base, 'ok': bool(rows),
                              'said': '' if rows else 'nothing is there - is the base right?'})
                n = len(one.search(self.base, ldap_equal('objectClass', 'group'), ('cn',),
                                   scope=2, limit=5000, paged=True))
                steps.append({'what': 'counted the groups', 'ok': True,
                              'said': '%d group(s) under the base' % n})
                out.append({'host': h, 'port': p, 'steps': steps, 'ok': bool(rows)})
            except LdapError as e:
                steps.append({'what': 'the next step', 'ok': False, 'said': str(e),
                              'detail': e.detail})
                out.append({'host': h, 'port': p, 'steps': steps, 'ok': False})
            finally:
                one.close()
        return {'name': self.name, 'servers': out, 'ok': bool(out) and all(s['ok'] for s in out),
                'took_ms': int((time.time() - began) * 1000), 'tls': self.tls,
                'verify': self.verify}


def group_matches(wanted, have):
    """Whether any group in `have` ([(dn, cn)]) is one of `wanted` (names or
    DNs). Returns the wanted entry that matched first, in `wanted`'s order."""
    by_dn = {dn.lower() for dn, _ in have}
    by_cn = {str(cn).lower() for _, cn in have}
    for one in wanted:
        said = str(one.get('group') if isinstance(one, dict) else one).strip()
        if not said:
            continue
        if '=' in said and ',' in said:
            if said.lower() in by_dn:
                return one
        elif said.lower() in by_cn:
            return one
    return None


# ---------------------------------------------------------------------------
# The tokens themselves
# ---------------------------------------------------------------------------
# The words a check of a code ends in are totpcgi's own, letter for letter:
# isemon reads them out of the token log and turns them into its own words
# (`OTP_SAYS`), and anything that already watches a token server knows them.
SAY_OK = 'Valid token used'
SAY_OK_DRIFT = 'Valid token within window size used'
SAY_SCRATCH = 'Scratch-token used'
SAY_BAD = 'Not a valid token'
SAY_REUSED = 'Token has already been used once'
SAY_RATE = 'Rate-limit reached, please try again later'
SAY_LOCKED = 'Locked out after too many wrong codes, please try again later'
SAY_NONE = 'No token is enrolled for this account'
SAY_OFF = 'This token is switched off'
SAY_PENDING = 'This token has not been confirmed yet'
SAY_LOST = 'The key of this token cannot be opened on this machine'


def seal_codes(codes, bind=None):
    """Recovery codes kept so that an administrator can show them again -
    each with when it was used, if it was: sealed with the key of the tokens,
    beside their hashes, which are what a code is checked against."""
    if not codes:
        return ''
    out = []
    for c in codes:
        out.append(dict(c) if isinstance(c, dict) else {'c': str(c), 'used': None})
    return seal_secret(json.dumps(out), bind)


def open_codes(value, bind=None):
    """The codes `seal_codes` kept, as [{c, used}] - also the plain JSON list
    an older version left in pending_scratch. None when none are kept."""
    if not value:
        return None
    text = unseal_secret(value, bind)
    if text is None and str(value).lstrip().startswith('['):
        text = value
    try:
        got = json.loads(text) if text else None
    except ValueError:
        return None
    if not isinstance(got, list):
        return None
    return [dict(x) if isinstance(x, dict) else {'c': str(x), 'used': None} for x in got]


class Tokens(object):
    """Making, checking and looking after tokens."""

    def __init__(self, store):
        self.store = store
        # A fixed row of locks, a name always to the same one: two checks of
        # one token wait for each other, and the row cannot grow however
        # many names are tried.
        self.locks = [threading.Lock() for _ in range(1024)]
        self.on_check = None                       # (name, ok, said, how, src, rid)

    def lock_of(self, name):
        return self.locks[zlib.crc32(str(name).encode('utf-8')) % len(self.locks)]

    # ---- made ------------------------------------------------------------------
    def label_for(self, name):
        tpl = str(CONFIG.get('totp_label') or '{user}')
        return tpl.replace('{user}', name).replace('{name}', name.split('@', 1)[0])[:190]

    def fresh(self):
        """A new key and new recovery codes, not yet anybody's."""
        secret = b32_new(20)
        codes = scratch_new(int(CONFIG.get('scratch_count') or 0),
                            int(CONFIG.get('scratch_digits') or 8))
        return secret, codes

    def picture(self, name, secret, digits=None, period=None, algorithm=None, issuer=None):
        """What the person scans, in every shape a page wants it."""
        digits = int(digits or CONFIG.get('totp_digits') or 6)
        period = int(period or CONFIG.get('totp_period') or 30)
        algorithm = str(algorithm or CONFIG.get('totp_algorithm') or 'SHA1')
        issuer = issuer if issuer is not None else str(CONFIG.get('totp_issuer') or '')
        uri = otpauth_uri(secret, self.label_for(name), issuer, digits, period, algorithm)
        return {'uri': uri, 'qr': qr_data_uri(uri), 'secret': secret,
                'secret_spaced': ' '.join(secret[i:i + 4] for i in range(0, len(secret), 4)),
                'issuer': issuer, 'label': self.label_for(name), 'digits': digits,
                'period': period, 'algorithm': algorithm}

    def enroll(self, name, by, pending=False, secret=None, codes=None, display='', note=None):
        """A token for `name`, replacing any there was. `pending` makes it wait
        for a code before it is used. Returns the picture and the codes."""
        name = norm_name(name)
        if not name:
            raise ValueError('a token needs a name')
        # 180 at most (1.0.44): staged:NAME and mailed:NAME have to fit a key.
        if not re.match(r'^[^\s,;=]{1,180}$', name):
            raise ValueError('a name has no spaces, commas, semicolons or = in it, and '
                             'is 180 characters at most')
        if secret is None:
            secret, codes = self.fresh()
        codes = list(codes or [])
        fields = {
            'secret': seal_secret(secret, token_bind(name)),
            'digits': int(CONFIG.get('totp_digits') or 6),
            'period': int(CONFIG.get('totp_period') or 30),
            'algorithm': str(CONFIG.get('totp_algorithm') or 'SHA1'),
            'state': 'pending' if pending else 'active', 'last_step': 0,
            'scratch': json.dumps([scratch_hash(name, c) for c in codes]),
            'scratch_sealed': seal_codes(codes, token_bind(name)),
            'scratch_left': len(codes), 'created': time.time(), 'created_by': str(by)[:190],
            'activated': None if pending else time.time(), 'failures': 0,
            'fail_times': '[]', 'locked_until': None,
            'issuer': str(CONFIG.get('totp_issuer') or ''),
            'label': self.label_for(name), 'pending_secret': None, 'pending_scratch': None,
            'pending_at': None, 'pending_by': None, 'last_used': None, 'last_from': '',
            'last_how': ''}
        if display:
            fields['display'] = str(display)[:300]
        if note is not None:
            fields['note'] = str(note)[:400]
        self.store.token_write(name, fields)
        self._staged_forget(name)
        out = self.picture(name, secret)
        out['scratch'] = codes
        out['name'] = name
        return out

    # ---- the shape of a key waiting beside an old one (1.0.32) ----------
    # A replacement is made with the settings of the day - digits, period,
    # hash - which need not be the old token's: an imported SHA-1 six-digit
    # token replaced while the settings say SHA-512 and eight digits. The
    # token's own columns describe the old key until the new one is
    # confirmed, so the new key's shape is kept beside it.
    def staged_shape(self, name):
        try:
            got = json.loads(self.store.get_meta('staged:' + norm_name(name), '') or '{}')
        except ValueError:
            got = {}
        return {'digits': int(got.get('digits') or CONFIG.get('totp_digits') or 6),
                'period': int(got.get('period') or CONFIG.get('totp_period') or 30),
                'algorithm': str(got.get('algorithm') or CONFIG.get('totp_algorithm') or 'SHA1'),
                'issuer': str(got.get('issuer') if got.get('issuer') is not None
                              else CONFIG.get('totp_issuer') or '')}

    def _staged_forget(self, name):
        try:
            self.store.db.run('DELETE FROM meta WHERE k = ?', ('staged:' + norm_name(name),))
        except Exception:                               # noqa: BLE001
            pass

    def stage_replacement(self, name, by):
        """A new key for somebody who has a token already, kept beside the
        old one until a code from the new one proves it was scanned. The old
        one goes on working until then."""
        name = norm_name(name)
        if not self.store.token(name):
            raise ValueError('%s has no token to replace' % name)
        secret, codes = self.fresh()
        shape = {'digits': int(CONFIG.get('totp_digits') or 6),
                 'period': int(CONFIG.get('totp_period') or 30),
                 'algorithm': str(CONFIG.get('totp_algorithm') or 'SHA1'),
                 'issuer': str(CONFIG.get('totp_issuer') or '')}
        self.store.set_meta('staged:' + name, json.dumps(shape))
        self.store.token_write(name, {
            'pending_secret': seal_secret(secret, token_bind(name)),
            'pending_scratch': seal_codes(codes, token_bind(name)), 'pending_at': time.time(),
            'pending_by': str(by)[:190]})
        out = self.picture(name, secret, shape['digits'], shape['period'], shape['algorithm'],
                           shape['issuer'] or None)
        out['scratch'] = codes
        out['name'] = name
        return out

    def confirm(self, name, code, how='portal', src=''):
        """A code from a token that is waiting - a new one, or a replacement
        staged beside an old one. (ok, words)."""
        name = norm_name(name)
        # One at a time per name, as a check is (1.0.33).
        with self.lock_of(name):
            return self._confirm(name, code, how, src)

    def _confirm(self, name, code, how='portal', src=''):
        tok = self.store.token(name)
        if not tok:
            return False, SAY_NONE
        staged = bool(tok.get('pending_secret'))
        # Only a token that waits is confirmed: a new one, or one with a
        # replacement staged. A token an administrator switched off is not
        # brought back by its owner's code (1.0.15), and an active one with
        # nothing staged has nothing to confirm.
        if tok.get('state') == 'disabled':
            return False, SAY_OFF
        if not staged and tok.get('state') != 'pending':
            return False, 'There is nothing to confirm: this token is in use already'
        sealed = tok['pending_secret'] if staged else tok['secret']
        secret = unseal_secret(sealed or '', token_bind(name))
        if not secret:
            return False, SAY_LOST
        # A staged key is checked with its own shape, not the old token's.
        shape = self.staged_shape(name) if staged else {
            'digits': tok['digits'] or 6, 'period': tok['period'] or 30,
            'algorithm': tok['algorithm'] or 'SHA1', 'issuer': tok.get('issuer') or ''}
        # Throttled like a sign-in (1.0.33): the same pause after wrong codes,
        # so the page cannot be used to guess a waiting key's codes quickly.
        t = time.time()
        try:
            fails = [float(x) for x in json.loads(tok.get('fail_times') or '[]')]
        except (ValueError, TypeError):
            fails = []
        tries = int(CONFIG.get('rate_limit_tries') or 0)
        fails = [x for x in fails if t - x < int(CONFIG.get('rate_limit_s') or 30)]
        if (tries and len(fails) >= tries) or float(tok.get('locked_until') or 0) > t:
            self._said(name, False, SAY_RATE + ' (confirming a new token)', how, src, '')
            return False, SAY_RATE
        step = totp_match(secret, code, None, shape['digits'], shape['period'],
                          shape['algorithm'], self.window(tok))
        if step is None:
            # Counted toward the lockout as well (1.0.44), not only the short
            # pause: a waiting key could be guessed at day after day.
            self.store.db.run('UPDATE tokens SET failures = COALESCE(failures, 0) + 1 '
                              'WHERE id = ?', (tok['id'],))
            n = int(self.store.db.value('SELECT failures FROM tokens WHERE id = ?',
                                        (tok['id'],)) or 0)
            fields = {'fail_times': json.dumps(fails + [t])}
            after = int(CONFIG.get('lockout_after') or 0)
            if after and n >= after:
                fields['locked_until'] = t + 60 * int(CONFIG.get('lockout_min') or 15)
            self.store.token_update(tok['id'], fields)
            self._said(name, False, SAY_BAD + ' (confirming a new token)', how, src, '')
            return False, SAY_BAD + '. ' + self.why_wrong(secret, code, shape)
        # last_step never goes down for the same key: its code of a step
        # already used stays used. A new key starts from its own step
        # (1.0.33): steps of another period are not comparable - a 30 s
        # token replaced by a 60 s one refused every code after.
        fields = {'state': 'active', 'activated': time.time(),
                  'last_step': int(step) if staged else max(int(step),
                                                             int(tok.get('last_step') or 0)),
                  'failures': 0, 'fail_times': '[]', 'locked_until': None}
        if staged:
            codes = [x['c'] for x in (open_codes(tok.get('pending_scratch'),
                                                 token_bind(name)) or [])]
            fields.update({'secret': tok['pending_secret'], 'pending_secret': None,
                           'pending_scratch': None, 'pending_at': None, 'pending_by': None,
                           'scratch': json.dumps([scratch_hash(name, c) for c in codes]),
                           'scratch_sealed': seal_codes(codes, token_bind(name)),
                           'scratch_left': len(codes), 'created': time.time(),
                           'created_by': tok.get('pending_by') or how,
                           'digits': shape['digits'], 'period': shape['period'],
                           'algorithm': shape['algorithm'],
                           'label': self.label_for(name),
                           'issuer': shape['issuer'],
                           # The old key's use is not the new one's (1.0.36).
                           'last_used': None, 'last_from': '', 'last_how': ''})
        self.store.token_update(tok['id'], fields)
        if staged:
            self._staged_forget(name)
        self._said(name, True, 'Token confirmed', how, src, '')
        return True, 'Token confirmed'

    @staticmethod
    def why_wrong(secret, code, tok):
        """What a wrong code most likely means, for the person typing it."""
        period = int(tok.get('period') or 30)
        far = totp_match(secret, code, None, tok.get('digits') or 6, period,
                         tok.get('algorithm') or 'SHA1', 40)
        if far is not None:
            off = (far - totp_step(None, period)) * period
            return ('It is this token\'s code, but from %d s %s: the clock of the phone is '
                    'wrong - set it to the network\'s time.' % (abs(off), 'ago' if off < 0
                                                                 else 'ahead'))
        return ('It is not a code of this token. If the application shows several accounts '
                'of this name, an older one is answering - type the code of the newest, or '
                'take the old one out of the application.')

    def drop_staged(self, name):
        tok = self.store.token(name)
        if not tok:
            self._staged_forget(name)
            return
        self.store.token_update(tok['id'], {'pending_secret': None, 'pending_scratch': None,
                                      'pending_at': None, 'pending_by': None})
        self._staged_forget(name)

    def new_scratch(self, name, by=''):
        name = norm_name(name)
        if not self.store.token(name):
            raise ValueError('%s has no token' % name)
        codes = scratch_new(int(CONFIG.get('scratch_count') or 0) or 5,
                            int(CONFIG.get('scratch_digits') or 8))
        self.store.token_write(name, {'scratch': json.dumps([scratch_hash(name, c)
                                                             for c in codes]),
                                      'scratch_sealed': seal_codes(codes, token_bind(name)),
                                      'scratch_left': len(codes)})
        return codes

    @staticmethod
    def window(tok):
        w = tok.get('window_steps')
        if w is None or int(w) < 0:
            return int(CONFIG.get('totp_window') or 0)
        return int(w)

    # ---- checked ---------------------------------------------------------------
    def check(self, name, code, how='radius', src='127.0.0.1', rid='', dry=False, quiet=False):
        """Whether `code` is right for the token of `name`. (ok, words, facts)
        - the words totpcgi would have said. `quiet`: not written down - the
        probe that finds where a password ends and its code begins."""
        name = norm_name(name)
        code = str(code or '').strip()
        with self.lock_of(name):
            ok, said, facts = self._check(name, code, dry)
        # A dry check - the administrator's test - is written down like any
        # other, marked as such; the only thing it leaves alone is the code,
        # which stays usable.
        if not quiet:
            self._said(name, ok, said, how + '-dry' if dry else how, src, rid, facts.get('off'))
        return ok, said, facts

    def _check(self, name, code, dry):
        tok = self.store.token(name)
        facts = {}
        if not tok:
            return False, SAY_NONE, facts
        if tok.get('state') == 'disabled':
            return False, SAY_OFF, facts
        if tok.get('state') == 'pending':
            return False, SAY_PENDING, facts
        t = time.time()
        try:
            fails = [float(x) for x in json.loads(tok.get('fail_times') or '[]')]
        except (ValueError, TypeError):
            fails = []
        tries = int(CONFIG.get('rate_limit_tries') or 0)
        span = int(CONFIG.get('rate_limit_s') or 30)
        fails = [x for x in fails if t - x < span]
        # A lockout after many wrong codes in a row, however slowly they
        # came (1.0.33): the short pause alone let a patient guesser try
        # thousands of codes a day.
        if float(tok.get('locked_until') or 0) > t:
            return False, SAY_LOCKED, facts
        if tries and len(fails) >= tries:
            return False, SAY_RATE, facts
        secret = unseal_secret(tok.get('secret') or '', token_bind(name))
        if not secret:
            return False, SAY_LOST, facts
        digits = int(tok.get('digits') or 6)
        # Digits 0-9 and nothing else: \d also takes Arabic-Indic and other
        # digits, which then broke the comparison and left the request
        # unanswered and unwritten (1.0.33).
        plain = re.fullmatch(r'[0-9]+', code, re.ASCII) is not None

        def failed(said):
            # A dry check - the administrator's test, or the probe that finds
            # where a password ends and its code begins - counts nothing
            # (1.0.33): it is not somebody trying to sign in, and it counted
            # one typo three times.
            if dry:
                return False, said, facts
            # Counted in the database itself (1.0.44): two nodes reading
            # n and both writing n+1 lost one wrong code each time.
            self.store.db.run('UPDATE tokens SET failures = COALESCE(failures, 0) + 1 '
                              'WHERE id = ?', (tok['id'],))
            n = int(self.store.db.value('SELECT failures FROM tokens WHERE id = ?',
                                        (tok['id'],)) or 0)
            fields = {'fail_times': json.dumps(fails + [t])}
            after = int(CONFIG.get('lockout_after') or 0)
            if after and n >= after:
                fields['locked_until'] = t + 60 * int(CONFIG.get('lockout_min') or 15)
            self.store.token_update(tok['id'], fields)
            if after and n == after:
                log('the token of %s is locked out for %d min after %d wrong codes in a row'
                    % (name, int(CONFIG.get('lockout_min') or 15), n), 'warn')
            return False, said, facts
        if not plain:
            return failed(SAY_BAD)

        def scratch_try():
            """A recovery code: used once. None when it is not one."""
            try:
                kept = json.loads(tok.get('scratch') or '[]')
            except ValueError:
                kept = []
            key = sealing_key()
            hit, h = scratch_find(name, code, kept, key)
            if hit:
                was = tok.get('scratch') or '[]'
                if not dry:
                    kept.remove(hit)
                    shown = open_codes(tok.get('scratch_sealed'), token_bind(name))
                    if shown is not None:
                        for one in shown:
                            if not one.get('used') and hmac.compare_digest(
                                    scratch_hash(name, one['c'], key), h):
                                one['used'] = t
                        # The rest, which were kept in the old shape too if
                        # this one was, written in the new one.
                        # (Without a sealed copy the others stay as they
                        # are until each is used.)
                        if hit != h:
                            kept = [scratch_hash(name, one['c'], key) for one in shown
                                    if not one.get('used')]
                    # Only if the codes are still the ones read: a recovery
                    # code used on the other node at the same moment is not
                    # used twice. (1.0.13)
                    won = self.store.db.run(
                        'UPDATE tokens SET scratch = ?, scratch_sealed = ?, scratch_left = ?, '
                        "last_used = ?, last_how = 'scratch', failures = 0, fail_times = '[]' "
                        'WHERE id = ? AND scratch = ?',
                        (json.dumps(kept), seal_codes(shown, token_bind(name)) if shown is not None else
                         (tok.get('scratch_sealed') or ''), len(kept), t, tok['id'], was))
                    if not won:
                        return False, SAY_REUSED, facts
                elif hit != h:
                    # Dry, so the code stays; but an entry in the old shape is
                    # rewritten in the new one now that it is known.
                    kept[kept.index(hit)] = h
                    self.store.db.run('UPDATE tokens SET scratch = ? WHERE id = ? AND scratch = ?',
                                      (json.dumps(kept), tok['id'], was))
                facts['scratch_left'] = len(kept)
                return True, SAY_SCRATCH, facts
            return None
        if len(code) != digits:
            got = scratch_try()
            return got if got is not None else failed(SAY_BAD)
        step = totp_match(secret, code, t, digits, tok.get('period') or 30,
                          tok.get('algorithm') or 'SHA1', self.window(tok))
        if step is None:
            # A recovery code as long as a code from the phone (1.0.33): with
            # the two lengths set alike, recovery codes were never tried.
            got = scratch_try()
            return got if got is not None else failed(SAY_BAD)
        facts['off'] = step - totp_step(t, tok.get('period') or 30)
        if CONFIG.get('totp_disallow_reuse', 1) and step <= int(tok.get('last_step') or 0):
            return failed(SAY_REUSED)
        if not dry:
            if CONFIG.get('totp_disallow_reuse', 1):
                # Used up with one conditional UPDATE: of two nodes asked for
                # the same code at the same moment, only one changes the row.
                won = self.store.db.run(
                    'UPDATE tokens SET last_step = ?, last_used = ?, failures = 0, '
                    "fail_times = '[]', last_how = 'code' WHERE id = ? AND "
                    'COALESCE(last_step, 0) < ?', (step, t, tok['id'], step))
                if not won:
                    return False, SAY_REUSED, facts
            else:
                self.store.token_update(tok['id'], {'last_step': step, 'last_used': t,
                                                    'failures': 0, 'fail_times': '[]',
                                                    'last_how': 'code'})
        return True, (SAY_OK if facts['off'] == 0 else SAY_OK_DRIFT), facts

    def mark_from(self, name, src):
        # One UPDATE (1.0.33): read and written again, it was two round trips
        # on every request let in.
        self.store.db.run('UPDATE tokens SET last_from = ? WHERE name = ?',
                          (str(src or '')[:120], norm_name(name)))

    def _said(self, name, ok, said, how, src, rid, off=None):
        try:
            self.store.otp_add({'ts': time.time(), 'name': name, 'ok': 1 if ok else 0,
                                'said': said, 'how': how, 'src': str(src or '')[:120],
                                'rid': str(rid or '')[:120],
                                'step_off': int(off) if off is not None else None})
        except Exception as e:
            log('the check of a code could not be written down: %s' % e, 'warn')
        if self.on_check:
            try:
                self.on_check(name, ok, said, how, src, rid)
            except Exception as e:
                log('the check of a code could not be sent on: %s' % e, 'warn')


# ---------------------------------------------------------------------------
# Sending the logs to isemon
# ---------------------------------------------------------------------------
# isemon reads a token server through two files rsyslog writes for it: what
# totpcgi said about every code (`totp.cgi`), and every RADIUS packet the
# FreeRADIUS in front of it wrote into its detail files, one to a line
# (`radius-detail`). This writes both, in exactly those shapes, as syslog to
# isemon's receiver - and into files here as well - so that isemon reads this
# server with the readers it already has and nothing changed on its side.

SYSLOG_FACILITY = {'auth': 4, 'authpriv': 10, 'local5': 21, 'daemon': 3, 'user': 1}


def syslog_targets(text, strict=False):
    """`host[:port][/udp|/tcp]`, comma separated, as (host, port, proto)."""
    out = []
    for one in re.split(r'[,;\s]+', str(text or '')):
        one = one.strip()
        if not one:
            continue
        m = re.match(r'^(\[[0-9a-fA-F:]+\]|[A-Za-z0-9.\-]+)(?::(\d+))?(?:/(udp|tcp))?$',
                     one, re.I)
        if not m:
            if strict:
                raise BadSetting('isemon_targets: %r is not host[:port][/udp|/tcp]' % one)
            continue
        port = int(m.group(2) or 514)
        if strict and not 0 < port < 65536:
            raise BadSetting('isemon_targets: %d is not a port' % port)
        out.append((m.group(1).strip('[]'), port, (m.group(3) or 'udp').lower()))
    return out


def syslog_stamp(ts=None):
    """`Oct 22 15:31:02` - RFC 3164, the shape the readers on the other side
    expect: no year, no zone, the day padded with a space."""
    t = datetime.fromtimestamp(float(ts if ts is not None else time.time()))
    return '%s %2d %s' % (t.strftime('%b'), t.day, t.strftime('%H:%M:%S'))


def detail_quote(value):
    """A value as FreeRADIUS writes it in a detail file: a string in quotes,
    with its quotes and backslashes escaped."""
    said = str(value)
    if re.match(r'^(0x[0-9a-fA-F]*|\d+|\d+\.\d+\.\d+\.\d+)$', said) or said in (
            'Access-Request', 'Access-Accept', 'Access-Reject', 'Access-Challenge',
            'Accounting-Request') or re.match(r'^[A-Z][A-Za-z0-9.-]*$', said) and \
            said in [w for d in RADIUS_VALUES.values() for w in d.values()]:
        return said
    return '"%s"' % said.replace('\\', '\\\\').replace('"', '\\"')


class Shipper(object):
    """A queue and a thread that empties it into isemon's receivers and the
    files here. Nothing that answers a VPN ever waits for any of it."""

    def __init__(self):
        self.q = queue.Queue(maxsize=20000)
        self.targets = []
        self.tcp = {}
        self.udp4 = None
        self.udp6 = None
        self.files = {}
        self.sent = collections.Counter()
        self.trouble = {}
        self.dropped = 0
        self.last_sent = 0.0
        self.stop_flag = False
        self.thread = threading.Thread(target=self.run, name='shipper', daemon=True)
        self.configure()
        self.thread.start()

    def configure(self):
        self.targets = syslog_targets(CONFIG.get('isemon_targets')) if CONFIG.get('isemon') \
            else []
        for key, sock in list(self.tcp.items()):
            if (key[0], key[1], 'tcp') not in self.targets:
                try:
                    sock.close()
                except OSError:
                    pass
                self.tcp.pop(key, None)

    def host(self):
        return str(CONFIG.get('isemon_hostname') or '').strip() or short_host()

    # ---- what is said ----------------------------------------------------------
    def put(self, tag, facility, words, ts=None, file_name=None):
        if not CONFIG.get('isemon') and not CONFIG.get('ship_files'):
            return
        most = int(CONFIG.get('isemon_max_bytes') or 1800)
        if len(words.encode('utf-8')) > most:
            words = words.encode('utf-8')[:most].decode('utf-8', 'ignore') + ' ...TRUNCATED'
        line = '%s %s %s[%d]: %s' % (syslog_stamp(ts), self.host(), tag, os.getpid(),
                                     words.replace('\n', ' ').replace('\r', ' '))
        pri = SYSLOG_FACILITY.get(facility, 1) * 8 + 5          # notice
        try:
            self.q.put_nowait((pri, line, file_name))
        except queue.Full:
            self.dropped += 1

    def token_line(self, name, ok, said, how, src, rid):
        """`totp.cgi[pid]: Success: user=..., mode=PAM_SM_AUTH, host=..., rid=...,
        message=...` - totpcgi's own line, with the request id isemon joins it
        to the RADIUS packet by."""
        if how not in ('radius', 'test'):
            mode = 'PROVISION' if how == 'portal' else how.upper()
        else:
            mode = 'PAM_SM_AUTH'
        clean = lambda s: re.sub(r'[\r\n]', ' ', str(s or ''))
        rid = re.sub(r'[^A-Za-z0-9.:_-]', '', str(rid or ''))[:64]
        words = '%s: user=%s, mode=%s, host=%s, %smessage=%s' % (
            'Success' if ok else 'Failure', clean(name), mode, '127.0.0.1',
            ('rid=%s, ' % rid) if rid else '', clean(said))
        self.put('totp.cgi', 'auth', words, file_name='totp.cgi.log')

    def detail_line(self, nas, kind, ts, pairs, ident=''):
        """`radius-detail[pid]: nas=... id=... file=auth-detail-YYYYMMDD ts=[ctime]
        Name = value, ...` - one detail record a line, the way the shipper
        isemon ships with writes it."""
        if not CONFIG.get('isemon_detail', 1):
            return
        fname = '%s-%s' % (kind, datetime.fromtimestamp(ts).strftime('%Y%m%d'))
        body = ', '.join('%s = %s' % (k, detail_quote(v)) for k, v in pairs)
        rid = ident or hashlib.sha1(('%s|%s|%s|%s' % (nas, fname, ts, body))
                                    .encode('utf-8', 'replace')).hexdigest()[:16]
        words = 'nas=%s id=%s file=%s ts=[%s] %s' % (nas, rid, fname, time.ctime(ts), body)
        self.put('radius-detail', 'local5', words, file_name='radius-detail.log')

    def event_line(self, kind, words, level, who):
        if CONFIG.get('isemon_events'):
            self.put('otp', 'daemon', '%s: %s%s' % (kind, words, (' (by %s)' % who) if who
                                                    else ''), file_name=None)

    # ---- sending ---------------------------------------------------------------
    def run(self):
        while not self.stop_flag:
            try:
                pri, line, file_name = self.q.get(timeout=1.0)
            except queue.Empty:
                continue
            if file_name and CONFIG.get('ship_files'):
                self._to_file(file_name, line)
            if CONFIG.get('isemon'):
                for target in list(self.targets):
                    self._to_target(target, '<%d>%s' % (pri, line))

    def _to_file(self, name, line):
        path = LOG_DIR / name
        f = self.files.get(name)
        try:
            if f is not None:
                try:
                    if os.fstat(f.fileno()).st_ino != os.stat(path).st_ino:
                        raise OSError('rotated')
                except OSError:
                    f.close()
                    f = None
            if f is None:
                LOG_DIR.mkdir(parents=True, exist_ok=True)
                f = open(path, 'a', encoding='utf-8')
                self.files[name] = f
            f.write(line + '\n')
            f.flush()
        except OSError as e:
            self.trouble['file:' + name] = str(e)

    def _to_target(self, target, data):
        host, port, proto = target
        key = '%s:%d/%s' % target
        raw = data.encode('utf-8', 'replace')
        try:
            if proto == 'udp':
                fam = socket.AF_INET6 if ':' in host else socket.AF_INET
                if fam == socket.AF_INET6:
                    if self.udp6 is None:
                        self.udp6 = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
                    self.udp6.sendto(raw, (host, port))
                else:
                    if self.udp4 is None:
                        self.udp4 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    self.udp4.sendto(raw, (host, port))
            else:
                sock = self.tcp.get((host, port))
                for attempt in (1, 2):
                    if sock is None:
                        sock = socket.create_connection((host, port), timeout=5)
                        sock.settimeout(5)
                        self.tcp[(host, port)] = sock
                    try:
                        sock.sendall(raw + b'\n')
                        break
                    except OSError:
                        try:
                            sock.close()
                        except OSError:
                            pass
                        sock = None
                        self.tcp.pop((host, port), None)
                        if attempt == 2:
                            raise
            self.sent[key] += 1
            self.last_sent = time.time()
            self.trouble.pop(key, None)
        except OSError as e:
            if key not in self.trouble:
                log('isemon at %s cannot be sent to: %s' % (key, e), 'warn')
            self.trouble[key] = '%s (%s)' % (e, datetime.now().strftime('%H:%M:%S'))

    def state(self):
        return {'on': bool(CONFIG.get('isemon')), 'host': self.host(),
                'targets': ['%s:%d/%s' % t for t in self.targets],
                'sent': dict(self.sent), 'trouble': dict(self.trouble),
                'queued': self.q.qsize(), 'dropped': self.dropped,
                'last_sent': self.last_sent, 'files': bool(CONFIG.get('ship_files')),
                'file_dir': str(LOG_DIR)}

    def flush(self, wait=3.0):
        until = time.time() + wait
        while not self.q.empty() and time.time() < until:
            time.sleep(0.05)


# ---------------------------------------------------------------------------
# Deciding: one Access-Request, step by step
# ---------------------------------------------------------------------------
# The order (1.0.33): the realm and whether this client may use it, the
# directory - is the account there, in use, in a group that lets in - and
# its password, and the code last. Somebody who does not know the password
# can then neither guess codes nor lock a token out by guessing them, and a
# code is only used up by a request that would otherwise be let in. (Until
# 1.0.32 the code came first, as the old token server had it.)
#
# Every step is written down - what was asked, what came back, how long it
# took - and kept with the request, so that "why was I refused" is answered
# by opening one row rather than by reading a debug log.

class Decision(object):
    def __init__(self):
        self.steps = []
        self.began = time.time()
        self.result = 'reject'
        self.reason = ''
        self.otp = ''
        self.reply = []                 # [(Name, value)]
        self.realm = ''
        self.user = ''
        self.token_name = ''
        self.display = ''

    def step(self, what, ok, said='', since=None):
        one = {'what': what, 'ok': ok, 'said': str(said or '')[:600]}
        if since is not None:
            one['ms'] = int((time.time() - since) * 1000)
        self.steps.append(one)
        if debugging('radius'):
            log('radius %s: %s%s' % (self.user or '?', what,
                                     (' - ' + str(said)) if said else ''), 'debug')
        return one

    def refuse(self, reason):
        self.result = 'reject'
        self.reason = reason
        return self


def client_realm_list(client):
    """The realms a client may use, by name, lower case; [] for any."""
    raw = (client or {}).get('realms') or ''
    if isinstance(raw, (list, tuple)):
        got = raw
    else:
        got = re.split(r'[,;\n]+', str(raw))
    return [str(x).strip().lower() for x in got if str(x).strip()]


class Authenticator(object):
    """What the RADIUS server asks: may this person in, and with what."""

    def __init__(self, store, tokens, dirs):
        self.store = store
        self.tokens = tokens
        self.dirs = dirs                 # name -> Directory

    def directory(self, name):
        return self.dirs.get(str(name or '').lower())

    @staticmethod
    def full_name(user, client_realm):
        """The name as it will be looked up: DOMAIN\\name as name, and the
        client's own realm added to a name that has none - what FreeRADIUS's
        hints file did, NAS by NAS. A dot at the end of the realm is dropped
        (corp.cz. is corp.cz) and a name with nothing before its @ is no
        name at all (1.0.33)."""
        said = str(user or '').strip()
        if '\\' in said and '@' not in said:
            said = said.split('\\', 1)[1]
        if '@' in said:
            who, _, where = said.rpartition('@')
            where = where.strip().rstrip('.')
            who = who.strip()
            if not who or not where:
                return ''
            return '%s@%s' % (who, where)
        if not said:
            return ''
        if client_realm:
            said = '%s@%s' % (said, str(client_realm).lstrip('@'))
        return said

    @staticmethod
    def token_name(user, realm):
        if realm and realm.get('token_name') == 'bare':
            return norm_name(user.split('@', 1)[0])
        return norm_name(user)

    def decide(self, user, password, client_realm='', src='', rid='', chap=False,
               how='radius', client=None):
        d = Decision()
        d.user = self.full_name(user, client_realm or CONFIG.get('default_realm') or '')
        if not d.user:
            d.step('a name', False, 'the request carries no User-Name, or only a realm')
            return d.refuse('the request carries no User-Name')
        if d.user != str(user):
            d.step('the name is read as %s' % d.user, True,
                   'the client adds @%s to a name without a realm' % client_realm
                   if client_realm and '@' not in str(user) else '')
        realm = self.store.realm_for(d.user)
        if not realm:
            d.step('a realm for %s' % d.user, False, 'no realm takes this name')
            return d.refuse('no realm takes the name %s' % d.user)
        d.realm = realm['name']
        d.step('the realm is %s' % realm['name'], True, {
            'otp': 'the password is the code from the phone',
            'password_otp': 'the password is the directory password followed by the code',
            'password': 'the password is the directory password alone'}[realm['auth_mode']])
        # Whether this client may use that realm at all (1.0.33): without it
        # the name typed chose the realm, and with it how strictly the
        # person is checked - user@wifi through the VPN, password alone.
        allowed = client_realm_list(client)
        if allowed and realm['name'].lower() not in allowed:
            d.step('the client may use the realm %s' % realm['name'], False,
                   'the client %s may use only: %s' % ((client or {}).get('name') or '?',
                                                       ', '.join(allowed)))
            return d.refuse('the client %s may not use the realm %s'
                            % ((client or {}).get('name') or '?', realm['name']))
        if chap or password is None:
            d.step('a password', False, 'CHAP or no User-Password: a one-time code can only '
                   'travel as PAP')
            return d.refuse('the request carries no User-Password (PAP)')
        if password and any(ord(c) < 32 or c == '\ufffd' for c in password):
            d.step('the password reads as text', False, 'what came is not text - is the shared '
                   'secret the same on both sides?')
            return d.refuse('the password does not decode: the shared secret is probably '
                            'not the same as on the client')
        if not password:
            d.step('a password', False, 'it is empty')
            return d.refuse('the password is empty')
        d.token_name = self.token_name(d.user, realm)
        mode = realm['auth_mode']
        # ---- where the password ends and the code begins -------------------
        code, ad_password = None, None
        if mode == 'otp':
            code = password
        elif mode == 'password_otp':
            tok = self.store.token(d.token_name)
            digits = int((tok or {}).get('digits') or CONFIG.get('totp_digits') or 6)
            splits = []
            if len(password) > digits:
                splits.append((password[-digits:], password[:-digits]))
            sd = int(CONFIG.get('scratch_digits') or 8)
            if len(password) > sd and sd != digits:
                splits.append((password[-sd:], password[:-sd]))
            if not splits:
                d.step('the code', False, 'nothing after the password looks like a code')
                d.otp = SAY_BAD
                return d.refuse('Denied by the token server: ' + SAY_BAD)
            code, ad_password = splits[0]
            if len(splits) > 1:
                # Which one: the code that is right now, found with a dry
                # check that counts nothing and writes nothing - so one
                # password costs the directory one try, not two.
                for c, rest in splits:
                    ok, _said, _f = self.tokens.check(d.token_name, c, how=how, src=src,
                                                      rid=rid, dry=True, quiet=True)
                    if ok:
                        code, ad_password = c, rest
                        break
        # ---- the directory -----------------------------------------------
        entry = None
        lookup = realm.get('lookup') or ''
        if lookup not in ('upn', 'sam'):
            # No way chosen: by the form of the name. A realm with a directory
            # always asks it - its groups and a switched-off account are never
            # skipped because nobody picked how to look a name up.
            lookup = 'upn' if '@' in d.user else 'sam'
        if (realm.get('groups') or []) and not realm.get('directory'):
            d.step('the groups of %s' % d.user, False, 'the realm names groups and no directory '
                   'to ask them of')
            return d.refuse('account does not pass LDAP group filter(s): the realm %s has no '
                            'directory' % realm['name'])
        if realm.get('directory'):
            ad = self.directory(realm['directory'])
            if not ad:
                d.step('the directory %s' % realm['directory'], False, 'it is not set up')
                return d.refuse('the directory %s is not set up' % realm['directory'])
            t = time.time()
            try:
                entry = ad.find_user(d.user, lookup)
            except LdapError as e:
                d.step('look %s up in %s' % (d.user, ad.name), False, str(e), t)
                return d.refuse('LDAP server(s) have gone away' if isinstance(
                    e, LdapUnreachable) else 'the directory could not be asked: %s' % e)
            if not entry:
                d.step('look %s up in %s' % (d.user, ad.name), False,
                       'by %s: there is no such account' % {'upn': 'userPrincipalName',
                                                           'sam': 'sAMAccountName'}.get(lookup,
                                                                                         lookup),
                       t)
                return d.refuse('account does not pass LDAP user filter: %s is not in %s'
                                % (d.user, ad.name))
            d.display = entry.get('display') or ''
            d.step('found %s' % entry['dn'], True, entry.get('display') or '', t)
            if realm.get('check_disabled', 1):
                if entry['disabled']:
                    d.step('the account is in use', False, 'it is disabled in the directory')
                    return d.refuse('the account is disabled in the directory')
                if entry.get('expires') and entry['expires'] < time.time():
                    d.step('the account is in use', False, 'it expired %s'
                           % stamp(entry['expires']))
                    return d.refuse('the account has expired in the directory')
            if mode in ('password', 'password_otp'):
                pw = password if mode == 'password' else ad_password
                t = time.time()
                try:
                    ad.password_ok(entry, pw)
                    d.step('the directory password', True, '', t)
                except LdapError as e:
                    d.step('the directory password', False, str(e), t)
                    return d.refuse('the directory refused the password: %s' % e
                                    if not isinstance(e, LdapUnreachable)
                                    else 'LDAP server(s) have gone away')
            wanted = realm.get('groups') or []
            if wanted:
                t = time.time()
                try:
                    have = ad.groups_of(entry, bool(realm.get('nested', 1)))
                except LdapError as e:
                    d.step('the groups of %s' % d.user, False, str(e), t)
                    return d.refuse('LDAP server(s) have gone away')
                hit = group_matches(wanted, have)
                if not hit:
                    names = ', '.join(cn_of(w.get('group') or '') or w.get('group') or ''
                                      for w in wanted[:6]) + (' …' if len(wanted) > 6 else '')
                    d.step('a member of one of %d group(s)' % len(wanted), False,
                           'a member of %d group(s)%s, none of them one of: %s'
                           % (len(have), ' (nested counted)' if realm.get('nested', 1) else '',
                              names), t)
                    return d.refuse('account does not pass LDAP group filter(s): %s is in '
                                    'none of %s' % (d.user, names))
                d.step('a member of %s' % hit['group'], True, '', t)
                try:
                    d.reply.extend(reply_lines(hit.get('reply') or ''))
                except RadiusError:
                    pass
        elif mode in ('password', 'password_otp'):
            d.step('the directory password', False, 'the realm has no directory to ask')
            return d.refuse('the realm %s has no directory' % realm['name'])
        # ---- the code, last ----------------------------------------------
        if code is not None:
            t = time.time()
            ok, said, facts = self.tokens.check(d.token_name, code, how=how, src=src, rid=rid)
            d.otp = said
            d.step('the code for the token %s' % d.token_name, ok, said, t)
            if not ok:
                return d.refuse('Denied by the token server: ' + said)
        try:
            d.reply = reply_lines(realm.get('reply') or '') + d.reply
        except RadiusError as e:
            d.step('the answer', False, str(e))
        d.result = 'accept'
        d.step('let in', True, ', '.join('%s = %s' % p for p in d.reply))
        return d


# ---------------------------------------------------------------------------
# The RADIUS server
# ---------------------------------------------------------------------------
class SentReply(bytes):
    """An answer, and whether it has gone out already."""
    sent = False
    late = False


class RadiusServer(object):
    """Two UDP sockets - authentication and accounting - read by a thread
    each and answered by a pool of workers."""

    def __init__(self, daemon):
        self.d = daemon
        self.socks = {}
        self.jobs = queue.Queue(maxsize=5000)
        # duplicate key -> (time, reply or None), oldest first, never more
        # than SEEN_MAX: a flood fills it to the brim and no further (1.0.33).
        self.seen = collections.OrderedDict()
        self.seen_lock = threading.Lock()
        self.unknown_said = {}
        self.unknown_lock = threading.Lock()
        # What is not written down one by one - malformed packets, and more
        # than a few unknown addresses a minute - is counted and summed up
        # once a minute instead (1.0.33): a flood of junk was a row each.
        self.quiet = collections.Counter()
        self.quiet_at = time.time()
        self.drops_this_minute = 0
        # Clients that have sent a right Message-Authenticator (1.0.33).
        self.ma_seen = set()
        # Refusals waiting out radius_reject_delay_ms (1.0.36).
        self.late = []
        self.late_lock = threading.Lock()
        self.late_wake = threading.Event()
        self.late_thread = None
        self.workers = []
        self.readers = []
        self.stop_flag = False
        self.counts = collections.Counter()
        self.bound = []
        self.trouble = ''

    # ---- the sockets -------------------------------------------------------------
    def want(self):
        bind = str(CONFIG.get('radius_bind') or '0.0.0.0')
        out = [('auth', bind, int(CONFIG.get('radius_auth_port') or 1812))]
        if int(CONFIG.get('radius_acct_port') or 0):
            out.append(('acct', bind, int(CONFIG.get('radius_acct_port'))))
        return out

    def start(self):
        self.stop_flag = False
        self.open_sockets()
        for i in range(int(CONFIG.get('radius_workers') or 16)):
            t = threading.Thread(target=self.work, name='radius-%d' % i, daemon=True)
            t.start()
            self.workers.append(t)

    def open_sockets(self):
        want = self.want()
        if [(k, b, p) for k, (b, p, _s) in sorted(self.socks.items())] == sorted(want):
            return
        for kind, (_b, _p, sock) in list(self.socks.items()):
            try:
                sock.close()
            except OSError:
                pass
        self.socks = {}
        self.bound = []
        troubles = []
        for kind, bind, port in want:
            fam = socket.AF_INET6 if ':' in bind else socket.AF_INET
            sock = socket.socket(fam, socket.SOCK_DGRAM)
            # No SO_REUSEADDR: on UDP it lets a second process bind the very same
            # port and take half the packets. A port in use has to say so.
            if fam == socket.AF_INET6:
                try:
                    sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                except OSError:
                    pass
            try:
                sock.bind((bind, port))
            except OSError as e:
                troubles.append('%s:%d (%s) could not be listened on: %s' % (bind, port, kind, e))
                sock.close()
                continue
            sock.settimeout(1.0)
            self.socks[kind] = (bind, port, sock)
            self.bound.append('%s:%d/%s' % (bind, port, kind))
            t = threading.Thread(target=self.read, args=(kind, sock), name='radius-' + kind,
                                 daemon=True)
            t.start()
            self.readers.append(t)
        self.trouble = '; '.join(troubles)
        if troubles:
            self.d.store.add_event('radius', self.trouble, 'bad')
        else:
            log('RADIUS listening on %s' % ', '.join(self.bound))

    def stop(self):
        self.stop_flag = True
        for _b, _p, sock in self.socks.values():
            try:
                sock.close()
            except OSError:
                pass

    def read(self, kind, sock):
        while not self.stop_flag:
            try:
                data, peer = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                if self.socks.get(kind, (None, None, None))[2] is not sock:
                    return
                time.sleep(0.2)
                continue
            if self.socks.get(kind, (None, None, None))[2] is not sock:
                return
            try:
                self.jobs.put_nowait((kind, sock, data, peer, time.time()))
            except queue.Full:
                self.counts['overflow'] += 1

    def work(self):
        while not self.stop_flag:
            try:
                kind, sock, data, peer, arrived = self.jobs.get(timeout=1.0)
            except queue.Empty:
                continue
            try:
                self.handle(kind, sock, data, peer, arrived)
            except Exception as e:
                log('a RADIUS request from %s broke: %s\n%s' % (peer[0], e,
                                                                 traceback.format_exc()), 'error')

    # ---- one packet -----------------------------------------------------------
    def handle(self, kind, sock, data, peer, arrived):
        ip, port = peer[0], peer[1]
        if ip.startswith('::ffff:'):
            ip = ip[7:]
        self.counts['packets'] += 1
        self.sum_up()
        # In maintenance nothing is answered (1.0.37): the VPN takes this
        # node for down and asks the other, as it would any node that is.
        if maintenance_now(self.d.store).get('on'):
            self.counts['maintenance'] += 1
            return
        client = self.d.store.client_for(ip)
        try:
            pkt = Packet.parse(data)
        except RadiusError as e:
            self.counts['malformed'] += 1
            # Only from a client is one written down, and then sparingly:
            # anybody can send junk to the port, from any address.
            if client:
                self.drop(ip, port, '', 'not a RADIUS packet: %s' % e, client=client, sparing=True)
            else:
                self.quiet['malformed from %s' % ip] += 1
            return
        if not client:
            self.counts['unknown'] += 1
            self.drop(ip, port, pkt.text(1), 'the address %s is not one of the clients' % ip,
                      pkt=pkt, unknown=True)
            return
        secret = (client.get('_secret') or '').encode('utf-8')
        if not secret:
            self.drop(ip, port, pkt.text(1), 'the secret of the client %s cannot be opened '
                      'on this machine' % client['name'], pkt=pkt, client=client)
            return
        key = (ip, port, pkt.ident, pkt.authenticator, kind)
        window = int(CONFIG.get('radius_dup_window_s') or 0)
        if window:
            with self.seen_lock:
                got = self.seen.get(key)
                if got and arrived - got[0] < window:
                    self.counts['repeated'] += 1
                    if got[1]:
                        try:
                            sock.sendto(got[1], peer)
                        except OSError:
                            pass
                    return
                self.seen[key] = (arrived, None)
                self.seen.move_to_end(key)
                # Old ones go from the front; past the limit the oldest go
                # whatever their age - never a rebuild of the whole table.
                cut = arrived - window
                while self.seen:
                    k0, v0 = next(iter(self.seen.items()))
                    if v0[0] >= cut and len(self.seen) <= self.SEEN_MAX:
                        break
                    self.seen.popitem(last=False)
        if kind == 'acct':
            reply = self.accounting(pkt, client, ip, port, secret, arrived)
        elif pkt.code == STATUS_SERVER:
            reply = self.status(pkt, client, ip, port, secret)
        elif pkt.code == ACCESS_REQUEST:
            reply = self.access(pkt, client, ip, port, secret, arrived, sock, peer)
        else:
            self.drop(ip, port, pkt.text(1), 'a %s is not something this port answers'
                      % CODE_WORDS.get(pkt.code, 'code %d' % pkt.code), pkt=pkt, client=client)
            reply = None
        if reply and not getattr(reply, 'sent', False):
            try:
                sock.sendto(reply, peer)
            except OSError as e:
                log('the answer to %s could not be sent: %s' % (ip, e), 'warn')
        if window:
            with self.seen_lock:
                # A refusal still waiting out its delay is not handed to a
                # repeat of the request either (1.0.36): it would have skipped
                # the wait.
                if key in self.seen and not getattr(reply, 'late', False):
                    self.seen[key] = (arrived, bytes(reply) if reply else None)
        try:
            self.d.store.client_seen(client['id'])
        except Exception as e:                          # noqa: BLE001
            log('the client %s could not be marked as seen: %s' % (client['name'], e), 'warn')

    SEEN_MAX = 20000

    def sum_up(self):
        """Once a minute, what was only counted, in one line."""
        t = time.time()
        if t - self.quiet_at < 60:
            return
        with self.unknown_lock:
            if t - self.quiet_at < 60:
                return
            said, self.quiet = self.quiet, collections.Counter()
            self.quiet_at = t
            self.drops_this_minute = 0
        if said:
            top = ', '.join('%s: %d' % kv for kv in said.most_common(8))
            try:
                self.d.store.add_event('radius', 'not answered and not written down one by one '
                                       'in the last minute: %d packet(s) - %s'
                                       % (sum(said.values()), top), 'warn')
            except Exception as e:                      # noqa: BLE001
                log('could not write the minute\'s summary: %s' % e, 'warn')

    def drop(self, ip, port, user, reason, pkt=None, client=None, unknown=False,
             sparing=False):
        """A packet that is not answered: written down - for an unknown
        address only once a minute, so a VPN pointed here before it was
        added does not fill the log, and never more than 30 a minute in
        all, so a flood from made-up addresses does not either (1.0.33)."""
        self.counts['dropped'] += 1
        if unknown or sparing:
            if unknown and not CONFIG.get('radius_unknown_log', 1):
                return
            with self.unknown_lock:
                t = time.time()
                last = self.unknown_said.get(ip, 0)
                if t - last < 60 or self.drops_this_minute >= 30:
                    self.quiet[('unknown address %s' if unknown else 'dropped from %s') % ip] += 1
                    return
                self.unknown_said[ip] = t
                self.drops_this_minute += 1
                if len(self.unknown_said) > 4000:
                    # Kept to the newest addresses, so a scan of the port
                    # cannot grow this table without end.
                    newest = sorted(self.unknown_said.items(), key=lambda kv: kv[1])[-2000:]
                    self.unknown_said = dict(newest)
        self.d.store.radius_add({
            'ts': time.time(), 'client': (client or {}).get('name') or '', 'nas_ip': ip,
            'src': '%s:%d' % (ip, port), 'packet': CODE_WORDS.get(pkt.code, '?') if pkt else '?',
            'username': str(user or '')[:190], 'realm': '', 'calling': '', 'called': '',
            'result': 'drop', 'reason': reason[:500], 'otp': '', 'rid': '', 'took_ms': 0,
            'attrs': json.dumps(pkt.words() if pkt else []), 'reply': '[]',
            'steps': json.dumps([{'what': 'answered', 'ok': False, 'said': reason}]),
            'device': '', 'tunnel': ''})
        if unknown:
            self.d.store.add_event('radius', 'a request from %s, which is not a client, was '
                                   'not answered' % ip, 'warn')

    def ma_check(self, pkt, client, secret, ip, port):
        """Whether the Message-Authenticator lets this one through."""
        got = pkt.message_authenticator_ok(secret)
        if got is False:
            self.drop(ip, port, pkt.text(1), 'the Message-Authenticator is wrong: the shared '
                      'secret is not the same as on the client', pkt=pkt, client=client,
                      sparing=True)
            return False
        if got is True:
            self.ma_seen.add(client['id'])
            return True
        # None: there is none. A client that has sent one before must go on
        # sending one (1.0.33) - what is stripped off on the way, as
        # BlastRADIUS does, is refused.
        sticky = CONFIG.get('radius_ma_sticky', 1) and client['id'] in self.ma_seen
        if client.get('require_ma') or pkt.code == STATUS_SERVER or sticky:
            self.drop(ip, port, pkt.text(1), 'there is no Message-Authenticator, and this '
                      'client must send one%s' % (' - it has sent one before' if sticky and
                                                  not client.get('require_ma') else ''),
                      pkt=pkt, client=client, sparing=True)
            return False
        return True

    def status(self, pkt, client, ip, port, secret):
        if not CONFIG.get('radius_status_server', 1):
            return None
        if not self.ma_check(pkt, client, secret, ip, port):
            return None
        self.counts['status'] += 1
        return build_reply(pkt, ACCESS_ACCEPT, [attr_bytes('Reply-Message', 'otp is alive')],
                           secret, True)

    def access(self, pkt, client, ip, port, secret, arrived, sock=None, peer=None):
        if not self.ma_check(pkt, client, secret, ip, port):
            return None
        rid = '%s:%d' % (ip, port)
        user = pkt.text(1)
        try:
            password = pkt.password(secret)
        except RadiusError:
            password = None
        chap = pkt.get(3) is not None
        words = pkt.words()
        w = dict(words)
        try:
            d = self.d.auth.decide(user, password, client.get('realm') or '', src=ip, rid=rid,
                                   chap=chap, client=client)
        except Exception as e:
            # Whatever went wrong inside, the VPN gets an answer - a refusal
            # with the reason written down - rather than silence and a retry.
            log('a request for %s could not be decided: %s' % (user, e), 'error')
            d = Decision()
            d.user = str(user or '')
            d.step('the decision', False, 'it could not be made: %s' % e)
            d.refuse('the token server could not decide: %s' % str(e)[:120])
        pairs = []
        for name, value in d.reply:
            try:
                pairs.append(attr_bytes(name, value))
            except RadiusError as e:
                d.step('the answer', False, str(e))
        if d.result == 'accept':
            self.counts['accept'] += 1
            code = ACCESS_ACCEPT
        else:
            self.counts['reject'] += 1
            code = ACCESS_REJECT
            # The reason is cut by bytes, not characters, so a reason full of
            # accented letters still fits the attribute; and if the attribute
            # cannot be built for whatever reason the reject still goes out
            # without it rather than the request going unanswered and unlogged.
            pairs = []
            # The reason stays here unless asked for (1.0.33): sent back, a
            # VPN may show it to whoever is signing in - whether the name has
            # a token, whether the code was right and the password not.
            if CONFIG.get('radius_reject_reason'):
                try:
                    said = (d.reason or '').encode('utf-8')[:253].decode('utf-8', 'ignore')
                    if said:
                        pairs = [attr_bytes('Reply-Message', said)]
                except (RadiusError, ValueError) as e:
                    d.step('the answer', False, 'the reason could not be sent along: %s' % e)
                    pairs = []
        try:
            reply = build_reply(pkt, code, pairs, secret, bool(CONFIG.get('radius_reply_ma', 1)))
        except RadiusError as e:
            # Too long with what the realm and the groups add (1.0.44): a
            # refusal still goes out and is written down - never an Accept
            # without the attributes that limit what it lets in to.
            d.step('the answer', False, '%s - refused, since it cannot be sent whole' % e)
            if code == ACCESS_ACCEPT:
                self.counts['accept'] -= 1
                self.counts['reject'] += 1
                d.refuse('the answer would be longer than a RADIUS packet may be: too many '
                         'reply attributes in the realm and its groups')
                code = ACCESS_REJECT
            reply = build_reply(pkt, code, [], secret, bool(CONFIG.get('radius_reply_ma', 1)))
        took = int((time.time() - arrived) * 1000)
        # The answer goes out before anything is written down (1.0.33): a
        # database that is slow or locked delays the log, not the person -
        # and never leaves a request that was let in without its answer.
        reply = SentReply(reply)
        delay = int(CONFIG.get('radius_reject_delay_ms') or 0) if code == ACCESS_REJECT else 0
        # To the address the request came from, as it came (1.0.36): on a
        # socket listening on :: an IPv4 client is ::ffff:a.b.c.d there, and
        # the bare a.b.c.d could not be sent to - every answer was lost.
        sock = sock or self.socks.get('auth', (None, None, None))[2]
        peer = peer or (ip, port)
        if delay:
            # Waited out by one thread for all of them, not a thread each
            # (1.0.36), and not in a worker: a flood of wrong codes cannot
            # tie up the workers sleeping.
            reply.late = True
            self.later(min(delay, 10000) / 1000.0, sock, bytes(reply), peer)
        else:
            try:
                if sock is not None:
                    sock.sendto(bytes(reply), peer)
            except OSError as e:
                log('the answer to %s could not be sent: %s' % (ip, e), 'warn')
        reply.sent = True
        try:
            self.write_down(pkt, client, ip, port, rid, arrived, d, code, reply, took, words, w)
        except Exception as e:                          # noqa: BLE001
            log('the request from %s for %s could not be written down: %s'
                % (ip, d.user, e), 'error')
        return reply

    def later(self, wait, sock, data, peer):
        """An answer sent after `wait` seconds, by the one thread that sends
        the late ones. Past 10 000 waiting the newest are sent at once rather
        than kept."""
        with self.late_lock:
            if len(self.late) >= 10000:
                self.send_late(sock, data, peer)
                return
            heapq.heappush(self.late, (time.time() + wait, id(data), sock, data, peer))
            if self.late_thread is None or not self.late_thread.is_alive():
                self.late_thread = threading.Thread(target=self.send_lates, name='radius-late',
                                                    daemon=True)
                self.late_thread.start()
        self.late_wake.set()

    def send_lates(self):
        while not self.stop_flag:
            # Cleared before the queue is looked at, not after the wait: one
            # put in between would otherwise sleep a whole second.
            self.late_wake.clear()
            with self.late_lock:
                due = []
                now = time.time()
                while self.late and self.late[0][0] <= now:
                    due.append(heapq.heappop(self.late))
                wait = (self.late[0][0] - now) if self.late else 1.0
            for _t, _i, sock, data, peer in due:
                self.send_late(sock, data, peer)
            self.late_wake.wait(max(0.005, min(wait, 1.0)))

    @staticmethod
    def send_late(sock, data, peer):
        try:
            if sock is not None:
                sock.sendto(data, peer)
        except OSError:
            pass

    def write_down(self, pkt, client, ip, port, rid, arrived, d, code, reply, took, words, w):
        if d.result == 'accept' and d.token_name:
            self.d.tokens.mark_from(d.token_name, w.get('Calling-Station-Id') or ip)
        av = {}
        for name, value in words:
            if name == 'Cisco-AVPair' and '=' in value:
                k, _, v = value.partition('=')
                if k == 'mdm-tlv':
                    k, _, v = v.partition('=')
                av[k] = v
        tunnel = ''
        for name, value in words:
            if name == 'Vendor-3076-Attr-146' and value.startswith('0x'):
                try:
                    tunnel = bytes.fromhex(value[2:]).decode('ascii', 'ignore').strip('\x00')
                except ValueError:
                    pass
        reply_words = [(n, v) for n, v in Packet.parse(bytes(reply)).words()
                       if n != 'Message-Authenticator']
        self.d.store.radius_add({
            'ts': arrived, 'client': client['name'], 'nas_ip': w.get('NAS-IP-Address') or ip,
            'src': rid, 'packet': 'Access-Request',
            'username': d.user[:190] or (pkt.text(1) or '')[:190],
            'realm': d.realm, 'calling': (w.get('Calling-Station-Id') or '')[:190],
            'called': (w.get('Called-Station-Id') or '')[:190], 'result': d.result,
            'reason': d.reason[:1000], 'otp': d.otp[:190], 'rid': rid, 'took_ms': took,
            'attrs': json.dumps(words), 'reply': json.dumps(reply_words),
            'steps': json.dumps(d.steps), 'device': (av.get('computer-name') or '')[:190],
            'tunnel': tunnel[:190]})
        self.ship(pkt, words, reply_words, code, ip, port, rid, arrived)

    def accounting(self, pkt, client, ip, port, secret, arrived):
        if pkt.code == STATUS_SERVER:
            # Asked on the accounting port, answered with an
            # Accounting-Response (RFC 5997 4; 1.0.44).
            if not CONFIG.get('radius_status_server', 1):
                return None
            if not self.ma_check(pkt, client, secret, ip, port):
                return None
            self.counts['status'] += 1
            return build_reply(pkt, ACCOUNTING_RESPONSE, [], secret, True)
        if pkt.code != ACCOUNTING_REQUEST:
            self.drop(ip, port, pkt.text(1), 'only Accounting-Request is answered on this port',
                      pkt=pkt, client=client)
            return None
        if not pkt.accounting_ok(secret):
            self.drop(ip, port, pkt.text(1), 'the authenticator of the accounting request is '
                      'wrong: the shared secret is not the same as on the client', pkt=pkt,
                      client=client)
            return None
        self.counts['accounting'] += 1
        words = pkt.words()
        w = dict(words)
        self.d.store.radius_add({
            'ts': arrived, 'client': client['name'], 'nas_ip': w.get('NAS-IP-Address') or ip,
            'src': '%s:%d' % (ip, port), 'packet': 'Accounting-Request',
            'username': (w.get('User-Name') or '')[:190], 'realm': '',
            'calling': (w.get('Calling-Station-Id') or '')[:190],
            'called': (w.get('Called-Station-Id') or '')[:190], 'result': 'acct',
            'reason': (w.get('Acct-Status-Type') or '')[:100], 'otp': '', 'rid': '',
            'took_ms': int((time.time() - arrived) * 1000), 'attrs': json.dumps(words),
            'reply': '[]', 'steps': '[]', 'device': '', 'tunnel': ''})
        if self.d.shipper:
            self.d.shipper.detail_line(ip, 'detail', arrived, self.header(
                'Accounting-Request', ip, port, port_here=self.port_of('acct')) + words)
        return build_reply(pkt, ACCOUNTING_RESPONSE, [], secret, with_ma=False)

    def port_of(self, kind):
        got = self.socks.get(kind)
        return got[1] if got else 0

    @staticmethod
    def header(packet, ip, port, port_here, reply=False):
        """What FreeRADIUS writes first in a detail record under
        `log_packet_header = yes`."""
        if reply:
            return [('Packet-Type', packet), ('Packet-Dst-IP-Address', ip),
                    ('Packet-Dst-IP-Port', str(port))]
        return [('Packet-Type', packet), ('Packet-Src-IP-Address', ip),
                ('Packet-Src-IP-Port', str(port)), ('Packet-Dst-IP-Port', str(port_here))]

    def ship(self, pkt, words, reply_words, code, ip, port, rid, arrived):
        sh = self.d.shipper
        if not sh:
            return
        here = self.port_of('auth')
        ask = self.header('Access-Request', ip, port, here) + words + [('Totp-Request-Id', rid)]
        sh.detail_line(ip, 'auth-detail', arrived, ask)
        answer = self.header(CODE_WORDS[code], ip, port, here, reply=True) + reply_words + [
            ('Totp-Request-Id', rid)]
        sh.detail_line(ip, 'reply-detail', time.time(), answer)

    def state(self):
        return {'listening': self.bound, 'trouble': self.trouble, 'counts': dict(self.counts),
                'queued': self.jobs.qsize()}


# ---------------------------------------------------------------------------
# Bringing an old token server over: totpcgi and its FreeRADIUS
# ---------------------------------------------------------------------------
# The server this replaces kept a file per person (`name@realm.totp`, the
# google-authenticator format: the key, a few `" OPTION` lines, the recovery
# codes), its RADIUS clients in clients.conf, the realm a client's names
# belong to in hints, and the directory and its groups in a YAML file beside
# the Perl handler. All of it is read here so that nobody has to enrol again.

def parse_totp_file(text):
    """(secret, options, recovery codes) out of one google-authenticator file."""
    lines = [l.strip() for l in str(text or '').splitlines() if l.strip()]
    if not lines:
        raise ValueError('the file is empty')
    secret = lines[0]
    # At least 80 bits, as google-authenticator writes them (1.0.36): any
    # word at all was taken for a key, and a file of rubbish made an active
    # token with a 35-bit key.
    if len(b32_clean(secret)) < 10:
        raise ValueError('the first line is not a key of at least 16 base32 characters')
    opts, codes = {}, []
    for line in lines[1:]:
        if line.startswith('"'):
            bits = line[1:].split()
            if bits:
                opts[bits[0].upper()] = bits[1:]
        elif re.match(r'^[0-9]{6,10}$', line):
            codes.append(line)
    if 'HOTP_COUNTER' in opts:
        raise ValueError('a counter (HOTP) token, not a time one: it would not give the '
                         'same codes here')
    return re.sub(r'[\s\-=]', '', secret).upper(), opts, codes


def import_totp(store, name, text, by='import', replace=False):
    """One person's token, from the old server's file. Returns what happened."""
    secret, opts, codes = parse_totp_file(text)
    name = norm_name(name)
    if store.token(name) and not replace:
        return 'kept (there is a token for %s already)' % name
    window = -1
    if 'WINDOW_SIZE' in opts and opts['WINDOW_SIZE']:
        try:
            window = max(0, (int(opts['WINDOW_SIZE'][0]) - 1) // 2)
        except ValueError:
            window = -1
    store.token_write(name, {
        'secret': seal_secret(secret, token_bind(name)), 'digits': 6, 'period': 30,
        'algorithm': 'SHA1',
        'window_steps': window, 'state': 'active', 'last_step': 0,
        'scratch': json.dumps([scratch_hash(name, c) for c in codes]),
        'scratch_sealed': seal_codes(codes, token_bind(name)),
        'scratch_left': len(codes), 'created': time.time(), 'created_by': by,
        'activated': time.time(), 'failures': 0, 'fail_times': '[]', 'locked_until': None,
        'pending_secret': None, 'pending_scratch': None, 'pending_at': None, 'pending_by': None,
        'issuer': str(CONFIG.get('totp_issuer') or ''), 'label': name,
        'note': 'brought over from totpcgi' + ('' if 'TOTP_AUTH' in opts else
                                               ' (the file was not marked TOTP_AUTH)')})
    try:
        store.db.run('DELETE FROM meta WHERE k = ?', ('staged:' + name,))
    except Exception:                                   # noqa: BLE001
        pass
    return 'imported, %d recovery code(s)' % len(codes)


def _legacy_root(root):
    root = Path(root)
    for cand in (root, root / 'otp', root / 'otp' / 'otp'):
        if (cand / 'etc' / 'raddb').is_dir() or (cand / 'etc' / 'totpcgi').is_dir():
            return cand
    raise ValueError('%s holds no etc/raddb or etc/totpcgi' % root)


def parse_clients_conf(text):
    """FreeRADIUS clients.conf as [{name, address, secret, shortname}]."""
    out = []
    body = re.sub(r'#[^\n]*', '', str(text or ''))
    for m in re.finditer(r'client\s+(\S+)\s*\{([^}]*)\}', body):
        key, inside = m.group(1), m.group(2)
        vals = dict((a.strip().lower(), b.strip().strip('"'))
                    for a, b in re.findall(r'^\s*([A-Za-z_]+)\s*=\s*(.+?)\s*$', inside, re.M))
        addr = vals.get('ipaddr') or vals.get('ipv4addr') or key
        out.append({'name': vals.get('shortname') or key, 'address': addr,
                    'secret': vals.get('secret', ''),
                    'require_ma': 1 if vals.get('require_message_authenticator') == 'yes'
                    else 0})
    return out


def parse_hints(text):
    """The realm FreeRADIUS's hints file adds to names, by NAS address."""
    out = {}
    lines = str(text or '').splitlines()
    for i, line in enumerate(lines):
        m = re.match(r'^\s*DEFAULT\s+NAS-IP-Address\s*==\s*"?([0-9a-fA-F.:]+)"?', line)
        if not m:
            continue
        for nxt in lines[i + 1:i + 4]:
            r = re.search(r'User-Name\s*:?=\s*"%\{User-Name\}@([^"]+)"', nxt)
            if r:
                out[m.group(1)] = r.group(1)
                break
    return out


def parse_handler_yaml(text):
    """What the old Perl handler was told about the directory."""
    got = {'hosts': [], 'groups': []}
    in_list = None
    for raw in str(text or '').splitlines():
        line = raw.split('#', 1)[0].rstrip() if not raw.strip().startswith("- '") else raw
        if not line.strip():
            continue
        m = re.match(r'^(\w+)\s*:\s*(.*)$', line.strip())
        if m and not line.startswith(' '):
            k, v = m.group(1), m.group(2).strip().strip("'\"")
            in_list = k if not v else None
            got[k] = v
            continue
        m = re.match(r'^\s*-\s*[\'"]?(.*?)[\'"]?\s*$', line)
        if m and in_list:
            got.setdefault(in_list + '_list', []).append(m.group(1))
    hosts = got.get('ldaphosts_list') or []
    got['hosts'] = [re.sub(r'^ldaps?://', '', h).rstrip('/') for h in hosts]
    got['tls'] = 'ldaps' if any(h.startswith('ldaps') for h in hosts) else 'none'
    groups = []
    for f in got.get('groupSearch_list') or []:
        m = re.search(r'\(cn=([^)]+)\)', f, re.I)
        if m:
            groups.append(m.group(1))
    got['groups'] = groups
    return got


def bind_tokens(store):
    """Every token's secrets sealed again tied to its name (1.0.33), where
    they were sealed the old way, without it; then the old way is no longer
    taken for a token at all. Run at start and after a restore."""
    cols = ('secret', 'pending_secret', 'scratch_sealed', 'pending_scratch')
    done = left = 0
    try:
        rows = store.db.rows("SELECT id, name, %s FROM tokens WHERE %s"
                             % (', '.join(cols), ' OR '.join("%s LIKE 'sealed:1:%%'" % c
                                                            for c in cols)))
    except Exception as e:                              # noqa: BLE001
        log('the tokens could not be read to seal them again: %s' % e, 'warn')
        return
    for r in rows:
        fields = {}
        for c in cols:
            v = r.get(c)
            if isinstance(v, str) and v.startswith(SEALED):
                plain = unseal_secret(v)
                if plain is None:
                    left += 1
                    continue
                fields[c] = seal_secret(plain, token_bind(r['name']))
        if fields:
            # Only if still as read: the other node may have done it already.
            sets = ', '.join('%s = ?' % c for c in fields)
            conds = ' AND '.join('%s = ?' % c for c in fields)
            store.db.run('UPDATE tokens SET %s WHERE id = ? AND %s' % (sets, conds),
                         list(fields.values()) + [r['id']] + [r[c] for c in fields])
            done += 1
    if done:
        log('%d token(s) sealed again, tied to their names' % done)
    if not left:
        BIND_STRICT['tokens'] = True
    else:
        log('%d sealed value(s) of tokens do not open with this key and were left as they are'
            % left, 'warn')


def import_legacy(store, root, by='import', replace=False, say=print):
    """Everything the old server held, into this one. Returns counts."""
    base = _legacy_root(root)
    done = collections.Counter()
    raddb = base / 'etc' / 'raddb'
    hints = parse_hints((raddb / 'hints').read_text(errors='replace')) \
        if (raddb / 'hints').exists() else {}
    realms_seen = set(hints.values())
    # ---- the directory and the realm -----------------------------------
    yaml_file = raddb / 'totpcgi-handler.yaml'
    directory = ''
    if yaml_file.exists():
        y = parse_handler_yaml(yaml_file.read_text(errors='replace'))
        if y['hosts'] and y.get('userSearchBase'):
            directory = 'AD'
            if not store.directory(directory) or replace:
                old = store.directory(directory)
                store.directory_save({
                    'id': old['id'] if old else None, 'name': directory,
                    'hosts': ', '.join(y['hosts']), 'tls': y['tls'],
                    'port': 636 if y['tls'] == 'ldaps' else 389, 'verify': 1,
                    'base': y.get('userSearchBase'), 'bind_dn': y.get('bindDN', ''),
                    'bind_pw': y.get('bindPassword', ''), 'user_attr': 'sAMAccountName',
                    'nested': 0,
                    'note': 'brought over from totpcgi-handler.yaml'}, by)
                done['directories'] += 1
                say('directory %s: %s (base %s, signing in as %s). Its certificate is '
                    'checked: import the certificate authority that signed the domain '
                    'controllers’ certificates, or switch the check off.'
                    % (directory, ', '.join(y['hosts']), y.get('userSearchBase'),
                       y.get('bindDN')))
            lookup = 'upn' if 'userPrincipalName' in str(y.get('search') or
                                                          y.get('userAttribute') or '') \
                else 'sam'
            for suffix in sorted(realms_seen) or ['*']:
                if any(str(r.get('suffix')) == suffix for r in store.realms()) and not replace:
                    continue
                old = next((r for r in store.realms() if r.get('suffix') == suffix), None)
                store.realm_save({
                    'id': old['id'] if old else None, 'name': suffix if suffix != '*'
                    else 'default', 'suffix': suffix, 'directory': directory,
                    'lookup': lookup, 'auth_mode': 'otp', 'check_disabled': 1, 'nested': 0,
                    'groups': [{'group': g, 'reply': ''} for g in y['groups']],
                    'token_name': 'whole',
                    'note': 'brought over: the code alone, then the user filter and the '
                            'group filter the old handler applied'}, by)
                done['realms'] += 1
                say('realm %s: %d group(s), looked up by %s' % (suffix, len(y['groups']),
                                                                lookup))
    # ---- the clients ---------------------------------------------------------
    if (raddb / 'clients.conf').exists():
        for c in parse_clients_conf((raddb / 'clients.conf').read_text(errors='replace')):
            try:
                net = address_net(c['address'])
            except ValueError:
                say('client %s: %r is not an address, left out' % (c['name'], c['address']))
                continue
            plain = str(net.network_address) if net.num_addresses == 1 else str(net)
            realm = hints.get(plain, '')
            if plain in ('127.0.0.1', '::1') and not realm:
                realm = hints.get('127.0.0.1', '')
            name = c['name'] if c['name'] != c['address'] else (
                'localhost' if plain == '127.0.0.1' else plain)
            old = next((x for x in store.clients() if x['name'].lower() == name.lower()), None)
            if old and not replace:
                say('client %s: there is one already, left as it is' % name)
                continue
            store.client_save({'id': old['id'] if old else None, 'name': name,
                               'address': plain, 'secret': c['secret'], 'realm': realm,
                               'require_ma': c['require_ma'], 'enabled': 1,
                               'note': 'brought over from clients.conf'}, by)
            done['clients'] += 1
            say('client %s: %s%s' % (name, plain, (', names get @' + realm) if realm else ''))
    # ---- the settings ----------------------------------------------------------
    prov = base / 'etc' / 'totpcgi' / 'provisioning.conf'
    if prov.exists():
        text = prov.read_text(errors='replace')
        def ini(key):
            m = re.search(r'^\s*%s\s*=\s*(.+?)\s*$' % key, text, re.M)
            return m.group(1) if m else None
        changes = {}
        if ini('totp_issuer'):
            changes['totp_issuer'] = ini('totp_issuer')
        if ini('window_size'):
            try:
                changes['totp_window'] = max(0, (int(ini('window_size')) - 1) // 2)
            except ValueError:
                pass
        if ini('rate_limit'):
            m = re.match(r'(\d+)\s*,\s*(\d+)', ini('rate_limit'))
            if m:
                changes['rate_limit_tries'] = int(m.group(1))
                changes['rate_limit_s'] = int(m.group(2))
        if ini('scratch_tokens_n'):
            changes['scratch_count'] = int(ini('scratch_tokens_n'))
        if realms_seen:
            r = sorted(realms_seen)[0]
            changes['portal_realm'] = r
            changes['portal_hint'] = 'login@%s' % r
        for k, v in changes.items():
            store.save_setting(k, check_setting(k, v), by)
            CONFIG[k] = check_setting(k, v)
            done['settings'] += 1
        if changes:
            say('settings: %s' % ', '.join('%s=%s' % kv for kv in sorted(changes.items())))
    # ---- the tokens -------------------------------------------------------------
    for folder in (base / 'etc' / 'totpcgi' / 'totp',):
        if not folder.is_dir():
            continue
        for f in sorted(folder.glob('*.totp')):
            name = f.name[:-5]
            try:
                said = import_totp(store, name, f.read_text(errors='replace'), by, replace)
                done['tokens' if said.startswith('imported') else 'tokens_kept'] += 1
            except ValueError as e:
                say('%s: %s' % (f.name, e))
                done['tokens_bad'] += 1
    loose = sorted((base / 'etc' / 'totpcgi').glob('*.totp')) \
        if (base / 'etc' / 'totpcgi').is_dir() else []
    if loose:
        say('left alone, outside the totp folder the old server read: %s'
            % ', '.join(f.name for f in loose))
    store.add_event('import', 'brought over from %s: %s' % (
        root, ', '.join('%s %d' % kv for kv in sorted(done.items())) or 'nothing'), who=by)
    return done


# ---------------------------------------------------------------------------
# Copies of the database
# ---------------------------------------------------------------------------
def make_backup(store, why='by hand'):
    """A copy of everything into the backups folder - and the key that opens
    the tokens beside it, because one without the other is nothing."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp_ = datetime.now().strftime('%Y%m%d-%H%M%S')
    out = BACKUP_DIR / ('otp-%s.json.gz' % stamp_)
    dump_tables(store.db, out)
    os.chmod(str(out), 0o640)
    key = sealing_key()
    if key:
        write_replacing(BACKUP_DIR / ('otp-%s.key' % stamp_), key.hex() + '\n', 0o600)
    keep = int(CONFIG.get('backup_keep') or 14)
    copies = sorted(list(BACKUP_DIR.glob('otp-*.json.gz')) + list(BACKUP_DIR.glob('opt-*.json.gz')),
                    key=lambda f: f.stat().st_mtime)
    for old in copies[:-keep] if len(copies) > keep else []:
        for f in (old, old.with_name(old.name.replace('.json.gz', '.key'))):
            try:
                f.unlink()
            except OSError:
                pass
    store.add_event('backups', 'a copy of the database was made (%s): %s' % (why, out.name))
    return out


def backups():
    if not BACKUP_DIR.is_dir():
        return []
    out = []
    for f in sorted(list(BACKUP_DIR.glob('otp-*.json.gz')) + list(BACKUP_DIR.glob('opt-*.json.gz')),
                   key=lambda f: f.stat().st_mtime, reverse=True):
        st = f.stat()
        out.append({'name': f.name, 'size': st.st_size, 'at': st.st_mtime,
                    'key': f.with_name(f.name.replace('.json.gz', '.key')).exists()})
    return out


# ---------------------------------------------------------------------------
# PHP and php2shell, as the daemon can tell from outside it
# ---------------------------------------------------------------------------
# The pages say what version of PHP they run on, and a version below the
# fixed ones (8.2.35, 8.3.36, 8.4.27, 8.5.12) is "may be affected" - because a
# distribution that backported the fix keeps its old number. The packages'
# own changelog says whether the fix is in, and the daemon can read it where
# PHP cannot: so the warning on the pages goes away when the fix is there.
PHP_FIXED = {'8.2': (8, 2, 35), '8.3': (8, 3, 36), '8.4': (8, 4, 27), '8.5': (8, 5, 12)}
_PHP_STATE = {'at': 0, 'state': None}


def php_state():
    if time.time() - _PHP_STATE['at'] < 3600 and _PHP_STATE['state'] is not None:
        return _PHP_STATE['state']
    out = {'version': '', 'fixed': None, 'how': ''}
    php = shutil.which('php') or next((p for p in ('/usr/bin/php', '/usr/local/bin/php')
                                       if os.path.exists(p)), None)
    if php:
        try:
            out['version'] = subprocess.run([php, '-r', 'echo PHP_VERSION;'], capture_output=True,
                                            text=True, timeout=10).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            pass
    m = re.match(r'^(\d+)\.(\d+)\.(\d+)', out['version'])
    if m:
        v = tuple(int(x) for x in m.groups())
        want = PHP_FIXED.get('%d.%d' % v[:2])
        if want and v >= want or (not want and v[:2] > (8, 5)):
            out.update(fixed=True, how='version')
    if not out['fixed']:
        said = ''
        rpm = shutil.which('rpm')
        if rpm:
            for pkg in ('php-fpm', 'php-common'):
                try:
                    said += subprocess.run([rpm, '-q', '--changelog', pkg], capture_output=True,
                                           text=True, timeout=20).stdout
                except (OSError, subprocess.SubprocessError):
                    pass
        else:
            import gzip
            import glob
            for f in glob.glob('/usr/share/doc/php*-fpm/changelog.Debian.gz') + glob.glob(
                    '/usr/share/doc/php*-common/changelog.Debian.gz'):
                try:
                    with gzip.open(f, 'rt', errors='replace') as g:
                        said += g.read(200000)
                except OSError:
                    pass
        if 'CVE-2026-109618' in said:
            out.update(fixed=True, how='changelog')
        elif out['version']:
            out['fixed'] = False
    _PHP_STATE.update(at=time.time(), state=out)
    return out


# ---------------------------------------------------------------------------
# The daemon
# ---------------------------------------------------------------------------
class Daemon(object):
    def __init__(self, store, serve=True):
        self.store = store
        self.started = time.time()
        self.stop_flag = threading.Event()
        self.shipper = None
        self.dirs = {}
        self.reload_directories()
        self.tokens = Tokens(store)
        self.auth = Authenticator(store, self.tokens, self.dirs)
        self.radius = None
        self.api = None
        self.serial = 0
        self.conf_serial = store.get_meta('conf_serial', '0')
        self.login_fails = collections.defaultdict(list)
        if serve:
            self.shipper = Shipper()
            self.tokens.on_check = self.shipper.token_line
            store.on_event = self.shipper.event_line
            self.radius = RadiusServer(self)

    def reload_directories(self):
        self.store._dirs = None
        fresh = {}
        for row in self.store.directories(with_secret=True):
            if row.get('enabled', 1):
                fresh[row['name'].lower()] = Directory(row)
        # Swapped in whole (1.0.44): emptied and filled again, a request in
        # between found no directory at all.
        self.dirs = fresh
        if getattr(self, 'auth', None) is not None:
            self.auth.dirs = fresh

    def fill_names(self, names=None, limit=500, by='', quiet=False):
        """The name a person goes by, from the directory, for the tokens that
        have none - those brought over from totpcgi or made here, which an
        enrolment on the pages would have given one. Each token's own realm
        says which directory to ask and how to look the name up. (1.0.14)"""
        done = {'filled': 0, 'not_found': 0, 'no_directory': 0, 'trouble': 0}
        dead = set()
        if names is None:
            rows = self.store.db.rows("SELECT name FROM tokens WHERE COALESCE(display, '') = '' "
                                      "ORDER BY id LIMIT %d" % int(limit))
            names = [r['name'] for r in rows]
        for name in names:
            realm = self.store.realm_for(name)
            ad = self.dirs.get(str((realm or {}).get('directory') or '').lower())
            if not realm or not ad:
                done['no_directory'] += 1
                continue
            lookup = realm.get('lookup') or ''
            if lookup not in ('upn', 'sam'):
                lookup = 'upn' if '@' in name else 'sam'
            if ad.name in dead:
                done['trouble'] += 1
                continue
            try:
                entry = ad.find_user(name, lookup)
            except Exception:                           # noqa: BLE001
                # Not reached: the rest of its tokens are not asked of it now
                # - every one would wait out the same timeout.
                dead.add(ad.name)
                done['trouble'] += 1
                continue
            if not entry or not entry.get('display'):
                done['not_found'] += 1
                continue
            self.store.token_write(name, {'display': str(entry['display'])[:300]})
            done['filled'] += 1
        if (done['filled'] or by) and not quiet:
            self.store.add_event('tokens', 'names from the directory: %d token(s) given their '
                                 'owner\'s name, %d not found, %d with no directory, %d could not '
                                 'be asked' % (done['filled'], done['not_found'],
                                               done['no_directory'], done['trouble']),
                                 who=by or None)
        return done

    def fill_names_later(self, names=None, by=''):
        threading.Thread(target=lambda: self.fill_names(names, by=by), name='fill-names',
                         daemon=True).start()

    def reload_all(self, why=''):
        """Everything read again from the database: the settings, the
        clients, the realms, the directories."""
        load_config(saved=self.store.settings_saved())
        if not BIND_STRICT.get('tokens'):
            bind_tokens(self.store)
        self.store._clients = None
        self.store._realms = None
        self.reload_directories()
        if self.shipper:
            self.shipper.configure()
        if self.radius:
            self.radius.open_sockets()
        self.conf_serial = self.store.get_meta('conf_serial', '0')
        if why:
            log('read the configuration again (%s)' % why)

    def changed(self, what=''):
        """Something the other processes (the command line) must notice."""
        try:
            # A mark of its own, not a count: two nodes counting up at the
            # same moment would write the same number, and neither would
            # see that the other changed something. (1.0.14)
            mark = '%.6f:%s' % (time.time(), node_name())
            self.store.set_meta('conf_serial', mark)
            self.conf_serial = mark
        except Exception:
            pass
        self.store._clients = None
        self.store._realms = None
        if what in ('directories', 'all'):
            self.reload_directories()

    # ---- settings ---------------------------------------------------------------
    def cluster_nodes(self):
        try:
            return [n['name'] for n in ha_nodes(self.store)]
        except Exception:                               # noqa: BLE001
            return [node_name()]

    def save_settings(self, changes, by='', node=None):
        checked = {}
        # In a cluster a node's own settings go to that node alone (1.0.37).
        many = bool(CONFIG.get('ha_mode')) or len(self.cluster_nodes()) > 1
        node = str(node or node_name())
        if node not in self.cluster_nodes() + [node_name()]:
            raise BadSetting('there is no node %s' % node)
        for key, value in (changes or {}).items():
            if key in SECRET_KEYS and is_masked(value):
                continue
            checked[key] = check_setting(key, value)
            # A secret kept in the database is sealed with the tokens' key
            # (1.0.20): a copy of the database alone does not give it away.
            if key in SEALED_KEYS and checked[key]:
                checked[key] = seal_secret(checked[key])
        file_side = {k: v for k, v in checked.items() if k in FILE_ONLY_KEYS}
        db_side = {k: v for k, v in checked.items() if k not in FILE_ONLY_KEYS}
        saved_now = self.store.settings_saved()
        for k, v in db_side.items():
            if k in NODE_KEYS and many:
                shared = saved_now.get(k, FILE_CONFIG.get(k, DEFAULTS[k]))
                if v == shared:
                    self.store.drop_setting(k + '@' + node)
                else:
                    self.store.save_setting(k + '@' + node, v, by)
                continue
            if v == FILE_CONFIG.get(k, DEFAULTS[k]):
                self.store.drop_setting(k)
            else:
                self.store.save_setting(k, v, by)
        said = []
        if file_side:
            if any(k in DB_KEYS for k in file_side) and (
                    file_side.get('db_engine', CONFIG.get('db_engine')) != 'sqlite' or
                    CONFIG.get('db_engine') != 'sqlite'):
                test = dict(CONFIG)
                test.update(file_side)
                try:
                    probe = open_db(test)
                    probe.make_tables()
                    probe.close()
                except Exception as e:
                    raise BadSetting('the database could not be used, so nothing was '
                                     'changed: %s' % e)
            write_file_settings(file_side)
            said.append('the database settings go into %s and take effect when the service '
                        'is restarted (systemctl restart otp)' % CONFIG_FILE)
        # Who may sign in from the directory changed (1.0.33): everybody
        # signed in from it is signed out, so their role is decided again by
        # the groups as they are now - not kept until their session ends.
        if any(k in checked for k in ('admin_directory', 'admin_group_full',
                                      'admin_group_token', 'admin_group_readonly')):
            try:
                self.store.db.run(
                    "DELETE FROM sessions WHERE kind = 'admin' AND LOWER(name) IN "
                    "(SELECT LOWER(name) FROM accounts WHERE source = 'directory')")
            except Exception as e:                      # noqa: BLE001
                log('the directory sign-ins could not be ended: %s' % e, 'warn')
        if checked:
            self.store.add_event('settings', 'changed: %s' % ', '.join(
                '%s%s=%s' % (k, ('@' + node) if (k in NODE_KEYS and many) else '',
                         '***' if k in SECRET_KEYS else json.dumps(v, ensure_ascii=False))
                for k, v in sorted(checked.items())), who=by)
        self.changed('settings')
        self.reload_all()
        return {'message': ' '.join(['%d setting(s) saved.' % len(checked)] + said),
                'saved': sorted(checked)}

    def settings_state(self, may_change=True):
        out = []
        saved = self.store.settings_saved()
        written = self.store.settings_written()
        for key in DEFAULTS:
            if key in ('ha_mode', 'ha_slot', 'ha_peer', 'ha_peer_port', 'ha_address'):
                continue                    # the cluster's own wiring, set by its wizard
            value = CONFIG.get(key)
            shape = TUNABLE.get(key)
            source = 'saved' if key in saved else ('file' if key in FILE_KEYS else 'default')
            one = {'key': key, 'value': value, 'default': DEFAULTS[key],
                   'name': NAMES.get(key, key), 'says': SAYS.get(key, ''),
                   'secret': key in SECRET_KEYS, 'source': source,
                   'source_says': {'saved': 'saved on these pages',
                                   'file': 'from config.json',
                                   'default': 'the built-in default'}[source],
                   'in_file': key in FILE_KEYS,
                   'file': FILE_CONFIG.get(key) if key in FILE_KEYS else None,
                   'file_only': key in FILE_ONLY_KEYS,
                   'node_key': key in NODE_KEYS}
            if key in NODE_KEYS:
                one['per_node'] = {k.split('@', 1)[1]: v for k, v in saved.items()
                                   if k.startswith(key + '@')}
                one['shared'] = saved.get(key, FILE_CONFIG.get(key, DEFAULTS[key]))
                if key + '@' + node_name() in saved:
                    one['source'], one['source_says'] = 'node', 'saved for this node'
            if key in written:
                one['saved_at'] = written[key]['at']
                one['saved_by'] = written[key]['by']
            if key in SECRET_KEYS:
                plain = unseal_secret(value) if key in SEALED_KEYS else value
                one['value'] = secret_shown(plain or '') if may_change else ''
                one['set'] = bool(value)
                one['file'] = None
            if isinstance(shape, tuple) and shape and isinstance(shape[0], str):
                one['choices'] = list(shape)
                if key in CHOICE_WORDS:
                    one['choice_words'] = CHOICE_WORDS[key]
            elif isinstance(shape, tuple):
                one['min'], one['max'] = shape
            out.append(one)
        return out

    # ---- what it is doing ------------------------------------------------------
    def status(self):
        c = self.store.token_counts()
        last = self.store.db.row("SELECT ts, result, username FROM radius_log WHERE packet = "
                                 "'Access-Request' ORDER BY ts DESC LIMIT 1")
        day = time.time() - 86400
        acc = int(self.store.db.value("SELECT COUNT(*) AS n FROM radius_log WHERE ts >= ? AND "
                                      "result = 'accept'", (day,), 0) or 0)
        rej = int(self.store.db.value("SELECT COUNT(*) AS n FROM radius_log WHERE ts >= ? AND "
                                      "result IN ('reject', 'drop')", (day,), 0) or 0)
        serial = self.store.db.value('SELECT MAX(id) AS n FROM radius_log', (), 0) or 0
        ev = self.store.db.value('SELECT MAX(id) AS n FROM events', (), 0) or 0
        r = self.radius.state() if self.radius else {}
        problems = []
        if self.radius and self.radius.trouble:
            problems.append(self.radius.trouble)
        if self.radius and not self.radius.bound:
            problems.append('the RADIUS server is not listening')
        sh = self.shipper.state() if self.shipper else {}
        if sh.get('on') and not sh.get('targets'):
            problems.append('sending to isemon is on and nowhere to send to is set')
        if sh.get('trouble'):
            problems.extend('isemon %s: %s' % kv for kv in sorted(sh['trouble'].items()))
        lost = int(self.store.db.value('SELECT COUNT(*) AS n FROM tokens', (), 0) or 0) and \
            not sealing_key()
        if lost:
            problems.append('the key that opens the tokens (%s) is missing: no code can be '
                            'checked' % sealing_key_path())
        if not self.store.clients():
            problems.append('there is no RADIUS client yet: nobody can ask this server')
        if not self.store.realms():
            problems.append('there is no realm yet: every request is refused')
        return {
            'ok': True, 'version': __version__, 'site': CONFIG.get('site_name') or short_host(),
            'host': socket.gethostname(), 'started': self.started,
            'uptime': time.time() - self.started, 'now': time.time(),
            'radius': r, 'isemon': sh, 'tokens': c,
            'clients': len(self.store.clients()), 'realms': len(self.store.realms()),
            'directories': len(self.dirs),
            'day': {'accept': acc, 'reject': rej},
            'last': last, 'serial': '%s/%s' % (serial, ev), 'problems': problems,
            'database': {'engine': self.store.db.engine, 'where': self.store.db.where()},
            'lang': CONFIG.get('ui_lang') or 'cs', 'php': php_state(), 'admin_show_key': bool(CONFIG.get('admin_show_key')),
            'default_realm': CONFIG.get('default_realm') or '',
            'node': node_name(),
            'nodes': [{'name': n['name'], 'alive': n['alive'], 'age': n['age'],
                       'version': n.get('version')} for n in ha_nodes(self.store)],
            'realm_suffixes': sorted(set(r['suffix'] for r in self.store.realms()
                                         if r.get('suffix') and r['suffix'] != '*')),
            # The overview's second row of cards (1.0.37): this server, the
            # cluster, the database, maintenance.
            'maintenance': maintenance_now(self.store),
            'maint_nodes': [n['name'] for n in ha_nodes(self.store)
                            if n.get('alive') and maintenance_row(self.store, n['name']).get('on')],
            'replication': self._repl_summary(),
            'db': self._db_summary(),
            'upgrade': self._upgrade_summary(),
        }

    def _repl_summary(self):
        if CONFIG.get('ha_mode') != 'replicated':
            return {'mode': CONFIG.get('ha_mode') or ''}
        try:
            r = ha_repl_state(self.store)
            return {'mode': 'replicated', 'healthy': bool(r.get('healthy')),
                    'lost': bool(r.get('lost')), 'trouble': r.get('trouble') or '',
                    'behind': max([int(x.get('behind') or 0) for x in r.get('outgoing') or []]
                                  or [0])}
        except Exception as e:                          # noqa: BLE001
            return {'mode': 'replicated', 'healthy': False, 'trouble': str(e)[:200]}

    DB_SUMMARY = {'at': 0, 'got': {}}

    def _db_summary(self):
        if time.time() - self.DB_SUMMARY['at'] > 60:
            got = {'engine': self.store.db.engine, 'where': self.store.db.where()}
            try:
                got['size'] = self.store.db.size()
            except Exception:                           # noqa: BLE001
                got['size'] = None
            try:
                kept = backups()
                got['backups'] = len(kept)
                got['last_backup'] = max([float(b.get('at') or b.get('mtime') or 0)
                                          for b in kept] or [0]) or None
            except Exception:                           # noqa: BLE001
                pass
            got['key_there'] = bool(sealing_key())
            self.DB_SUMMARY.update(at=time.time(), got=got)
        return self.DB_SUMMARY['got']

    def _upgrade_summary(self):
        try:
            plan = upgrade_plan(self.store)
            pkg = json.loads(self.store.get_meta('upgrade:pkg') or 'null')
        except Exception:                               # noqa: BLE001
            return {}
        return {'plan': {'state': plan['state'], 'version': plan['version']} if plan else None,
                'package': pkg['version'] if pkg else None}

    # ---- running -------------------------------------------------------------------
    def run(self):
        log('otp %s starting: the database is %s' % (__version__, self.store.db.where()))
        if not sealing_key():
            # A database that already holds sealed secrets gets no new key in
            # place of a missing one (1.0.33): the secrets would stay lost, and
            # on two nodes each would seal with a key of its own.
            held = 0
            try:
                held = int(self.store.db.value(
                    "SELECT COUNT(*) FROM tokens WHERE secret LIKE 'sealed:%'", (), 0) or 0)
            except Exception:                           # noqa: BLE001
                pass
            if held:
                log('%s is missing, and the database holds %d token(s) sealed with it: no new '
                    'key is made. Put the key back (it is beside every backup), or the tokens '
                    'cannot be opened.' % (sealing_key_path(), held), 'error')
                self.store.add_event('starting and stopping', 'the key that opens the tokens '
                                     'is missing: %s' % sealing_key_path(), 'bad')
            else:
                sealing_key(make=True)
        else:
            bind_tokens(self.store)
        self.radius.start()
        self.api = ApiServer(self)
        self.api.start()
        HA_STORE['store'] = self.store
        node_name_check(self.store)             # renamed since the last start? (1.0.48)
        self.store.add_event('starting and stopping', 'otp %s started on %s, RADIUS on %s'
                             % (__version__, node_name(),
                                ', '.join(self.radius.bound) or 'nothing'))
        try:
            heartbeat(self.store, self)
        except Exception as e:                          # noqa: BLE001
            log('the heartbeat could not be written: %s' % e, 'warn')
        last_beat = time.time()
        maintenance_ensure(self.store)
        # Tests the other node's pages ask of this one (1.0.45): looked for
        # every half second, only while this node is one of a cluster.
        def tests_for_me():
            while not self.stop_flag.wait(0.5):
                if not CONFIG.get('ha_mode') or HA_REBUILDING.is_set():
                    continue
                try:
                    radtest_serve(self)
                except Exception as e:                  # noqa: BLE001
                    log('a test asked by the other node: %s' % e, 'warn')
                    self.stop_flag.wait(5)
        threading.Thread(target=tests_for_me, name='tests-for-me', daemon=True).start()
        # The cluster's web address: whether this node may hold it (1.0.47).
        threading.Thread(target=vip_watch, args=(self,), name='vip-watch', daemon=True).start()
        try:
            upgrade_tick(self)
        except Exception as e:                          # noqa: BLE001
            log('the upgrade: %s' % e, 'warn')
        signal.signal(signal.SIGTERM, lambda *_: self.stop_flag.set())
        signal.signal(signal.SIGINT, lambda *_: self.stop_flag.set())
        signal.signal(signal.SIGHUP, lambda *_: self._hup())
        last_tidy = 0
        last_backup_day = self.store.get_meta('backup_day', '')
        while not self.stop_flag.wait(5):
            if HA_REBUILDING.is_set():
                continue                # nothing of its own written meanwhile (1.0.44)
            try:
                if time.time() - last_beat >= HEARTBEAT_S:
                    last_beat = time.time()
                    heartbeat(self.store, self)
                if self.store.get_meta('conf_serial', '0') != self.conf_serial:
                    self.reload_all('changed elsewhere')
                try:
                    upgrade_tick(self)
                except Exception as e:                  # noqa: BLE001
                    log('the upgrade: %s' % e, 'warn')
                try:
                    web_tick(self.store)
                except Exception as e:                  # noqa: BLE001
                    log('TLS and the web address: %s' % e, 'warn')
                try:
                    ha_watch_tick(self.store)
                except Exception as e:                  # noqa: BLE001
                    log('the cluster\'s history: %s' % e, 'warn')
                if time.time() - last_tidy > 3600:
                    last_tidy = time.time()
                    try:
                        self.fill_names(limit=100)
                    except Exception as e:              # noqa: BLE001
                        log('names from the directory: %s' % e, 'warn')
                    gone = self.store.tidy()
                    if any(gone.values()):
                        log('tidied: %s' % gone)
                if CONFIG.get('backup_daily'):
                    today = datetime.now().strftime('%Y-%m-%d')
                    # 3:30 is 03:30 (1.0.44): compared as numbers, not as text.
                    try:
                        hh, mm = (int(x) for x in str(CONFIG.get('backup_at') or '03:30')
                                  .strip().split(':', 1))
                    except ValueError:
                        hh, mm = 3, 30
                    nw = datetime.now()
                    if today != last_backup_day and (nw.hour, nw.minute) >= (hh, mm):
                        last_backup_day = today
                        # One node of a cluster makes it: the one whose
                        # conditional UPDATE took the day. (1.0.13)
                        mine = claim_once(self.store, 'backup_day' + (
                            ':' + node_name() if CONFIG.get('ha_mode') == 'replicated' else ''),
                            today)
                    else:
                        mine = False
                    if mine:
                        try:
                            # As isemon's: the engine's own dump every night,
                            # or a portable copy where its program is missing.
                            make_dump(self.store, 'daily')
                        except Exception as e:
                            self.store.add_event('backups', 'the daily dump failed: %s' % e,
                                                 'bad')
                        try:
                            note_size(self.store)
                        except Exception:               # noqa: BLE001
                            pass
            except Exception as e:
                log('housekeeping broke: %s\n%s' % (e, traceback.format_exc()), 'error')
        self.store.add_event('starting and stopping', 'otp stopped on %s' % node_name())
        self.radius.stop()
        if self.shipper:
            self.shipper.flush()
        if self.api:
            self.api.stop()

    def _hup(self):
        log_open()
        try:
            self.reload_all('SIGHUP')
        except Exception as e:
            log('reading the configuration again failed: %s' % e, 'error')


# ---------------------------------------------------------------------------
# Moving to another database, looking after the one in use, tuning its
# server - the database page, as isemon has it
# ---------------------------------------------------------------------------
ENGINE_WORDS = {'sqlite': 'the file on this machine (SQLite)', 'mariadb': 'MariaDB',
                'postgres': 'PostgreSQL'}
DB_KEYS = ('db_engine', 'db_host', 'db_port', 'db_name', 'db_user', 'db_password',
           'db_timeout_s')
DB_IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_]{0,62}$')


def file_db_settings():
    """The database settings as config.json has them now - Set it up writes
    the address and the password made there while the old database is
    still the one in use, and the steps after it must find them (1.0.37)."""
    try:
        with open(str(CONFIG_FILE), encoding='utf-8') as f:
            got = json.load(f)
        return {k: got[k] for k in DB_KEYS if k in got} if isinstance(got, dict) else {}
    except (OSError, ValueError):
        return {}


def engine_asked(given):
    """The database the page means: what it typed, over what is set."""
    c = {k: CONFIG.get(k) for k in DB_KEYS}
    on_file = file_db_settings()
    for k, v in on_file.items():
        if k != 'db_engine':
            c[k] = v
    for k, v in (given or {}).items():
        if k not in DB_KEYS or v is None:
            continue
        if k == 'db_password' and is_masked(v):
            continue
        c[k] = v
    if c.get('db_engine') not in ('sqlite', 'mariadb', 'postgres'):
        raise ValueError('the engine is sqlite, mariadb or postgres')
    for k in ('db_name', 'db_user'):
        if c['db_engine'] != 'sqlite' and not DB_IDENT.match(str(c.get(k) or '')):
            raise ValueError('%s is letters, digits and _ only, starting with a letter' % k)
    return c


def db_open(c):
    return Db(c.get('db_engine') or 'sqlite', c.get('db_host') or '', c.get('db_port') or 0,
              c.get('db_name') or 'otp', c.get('db_user') or 'otp', c.get('db_password') or '',
              c.get('db_timeout_s') or 10,
              tls=c.get('db_tls') if 'db_tls' in c else CONFIG.get('db_tls'),
              tls_ca=c.get('db_tls_ca') if 'db_tls_ca' in c else CONFIG.get('db_tls_ca'))


def same_database(c, db):
    """Whether the page's database is the one in use."""
    if c.get('db_engine') != db.engine:
        return False
    if db.engine == 'sqlite':
        return True
    port = int(c.get('db_port') or {'mariadb': 3306, 'postgres': 5432}[db.engine])
    here = {'', 'localhost', '127.0.0.1', '::1'}
    a, b = str(c.get('db_host') or '').lower(), str(db.host or '').lower()
    return ((a == b or (a in here and b in here)) and port == int(db.port or port)
            and str(c.get('db_name')) == str(db.name))


def db_try(c):
    """Reach a database as this program would. Never raises."""
    out = {'reached': False, 'engine': c.get('db_engine'),
           'words': ENGINE_WORDS.get(c.get('db_engine'), c.get('db_engine'))}
    try:
        db = db_open(c)
    except Exception as e:
        out['trouble'] = str(e).split('\n')[0][:300]
        return out
    try:
        out['reached'] = True
        out['where'] = db.where()
        out['version'] = db.version()
        names = db.tables()
        ours = [t for t in TABLES if t in names]
        out['tables'] = ours
        out['rows'] = sum(int(db.value('SELECT COUNT(*) FROM %s' % t) or 0)
                          for t in ours if t not in ('meta',))
        try:
            db.run('CREATE TABLE otp_probe (x INTEGER)')
            db.run('DROP TABLE otp_probe')
            out['writable'] = True
        except Exception as e:
            out['writable'] = False
            out['trouble'] = 'it answers, but this account may not make a table: %s' % (
                str(e).split('\n')[0][:200])
    except Exception as e:
        out['trouble'] = str(e).split('\n')[0][:300]
    finally:
        db.close()
    return out


def db_password_made():
    alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    return ''.join(secrets.choice(alphabet) for _ in range(24))


def db_make(c, admin_user, admin_password):
    """The database and its account, made by an administrator of that
    server who is used for this one connection and kept nowhere."""
    eng = c['db_engine']
    host = str(c.get('db_host') or '127.0.0.1')
    port = int(c.get('db_port') or {'mariadb': 3306, 'postgres': 5432}[eng])
    name, user, pw = c['db_name'], c['db_user'], c['db_password']
    done = []
    if eng == 'mariadb':
        import pymysql
        conn = pymysql.connect(host=host, port=port, user=admin_user, password=admin_password,
                               connect_timeout=int(c.get('db_timeout_s') or 10), autocommit=True)
        try:
            cur = conn.cursor()
            cur.execute('CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 '
                        'COLLATE utf8mb4_unicode_ci' % name)
            done.append('the database %s' % name)
            local = host in ('localhost', '127.0.0.1', '::1')
            for at in (('localhost', '127.0.0.1') if local else ('%',)):
                cur.execute("CREATE USER IF NOT EXISTS %s@%s IDENTIFIED BY %s", (user, at, pw))
                cur.execute("ALTER USER %s@%s IDENTIFIED BY %s", (user, at, pw))
                cur.execute('GRANT ALL PRIVILEGES ON `%s`.* TO %%s@%%s' % name, (user, at))
                done.append("the account '%s'@'%s', with every right on %s and none elsewhere"
                            % (user, at, name))
            cur.execute('FLUSH PRIVILEGES')
        finally:
            conn.close()
        return done
    import psycopg2
    conn = psycopg2.connect(host=host, port=port, user=admin_user, password=admin_password,
                            dbname='postgres', connect_timeout=int(c.get('db_timeout_s') or 10))
    conn.autocommit = True
    try:
        cur = conn.cursor()
        cur.execute('SELECT 1 FROM pg_roles WHERE rolname = %s', (user,))
        if cur.fetchone():
            cur.execute('ALTER ROLE "%s" WITH LOGIN PASSWORD %%s' % user, (pw,))
            done.append('the account %s was there; its password is new' % user)
        else:
            cur.execute('CREATE ROLE "%s" WITH LOGIN PASSWORD %%s' % user, (pw,))
            done.append('the account %s' % user)
        cur.execute('SELECT 1 FROM pg_database WHERE datname = %s', (name,))
        if cur.fetchone():
            cur.execute('ALTER DATABASE "%s" OWNER TO "%s"' % (name, user))
            done.append('the database %s was there; %s owns it now' % (name, user))
        else:
            cur.execute("CREATE DATABASE \"%s\" OWNER \"%s\" ENCODING 'UTF8' TEMPLATE template0"
                        % (name, user))
            done.append('the database %s, owned by %s' % (name, user))
    finally:
        conn.close()
    conn = psycopg2.connect(host=host, port=port, user=admin_user, password=admin_password,
                            dbname=name, connect_timeout=int(c.get('db_timeout_s') or 10))
    conn.autocommit = True
    try:
        conn.cursor().execute('GRANT ALL ON SCHEMA public TO "%s"' % user)
    except Exception:
        pass
    finally:
        conn.close()
    return done


def db_empty(c):
    db = db_open(c)
    try:
        gone = []
        for t in reversed(TABLES):
            if t in db.tables():
                db.run('DROP TABLE %s' % t)
                gone.append(t)
        return gone
    finally:
        db.close()


# ---- one long job at a time, which the page asks after ---------------------
DB_JOB = {'id': 0, 'what': '', 'running': False, 'done': 0, 'whole': 0, 'says': '',
          'error': '', 'result': None, 'began': 0, 'ended': 0}
DB_JOB_LOCK = threading.Lock()


def db_job(what, work):
    with DB_JOB_LOCK:
        if DB_JOB['running']:
            raise ValueError('%s is going on already' % DB_JOB['what'])
        DB_JOB.update({'id': DB_JOB['id'] + 1, 'what': what, 'running': True, 'done': 0,
                       'whole': 0, 'says': '', 'error': '', 'result': None,
                       'began': time.time(), 'ended': 0})

    def progress(done, whole, says):
        DB_JOB.update({'done': done, 'whole': whole, 'says': says})
        if time.time() - DB_JOB.get('_pub', 0) > 1:
            DB_JOB['_pub'] = time.time()
            job_publish({k: v for k, v in DB_JOB.items() if not k.startswith('_')})

    def run():
        try:
            DB_JOB['result'] = work(progress)
        except Exception as e:
            DB_JOB['error'] = scrub_secret(str(e).split('\n')[0][:400])
            log('%s failed: %s' % (what, scrub_secret(e)), 'error')
        finally:
            DB_JOB.update({'running': False, 'ended': time.time()})
            job_publish({k: v for k, v in DB_JOB.items() if not k.startswith('_')})

    def beat():
        # Said again every half minute, so the other node - or this one,
        # after a restart - can tell a job going on from one that died.
        while DB_JOB.get('running'):
            time.sleep(30)
            if DB_JOB.get('running'):
                job_publish({k: v for k, v in DB_JOB.items() if not k.startswith('_')})

    threading.Thread(target=run, name='db-job', daemon=True).start()
    threading.Thread(target=beat, name='db-job-beat', daemon=True).start()
    return dict(DB_JOB)


def db_move(store, c, by):
    """Everything here into the other database, through a copy."""
    def work(progress):
        progress(0, 0, 'making a copy of what is here')
        before = store.counts()
        copy = make_backup(store, 'before moving, by %s' % by)
        whole = sum(before.values())
        far = db_open(c)
        tally = {}
        try:
            def along(table, done):
                tally[table] = done
                progress(sum(tally.values()), whole, '%s: %s' % (table, done))
            load_tables(far, copy, say=along)
            after = {t: int(far.value('SELECT COUNT(*) FROM %s' % t) or 0)
                     for t in TABLES if t != 'meta'}
        finally:
            far.close()
        short = {t: (before.get(t, 0), after.get(t, 0)) for t in after
                 if after.get(t, 0) < before.get(t, 0) and t not in ('sessions',)}
        store.add_event('settings', 'everything was carried into %s (%s), by %s'
                        % (ENGINE_WORDS.get(c['db_engine']), db_where(c), by), who=by)
        progress(whole, whole, 'done')
        return {'copy': copy.name, 'rows': sum(after.values()), 'short': short,
                'where': db_where(c)}
    return db_job('carrying everything across', work)


def db_where(c):
    if c.get('db_engine') == 'sqlite':
        return str(DB_FILE)
    return '%s@%s:%s/%s' % (c.get('db_user'), c.get('db_host') or 'localhost',
                            c.get('db_port') or {'mariadb': 3306, 'postgres': 5432}
                            [c['db_engine']], c.get('db_name'))


# ---- looking after the one in use --------------------------------------------
def db_table_sizes(db):
    """Rows and bytes of every table, as far as the engine says."""
    out = []
    sizes = {}
    try:
        if db.engine == 'mariadb':
            for r in db.rows('SELECT TABLE_NAME AS t, DATA_LENGTH + INDEX_LENGTH AS b, '
                             'DATA_FREE AS f FROM information_schema.TABLES '
                             'WHERE TABLE_SCHEMA = DATABASE()'):
                sizes[r['t']] = (int(r['b'] or 0), int(r['f'] or 0))
        elif db.engine == 'postgres':
            for t in TABLES:
                sizes[t] = (int(db.value('SELECT pg_total_relation_size(?)', (t,)) or 0), 0)
        else:
            try:
                for r in db.rows('SELECT name AS t, SUM(pgsize) AS b FROM dbstat GROUP BY name'):
                    sizes[r['t']] = (int(r['b'] or 0), 0)
            except Exception:
                pass
    except Exception:
        pass
    for t in TABLES:
        try:
            n = int(db.value('SELECT COUNT(*) FROM %s' % t) or 0)
        except Exception:
            n = 0
        b, free = sizes.get(t, (None, 0))
        out.append({'table': t, 'rows': n, 'bytes': b, 'free': free})
    return out


def db_free_inside(db):
    """Room the engine holds that it would give back to the disk."""
    try:
        if db.engine == 'sqlite':
            pages = int(db.value('PRAGMA freelist_count') or 0)
            return pages * int(db.value('PRAGMA page_size') or 4096)
        if db.engine == 'mariadb':
            return int(db.value('SELECT SUM(DATA_FREE) FROM information_schema.TABLES '
                                'WHERE TABLE_SCHEMA = DATABASE()') or 0)
        return int(db.value('SELECT COALESCE(SUM(n_dead_tup), 0) FROM pg_stat_user_tables') or 0)
    except Exception:
        return 0


def db_check(db):
    """Read the database through and say whether anything is broken."""
    said = []
    if db.engine == 'sqlite':
        got = [r for r in db.rows('PRAGMA integrity_check')]
        words = [list(r.values())[0] for r in got]
        return {'ok': words == ['ok'], 'said': words[:20]}
    if db.engine == 'mariadb':
        ok = True
        for t in TABLES:
            for r in db.rows('CHECK TABLE %s' % t):
                v = {k.lower(): x for k, x in r.items()}
                if str(v.get('msg_type')).lower() in ('error', 'warning') or \
                        str(v.get('msg_text')).lower() not in ('ok', 'table is already up to date'):
                    ok = False
                    said.append('%s: %s' % (t, v.get('msg_text')))
        return {'ok': ok, 'said': said or ['every table: OK']}
    ok = True
    for t in TABLES:
        try:
            n = db.value('SELECT COUNT(*) FROM %s' % t)
            said.append('%s: %s row(s) read' % (t, n))
        except Exception as e:
            ok = False
            said.append('%s: %s' % (t, str(e).split('\n')[0]))
    return {'ok': ok, 'said': said}


def db_statistics(db):
    """Fresh statistics for the planner - quick, nothing is locked."""
    if db.engine == 'sqlite':
        db.run('ANALYZE')
        db.run('PRAGMA optimize')
    elif db.engine == 'mariadb':
        for t in TABLES:
            db.rows('ANALYZE TABLE %s' % t)
    else:
        db.run('ANALYZE')
    return 'the statistics of every table are fresh'


def db_give_back(store, progress):
    """Give the room deleted rows left back to the disk: VACUUM, OPTIMIZE
    TABLE, VACUUM FULL. Each holds a table shut while it works."""
    db = store.db
    before = db.size()
    if db.engine == 'sqlite':
        progress(0, 1, 'VACUUM')
        db.run('PRAGMA wal_checkpoint(TRUNCATE)')
        db.run('VACUUM')
        db.run('PRAGMA wal_checkpoint(TRUNCATE)')
    else:
        for i, t in enumerate(TABLES):
            progress(i, len(TABLES), t)
            if db.engine == 'mariadb':
                db.rows('OPTIMIZE TABLE %s' % t)
            else:
                db.run('VACUUM (FULL, ANALYZE) %s' % t)
    after = db.size()
    progress(1, 1, 'done')
    return {'before': before, 'after': after}


def db_prune(store, days):
    """Forget the requests and the checks of a code older than `days`."""
    edge = time.time() - int(days) * 86400 if int(days) > 0 else time.time() + 86400
    gone = {}
    for t in ('radius_log', 'otp_log'):
        gone[t] = store.db.run('DELETE FROM %s WHERE ts < ?' % t, (edge,))
    return gone


# ---- the server's own settings, for its machine (isemon's DbTune, smaller) --
def tune_machine(c, typed):
    """What the database server's machine has: read here when it is this
    machine, typed on the page when it is not."""
    host = str(c.get('db_host') or '').lower()
    local = host in ('', 'localhost', '127.0.0.1', '::1') or host == socket.gethostname().lower()
    facts = {'local': local, 'ram_gb': None, 'cpus': None, 'disk': None, 'avail': None,
             'ram': None, 'virtual': None, 'rotational': None,
             'source': 'this machine' if local else ''}
    if local:
        try:
            with open('/proc/meminfo') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        facts['ram'] = int(line.split()[1]) * 1024
                    elif line.startswith('MemAvailable:'):
                        facts['avail'] = int(line.split()[1]) * 1024
            if facts['ram']:
                facts['ram_gb'] = round(facts['ram'] / 1073741824.0, 1)
        except OSError:
            pass
        facts['cpus'] = os.cpu_count()
        try:
            with open('/proc/cpuinfo') as f:
                facts['virtual'] = ' hypervisor' in f.read()
        except OSError:
            pass
        try:
            rot = [open(p).read().strip() for p in
                   [str(x) for x in Path('/sys/block').glob('*/queue/rotational')]
                   if not re.search(r'/(loop|ram|zram|sr|dm-)\d', p)]
            if rot:
                facts['rotational'] = all(r == '1' for r in rot)
        except OSError:
            pass
    for k in ('ram_gb', 'cpus'):
        if typed.get(k) not in (None, ''):
            try:
                v = float(str(typed[k]).replace(',', '.')) if k == 'ram_gb' else int(typed[k])
            except ValueError:
                raise ValueError('the memory is a number of GB, the processors a whole number')
            if k == 'ram_gb' and facts['ram_gb'] and abs(v - facts['ram_gb']) > 0.05 * v:
                facts['source'] = 'typed' if not local else facts['source']
            if k == 'cpus' and v != facts['cpus'] and not local:
                facts['source'] = 'typed'
            facts[k] = v
            if k == 'ram_gb':
                facts['ram'] = int(v * 1073741824)
    return facts


def tune_commit_ms(db):
    """How long the server takes to make one small write safe: the middle of
    twenty, each its own transaction, less a round trip."""
    if db.engine == 'sqlite':
        return None
    took, trip = [], []
    try:
        # The row is there to be written (1.0.44): an UPDATE of nothing
        # commits nothing and every disk looked fast.
        db.run('DELETE FROM meta WHERE k = ?', ('tune_probe',))
        db.run('INSERT INTO meta (k, v) VALUES (?, ?)', ('tune_probe', '0'))
        for _ in range(5):
            t = time.perf_counter()
            db.value('SELECT 1')
            trip.append(time.perf_counter() - t)
        for i in range(20):
            t = time.perf_counter()
            db.run('UPDATE meta SET v = ? WHERE k = ?', (str(i), 'tune_probe'))
            took.append(time.perf_counter() - t)
        db.run('DELETE FROM meta WHERE k = ?', ('tune_probe',))
    except Exception:                                   # noqa: BLE001
        return None
    took.sort()
    trip.sort()
    return max(0.0, (took[len(took) // 2] - trip[len(trip) // 2]) * 1000.0)


def tune_disk_guess(facts, commit_ms):
    """As isemon's: what the disk says of itself first - except in a virtual
    machine, where a disk says it spins whatever it is on - then how long a
    small write takes to be made safe."""
    rot = facts.get('rotational')
    if rot is False:
        return 'ssd', 'the disk says it does not spin'
    if rot is True and not facts.get('virtual'):
        return 'hdd', 'the disk says it spins'
    if commit_ms is not None:
        if commit_ms < 2.5:
            return 'ssd', 'a write is made safe in %.1f ms, which is an SSD' % commit_ms
        if commit_ms > 6:
            return 'hdd', 'a write is made safe in %.1f ms, which is a disk that spins' % commit_ms
    return 'ssd', ('not known for certain - most servers are on SSDs now; choose the other if '
                   'this one is not')


def _mb(n):
    n = int(n)
    return '%dGB' % (n // 1024) if n >= 1024 and n % 1024 == 0 else '%dMB' % n


def tune_plan(engine, m):
    """name -> (value, why, needs_restart)"""
    ram = int((m.get('ram_gb') or 4) * 1024)
    cpus = max(1, int(m.get('cpus') or 2))
    ssd = (m.get('disk') or 'ssd') == 'ssd'
    # Shared with otp itself (and nginx, PHP) when it is this machine.
    share = 0.8 if m.get('local') else 1.0
    if engine == 'postgres':
        sb = max(128, min(int(ram * share / 4), 16384))
        return {
            'shared_buffers': (_mb(sb), 'a quarter of the memory: the server’s own cache', True),
            'effective_cache_size': (_mb(int(ram * share * 3 / 4)),
                                     'how much the planner may assume is cached', False),
            'maintenance_work_mem': (_mb(max(64, min(ram // 16, 2048))),
                                     'for VACUUM and building indexes', False),
            'work_mem': (_mb(max(4, min(ram // 256, 64))), 'for each sort and hash', False),
            'wal_buffers': ('16MB', 'the write-ahead log’s buffer', True),
            'max_wal_size': ('4GB' if ssd else '2GB', 'fewer checkpoints under load', False),
            'min_wal_size': ('1GB', 'kept between checkpoints', False),
            'checkpoint_completion_target': ('0.9', 'checkpoints spread out', False),
            'random_page_cost': ('1.1' if ssd else '4', 'an SSD reads anywhere as fast', False),
            'effective_io_concurrency': ('200' if ssd else '2', 'reads the disk takes at once', False),
            'max_worker_processes': (str(max(8, cpus)), 'one per processor', True),
            'max_parallel_workers': (str(cpus), 'parallel queries over every processor', False),
            'max_parallel_workers_per_gather': (str(max(1, min(4, cpus // 2))),
                                                'per query', False),
        }
    pool = max(128, int(ram * share * (0.5 if m.get('local') else 0.7)) // 128 * 128)
    return {
        'innodb_buffer_pool_size': (str(pool * 1048576), 'the server’s own cache: %s'
                                    % _mb(pool), False),
        'innodb_log_file_size': (str(min(pool // 4, 2048) * 1048576),
                                 'a log large enough for a busy hour', True),
        'innodb_flush_method': ('O_DIRECT', 'no second copy in the system’s cache', True),
        'innodb_io_capacity': ('2000' if ssd else '200', 'what the disk takes per second', False),
        'innodb_io_capacity_max': ('4000' if ssd else '400', '...at most', False),
        'innodb_flush_neighbors': ('0' if ssd else '1', 'an SSD has no neighbours', False),
        'tmp_table_size': (str(64 * 1048576), 'in-memory temporary tables', False),
        'max_heap_table_size': (str(64 * 1048576), '...the same', False),
        'table_open_cache': ('2000', 'tables kept open', False),
    }


def tune_current(db, names):
    out = {}
    for n in names:
        try:
            if db.engine == 'postgres':
                out[n] = str(db.value('SHOW %s' % n))
            else:
                r = db.row("SHOW GLOBAL VARIABLES LIKE ?", (n,))
                out[n] = str(list(r.values())[1]) if r else ''
        except Exception:
            out[n] = ''
    return out


def tune_same(engine, a, b):
    def norm(v):
        v = str(v).strip()
        m = re.match(r'^(\d+(?:\.\d+)?)\s*(kB|MB|GB|TB)?$', v, re.I)
        if not m:
            return v.lower()
        mult = {'kb': 1, 'mb': 1024, 'gb': 1048576, 'tb': 1073741824}.get(
            (m.group(2) or '').lower(), None)
        return float(m.group(1)) * mult if mult else float(m.group(1))
    try:
        x, y = norm(a), norm(b)
        if isinstance(x, float) and isinstance(y, float) and max(x, y) >= 1024:
            # Memory: within a tenth is the same - what is free moves from one
            # look to the next, and a setting is not changed for that.
            return abs(x - y) <= 0.1 * max(x, y)
        return x == y
    except Exception:
        return str(a) == str(b)


def tune_connect(store, admin_user, admin_password):
    """The server, as an administrator when one is given, else as ourselves."""
    c = {k: CONFIG.get(k) for k in DB_KEYS}
    if admin_user:
        c['db_user'], c['db_password'] = admin_user, admin_password
        if c['db_engine'] == 'postgres':
            pass
    return db_open(c) if admin_user else store.db


def tune_last(store):
    try:
        return json.loads(store.get_meta('tune_last:' + node_name()) or 'null')
    except ValueError:
        return None


def tune_pending(db):
    if db.engine != 'postgres':
        return []
    try:
        return [r['name'] for r in db.rows('SELECT name FROM pg_settings WHERE pending_restart')]
    except Exception:                                   # noqa: BLE001
        return []


def tune_plan_for(store, typed, probe=True):
    db = store.db
    if db.engine == 'sqlite':
        raise ValueError('the file on this machine has no server to tune: this program sets '
                         'it up itself')
    c = {k: CONFIG.get(k) for k in DB_KEYS}
    typed = typed or {}
    m = tune_machine(c, typed)
    commit_ms = tune_commit_ms(db) if probe else None
    disk, why = tune_disk_guess(m, commit_ms)
    if typed.get('disk') in ('ssd', 'hdd') and typed['disk'] != disk:
        disk, why = typed['disk'], 'chosen'
    m['disk'], m['why'], m['commit_ms'] = disk, why, commit_ms
    out = {'engine': db.engine, 'words': ENGINE_WORDS.get(db.engine), 'where': db.where(),
           'version': str(db.version() or '').split(' on ')[0].split(',')[0],
           'size': int(db.size() or 0), 'machine': m, 'facts': m,
           'restart': tune_restart_ready(store), 'last': tune_last(store), 'rows': [],
           'items': []}
    try:
        if db.engine == 'postgres':
            out['connections'] = int(db.value('SHOW max_connections') or 0)
        else:
            r = db.row("SHOW GLOBAL VARIABLES LIKE 'max_connections'")
            out['connections'] = int(list(r.values())[1]) if r else 0
    except Exception:                                   # noqa: BLE001
        pass
    if not m.get('ram_gb') or not m.get('cpus'):
        out['need_facts'] = True
        return out
    plan = tune_plan(db.engine, m)
    now = tune_current(db, plan.keys())
    pending = set(tune_pending(db))
    last = out['last'] or {}
    mine = last.get('engine') == db.engine and not last.get('undone') \
        and last.get('where') == db.where()
    put = (last.get('set') or {}) if mine else {}
    rows = []
    for n, (v, why_, rs) in plan.items():
        same = tune_same(db.engine, now.get(n, ''), v)
        row = {'name': n, 'now': now.get(n, ''), 'want': v, 'why': why_, 'restart': rs,
               'takes': 'at the next start' if rs else 'at once', 'same': same,
               'change': not same, 'pending': n in pending}
        if n in pending and n in put and tune_same(db.engine, put[n], v):
            row.update(change=False, waiting=True)
        rows.append(row)
    out['rows'] = out['items'] = rows
    if db.engine == 'mariadb':
        out['snippet'] = out['cnf'] = (
            '# Written by otp %s for this machine, as zz-otp-tuning.cnf in /etc/my.cnf.d/\n'
            '# (or /etc/mysql/mariadb.conf.d/) so that the settings outlast a restart.\n'
            '[mariadb]\n' % __version__) + ''.join('%s = %s\n' % (r['name'], r['want'])
                                                    for r in rows)
    return out


def tune_apply(store, typed, admin_user, admin_password, by):
    plan = tune_plan_for(store, typed, probe=False)
    if plan.get('need_facts'):
        raise ValueError('say what the machine has first: its memory and its processors')
    db = tune_connect(store, admin_user, admin_password)
    done, later, failed = [], [], []
    before = json.loads(store.get_meta('tune_before:' + node_name()) or '{}')
    try:
        for r in plan['rows']:
            if not r['change']:
                continue
            before.setdefault(r['name'], r['now'])
            try:
                if plan['engine'] == 'postgres':
                    db.run("ALTER SYSTEM SET %s = '%s'" % (r['name'], r['want'].replace("'", '')))
                    (later if r['restart'] else done).append(r['name'])
                else:
                    if r['restart']:
                        later.append(r['name'])
                        continue
                    db.run('SET GLOBAL %s = %s' % (r['name'], r['want'] if r['want'].isdigit()
                                                  else "'%s'" % r['want']))
                    done.append(r['name'])
            except Exception as e:
                failed.append('%s: %s' % (r['name'], str(e).split('\n')[0][:160]))
        if plan['engine'] == 'postgres' and (done or later):
            db.run('SELECT pg_reload_conf()')
    finally:
        if db is not store.db:
            db.close()
    store.set_meta('tune_before:' + node_name(), json.dumps(before))
    if done or later:
        store.set_meta('tune_last:' + node_name(), json.dumps({
            'engine': plan['engine'], 'where': store.db.where(), 'at': time.time(), 'by': by,
            'set': {r['name']: r['want'] for r in plan['rows'] if r['name'] in done + later},
            'undone': 0}))
    store.add_event('settings', 'the database server was tuned for its machine by %s: %s'
                    % (by, ', '.join(done + later) or 'nothing'), 'warn', who=by)
    plan2 = tune_plan_for(store, typed, probe=False)
    plan2.update({'done': done, 'later': later, 'failed': failed})
    return plan2


TUNE_RESTART_MARK = CONFIG_FILE.parent / 'may-restart-database'


def tune_restart_unit():
    """The postgresql service on this machine, as systemd knows it, or ''."""
    try:
        said = subprocess.run(['systemctl', 'list-units', '--type=service', '--all', '--plain',
                               '--no-legend', '--no-pager', 'postgresql*'],
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return ''
    found = []
    for line in said.stdout.splitlines():
        f = line.split()
        if len(f) >= 3 and f[2] == 'active' and \
                re.match(r'^postgresql(-\d+)?(@[\w.-]+)?\.service$', f[0]):
            found.append(f[0])
    return found[0] if len(found) == 1 else ''


def tune_restart_ready(store):
    db = store.db
    if db.engine != 'postgres':
        return {'may': False, 'unit': ''}
    host = str(CONFIG.get('db_host') or '').lower()
    if host not in ('', 'localhost', '127.0.0.1', '::1', socket.gethostname().lower()):
        return {'may': False, 'unit': 'postgresql',
                'why': 'PostgreSQL runs on another machine, which this program cannot restart'}
    unit = tune_restart_unit()
    if not unit:
        return {'may': False, 'unit': 'postgresql',
                'why': 'no single running postgresql service was found on this machine'}
    if not TUNE_RESTART_MARK.exists():
        return {'may': False, 'unit': unit,
                'why': 'install.sh has not let this program restart it (run install.sh --upgrade '
                       'without --no-db-restart)'}
    return {'may': True, 'unit': unit, 'why': ''}


def tune_restart(store, by):
    """PostgreSQL on this machine started again, for the settings that take
    only at a start - through systemd, where install.sh let this account do
    that - and waited for."""
    db = store.db
    ready = tune_restart_ready(store)
    if db.engine != 'postgres' or not ready['unit']:
        raise ValueError('no database server is running as a service on this machine')
    unit = ready['unit']
    if not TUNE_RESTART_MARK.exists():
        raise ValueError('this program may not restart %s: run  systemctl restart %s  as root'
                         % (unit, unit))
    waiting = tune_pending(db)
    if not waiting:
        raise ValueError('nothing waits for a restart')
    try:
        if str(db.value('SHOW huge_pages')).lower() == 'on':
            raise ValueError('huge_pages is on, and a start needs enough of them for the new '
                             'shared_buffers: check vm.nr_hugepages, then run  systemctl '
                             'restart %s  as root' % unit)
    except ValueError:
        raise
    except Exception:                                   # noqa: BLE001
        pass
    if 'shared_buffers' in waiting:
        try:
            want = int(db.value("SELECT pg_size_bytes(setting) FROM pg_file_settings WHERE "
                                "name = 'shared_buffers' AND applied = false ORDER BY seqno "
                                "DESC LIMIT 1") or 0)
        except Exception:                               # noqa: BLE001
            want = 0
        try:
            want = want or 0
            running = int(db.value("SELECT setting::bigint * 8192 FROM pg_settings WHERE "
                                   "name = 'shared_buffers'") or 0)
            avail = tune_machine({}, {}).get('avail') or 0
        except Exception:                               # noqa: BLE001
            running = avail = 0
        if want and avail and want - running > avail - 512 * 1048576:
            raise ValueError('the machine has %d MB free now, too little for shared_buffers of '
                             '%d MB - restarted now, PostgreSQL might not start. Free some '
                             'memory, or put back as it was' % (avail // 1048576,
                                                                 want // 1048576))
    began = time.time()
    try:
        said = subprocess.run(['systemctl', '--no-ask-password', '--no-block', 'restart', unit],
                              capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError) as e:
        raise ValueError('systemctl: %s' % str(e)[:160])
    if said.returncode != 0:
        raise ValueError('%s was not restarted: %s - run  systemctl restart %s  as root'
                         % (unit, (said.stderr or said.stdout).strip()[:160], unit))
    store.add_event('settings', '%s restarted %s for the settings waiting for it: %s'
                    % (by, unit, ', '.join(waiting)), 'warn', who=by)
    time.sleep(2)
    back = False
    while time.time() < began + 62:
        try:
            state = subprocess.run(['systemctl', 'is-failed', unit], capture_output=True,
                                   text=True, timeout=5).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            state = ''
        if state == 'failed':
            raise ValueError('%s did not start again - see  journalctl -u %s ; if it does not '
                             'start: as root, take the shared_buffers line out of '
                             'postgresql.auto.conf and run  systemctl start %s'
                             % (unit, unit, unit))
        try:
            started = float(db.value('SELECT extract(epoch from pg_postmaster_start_time())'))
            if started >= began - 1:
                back = True
                break
        except Exception:                               # noqa: BLE001
            pass
        time.sleep(1)
    if not back:
        raise ValueError('%s was asked to restart and has not answered yet - look again in a '
                         'minute' % unit)
    left = tune_pending(db)
    return {'unit': unit, 'waiting': waiting, 'still': left,
            'message': '%s started again%s' % (unit, '; still waiting: ' + ', '.join(left)
                                                if left else ': every setting is in effect')}


def tune_undo(store, admin_user, admin_password, by):
    before = json.loads(store.get_meta('tune_before:' + node_name()) or '{}')
    if not before:
        raise ValueError('nothing was changed here, so there is nothing to put back')
    db = tune_connect(store, admin_user, admin_password)
    done, failed = [], []
    try:
        for n, v in before.items():
            try:
                if store.db.engine == 'postgres':
                    db.run('ALTER SYSTEM RESET %s' % n)
                else:
                    db.run('SET GLOBAL %s = %s' % (n, v if str(v).isdigit() else "'%s'" % v))
                done.append(n)
            except Exception as e:
                failed.append('%s: %s' % (n, str(e).split('\n')[0][:160]))
        if store.db.engine == 'postgres':
            db.run('SELECT pg_reload_conf()')
    finally:
        if db is not store.db:
            db.close()
    store.set_meta('tune_before:' + node_name(), '')
    last = tune_last(store) or {}
    if last:
        last.update(undone=time.time(), undone_by=by)
        store.set_meta('tune_last:' + node_name(), json.dumps(last))
    store.add_event('settings', 'the database server’s settings were put back by %s: %s'
                    % (by, ', '.join(done)), 'warn', who=by)
    return {'done': done, 'failed': failed}

# ---------------------------------------------------------------------------
# The files kept beside the database, the disk under it, and putting one back
# ---------------------------------------------------------------------------
# As on isemon (1.10.160 on): two kinds of file are kept.
#
#   A *copy* is made by this program: every row of every table, written as a
#   portable file, which goes back into any of the three engines. That is
#   what carries an installation from the file to a server and back.
#
#   A *dump* is made by the engine's own program - pg_dump, mariadb-dump, or
#   for the file SQLite's own backup, which is the file. It is a fraction of
#   the size, the server's own tools read it, and it goes back into the
#   engine it came off.
#
# Every one of either kind has the key that opens the tokens beside it, in a
# file of its own, because one without the other is nothing.

DUMP_DIR = STATE_DIR / 'dumps'
DUMP_SUFFIX = {'sqlite': '.db', 'mariadb': '.sql.gz', 'postgres': '.pgc', 'copy': '.json.gz'}
DUMP_WORDS = {'sqlite': 'a copy of the file', 'mariadb': 'a MariaDB dump',
              'postgres': 'a PostgreSQL dump', 'copy': 'a portable copy'}
DUMP_TOOLS = {'sqlite': (),
              'mariadb': (('making one', ('mariadb-dump', 'mysqldump')),
                          ('putting one back', ('mariadb', 'mysql'))),
              'postgres': (('making one', ('pg_dump',)),
                           ('putting one back', ('pg_restore',)))}
DUMP_INSTALL = {'mariadb': 'dnf install mariadb (it is the client, not the server)',
                'postgres': 'dnf install postgresql (it is the client, not the server)'}
DRIVERS = {'mariadb': ('pymysql', 'python3-PyMySQL'),
           'postgres': ('psycopg2', 'python3-psycopg2')}
NAME_RE = re.compile(r'^o(?:tp|pt)-(sqlite|mariadb|postgres|copy)?-?(\d{8}-\d{6})(?:-([a-z-]+))?'
                     r'(\.db|\.sql\.gz|\.pgc|\.json\.gz)$')


def drivers_state():
    """Whether the driver for each server engine is installed - said before
    somebody types an address rather than after they press a button."""
    out = {}
    for engine, (module, package) in DRIVERS.items():
        try:
            __import__(module)
            out[engine] = {'ready': True, 'package': package}
        except Exception as e:                          # noqa: BLE001
            out[engine] = {'ready': False, 'package': package,
                           'says': 'the driver %s is not installed (%s)' % (module, e)}
    return out


def dump_info(engine):
    """Which program tonight's dump will be made with, and whether it is here."""
    out = {'engine': engine, 'words': DUMP_WORDS.get(engine, engine),
           'suffix': DUMP_SUFFIX.get(engine, ''), 'where': str(DUMP_DIR),
           'install': DUMP_INSTALL.get(engine, ''), 'ready': True, 'why': ''}
    for what, names in DUMP_TOOLS.get(engine, ()):
        if not any(shutil.which(n) for n in names):
            out.update(ready=False, why='%s is not on this machine, so a dump cannot be %s'
                       % (names[0], 'made' if what == 'making one' else 'put back'))
            break
    return out


def _tool(names):
    for one in names:
        got = shutil.which(one)
        if got:
            return got
    raise ValueError('%s is not on this machine' % names[0])


def _db_conf():
    return {k: CONFIG.get(k) for k in DB_KEYS}


def safe_db_name(c):
    """The database's name, as it may stand on a command line: never one
    that reads as an option (1.0.33)."""
    name = str(c.get('db_name') or '')
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_]{0,62}$', name):
        raise DbError('the database name %r is not letters, digits and _' % name[:60])
    return name


def _my_cnf(c):
    """A defaults file holding the password and nothing else, 0600, gone the
    moment the program has finished with it: `--password=` on a command line
    is readable by everybody on the machine while it runs."""
    handle, name = tempfile.mkstemp(prefix='otp-my-', suffix='.cnf')
    os.close(handle)
    os.chmod(name, 0o600)
    with open(name, 'w') as f:
        said = str(c.get('db_password') or '')
        if any(ord(ch) < 32 for ch in said):
            raise DbError('the database password has a line break or another control '
                          'character in it')
        f.write('[client]\npassword="%s"\n' % said.replace('\\', '\\\\').replace('"', '\\"'))
    return name


def _my_args(c, cnf):
    out = ['--defaults-extra-file=%s' % cnf,
           '--host=%s' % (str(c.get('db_host') or '127.0.0.1').strip('[]')),
           '--port=%d' % int(c.get('db_port') or 3306),
           '--user=%s' % (c.get('db_user') or '')]
    # The dump and restore tools encrypted as the daemon's own connection is
    # (1.0.36).
    mode = str((c.get('db_tls') if 'db_tls' in c else CONFIG.get('db_tls')) or '')
    ca = str((c.get('db_tls_ca') if 'db_tls_ca' in c else CONFIG.get('db_tls_ca')) or '')
    if mode:
        out.append('--ssl')
        if mode in ('verify-ca', 'verify-full'):
            out.append('--ssl-verify-server-cert')
        if ca:
            out.append('--ssl-ca=%s' % ca)
    return out


def _pg_args(c):
    return ['--host=%s' % (str(c.get('db_host') or '127.0.0.1').strip('[]')),
            '--port=%d' % int(c.get('db_port') or 5432),
            '--username=%s' % (c.get('db_user') or ''), '--no-password']


def _pg_env(c):
    env = dict(os.environ)
    env['PGPASSWORD'] = str(c.get('db_password') or '')
    env['PGCONNECT_TIMEOUT'] = str(int(c.get('db_timeout_s') or 10))
    mode = str((c.get('db_tls') if 'db_tls' in c else CONFIG.get('db_tls')) or '')
    ca = str((c.get('db_tls_ca') if 'db_tls_ca' in c else CONFIG.get('db_tls_ca')) or '')
    if mode:
        env['PGSSLMODE'] = mode
        if ca:
            env['PGSSLROOTCERT'] = ca
    return env


def _run(args, words, stdin=None, stdout=None, env=None, seconds=3600):
    try:
        got = subprocess.run(args, stdin=stdin, stdout=stdout if stdout is not None
                             else subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                             timeout=seconds)
    except subprocess.TimeoutExpired:
        raise ValueError('%s took longer than %d s and was stopped' % (words, seconds))
    if got.returncode != 0:
        said = (got.stderr or b'').decode('utf-8', 'replace').strip().split('\n')
        raise ValueError('%s failed: %s' % (words, (said[-1] if said else
                                                     'exit %d' % got.returncode)[:300]))
    return got.stdout


def _stamp():
    return datetime.now().strftime('%Y%m%d-%H%M%S')


def _key_beside(path):
    p = str(path)
    for suf in ('.json.gz', '.sql.gz', '.pgc', '.db'):
        if p.endswith(suf):
            return Path(p[:-len(suf)] + '.key')
    return Path(p + '.key')


def _write_key_beside(path):
    key = sealing_key()
    if key:
        write_replacing(_key_beside(path), key.hex() + '\n', 0o600)


def _kind_of_name(name):
    for kind, suf in (('copy', '.json.gz'), ('mariadb', '.sql.gz'), ('postgres', '.pgc'),
                      ('sqlite', '.db')):
        if name.endswith(suf):
            return kind
    return ''


def _prune(folder, pattern, keep):
    files = sorted((f for f in folder.glob(pattern) if NAME_RE.match(f.name)),
                   key=lambda f: f.stat().st_mtime)
    for old in files[:-keep] if keep > 0 and len(files) > keep else []:
        for f in (old, _key_beside(old)):
            try:
                f.unlink()
            except OSError:
                pass


def copy_engine(path):
    """Which engine a copy was taken off: its first line says."""
    import gzip
    try:
        with gzip.open(str(path), 'rt', encoding='utf-8') as f:
            return json.loads(f.readline() or '{}').get('engine') or ''
    except Exception:                                   # noqa: BLE001
        return ''


def kept_copies():
    """The copies this program made, newest first."""
    if not BACKUP_DIR.is_dir():
        return []
    out = []
    for f in sorted(list(BACKUP_DIR.glob('otp-*.json.gz')) + list(BACKUP_DIR.glob('opt-*.json.gz')),
                   key=lambda x: x.stat().st_mtime,
                    reverse=True):
        st = f.stat()
        out.append({'name': f.name, 'bytes': st.st_size, 'size': st.st_size, 'at': st.st_mtime,
                    'from': copy_engine(f), 'key': _key_beside(f).exists(), 'kind': 'copy'})
    return out


def kept_dumps(engine):
    """The dumps the engine made of itself, newest first."""
    if not DUMP_DIR.is_dir():
        return []
    out = []
    for f in sorted(DUMP_DIR.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        m = NAME_RE.match(f.name)
        if not m:
            continue
        kind = _kind_of_name(f.name)
        came = m.group(1) or ''
        if kind == 'copy':
            came = copy_engine(f) or came
        st = f.stat()
        out.append({'name': f.name, 'bytes': st.st_size, 'at': st.st_mtime, 'kind': kind,
                    'from': came if kind != 'copy' else came,
                    'mine': kind == 'copy' or kind == engine,
                    'key': _key_beside(f).exists()})
    return out


def make_dump(store, label='daily', folder=None):
    """A dump of the database in use by its own engine's program - or, where
    that program is not on this machine, a portable copy in its place."""
    engine = store.db.engine
    folder = Path(folder) if folder else DUMP_DIR
    folder.mkdir(parents=True, exist_ok=True)
    info = dump_info(engine)
    kind = engine if info['ready'] else 'copy'
    name = 'otp-%s-%s-%s%s' % (engine if kind != 'copy' else 'copy', _stamp(),
                              re.sub(r'[^a-z-]', '', label) or 'daily', DUMP_SUFFIX[kind])
    target = folder / name
    part = Path(str(target) + '.part')
    c = _db_conf()
    try:
        if kind == 'copy':
            dump_tables(store.db, part)
        elif engine == 'sqlite':
            # SQLite's own backup: a consistent copy of the file even while the
            # daemon writes to it.
            src = sqlite3.connect(str(store.db.path))
            dst = sqlite3.connect(str(part))
            try:
                src.backup(dst)
            finally:
                dst.close()
                src.close()
        elif engine == 'mariadb':
            import gzip
            tool = _tool(('mariadb-dump', 'mysqldump'))
            cnf = _my_cnf(c)
            try:
                raw = Path(str(part) + '.raw')
                with open(str(raw), 'wb') as out:
                    _run([tool] + _my_args(c, cnf) + [
                        '--single-transaction', '--quick', '--skip-lock-tables',
                        '--default-character-set=utf8mb4', '--no-tablespaces',
                        '--add-drop-table', '--skip-comments', safe_db_name(c)],
                        'mariadb-dump', stdout=out)
                with open(str(raw), 'rb') as src, gzip.open(str(part), 'wb', 6) as dst:
                    shutil.copyfileobj(src, dst, 1 << 20)
                raw.unlink()
            finally:
                os.unlink(cnf)
        else:
            tool = _tool(('pg_dump',))
            _run([tool] + _pg_args(c) + ['--format=custom', '--compress=6', '--no-owner',
                                         '--no-privileges', '--file=%s' % part,
                                         '--dbname=%s' % safe_db_name(c)],
                 'pg_dump', env=_pg_env(c))
        os.chmod(str(part), 0o640)
        part.replace(target)
    finally:
        for left in (part, Path(str(part) + '.raw')):
            if left.exists():
                try:
                    left.unlink()
                except OSError:
                    pass
    _write_key_beside(target)
    if folder == DUMP_DIR:
        _prune(DUMP_DIR, 'o[tp][tp]-*', int(CONFIG.get('backup_keep') or 14))
    store.add_event('backups', 'made %s (%s): %s' % (
        DUMP_WORDS[kind], {'daily': 'every night', 'by-hand': 'by hand',
                           'download': 'to be downloaded'}.get(label, label), target.name))
    return target


# ---- what is in a file, without putting any of it back ------------------------
def _magic(path):
    with open(str(path), 'rb') as f:
        return f.read(16)


def _peek_copy(path):
    import gzip
    counts, admins, tables, table = {}, 0, 0, None
    with gzip.open(str(path), 'rt', encoding='utf-8') as f:
        head = json.loads(f.readline() or '{}')
        if 'otp' not in head and 'opt' not in head:      # 'opt': before 1.0.37's new name
            return None, 'that is not a copy made by otp'
        for line in f:
            got = json.loads(line)
            if set(got.keys()) == {'table'}:
                table = got['table']
                tables += 1
                counts.setdefault(table, 0)
                continue
            if table:
                counts[table] += 1
                if table == 'accounts' and got.get('role') == 'fulladmin' \
                        and not got.get('disabled'):
                    admins += 1
    return {'kind': 'copy', 'from': head.get('engine') or '', 'version': head.get('otp') or head.get('opt'),
            'made': head.get('made'), 'counts': counts, 'admins': admins, 'tables': tables,
            'key': bool(head.get('key'))}, ''


def _peek_sqlite(path):
    try:
        con = sqlite3.connect('file:%s?mode=ro' % path, uri=True)
    except sqlite3.Error as e:
        return None, 'that file could not be opened: %s' % e
    try:
        names = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'")]
        if 'accounts' not in names or 'tokens' not in names:
            return None, 'that is not a database of otp: it has no tokens and no accounts'
        counts = {t: con.execute('SELECT COUNT(*) FROM %s' % t).fetchone()[0]
                  for t in TABLES if t in names}
        admins = con.execute("SELECT COUNT(*) FROM accounts WHERE role = 'fulladmin' AND "
                             "COALESCE(disabled, 0) = 0").fetchone()[0]
    except sqlite3.Error as e:
        return None, 'that database could not be read: %s' % e
    finally:
        con.close()
    return {'kind': 'sqlite', 'counts': counts, 'admins': admins,
            'tables': len([t for t in TABLES if t in names])}, ''


def _peek_mariadb(path):
    import gzip
    tables, admins, users, in_users = set(), 0, 0, False
    with gzip.open(str(path), 'rt', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('CREATE TABLE'):
                got = re.search(r'CREATE TABLE `([^`]+)`', line)
                if got:
                    tables.add(got.group(1))
                continue
            first = line.startswith('INSERT INTO `accounts`')
            if first:
                in_users = True
            elif in_users and not line.startswith('('):
                in_users = False
            if in_users:
                admins += line.count(",'fulladmin',")
                rest = line.split('VALUES', 1)[-1] if first else line
                users += rest.count('),(') + (1 if '(' in rest else 0)
                if line.rstrip().endswith(';'):
                    in_users = False
    if 'accounts' not in tables or 'tokens' not in tables:
        return None, 'that dump is not one of otp - it has no tokens and no accounts'
    return {'kind': 'mariadb', 'counts': {'accounts': users}, 'admins': admins,
            'tables': len(tables)}, ''


def _peek_postgres(path):
    tool = shutil.which('pg_restore')
    if not tool:
        return None, ('pg_restore is not on this machine, so what is in that dump cannot be '
                      'read: %s' % DUMP_INSTALL['postgres'])
    listed = _run([tool, '--list', str(path)], 'pg_restore --list', seconds=300)
    tables = set(re.findall(r'TABLE DATA\s+\S+\s+(\S+)', listed.decode('utf-8', 'replace')))
    if 'accounts' not in tables or 'tokens' not in tables:
        return None, 'that dump is not one of otp - it has no tokens and no accounts'
    rows = _run([tool, '--data-only', '--table=accounts', '--file=-', str(path)],
                'pg_restore', seconds=300).decode('utf-8', 'replace')
    users = admins = 0
    inside = False
    for line in rows.split('\n'):
        if line.startswith('COPY '):
            inside = True
            continue
        if inside:
            if line == '\\.':
                break
            users += 1
            if '\tfulladmin\t' in line:
                admins += 1
    return {'kind': 'postgres', 'counts': {'accounts': users}, 'admins': admins,
            'tables': len(tables)}, ''


def db_file_peek(path, engine):
    """What is in a copy or a dump, and whether it may be put back here."""
    head = _magic(path)
    try:
        if head.startswith(b'SQLite format 3'):
            said, why = _peek_sqlite(path)
        elif head.startswith(b'PGDMP'):
            said, why = _peek_postgres(path)
        elif head[:2] == b'\x1f\x8b':
            import gzip
            with gzip.open(str(path), 'rb') as f:
                first = f.read(64)
            if first.startswith(b'{'):
                said, why = _peek_copy(path)
            else:
                said, why = _peek_mariadb(path)
        else:
            return None, 'that is neither a copy nor a dump made by otp'
    except Exception as e:                              # noqa: BLE001
        return None, 'that file could not be read: %s' % str(e).split('\n')[0][:200]
    if said is None:
        return None, why
    kind = said['kind']
    if kind not in ('copy', 'sqlite') and kind != engine:
        return None, ('that is %s, and this installation is on %s: a dump goes back only into '
                      'the engine it came off. Use a copy - a copy goes into any of the three.'
                      % (DUMP_WORDS[kind], ENGINE_WORDS.get(engine, engine)))
    if not said.get('admins'):
        return None, ('there is no full administrator who can sign in in that file: putting it '
                      'back would lock everybody out of these pages')
    said['bytes'] = Path(path).stat().st_size
    return said, ''


def _sqlite_to_copy(path, out):
    """A SQLite file of ours, as a copy: so that it goes back into whatever
    engine is in use, by the same road as every copy."""
    src = Db('sqlite', path=path)
    try:
        dump_tables(src, out, [t for t in TABLES if t in src.tables()])
    finally:
        src.close()
    return out


def db_file_restore(store, path, by, key_file=None, from_name=''):
    """Put a copy or a dump back over everything. A copy of what is replaced
    is made first and kept with the others."""
    engine = store.db.engine
    said, why = db_file_peek(path, engine)
    if said is None:
        raise ValueError(why)
    kind = said['kind']
    if CONFIG.get('ha_mode') == 'replicated' and kind in ('postgres', 'mariadb'):
        raise ValueError('a dump puts tables back by making them again, which replication '
                         'does not carry to the other node: put a copy back instead (it goes '
                         'over row by row)')
    # A kept copy is read from a copy of its own (1.0.44): the safety copy
    # below rotates the kept ones, and the oldest - the one being put back -
    # would be the one it took away.
    held = []
    try:
        if Path(path).resolve().parent == Path(BACKUP_DIR).resolve():
            ext = ''.join(Path(path).suffixes[-2:]) if str(path).endswith('.gz') else Path(path).suffix
            fd, tmpname = tempfile.mkstemp(prefix='otp-putback-', suffix=ext, dir=str(STATE_DIR))
            os.close(fd)
            shutil.copyfile(str(path), tmpname)
            os.chmod(tmpname, 0o600)
            held.append(Path(tmpname))
            kf = Path(key_file) if key_file else None
            if kf and kf.exists():
                fd, kname = tempfile.mkstemp(prefix='otp-putback-', suffix='.key', dir=str(STATE_DIR))
                os.close(fd)
                shutil.copyfile(str(kf), kname)
                os.chmod(kname, 0o600)
                held.append(Path(kname))
                key_file = kname
            path = tmpname
        return _db_file_restore(store, path, by, key_file, from_name, kind)
    finally:
        for x in held:
            try:
                x.unlink()
            except OSError:
                pass


def _db_file_restore(store, path, by, key_file, from_name, kind):
    # The key that opens the tokens in it: beside a kept file, or inside a copy
    # that was downloaded with it.
    key_hex = ''
    if key_file and Path(key_file).exists():
        key_hex = Path(key_file).read_text().strip()
    elif kind == 'copy':
        import gzip
        with gzip.open(str(path), 'rt', encoding='utf-8') as f:
            key_hex = str(json.loads(f.readline() or '{}').get('key') or '')
    # In a cluster the other node keeps its own key, and the rows going over
    # would be ones it cannot open (1.0.44): a copy sealed with another key
    # is refused there before anything is replaced.
    if CONFIG.get('ha_mode') == 'replicated' and re.match(r'^[0-9a-f]{64}$', key_hex):
        now = sealing_key()
        if now and now.hex() != key_hex:
            raise ValueError('this copy was sealed with another key than the one both nodes '
                             'use; in a cluster it cannot be put back - the other node could '
                             'not open its tokens')
    safety = make_backup(store, 'before putting %s back, by %s' % (from_name or 'a file', by))
    c = _db_conf()
    if kind == 'copy':
        load_tables(store.db, path)
    elif kind == 'sqlite':
        tmp = Path(tempfile.mkstemp(prefix='otp-restore-', suffix='.json.gz',
                                    dir=str(STATE_DIR))[1])
        try:
            _sqlite_to_copy(path, tmp)
            load_tables(store.db, tmp)
        finally:
            tmp.unlink()
    elif kind == 'mariadb':
        import gzip
        tool = _tool(('mariadb', 'mysql'))
        with gzip.open(str(path), 'rb') as sent:
            for n, line in enumerate(sent):
                if line[:1] == b'\\' or line[:7].lower() == b'system ':
                    raise ValueError('line %d of the dump is a client command, not SQL. '
                                     'A dump this program made has none.' % (n + 1))
        cnf = _my_cnf(c)
        # The client is given the SQL itself: a gzip reader has no file
        # descriptor of its own to hand a program, so it is unpacked first.
        raw = Path(tempfile.mkstemp(prefix='otp-sql-', dir=str(STATE_DIR))[1])
        try:
            with gzip.open(str(path), 'rb') as src, open(str(raw), 'wb') as dst:
                shutil.copyfileobj(src, dst, 1 << 20)
            with open(str(raw), 'rb') as sent:
                _run([tool] + _my_args(c, cnf) + ['--default-character-set=utf8mb4',
                                                  '--local-infile=0', '--binary-mode',
                                                  safe_db_name(c)],
                     'the MariaDB client', stdin=sent)
        finally:
            os.unlink(cnf)
            try:
                raw.unlink()
            except OSError:
                pass
    else:
        tool = _tool(('pg_restore',))
        _run([tool] + _pg_args(c) + ['--single-transaction', '--clean', '--if-exists',
                                     '--no-owner', '--no-privileges',
                                     '--dbname=%s' % safe_db_name(c), str(path)],
             'pg_restore', env=_pg_env(c))
    store.db.make_tables()
    if CONFIG.get('ha_mode') == 'replicated' and store.db.engine == 'postgres':
        ha_sequences(store.db, int(CONFIG.get('ha_slot') or 1))
    key_said = 'the key that opens the tokens stays as it was'
    if re.match(r'^[0-9a-f]{64}$', key_hex):
        now = sealing_key()
        if not now or now.hex() != key_hex:
            write_replacing(sealing_key_path(), key_hex + '\n', 0o600)
            key_said = 'the key that opens the tokens came with it and is in use now'
    bump(store)
    store.add_event('backups', '%s put the database back from %s (%s); what it replaced is in %s'
                    % (by, from_name or 'a file', DUMP_WORDS.get(kind, kind), safety.name),
                    'warn', who=by)
    return {'safety': safety.name, 'kind': kind, 'key': key_said}


# ---- the disk under it ----------------------------------------------------------
def note_size(store):
    """The size of the database, once a day, for how fast it grows."""
    try:
        sizes = json.loads(store.get_meta('db_sizes:' + node_name()) or '{}')
    except ValueError:
        sizes = {}
    today = datetime.now().strftime('%Y-%m-%d')
    if sizes.get('engine') != store.db.engine:
        sizes = {'engine': store.db.engine, 'days': {}}
    if today not in sizes['days']:
        sizes['days'][today] = int(store.db.size() or 0)
        for old in sorted(sizes['days'])[:-60]:
            del sizes['days'][old]
        store.set_meta('db_sizes:' + node_name(), json.dumps(sizes))
    return sizes


def db_growth(store):
    days = note_size(store).get('days', {})
    edge = (datetime.now().timestamp() - 15 * 86400)
    seen = sorted((d, b) for d, b in days.items()
                  if datetime.strptime(d, '%Y-%m-%d').timestamp() >= edge)
    if len(seen) < 2:
        return {'a_day': 0, 'over_days': 0}
    (d0, b0), (d1, b1) = seen[0], seen[-1]
    span = max(1, (datetime.strptime(d1, '%Y-%m-%d') - datetime.strptime(d0, '%Y-%m-%d')).days)
    return {'a_day': max(0, int((b1 - b0) / span)), 'over_days': span}


def _folder_bytes(folder):
    total = 0
    if Path(folder).is_dir():
        for f in Path(folder).iterdir():
            try:
                total += f.stat().st_size
            except OSError:
                pass
    return total


def db_disk(store):
    db = store.db
    where = db.path.parent if db.engine == 'sqlite' else STATE_DIR
    out = {'where': str(where), 'total': 0, 'free': 0, 'share': 0, 'days_left': None,
           'holds': 'the database itself, its copies and its dumps' if db.engine == 'sqlite'
           else 'the copies and the dumps - the database itself is on the server'}
    try:
        u = shutil.disk_usage(str(where))
        out.update(total=u.total, free=u.free,
                   share=round(100.0 * (u.total - u.free) / u.total) if u.total else 0)
    except OSError:
        pass
    grew = db_growth(store)
    if grew['a_day'] and out['free']:
        out['days_left'] = int(out['free'] / grew['a_day'])
    parts = []
    if db.engine == 'sqlite':
        for suffix, what in (('', 'the database'), ('-wal', 'what is written, not yet folded in'),
                             ('-shm', 'the index of that')):
            f = Path(str(db.path) + suffix)
            if f.exists():
                parts.append({'name': f.name, 'what': what, 'bytes': f.stat().st_size})
    else:
        parts.append({'name': db.where(), 'what': 'the database, on the server',
                      'bytes': int(db.size() or 0)})
    parts.append({'name': str(BACKUP_DIR), 'what': 'the copies', 'bytes':
                  _folder_bytes(BACKUP_DIR)})
    parts.append({'name': str(DUMP_DIR), 'what': 'the dumps', 'bytes': _folder_bytes(DUMP_DIR)})
    return out, grew, parts


def db_cache(store):
    """The server's own cache, where it is left as installed and the database
    has outgrown it."""
    db = store.db
    if db.engine == 'sqlite':
        return None
    try:
        if db.engine == 'postgres':
            setting = 'shared_buffers'
            cache = int(db.value("SELECT setting::bigint * 8192 FROM pg_settings "
                                 "WHERE name = 'shared_buffers'") or 0)
        else:
            setting = 'innodb_buffer_pool_size'
            r = db.row("SHOW GLOBAL VARIABLES LIKE 'innodb_buffer_pool_size'")
            cache = int(list(r.values())[1]) if r else 0
    except Exception:                                   # noqa: BLE001
        return None
    size = int(db.size() or 0)
    ram = 0
    try:
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    ram = int(line.split()[1]) * 1024
    except OSError:
        pass
    return {'engine': ENGINE_WORDS.get(db.engine), 'setting': setting, 'cache': cache,
            'size': size, 'ram': ram, 'low': bool(cache and size > cache)}


# ---- erasing what was collected -----------------------------------------------
ERASABLE = [
    ('radius', 'radius_log', 'the RADIUS requests',
     'every request the VPN sent and what it was answered, with its steps. Nothing reads them '
     'back: they are the record of what happened.'),
    ('otp', 'otp_log', 'the checks of a code',
     'every code typed on the enrolment pages, in a test or through RADIUS, right or wrong. '
     'The tokens themselves are not touched: nobody has to enrol again.'),
    ('events', 'events', 'the event log',
     'what this program noted about itself: sign-ins, changes, copies, starts and stops.'),
]


def db_erasable(store):
    groups = []
    for key, table, name, says in ERASABLE:
        groups.append({'key': key, 'name': name, 'says': says,
                       'rows': int(store.db.value('SELECT COUNT(*) FROM %s' % table) or 0)})
    return {'groups': groups, 'bytes': int(store.db.size() or 0)}


def db_erase_job(store, groups, tidy, by):
    tables = [(t, n) for k, t, n, _ in ERASABLE if k in groups]
    if not tables:
        raise ValueError('nothing was ticked')

    def work(progress):
        progress(0, len(tables) + 2, 'making a copy first')
        copy = make_backup(store, 'before erasing, by %s' % by)
        gone = {}
        for i, (t, n) in enumerate(tables):
            progress(i + 1, len(tables) + 2, 'emptying %s' % n)
            gone[t] = store.db.run('DELETE FROM %s' % t)
        given = None
        if tidy:
            progress(len(tables) + 1, len(tables) + 2, 'giving the disk back')
            given = db_give_back(store, lambda *a: None)
        store.add_event('settings', '%s erased %s (a copy was made first: %s)'
                        % (by, ', '.join(n for _, n in tables), copy.name), 'warn', who=by)
        progress(len(tables) + 2, len(tables) + 2, 'done')
        return {'erased': gone, 'copy': copy.name, 'given': given}
    return db_job('erasing the collected data', work)


# ---- the server's settings: what was done, what waits for a start ---------------
def tune_state(store):
    db = store.db
    out = {'engine': db.engine, 'last': None, 'pending': [], 'lost': [],
           'restart': {'may': False, 'unit': {'postgres': 'postgresql',
                                              'mariadb': 'mariadb'}.get(db.engine, '')}}
    try:
        last = json.loads(store.get_meta('tune_last:' + node_name()) or 'null')
    except ValueError:
        last = None
    out['last'] = last
    if db.engine == 'postgres':
        try:
            out['pending'] = [r['name'] for r in db.rows(
                'SELECT name FROM pg_settings WHERE pending_restart')]
        except Exception:                               # noqa: BLE001
            pass
    elif db.engine == 'mariadb' and last and not last.get('undone') \
            and last.get('engine') == 'mariadb':
        now = tune_current(db, list((last.get('set') or {}).keys()))
        out['lost'] = [n for n, v in (last.get('set') or {}).items()
                       if not tune_same('mariadb', now.get(n, ''), v)]
    return out

# ---------------------------------------------------------------------------
# Sending mail (1.0.20)
# ---------------------------------------------------------------------------
# A token's QR code, and if wanted its recovery codes, sent to the person it
# is for. Two ways out: through a mail server (SMTP relay, with STARTTLS,
# SMTPS or nothing, signing in with PLAIN, LOGIN, CRAM-MD5, XOAUTH2 or not at
# all), or straight to the server of the recipient's domain - its MX record,
# looked up here - with no relay at all. A certificate signed by an authority
# of your own is trusted once that authority is added, as for a directory.

MAIL_CA_META = 'mail_ca'


def mail_ca_pem(store):
    try:
        return str(store.get_meta(MAIL_CA_META) or '')
    except Exception:
        return ''


def mail_ca_set(store, pem, mode='add', fingerprint=''):
    """The authorities trusted for the mail server, each added and taken out
    by itself - the same as a directory's."""
    pem = str(pem or '').strip()
    have = split_certificates(mail_ca_pem(store))
    if mode == 'add' and pem:
        new = split_certificates(pem)
        if not new or not all(describe_certificate(b) for b in new):
            raise ValueError('that is not a certificate this can read: a PEM certificate '
                             'starts -----BEGIN CERTIFICATE-----')
        seen = {c['fingerprint'] for c in describe_certificates('\n'.join(have))}
        have += [b for b, c in zip(new, describe_certificates('\n'.join(new)))
                 if c['fingerprint'] not in seen]
    elif mode == 'drop':
        keep = [b for b, c in zip(have, describe_certificates('\n'.join(have)))
                if c['fingerprint'] != fingerprint]
        if len(keep) == len(have):
            raise ValueError('that certificate is not among the ones kept')
        have = keep
    else:
        have = []
    store.set_meta(MAIL_CA_META, '\n'.join(have))
    return describe_certificates('\n'.join(have))


def mail_tls(store, verify=None):
    verify = bool(CONFIG.get('smtp_verify', 1)) if verify is None else verify
    ctx = ssl.create_default_context()
    pem = mail_ca_pem(store)
    if pem.strip():
        try:
            ctx.load_verify_locations(cadata=pem)
        except (ssl.SSLError, ValueError) as e:
            raise MailError('the certificate authorities kept for mail cannot be read: %s' % e)
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


class MailError(RuntimeError):
    def __init__(self, said, steps=None):
        super(MailError, self).__init__(said)
        self.steps = steps or []


# ---- the recipients' servers, without a library to ask DNS with -----------------
def own_dns():
    """The DNS servers set for mail going direct (`mail_dns`), if any."""
    good = []
    for w in re.split(r'[\s,;]+', str(CONFIG.get('mail_dns') or '')):
        try:
            good.append(str(ipaddress.ip_address(w)))
        except ValueError:
            pass
    return good


def dns_servers():
    if own_dns():
        return own_dns()
    out = []
    try:
        with open('/etc/resolv.conf') as f:
            for line in f:
                bits = line.split()
                if len(bits) >= 2 and bits[0] == 'nameserver':
                    out.append(bits[1])
    except OSError:
        pass
    return out or ['127.0.0.1']


def _dns_name(data, at):
    labels, jumped, end = [], False, at
    for _ in range(64):
        n = data[at]
        if n == 0:
            at += 1
            break
        if n & 0xC0 == 0xC0:
            if not jumped:
                end = at + 2
            at = ((n & 0x3F) << 8) | data[at + 1]
            jumped = True
            continue
        labels.append(data[at + 1:at + 1 + n].decode('ascii', 'replace'))
        at += 1 + n
    return '.'.join(labels), (end if jumped else at)


def _dns_ask(server, name, qtype, timeout):
    """One question to one DNS server: the raw answer. EDNS0 asks for room
    for a long answer; one that is cut short anyway is asked again over TCP
    (1.0.22)."""
    ident = secrets.randbits(16)
    q = struct.pack('>HHHHHH', ident, 0x0100, 1, 0, 0, 1)
    for label in name.split('.'):
        if not label:
            continue
        raw = label.encode('idna') if any(ord(c) > 127 for c in label) else label.encode()
        q += bytes([len(raw)]) + raw
    q += b'\x00' + struct.pack('>HH', qtype, 1)
    q += b'\x00' + struct.pack('>HHIH', 41, 4096, 0, 0)          # OPT: 4096 bytes
    fam = socket.AF_INET6 if ':' in server else socket.AF_INET
    s = socket.socket(fam, socket.SOCK_DGRAM)
    deadline = time.time() + timeout
    question = q[12:-11]                    # the name, the type and the class asked
    try:
        # connect(): only answers from the server asked are read at all.
        s.connect((server, 53))
        s.send(q)
        while True:
            left = deadline - time.time()
            if left <= 0:
                raise socket.timeout('no answer from %s' % server)
            s.settimeout(left)
            data = s.recv(65535)
            # Its own answer: the same ID, and the same question (1.0.33) -
            # and no waiting past the deadline however many others come.
            if len(data) >= 12 + len(question) and struct.unpack('>H', data[:2])[0] == ident \
                    and data[12:12 + len(question)].lower() == question.lower():
                break
    finally:
        s.close()
    if struct.unpack('>H', data[2:4])[0] & 0x0200:                # TC: cut short
        t = socket.create_connection((server, 53), timeout=timeout)
        try:
            t.sendall(struct.pack('>H', len(q)) + q)
            want, got = None, b''
            while want is None or len(got) < want + 2:
                chunk = t.recv(65535)
                if not chunk:
                    break
                got += chunk
                if want is None and len(got) >= 2:
                    want = struct.unpack('>H', got[:2])[0]
            data = got[2:]
        finally:
            t.close()
    return data


def _dns_records(data):
    """(rcode, [(type, name, rdata-offset, size)]) of an answer."""
    flags, qd, an = struct.unpack('>HHH', data[2:8])
    at = 12
    for _ in range(qd):
        _, at = _dns_name(data, at)
        at += 4
    out = []
    for _ in range(an):
        rname, at = _dns_name(data, at)
        rtype, _cls, _ttl, size = struct.unpack('>HHIH', data[at:at + 10])
        at += 10
        out.append((rtype, rname, at, size))
        at += size
    return flags & 0x0F, out


DNS_RCODES = {1: 'could not read the question', 2: 'failed (SERVFAIL)', 4: 'does not do that',
              5: 'refused to answer'}


def dns_mx_full(domain, timeout=5.0):
    """The mail servers of a domain, best first, and how they were found:
    ([(preference, host)], words). A domain with no MX record is its own
    mail server (RFC 5321) - but only when a DNS server said so, never
    because one failed to answer (1.0.22: a failed answer was taken for
    "no MX" and the mail went to the domain's own address)."""
    domain = str(domain).strip().strip('.').lower()
    try:                                       # dnspython, where it is installed
        import dns.resolver                     # type: ignore
        try:
            ans = dns.resolver.resolve(domain, 'MX', lifetime=timeout * 2)
            got = sorted((int(r.preference), str(r.exchange).rstrip('.')) for r in ans)
            got = [g for g in got if g[1]]
            if got:
                return got, 'MX records (dnspython)'
        except dns.resolver.NXDOMAIN:
            raise MailError('the domain %s does not exist' % domain)
        except dns.resolver.NoAnswer:
            return [(0, domain)], 'no MX record: the domain itself (dnspython)'
        except Exception:                       # noqa: BLE001 - our own below
            pass
    except ImportError:
        pass
    trouble = []
    name = domain
    for server in dns_servers():
        name = domain
        for _hop in range(6):                   # a CNAME, followed
            try:
                data = _dns_ask(server, name, 15, timeout)
                rcode, recs = _dns_records(data)
            except (OSError, struct.error, IndexError, ValueError) as e:
                trouble.append('%s: %s' % (server, e))
                break
            if rcode == 3:
                raise MailError('the domain %s does not exist (DNS %s)' % (name, server))
            if rcode:
                trouble.append('%s %s' % (server, DNS_RCODES.get(rcode, 'answered %d' % rcode)))
                break
            mx, cname, nullmx = [], None, False
            try:
                for rtype, _rname, at, _size in recs:
                    if rtype == 15:
                        pref = struct.unpack('>H', data[at:at + 2])[0]
                        host, _ = _dns_name(data, at + 2)
                        if host and host != '.':
                            mx.append((pref, host.rstrip('.').lower()))
                        else:
                            nullmx = True
                    elif rtype == 5:
                        cname, _ = _dns_name(data, at)
            except (struct.error, IndexError, ValueError) as e:
                trouble.append('%s: an answer that does not read: %s' % (server, e))
                break
            if mx:
                return sorted(mx), 'MX records from DNS %s' % server
            if nullmx:
                return [], 'a null MX (DNS %s): the domain takes no mail' % server
            if cname and cname.lower() != name:
                name = cname.rstrip('.').lower()
                continue
            # A null MX (RFC 7505) is "0 ." - the domain takes no mail.
            return [(0, name)], 'no MX record (DNS %s): the domain itself' % server
    raise MailError('no DNS server could say where mail for %s goes%s' % (
        domain, (': ' + '; '.join(trouble)) if trouble else ''))


def dns_mx(domain, timeout=5.0):
    return dns_mx_full(domain, timeout)[0]


def dns_addrs(host, timeout=5.0):
    """The IPv4 and IPv6 addresses of a host (A and AAAA, a CNAME followed),
    asked of the same DNS servers as the MX records (1.0.23) - not of the
    system's resolver, which may be the very one that will not answer."""
    host = str(host).strip().strip('.').lower()
    try:
        return [str(ipaddress.ip_address(host))]
    except ValueError:
        pass
    out, trouble = [], []
    for qtype in (1, 28):
        for server in dns_servers():
            name, done = host, False
            for _hop in range(6):
                try:
                    data = _dns_ask(server, name, qtype, timeout)
                    rcode, recs = _dns_records(data)
                except (OSError, struct.error, IndexError, ValueError) as e:
                    trouble.append('%s: %s' % (server, e))
                    break
                if rcode == 3:
                    done = True
                    break
                if rcode:
                    trouble.append('%s %s' % (server, DNS_RCODES.get(rcode, 'answered %d' % rcode)))
                    break
                cname, got = None, []
                try:
                    for rtype, _rname, at, size in recs:
                        if rtype == 1 and size == 4:
                            got.append(socket.inet_ntop(socket.AF_INET, data[at:at + 4]))
                        elif rtype == 28 and size == 16:
                            got.append(socket.inet_ntop(socket.AF_INET6, data[at:at + 16]))
                        elif rtype == 5:
                            cname, _ = _dns_name(data, at)
                except (struct.error, IndexError, ValueError, OSError) as e:
                    trouble.append('%s: an answer that does not read: %s' % (server, e))
                    break
                if got:
                    out += [g for g in got if g not in out]
                    done = True
                    break
                if cname and cname.rstrip('.').lower() != name:
                    name = cname.rstrip('.').lower()
                    continue
                done = True                     # no record of this type
                break
            if done:
                break
    if not out:
        raise MailError('no address found for %s%s' % (host, (': ' + '; '.join(trouble))
                                                       if trouble else ''))
    # IPv4 first: a machine with an IPv6 address and no IPv6 route waits out
    # the whole timeout on every server otherwise.
    return sorted(out, key=lambda a: ':' in a)


class _AddrSMTP(smtplib.SMTP):
    """smtplib, connecting to addresses already looked up; the host's name
    is still what the certificate is checked against. It keeps what the
    server answered to the message itself - "250 Ok: queued as 4Xy..." -
    which is what its own log is searched by (1.0.27)."""
    addrs = ()
    last_reply = None

    def data(self, msg):
        got = smtplib.SMTP.data(self, msg)
        self.last_reply = got
        return got

    def _get_socket(self, host, port, timeout):
        last = None
        for a in self.addrs or [host]:
            try:
                return socket.create_connection((a, port), timeout, self.source_address)
            except OSError as e:
                last = e
        raise last or OSError('no address to reach')


class _AddrSMTPS(smtplib.SMTP_SSL):
    addrs = ()
    last_reply = None

    def data(self, msg):
        got = smtplib.SMTP.data(self, msg)
        self.last_reply = got
        return got

    def _get_socket(self, host, port, timeout):
        sock = _AddrSMTP._get_socket(self, host, port, timeout)
        return self.context.wrap_socket(sock, server_hostname=self._host)


# ---- one conversation with one server ---------------------------------------------
def _xoauth2(user, token):
    return lambda challenge=None: 'user=%s\x01auth=Bearer %s\x01\x01' % (user, token)


def smtp_talk(store, host, port, security, auth, msg, to, steps, helo='', verify=None,
              timeout=None, direct=False):
    """Send one message through one server, writing down every step."""
    timeout = float(timeout or CONFIG.get('smtp_timeout_s') or 20)
    helo = str(helo or CONFIG.get('mail_helo') or socket.getfqdn() or 'localhost')
    ctx = mail_tls(store, verify)
    began = time.time()

    def step(what, ok=True, said=''):
        steps.append({'what': what, 'ok': ok, 'said': str(said or '')[:500]})

    # Going direct, the recipients' servers are looked up by the same DNS
    # servers that gave their MX records - A, AAAA and CNAME (1.0.23).
    # Only here, and only for mail going straight to the recipients, are
    # the DNS servers of `mail_dns` asked; with none set it is the system's
    # own resolver (/etc/hosts, nsswitch), as for everything else. (1.0.23)
    addrs = ()
    if direct:
        try:
            if own_dns():
                addrs = tuple(dns_addrs(host))
                how = 'DNS ' + ', '.join(own_dns())
            else:
                addrs = tuple(sorted({a[4][0] for a in socket.getaddrinfo(
                    host, port, 0, socket.SOCK_STREAM)}, key=lambda a: ':' in a))
                how = 'the system resolver'
            step('looked up %s' % host, True, ', '.join(addrs) + ' · ' + how)
        except (MailError, OSError) as e:
            step('look up %s' % host, False, e)
            raise MailError('no address found for %s: %s' % (host, e), steps)
    try:
        if security == 'tls':
            conn = _AddrSMTPS(local_hostname=helo, timeout=timeout, context=ctx)
            conn.addrs = addrs
            code, said = conn.connect(host, port)
            if code != 220:
                conn.close()
                raise smtplib.SMTPConnectError(code, said)
            step('reached %s:%d over TLS' % (host, port), True,
                 '%d ms' % int((time.time() - began) * 1000))
        else:
            conn = _AddrSMTP(local_hostname=helo, timeout=timeout)
            conn.addrs = addrs
            code, said = conn.connect(host, port)
            if code != 220:
                conn.close()
                raise smtplib.SMTPConnectError(code, said)
            step('reached %s:%d' % (host, port), True,
                 '%d ms' % int((time.time() - began) * 1000))
    except ssl.SSLCertVerificationError as e:
        step('reach the server %s:%d over TLS' % (host, port), False,
             'its certificate is not trusted: %s' % e.verify_message)
        raise MailError('the certificate of %s is not trusted - add the authority that '
                        'signed it, or switch the check off' % host, steps)
    except (OSError, smtplib.SMTPException) as e:
        step('reach the server %s:%d' % (host, port), False, e)
        raise MailError('%s:%d could not be reached: %s' % (host, port, e), steps)
    try:
        code, said = conn.ehlo()
        step('greeted it as %s' % helo, 200 <= code < 300, said.decode('utf-8', 'replace')
             .split('\n')[0] if isinstance(said, bytes) else said)
        if security in ('starttls', 'starttls-if'):
            if conn.has_extn('starttls'):
                try:
                    conn.starttls(context=ctx)
                except ssl.SSLCertVerificationError as e:
                    step('started TLS', False, 'its certificate is not trusted: %s'
                         % e.verify_message)
                    raise MailError('the certificate of %s is not trusted - add the authority '
                                    'that signed it, or switch the check off' % host, steps)
                conn.ehlo()
                cert = conn.sock.getpeercert() if hasattr(conn.sock, 'getpeercert') else None
                who = ''
                if cert:
                    who = ', '.join('%s=%s' % kv for part in cert.get('subject', ())
                                    for kv in part if kv[0] == 'commonName')
                step('started TLS', True, (conn.sock.version() if hasattr(conn.sock, 'version')
                                           else '') + ((' · ' + who) if who else ''))
            elif security == 'starttls':
                step('start TLS', False, 'the server does not offer STARTTLS')
                raise MailError('%s does not offer STARTTLS - choose TLS from the start, or '
                                'none' % host, steps)
            else:
                step('stayed in plain text', True, 'the server does not offer STARTTLS')
        if auth and auth != 'none' and not direct:
            user = str(CONFIG.get('smtp_user') or '')
            pw = unseal_secret(CONFIG.get('smtp_password') or '') or ''
            offered = (conn.esmtp_features.get('auth') or '').upper().split()
            try:
                if auth == 'auto':
                    conn.login(user, pw)
                elif auth == 'xoauth2':
                    conn.auth('XOAUTH2', _xoauth2(user, pw), initial_response_ok=True)
                else:
                    conn.user, conn.password = user, pw
                    mech = {'plain': 'PLAIN', 'login': 'LOGIN', 'cram-md5': 'CRAM-MD5'}[auth]
                    fn = {'PLAIN': conn.auth_plain, 'LOGIN': conn.auth_login,
                          'CRAM-MD5': conn.auth_cram_md5}[mech]
                    conn.auth(mech, fn, initial_response_ok=(mech != 'CRAM-MD5'))
                step('signed in as %s (%s)' % (user, auth.upper()), True,
                     'it offers: %s' % (' '.join(offered) or 'nothing'))
            except smtplib.SMTPAuthenticationError as e:
                step('sign in as %s (%s)' % (user, auth.upper()), False,
                     '%s %s' % (e.smtp_code, (e.smtp_error or b'').decode('utf-8', 'replace')))
                raise MailError('the mail server did not take the account or the password',
                                steps)
            except smtplib.SMTPException as e:
                step('sign in as %s (%s)' % (user, auth.upper()), False,
                     '%s · it offers: %s' % (e, ' '.join(offered) or 'nothing'))
                raise MailError('signing in failed: %s' % e, steps)
        if msg is not None:
            refused = conn.send_message(msg, to_addrs=list(to))
            if refused:
                step('handed the message over', False, '; '.join(
                    '%s: %s' % (k, v) for k, v in refused.items()))
                raise MailError('the server refused %s' % ', '.join(refused), steps)
            reply = getattr(conn, 'last_reply', None)
            said = ''
            if reply:
                said = ' · %s %s' % (reply[0], (reply[1] or b'').decode('utf-8', 'replace')
                                     if isinstance(reply[1], bytes) else reply[1])
            step('handed the message over', True, 'for %s%s' % (', '.join(to), said))
    except smtplib.SMTPRecipientsRefused as e:
        step('handed the message over', False, '; '.join(
            '%s: %s %s' % (k, v[0], v[1].decode('utf-8', 'replace') if isinstance(v[1], bytes)
                           else v[1]) for k, v in e.recipients.items()))
        raise MailError('the server would not take mail for %s' % ', '.join(e.recipients), steps)
    except smtplib.SMTPSenderRefused as e:
        step('handed the message over', False, '%s %s' % (e.smtp_code, (
            e.smtp_error or b'').decode('utf-8', 'replace')))
        raise MailError('the server would not take mail from %s' % e.sender, steps)
    except (smtplib.SMTPException, OSError) as e:
        if not isinstance(e, MailError):
            step('talking to it', False, e)
            raise MailError('the conversation with %s broke off: %s' % (host, e), steps)
        raise
    finally:
        try:
            conn.quit()
        except Exception:
            pass
    return steps


def mail_send(store, msg, to, mode=None):
    """Send `msg` to `to` ([addresses]) the way the settings say. Returns the
    steps; raises MailError with them where it failed."""
    mode = mode or CONFIG.get('mail_mode') or 'off'
    steps = []
    if mode == 'off':
        raise MailError('sending mail is switched off - Settings → Mail', steps)
    if mode == 'smtp':
        host = str(CONFIG.get('smtp_host') or '').strip()
        if not host:
            raise MailError('no mail server is set - Settings → Mail', steps)
        security = CONFIG.get('smtp_security') or 'starttls'
        port = int(CONFIG.get('smtp_port') or 0) or {'tls': 465, 'none': 25}.get(security, 587)
        return smtp_talk(store, host, port, security, CONFIG.get('smtp_auth') or 'auto', msg,
                         to, steps)
    # Straight to each domain's own server: one conversation per domain.
    by_domain = collections.OrderedDict()
    for one in to:
        by_domain.setdefault(one.rsplit('@', 1)[-1].lower(), []).append(one)
    port = int(CONFIG.get('mail_direct_port') or 25)
    for domain, who in by_domain.items():
        try:
            mxs, how = dns_mx_full(domain)
            mxs = [m for m in mxs if m[1] not in ('', '.')]
            if not mxs:
                raise MailError('%s takes no mail (its MX record is a null MX)' % domain)
        except MailError as e:
            steps.append({'what': 'look up the mail servers of %s' % domain, 'ok': False,
                          'said': str(e)})
            raise MailError(str(e), steps)
        steps.append({'what': 'looked up the mail servers of %s' % domain, 'ok': True,
                      'said': ', '.join('%s (%d)' % (h, p) for p, h in mxs) + ' · ' + how})
        last = None
        for _pref, host in mxs[:4]:
            try:
                smtp_talk(store, host, port,
                          'starttls' if CONFIG.get('mail_direct_tls') == 'required'
                          else 'starttls-if', 'none', msg, who, steps, direct=True)
                last = None
                break
            except MailError as e:
                last = e
        if last:
            raise MailError('no mail server of %s took it: %s' % (domain, last), steps)
    return steps


# ---- the QR code as a picture every mail program shows ----------------------------
def qr_png(text, scale=8, border=4):
    """A PNG of the QR code: mail programs do not show SVG."""
    q = QrCode(text, 'M')
    size = q.size + border * 2
    width = size * scale
    rows = []
    for y in range(-border, q.size + border):
        line = bytearray()
        for x in range(-border, q.size + border):
            dark = 0 <= x < q.size and 0 <= y < q.size and q.modules[y][x]
            line += (b'\x00' if dark else b'\xff') * scale
        rows.extend([b'\x00' + bytes(line)] * scale)
    raw = b''.join(rows)

    def chunk(kind, data):
        body = kind + data
        return struct.pack('>I', len(data)) + body + struct.pack('>I', zlib.crc32(body)
                                                                & 0xffffffff)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, width, 8, 0,
                                                            0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))


# ---- the token's mail, in Czech or in English --------------------------------------
MAIL_WORDS = {
    'cs': {
        'subject': 'Váš token pro přihlášení do VPN – {site}',
        'hello': 'Dobrý den, {name},',
        'hello_anon': 'Dobrý den,',
        'lede': 'pro účet <b>{account}</b> byl vytvořen token pro dvoufázové přihlášení. '
                'Kód z telefonu budete zadávat při přihlášení do VPN.',
        'step1': 'Nainstalujte si do telefonu aplikaci pro jednorázové kódy – například '
                 '<b>Microsoft Authenticator</b>, <b>Google Authenticator</b> nebo '
                 '<b>FreeOTP</b>.',
        'step2': 'V aplikaci zvolte přidání účtu a naskenujte tento QR kód:',
        'step3': 'Nejde-li kód naskenovat, zadejte do aplikace klíč ručně:',
        'key': 'Klíč',
        'facts': 'Typ: časový (TOTP) · {digits} číslic · platnost {period} s',
        'pending': 'Token začne platit, až ho potvrdíte prvním kódem z aplikace na stránce '
                   'registrace.',
        'codes_h': 'Záložní kódy',
        'codes_p': 'Každý platí jednou, místo kódu z telefonu – pro případ, že telefon ztratíte '
                   'nebo nebude po ruce. Uschovejte je jinde než v telefonu.',
        'warn': 'Tento e-mail je stejně cenný jako heslo: kdo má QR kód nebo klíč, může '
                'vytvářet vaše kódy. Po naskenování ho smažte a nikomu ho nepřeposílejte.',
        'foot': 'Vytvořil(a) {by} na {site}. Pokud jste token nečekali, obraťte se na správce.',
    },
    'en': {
        'subject': 'Your sign-in token for the VPN – {site}',
        'hello': 'Hello {name},',
        'hello_anon': 'Hello,',
        'lede': 'a token for two-step sign-in has been made for the account <b>{account}</b>. '
                'You will type the code from your phone when you sign in to the VPN.',
        'step1': 'Install an app for one-time codes on your phone – for example '
                 '<b>Microsoft Authenticator</b>, <b>Google Authenticator</b> or <b>FreeOTP</b>.',
        'step2': 'In the app, choose to add an account and scan this QR code:',
        'step3': 'If the code cannot be scanned, type the key into the app instead:',
        'key': 'Key',
        'facts': 'Type: time-based (TOTP) · {digits} digits · every {period} s',
        'pending': 'The token starts working once you confirm it with the first code from the '
                   'app on the enrolment pages.',
        'codes_h': 'Recovery codes',
        'codes_p': 'Each works once, in place of a code from the phone – for when the phone is '
                   'lost or not at hand. Keep them somewhere other than the phone.',
        'warn': 'This mail is worth as much as a password: whoever has the QR code or the key '
                'can make your codes. Delete it once the code is scanned, and do not forward it.',
        'foot': 'Made by {by} on {site}. If you did not expect this token, contact your '
                'administrator.',
    },
}


# The numbers of the steps as pictures for Outlook on Windows (1.0.31): it
# draws mail with Word, which has no round corners, and its own VML circles
# put the digit at the bottom edge. 56 px, shown at 28 for sharp screens;
# Inter Bold, white on #2563eb, on white. Every mail program gets the same
# pictures - one shown only to Outlook would be an attachment elsewhere.
MAIL_BADGES = {
    1: 'iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAIAAAAn5KxJAAAGh0lEQVR42tWaX4hc9RXHv+f87p+5szM7mdmw68ZQQjYYKpFEVCihraRi24XSB2mJJaValRQRLPqW+tBQQtOnioKItlqFpiFU+uBDFxEN1hIEFbM0KBE39iG62ZDMZGZnZ+b++Z3Thzvuzm43YXdm/4yH+3KZuff3ueff7/c750eqihWLKFRhuH0728R//pucvZCcv2inpuPKrF6tJaIMgEmGBp1insZG3d3bzb6dzm07nHzQftAKiMC08pFBKwRVhXyFONfSf39sJz6Mz34WT1eUjA+oSgK1KhZIX0jEBmSIHYDUhqNF2rfLHb/D/fatZiBDKS4TiNYO1Eob8eIVe+rd+PX3opnZAIDaJiRkAkAqUFLVhWGJlJSIAagowD6ZAMBIvvnjb3kHv+Nu32o6X94T6LwiZ5vy5zeiv74dN2xW4jojUkAFipXaj6DEIEDgsZvLmsbPv+c+8gMvH/BKVHsjUNG2G711Nj7+9+iLaxkbVRlWdRV8yxMTBMZ4hZu3tI781Ltnn9s53OpAU4tEsR5/LTz5L1KJSFoKdBq3FyFSApQzxN7PvqtHfuJ7Lt3ADZYHTR+YLiePvxCe+yJAdFUFgrVB7BSGEgPe0J6bm8/+yh8tOddjXQY0/etnXyYPP9OamXURV9OMs37CJHALI/n4pV9ndm1bnnUp6DzlA39sXq0b2Pp6Uy6wmtxQzr76ZLAsKy+JHsOYqdiHnt5QSgCiDFu/WjcPPd2cqVjDEL0OqCpUEVs8+lz98py3kZSdrJfnvEefq8e2zbM8qGEcO1n75FJ+A/zyuqxx9ZNL+WMna4aXA7UCZpyeDE+dyWhU3hTKeVaNyqfOZE5Phsyw0gGqCiLMtfToiQYkXOodmwELCY+eaMy1lKit1zYoE16caFxuFGCbvedLoo6rC04QbPNyo/DiRIPnQUVBhOmyvPJmrFFVe6NM58A4WbjmbbcqUZBG1VfejKfLQgRRcGr3E6ebEQ1C415mSMegEaoVDA1SKU+lPA0N0kCGdPWupErQOKLBE6ebqfVJVZuh3vObSrluIHF3/skEEMqzetsO59gvct/8hgOFAIbwjzOtI3+pF3O0WtUyAeyWcvat3xcDnxwA75yLKs089Jp0pU4mhImGMR7+fvDU/QO5YNFLutNoezGlUaW55Z1z0Q/v8BnAxPshmKBdxk2UYCjPf3p88Pgvc7mArG1n5cRCtUsfnXdVME28HwJw5lr6waeRxF1SWsFAhl57asuOERPF8FwYgziB63Qf9Z2cGjc++DSaaylPXoiv1F1I2F0YiSAX0PAWji08FzPX5PCztc9nkvSnHkWVIOGVujt5IeaPphIyPvfw4YmFCFyDNz6MfvTba6+/F7pmzVauTCDjfzSVOOcvJoDXw0fDNYgS/d3f5l74Z9NzUMp3GT03kPMXE2fqklWJIV1SMqMV6/1/qE5eSIo5ShW8hqICpXjqknUqNYVaJXQX9Q6j1tDybFLKkxWsuSgBais1dcp1q6roNjoVYELGXRfKr6YoW64Li3KXylycnNdTVJQ3bd256vBnEqzDPnhNhZiESzlDbIi0TxlJiU0pZ7g4SCDTr5wgBcgUB4nHbjLELnHfWh3E7thNhndvd/o/knZvd/j2MUdtKP1qelGoDW8fc3jvTndrLgb7fRhPRAr2t+bivTtdHsjQnbd47GbXMEWl5d/06mWBQgC72Ttv8QYyxADG7/IhuobJNOMRE3wXTPCcHuY9AkTH7/IBOADu3uMVg0q57jHFa+KsU9NJmJjEwjGYrojpKqUwAeQVg9m79xQBOFYQ+HTffv+ltwONriyp73UnjzxT67zNB90tWYSc/H37m4FPVsDprvnQgcDTGsjtk5AiUpDrae3QgSCtPHBaMxkt8YP3uuQVCP0BCiWv8OC97miJ04oTp5tJURwezw5nqzABbzYrQ2GC4Wz18Hg2rTi1i2Sp9QcydPRQFuyDN3sxxQT2jx7KpsWLBVAAhiGCA3v9g/tb5JWYZPMghbzSwf2tA3t96ajkLzQb5rP0wePVj7/MbErROW2P3LqtdepIgWlRO4+XFDVdg+cfyw0PRDC5DdZr2hgZHoiefyznmjZPh+Mu9g0rGCmal58IhnJ2I1nn2zcvPxGMFE3aHV0cYYvFMKxg1zbn1SeDkYLALWwAa7shVpDrNZnw9W4xdrL2e9N2ftH6NWiDd+asfj9YsMQN0M9HNf5ftejnwy+LtlqbdJzof5+gHCZfuYJ0AAAAAElFTkSuQmCC',
    2: 'iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAIAAAAn5KxJAAAIh0lEQVR42tWafYwU9RnHv8/zm5fd27fbO7zjkFh5URoLBQUTY0ULBpV/2j8soUYbrDY2xFSrsalY02IC2jRNiSbWiIWKlQDSJk1fAlWBpBhigy+QqgQDtE1QDnrssbcvszszv9/TP2Y51uOgO3sn4GT+ucnNzGef95chEUHLhxGIQHHjz5KHf/473HckPHhUHz4WDJbk5FBohAEwme6slc/QtD57xmQ1Z6o160ork2zcqA2IwNT6m0EtgorAnEas1OStj/S2d4N9h4Jjg0LKBURMCNFiNBA9kIgVSBFbAImu9+VpznR78Vz7pmtUKkERLhOIxg9Umwbi0QG9ZXfwp7f946UkANEeTJ0JAImBkIiceS2RkBAxADECsEsqCaA3433jBmfpfHvyBNX88DGBDguy5Jnf/M1/dWdQ1R0mKDN8AcRA0Kr+CEIMAgwcttMdqnrPQvt7tzuZJLci2vOBGmmY0Y59wTNb/U9OJbRfZGiRGHyjExMMlHJyl3fWVixxbp1jN78uHmikET+QZ35f3/R3EuOTqQnQrNyxHERCgHCC2LnrZlnxLdex6TxmMDpodMOxQvjQi/UPPknCPykGBuOD2HwwhBhwumde7j33fbevyzoX6yig0b8e+jS8/9na8ZKNoBhFnM/vYDKwc72ZYN3DiemTRmcdCTpMuexX3smygi5/3pRnWFW6O603PJoclZVHeI9iHB/U9625oJQAjDB0+WRZ3bfGOz6oFcPIOUBFIIJAY/nz5RMV50JSNrOeqDjLny8HusEzOqhirNo0dKA/cwHs8pysQfFAf2bVpiHFo4FqA2bs2l/fsichfuGiUA6zil/Ysiexa3+dGdo0gYqACJWarNxYhamPtI6LAQtTX7mxWqkJUUOuDVAmrN1WPVHNQXtjiZdRTdR6qTE6JwjaO1HNrd1W5WFQIyDCsYJ5+Y1A/GJ7uZGoEU2CEJ4vni9B2LjYHrGAxC++/EZwrGCIYAQc6X3jLs+nLCRoI0Mqhh+gUBJt0NPJMyZbV02yurPkB1IoSRC2VBydVQwRJPApu3GXF2mfRMSry61PDBbKCiaIa5+KcaoiU3rVXV9PLJjtXHGZSidIgKGq/Ks/3LHPf2137ZMBk0vRsFu0nAIAtrvSesfT+aRLJCLb360/so4lPGUMtUG55KbEU99J5dNnAggBfFqKJ06ZJ18p//kf9c42WFnI6lxzv7ljrssAtu2tgwnxZVmsyDdvcJ9bnsmnOdQwpnE9ogw1Qo2eTl77UPb2uc5QVWLbgABM2/bWAViVmrzzsW+C2N7jh+jp5NXL0gIYA0sBwM79/nuHAtemW2Y5X51iiTSKh6fvzew9OOiHEksgAkhQfedjv1ITa/+RYKBsQ+qx3IgJZU++fXOiO8tBCGYYwU9eLr+0vWopiODnr9GqZenvLkqSQBtM6uKFc5ytu2v5dAwDECEy9YGys/9IwO8fDkm5TO2EpPmzbAC2BcV471Cw7nXvshx3ZXhCll2bfrG1cnzQMMMYiGDWlVYUCuO6FCn3/cOhdfBoCDjxwwccC5WaHDmm/VAcm95837dOmyYA10alJkf6dW+eBUJEHS4RIG1lvYNHQ+twvxYTwMROcgmHVvy23HwxnTyjVmPg2NSbP+M+/y0aQWyJioFQcLhf8+CQQLSMa5dhKRSrMv8rztSJyggsJgB7DviOFbuOEAJEDw6JVShrEcH49UOKUa1Lb55X3pMCoDVsC2996L99IEgnyJg2UpQulA0bYUDGkbIWiGvRuh9mv9SjQg1LoVqXn71a4fYrRzHC41l3KobnS8KmDY/l5l1lhxpEIMKP1pU+/E+Ycmks9SMzmXHRu6VQqUlnijc93nnDlxuUivHUxvLW3fWuDIWm7WcTk+GutCJWRDJGyqGq9HWpLStyc6ZagQYTFGP15srzf/G6MxTFrDbnFKy60orzWQKpsXBaCqcqMr3P2vpEbsZkK9SNdP/T35Wf/WO1OxO7FvlsOw+QymeJp01UxDa1a6u2QqEks6dYW57IXdGjQg1mMOHH68u//mt1Qm5MlACIQWxPm6h4xmRrLLIcGJKvXWNveryzt5O1gaUiytKGN72+PEedbXSOxW9nTLasa6dZor02MptiFEpy21znxR9kO1yKhshlTx59qfTKDq8nxyeHZERtEM1v46ZA6Pq105LW7Kn2hPTQQMUlE6OAYkK5JovnOWsfztkKRsAMAjxfbr/OWTI/oZtCUdQ8Hj9lVm+umDhNGZGA3Qkpf/bUrJVK0Lyrndc/6JB6XWI8AnUft13n2gpBCEsBAgEuy/GdNyVGveVE0azeXIk5SQXZHfOuRipBDGDx9S5M7PaTCPVAojIvCuznKjii31+txTcvAowsvt4FYAG4ZaaTTw4Wyg5TjOaOCDVfihU5/6QYgAEYKHnxQJkAcvLJ0i0z8wAo1KIYv/xDZd3OpPgDrQ9zRJB0ybUbg5b/01IQtEE5DiuTIWfC/Qu9x+5MaQPSRgjoHzR3PDlUD0UkbN2ljEEsDbTe3BEJkeVatH1VdmKeBeBoZtLXxfcussnJxWpGFcO2Wj2j7i/GQsLJ3bvI7uviKGhw9FuN4IHFHT0dRagkt8wqp6eqLZ6tD/ahkj0dxQcWdwy3WQ1QEaQStPLuDrALHv+lQuyOjt2Vd3ekEiTNoJESjcGC2e7SG2vkdDGZiwdpyOlaemNtwWzXNE3yzywboiWdESx9pvjRp4mLMnSO1iPXTKptWZEbMb7kZq8kgq3wwoPpnpQPlb7Aco0WIz0p/4UH07YamUF4hG1og968Wv9IsjutLyTr8Ppm/SPJ3ryKtqOf9bCzIo42mD7J2vBosjdnYOcuAGtjIZYz51oy4Yu9YmxmvdSXtsNF6xdgDd4csy71DwtGmAEu5U81zhYtLuWPX5qt9mJ9TvQ/JPg5wMeLOXEAAAAASUVORK5CYII=',
    3: 'iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAIAAAAn5KxJAAAJRklEQVR42tWaf4xU1RXHv+fe+96bNz/3V8HlR4qAQi0IFm2Vag0i0Y1N/1AsIZpq1dKgia02NZWYSFtT06TVaGOMWCxGiSFtTatNV0QlbQ0VEQV/YEFXG7u6C9nd2Z2dmTfvx72nf7xxWLeL3Tcg4P1vJjP3ft45556fj5gZk16GwQwp6h9HPbzx72jPe9H+Xt3TFxZHebAUGRYABJn2vGrN0ZxOa94MuXi2WjhL5dz6H7UBEQRN/mTQJEGZYT5GrNT4xX26e3e4592wr8gkHYDZRGDNRgPxhkRCgiQJBRBrv7OVFs+1upZY558hMymKcQWB6NiBalNH7B3QW/4RPvVScHDUBcDag/EFASA2YGLmw8cSMTGRAMCGAeGQdAFMzXnfOtdedYE1o0OO3fyoQBuCHPXMb7cGj78QVnXahGWBgAE2YExWfwQmAQIMbGFl07J69UXWDZfYOVdMRrSfBmq4bkbP7wnv/n3w4XBKByMCmjkB38TEBAMp7cL0ltrtV9rLF1tjj0sGGmskCPnuP/hP/J3YBGRqDIxV7tEsIiaARYqEvfobfPtKx7boU8xgYtD4D31D0c0P+W9+6CIYZAODY4M4dgkwCcBuXzDdu//7TmebOhLrBKDxT9/9KLr+vtrBUQvhSOxxPrslyMAqTM2FG3+QmjttYtbxoA3Ka+7xBssSuvxZUx5mldn2rH70VndCVjHu9kiBg0V93b3HlRKAYQFdHizL6+71Dha1FDB8BFBmMCPUWPtA+VDFPp6UY1kPVey1D5RDXeeZGFQK3PVE6e3+3HGwyyOyhiNv9+fueqIkxUSg2kAIbN/rb9mR4mDohFA2WDkY2rIjtX2vLwS0GQPKDCJUarx+cxXGH28dJwIWxl+/uVqpMVFdrnVQQdjQXT1ULUB7TftLAgRBCEiRINuYgBME7R2qFjZ0V0UD1DCI0DdkNm0LORhpLjYKghTQDC/g0SqXqlz1OdJ14iYWgzgY2bQt7BsyRDAMEet983YvoDw4bCJCSgEv4GKZHQvzZ6oLF9rLFtkLT7WyLg1XuOKzTG7wzAQOA8pv3u7F2idm9nxevq44VJYwYVL7FIThCi+arb6z3L1ggTW9XTaw+otmx75w03Pey/vDQoY4+c4QVltWP/+LVtchYuZndvu3bBQcDRtDSfca9XjtZekfr0w7FgEwBpoPG0P8za/+WLnvz9WcS4mlIJhUy73Xm0uXOAJA9y4fgsCJNT5c4Ru/mb5jdcaxKNLx1rAkLAkpwEBkQITbrsys6XKHK8ltgAFB3bt8AKpS41cOBCZMrJeqz1/+orxtZSZ2dUoi0nhyR23XgVAbfG2etfL8lBLQBgTctjKzdXfQV9S2SmADDHBYfeVAUKmx2vteOFC2wH6iayQEvABXfD1lqXoe44e85v7S0zt9xyICNm71dv4r/PX3ckRgA9eh5YvtDd1eKg+tE1wpMv5A2d77Xihe64lIOkmdiGFYEqdNV0HEXsBhhK27g7/s9Ke1iZYMtWRoWpt4ckftnY+0IGhmZszulHUpJVQdSee1nkjt740AO7FPNkg7dOdjZceqB7aRKrfnRfixtJSAMaj6h7nCCIwmo8D+3kj19Gs2IUwTtQT6ioYNgwCGlCQFIh1/wsGiWXam/aWZ0jAIRISXD4Tqk3nGpLRvwBT29GtVLDFYMyVWCgBbxYET9HEum3aIGSmHLvuqs25VxrHIMCyFv70RPPdqkEuTTigRJoB1scRqqKyZGU1FzoZ4hMBohVcvS/3k2xmtkU9T3GJgRhjxtteCdZvKoqmEjJnAeqhslGHRjDAnul5ph6YURLyXH0JJ9A7o3zxVfez5mhBozVKom8t32LA4ZnknM5Ss51AEOBakwIwO+dOrs3/9ecuFC+3hMqujOI3m3XDo6IVKBD/E6dPlV+ZazMin6aw56pIlTiMUaYPr7hl5bk+QT26mAAkydN4PBwcroom8iYCx+mBGLWTPR5zsGMayM+2Hbs61ZESkYSn0DuiL1xV1wmyXiEFWe8aI1jyBJCUUKAGRwXCFhys8UuHhCgcRUja15ag1S+15mtpCW1/1N271iEAEYzCjQy6Za1VrycyNGCDZmic15xTZc8girk3elcaULRlavthuVDKvvx8NlEyjIpMCeZf29+rYMBhgRmebSCxRAQhrzims5s1Qz76e2CJDzR0FueHmfOPLDd3ejx4enfkFEYPGsers06zGsxGhWuPmItO8GUqcNUex9hNlioaRsuj9ft3TpyONMII2uPqi1HdXuGWPi2Uulnm0yteucK+5OBUXZCAEEd76IHIsJD2LtX/WHKUWzbY6sqWBikMmQQIlBYbK/PgL3p1XZcMIgpB26P61uTVd7tv/iZgxf6Y681QVJyFRBEvhqZdqBz7ULZkEt56IIZyOTLBodl5lUnT26fazb6bZ9yf/qNqgkKHfbfPOnW9dssRhRqRBhAWz1IJZqvGbWJyWwr4Pop9trqSdZEk+AWSlzz4dmRQJAF3nODCJy08ClKQbHxh95Fkv9vaN2iOWmRRQEkLg6Z3+6l+OlDxjyYRJCQGGu85x6t28pou72O+UPV5ymnXF+c55863pHTLtEBGqPvcNmlfeCf/0z9qLb4WORbYFk8TVjyvulDZwHbp8qbPxBZeDgXH9vf8bNgWhJUt73w93HQhzaerIi5xLRBj1eLBkSlVWErk0MSejjC8SqdzlSz3XIW1A2jAB/UVz6R0lP2LmqInSPu6LaINIQxsGIAQ1SjzTTLLLRMpR9Mxd+VNaBQMi7pl0tolrV1hkF6ipoG+4bpeWgmuTa5Ot6vepCcr6QMIuXLvC6mwTsd5E3dQYa7rSU9IjkK44igQljvKGE2fy4xr7kO6U9MiarnTccao3yeI0IpOi9VelIZwm20XHtE8O4ay/Kp1JEY8FjV2JMVi2yFm1tEZ2myBz4iAN2W2rltaWLXLMmE7+4WFDQ2ur7h7Z91HqhDSd4/HIGdNqW24vCPpE71KMdYpEsCQevCk7JRNAZo+zXOPByJRM8OBNWUvWeSaeigiCNpjaKh+5xW3P6uPJ2hjfPHKLO7VVxtPRI45vYmPVBnOnqUdvdacWDKzCcWCtD8QK5khDJny+R4xjWU/2oW0j3nwOxuBjfdbJ/mLBODPAyfyqxv+KFifzyy+fKLVO0OtE/wUdSLsWCTs8lAAAAABJRU5ErkJggg==',
    4: 'iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAIAAAAn5KxJAAAHvUlEQVR42tWae4xUVx3Hv7/fuffO3HnsMLvIlofGCgGDaKmCGoJW2lSyTTRFW9Esxoaa1qZGA5o01D+6Kin/mJKaYJXYpqQgIT7jI0SaQlDTmLRaiBsaSKGNge6yYWd2d+7Mnfs45+cfd1xml4Xs7Cy79OT+MTOZe+7nnt/j/B6HRATTHkYgAsWNrxUf/3knPnUhPntRnx+IyhUZHouNMAAm09VhFfO0fLG9apla+yHrox+08m7jRm1ABKbpPxk0TVARmP8jVuvyjzP66L+iU29FA2UhlQJETAzRYjSQTEjECqSILYBEB4uLtHaF3fMJe+NqlU1TgssEotkD1aaBePGKPvL36I//DC9XXACifZiACQCJgZCIXH0skZAQMQAxAnCKlAugO+9/8dPO1s/Yyxaq5snbAh1fyIpvfvnX8ODxqKYzJvIYoQBiIJiu/AhCDAIMHLZzGVXbdrf9zc1O3uXpLO2NQI001OiVU9GeX4eXRtI6HGVokRb4piYmGCjlFJYuqO960Llnrd38uNZAE4mEkez5TXD4byQmJFMXoFm47QwiIUA4Tex87bOy64GUY9MN1GBq0OSGgVL8nV8E/ZdchMNiYDA7iM2DIcSA07Vmqf/TR1OLO63rsU4Bmvz1rXfjh5+tX67YiEYTj3PzBpOBXejOR89/N71iydSsk0HHKb/xjD/sKWjvZlNeZVW5rpw+sNOdkpUnWY9iXC7r7XvnlBKAEYb2hj21fa9/uawVw8h1QEUggkjjsX3eUNWZS8pm1qGq89g+L9INnqlBFWP34bE3B/NzoJfXZY1G3xzM7z48pngqUG3AjBOngyOvpiUszQvlOKuEpSOvpk+cDpihTROoCIhQrUvfoRpMMFk75gMWJug7VKvWhaixrg1QJuw/WhuqFaD99v0lAUQTrtY4QdD+UK2w/2iNx0GNgAgDJfPiy5GEo9I+JcEIonjC1eoQkISjL74cDZRMMiEncj90wg+pAxK1uUMSQWvYFro6qDNPXR2UfOAWZxUhSBRSx6ETfiJ9EhE/kHueLJc8BRO1r58i+NUThZVLLRGAQIA2+NLukbcHY9eh6c/PBLDdmdOvPF10U8QATvaHZT8PCduktBRGPHn0Pnf9SruQpQU5WpClQnYmK5pYFCQs+/mT/WHDmI6+FoAJ7VEywavLx263vv2FjDYwphHLisxER8dVFUxHXwsAWNW6vH4uNFH7cRu0Qd+2XNqhxCs3e4AZc0pUe/1cWK0Ln74QXfFsmKAdM7IUyhXp/Vx640fscUpj2ld3ggmuePbpCxG/cT4mlWJqy9LrId7/Pn7iK9lEywn42Z9r1fosxNhMIJV643zMZy/Gbc6lCNW6/OCrua48x1oU49i/w4PH6zl31gLtsxdj6/ygFhNhpmJSjHJVetY7WzakYg2LyQ+l75BnWzNXzQnSNxCKzg9qLo8JRM9MSATEGoUsPdWbAyAizNj3p1r/O3E2TbMSMggBostjwiVPi9EzsySlMFqVHfdnb+9WUQzbojP/jX/+F7+Yo1jPjtBFSIwueZqNMGbkQplRqcmnPmxv3+wmlm4ET73kBbEont00UIwwt/GuYMYPt2VtBW1EMQ4e90/2Rx0Z0jchUGQmg9YjJkuhVJHtm92Pr7AjDceioRHzzO9qxRwRoHhyapb8oma4LMRkuDOniBWRtOTbaoGs/oDauSVrDJgQxdixv3LukvZ8Ga5IqSKj1QkTjlSlVJGxmrTupIVYdeaUVeyg4ZoiE0kLN8MP8K37MnmXYg1LIYjk/g2pBzamRYQI2qAjw+PuiRk/+nquWjcDJfPsH2pKYfqlThIIq2KHWMtvU+eHbJJ6S66UCHm34YBEkEnRgxvTN5BAzzoHwIVBvff3NdWa1AG2l98mvGqZNeMohAmWmpZjT5awFszQyFYts6w7l1uifZFWVQdjNSl7JtZTmIgAtqKOzNU3KHsCTFbc6UalOrhzuUuebz7/5PCVqtNSACUCN0W2msIDM6PqyydX2Qe+V0gqibHGlh+PvD0YOxZ5dWnJksCphdnw2NNdVjZN61Y6x/ozEgQt2VMtmLpiyQzPl4ovRhqJtxGM1WSkKq7TWgBAANmZdSuRTRMD6Fmfgmk5/VQES13nYtgWmGAxmOBYsBUshqVaNgMY6VmfAmABuGuNU3TLJc9haiG5E0y99SZprR/IhUGdfNYaYQwQWrIEJoCcolu5a00RACUR5E9+W33+uCvhlXks5lxbiCRn4cN3+9//clYbcJI1925yHRkD2S1tUTdvEAnIdmSsd5ObiIWTmsniTn7oXpucQrvJ6GyBQsgpPHSvvbiTk4oTjxdhHunJLMqMQrk836wMgXIXZUYf6ckkFadGXp9IP5umvt4MOAWmeVdPcKqvN5NNkzSDJmGYMdh0R2rrhjo5nUxmXm2oc+uG+qY7Uqapkn+12ZAUNoxg657RM++m56XonLRHVi+pH9lVYJrQzuPmzYYItsJzj+cWZUOo3Byva9IYWZQNn3s8Z6vJhVWepBvaoLuoXtjhduX0XLKOt29e2OF2F1XSHZ1oYdfk6dpgxRLrwE63u2BgF+aAtdEQK5jrNZnw3m4xNrPe6k3b8aD1PdAGb/ZZt/rBgklqgFv5qMa1S4tb+fBLs9bO13Gi/wE33N3OMZyRlAAAAABJRU5ErkJggg==',
}


def _h(text):
    return html.escape(str(text or ''), quote=True)


def token_mail(to, name, picture, codes=None, lang='cs', display='', by='', pending=False,
               portal_url=''):
    """The mail a token's owner gets: the QR code inline, the key, and the
    recovery codes where wanted - laid out in tables with the styles written
    on each element, which is what every mail program shows the same."""
    w = MAIL_WORDS.get(lang) or MAIL_WORDS['cs']
    site = str(CONFIG.get('site_name') or socket.gethostname())
    issuer = picture.get('issuer') or site
    fmt = {'site': _h(site), 'name': _h(display or name), 'account': _h(name), 'by': _h(by),
           'digits': picture.get('digits'), 'period': picture.get('period')}
    cid = make_msgid(domain='otp.local')[1:-1]
    hello = (w['hello'] if display else w['hello_anon']).format(**fmt)
    key = picture.get('secret_spaced') or picture.get('secret') or ''
    font = ("font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;")
    # Tables and attributes, not floats and inline blocks (1.0.29): Outlook
    # draws mail with Word, which ignores width, height and border-radius on
    # anything but a table cell - the numbered badges came out as a sliver
    # and the recovery codes ran together into one long number.
    def nobreak_link(text):
        # Outlook and others make every name@domain a link; a zero-width
        # joiner after the @ keeps it plain text, the way it reads.
        return ('<span style="white-space:nowrap">%s</span>'
                % _h(text).replace('@', '@&#8205;'))
    fmt['account'] = nobreak_link(name)
    txt = 'font-size:15px;line-height:1.55;color:#111827;'

    badge_cid = {n: make_msgid(domain='otp.local')[1:-1] for n in MAIL_BADGES}

    def step(n, words, extra=''):
        return ('<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                'border="0" style="margin:0 0 %s"><tr>'
                '<td width="40" valign="top" style="width:40px;padding:1px 0 0">'
                # A picture of the number in its circle (1.0.31): the one
                # thing Outlook on Windows draws the same as everybody else.
                '<img src="cid:%s" width="28" height="28" alt="%d" '
                'style="display:block;width:28px;height:28px;border:0"></td>'
                '<td valign="top" style="padding-top:3px;%s%s">%s%s</td></tr></table>'
                % ('16px' if not extra else '8px', badge_cid[n], n, txt, font, words, extra))

    rows = []
    rows.append('<p style="margin:0 0 6px;font-size:16px;color:#111827">%s</p>' % hello)
    rows.append('<p style="margin:0 0 24px;font-size:15px;line-height:1.55;color:#374151">%s</p>'
                % w['lede'].format(**fmt))
    rows.append(step(1, w['step1']))
    rows.append(step(2, w['step2']))
    rows.append('<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                'border="0" style="margin:4px 0 20px"><tr><td align="center">'
                '<table role="presentation" cellspacing="0" cellpadding="0" border="0"><tr>'
                '<td align="center" bgcolor="#ffffff" style="padding:10px;border:1px solid #e5e7eb;'
                'border-radius:12px;background:#ffffff"><img src="cid:%s" width="220" height="220" '
                'alt="QR" style="display:block;width:220px;height:220px;border:0"></td></tr></table>'
                '<div style="margin-top:8px;font-size:13px;color:#6b7280;%s">%s · %s</div>'
                '</td></tr></table>'
                % (cid, font, _h(issuer), nobreak_link(picture.get('label') or name)))
    rows.append(step(3, w['step3']))
    rows.append('<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                'border="0" style="margin:0 0 6px"><tr><td style="padding-left:40px">'
                '<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                'border="0"><tr><td align="center" bgcolor="#f3f4f6" style="padding:12px 10px;'
                'background:#f3f4f6;border-radius:8px;font-family:Consolas,Menlo,\'Courier New\','
                'monospace;font-size:15px;font-weight:700;letter-spacing:1px;color:#111827;white-space:nowrap">%s'
                '</td></tr></table>'
                '<div style="margin:6px 0 0;font-size:12.5px;color:#6b7280;text-align:center;%s">'
                '%s</div></td></tr></table>' % (_h(key), font, w['facts'].format(**fmt)))
    rows.append('<div style="height:18px;line-height:18px;font-size:1px">&nbsp;</div>')
    if pending:
        rows.append('<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                    'border="0" style="margin:0 0 20px"><tr><td bgcolor="#eff6ff" '
                    'style="padding:12px 16px;background:#eff6ff;border-left:4px solid #2563eb;'
                    'font-size:14px;line-height:1.5;color:#1e3a8a;%s">%s%s</td></tr></table>'
                    % (font, w['pending'], (' <a href="%s" style="color:#1d4ed8">%s</a>'
                                            % (_h(portal_url), _h(portal_url)))
                       if portal_url else ''))
    if codes:
        codes = [str(c) for c in codes]
        per = 5 if len(codes) % 5 == 0 or len(codes) > 6 else (3 if len(codes) % 3 == 0 else 4)
        per = min(per, len(codes))
        lines = []
        for at in range(0, len(codes), per):
            chunk = codes[at:at + per]
            cells = []
            for c in chunk:
                cells.append('<td align="center" width="%d%%" style="padding:4px">'
                             '<table role="presentation" width="100%%" cellspacing="0" '
                             'cellpadding="0" border="0"><tr><td align="center" bgcolor="#f9fafb" '
                             'style="padding:9px 2px;background:#f9fafb;border:1px solid #d1d5db;'
                             'border-radius:6px;font-family:Consolas,Menlo,\'Courier New\','
                             'monospace;font-size:14px;font-weight:700;letter-spacing:.5px;'
                             'color:#111827;white-space:nowrap">%s</td></tr></table></td>' % (100 // per, _h(c)))
            cells += ['<td width="%d%%" style="padding:4px">&nbsp;</td>' % (100 // per)] * (
                per - len(chunk))
            lines.append('<tr>%s</tr>' % ''.join(cells))
        rows.append('<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                    'border="0" style="margin:0 0 22px"><tr><td bgcolor="#ffffff" '
                    'style="padding:16px 16px 12px;border:1px solid #e5e7eb;border-radius:10px">'
                    '<div style="font-size:15px;font-weight:700;color:#111827;%s">%s</div>'
                    '<div style="margin:4px 0 10px;font-size:13.5px;line-height:1.5;color:#4b5563;'
                    '%s">%s</div>'
                    '<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                    'border="0">%s</table></td></tr></table>'
                    % (font, w['codes_h'], font, w['codes_p'], ''.join(lines)))
    rows.append('<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
                'border="0"><tr><td bgcolor="#fff7ed" style="padding:12px 16px;background:#fff7ed;'
                'border-left:4px solid #f59e0b;font-size:13px;line-height:1.5;color:#7c2d12;%s">'
                '%s</td></tr></table>' % (font, w['warn']))
    body = ''.join(rows)
    page = ('<!doctype html><html lang="%s" xmlns:v="urn:schemas-microsoft-com:vml" '
            'xmlns:o="urn:schemas-microsoft-com:office:office"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1"><title>%s</title>'
            '<!--[if mso]><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch>'
            '</o:OfficeDocumentSettings></xml><![endif]--></head>'
            '<body style="margin:0;padding:0;background:#f3f4f6;%s">'
            '<table role="presentation" width="100%%" cellspacing="0" cellpadding="0" '
            'border="0" bgcolor="#f3f4f6" style="background:#f3f4f6"><tr><td align="center" '
            'style="padding:28px 12px">'
            '<table role="presentation" width="560" cellspacing="0" cellpadding="0" border="0" '
            'bgcolor="#ffffff" style="max-width:560px;width:100%%;background:#ffffff;border-radius:14px;'
            'overflow:hidden;border:1px solid #e5e7eb">'
            '<tr><td bgcolor="#1e3a8a" style="background:#1e3a8a;padding:20px 28px;'
            'color:#ffffff;%s">'
            '<p style="margin:0;font-size:12px;letter-spacing:1.5px;text-transform:uppercase;'
            'color:#c7d2fe">%s</p><p style="margin:4px 0 0;font-size:20px;font-weight:700;'
            'color:#ffffff">%s</p></td></tr>'
            '<tr><td style="padding:26px 28px;%s">%s</td></tr>'
            '<tr><td style="padding:14px 28px 22px;font-size:12px;color:#9ca3af;%s;'
            'border-top:1px solid #f3f4f6">%s</td></tr></table></td></tr></table></body></html>'
            % (lang, _h(w['subject'].format(**fmt)), font, font, _h(issuer),
               'VPN · ' + ('Dvoufázové přihlášení' if lang == 'cs' else 'Two-step sign-in'),
               font, body, font, w['foot'].format(**fmt)))
    text = [re.sub('<[^>]+>', '', hello), '',
            re.sub('<[^>]+>', '', w['lede'].format(**fmt)), '',
            '1. ' + re.sub('<[^>]+>', '', w['step1']),
            '2. ' + re.sub('<[^>]+>', '', w['step2']) + ' (QR)',
            '3. ' + re.sub('<[^>]+>', '', w['step3']), '', '   ' + key, '',
            re.sub('<[^>]+>', '', w['facts'].format(**fmt)), '']
    if pending:
        text += [re.sub('<[^>]+>', '', w['pending']) + (' ' + portal_url if portal_url else ''),
                 '']
    if codes:
        text += [w['codes_h'] + ':', '   ' + '   '.join(codes), '',
                 re.sub('<[^>]+>', '', w['codes_p']), '']
    text += [re.sub('<[^>]+>', '', w['warn']), '', '-- ',
             re.sub('<[^>]+>', '', w['foot'].format(**fmt))]
    msg = EmailMessage()
    msg['Subject'] = w['subject'].format(site=site)
    sender = str(CONFIG.get('mail_from') or '').strip()
    if not sender:
        raise MailError('no sender address is set - Settings → Mail → From (address)')
    msg['From'] = formataddr((str(CONFIG.get('mail_from_name') or site), sender))
    msg['To'] = to
    if CONFIG.get('mail_reply_to'):
        msg['Reply-To'] = str(CONFIG.get('mail_reply_to'))
    msg['Date'] = formatdate(localtime=True)
    msg['Message-ID'] = make_msgid(domain=sender.rsplit('@', 1)[-1] or None)
    msg['Auto-Submitted'] = 'auto-generated'
    msg.set_content('\n'.join(text))
    msg.add_alternative(page, subtype='html')
    msg.get_payload()[1].add_related(qr_png(picture['uri']), 'image', 'png', cid='<%s>' % cid,
                                     filename='qr.png', disposition='inline')
    for n in (1, 2, 3):
        msg.get_payload()[1].add_related(base64.b64decode(MAIL_BADGES[n]), 'image', 'png',
                                         cid='<%s>' % badge_cid[n], filename='%d.png' % n,
                                         disposition='inline')
    return msg


def test_mail(to, lang='cs'):
    site = str(CONFIG.get('site_name') or socket.gethostname())
    msg = EmailMessage()
    msg['Subject'] = ('Zkušební zpráva z %s' if lang == 'cs' else 'A test message from %s') % site
    sender = str(CONFIG.get('mail_from') or '').strip()
    if not sender:
        raise MailError('no sender address is set - Settings → Mail → From (address)')
    msg['From'] = formataddr((str(CONFIG.get('mail_from_name') or site), sender))
    msg['To'] = to
    msg['Date'] = formatdate(localtime=True)
    msg['Message-ID'] = make_msgid(domain=sender.rsplit('@', 1)[-1] or None)
    msg.set_content(('Tato zpráva ověřuje, že %s umí odesílat poštu. Není třeba nic dělat.'
                     if lang == 'cs' else 'This message checks that %s can send mail. '
                     'Nothing needs doing.') % site)
    return msg

# ---------------------------------------------------------------------------
# Two servers, both answering: high availability, active/active (1.0.13)
# ---------------------------------------------------------------------------
# Both nodes open the same PostgreSQL and keep nothing that matters anywhere
# else, so that a load balancer may send any request - a RADIUS packet, a
# page, the second half of an enrolment - to either, round robin and without
# stickiness:
#
#   * every setting, client, realm, directory and token is in the database,
#     and a node that sees another node's change (`conf_serial`) reads it in
#     within five seconds;
#   * a sign-in is a row in the database, and so is what belongs to it (the
#     "Edit the columns" switch); a job's progress (a move, an erase) is in
#     the database too, so the bar keeps moving whichever node is asked;
#   * a code is used up with one conditional UPDATE - two nodes asked for the
#     same code at the same moment cannot both let it in;
#   * the nightly dump is claimed by one node, with one conditional UPDATE;
#   * the key that seals the tokens is the same file on both, carried to the
#     second node once in a bundle locked with a passphrase.
#
# Each node writes a heartbeat into the database every fifteen seconds; the
# pages show the nodes and how long since each was heard from.

HA_KIND = 'otp-ha-join'
HA_STORE = {'store': None}
HEARTBEAT_S = 15


def node_name():
    return this_node_name()


def node_address():
    """The address this machine uses to reach the outside - what a peer would
    use to reach it."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('192.0.2.1', 9))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return ''


# Set while this node is rebuilt from the other (1.0.44): it answers nothing
# and writes nothing until every row has come over.
HA_REBUILDING = threading.Event()


def heartbeat(store, daemon=None):
    if HA_REBUILDING.is_set():
        return {}                       # nothing written while the rows come over (1.0.44)
    beat = {'at': time.time(), 'version': __version__, 'address': node_address(),
            'host': socket.gethostname(), 'started': daemon.started if daemon else None,
            'radius': list(getattr(getattr(daemon, 'radius', None), 'bound', []) or []),
            'engine': store.db.engine,
            'maintenance': bool(maintenance_now(store).get('on'))}
    try:
        beat['web'] = web_state(store)          # TLS and the web address (1.0.47)
    except Exception:                                   # noqa: BLE001
        pass
    store.set_meta('node:' + node_name(), json.dumps(beat))
    return beat


def ha_nodes(store):
    out = []
    try:
        rows = store.db.rows("SELECT k, v FROM meta WHERE k LIKE 'node:%'")
    except Exception:                                   # noqa: BLE001
        rows = []
    now = time.time()
    for r in rows:
        try:
            beat = json.loads(r['v'] or '{}')
        except ValueError:
            continue
        name = r['k'][5:]
        age = now - float(beat.get('at') or 0)
        beat.update(name=name, age=age, me=name == node_name(),
                    alive=age < HEARTBEAT_S * 3)
        out.append(beat)
    out.sort(key=lambda b: (not b['me'], b['name']))
    return out


def ha_forget(store, name):
    if name == node_name():
        raise ValueError('this is the node answering: it would write itself back at once')
    store.db.run('DELETE FROM meta WHERE k = ?', ('node:' + name,))


def claim_once(store, key, value):
    """True for exactly one node: the one whose conditional UPDATE changed the
    row. A key not there yet is made first; two nodes making it at the same
    moment cannot both insert it (it is the primary key)."""
    if store.get_meta(key) is None:
        try:
            store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)', (key, ''))
        except Exception:                               # noqa: BLE001
            pass
    return bool(store.db.run('UPDATE meta SET v = ? WHERE k = ? AND (v IS NULL OR v <> ?)',
                             (str(value), key, str(value))))


# ---- a job's progress, where both nodes can read it ------------------------------
def job_publish(job):
    store = HA_STORE.get('store')
    if not store or HA_REBUILDING.is_set():
        return
    try:
        store.set_meta('db_job:' + node_name(), json.dumps(dict(job, node=node_name(),
                                                                at=time.time()),
                                                           default=str))
    except Exception:                                   # noqa: BLE001
        pass


def job_read():
    """The job as the database has it - this node's, or the other's."""
    if DB_JOB.get('running') or DB_JOB.get('ended'):
        here = dict(DB_JOB, node=node_name())
    else:
        here = None
    store = HA_STORE.get('store')
    there = None
    if store:
        try:
            for r in store.db.rows("SELECT v FROM meta WHERE k LIKE 'db!_job:%' ESCAPE '!'"):
                one = json.loads(r['v'] or 'null')
                # Going on, by the word of a node that has not said so for
                # five minutes - or of this node, which is not running it:
                # it ended with the process that ran it (1.0.37).
                if one and one.get('running') and (
                        time.time() - float(one.get('at') or one.get('began') or 0) > 300 or
                        (one.get('node') == node_name() and not DB_JOB.get('running'))):
                    one = dict(one, running=False, ended=float(one.get('at') or 0),
                               error=one.get('error') or 'it stopped with the service that '
                               'ran it (restarted, or the database was changed)')
                if one and (not there or float(one.get('began') or 0) >
                            float(there.get('began') or 0)):
                    there = one
        except Exception:                               # noqa: BLE001
            there = None
    if here and (not there or float(here.get('began') or 0) >= float(there.get('began') or 0)):
        return here
    return there or dict(DB_JOB)


# ---- the bundle that carries a cluster to its second node --------------------------
def _bundle_key(passphrase, salt):
    return hashlib.scrypt(str(passphrase).encode('utf-8'), salt=salt, n=2 ** 15, r=8, p=1,
                          maxmem=64 * 1024 * 1024, dklen=32)


def bundle_lock(data, passphrase):
    salt = secrets.token_bytes(16)
    key = _bundle_key(passphrase, salt)
    raw = json.dumps(data).encode('utf-8')
    nonce = secrets.token_bytes(16)
    hide = hmac.new(key, b'hide', hashlib.sha256).digest()
    sign = hmac.new(key, b'sign', hashlib.sha256).digest()
    body = bytes(a ^ b for a, b in zip(raw, _seal_stream(hide, nonce, len(raw))))
    tag = hmac.new(sign, salt + nonce + body, hashlib.sha256).digest()
    return {'kind': HA_KIND, 'format': 1, 'made': time.time(), 'from': node_name(),
            'version': __version__,
            'locked': base64.b64encode(salt + nonce + body + tag).decode('ascii')}


def bundle_open(bundle, passphrase):
    if isinstance(bundle, str):
        try:
            bundle = json.loads(bundle)
        except ValueError:
            raise ValueError('that is not a bundle made by otp --ha-bundle: it is not JSON')
    if not isinstance(bundle, dict) or bundle.get('kind') not in (HA_KIND, 'opt-ha-join'):
        raise ValueError('that is not a bundle made by otp --ha-bundle')
    try:
        raw = base64.b64decode(bundle.get('locked') or '')
    except (ValueError, TypeError):
        raise ValueError('the bundle is damaged')
    if len(raw) < 16 + 16 + 32:
        raise ValueError('the bundle is damaged')
    salt, nonce, body, tag = raw[:16], raw[16:32], raw[32:-32], raw[-32:]
    key = _bundle_key(passphrase, salt)
    sign = hmac.new(key, b'sign', hashlib.sha256).digest()
    if not hmac.compare_digest(tag, hmac.new(sign, salt + nonce + body, hashlib.sha256).digest()):
        raise ValueError('the passphrase is not the one the bundle was locked with')
    hide = hmac.new(key, b'hide', hashlib.sha256).digest()
    data = json.loads(bytes(a ^ b for a, b in zip(body, _seal_stream(hide, nonce, len(body))))
                      .decode('utf-8'))
    data['_from'] = bundle.get('from')
    data['_made'] = bundle.get('made')
    return data


def ha_passphrase():
    words = 'abcdefghijkmnopqrstuvwxyz23456789'
    return '-'.join(''.join(secrets.choice(words) for _ in range(5)) for _ in range(5))


def ha_checks(store):
    """What has to be true before a second node can join, each with its
    answer: the database, its address as the other node will see it, the
    key."""
    db = store.db
    host = str(CONFIG.get('db_host') or '')
    local = host in ('', 'localhost', '127.0.0.1', '::1')
    mode = CONFIG.get('ha_mode') or ''
    out = [
        {'key': 'engine', 'ok': db.engine == 'postgres',
         'says': 'the database is PostgreSQL' if db.engine == 'postgres' else
         'the database is %s: a cluster needs PostgreSQL, which both nodes open - move to it '
         'first (Settings → The database)' % ENGINE_WORDS.get(db.engine, db.engine)},
        {'key': 'key', 'ok': bool(sealing_key()),
         'says': 'the key that seals the tokens is there' if sealing_key() else
         'the key that seals the tokens is missing'},
    ]
    if mode == 'replicated' and db.engine == 'postgres':
        # Made two already (1.0.43): each node has its own PostgreSQL here,
        # and the other node never opens it - nothing to warn of.
        out.append({'key': 'address', 'ok': True,
                    'says': 'this node is one of two already: each has its own PostgreSQL '
                            'and they replicate to each other'})
        return out
    out += [
        {'key': 'address', 'ok': not local or db.engine != 'postgres',
         'warn': local and db.engine == 'postgres',
         'says': ('PostgreSQL is reached at %s, which the other node can use as well' % host)
         if not local else ('PostgreSQL is on this machine (%s): the other node reaches it at '
                            'this machine\'s address - it has to listen there and let the other '
                            'node in (otp --ha-setup does both, as root)' % (host or 'localhost'))},
    ]
    return out


def ha_bundle_data(store, peer_db_host='', with_tls=None):
    """What the second node needs and nothing else: how to open the
    database, the key that opens the tokens, and the name of the cluster."""
    if store.db.engine != 'postgres':
        raise ValueError('a cluster needs PostgreSQL: move to it first (Settings → The database)')
    key = sealing_key()
    if not key:
        raise ValueError('the key that seals the tokens is missing')
    db = {k: CONFIG.get(k) for k in DB_KEYS}
    host = str(db.get('db_host') or '')
    if peer_db_host:
        db['db_host'] = peer_db_host
    elif host in ('', 'localhost', '127.0.0.1', '::1'):
        db['db_host'] = node_address()
    data = {'db': db, 'key': key.hex(), 'cluster': CONFIG.get('site_name') or 'otp',
            'peer': {'name': node_name(), 'address': node_address()}}
    if with_tls:
        data['tls'] = with_tls
    return data


def ha_join(data, name='', even_if_data=False, by=''):
    """This node into the cluster: the database's address into config.json and
    the key beside it. The daemon starts again on it afterwards."""
    db = data.get('db') or {}
    if db.get('db_engine') != 'postgres':
        raise ValueError('the bundle does not name a PostgreSQL')
    key_hex = str(data.get('key') or '')
    if not re.match(r'^[0-9a-f]{64}$', key_hex):
        raise ValueError('the bundle holds no key')
    got = db_try(db)
    if not got.get('reached'):
        raise ValueError('the database in the bundle cannot be reached from here: %s'
                         % (got.get('trouble') or 'no answer'))
    now = sealing_key()
    if now and now.hex() != key_hex and not even_if_data:
        # This node has a key of its own: whatever it sealed would be lost.
        store = HA_STORE.get('store')
        mine = 0
        if store and store.db.engine == 'sqlite':
            try:
                mine = int(store.db.value('SELECT COUNT(*) FROM tokens') or 0)
            except Exception:                           # noqa: BLE001
                mine = 0
        if mine:
            raise ValueError('this node holds %d token(s) of its own, sealed with another key; '
                             'joining replaces both its database and its key. Say so to go on '
                             '(--yes, or tick it on the page)' % mine)
    if now and now.hex() != key_hex:
        backup = sealing_key_path().with_name('secrets.key.before-join')
        write_replacing(backup, now.hex() + '\n', 0o600)
    write_replacing(sealing_key_path(), key_hex + '\n', 0o600)
    changes = {k: db.get(k) for k in DB_KEYS if k in db}
    if name:
        changes['node_name'] = name
    write_file_settings(changes)
    return {'where': db_where(db), 'rows': got.get('rows'), 'peer': data.get('peer') or {},
            'message': 'this node joins the cluster: it starts again on %s' % db_where(db)}


# ---- the PostgreSQL side, as root on the machine it runs on ------------------------
def pg_local_admin(sql, secret=False):
    """A statement run as the postgres account on this machine (root only).
    The SQL goes in on standard input, never on the command line, where
    every process on the machine could read it; `secret` marks one that
    carries a password, which is then kept out of PostgreSQL's own log."""
    for runner in (['runuser', '-u', 'postgres', '--'], ['su', '-s', '/bin/sh', 'postgres', '-c']):
        if not shutil.which(runner[0]):
            continue
        if runner[0] == 'su':
            args = runner + ['psql -XAtq -v ON_ERROR_STOP=1 -f -']
        else:
            args = runner + ['psql', '-XAtq', '-v', 'ON_ERROR_STOP=1', '-f', '-']
        got = subprocess.run(args, capture_output=True, text=True, timeout=30,
                             input=pg_script(sql, secret))
        if got.returncode == 0:
            return got.stdout.strip()
        raise ValueError(scrub_secret((got.stderr or got.stdout).strip()[:300]) or 'psql failed')
    raise ValueError('neither runuser nor su is here')


PG_QUIET = "SET log_statement = 'none'; SET log_min_error_statement = 'panic';\n"


def pg_script(sql, secret=False):
    """The statement as psql reads it from its standard input - for one with
    a password in it, after switching the logging of statements off for the
    session, so the password lands in no log."""
    return (PG_QUIET if secret else '') + str(sql).rstrip().rstrip(';') + ';\n'


def shlex_quote(s):
    import shlex
    return shlex.quote(s)


def peer_address(text):
    """The other node's address - one address, never a range: ValueError
    otherwise."""
    said = str(text or '').strip()
    if not said:
        raise ValueError('the other node\'s address is needed')
    try:
        return ipaddress.ip_address(said)
    except ValueError:
        raise ValueError('%s is not an address (one address, not a range or a name)' % said)


def peer_net(text):
    """That address as the one-address network pg_hba.conf takes."""
    a = peer_address(text)
    return '%s/%d' % (a, 32 if a.version == 4 else 128)


def pg_open_to(peer, db_name, db_user):
    """PostgreSQL on this machine listening beyond localhost and letting the
    other node's address in for this one database and account. Returns what
    was done, in words."""
    done = []
    listen = pg_local_admin('SHOW listen_addresses')
    if listen not in ('*', '0.0.0.0') and '*' not in listen.split(','):
        pg_local_admin("ALTER SYSTEM SET listen_addresses = '*'")
        done.append("listen_addresses = '*' (was %s) - takes effect at the next start" % listen)
    hba = pg_local_admin('SHOW hba_file')
    line = 'host    %s    %s    %s    scram-sha-256' % (db_name, db_user, peer_net(peer))
    try:
        text = Path(hba).read_text()
    except OSError as e:
        raise ValueError('%s could not be read: %s' % (hba, e))
    if line not in text:
        # In front of whatever is there: pg_hba.conf is read top down, and a
        # "reject" or an "ident" line further up would win otherwise.
        Path(hba).write_text('# otp high availability: the other node (%s)\n%s\n%s'
                             % (datetime.now().strftime('%Y-%m-%d'), line, text))
        done.append('%s: %s' % (hba, line))
    pg_local_admin('SELECT pg_reload_conf()')
    return done


# ---------------------------------------------------------------------------
# Replicated: a PostgreSQL on each node, each replicating to the other (1.0.14)
# ---------------------------------------------------------------------------
# Each node opens only its own PostgreSQL, on this machine, and goes on alone
# when the other is gone. The two replicate both ways with PostgreSQL's own
# logical replication: a publication of every table on each (inserts, updates
# and deletes - never TRUNCATE, so that a node being rebuilt cannot empty the
# other), and on each a subscription to the other with `origin = none`, so
# that what came from the other is not sent back to it. PostgreSQL 16 or
# later on both.
#
# Rows made on both at once never collide: the numbering of every table goes
# up in twos, odd on node 1 and even on node 2.
#
# A node that was away comes back by itself: what it missed waited in its
# replication slot on the other (up to max_slot_wal_keep_size). A node that
# was lost - or reinstalled - is rebuilt from the living one: its tables
# emptied, every row copied over by the subscription, and the other node's
# subscription to it made afresh.

HA_PUB = 'otp_pub'
# Before 1.0.37 the program was called opt, and its replication objects so:
# a publication and subscriptions are renamed at the upgrade, a slot keeps
# its name until it is next made (a rebuild) - so both are looked for.
HA_PUB_OLD = 'opt_pub'
HA_SLOT_KEEP = '16GB'


def ha_sub_name(slot):
    """The subscription that brings node `slot`'s rows in (and its slot on
    node `slot`)."""
    return 'otp_from_%d' % int(slot)


def ha_sub_names(slot):
    return ['otp_from_%d' % int(slot), 'opt_from_%d' % int(slot)]


def ha_sub_here(db, slot):
    """The subscription for node `slot` as it is called in `db`."""
    for name in ha_sub_names(slot):
        if db.value('SELECT 1 FROM pg_subscription WHERE subname = ?', (name,)):
            return name
    return ha_sub_name(slot)


def pg_admin(sql, port=5432, db='postgres', secret=False):
    """A statement as the postgres account on this machine (root only). As
    pg_local_admin: the SQL on standard input, a `secret` one unlogged."""
    for runner in (['runuser', '-u', 'postgres', '--'], ['sudo', '-u', 'postgres']):
        if shutil.which(runner[0]):
            got = subprocess.run(runner + ['psql', '-XAtq', '-p', str(int(port)), '-d', db,
                                           '-v', 'ON_ERROR_STOP=1', '-f', '-'],
                                 capture_output=True, text=True, timeout=120,
                                 input=pg_script(sql, secret))
            if got.returncode == 0:
                return got.stdout.strip()
            raise ValueError(scrub_secret((got.stderr or got.stdout).strip()[:400])
                             or 'psql failed')
    raise ValueError('neither runuser nor sudo is on this machine')


def pg_local_running(port=5432):
    try:
        return pg_admin('SELECT 1', port) == '1'
    except Exception:                                   # noqa: BLE001
        return False


def pg_install_local(major, say):
    """PostgreSQL `major` on this machine, installed, initialised and running."""
    if shutil.which('dnf'):
        say('installing PostgreSQL %s (dnf)' % major)
        subprocess.run(['dnf', '-y', 'module', 'reset', 'postgresql'], capture_output=True)
        subprocess.run(['dnf', '-y', 'module', 'enable', 'postgresql:%s' % major],
                       capture_output=True)
        got = subprocess.run(['dnf', '-y', 'install', 'postgresql-server', 'postgresql',
                              'postgresql-contrib'], capture_output=True, text=True)
        if got.returncode != 0:
            raise ValueError('dnf could not install PostgreSQL %s: %s'
                             % (major, (got.stderr or got.stdout).strip()[-300:]))
        if not Path('/var/lib/pgsql/data/PG_VERSION').exists():
            subprocess.run(['postgresql-setup', '--initdb'], capture_output=True)
        subprocess.run(['systemctl', 'enable', '--now', 'postgresql'], capture_output=True)
    elif shutil.which('apt-get'):
        say('installing PostgreSQL %s (apt)' % major)
        got = subprocess.run(['apt-get', 'install', '-y', 'postgresql-%s' % major,
                              'postgresql-client-%s' % major], capture_output=True, text=True)
        if got.returncode != 0:
            got = subprocess.run(['apt-get', 'install', '-y', 'postgresql'],
                                 capture_output=True, text=True)
        if got.returncode != 0:
            raise ValueError('apt could not install PostgreSQL: %s'
                             % (got.stderr or got.stdout).strip()[-300:])
    else:
        raise ValueError('install PostgreSQL %s on this machine first' % major)
    for _ in range(30):
        if pg_local_running():
            return
        time.sleep(1)
    raise ValueError('PostgreSQL was installed but does not answer')


def pg_restart_local(port=5432):
    unit = tune_restart_unit()
    if unit:
        subprocess.run(['systemctl', 'restart', unit], capture_output=True)
    elif shutil.which('pg_lsclusters'):
        for line in subprocess.run(['pg_lsclusters', '-h'], capture_output=True,
                                   text=True).stdout.splitlines():
            f = line.split()
            if len(f) >= 3 and f[2] == str(port):
                subprocess.run(['pg_ctlcluster', f[0], f[1], 'restart'], capture_output=True)
    else:
        raise ValueError('PostgreSQL could not be restarted: no service of it was found')
    for _ in range(60):
        if pg_local_running(port):
            return
        time.sleep(1)
    raise ValueError('PostgreSQL did not come back after its restart')


def pg_prepare_local(port, peer, name, user, password, say):
    """PostgreSQL on this machine ready to replicate with `peer`: logical
    WAL, listening on the network, the peer let in, the account able to
    replicate and to subscribe, the database there. True when it has to be
    restarted for it."""
    major = int(pg_admin('SHOW server_version_num', port)) // 10000
    if major < 16:
        raise ValueError('PostgreSQL %d is here; replicating both ways needs 16 or later '
                         '(dnf module enable postgresql:16, then upgrade it)' % major)
    restart = False
    for key, want in (('wal_level', 'logical'), ('listen_addresses', '*'),
                      ('max_slot_wal_keep_size', HA_SLOT_KEEP)):
        now = pg_admin('SHOW %s' % key, port)
        if key == 'max_slot_wal_keep_size' and now not in ('-1',) and now.upper() == want:
            continue
        if now != want:
            pg_admin("ALTER SYSTEM SET %s = '%s'" % (key, want), port)
            say('%s = %s (was %s)' % (key, want, now))
            if key != 'max_slot_wal_keep_size':
                restart = True
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_]{0,62}$', user) or \
            not re.match(r'^[A-Za-z_][A-Za-z0-9_]{0,62}$', name):
        raise ValueError('the database and its account are letters, digits and _')
    lit = "'%s'" % str(password).replace("'", "''")
    if pg_admin("SELECT 1 FROM pg_roles WHERE rolname = '%s'" % user, port) != '1':
        pg_admin('CREATE ROLE %s LOGIN PASSWORD %s' % (user, lit), port, secret=True)
        say('the account %s was made' % user)
    else:
        pg_admin('ALTER ROLE %s LOGIN PASSWORD %s' % (user, lit), port, secret=True)
    pg_admin('ALTER ROLE %s REPLICATION' % user, port)
    pg_admin('GRANT pg_create_subscription TO %s' % user, port)
    if pg_admin("SELECT 1 FROM pg_database WHERE datname = '%s'" % name, port) != '1':
        # UTF-8 whatever the cluster was made with: one made under LANG=C is
        # SQL_ASCII, and every name with an accent would come back unreadable.
        pg_admin("CREATE DATABASE %s OWNER %s ENCODING 'UTF8' TEMPLATE template0 "
                 "LC_COLLATE 'C.UTF-8' LC_CTYPE 'C.UTF-8'" % (name, user), port)
        say('the database %s was made' % name)
    pg_admin('GRANT CREATE ON DATABASE %s TO %s' % (name, user), port)
    hba = pg_admin('SHOW hba_file', port)
    text = Path(hba).read_text()
    added = []
    for who in sorted(set(([peer] if peer else []) + ['127.0.0.1'])):
        line = 'host    %s    %s    %s    scram-sha-256' % (name, user, peer_net(who))
        if line not in text:
            added.append(line)
    if added:
        # In front of whatever is there: pg_hba.conf is read top down, and a
        # "reject" or an "ident" line further up would win otherwise.
        Path(hba).write_text('# otp high availability (%s)\n%s\n%s'
                             % (datetime.now().strftime('%Y-%m-%d'), '\n'.join(added), text))
        say('%s: %s' % (hba, '; '.join(added)))
    pg_admin('SELECT pg_reload_conf()', port)
    return restart, major


def pg_publication(port, name):
    if pg_admin("SELECT 1 FROM pg_publication WHERE pubname = '%s'" % HA_PUB_OLD, port, name) == '1':
        pg_admin('ALTER PUBLICATION %s RENAME TO %s' % (HA_PUB_OLD, HA_PUB), port, name)
    if pg_admin("SELECT 1 FROM pg_publication WHERE pubname = '%s'" % HA_PUB, port, name) != '1':
        pg_admin("CREATE PUBLICATION %s FOR ALL TABLES WITH (publish = 'insert, update, delete')"
                 % HA_PUB, port, name)


def ha_conninfo(host, port, name, user, password):
    def q(v):
        return "'%s'" % str(v).replace('\\', '\\\\').replace("'", "\\'")
    tls = ''
    if CONFIG.get('db_tls'):
        # The other node's link encrypted as the database's own is (1.0.33).
        tls = ' sslmode=%s' % q(CONFIG.get('db_tls'))
        if CONFIG.get('db_tls_ca'):
            tls += ' sslrootcert=%s' % q(CONFIG.get('db_tls_ca'))
    return 'host=%s port=%d dbname=%s user=%s password=%s connect_timeout=10%s' % (
        q(host), int(port), q(name), q(user), q(password), tls)


def ha_drop_sub(db, sub):
    """A subscription taken away without asking the other side for its slot
    (which may be gone with a lost node) - under its name now or before."""
    names = ha_sub_names(sub.rsplit('_', 1)[1]) if sub[:9] in ('otp_from_', 'opt_from_') \
        else [sub]
    for one in names:
        if db.value('SELECT 1 FROM pg_subscription WHERE subname = ?', (one,)):
            db.run('ALTER SUBSCRIPTION %s DISABLE' % one)
            db.run('ALTER SUBSCRIPTION %s SET (slot_name = NONE)' % one)
            db.run('DROP SUBSCRIPTION %s' % one)


def ha_drop_slot(db, slot_name):
    if slot_name[:9] in ('otp_from_', 'opt_from_'):
        gone = False
        for one in ha_sub_names(slot_name.rsplit('_', 1)[1]):
            gone = _ha_drop_slot(db, one) or gone
        return gone
    return _ha_drop_slot(db, slot_name)


def _ha_drop_slot(db, slot_name):
    got = db.row('SELECT active, active_pid FROM pg_replication_slots WHERE slot_name = ?',
                 (slot_name,))
    if not got:
        return False
    if got.get('active') and got.get('active_pid'):
        db.value('SELECT pg_terminate_backend(?)', (int(got['active_pid']),))
        time.sleep(1)
    db.value('SELECT pg_drop_replication_slot(?)', (slot_name,))
    return True


def ha_sequences(db, slot):
    """Every table numbered in twos: odd on node 1, even on node 2."""
    slot = int(slot)
    for table in TABLES:
        if table in ('meta', 'settings'):
            continue                    # keyed by name, not numbered
        seq = db.value("SELECT pg_get_serial_sequence(?, 'id')", (table,))
        if not seq:
            continue
        top = int(db.value('SELECT COALESCE(MAX(id), 0) FROM %s' % table) or 0)
        start = top + 1
        while start % 2 != slot % 2:
            start += 1
        db.run('ALTER SEQUENCE %s INCREMENT BY 2' % seq)
        # The next nextval() is `start`.
        db.value('SELECT setval(?, ?, false)', (seq, start))


def ha_wait_copied(db, sub, say, seconds=3600):
    t0 = time.time()
    while time.time() - t0 < seconds:
        left = db.rows("SELECT c.relname AS t, r.srsubstate AS s FROM pg_subscription_rel r "
                       "JOIN pg_subscription s ON s.oid = r.srsubid "
                       "JOIN pg_class c ON c.oid = r.srrelid WHERE s.subname = ? "
                       "AND r.srsubstate <> 'r'", (sub,))
        if not left and db.value('SELECT COUNT(*) FROM pg_subscription_rel r JOIN '
                                 'pg_subscription s ON s.oid = r.srsubid WHERE s.subname = ?',
                                 (sub,)):
            return True
        say('copying: %s still to come' % ', '.join(sorted(x['t'] for x in left)[:6]))
        time.sleep(2)
    raise ValueError('the copy from the other node did not finish in %d s' % seconds)


def ha_subscribe(db, sub, conninfo, copy_data):
    """A subscription made on `db`. The statement carries the password of
    the account in its conninfo, so it is kept out of PostgreSQL's log for
    the session, and out of any error that comes back."""
    # Tried from here first (1.0.44): the SETs below need a superuser, which
    # the otp account is not, so a CREATE SUBSCRIPTION that fails - the
    # other node unreachable, a wrong password - would be written to
    # PostgreSQL's log with the password in it. What fails here is never
    # sent.
    try:
        import psycopg2
        probe = psycopg2.connect(conninfo + ' connect_timeout=10')
        probe.close()
    except ImportError:
        pass
    except Exception as e:                              # noqa: BLE001
        raise ValueError('the other node\'s database cannot be reached from here, so the '
                         'subscription %s was not made: %s'
                         % (sub, scrub_secret(str(e).split('\n')[0][:300])))
    for quiet in ("SET log_statement = 'none'", "SET log_min_error_statement = 'panic'"):
        try:
            db.run(quiet)
        except Exception:                               # noqa: BLE001
            pass                                        # not a superuser: logged as usual
    try:
        db.run("CREATE SUBSCRIPTION %s CONNECTION '%s' PUBLICATION %s WITH (copy_data = %s, "
               "origin = none)" % (sub, conninfo.replace("'", "''"), HA_PUB,
                                   'true' if copy_data else 'false'))
    except Exception as e:                              # noqa: BLE001
        raise ValueError('the subscription %s could not be made: %s'
                         % (sub, scrub_secret(str(e).split('\n')[0][:300])))
    finally:
        for back in ('RESET log_statement', 'RESET log_min_error_statement'):
            try:
                db.run(back)
            except Exception:                           # noqa: BLE001
                pass


def ha_rebuild(local, remote, my_slot, peer_slot, my_host, my_port, peer_host, peer_port,
               name, user, password, say):
    """This node rebuilt from the other: both subscriptions made afresh, this
    node's tables emptied and every row copied over. What this node held is
    replaced by what the other holds."""
    mine_on_peer = ha_sub_name(my_slot)       # on the peer: brings my rows to it
    theirs_here = ha_sub_name(peer_slot)      # here: brings the peer's rows to me
    say('the other node stops taking rows from this one')
    ha_drop_sub(remote, mine_on_peer)
    ha_drop_slot(local, mine_on_peer)
    say('this node stops taking rows from the other')
    ha_drop_sub(local, theirs_here)
    ha_drop_slot(remote, theirs_here)
    say('this node\'s tables emptied')
    local.make_tables()
    # Nothing written here while the rows come over (1.0.44): the heartbeat
    # and the job's own progress wrote rows the copy then met again, and it
    # stopped on a duplicate key for good.
    HA_REBUILDING.set()
    try:
        local.run('TRUNCATE %s RESTART IDENTITY' % ', '.join(TABLES))
        say('every row copied from the other node')
        ha_subscribe(local, theirs_here, ha_conninfo(peer_host, peer_port, name, user, password),
                     copy_data=True)
        ha_wait_copied(local, theirs_here, say)
    finally:
        HA_REBUILDING.clear()
    ha_sequences(local, my_slot)
    say('the other node takes this one\'s rows from now on')
    ha_subscribe(remote, mine_on_peer, ha_conninfo(my_host, my_port, name, user, password),
                 copy_data=False)
    rows = sum(int(local.value('SELECT COUNT(*) FROM %s' % t) or 0) for t in TABLES)
    return {'rows': rows}


def ha_repl_state(store):
    """Both directions, as this node's PostgreSQL sees them."""
    db = store.db
    out = {'mode': CONFIG.get('ha_mode') or '', 'slot': CONFIG.get('ha_slot') or 0,
           'peer': CONFIG.get('ha_peer') or '', 'incoming': [], 'outgoing': []}
    if out['mode'] != 'replicated' or db.engine != 'postgres':
        return out
    try:
        for r in db.rows(
                'SELECT s.subname AS name, s.subenabled AS enabled, st.pid AS pid, '
                'EXTRACT(EPOCH FROM st.last_msg_receipt_time) AS last_msg, '
                'EXTRACT(EPOCH FROM st.latest_end_time) AS latest_end, '
                'COALESCE(ss.apply_error_count, 0) AS apply_errors, '
                'COALESCE(ss.sync_error_count, 0) AS sync_errors '
                'FROM pg_subscription s LEFT JOIN pg_stat_subscription st '
                'ON st.subid = s.oid AND st.relid IS NULL '
                'LEFT JOIN pg_stat_subscription_stats ss ON ss.subid = s.oid'):
            r['running'] = bool(r.get('pid'))
            out['incoming'].append(r)
        for r in db.rows(
                "SELECT slot_name AS name, active, wal_status, "
                "pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn) AS behind "
                "FROM pg_replication_slots WHERE slot_name LIKE 'o__!_from!_%' ESCAPE '!'"):
            r['behind'] = int(float(r.get('behind') or 0))
            out['outgoing'].append(r)
    except Exception as e:                              # noqa: BLE001
        out['trouble'] = str(e).split('\n')[0][:300]
    healthy = bool(out['incoming']) and all(x['enabled'] and x['running'] for x in
                                            out['incoming']) and bool(out['outgoing']) and \
        all(x['wal_status'] not in ('lost',) for x in out['outgoing'])
    out['healthy'] = healthy
    out['lost'] = any(x.get('wal_status') == 'lost' for x in out['outgoing'])
    return out


def ha_peer_db():
    c = {k: CONFIG.get(k) for k in DB_KEYS}
    c['db_host'] = CONFIG.get('ha_peer')
    c['db_port'] = CONFIG.get('ha_peer_port') or 5432
    return db_open(c)


def ha_control(store, act, by=''):
    """Replication worked by hand: paused, resumed, switched off, refreshed.
    `in` is what this node takes from the other (its own subscription);
    `out` is what the other takes from this one (the other's subscription,
    reached over its PostgreSQL). (1.0.14)"""
    if CONFIG.get('ha_mode') != 'replicated':
        raise ValueError('this node does not replicate')
    slot = int(CONFIG.get('ha_slot') or 1)
    peer_slot = 3 - slot
    here = store.db
    sub_in = ha_sub_here(here, peer_slot)
    said = []

    def on_peer(fn):
        try:
            far = ha_peer_db()
        except Exception as e:                          # noqa: BLE001
            raise ValueError('the other node\'s PostgreSQL cannot be reached: %s'
                             % str(e).split('\n')[0][:200])
        try:
            return fn(far)
        finally:
            far.close()

    def has(db, sub):
        return bool(db.value('SELECT 1 FROM pg_subscription WHERE subname = ?', (sub,)))

    if act in ('pause_in', 'pause'):
        if has(here, sub_in):
            here.run('ALTER SUBSCRIPTION %s DISABLE' % sub_in)
            said.append('this node takes nothing from the other for now')
    if act in ('pause_out', 'pause'):
        def p(far):
            sub_out = ha_sub_here(far, slot)
            if has(far, sub_out):
                far.run('ALTER SUBSCRIPTION %s DISABLE' % sub_out)
                said.append('the other node takes nothing from this one for now')
        on_peer(p)
    if act in ('resume_in', 'resume'):
        if has(here, sub_in):
            here.run('ALTER SUBSCRIPTION %s ENABLE' % sub_in)
            said.append('this node takes the other\'s rows again, from where it stopped')
    if act in ('resume_out', 'resume'):
        def r(far):
            sub_out = ha_sub_here(far, slot)
            if has(far, sub_out):
                far.run('ALTER SUBSCRIPTION %s ENABLE' % sub_out)
                said.append('the other node takes this one\'s rows again, from where it '
                            'stopped')
        on_peer(r)
    if act == 'refresh':
        if has(here, sub_in):
            here.run('ALTER SUBSCRIPTION %s REFRESH PUBLICATION WITH (copy_data = false)'
                     % sub_in)
        said.append('the list of tables taken from the other was read again')
    if act == 'stop':
        # Both directions taken away; both nodes go on alone, each with what
        # it has. Joining them again is a rebuild of one from the other.
        ha_drop_sub(here, sub_in)
        try:
            on_peer(lambda far: (ha_drop_sub(far, ha_sub_name(slot)), ha_drop_slot(far, sub_in)))
        except ValueError as e:
            said.append('the other node could not be reached (%s): take its subscription '
                        'away there with otp --ha-stop' % e)
        ha_drop_slot(here, ha_sub_name(slot))
        said.append('replication is off: each node goes on alone with what it has')
    if not said:
        raise ValueError('nothing to do: %s' % act)
    store.add_event('settings', '%s: replication - %s' % (by or 'command line', '; '.join(said)),
                    'warn', who=by or 'command line')
    return {'message': '; '.join(said)}


def ha_resync_job(store, by):
    """This node rebuilt from the other, as a job the pages can follow."""
    if CONFIG.get('ha_mode') != 'replicated':
        raise ValueError('this node does not replicate')

    def work(progress):
        steps = []

        def say(t):
            steps.append(t)
            progress(len(steps), 8, t)
        progress(0, 8, 'making a copy of what is here first')
        copy = make_backup(store, 'before rebuilding from the other node, by %s' % by)
        remote = ha_peer_db()
        try:
            got = ha_rebuild(store.db, remote, int(CONFIG.get('ha_slot') or 2),
                             3 - int(CONFIG.get('ha_slot') or 2),
                             CONFIG.get('ha_address') or node_address(),
                             int(CONFIG.get('db_port') or 5432), CONFIG.get('ha_peer'),
                             int(CONFIG.get('ha_peer_port') or 5432), CONFIG.get('db_name'),
                             CONFIG.get('db_user'), CONFIG.get('db_password'), say)
        finally:
            remote.close()
        store._clients = store._realms = None
        store.set_meta('conf_serial', '%.6f:%s' % (time.time(), node_name()))
        store.add_event('settings', '%s rebuilt this node from the other: %d row(s); what it '
                        'held is in %s' % (by, got['rows'], copy.name), 'warn', who=by)
        progress(8, 8, 'done')
        return {'rows': got['rows'], 'copy': copy.name, 'where': CONFIG.get('ha_peer')}
    return db_job('rebuilding this node from the other', work)


def bytes_words(n):
    n = float(n or 0)
    for unit in ('B', 'kB', 'MB', 'GB', 'TB'):
        if n < 1024 or unit == 'TB':
            return ('%d %s' % (n, unit)) if unit == 'B' else ('%.1f %s' % (n, unit))
        n /= 1024.0


# ---------------------------------------------------------------------------
# Maintenance, and a new version put in from the pages (1.0.37)
# ---------------------------------------------------------------------------
# Maintenance is per node: the node stops answering RADIUS (the VPN goes to
# the other one, as it would to a node that is down) and /healthz says 503
# (the load balancer takes it out). The pages go on working, so the node can
# be looked at and brought back.
#
# An upgrade: the package goes into the database, in pieces (so the other
# node of a cluster has it too), and a plan says which nodes, in which
# order. Each node does its own turn when it comes - maintenance on, a
# moment for the balancer to notice, the package handed to root
# (otp_upgrade.py, by otp-upgrade.path), and after its restart its own
# check before it leaves maintenance. Then the next one.
#
# Every row has ONE node that writes it (the plan: the one that started it;
# `upgrade:node:X` and `maint:X`: node X - or, for maintenance, the pages,
# which only ever UPDATE it). Replicated, a newer version may add a column,
# and the older node then takes nothing more from it until it is upgraded
# too; so a node's own rows are also written straight into the other's
# database - an UPDATE of a row both have, never an INSERT, which the
# replication arriving later would then collide with.
UPGRADE_DIR = STATE_DIR / 'upgrade'
UPGRADE_HELPER = Path(os.environ.get('OTP_UPGRADE_HELPER',
                                     str(Path(__file__).resolve().parent / 'otp_upgrade.py')))
UPGRADE_MOST = 64 * 1024 * 1024
UPGRADE_PIECE = 40000                       # base64 characters in one meta row
UPGRADE_DRAIN_S = int(os.environ.get('OTP_UPGRADE_DRAIN_S', '20'))
UPGRADE_TIMEOUT_S = 30 * 60
MAINT_CACHE = {'at': 0.0, 'row': None}


def _meta_json(store, k):
    try:
        got = store.get_meta(k)
        return json.loads(got) if got else None
    except (ValueError, TypeError):
        return None


def _peer_update(k, v):
    """The same row changed in the other node's database too - UPDATE only."""
    if CONFIG.get('ha_mode') != 'replicated' or not CONFIG.get('ha_peer'):
        return False
    try:
        far = ha_peer_db()
    except Exception:                                   # noqa: BLE001
        return False
    try:
        return bool(far.run('UPDATE meta SET v = ? WHERE k = ?', (v, k)))
    except Exception:                                   # noqa: BLE001
        return False
    finally:
        try:
            far.close()
        except Exception:                               # noqa: BLE001
            pass


def _row_write(store, k, data, mine=True, mirror=True):
    """A row of this node's own (made here if need be), or someone else's
    (only ever UPDATEd)."""
    v = json.dumps(data, default=str)
    if store.db.value('SELECT k FROM meta WHERE k = ?', (k,)) is None:
        if not mine:
            raise ValueError('that node has not been heard of here yet')
        store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)', (k, v))
    else:
        store.db.run('UPDATE meta SET v = ? WHERE k = ?', (v, k))
    if mirror:
        _peer_update(k, v)


# ---- maintenance ---------------------------------------------------------------------
def maintenance_row(store, name=None):
    return _meta_json(store, 'maint:' + (name or node_name())) or {'on': False}


def maintenance_now(store):
    """This node's maintenance, read at most every two seconds - asked for
    every RADIUS packet."""
    if HA_REBUILDING.is_set():
        return {'on': True, 'why': 'rebuilt from the other node'}
    now = time.time()
    if now - MAINT_CACHE['at'] > 2:
        MAINT_CACHE['at'] = now
        try:
            MAINT_CACHE['row'] = maintenance_row(store)
        except Exception:                               # noqa: BLE001
            pass                                        # the last one known stands
    return MAINT_CACHE['row'] or {'on': False}


def maintenance_ensure(store):
    """The row of this node, made by this node: the pages only change it."""
    if HA_REBUILDING.is_set():
        return
    try:
        if store.get_meta('maint:' + node_name()) is None:
            store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)',
                         ('maint:' + node_name(), json.dumps({'on': False})))
    except Exception:                                   # noqa: BLE001
        pass


def maintenance_set(store, on, why='', by='', name=None):
    name = name or node_name()
    row = {'on': bool(on), 'why': str(why or '')[:200], 'by': str(by or '')[:100],
           'at': time.time()}
    _row_write(store, 'maint:' + name, row, mine=(name == node_name()))
    MAINT_CACHE['at'] = 0
    store.add_event('starting and stopping', '%s: %s%s' % (
        name, 'in maintenance' if on else 'back in service',
        (' - ' + why) if why and on else ''), 'warn' if on else 'info', who=by or None)
    return row


# ---- the package --------------------------------------------------------------------
def upgrade_inspect(path):
    """What the package is, asked of otp_upgrade.py - the same check root
    makes again before putting it in."""
    if not UPGRADE_HELPER.exists():
        raise ValueError('otp_upgrade.py is not installed beside otp.py; upgrade once on the '
                         'command line (install.sh --upgrade)')
    try:
        r = subprocess.run([sys.executable, '-I', str(UPGRADE_HELPER), '--inspect', str(path)],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
        got = json.loads(r.stdout.decode('utf-8', 'replace') or '{}')
    except (OSError, ValueError, subprocess.SubprocessError) as e:
        raise ValueError('the package could not be checked: %s' % e)
    if not got.get('ok'):
        raise ValueError(got.get('said') or 'the package was refused')
    return got


def upgrade_store_package(store, path, info, by):
    """The package into the database in pieces, the one before taken out."""
    raw = Path(path).read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    text = base64.b64encode(raw).decode('ascii')
    pieces = [text[i:i + UPGRADE_PIECE] for i in range(0, len(text), UPGRADE_PIECE)]
    old = _meta_json(store, 'upgrade:pkg') or {}
    # Every other package's pieces out, not only the last one's (1.0.44).
    store.db.run("DELETE FROM meta WHERE k LIKE 'upgrade:piece:%' AND k NOT LIKE ?",
                 ('upgrade:piece:%s:%%' % sha[:16],))
    for i, one in enumerate(pieces):
        k = 'upgrade:piece:%s:%04d' % (sha[:16], i)
        if store.get_meta(k) is None:
            store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)', (k, one))
    meta = {'sha': sha, 'version': info['version'], 'bytes': len(raw), 'pieces': len(pieces),
            'signed_by': info.get('signed_by'), 'changelog': info.get('changelog', ''),
            'by': by, 'at': time.time()}
    store.set_meta('upgrade:pkg', json.dumps(meta))
    return meta


def upgrade_package_file(store, meta):
    """The package back out of the database, to the folder root takes it
    from - from the other node's database when this one has not all of it
    yet."""
    UPGRADE_DIR.mkdir(mode=0o750, exist_ok=True)
    out = UPGRADE_DIR / ('otp-%s.tar.gz' % meta['version'])

    def pieces_of(db):
        rows = db.rows("SELECT k, v FROM meta WHERE k LIKE ? ESCAPE '!' ORDER BY k",
                       ('upgrade:piece:%s:%%' % meta['sha'][:16],))
        return [r['v'] for r in rows]
    got = pieces_of(store.db)
    if len(got) != int(meta['pieces']) and CONFIG.get('ha_mode') == 'replicated':
        far = ha_peer_db()
        try:
            got = pieces_of(far)
        finally:
            far.close()
    if len(got) != int(meta['pieces']):
        raise ValueError('the package has not all arrived in this node\'s database')
    raw = base64.b64decode(''.join(got))
    if hashlib.sha256(raw).hexdigest() != meta['sha']:
        raise ValueError('the package in the database is damaged')
    tmp = out.with_suffix('.part')
    try:
        tmp.unlink()
    except OSError:
        pass
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640)
    with os.fdopen(fd, 'wb') as f:
        f.write(raw)
    os.replace(str(tmp), str(out))
    return out


# ---- the plan ------------------------------------------------------------------------
def upgrade_nodes_now(store):
    """The nodes an upgrade goes over: every one heard from lately, or this
    one alone."""
    nodes = [n for n in ha_nodes(store) if n.get('alive')]
    if not nodes:
        nodes = [{'name': node_name(), 'version': __version__, 'me': True, 'alive': True}]
    return nodes


def upgrade_plan(store):
    plan = _meta_json(store, 'upgrade:plan')
    if not plan:
        return None
    plan['steps'] = []
    for name in plan.get('order') or []:
        row = _meta_json(store, 'upgrade:node:' + name) or {}
        if row.get('id') != plan.get('id'):
            row = {'state': 'waiting'}
        row['name'] = name
        plan['steps'].append(row)
    states = [s.get('state') for s in plan['steps']]
    if any(s == 'failed' for s in states):
        plan['state'] = 'failed'
    elif states and all(s == 'done' for s in states):
        plan['state'] = 'done'
    elif plan.get('cancelled'):
        plan['state'] = 'cancelled'
    else:
        plan['state'] = 'running'
    return plan


def upgrade_checks(store, meta):
    """What must be so before an upgrade starts - (ok, [why not])."""
    why = []
    if not meta:
        return False, ['no package has been sent yet']
    nodes = upgrade_nodes_now(store)
    for n in ha_nodes(store):
        if not n.get('alive'):
            why.append('%s has not been heard from for %d s - bring it back, or forget it '
                       '(Settings - High availability)' % (n['name'], int(n.get('age') or 0)))
    for n in nodes:
        have = str(n.get('version') or '')
        try:
            if have and tuple(int(x) for x in have.split('.')) > \
                    tuple(int(x) for x in meta['version'].split('.')):
                why.append('%s runs %s, newer than %s' % (n['name'], have, meta['version']))
        except ValueError:
            pass
    if CONFIG.get('ha_mode') == 'replicated':
        rep = ha_repl_state(store)
        if not rep.get('healthy'):
            why.append('the replication is not running both ways - see Settings - High '
                       'availability')
    plan = upgrade_plan(store)
    if plan and plan['state'] == 'running':
        why.append('an upgrade is going on already')
    return not why, why


def upgrade_start(store, by):
    meta = _meta_json(store, 'upgrade:pkg')
    ok, why = upgrade_checks(store, meta)
    if not ok:
        raise ValueError('; '.join(why))
    names = [n['name'] for n in upgrade_nodes_now(store)]
    me = node_name()
    # The others first and this node last: the pages it shows stay up the
    # longest, and the first node is the one somebody can look at while it
    # is done.
    order = sorted(n for n in names if n != me) + ([me] if me in names else [])
    ident = '%d-%s' % (int(time.time()), secrets.token_hex(4))
    for name in order:
        k = 'upgrade:node:' + name
        if store.get_meta(k) is None:
            # Made here, for every node, before anything else: from then on
            # each node only UPDATEs its own.
            store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)',
                         (k, json.dumps({'state': 'none'})))
    plan = {'id': ident, 'version': meta['version'], 'sha': meta['sha'], 'order': order,
            'by': by, 'at': time.time(), 'from': me}
    store.set_meta('upgrade:plan', json.dumps(plan))
    store.add_event('starting and stopping', '%s started the upgrade to %s: %s, one at a '
                    'time' % (by, meta['version'], ', '.join(order)), 'warn', who=by)
    return upgrade_plan(store)


def upgrade_cancel(store, by):
    plan = _meta_json(store, 'upgrade:plan')
    if not plan:
        raise ValueError('no upgrade is going on')
    plan['cancelled'] = {'by': by, 'at': time.time()}
    store.set_meta('upgrade:plan', json.dumps(plan))
    _peer_update('upgrade:plan', json.dumps(plan))
    store.add_event('starting and stopping', '%s stopped the upgrade to %s: the nodes not '
                    'begun stay as they are' % (by, plan.get('version')), 'warn', who=by)


def _my_step(store, plan, **fields):
    k = 'upgrade:node:' + node_name()
    row = _meta_json(store, k) or {}
    if row.get('id') != plan['id']:
        row = {'id': plan['id']}
    row.update(fields)
    row['at'] = time.time()
    _row_write(store, k, row, mine=False)
    return row


def _helper_status():
    try:
        fd = os.open(str(UPGRADE_DIR / 'status.json'), os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as f:
            return json.loads(f.read(1 << 20).decode('utf-8'))
    except (OSError, ValueError):
        return {}


def upgrade_log_tail(lines=200):
    try:
        fd = os.open(str(UPGRADE_DIR / 'last.log'), os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as f:
            text = f.read(4 << 20).decode('utf-8', 'replace')
        return text.splitlines()[-lines:]
    except OSError:
        return []


def upgrade_tick(daemon):
    """This node's part of the plan, every few seconds."""
    store = daemon.store
    if HA_REBUILDING.is_set():
        return
    plan = upgrade_plan(store)
    # A cancelled plan is still finished where a node has begun (1.0.44):
    # one that drains goes back into service, one that installs is checked
    # and comes back - it never stays in maintenance for good.
    if not plan or plan['state'] not in ('running', 'cancelled'):
        return
    me = node_name()
    if store.get_meta('upgrade:node:' + me) is None:
        return                          # its row has not come over from the other node yet
    steps = plan['steps']
    turn = next((s for s in steps if s.get('state') != 'done'), None)
    if not turn or turn['name'] != me:
        return
    state = turn.get('state')
    now = time.time()
    if plan.get('cancelled') and state in ('waiting', 'none', None, 'cancelled'):
        return
    if plan.get('cancelled') and state == 'draining':
        if not turn.get('was_maint'):
            maintenance_set(store, False, by=plan.get('by') or '')
        _my_step(store, plan, state='cancelled', said='cancelled before it was installed; '
                 'back in service')
        return
    if state in ('waiting', 'none', None) and len(steps) > 1:
        # Never both out at once (1.0.44): the others have to be alive and
        # in service before this one leaves.
        for n in ha_nodes(store):
            if n['name'] == me or n['name'] not in [x['name'] for x in steps]:
                continue
            if not n.get('alive') or maintenance_row(store, n['name']).get('on'):
                if turn.get('said') != 'waiting for %s to be in service' % n['name']:
                    _my_step(store, plan, state='waiting',
                             said='waiting for %s to be in service' % n['name'])
                return
    if state in ('waiting', 'none', None):
        was = maintenance_row(store)
        alone = len(steps) == 1
        maintenance_set(store, True, 'upgrade to %s' % plan['version'], plan.get('by') or '')
        _my_step(store, plan, state='draining', was_maint=bool(was.get('on')),
                 began=now, said='in maintenance; the balancer and the VPN go to the other '
                 'node' if not alone else 'in maintenance')
        if not alone:
            return
        state = 'draining'
        turn = _meta_json(store, 'upgrade:node:' + me)
    if state == 'draining':
        if len(steps) > 1 and now - float(turn.get('at') or 0) < UPGRADE_DRAIN_S:
            return
        meta = _meta_json(store, 'upgrade:pkg') or {}
        try:
            if meta.get('sha') != plan['sha']:
                raise ValueError('the package in the database is not the one this upgrade '
                                 'was started with')
            path = upgrade_package_file(store, meta)
            req = {'id': plan['id'], 'file': path.name, 'sha': plan['sha'],
                   'version': plan['version'], 'by': plan.get('by'), 'at': now}
            tmp = UPGRADE_DIR / 'request.part'
            try:
                tmp.unlink()
            except OSError:
                pass
            fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640)
            with os.fdopen(fd, 'w') as f:
                json.dump(req, f)
            os.replace(str(tmp), str(UPGRADE_DIR / 'request.json'))
        except Exception as e:                          # noqa: BLE001
            _upgrade_failed(store, plan, turn, 'the package could not be handed over: %s' % e)
            return
        _my_step(store, plan, state='installing', asked=now,
                 said='handed to root (otp-upgrade.service)')
        log('the upgrade to %s is handed to otp-upgrade.service' % plan['version'])
        return
    if state == 'installing':
        if __version__ == plan['version'] and float(daemon.started or 0) > \
                float(turn.get('asked') or 0):
            _my_step(store, plan, state='checking', said='restarted as %s' % __version__)
            state = 'checking'
            turn = _meta_json(store, 'upgrade:node:' + me)
        else:
            got = _helper_status()
            if got.get('id') == plan['id'] and got.get('state') == 'failed':
                _upgrade_failed(store, plan, turn, got.get('said') or
                                'install.sh ended with %s' % got.get('rc'),
                                tail=got.get('tail'))
                return
            if not (UPGRADE_DIR / 'request.json').exists() and \
                    not (UPGRADE_DIR / 'request.taken').exists() and \
                    got.get('id') != plan['id'] and now - float(turn.get('asked') or now) > 120:
                _upgrade_failed(store, plan, turn, 'otp-upgrade.service never took the request '
                                '- is otp-upgrade.path installed and running? (install.sh '
                                '--upgrade once on the command line puts it in)')
                return
            if now - float(turn.get('asked') or now) > UPGRADE_TIMEOUT_S:
                _upgrade_failed(store, plan, turn, 'it has not come back as %s in %d min'
                                % (plan['version'], UPGRADE_TIMEOUT_S // 60))
            return
    if state == 'checking':
        trouble = []
        try:
            store.db.value('SELECT 1')
        except Exception as e:                          # noqa: BLE001
            trouble.append('the database: %s' % e)
        if not getattr(getattr(daemon, 'radius', None), 'bound', None):
            trouble.append('RADIUS is not listening')
        got = _helper_status()
        if got.get('id') == plan['id'] and got.get('state') == 'running':
            if now - float(turn.get('at') or now) < 600:
                return                  # install.sh is still finishing (the firewall, its checks)
            # Not done just because it took long (1.0.44).
            trouble.append('install.sh has not said it finished in 10 min (see '
                           'journalctl -u otp-upgrade)')
        if got.get('id') == plan['id'] and got.get('state') == 'failed':
            trouble.append(got.get('said') or 'install.sh ended with %s' % got.get('rc'))
        if CONFIG.get('ha_mode') == 'replicated':
            ha_refresh_tables(store)
        if trouble:
            _upgrade_failed(store, plan, turn, '; '.join(trouble), tail=got.get('tail'))
            return
        if not turn.get('was_maint'):
            maintenance_set(store, False, by=plan.get('by') or '')
        _my_step(store, plan, state='done', said='%s, checked, back in service' % __version__,
                 tail=(got.get('tail') or [])[-12:])
        store.add_event('starting and stopping', '%s is upgraded to %s' % (me, __version__))
        log('upgraded to %s and back in service' % __version__)
        if all((s.get('state') == 'done') or s['name'] == me for s in steps):
            store.add_event('starting and stopping', 'the upgrade to %s is done on every node'
                            % plan['version'])


def _upgrade_failed(store, plan, turn, said, tail=None):
    _my_step(store, plan, state='failed', said=str(said)[:500], tail=(tail or [])[-40:])
    # Back in service where it still runs as it did: a failed upgrade must
    # not leave a working node out.
    if not turn.get('was_maint'):
        try:
            maintenance_set(store, False, by=plan.get('by') or '')
        except Exception:                               # noqa: BLE001
            pass
    store.add_event('starting and stopping', 'the upgrade of %s to %s failed: %s'
                    % (node_name(), plan['version'], said), 'bad')
    log('the upgrade to %s failed: %s' % (plan['version'], said), 'error')


def ha_refresh_tables(store):
    """The list of tables taken from the other node read again, here and
    there: a version that adds a table needs it, and it costs nothing when
    none was added. Where the other node does not have the table yet (it
    is still the older version) its half fails, and it is done again when
    that node comes back upgraded."""
    try:
        ha_control(store, 'refresh', by='the upgrade')
    except Exception as e:                              # noqa: BLE001
        log('reading the tables of the other node again: %s' % e, 'warn')
    slot = int(CONFIG.get('ha_slot') or 1)
    try:
        far = ha_peer_db()
        try:
            far.run('ALTER SUBSCRIPTION %s REFRESH PUBLICATION WITH (copy_data = false)'
                    % ha_sub_here(far, slot))
        finally:
            far.close()
    except Exception as e:                              # noqa: BLE001
        log('the other node could not read this one\'s tables again yet: %s'
            % str(e).split('\n')[0][:200], 'info')


# ---------------------------------------------------------------------------
# The web side (1.0.47): TLS of each node and of the cluster's web address,
# and that address itself (VIP, active/standby, held by keepalived).
#
# Everything is kept in the database, so both nodes know all of it:
#   web:vip          the address, its name, the VRRP id, the node it is meant
#                    to be on, each node's interface
#   web:tls:NODE     a node's own certificate, chain, root and TLS settings
#   web:tls:vip      the same for the web address's own name
# Keys are sealed with the tokens' key. Each node then asks root for its own
# part of it (otp_web.py, through /var/lib/otp/web/request.json) and keeps
# /run/otp/vip-state up to date for keepalived: whether this node is healthy
# enough to hold the address - its own pages answering /healthz end to end
# (nginx, PHP, the daemon, the database), RADIUS listening, not in
# maintenance, not being upgraded or rebuilt - and whether it is the one the
# address is meant to be on.
# ---------------------------------------------------------------------------
WEB_DIR = STATE_DIR / 'web'
VIP_STATE = RUN_DIR / 'vip-state'
VIP_ROLE = RUN_DIR / 'vip-role'
WEB_HELPER = Path(__file__).parent / 'otp_web.py'
VIP_FAILS_BEFORE = 2
VIP_HEALTH_URL = os.environ.get('OTP_VIP_HEALTH_URL', 'https://127.0.0.1/healthz')                    # checks in a row before it is said unhealthy
TLS_PRESETS = {
    # The ciphers otp has always used: ECDHE only, AEAD only.
    'standard': {'protocols': ['TLSv1.2', 'TLSv1.3'], 'ciphers': (
        'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:'
        'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:'
        'ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305')},
    # Mozilla's "intermediate": the same and the DHE ones (DH parameters).
    'intermediate': {'protocols': ['TLSv1.2', 'TLSv1.3'], 'ciphers': (
        'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:'
        'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:'
        'ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:'
        'DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:DHE-RSA-CHACHA20-POLY1305')},
    # Mozilla's "modern": TLS 1.3 alone - its ciphers are not chosen.
    'modern': {'protocols': ['TLSv1.3'], 'ciphers': ''},
}
DH_WORDS = {'none': 'none (ECDHE only needs none)',
            'ffdhe2048': 'RFC 7919 ffdhe2048', 'ffdhe3072': 'RFC 7919 ffdhe3072',
            'ffdhe4096': 'RFC 7919 ffdhe4096', 'gen2048': 'made here, 2048 bits',
            'gen3072': 'made here, 3072 bits (a minute or so)',
            'gen4096': 'made here, 4096 bits (several minutes)'}
WEB_LOCK = threading.Lock()
VIP_HEALTH = {'ok': None, 'why': '', 'fails': 0, 'at': 0.0}


def _json_meta(store, k):
    try:
        got = json.loads(store.get_meta(k) or 'null')
        return got if isinstance(got, dict) else None
    except ValueError:
        return None


def vip_conf(store):
    return _json_meta(store, 'web:vip') or {'on': False}


def tls_profile(store, target):
    return _json_meta(store, 'web:tls:' + target)


def vip_auth():
    """The VRRP password: the same on every node, from the tokens' key."""
    key = sealing_key() or b''
    raw = hmac.new(key, b'otp-vip-vrrp', hashlib.sha256).digest()
    abc = string.ascii_letters + string.digits
    return ''.join(abc[b % len(abc)] for b in raw[:8])


VIP_MOVE_S = 60          # a move asked for by hand, in 'stays' mode, is wanted this long


def vip_moving(conf):
    """The node a move by hand is going to, while it is still under way."""
    to = str(conf.get('move_to') or '')
    if to and time.time() - float(conf.get('move_at') or 0) < VIP_MOVE_S:
        return to
    return ''


def vip_prefer_me(store, conf=None):
    """Is this node the one the address should be on - asked every 3 s.

    'back' (the default): the chosen node, always; the address goes back to it
    as soon as it is healthy. 'stays' (1.0.52): no preference - the node that
    holds it keeps it (keepalived's own state says which: MASTER), until it is
    unhealthy or gone, or until it is moved by hand."""
    conf = conf or vip_conf(store)
    me = node_name()
    if conf.get('mode') != 'stays':
        return vip_prefer(store, conf) == me
    moving = vip_moving(conf)
    if moving:
        return moving == me
    try:
        role = VIP_ROLE.read_text().split()[0]
    except (OSError, IndexError):
        role = ''
    return role == 'MASTER' or (role == '' and vip_here(conf.get('address')))


def vip_prefer(store, conf=None):
    conf = conf or vip_conf(store)
    if conf.get('mode') == 'stays':
        # Whoever holds it now (or is getting it).
        moving = vip_moving(conf)
        if moving:
            return moving
        for n in ha_nodes(store):
            w = web_state(store) if n['me'] else (n.get('web') or {})
            if w.get('vip_here'):
                return n['name']
        return ''
    want = str(conf.get('prefer') or '')
    if want:
        return want
    # Nobody chosen: the first node of the cluster.
    for n in ha_nodes(store):
        if n['me'] and int(CONFIG.get('ha_slot') or 1) == 1:
            return n['name']
    names = sorted(n['name'] for n in ha_nodes(store))
    return names[0] if names else node_name()


# ---- certificates: read, taken apart, made -----------------------------------
def _openssl(args, data=None, env=None, what='openssl'):
    e = dict(os.environ)
    e.update(env or {})
    got = subprocess.run(['openssl'] + args, input=data, capture_output=True, env=e,
                         timeout=120)
    if got.returncode != 0:
        said = (got.stderr or got.stdout or b'').decode('utf-8', 'replace').strip()
        raise ValueError('%s: %s' % (what, (said.splitlines() or ['openssl said no'])[-1][:200]))
    return got.stdout


PEM_CERT = re.compile(r'-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----')
PEM_KEY = re.compile(r'-----BEGIN ((?:RSA |EC |ENCRYPTED )?PRIVATE KEY)-----[A-Za-z0-9+/=\s:,-]+?'
                     r'-----END \1-----')


def cert_info(pem):
    """What a certificate says of itself, for the pages."""
    out = _openssl(['x509', '-noout', '-subject', '-issuer', '-startdate', '-enddate',
                    '-fingerprint', '-sha256', '-ext', 'subjectAltName', '-nameopt',
                    'RFC2253'], pem.encode(), what='the certificate').decode()
    info = {'san': []}
    lines = out.splitlines()
    for i, line in enumerate(lines):
        if line.startswith('subject='):
            info['subject'] = line[8:].strip()
        elif line.startswith('issuer='):
            info['issuer'] = line[7:].strip()
        elif line.startswith('notBefore='):
            info['not_before'] = _cert_time(line[10:])
        elif line.startswith('notAfter='):
            info['not_after'] = _cert_time(line[9:])
        elif 'Fingerprint=' in line:
            info['fingerprint'] = line.split('=', 1)[1].strip()
        elif 'Subject Alternative Name' in line and i + 1 < len(lines):
            info['san'] = [x.strip().split(':', 1)[-1] for x in lines[i + 1].split(',')
                           if x.strip()]
    info['self_signed'] = info.get('subject') == info.get('issuer')
    cn = re.search(r'(?:^|,)CN=([^,]+)', info.get('subject') or '')
    info['cn'] = cn.group(1) if cn else ''
    try:
        pub = _openssl(['x509', '-noout', '-pubkey'], pem.encode()).decode()
        txt = _openssl(['pkey', '-pubin', '-noout', '-text'], pub.encode()).decode()
        m = re.search(r'\((\d+) bit\)', txt)
        info['key'] = ('%s %s bit' % ('EC' if 'ASN1 OID' in txt or 'NIST' in txt else 'RSA',
                                      m.group(1))) if m else ''
    except ValueError:
        info['key'] = ''
    return info


def _cert_time(text):
    try:
        return datetime.strptime(text.strip().replace('  ', ' '),
                                 '%b %d %H:%M:%S %Y %Z').replace(
            tzinfo=timezone.utc).timestamp()
    except ValueError:
        return None


def _pub_of_cert(pem):
    return _openssl(['x509', '-noout', '-pubkey'], pem.encode(), what='the certificate')


def _pub_of_key(pem):
    return _openssl(['pkey', '-pubout'], pem.encode(), what='the key')


def key_plain(pem, password=''):
    """A private key without its passphrase, as PEM."""
    return _openssl(['pkey', '-passin', 'env:OTP_PW'], pem.encode(),
                    {'OTP_PW': password or ''},
                    what='the key (a wrong or missing password?)').decode()


def cert_bundle(cert='', key='', chain='', root='', pfx=b'', password='', pending_key=''):
    """Whatever was sent - one PEM with everything in it, separate parts, or
    a PFX / PKCS#12 with or without a password - as the parts nginx needs:
    the certificate, its key, the chain up from it, the root. The key is the
    certificate's own or nothing is taken."""
    certs, keys = [], []
    if pfx:
        got = None
        for extra in ([], ['-legacy']):
            try:
                got = _openssl(['pkcs12', '-nodes', '-passin', 'env:OTP_PW'] + extra, pfx,
                               {'OTP_PW': password or ''}, what='the PFX / PKCS#12 file')
                break
            except ValueError as e:
                last = e
        if got is None:
            raise ValueError('%s - is the password right?' % last)
        text = got.decode('utf-8', 'replace')
        certs += [m.group(0) for m in PEM_CERT.finditer(text)]
        keys += [m.group(0) for m in PEM_KEY.finditer(text)]
    for part in (cert, chain, root, key):
        part = str(part or '')
        certs += [m.group(0) for m in PEM_CERT.finditer(part)]
        keys += [m.group(0) for m in PEM_KEY.finditer(part)]
    if not certs:
        raise ValueError('no certificate was found in what was sent (PEM, or a PFX / PKCS#12 '
                         'file)')
    if len(keys) > 1:
        raise ValueError('more than one private key was sent')
    if keys:
        key_pem = key_plain(keys[0], password)
    elif pending_key:
        key_pem = pending_key
    else:
        raise ValueError('no private key came with it: send the key too (or the PFX), or make '
                         'the request here first so the key is waiting')
    want = _pub_of_key(key_pem)
    leaf = next((c for c in certs if _pub_of_cert(c) == want), None)
    if not leaf:
        raise ValueError('none of the certificates is the one of this key')
    others = [c for c in certs if c != leaf]
    infos = {c: cert_info(c) for c in others}
    roots = [c for c in others if infos[c]['self_signed']]
    roots += [m.group(0) for m in PEM_CERT.finditer(str(root or '')) if m.group(0) not in roots]
    inter = [c for c in others if c not in roots]
    # The chain in order: each the issuer of the one before it.
    chain_out, at = [], cert_info(leaf)
    while inter:
        nxt = next((c for c in inter if infos[c].get('subject') == at.get('issuer')), None)
        if not nxt:
            chain_out += inter
            break
        chain_out.append(nxt)
        inter.remove(nxt)
        at = infos[nxt]
    info = cert_info(leaf)
    verify = ''
    if roots:
        with tempfile.TemporaryDirectory(prefix='otp-cert-') as t:
            def put(name, text):
                p = os.path.join(t, name)
                with open(p, 'w') as f:
                    f.write(text)
                return p
            args = ['verify', '-CAfile', put('root.pem', '\n'.join(roots) + '\n')]
            if chain_out:
                args += ['-untrusted', put('chain.pem', '\n'.join(chain_out) + '\n')]
            args.append(put('leaf.pem', leaf + '\n'))
            try:
                _openssl(args, what='the chain')
                verify = 'ok'
            except ValueError as e:
                verify = str(e)
    return {'cert': leaf + '\n', 'chain': ''.join(c + '\n' for c in chain_out),
            'root': ''.join(c + '\n' for c in roots), 'key': key_pem, 'info': info,
            'chain_info': [cert_info(c) for c in chain_out],
            'root_info': [cert_info(c) for c in roots], 'verify': verify}


def _san_ext(names):
    out = []
    for n in names:
        n = str(n).strip()
        if not n:
            continue
        try:
            ipaddress.ip_address(n)
            out.append('IP:' + n)
        except ValueError:
            if not re.match(r'^(\*\.)?[A-Za-z0-9.-]{1,253}$', n):
                raise ValueError('%r is not a name or an address' % n)
            out.append('DNS:' + n)
    return ','.join(out)


def _subject(cn, org='', unit='', country='', city=''):
    def esc(v):
        return re.sub(r'([/\\=+,])', r'\\\1', str(v).strip())
    if not cn or not re.match(r'^[A-Za-z0-9*.-]{1,64}$', cn):
        raise ValueError('the common name is a host name')
    s = '/CN=' + esc(cn)
    if org:
        s += '/O=' + esc(org)
    if unit:
        s += '/OU=' + esc(unit)
    if city:
        s += '/L=' + esc(city)
    if country:
        if not re.match(r'^[A-Za-z]{2}$', country):
            raise ValueError('the country is two letters (CZ)')
        s += '/C=' + country.upper()
    return s


def new_key(kind):
    if kind == 'ec':
        return _openssl(['genpkey', '-algorithm', 'EC', '-pkeyopt',
                         'ec_paramgen_curve:P-256']).decode()
    bits = {'rsa2048': 2048, 'rsa3072': 3072, 'rsa4096': 4096}.get(kind)
    if not bits:
        raise ValueError('the key is ec, rsa2048, rsa3072 or rsa4096')
    return _openssl(['genpkey', '-algorithm', 'RSA', '-pkeyopt',
                     'rsa_keygen_bits:%d' % bits]).decode()


def make_csr(cn, names, kind='rsa2048', **subject):
    key = new_key(kind)
    with tempfile.TemporaryDirectory(prefix='otp-csr-') as t:
        kf = os.path.join(t, 'k.pem')
        with open(kf, 'w') as f:
            f.write(key)
        csr = _openssl(['req', '-new', '-key', kf, '-subj', _subject(cn, **subject),
                        '-addext', 'subjectAltName=' + _san_ext([cn] + list(names))],
                       what='the request').decode()
    return key, csr


def make_selfsigned(cn, names, days=825, kind='rsa2048', **subject):
    key = new_key(kind)
    with tempfile.TemporaryDirectory(prefix='otp-crt-') as t:
        kf = os.path.join(t, 'k.pem')
        with open(kf, 'w') as f:
            f.write(key)
        crt = _openssl(['req', '-new', '-x509', '-key', kf, '-days', str(int(days)), '-subj',
                        _subject(cn, **subject), '-addext',
                        'subjectAltName=' + _san_ext([cn] + list(names))],
                       what='the certificate').decode()
    return key, crt


# ---- the TLS of a target, kept ---------------------------------------------------------
def tls_targets(store):
    names = sorted(set([node_name()] + [n['name'] for n in ha_nodes(store)]))
    return names + ['vip']


def tls_save(store, target, prof, by):
    prof = dict(prof)
    prof['at'] = time.time()
    prof['by'] = by
    store.set_meta('web:tls:' + target, json.dumps(prof))


def tls_view(prof):
    """A profile as the pages may see it: no key."""
    if not prof:
        return None
    out = {k: v for k, v in prof.items() if k not in ('key', 'pending_key')}
    out['has_key'] = bool(prof.get('key'))
    out['pending'] = bool(prof.get('pending_key'))
    return out


def tls_policy_checked(b):
    preset = str(b.get('preset') or 'standard')
    if preset not in list(TLS_PRESETS) + ['custom']:
        raise ValueError('the TLS settings are standard, intermediate, modern or custom')
    out = {'preset': preset}
    if preset == 'custom':
        prot = b.get('protocols') or []
        if not isinstance(prot, list) or not prot or \
                any(p not in ('TLSv1.2', 'TLSv1.3') for p in prot):
            raise ValueError('the protocols are TLSv1.2 and/or TLSv1.3')
        out['protocols'] = [p for p in ('TLSv1.2', 'TLSv1.3') if p in prot]
        ciphers = str(b.get('ciphers') or '').strip()
        if ciphers:
            if not re.match(r'^[A-Za-z0-9_+!@=:.-]{1,2000}$', ciphers):
                raise ValueError('the ciphers are an OpenSSL cipher list')
            _openssl(['ciphers', ciphers], what='OpenSSL does not know that cipher list')
        out['ciphers'] = ciphers
    dh = str(b.get('dh') or 'none')
    if dh not in DH_WORDS:
        raise ValueError('the DH parameters are one of %s' % ', '.join(DH_WORDS))
    out['dh'] = dh
    out['prefer'] = bool(b.get('prefer'))
    try:
        out['hsts'] = max(0, min(63072000, int(b.get('hsts') or 0)))
    except (TypeError, ValueError):
        raise ValueError('HSTS is a number of seconds')
    return out


def tls_resolved(prof):
    """What root is handed for a profile: the parts and the lines."""
    if not prof:
        return None
    preset = prof.get('preset') or 'standard'
    p = TLS_PRESETS.get(preset) or {'protocols': prof.get('protocols') or ['TLSv1.2', 'TLSv1.3'],
                                    'ciphers': prof.get('ciphers') or ''}
    out = {'protocols': p['protocols'], 'ciphers': p['ciphers'], 'prefer': bool(prof.get('prefer')),
           'dh': prof.get('dh') or 'none', 'hsts': int(prof.get('hsts') or 0)}
    if prof.get('cert') and prof.get('key'):
        out.update(cert=prof['cert'], chain=prof.get('chain') or '', root=prof.get('root') or '',
                   key=unseal_secret(prof['key'], 'web:tls'))
    return out


# ---- what this node asks of root, and how it went -------------------------------------
def web_desired(store):
    me = node_name()
    v = vip_conf(store)
    vip = {'on': False}
    many = bool(CONFIG.get('ha_mode'))
    if v.get('on') and many:
        vip = {'on': True, 'address': v.get('address'), 'fqdn': v.get('fqdn') or '',
               'vrid': int(v.get('vrid') or 51), 'auth': vip_auth(),
               'own': CONFIG.get('ha_address') or node_address(),
               'peer': CONFIG.get('ha_peer') or '',
               'iface': (v.get('ifaces') or {}).get(me, '')}
    tls = {'node': tls_resolved(tls_profile(store, me)),
           'vip': tls_resolved(tls_profile(store, 'vip')) if vip['on'] else None}
    out = {'node': me, 'vip': vip, 'tls': tls}
    # Asked only once set on the pages (1.0.52): a request from before had
    # neither, and its hash stays what it was.
    fw, access = fw_desired(store), access_desired(store)
    if fw is not None:
        out['fw'] = fw
    if access is not None:
        out['access'] = access
    return out


def web_hash(desired):
    return hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()


def web_status():
    try:
        fd = os.open(str(WEB_DIR / 'status.json'), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as f:
            got = json.loads(f.read(1 << 20).decode('utf-8'))
        return got if isinstance(got, dict) else {}
    except (OSError, ValueError):
        return {}


def web_tick(store):
    """Asks root for this node's part when what is wanted has changed."""
    if HA_REBUILDING.is_set() or not WEB_DIR.is_dir():
        return
    desired = web_desired(store)
    # Nothing ever asked and nothing to ask: no request at all.
    st = web_status()
    if not st and not desired['vip']['on'] and not desired['tls']['node'] and \
            'fw' not in desired and 'access' not in desired:
        return
    h = web_hash(desired)
    if st.get('hash') == h:
        if st.get('state') == 'done':
            return
        # Failed with exactly this: asked again only when somebody says so.
        if float(store.get_meta('web:retry:' + node_name()) or 0) <= float(st.get('at') or 0):
            return
    req = WEB_DIR / 'request.json'
    if req.exists() and time.time() - req.stat().st_mtime < 600:
        # Waiting for root: left as it is when it asks for this very thing,
        # replaced when what is wanted changed meanwhile.
        try:
            if json.loads(req.read_text()).get('hash') == h:
                return
        except (OSError, ValueError):
            return
    body = dict(desired, id=secrets.token_hex(8), hash=h)
    tmp = WEB_DIR / 'request.part'
    try:
        tmp.unlink()
    except OSError:
        pass
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(body, f)
    os.replace(str(tmp), str(req))
    WEB_ASKED['hash'] = h
    WEB_ASKED['at'] = time.time()


WEB_ASKED = {'hash': '', 'at': 0.0}


def web_progress():
    """What root is doing now, if anything (1.0.50)."""
    try:
        fd = os.open(str(WEB_DIR / 'progress.json'), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as f:
            got = json.loads(f.read(65536).decode('utf-8'))
    except (OSError, ValueError):
        return None
    if not isinstance(got, dict) or time.time() - float(got.get('at') or 0) > 3 * 3600:
        return None
    got['now'] = time.time()
    return got


def web_state(store):
    """This node's web side, for its heartbeat: what root said last, whether
    that is what is wanted now, and the address."""
    st = web_status()
    desired_hash = ''
    try:
        desired_hash = web_hash(web_desired(store))
    except Exception:                                   # noqa: BLE001
        pass
    role = ''
    try:
        role = VIP_ROLE.read_text().split()[0]
    except (OSError, IndexError):
        pass
    v = vip_conf(store)
    return {'cert_now': cert_now('/etc/nginx/certs/otp.pem'),
            'vip_cert_now': cert_now('/etc/nginx/certs/otp-vip.pem'),
            'state': st.get('state') or '', 'said': (st.get('said') or [])[-6:],
            'at': st.get('at'), 'current': bool(st) and st.get('hash') == desired_hash,
            'waiting': (WEB_DIR / 'request.json').exists(),
            'progress': web_progress(),
            'iface': (st.get('applied') or {}).get('iface') or '',
            'vip_here': vip_here(v.get('address')) if v.get('on') else False,
            'role': role, 'health': dict(VIP_HEALTH),
            'fw': st.get('fw') or {}, 'access': st.get('access') or {},
            'ifaces': sorted(os.listdir('/sys/class/net')) if os.path.isdir('/sys/class/net')
            else []}


CERT_NOW = {}


def cert_now(path):
    """What the certificate nginx has in `path` says - read again only
    when the file changes."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    had = CERT_NOW.get(path)
    if had and had[0] == st.st_mtime:
        return had[1]
    try:
        with open(path) as f:
            text = f.read(200000)
        m = PEM_CERT.search(text)
        info = cert_info(m.group(0)) if m else None
        if info:
            info['chain'] = max(0, len(PEM_CERT.findall(text)) - 1)
    except (OSError, ValueError):
        info = None
    CERT_NOW[path] = (st.st_mtime, info)
    return info


def local_addresses():
    """Every address on this machine's interfaces, read from the kernel.

    Not by binding to it (1.0.55): with net.ipv4.ip_nonlocal_bind on - which
    the web address turns on since 1.0.51, so nginx can listen on it - a bind
    succeeds for an address the machine does not hold, and both nodes said
    they had the web address."""
    out = set()
    try:
        # IPv4: the local table of the FIB, "/32 host LOCAL" under each address.
        last = None
        with open('/proc/net/fib_trie') as f:
            for line in f:
                m = re.match(r'^\s*\|--\s+([0-9.]+)\s*$', line)
                if m:
                    last = m.group(1)
                elif last and '/32 host LOCAL' in line:
                    out.add(last)
    except OSError:
        pass
    try:
        with open('/proc/net/if_inet6') as f:
            for line in f:
                h = line.split()[0]
                if len(h) == 32:
                    out.add(str(ipaddress.ip_address(int(h, 16))))
    except (OSError, ValueError, IndexError):
        pass
    if not out and shutil.which('ip'):
        got = subprocess.run(['ip', '-o', 'addr', 'show'], capture_output=True, text=True)
        for m in re.finditer(r'\binet6?\s+([0-9a-fA-F:.]+)/', got.stdout or ''):
            out.add(str(ipaddress.ip_address(m.group(1))))
    return out


def vip_here(address):
    """Does this machine hold the address now? Its interfaces say so."""
    try:
        ip = ipaddress.ip_interface(str(address or '')).ip
    except ValueError:
        return False
    return str(ip) in local_addresses()


# ---- may this node hold the address? ---------------------------------------------------
def vip_health_check(daemon):
    """One look at everything the pages need, from outside the daemon: its
    own /healthz through nginx and PHP to the daemon and the database - and
    RADIUS listening, and no maintenance, upgrade or rebuild. A node that is
    not healthy lets the address go to the other."""
    store = daemon.store
    why = ''
    if HA_REBUILDING.is_set():
        why = 'being rebuilt from the other node'
    elif maintenance_now(store).get('on'):
        why = 'in maintenance'
    elif not getattr(getattr(daemon, 'radius', None), 'bound', None):
        why = 'RADIUS is not listening'
    elif VIP_HEALTH_URL == 'none':
        pass                            # a test bed whose nginx is another node's
    else:
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(VIP_HEALTH_URL,
                                         headers={'User-Agent': 'otp-vip-check'})
            with urllib.request.urlopen(req, timeout=4, context=ctx) as r:
                body = r.read(200).decode('utf-8', 'replace')
                if r.status != 200 or not body.startswith('ok'):
                    why = 'its pages say: %s' % body.strip()[:80]
        except urllib.error.HTTPError as e:
            try:
                why = 'its pages say %d: %s' % (e.code, e.read(200).decode('utf-8',
                                                                           'replace').strip()[:80])
            except Exception:                           # noqa: BLE001
                why = 'its pages say %d' % e.code
        except Exception as e:                          # noqa: BLE001
            why = 'its pages do not answer (%s)' % str(e)[:80]
    return why


def vip_watch(daemon):
    """Every three seconds: /run/otp/vip-state for keepalived."""
    while not daemon.stop_flag.wait(3):
        try:
            store = daemon.store
            v = vip_conf(store)
            if not v.get('on') or not CONFIG.get('ha_mode'):
                try:
                    VIP_STATE.unlink()
                except OSError:
                    pass
                continue
            why = vip_health_check(daemon)
            if why:
                VIP_HEALTH['fails'] += 1
            else:
                VIP_HEALTH['fails'] = 0
            ok = VIP_HEALTH['fails'] < VIP_FAILS_BEFORE
            if not why or not ok or VIP_HEALTH['ok'] is None:
                VIP_HEALTH.update(ok=ok, why=why if not ok else '')
            VIP_HEALTH['at'] = time.time()
            prefer = vip_prefer_me(store, v)
            line = ('ok prefer' if prefer else 'ok') if ok else 'fail ' + (why or '?')
            tmp = RUN_DIR / '.vip-state'
            tmp.write_text(line + '\n')
            os.chmod(str(tmp), 0o640)
            os.replace(str(tmp), str(VIP_STATE))
        except Exception as e:                          # noqa: BLE001
            log('the web address: %s' % e, 'warn')
            daemon.stop_flag.wait(10)


# ---- what the pages and the command line change ----------------------------------------
def vip_checked(b, store):
    try:
        net = ipaddress.ip_interface(str(b.get('address') or '').strip())
    except ValueError:
        raise ValueError('the web address is an address with its prefix, e.g. 192.0.2.10/24')
    if '/' not in str(b.get('address') or ''):
        raise ValueError('give the prefix with the address, e.g. 192.0.2.10/24')
    if net.ip.is_loopback or net.ip.is_multicast or net.ip.is_unspecified:
        raise ValueError('%s cannot be the web address' % net.ip)
    nodes = [n for n in ha_nodes(store)]
    for n in nodes:
        if str(n.get('address') or '') == str(net.ip):
            raise ValueError('%s is the address of %s: the web address is a third one'
                             % (net.ip, n['name']))
    fqdn = str(b.get('fqdn') or '').strip().lower().rstrip('.')
    if fqdn and not re.match(r'^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?'
                             r'(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$', fqdn):
        raise ValueError('%r is not a host name' % fqdn)
    try:
        vrid = int(b.get('vrid') or 51)
    except (TypeError, ValueError):
        raise ValueError('the VRRP id is a number')
    if not 1 <= vrid <= 255:
        raise ValueError('the VRRP id is 1 to 255 - one no other VRRP on that network uses')
    ifaces = {}
    for k, val in (b.get('ifaces') or {}).items():
        val = str(val or '').strip()
        if val and not re.match(r'^[A-Za-z0-9_.:-]{1,15}$', val):
            raise ValueError('%r is not the name of a network interface' % val)
        if val:
            ifaces[str(k)] = val
    return {'address': str(net), 'fqdn': fqdn, 'vrid': vrid, 'ifaces': ifaces}


def vip_set(store, by, **changes):
    v = vip_conf(store)
    v.update(changes)
    v['at'] = time.time()
    v['by'] = by
    store.set_meta('web:vip', json.dumps(v))
    return v


# ---- a node renamed (1.0.48) ---------------------------------------------------------
NODE_NAME_FILE = STATE_DIR / 'node-name'


def node_carry(store, old, new, by='the daemon'):
    """What belongs to a node by its name, carried to its new name: its own
    settings (key@node), its maintenance, its TLS, its place as the web
    address's preferred node and its interface - and the old name off the
    list of nodes. Nothing the new name has already is overwritten."""
    if not old or old == new:
        return []
    said = []
    for r in store.db.rows('SELECT k, v FROM settings'):
        k = str(r['k'])
        if k.endswith('@' + old):
            want = k[:-len(old)] + new
            if store.db.value('SELECT 1 FROM settings WHERE k = ?', (want,)) is None:
                store.db.run('UPDATE settings SET k = ? WHERE k = ?', (want, k))
                said.append('its own setting %s' % k.split('@')[0])
            else:
                store.db.run('DELETE FROM settings WHERE k = ?', (k,))
    old_maint = _json_meta(store, 'maint:' + old)
    if old_maint and old_maint.get('on') and not (maintenance_row(store, new) or {}).get('on'):
        maintenance_set(store, True, old_maint.get('why') or 'carried over from %s' % old,
                        old_maint.get('by') or '', name=new)
        said.append('its maintenance')
    prof = store.get_meta('web:tls:' + old)
    if prof and store.get_meta('web:tls:' + new) is None:
        store.set_meta('web:tls:' + new, prof)
        said.append('its certificate and TLS settings')
    v = vip_conf(store)
    changed = False
    if v.get('prefer') == old:
        v['prefer'] = new
        changed = True
    ifaces = v.get('ifaces') or {}
    if old in ifaces and new not in ifaces:
        ifaces[new] = ifaces.pop(old)
        v['ifaces'] = ifaces
        changed = True
    if changed:
        store.set_meta('web:vip', json.dumps(v))
        said.append('its place in the web address')
    for k in ('node:', 'maint:', 'upgrade:node:', 'web:tls:', 'web:retry:', 'db_job:',
              'db_sizes:'):
        store.db.run('DELETE FROM meta WHERE k = ?', (k + old,))
    store.add_event('settings', 'the node %s is called %s now; carried over: %s' % (
        old, new, ', '.join(said) or 'nothing (it had nothing of its own)'), 'warn', who=by)
    return said


def node_name_check(store):
    """At the start: was this node called something else last time?"""
    me = node_name()
    try:
        before = NODE_NAME_FILE.read_text().strip()
    except OSError:
        before = ''
    if before and before != me:
        try:
            said = node_carry(store, before, me)
            log('this node was %s and is %s now; carried over: %s'
                % (before, me, ', '.join(said) or 'nothing'), 'warn')
        except Exception as e:                          # noqa: BLE001
            log('carrying %s over to %s: %s' % (before, me, e), 'warn')
            return
    if before != me:
        try:
            NODE_NAME_FILE.write_text(me + '\n')
        except OSError:
            pass


# ---- the local firewall and who may reach which pages (1.0.52) -------------------------
# Kept for the whole cluster in meta, put in by each node's root helper with
# the rest of the web side (one request, one status). What otp's functions
# need is worked out here from what is set up; the rules somebody adds by
# hand come first, so a DROP or REJECT of theirs wins over what otp opens.
FW_AUTO_OPTIONAL = ('ssh', 'icmp', 'dhcpv6', 'web', 'radius')
ACCESS_WORDS = {'portal': 'the enrolment pages', 'admin': 'the administration pages',
                'health': 'the health check (/healthz)'}


def fw_conf(store):
    c = _json_meta(store, 'fw:conf') or {}
    c.setdefault('on', False)
    c.setdefault('off', [])
    c.setdefault('rules', [])
    return c


def access_conf(store):
    return _json_meta(store, 'web:access') or {}


def cluster_addresses(store, node):
    """The other nodes' addresses, seen from `node`: what must always get in."""
    me = node_name()
    out = set()
    for n in ha_nodes(store):
        if n['name'] != node and n.get('address'):
            out.add(n['address'])
    if CONFIG.get('ha_mode'):
        if node == me and CONFIG.get('ha_peer'):
            out.add(CONFIG['ha_peer'])
        if node != me:
            out.add(CONFIG.get('ha_address') or node_address())
    v = vip_conf(store)
    if v.get('on') and v.get('address'):
        out.add(str(v['address']).split('/')[0])
    good = set()
    for a in out:
        try:
            good.add(str(ipaddress.ip_address(str(a).strip())))
        except ValueError:
            pass
    return sorted(good)


def _fam(addr):
    try:
        return ipaddress.ip_network(addr, strict=False).version
    except ValueError:
        return 0


def access_desired(store, node=None):
    """The three lists as nginx gets them: what was set, the cluster added."""
    a = access_conf(store)
    if not a:
        return None
    inner = cluster_addresses(store, node or node_name())
    out = {}
    for k in ACCESS_WORDS:
        one = a.get(k) or {'any': True, 'from': []}
        nets = list(one.get('from') or [])
        if not one.get('any'):
            nets += [x for x in inner if x not in nets]
        out[k] = {'any': bool(one.get('any')), 'from': nets}
    return out


def fw_auto(store, node):
    """What otp's functions need on `node`: [{key, title, why, fixed, rules}]."""
    peers = cluster_addresses(store, node)
    v = vip_conf(store)
    out = [{'key': 'ssh', 'title': 'SSH', 'why': 'to manage the machine - turned off, '
            'take care to keep a rule of your own for it',
            'rules': [{'family': f, 'proto': 'tcp', 'port': '22', 'source': ''} for f in (4, 6)]},
           {'key': 'icmp', 'title': 'ICMP / ICMPv6', 'why': 'ping, and IPv6 cannot work without '
            'ICMPv6 (neighbour discovery)',
            'rules': [{'family': f, 'proto': 'icmp', 'port': '', 'source': ''} for f in (4, 6)]},
           {'key': 'dhcpv6', 'title': 'DHCPv6 client', 'why': 'answers of a DHCPv6 server, for '
            'an address given that way', 'rules': [{'family': 6, 'proto': 'udp', 'port': '546',
                                                     'source': 'fe80::/10'}]}]
    # The pages: from everybody when one of the three is for everybody, else
    # from the networks of the three lists (nginx then says who sees which).
    a = access_conf(store)
    srcs = ['']
    if a and not any((a.get(k) or {}).get('any') for k in ACCESS_WORDS):
        srcs = []
        for k in ACCESS_WORDS:
            for n in (a.get(k) or {}).get('from') or []:
                if n not in srcs:
                    srcs.append(n)
    web = []
    for s in srcs:
        for f in ((4, 6) if not s else (_fam(s),)):
            web.append({'family': f, 'proto': 'tcp', 'port': '80,443', 'source': s})
    out.append({'key': 'web', 'title': 'HTTP / HTTPS', 'why': 'the enrolment and '
                'administration pages and the health check; who sees which is under '
                '"Who may reach the pages"', 'rules': web})
    ports = str(int(CONFIG.get('radius_auth_port') or 1812))
    if int(CONFIG.get('radius_acct_port') or 0):
        ports += ',%d' % int(CONFIG.get('radius_acct_port'))
    rad = []
    for c in store.clients():
        if not c.get('enabled'):
            continue
        try:
            net = address_net(c['address'])
        except (ValueError, KeyError):
            continue
        if net is None:
            continue
        rad.append({'family': net.version, 'proto': 'udp', 'port': ports, 'source': str(net),
                    'note': 'RADIUS %s' % c.get('name', '')})
    out.append({'key': 'radius', 'title': 'RADIUS', 'why': 'from each RADIUS client set up '
                '(Clients), and only from them', 'rules': rad})
    # Inside the cluster: always, never turned off.
    if CONFIG.get('ha_mode') and peers:
        pg = str(int(CONFIG.get('db_port') or 5432))
        nodes_only = [p for p in peers if p != str(v.get('address') or '').split('/')[0]]
        out.append({'key': 'cluster', 'title': 'The other node', 'fixed': True,
                    'why': 'replication (PostgreSQL), its pages and the health check - inside '
                    'the cluster everything has to work',
                    'rules': [{'family': _fam(p), 'proto': 'tcp', 'port': '%s,80,443' % pg,
                               'source': p} for p in nodes_only]})
        if v.get('on'):
            out.append({'key': 'vrrp', 'title': 'VRRP (the web address)', 'fixed': True,
                        'why': 'keepalived of the other node says it is there',
                        'rules': [{'family': _fam(p), 'proto': 'vrrp', 'port': '', 'source': p}
                                  for p in nodes_only]})
    off = set(fw_conf(store).get('off') or [])
    for item in out:
        item['fixed'] = bool(item.get('fixed'))
        item['on'] = item['fixed'] or item['key'] not in off
        for r in item['rules']:
            r.setdefault('note', item['title'])
            r['action'] = 'accept'
    return out


def fw_rules_for(store, node):
    """Everything the chain of `node` holds, in order."""
    c = fw_conf(store)
    auto = fw_auto(store, node)
    # The cluster first (1.0.52): nothing of anybody's can shut the other
    # node out; then the rules of your own; then the rest otp needs.
    rules = [r for item in auto if item['fixed'] for r in item['rules']]
    for r in c.get('rules') or []:
        if r.get('scope', 'all') not in ('all', node) or r.get('disabled'):
            continue
        for f in ((4, 6) if not r.get('family') else (int(r['family']),)):
            if r.get('source') and _fam(r['source']) != f:
                continue
            rules.append({'family': f, 'proto': r.get('proto') or 'any',
                          'port': r.get('port') or '', 'source': r.get('source') or '',
                          'action': r.get('action') or 'accept', 'note': r.get('note') or 'manual'})
    for item in auto:
        if item['on'] and not item['fixed']:
            rules += item['rules']
    return rules


def fw_desired(store):
    c = fw_conf(store)
    if not c.get('set'):
        return None
    return {'on': bool(c.get('on')), 'rules': fw_rules_for(store, node_name()) if c.get('on')
            else []}


FW_PROTOS = ('tcp', 'udp', 'icmp', 'vrrp', 'any')


def fw_rule_checked(b, store):
    """A rule somebody adds by hand, as it is kept."""
    fam = int(b.get('family') or 0)
    if fam not in (0, 4, 6):
        raise ApiError(400, 'IPv4, IPv6 or both')
    proto = str(b.get('proto') or 'any')
    if proto not in FW_PROTOS:
        raise ApiError(400, 'the protocol is one of %s' % ', '.join(FW_PROTOS))
    port = str(b.get('port') or '').replace(' ', '')
    if port:
        if proto not in ('tcp', 'udp'):
            raise ApiError(400, 'a port is for TCP or UDP')
        for p in port.split(','):
            m = re.match(r'^(\d{1,5})(?:-(\d{1,5}))?$', p)
            if not m or not 1 <= int(m.group(1)) <= 65535 or \
                    (m.group(2) and not int(m.group(1)) <= int(m.group(2)) <= 65535):
                raise ApiError(400, '%s is not a port or a range (80, 1812-1813, 80,443)' % p)
        if len(port.split(',')) > 15:
            raise ApiError(400, 'fifteen ports at most in one rule')
    src = str(b.get('source') or '').strip()
    if src:
        try:
            net = ipaddress.ip_network(src, strict=False)
        except ValueError:
            raise ApiError(400, '%s is not an address or a network' % src[:60])
        if fam and net.version != fam:
            raise ApiError(400, '%s is not an IPv%d address' % (src, fam))
        src, fam = str(net), net.version
    action = str(b.get('action') or 'accept')
    if action not in ('accept', 'drop', 'reject'):
        raise ApiError(400, 'accept, drop or reject')
    scope = str(b.get('scope') or 'all')
    if scope != 'all' and scope not in {n['name'] for n in ha_nodes(store)} | {node_name()}:
        raise ApiError(400, 'there is no node called %s' % scope)
    note = re.sub(r'[^A-Za-z0-9 ._:/@()+,-]', '', str(b.get('note') or ''))[:80]
    return {'family': fam, 'proto': proto, 'port': port, 'source': src, 'action': action,
            'scope': scope, 'note': note, 'disabled': bool(b.get('disabled'))}


def fw_set(store, by, **changes):
    c = fw_conf(store)
    c.update(changes)
    c.update(set=True, at=time.time(), by=by)
    store.set_meta('fw:conf', json.dumps(c))
    return c


def access_checked_api(b):
    out = {}
    for k, words in ACCESS_WORDS.items():
        one = b.get(k) or {}
        nets = []
        raw = one.get('from') or []
        if isinstance(raw, str):
            raw = re.split(r'[\s,;]+', raw)
        for x in raw[:200]:
            x = str(x).strip()
            if not x:
                continue
            try:
                n = str(ipaddress.ip_network(x, strict=False))
            except ValueError:
                raise ApiError(400, '%s: %s is not an address or a network' % (words, x[:60]))
            if n not in nets:
                nets.append(n)
        if not one.get('any') and not nets:
            raise ApiError(400, '%s would be for nobody: give a network, or let everybody in'
                           % words)
        out[k] = {'any': bool(one.get('any')), 'from': nets}
    return out


# ---- what happened to the cluster, written down (1.0.52) -------------------------------
# Every five seconds this node looks at what it can see - the web address
# here or not, its own health, the other node, replication both ways - and
# writes an event (kind 'ha') whenever one of them changes. Settings -
# High availability - History shows them, with what was changed by hand.
HA_SEEN = {}
PGLOG_ASK = 'pglog.ask'
PGLOG_FILE = 'pglog.json'


def _ha_change(store, key, now, words, level='warn'):
    """An event when `key` was something else before; nothing the first time."""
    was = HA_SEEN.get(key, '__first__')
    HA_SEEN[key] = now
    if was == '__first__' or was == now:
        return False
    store.add_event('ha', words, level)
    return True


def ha_watch_tick(store):
    me = node_name()
    if not CONFIG.get('ha_mode'):
        return
    v = vip_conf(store)
    if v.get('on'):
        try:
            role = VIP_ROLE.read_text().split()[0]
        except (OSError, IndexError):
            role = ''
        held = vip_here(v.get('address')) if role else False
        why = VIP_HEALTH.get('why') or ''
        _ha_change(store, 'vip', 'here' if held else 'not',
                   ('the web address %s came to %s%s' % (v.get('address'), me,
                                                           ' (%s)' % role if role else '')) if held
                   else ('the web address %s left %s%s' % (
                       v.get('address'), me, ' - %s' % why if why else
                       (' (%s)' % role if role else ''))))
        ok = VIP_HEALTH.get('ok')
        if ok is not None:
            _ha_change(store, 'health', 'ok' if ok else 'bad',
                       ('%s is healthy again: the web address may come back to it' % me) if ok
                       else ('%s is not healthy - %s: the web address leaves it' % (me, why or '?')),
                       'info' if ok else 'bad')
    else:
        HA_SEEN.pop('vip', None)
        HA_SEEN.pop('health', None)
    for n in ha_nodes(store):
        if n['me']:
            continue
        _ha_change(store, 'node:' + n['name'], 'alive' if n.get('alive') else 'gone',
                   ('%s answers again (seen from %s)' % (n['name'], me)) if n.get('alive')
                   else ('%s stopped answering (seen from %s, last heard %d s ago)'
                         % (n['name'], me, int(n.get('age') or 0))),
                   'info' if n.get('alive') else 'bad')
        m = bool((n.get('maintenance')))
        _ha_change(store, 'maint:' + n['name'], 'on' if m else 'off',
                   '%s %s maintenance' % (n['name'], 'went into' if m else 'came out of'), 'info')
    if CONFIG.get('ha_mode') != 'replicated':
        return
    r = ha_repl_state(store)
    if r.get('trouble'):
        return
    for x in r.get('incoming') or []:
        name = x.get('name')
        state = 'running' if x.get('running') else ('paused' if not x.get('enabled') else 'stopped')
        _ha_change(store, 'in:' + name, state,
                   'replication coming in (%s): %s' % (name, {
                       'running': 'running again', 'paused': 'paused',
                       'stopped': 'stopped - the other node or its PostgreSQL is not reached, or '
                                  'an error stops it'}[state]),
                   {'running': 'info', 'paused': 'warn'}.get(state, 'bad'))
        errs = int(x.get('apply_errors') or 0) + int(x.get('sync_errors') or 0)
        was = HA_SEEN.get('err:' + name)
        HA_SEEN['err:' + name] = errs
        if was is not None and errs > was:
            store.add_event('ha', 'replication coming in (%s): %d new error(s), %d in all - '
                                  'Settings - High availability - the errors say what'
                                  % (name, errs - was, errs), 'bad')
    for x in r.get('outgoing') or []:
        _ha_change(store, 'out:' + x['name'], x.get('wal_status') or '',
                   'replication going out (%s): %s' % (x['name'], {
                       'lost': 'LOST - the other node waited too long and has to be rebuilt',
                       'unreserved': 'about to be lost - the other node is far behind',
                       'extended': 'the other node is behind', 'reserved': 'caught up'}.get(
                           x.get('wal_status'), x.get('wal_status') or '?')),
                   'bad' if x.get('wal_status') in ('lost', 'unreserved') else 'info')


def ha_history(store, limit=300, since=0, until=0):
    """The cluster's story: what this watch saw and what was done by hand."""
    span, args = '', []
    cleared = float(store.get_meta('ha:history_cleared') or 0)
    since = max(float(since or 0), cleared)
    if since:
        span += ' AND ts >= ?'
        args.append(float(since))
    if until:
        span += ' AND ts < ?'
        args.append(float(until))
    rows = store.db.rows(
        "SELECT ts, kind, node, level, who, words FROM events WHERE (kind = 'ha' OR "
        "(kind = 'settings' AND (words LIKE '%web address%' OR words LIKE '%replication%' OR "
        "words LIKE '%maintenance%' OR words LIKE '%rebuilt%' OR words LIKE '%cluster%' OR "
        "words LIKE '%upgrade%') AND words NOT LIKE '%certificate%' AND "
        "words NOT LIKE '%TLS%'))" + span +
        " ORDER BY ts DESC LIMIT " + str(int(limit)), args)
    for r in rows:
        w = (r.get('words') or '').lower()
        r['what'] = ('vip' if 'web address' in w else 'replication' if 'replication' in w
                     or 'rebuilt' in w else 'maintenance' if 'maintenance' in w or 'upgrade' in w
                     else 'node')
    return rows


# ---- replication's errors: counted since cleared, read from PostgreSQL's log -----------
def repl_errors(store, ask_log=True):
    """The errors of each subscription since they were last cleared, and what
    PostgreSQL's log says about them (root reads it: the log is postgres's)."""
    r = ha_repl_state(store)
    base = _json_meta(store, 'ha:errbase:' + node_name()) or {}
    subs = []
    for x in r.get('incoming') or []:
        b = base.get(x['name']) or {}
        subs.append({'name': x['name'], 'running': x.get('running'), 'enabled': x.get('enabled'),
                     'apply': int(x.get('apply_errors') or 0),
                     'sync': int(x.get('sync_errors') or 0),
                     'apply_new': max(0, int(x.get('apply_errors') or 0) - int(b.get('apply') or 0)),
                     'sync_new': max(0, int(x.get('sync_errors') or 0) - int(b.get('sync') or 0)),
                     'cleared': base.get('at'), 'cleared_by': base.get('by')})
    got = {}
    if ask_log and WEB_DIR.is_dir():
        ask = WEB_DIR / PGLOG_ASK
        t0 = time.time()
        try:
            ask.write_text(json.dumps({'at': t0, 'port': int(CONFIG.get('db_port') or 5432)}))
        except OSError:
            pass
        while time.time() - t0 < 8:
            got = _pglog_read()
            if float(got.get('at') or 0) >= t0:
                break
            time.sleep(0.4)
    else:
        got = _pglog_read()
    since = float(base.get('at') or 0)
    lines = [e for e in got.get('entries') or [] if float(e.get('ts') or 0) >= since or
             not e.get('ts')]
    return {'subs': subs, 'log': lines[-60:], 'log_at': got.get('at'),
            'log_file': got.get('file') or '', 'log_said': got.get('said') or '',
            'fresh': float(got.get('at') or 0) >= time.time() - 15}


def _pglog_read():
    try:
        fd = os.open(str(WEB_DIR / PGLOG_FILE), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as f:
            got = json.loads(f.read(1 << 20).decode('utf-8', 'replace'))
        return got if isinstance(got, dict) else {}
    except (OSError, ValueError):
        return {}


def repl_errors_clear(store, by):
    r = ha_repl_state(store)
    base = {'at': time.time(), 'by': by}
    for x in r.get('incoming') or []:
        base[x['name']] = {'apply': int(x.get('apply_errors') or 0),
                           'sync': int(x.get('sync_errors') or 0)}
    store.set_meta('ha:errbase:' + node_name(), json.dumps(base))
    return base


# ---------------------------------------------------------------------------
# From opt to otp (1.0.37): the database's own names
# ---------------------------------------------------------------------------
# Until 1.0.37 this program was called opt, and so were the database and the
# account it made, and its replication. install.sh --upgrade moves the files,
# folders and system accounts; this (otp --rename-from-opt, as root) does the
# databases on this machine:
#
#   * PostgreSQL here: the database opt and the account opt are renamed otp,
#     and pg_hba.conf with them;
#   * MariaDB here: the tables are moved into a database otp, the account is
#     renamed and given that database;
#   * replicated: the publication, this node's subscription, and the slot on
#     this node with the other node's subscription to it - renamed without a
#     row lost: the other node's subscription is paused, the slot copied
#     under its new name at the same place, the subscription pointed at it
#     (and at the renamed database and account), resumed, and the old slot
#     dropped. Whichever node goes first, the second finishes the job.
#
# A database on another machine is left as it is (that takes its own
# administrator): its names are written into config.json, so nothing breaks.
RENAME_OLD, RENAME_NEW = 'opt', 'otp'


def _local_host(c):
    h = str(c.get('db_host') or '').strip()
    return h in ('', '127.0.0.1', 'localhost', '::1') or h.startswith('/')


def _pg_hba_rename(port, say):
    """'opt' as a database or an account in pg_hba.conf becomes 'otp'."""
    path = pg_admin('SHOW hba_file', port)
    try:
        lines = Path(path).read_text().splitlines(True)
    except OSError as e:
        say('pg_hba.conf could not be read (%s): look at it by hand' % e)
        return
    out, changed = [], 0
    for line in lines:
        bare = line.split('#', 1)[0]
        bits = bare.split()
        if bits and bits[0] in ('local', 'host', 'hostssl', 'hostnossl', 'hostgssenc',
                                'hostnogssenc') and len(bits) >= 3:
            def fix(field):
                return ','.join(RENAME_NEW if x == RENAME_OLD else x for x in field.split(','))
            db_f, user_f = fix(bits[1]), fix(bits[2])
            if (db_f, user_f) != (bits[1], bits[2]):
                rest = line[len(line) - len(line.lstrip()):]
                head = line[:len(line) - len(rest)]
                parts = re.split(r'(\s+)', rest)
                # parts: word, space, word, space, word, ... - fields 1 and 2
                words = [i for i, p in enumerate(parts) if p and not p.isspace()]
                parts[words[1]], parts[words[2]] = db_f, user_f
                line = head + ''.join(parts)
                changed += 1
        out.append(line)
    if changed:
        shutil.copy2(path, path + '.before-otp')
        Path(path).write_text(''.join(out))
        pg_admin('SELECT pg_reload_conf()', port)
        say('pg_hba.conf: %d line(s) now name otp (the old one is %s.before-otp)'
            % (changed, path))


def _pg_rename_local(c, say):
    port = int(c.get('db_port') or 5432)
    name, user = str(c.get('db_name') or RENAME_OLD), str(c.get('db_user') or RENAME_OLD)
    new = {}

    def exists(sql):
        return pg_admin(sql, port) == '1'
    if name == RENAME_OLD:
        if exists("SELECT 1 FROM pg_database WHERE datname = '%s'" % RENAME_NEW):
            say('PostgreSQL already has a database otp: the database opt keeps its name')
        elif exists("SELECT 1 FROM pg_database WHERE datname = '%s'" % RENAME_OLD):
            pg_admin("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = "
                     "'%s' AND pid <> pg_backend_pid()" % RENAME_OLD, port)
            time.sleep(1)
            pg_admin('ALTER DATABASE %s RENAME TO %s' % (RENAME_OLD, RENAME_NEW), port)
            new['db_name'] = RENAME_NEW
            say('PostgreSQL: the database opt is now otp')
    if user == RENAME_OLD:
        if exists("SELECT 1 FROM pg_roles WHERE rolname = '%s'" % RENAME_NEW):
            say('PostgreSQL already has an account otp: the account opt keeps its name')
        elif exists("SELECT 1 FROM pg_roles WHERE rolname = '%s'" % RENAME_OLD):
            pg_admin('ALTER ROLE %s RENAME TO %s' % (RENAME_OLD, RENAME_NEW), port)
            if c.get('db_password'):
                # An MD5 password does not survive a rename; it is set again.
                pg_admin("ALTER ROLE %s PASSWORD '%s'" % (
                    RENAME_NEW, str(c['db_password']).replace("'", "''")), port, secret=True)
            new['db_user'] = RENAME_NEW
            say('PostgreSQL: the account opt is now otp')
    if new:
        _pg_hba_rename(port, say)
    return new


def _mariadb(sql):
    for cmd in ('mariadb', 'mysql'):
        if shutil.which(cmd):
            got = subprocess.run([cmd, '-uroot', '-N', '-B', '-e', sql], capture_output=True,
                                 text=True, timeout=300)
            if got.returncode == 0:
                return got.stdout.strip()
            raise ValueError((got.stderr or got.stdout).strip()[:300] or 'mariadb failed')
    raise ValueError('the mariadb client is not on this machine')


def _mariadb_rename_local(c, say):
    name, user = str(c.get('db_name') or RENAME_OLD), str(c.get('db_user') or RENAME_OLD)
    new = {}
    if name == RENAME_OLD:
        if _mariadb("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = "
                    "'%s'" % RENAME_NEW) != '0':
            say('MariaDB already has a database otp: the database opt keeps its name')
        else:
            tables = [t for t in _mariadb("SELECT TABLE_NAME FROM information_schema.TABLES "
                                          "WHERE TABLE_SCHEMA = '%s'" % RENAME_OLD).split('\n')
                      if t.strip()]
            _mariadb('CREATE DATABASE `%s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'
                     % RENAME_NEW)
            if tables:
                _mariadb('RENAME TABLE ' + ', '.join('`%s`.`%s` TO `%s`.`%s`' % (
                    RENAME_OLD, t, RENAME_NEW, t) for t in tables))
            _mariadb('DROP DATABASE `%s`' % RENAME_OLD)
            new['db_name'] = RENAME_NEW
            say('MariaDB: the database opt is now otp (%d tables moved)' % len(tables))
    target_db = new.get('db_name', name)
    hosts = [h for h in _mariadb("SELECT Host FROM mysql.user WHERE User = '%s'"
                                 % (RENAME_OLD if user == RENAME_OLD else user)).split('\n')
             if h.strip()]
    if user == RENAME_OLD and hosts:
        if _mariadb("SELECT COUNT(*) FROM mysql.user WHERE User = '%s'" % RENAME_NEW) != '0':
            say('MariaDB already has an account otp: the account opt keeps its name')
        else:
            for h in hosts:
                _mariadb("RENAME USER '%s'@'%s' TO '%s'@'%s'" % (RENAME_OLD, h, RENAME_NEW, h))
            new['db_user'] = RENAME_NEW
            say('MariaDB: the account opt is now otp')
    who = new.get('db_user', user)
    if new:
        for h in hosts:
            _mariadb("GRANT ALL PRIVILEGES ON `%s`.* TO '%s'@'%s'" % (target_db, who, h))
            try:
                _mariadb("REVOKE ALL PRIVILEGES ON `%s`.* FROM '%s'@'%s'" % (RENAME_OLD, who, h))
            except ValueError:
                pass
        _mariadb('FLUSH PRIVILEGES')
    return new


def _ha_rename(c, say):
    """The replication's objects, on this node and the other one's
    subscription to it. Run with this node's daemon stopped."""
    port = int(c.get('db_port') or 5432)
    db = str(c.get('db_name') or RENAME_NEW)
    slot = int(c.get('ha_slot') or 1)
    peer_slot = 3 - slot
    if pg_admin("SELECT 1 FROM pg_publication WHERE pubname = '%s'" % HA_PUB_OLD, port, db) == '1':
        if pg_admin("SELECT 1 FROM pg_publication WHERE pubname = '%s'" % HA_PUB, port, db) != '1':
            pg_admin('ALTER PUBLICATION %s RENAME TO %s' % (HA_PUB_OLD, HA_PUB), port, db)
            say('replication: the publication is now %s' % HA_PUB)
    # This node's subscription, bringing the other's rows: its name.
    old_in, new_in = 'opt_from_%d' % peer_slot, ha_sub_name(peer_slot)
    if pg_admin("SELECT 1 FROM pg_subscription WHERE subname = '%s'" % old_in, port, db) == '1':
        pg_admin('ALTER SUBSCRIPTION %s RENAME TO %s' % (old_in, new_in), port, db)
        say('replication: this node\'s subscription is now %s' % new_in)
    # The slot here, and the other node's subscription that reads it.
    old_slot, new_slot = 'opt_from_%d' % slot, ha_sub_name(slot)
    have_old = pg_admin("SELECT 1 FROM pg_replication_slots WHERE slot_name = '%s'" % old_slot,
                        port) == '1'
    far = None
    for name, user in ((RENAME_NEW, RENAME_NEW), (RENAME_OLD, RENAME_OLD),
                       (c.get('db_name'), c.get('db_user'))):
        try:
            far = db_open(dict(c, db_host=c.get('ha_peer'), db_port=c.get('ha_peer_port') or 5432,
                               db_name=name, db_user=user))
            far.value('SELECT 1')
            break
        except Exception:                               # noqa: BLE001
            far = None
    if far is None:
        say('the other node\'s PostgreSQL could not be reached: its subscription to this node '
            'is put right when it is upgraded too')
        return
    try:
        sub = None
        for one in ha_sub_names(slot):
            if far.value('SELECT 1 FROM pg_subscription WHERE subname = ?', (one,)):
                sub = one
                break
        if not sub:
            say('the other node has no subscription to this one: nothing to put right there')
            return
        conninfo = ha_conninfo(c.get('ha_address') or node_address(), port, db,
                               str(c.get('db_user') or RENAME_NEW), c.get('db_password') or '')
        far.run('ALTER SUBSCRIPTION %s DISABLE' % sub)
        time.sleep(2)
        try:
            if have_old and pg_admin("SELECT 1 FROM pg_replication_slots WHERE slot_name = "
                                     "'%s'" % new_slot, port) != '1':
                # Copied at the same place: what the other node had not yet
                # taken is still there for it under the new name.
                pg_admin("SELECT pg_copy_logical_replication_slot('%s', '%s')"
                         % (old_slot, new_slot), port, db)
            for quiet in ("SET log_statement = 'none'",):
                try:
                    far.run(quiet)
                except Exception:                       # noqa: BLE001
                    pass
            far.run("ALTER SUBSCRIPTION %s CONNECTION '%s'" % (sub, conninfo.replace("'", "''")))
            far.run('ALTER SUBSCRIPTION %s SET PUBLICATION %s WITH (refresh = false)'
                    % (sub, HA_PUB))
            far.run("ALTER SUBSCRIPTION %s SET (slot_name = '%s')" % (sub, new_slot))
            if sub != new_slot:
                far.run('ALTER SUBSCRIPTION %s RENAME TO %s' % (sub, new_slot))
                sub = new_slot
        finally:
            far.run('ALTER SUBSCRIPTION %s ENABLE' % sub)
        if have_old:
            pg_admin("SELECT pg_drop_replication_slot('%s') FROM pg_replication_slots WHERE "
                     "slot_name = '%s' AND NOT active" % (old_slot, old_slot), port)
        say('replication: the other node reads this one as %s, from where it was' % new_slot)
    finally:
        far.close()


def rename_from_opt(say=print):
    """otp --rename-from-opt, as root, with the service stopped."""
    if os.geteuid() != 0:
        raise SystemExit('otp: --rename-from-opt is for root (install.sh runs it)')
    load_config()
    c = dict(CONFIG)
    eng = c.get('db_engine') or 'sqlite'
    changes = {}
    if eng != 'sqlite':
        # Whatever happens below, the names in use are written down: the
        # defaults are otp now, and a database still called opt must be
        # found under that name.
        for k in ('db_name', 'db_user'):
            if k not in FILE_KEYS:
                changes[k] = c.get(k) if c.get(k) != DEFAULTS[k] else RENAME_OLD
                c[k] = changes[k]
        if _local_host(c):
            try:
                if eng == 'postgres':
                    changes.update(_pg_rename_local(c, say))
                else:
                    changes.update(_mariadb_rename_local(c, say))
            except Exception as e:                      # noqa: BLE001
                say('the database could not be renamed (%s): it keeps its names, which are '
                    'written into %s' % (str(e).split('\n')[0][:200], CONFIG_FILE))
        else:
            say('the database is on %s, not here: it keeps its names (%s, %s)'
                % (c.get('db_host'), c['db_name'], c['db_user']))
        c.update(changes)
        if eng == 'postgres' and CONFIG.get('ha_mode') == 'replicated':
            try:
                _ha_rename(c, say)
            except Exception as e:                      # noqa: BLE001
                say('replication could not be renamed (%s): it goes on under its old names'
                    % str(e).split('\n')[0][:200])
    if changes:
        # Written as given: the old names stay explicit, the new are the
        # defaults and drop out.
        write_file_settings(changes)
    return 0


# ---------------------------------------------------------------------------
# The API the web pages ask
# ---------------------------------------------------------------------------
# On 127.0.0.1 only, and only for whoever holds the token in /run/otp - which
# is the web server's group and nobody else. The PHP pages relay to it and
# add nothing: the session travels as a header, and this decides what that
# session may have. Two kinds of session: an administrator's (`admin`) and a
# person enrolling their own token (`portal`), which can reach nothing but
# its own token.

ROLE_RANK = {'readonly': 1, 'tokenadmin': 2, 'fulladmin': 3}


class ApiError(Exception):
    def __init__(self, status, words, detail=''):
        Exception.__init__(self, words)
        self.status = status
        self.detail = detail


def api_token(make=False):
    if make:
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        token = secrets.token_urlsafe(32)
        write_replacing(TOKEN_FILE, token + '\n', 0o640)
        try:
            import grp
            gid = grp.getgrnam(WEB_GROUP).gr_gid
            os.chown(str(TOKEN_FILE), -1, gid)
            os.chmod(str(RUN_DIR), 0o750)
            os.chown(str(RUN_DIR), -1, gid)
        except (KeyError, OSError, ImportError):
            pass
        return token
    try:
        return TOKEN_FILE.read_text().strip()
    except OSError:
        return ''


class ApiHandler(BaseHTTPRequestHandler):
    server_version = 'otp'
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        if debugging('api'):
            log('api %s' % (fmt % args), 'debug')

    # ---- the plumbing ---------------------------------------------------------
    @property
    def d(self):
        return self.server.daemon

    @property
    def store(self):
        return self.server.daemon.store

    def client_ip(self):
        said = str(self.headers.get('X-Otp-Client') or '').strip()
        return said if re.match(r'^[0-9a-fA-F:.]{2,45}$', said) else self.client_address[0]

    def send_json(self, data, status=200):
        body = json.dumps(data, default=str, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        if hasattr(self, '_body'):
            return self._body
        n = int(self.headers.get('Content-Length') or 0)
        if n > 8 * 1024 * 1024:
            raise ApiError(413, 'that is more than this takes')
        raw = self.rfile.read(n) if n else b''
        try:
            self._body = json.loads(raw.decode('utf-8')) if raw else {}
        except ValueError:
            raise ApiError(400, 'the body is not JSON')
        if not isinstance(self._body, dict):
            raise ApiError(400, 'the body is not an object')
        return self._body

    def body_to_file(self, path, most):
        """A request body that is a file, written down a lump at a time."""
        n = int(self.headers.get('Content-Length') or 0)
        if n <= 0:
            raise ApiError(400, 'no file arrived')
        if n > most:
            raise ApiError(413, 'that file is bigger than this takes')
        left = n
        with open(str(path), 'wb') as out:
            while left > 0:
                lump = self.rfile.read(min(left, 1 << 20))
                if not lump:
                    raise ApiError(400, 'the file did not arrive whole')
                out.write(lump)
                left -= len(lump)
        self._body = {}
        return n

    def send_bytes(self, data, name, kind='application/octet-stream'):
        self.send_response(200)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Disposition', 'attachment; filename="%s"' % name)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def send_file(self, path, name):
        size = Path(path).stat().st_size
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Disposition', 'attachment; filename="%s"' % name)
        self.send_header('Content-Length', str(size))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with open(str(path), 'rb') as f:
            shutil.copyfileobj(f, self.wfile, 1 << 18)

    def do_GET(self):
        self.route('GET')

    def do_POST(self):
        self.route('POST')

    def route(self, method):
        url = urlparse(self.path)
        self.args = {k: v[-1] for k, v in parse_qs(url.query).items()}
        path = url.path.rstrip('/')
        self.route_path = path
        if path != '/api/health':
            want = api_token()
            given = str(self.headers.get('X-Otp-Token') or '')
            if not want or not hmac.compare_digest(want, given):
                return self.send_json({'ok': False, 'error': 'not this API’s token'}, 403)
        fn = ROUTES.get((method, path))
        if not fn:
            return self.send_json({'ok': False, 'error': 'no such endpoint: %s %s'
                                   % (method, path)}, 404)
        self._held = None
        self._failed = False
        try:
            got = fn(self)
            if got is not None:
                self.send_json(got if 'ok' in got else dict(ok=True, **got))
        except ApiError as e:
            # What went wrong in detail - a domain controller's name, a bind
            # DN - only to somebody signed in (1.0.33); the rest is in the log.
            detail = e.detail if self._signed_in() else None
            if e.detail and not detail:
                log('%s %s: %s (%s)' % (method, path, e, e.detail), 'info')
            self.send_json({'ok': False, 'error': str(e), 'detail': detail}, e.status)
        except (ValueError, BadSetting, RadiusError) as e:
            self.send_json({'ok': False, 'error': str(e)}, 400)
        except LdapError as e:
            self.send_json({'ok': False, 'error': str(e), 'detail': e.detail}, 502)
        except DbError as e:
            self.send_json({'ok': False, 'error': str(e)}, 503)
        except (TypeError, AttributeError, KeyError) as e:
            # A field of the wrong kind - null where a number goes, a list
            # where an object does (1.0.44): the request's fault, said so,
            # and the trace kept in case it was not.
            log('%s %s could not be read: %s\n%s' % (method, path, e, traceback.format_exc()),
                'warn')
            self.send_json({'ok': False, 'error': 'the request is not in the shape this '
                                                  'takes (a field of the wrong kind)'}, 400)
        except Exception as e:
            log('the API broke on %s %s: %s\n%s' % (method, path, e, traceback.format_exc()),
                'error')
            # The words of the exception stay in the log (1.0.33).
            self.send_json({'ok': False, 'error': 'it broke - the reason is in the log of the '
                                                  'service (/var/log/otp/otp.log)'}, 500)
        finally:
            self._release()

    def _signed_in(self):
        token = str(self.headers.get('X-Otp-Session') or '')
        if not token:
            return False
        try:
            # Only a look: an error must not keep a session alive. (1.0.36)
            return bool(self.store.session_get(
                token, 'admin', int(CONFIG.get('session_idle_min') or 120) * 60, touch=False) or
                self.store.session_get(
                token, 'portal', int(CONFIG.get('portal_session_min') or 15) * 60, touch=False))
        except Exception:                               # noqa: BLE001
            return False

    def arg(self, name, default=''):
        return self.args.get(name, default)

    def num(self, name, default, lo=0, hi=10 ** 9):
        try:
            return max(lo, min(hi, int(float(self.args.get(name, default)))))
        except (TypeError, ValueError):
            return default

    # ---- who is asking ----------------------------------------------------------
    def session(self, kind):
        token = str(self.headers.get('X-Otp-Session') or '')
        if kind == 'admin':
            idle = int(CONFIG.get('session_idle_min') or 120) * 60
        else:
            idle = int(CONFIG.get('portal_session_min') or 15) * 60
        return self.store.session_get(token, kind, idle)

    def me(self, role='readonly'):
        s = self.session('admin')
        if not s:
            raise ApiError(401, 'not signed in, or the sign-in has run out')
        acc = self.store.account(s['name'])
        if not acc or acc.get('disabled'):
            self.store.session_end(self.headers.get('X-Otp-Session'))
            raise ApiError(401, 'that account may no longer sign in')
        if acc.get('source') == 'directory':
            acc = self.directory_recheck(acc)
        s['role'] = acc['role']
        if acc.get('must_change') and getattr(self, 'route_path', '') not in MUST_CHANGE_ALLOWED:
            raise ApiError(403, 'change the password first')
        if ROLE_RANK.get(s['role'], 0) < ROLE_RANK[role]:
            raise ApiError(403, {'fulladmin': 'only a full administrator may do that',
                                 'tokenadmin': 'only a token administrator may do that'}
                           .get(role, 'that account may not do that'))
        s['account'] = acc
        return s

    def portal_link(self):
        """The enrolment pages' address, for a token's mail: from the name the
        pages were reached by, never from what the page sent (1.0.33)."""
        host = str(self.headers.get('X-Otp-Host') or '')
        if not re.fullmatch(r'([A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:.]{2,45}\])(:[0-9]{1,5})?', host):
            return ''
        return 'https://%s/' % host

    DIR_CHECKED = {}
    DIR_CHECK_S = 600

    def directory_recheck(self, acc):
        """Somebody signed in from the directory, asked about again every ten
        minutes (1.0.33): switched off there, or out of every group that gives
        a role, and the sign-in ends - not hours later when it runs out. A
        directory that cannot be reached leaves them as they are."""
        name = acc['name']
        t = time.time()
        if t - self.DIR_CHECKED.get(name.lower(), 0) < self.DIR_CHECK_S:
            return acc
        ad = self.d.dirs.get(str(CONFIG.get('admin_directory') or '').lower())
        if not ad:
            self.end_all(name, 'the directory administrators sign in against is gone')
        try:
            who, how = admin_name_parts(name)
            entry = ad.find_user(who, how)
            role = None
            if entry and not entry.get('disabled'):
                role = admin_role_for(ad.groups_of(entry, True))
        except Exception as e:                          # noqa: BLE001
            # Asked again in a minute, not on every click: a directory that
            # does not answer would hold each page for its whole timeout. (1.0.36)
            self.DIR_CHECKED[name.lower()] = t - self.DIR_CHECK_S + 60
            log('the directory could not be asked about %s: %s' % (name, e), 'warn')
            return acc
        self.DIR_CHECKED[name.lower()] = t
        if not role:
            self.end_all(name, 'the directory no longer gives %s a role here' % name)
        if role != acc.get('role'):
            self.store.set_account(name, role=role)
            self.store.add_event('accounts', 'the directory gives %s the role %s now (was %s)'
                                 % (name, role, acc.get('role')), 'warn')
            acc = self.store.account(name)
        return acc

    def end_all(self, name, why):
        self.store.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ?',
                          ('admin', name.lower()))
        self.store.add_event('accounts', '%s: signed out everywhere' % why, 'warn')
        raise ApiError(401, 'that account may no longer sign in')

    THROTTLE_LOCK = threading.Lock()

    def throttle(self, kind, tries, wait_min, name=''):
        """A sign-in attempt, counted before the password is asked (1.0.33):
        thirty at once from one address all slipped past a count made after
        the slow check. The attempt holds a place until it is known to have
        gone well, and gives it back then. Counted per address and, more
        loosely, per name, so many addresses cannot share out the guessing
        of one password."""
        ip = self.client_ip()
        keys = [(kind, ip)]
        if name:
            # Counted per person, not per spelling (1.0.44): DOMAIN\\novak,
            # novak@anything and Novak are all novak here.
            who = str(name).strip().lower()
            who = who.split('\\', 1)[-1].rsplit('@', 1)[0].strip()
            keys.append((kind + '-name', who[:190]))
        t = time.time()
        span = wait_min * 60
        with self.THROTTLE_LOCK:
            for i, key in enumerate(keys):
                limit = tries if i == 0 else tries * 4
                fails = [x for x in self.d.login_fails[key] if t - x < span]
                self.d.login_fails[key] = fails
                if len(fails) >= limit:
                    raise ApiError(429, 'too many wrong passwords %s: try again in %s'
                                   % ('from %s' % ip if i == 0 else 'for this name',
                                      human_span(span - (t - fails[0]))))
            for key in keys:
                self.d.login_fails[key].append(t)
            if len(self.d.login_fails) > 20000:
                old = [k for k, v in self.d.login_fails.items() if not v or t - v[-1] > span]
                for k in old:
                    self.d.login_fails.pop(k, None)
        self._held = (keys, t)
        return keys

    def failed(self, key):
        """The attempt went wrong: the place it holds stays taken."""
        self._failed = True

    def _release(self):
        held = getattr(self, '_held', None)
        if not held or getattr(self, '_failed', False):
            return
        keys, t = held
        with self.THROTTLE_LOCK:
            for key in keys:
                got = self.d.login_fails.get(key)
                if got and t in got:
                    got.remove(t)
        self._held = None


ROUTES = {}
# What an administrator who still has to change their password may do.
MUST_CHANGE_ALLOWED = ('/api/auth/password', '/api/auth/logout', '/api/auth/whoami')


def route(method, path):
    def wrap(fn):
        ROUTES[(method, path)] = fn
        return fn
    return wrap


# ---- health and signing in -------------------------------------------------------
@route('GET', '/api/health')
def _health(h):
    """Asked without the API token, so it says only what the pages need
    before anybody is signed in: that the database opens, whether any
    account exists at all (the sign-in page says how to make the first one
    otherwise), the language and this node's name. No version, no count."""
    try:
        users = 1 if h.store.db.value('SELECT 1 FROM accounts LIMIT 1') else 0
        db_ok = True
    except Exception:
        users, db_ok = 0, False
    try:
        maint = bool(maintenance_now(h.store).get('on'))
    except Exception:                                   # noqa: BLE001
        maint = False
    out = {'ok': True, 'users': users, 'database': {'ok': db_ok},
           'lang': CONFIG.get('ui_lang') or 'cs', 'node': node_name(),
           'maintenance': maint,
           # For a balancer of RADIUS and for monitoring (1.0.47): whether
           # RADIUS listens, and - asked for - whether replication runs.
           'radius': bool(getattr(getattr(h.d, 'radius', None), 'bound', None))}
    if h.arg('check') == 'all' and CONFIG.get('ha_mode') == 'replicated':
        try:
            rep = ha_repl_state(h.store)
            out['replication'] = {'ok': bool(rep.get('healthy')), 'lost': bool(rep.get('lost'))}
        except Exception:                               # noqa: BLE001
            out['replication'] = {'ok': False}
    return out


DUMMY_PW_HASH = password_hash(secrets.token_urlsafe(18))

ROLE_GROUP_KEYS = (('admin_group_full', 'fulladmin'), ('admin_group_token', 'tokenadmin'),
                   ('admin_group_readonly', 'readonly'))


def admin_role_for(have):
    """Which role these groups earn - full administrator first - or None.
    Only a group named for a role lets anybody in (1.0.33): with none named,
    nobody from the directory gets in at all. Before, being anywhere in the
    directory was then enough to read every log and every token."""
    for key, role in ROLE_GROUP_KEYS:
        wanted = dn_list(CONFIG.get(key))
        if wanted and group_matches(wanted, have):
            return role
    return None


def admin_name_parts(name):
    """`DOMAIN\\novak`, `novak@example.cz` or `novak`, as the directory is asked."""
    name = name.strip()
    if '\\' in name:
        name = name.split('\\', 1)[1]
    return name, ('upn' if '@' in name else 'sam')


def admin_ask_directory(h, name, password):
    """One sign-in, asked of the directory in `admin_directory`, and what it
    earns here. Nothing is made and no session is opened."""
    ad = h.d.dirs.get(str(CONFIG.get('admin_directory') or '').lower())
    if not ad:
        return None
    who, how = admin_name_parts(name)
    try:
        entry = ad.find_user(who, how)
    except LdapUnreachable as e:
        raise ApiError(503, 'the directory cannot be reached', str(e))
    if not entry:
        return {'ok': False, 'missing': True, 'said': 'the directory has nobody called %s' % who,
                'directory': ad.name}
    if entry.get('disabled'):
        return {'ok': False, 'said': 'the account is disabled in the directory',
                'dn': entry['dn'], 'directory': ad.name}
    try:
        ad.password_ok(entry, password)
    except LdapUnreachable as e:
        raise ApiError(503, 'the directory cannot be reached', str(e))
    except LdapError as e:
        return {'ok': False, 'said': str(e) or 'the password is not right', 'dn': entry['dn'],
                'directory': ad.name}
    have = ad.groups_of(entry, True)
    return {'ok': True, 'name': who, 'role': admin_role_for(have), 'dn': entry['dn'],
            'display': entry.get('display') or '', 'directory': ad.name, 'entry': entry,
            'groups': sorted({cn for _, cn in have}, key=str.lower)}


def admin_from_directory(h, name, password):
    """An administrator signed in against the directory named in
    `admin_directory`: the role is that of the first group they are in."""
    said = admin_ask_directory(h, name, password)
    if said is None:
        return None
    if not said['ok']:
        # What the directory said goes into the log only: the answer must not
        # tell the caller whether the name exists there.
        h.store.add_event('sign-ins', 'the directory did not sign %s in from %s: %s'
                          % (name, h.client_ip(), said.get('said') or '?'), 'warn')
        raise ApiError(401, 'the name or the password is not right')
    if not said['role']:
        raise ApiError(403, 'the directory knows %s, and none of the groups given a role '
                       'here holds them' % said['name'])
    name, role, entry = said['name'], said['role'], said['entry']
    acc = h.store.account(name)
    groups = '; '.join(said['groups'])[:2000]
    if acc:
        if acc.get('source') != 'directory':
            return None
        h.store.set_account(name, role=role, display=entry.get('display') or '',
                            dn=entry['dn'], group_list=groups)
    else:
        h.store.add_account(name, role, None, source='directory',
                            note='signed in from %s' % said['directory'],
                            display=entry.get('display') or '', dn=entry['dn'], groups=groups)
    return h.store.account(name)


@route('POST', '/api/auth/login')
def _login(h):
    b = h.body()
    name = str(b.get('name') or '').strip()
    password = str(b.get('password') or '')
    key = h.throttle('admin', int(CONFIG.get('login_tries') or 5),
                     int(CONFIG.get('login_wait_min') or 15), name=name)
    acc = h.store.account(name) or (h.store.account(admin_name_parts(name)[0])
                                    if CONFIG.get('admin_directory') else None)
    ok = None
    if acc and acc.get('source') != 'directory':
        ok = acc if (acc.get('pw') and password_ok(password, acc['pw'])) else None
    elif not acc and not CONFIG.get('admin_directory'):
        # As long as for a name that is there (1.0.33): how long the answer
        # took told which names exist.
        password_ok(password, DUMMY_PW_HASH)
    elif CONFIG.get('admin_directory') and password:
        try:
            ok = admin_from_directory(h, name, password)
        except ApiError as e:
            h.failed(key)
            h.store.add_event('sign-ins', '%s could not sign in from %s: %s'
                              % (name, h.client_ip(), e), 'warn')
            raise
    if not ok:
        h.failed(key)
        h.store.add_event('sign-ins', 'a wrong password for %s from %s'
                          % (name or '(nobody)', h.client_ip()), 'warn')
        raise ApiError(401, 'the name or the password is not right')
    if ok.get('disabled'):
        raise ApiError(403, 'that account is switched off')
    token = h.store.session_new('admin', ok['name'], ok['role'], h.client_ip(),
                                CONFIG.get('session_hours') or 12)
    h.store.set_account(ok['name'], last_in=time.time(), last_from=h.client_ip())
    h.store.add_event('sign-ins', '%s signed in from %s' % (ok['name'], h.client_ip()),
                      who=ok['name'])
    return {'token': token, 'who': {'name': ok['name'], 'role': ok['role']},
            'must_change': bool(ok.get('must_change'))}


# ---- editing the columns, switched on for one sign-in --------------------------
# Held here in memory, as on isemon: signing out, a sign-in running out and a
# restart of the service all switch it off again. Off, a layout already kept
# is drawn just the same; nothing can be changed.
COLS_EDITING = {}
COLS_EDITING_LOCK = threading.Lock()


def _cols_key(token):
    return hashlib.sha256(str(token or '').encode('utf-8', 'replace')).hexdigest()


# Kept with the sign-in's own row since 1.0.13 - in memory it was this node's
# alone, and behind a load balancer the next request found it switched off.
def _session_row(token):
    store = HA_STORE.get('store')
    if not store or not token:
        return None, None
    row = store.db.row('SELECT id, data FROM sessions WHERE token_hash = ?',
                       (hashlib.sha256(str(token).encode()).hexdigest(),))
    if not row:
        return store, None
    try:
        row['data'] = json.loads(row.get('data') or '{}')
    except ValueError:
        row['data'] = {}
    return store, row


def cols_editing(token):
    _, row = _session_row(token)
    return bool(row and row['data'].get('cols_edit'))


def set_cols_editing(token, on):
    store, row = _session_row(token)
    if not row:
        return False
    data = row['data']
    if on:
        data['cols_edit'] = 1
    else:
        data.pop('cols_edit', None)
    store.session_set_data(row['id'], data)
    return bool(on)


SETTINGS_FILE_KIND = 'otp-user-settings'


@route('POST', '/api/auth/logout')
def _logout(h):
    token = h.headers.get('X-Otp-Session')
    h.store.session_end(token)
    set_cols_editing(token, False)
    return {}


@route('POST', '/api/auth/columns')
def _columns(h):
    """Anybody signed in, a read-only account as well: this is how the page
    looks to that one person and changes nothing anybody else sees."""
    s = h.me()
    b = h.body()
    token = h.headers.get('X-Otp-Session') or ''
    if 'edit' in b:
        set_cols_editing(token, bool(b.get('edit')))
        if 'cols' not in b:
            return {'edit': cols_editing(token)}
    reset = bool(b.get('reset'))
    # Putting them back is always allowed; changing them only with the switch
    # on, so a page that misbehaves cannot rearrange somebody's tables while
    # they are only reading them.
    if not reset and not cols_editing(token):
        raise ApiError(409, 'switch on "Edit the columns" under your name first: the columns '
                       'are not being edited from this sign-in')
    try:
        kept = h.store.put_user_cols(s['name'], {} if reset else (b.get('cols') or {}))
    except ValueError as e:
        raise ApiError(400, str(e))
    if reset:
        h.store.add_event('accounts', '%s put the columns of every table back as they come'
                          % s['name'], who=s['name'])
    return {'tables': len(kept), 'edit': cols_editing(token)}


@route('GET', '/api/auth/settings')
def _my_settings(h):
    """What a person has set for themselves on the page, as one object that
    can be saved to a file and read back - here or on another machine. Never
    the password, the role or anything else about the account."""
    s = h.me()
    return {'name': s['name'], 'version': __version__, 'kind': SETTINGS_FILE_KIND,
            'settings': {'columns': h.store.user_cols(s['name']),
                         'prefs': h.store.user_prefs(s['name'])}}


@route('POST', '/api/auth/settings')
def _my_settings_put(h):
    s = h.me()
    b = h.body()
    got = b.get('settings')
    if not isinstance(got, dict):
        raise ApiError(400, 'that is not a file of settings: there is no "settings" in it')
    known = ('columns', 'prefs')
    ignored = sorted(k for k in got if k not in known)
    # Every section checked before any of them is written.
    for section, check, words in (('columns', h.store.clean_cols, 'the columns'),
                                  ('prefs', h.store.clean_prefs, 'the choices')):
        if section in got:
            try:
                check(got[section] if got[section] is not None else {})
            except (ValueError, TypeError, AttributeError) as e:
                raise ApiError(400, '%s in that file: %s' % (words, e))
    took = {}
    if 'columns' in got:
        took['columns'] = len(h.store.put_user_cols(s['name'], got['columns'] or {}))
    if 'prefs' in got:
        took['prefs'] = len(h.store.put_user_prefs(s['name'], got['prefs'] or {}))
    if not took:
        raise ApiError(400, 'nothing in that file is a setting this version keeps'
                       + (' (it holds: %s)' % ', '.join(ignored) if ignored else ''))
    h.store.add_event('accounts', '%s read their own settings back from a file (%s)'
                      % (s['name'], ', '.join('%s: %d' % kv for kv in took.items())),
                      who=s['name'])
    return {'took': took, 'ignored': ignored}


@route('GET', '/api/auth/whoami')
def _whoami(h):
    s = h.session('admin')
    if not s:
        return {'who': None}
    acc = h.store.account(s['name'])
    if not acc or acc.get('disabled'):
        return {'who': None}
    try:
        prefs = json.loads(acc.get('prefs') or '{}')
    except ValueError:
        prefs = {}
    # The page is drawn with the person's own layout of the tables from the
    # first frame, rather than as it comes and then again.
    return {'idle_min': int(CONFIG.get('session_idle_min') or 120),
            'who': {'name': acc['name'], 'role': acc['role'], 'source': acc.get('source'),
                    'display': acc.get('display') or '', 'must_change': bool(
                        acc.get('must_change')), 'prefs': prefs,
                    'cols': h.store.user_cols(acc['name']),
                    'cols_edit': cols_editing(h.headers.get('X-Otp-Session') or '')}}


@route('POST', '/api/auth/password')
def _password(h):
    s = h.me()
    b = h.body()
    acc = s['account']
    if acc.get('source') == 'directory':
        raise ApiError(400, 'this account signs in with its directory password, which is '
                       'changed in the directory')
    if not password_ok(str(b.get('old') or ''), acc.get('pw')):
        raise ApiError(400, 'the password you have now is not right')
    h.store.set_account(acc['name'], password=str(b.get('new') or ''), must_change=0)
    # Every other sign-in with the old password ends (1.0.33).
    h.store.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ? AND token_hash <> ?',
                   ('admin', acc['name'].lower(), hashlib.sha256(
                       str(h.headers.get('X-Otp-Session') or '').encode()).hexdigest()))
    h.store.add_event('accounts', '%s changed their own password' % acc['name'],
                      who=acc['name'])
    # The first password, written down by the installer, is no use to anybody
    # now - and stays readable no longer (1.0.33).
    first = STATE_DIR / 'first-login.txt'
    try:
        if first.exists() and ('name: %s\n' % acc['name']) in first.read_text():
            first.unlink()
    except OSError:
        pass
    return {'message': 'the password is changed'}


@route('POST', '/api/auth/prefs')
def _prefs(h):
    s = h.me()
    acc = s['account']
    try:
        prefs = json.loads(acc.get('prefs') or '{}')
    except ValueError:
        prefs = {}
    b = h.body()
    if 'lang' in b:
        if str(b['lang']) not in ('cs', 'en'):
            raise ApiError(400, 'no such language here')
        prefs['lang'] = str(b['lang'])
    h.store.set_account(acc['name'], prefs=json.dumps(prefs))
    return {'prefs': prefs}


# ---- what it is doing --------------------------------------------------------------
@route('GET', '/api/status')
def _status(h):
    s = h.me()
    out = h.d.status()
    out['role'] = s['role']
    return out


@route('GET', '/api/dashboard')
def _dashboard(h):
    h.me()
    return h.store.overview(h.num('hours', 24, 1, 24 * 400),
                            since=h.num('since', 0, 0, 10 ** 11) or None,
                            until=h.num('until', 0, 0, 10 ** 11) or None)


def list_query(listname, text):
    """(query, error words): what a search box asked, read as fields."""
    try:
        return ListQuery(listname, text), ''
    except ListQueryError as e:
        return None, str(e)


@route('GET', '/api/suggest')
def _suggest(h):
    """The fields of one list, or what one of them holds - what the search
    box over the list offers as somebody types (1.0.19)."""
    h.me()
    name = h.arg('list')
    if name not in LIST_FIELDS:
        raise ApiError(400, 'no such list')
    field = h.arg('field').lower()
    if not field:
        said = LIST_FIELD_SAYS.get(name) or LIST_FIELD_SAYS.get('radius')
        return {'fields': [list(f) for f in said]}
    hours = h.num('hours', 0, 0, 24 * 3650)
    since = time.time() - hours * 3600 if hours else 0
    typed = h.arg('typed')[:120]
    if name == 'radius':
        # The Log is two lists in one: a field either of them holds.
        got = h.store.list_values('radius', field, typed, since)
        more = h.store.list_values('otp', field, typed, since)
        seen = {g['val'].lower(): g for g in got}
        for m in more:
            if m['val'].lower() in seen:
                seen[m['val'].lower()]['n'] += m['n']
            else:
                got.append(m)
        got.sort(key=lambda x: -x['n'])
        return {'values': got[:15]}
    return {'values': h.store.list_values(name, field, typed, since)}


@route('GET', '/api/radius')
def _radius(h):
    h.me()
    lq, bad = list_query('radius', h.arg('q'))
    if bad:
        return {'rows': [], 'total': 0, 'q_error': bad, 'clients': []}
    rows, total = h.store.radius_rows(
        hours=h.num('hours', 24, 1, 24 * 3650), q=lq.words, extra=(lq.sql, lq.args),
        result=h.arg('result'),
        client=h.arg('client'), limit=h.num('limit', 100, 1, 1000),
        offset=h.num('offset', 0), sort=h.arg('sort', 'ts'),
        desc=h.arg('desc', '1') != '0', user=h.arg('user'))
    return {'rows': rows, 'total': total,
            'clients': [c['name'] for c in h.store.clients()]}


@route('GET', '/api/activity')
def _activity(h):
    """The one log of the pages: every RADIUS request - with what the token
    said about its code - and every code checked anywhere else (the
    enrolment pages, a test, the command line), newest first."""
    h.me()
    hours = h.num('hours', 24, 1, 24 * 3650)
    q, kind, result = h.arg('q'), h.arg('kind'), h.arg('result')
    client = h.arg('client')
    limit, offset = h.num('limit', 100, 1, 1000), h.num('offset', 0, 0, 20000)
    want = offset + limit
    out, total = [], 0
    rq, bad = list_query('radius', q)
    oq, bad2 = list_query('otp', q)
    if bad or bad2:
        return {'rows': [], 'total': 0, 'q_error': bad or bad2,
                'clients': [c['name'] for c in h.store.clients()]}
    # One hour of the chart, counted and paged here (1.0.36): picked out of
    # the first page in the browser, the count was the day's, and an older
    # hour came out empty.
    since, until = h.num('since', 0, 0, 10 ** 11), h.num('until', 0, 0, 10 ** 11)

    def span(sql, args):
        parts, args = ([sql] if sql else []), list(args or [])
        if since:
            parts.append('ts >= ?')
            args.append(since)
        if until:
            parts.append('ts < ?')
            args.append(until)
        return ' AND '.join('(%s)' % x for x in parts), args
    rq.sql, rq.args = span(rq.sql, rq.args)
    oq.sql, oq.args = span(oq.sql, oq.args)
    if kind != 'codes':
        rows, n = h.store.radius_rows(hours=hours, q=rq.words, extra=(rq.sql, rq.args),
                                      result=result, client=client, limit=want, offset=0)
        total += n
        for r in rows:
            out.append({'kind': 'radius', 'id': r['id'], 'ts': r['ts'], 'name': r.get('username'),
                        'realm': r.get('realm'), 'result': r.get('result'),
                        'why': r.get('reason') or r.get('otp') or '',
                        'code': r.get('otp') or '', 'source': r.get('client') or '',
                        'from': r.get('calling') or r.get('src') or '',
                        'device': r.get('device') or '', 'ms': r.get('took_ms'),
                        'node': r.get('node') or ''})
    if kind != 'radius' and not client and result in ('', 'access', 'accept', 'reject'):
        ok = None if result in ('', 'access') else result == 'accept'
        rows, n = h.store.otp_rows(hours=hours, q=oq.words, ok=ok, limit=want, offset=0,
                                   not_how='radius', extra=(oq.sql, oq.args))
        total += n
        for r in rows:
            out.append({'kind': 'code', 'id': r['id'], 'ts': r['ts'], 'name': r.get('name'),
                        'result': 'accept' if r.get('ok') else 'reject',
                        'why': r.get('said') or '', 'code': r.get('said') or '',
                        'source': r.get('how') or '', 'from': r.get('src') or '',
                        'device': '', 'ms': None, 'rid': r.get('rid') or '',
                        'node': r.get('node') or ''})
    out.sort(key=lambda x: (x['ts'] or 0, x['id']), reverse=True)
    return {'rows': out[offset:offset + limit], 'total': total,
            'clients': [c['name'] for c in h.store.clients()]}


@route('GET', '/api/radius/row')
def _radius_row(h):
    h.me()
    r = h.store.radius_row(h.num('id', 0))
    if not r:
        raise ApiError(404, 'there is no such request')
    return {'row': r}


@route('GET', '/api/otp')
def _otp(h):
    h.me()
    ok = h.arg('ok')
    rows, total = h.store.otp_rows(hours=h.num('hours', 24, 1, 24 * 3650), q=h.arg('q'),
                                   ok=None if ok == '' else ok == '1',
                                   limit=h.num('limit', 100, 1, 1000),
                                   offset=h.num('offset', 0), name=h.arg('name'))
    return {'rows': rows, 'total': total}


# ---- the tokens -----------------------------------------------------------------------
@route('GET', '/api/tokens')
def _tokens(h):
    h.me()
    lq, bad = list_query('tokens', h.arg('q'))
    if bad:
        return {'rows': [], 'total': 0, 'q_error': bad, 'counts': h.store.token_counts()}
    rows, total = h.store.tokens(q=lq.words, extra=(lq.sql, lq.args), state=h.arg('state'),
                                 limit=h.num('limit', 100, 1, 5000), offset=h.num('offset', 0),
                                 sort=h.arg('sort', 'name'), desc=h.arg('desc') == '1')
    return {'rows': rows, 'total': total, 'counts': h.store.token_counts()}


def totp_file_text(tok):
    """One token as the file totpcgi (google-authenticator) keeps for it:
    the key, its options, the recovery codes not used yet - what the import
    reads back (1.0.20)."""
    secret = unseal_secret(tok.get('secret') or '', token_bind(tok.get('name')))
    if not secret:
        return None
    lines = [secret]
    tries = int(CONFIG.get('rate_limit_tries') or 0)
    if tries:
        lines.append('" RATE_LIMIT %d %d' % (tries, int(CONFIG.get('rate_limit_s') or 30)))
    w = tok.get('window_steps')
    w = Tokens.window(tok)     # the same as the check uses: 0 is 0 (1.0.36)
    lines.append('" WINDOW_SIZE %d' % (w * 2 + 1))
    if CONFIG.get('totp_disallow_reuse'):
        lines.append('" DISALLOW_REUSE')
    lines.append('" TOTP_AUTH')
    for c in open_codes(tok.get('scratch_sealed'), token_bind(tok.get('name'))) or []:
        if isinstance(c, dict):
            if not c.get('used'):
                lines.append(str(c.get('c')))
        else:
            lines.append(str(c))
    return '\n'.join(lines) + '\n'


@route('GET', '/api/tokens/export')
def _tokens_export(h):
    """Tokens as totpcgi files: one token as its .totp, several as a ZIP of
    them. Every key in it signs its owner in, so: a full administrator only,
    where showing keys is allowed, and every export written down."""
    s = h.me('fulladmin')
    if not CONFIG.get('admin_show_key'):
        raise ApiError(403, 'showing the keys of tokens is switched off (Settings - Tokens)')
    one = norm_name(h.arg('name'))
    if one:
        tok = h.store.token(one)
        if not tok:
            raise ApiError(404, 'there is no token for %s' % one)
        text = totp_file_text(tok)
        if text is None:
            raise ApiError(409, 'the key of this token cannot be opened on this machine')
        h.store.add_event('tokens', '%s exported the token of %s as a .totp file' % (
            s['name'], one), 'warn', who=s['name'])
        h.send_bytes(text.encode('utf-8'), re.sub(r'[^A-Za-z0-9@._-]', '_', one) + '.totp',
                     'text/plain; charset=utf-8')
        return None
    lq, bad = list_query('tokens', h.arg('q'))
    if bad:
        raise ApiError(400, bad)
    rows, _ = h.store.tokens(q=lq.words, extra=(lq.sql, lq.args), state=h.arg('state'),
                             limit=100000)
    buf = io.BytesIO()
    done, lost, odd = 0, [], []
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for r in rows:
            tok = h.store.token(r['name'])
            text = totp_file_text(tok or {})
            if text is None:
                lost.append(r['name'])
                continue
            if int(tok.get('digits') or 6) != 6 or int(tok.get('period') or 30) != 30 or \
                    str(tok.get('algorithm') or 'SHA1').upper() != 'SHA1':
                odd.append('%s (%s digits, %s s, %s)' % (r['name'], tok.get('digits'),
                                                         tok.get('period'), tok.get('algorithm')))
            z.writestr(re.sub(r'[^A-Za-z0-9@._-]', '_', r['name']) + '.totp', text)
            done += 1
        notes = ['%d token(s) exported by %s on %s at %s.' % (
            done, s['name'], node_name(), time.strftime('%Y-%m-%d %H:%M:%S')), '',
            'Each file is what totpcgi (google-authenticator) keeps for one person: the key,',
            'its options and the recovery codes not used yet. otp reads them back under',
            'Settings - Bringing tokens over, or: otp --import-totpcgi DIR', '']
        if odd:
            notes += ['Not 6 digits, 30 s and SHA-1 - totpcgi itself cannot check these:'] + \
                     ['  ' + x for x in odd] + ['']
        if lost:
            notes += ['Left out - their keys cannot be opened on this machine:'] + \
                     ['  ' + x for x in lost] + ['']
        notes += ['Every key here signs its owner in. Keep this file as you keep passwords.']
        z.writestr('README.txt', '\n'.join(notes) + '\n')
    h.store.add_event('tokens', '%s exported %d token(s) as .totp files%s' % (
        s['name'], done, (' (filter: %s)' % h.arg('q')) if h.arg('q') else ''), 'warn',
        who=s['name'])
    h.send_bytes(buf.getvalue(), 'otp-tokens-%s.zip' % time.strftime('%Y%m%d-%H%M%S'),
                 'application/zip')
    return None


def mail_reply_words(steps):
    """What the receiving server said when it took the message, for the
    event: its queue id is what its own log can be searched by."""
    last = (steps or [{}])[-1].get('said', '') if steps else ''
    return (' - the server said: %s' % last.split(' · ', 1)[1]) if ' · ' in last else ''


def mailed_get(store, name):
    """Where a token's mail last went, and how (1.0.27): {to, lang, codes,
    at, by}, or {} when it never was mailed."""
    try:
        got = json.loads(store.get_meta('mailed:' + norm_name(name), '') or '{}')
        return got if isinstance(got, dict) else {}
    except ValueError:
        return {}


def mailed_set(store, name, to, lang, codes, by):
    store.set_meta('mailed:' + norm_name(name), json.dumps(
        {'to': to, 'lang': lang, 'codes': bool(codes), 'at': int(time.time()), 'by': by}))


def mailed_drop(store, name):
    store.db.run('DELETE FROM meta WHERE k = ?', ('mailed:' + norm_name(name),))


@route('GET', '/api/token')
def _token(h):
    h.me()
    name = norm_name(h.arg('name'))
    tok = h.store.token(name)
    checks, _ = h.store.otp_rows(hours=24 * 365, name=name, limit=30)
    reqs, _ = h.store.radius_rows(hours=24 * 365, user=name, limit=30)
    if not reqs and '@' not in name:
        reqs, _ = h.store.radius_rows(hours=24 * 365, q=name, limit=30)
    return {'token': h.store.token_shown(tok), 'checks': checks, 'requests': reqs,
            'name': name, 'mailed': mailed_get(h.store, name) if tok else {}}


@route('POST', '/api/token')
def _token_do(h):
    s = h.me('tokenadmin')
    b = h.body()
    act = str(b.get('action') or '')
    name = norm_name(b.get('name'))
    who = s['name']
    if act == 'fill_names':
        h.me('tokenadmin')
        got = h.d.fill_names(by=who)
        return dict(got, message='%d token(s) given their owner\'s name; %d not found in the '
                    'directory, %d with no directory to ask, %d could not be asked'
                    % (got['filled'], got['not_found'], got['no_directory'], got['trouble']))
    if not name:
        raise ApiError(400, 'which token?')
    tk = h.d.tokens
    if act in ('disable', 'enable', 'unlock', 'note', 'window', 'drop_staged') and \
            not h.store.token(name):
        # Written by name, these made an empty token of a name that had none.
        # (1.0.36)
        raise ApiError(404, 'there is no token %s' % name)
    if act == 'enroll':
        had = h.store.token(name)
        display = str(b.get('display') or '').strip()
        note = b.get('note')
        if had and not str(note or '').strip():
            note = None             # a new key keeps the note it had (1.0.36)
        got = tk.enroll(name, 'admin:' + who, pending=bool(b.get('pending')),
                        note=note, display=display)
        if not display and not (had or {}).get('display'):
            # The person's name from the directory at once (1.0.20), not when
            # somebody next presses Names from the directory.
            try:
                h.d.fill_names([name], quiet=True)
            except Exception:                           # noqa: BLE001
                pass
        h.store.add_event('tokens', '%s %s a token for %s' % (
            who, 'replaced' if had else 'made', name), 'warn' if had else 'info', who=who)
        out = {'made': got, 'message': 'the token for %s is made' % name}
        to = str(b.get('mail_to') or '').strip()
        if b.get('mail') and to:
            # Its QR code - and the recovery codes, where asked - to the person
            # it is for (1.0.20). The token stays made whatever the mail does.
            if not re.match(r'^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$', to):
                out['mail_error'] = '%s is not a mail address' % to
                return out
            lang = str(b.get('mail_lang') or CONFIG.get('mail_lang') or 'cs')
            lang = lang if lang in MAIL_WORDS else 'cs'
            tokrow = h.store.token(name) or {}
            try:
                msg = token_mail(to, name, got, codes=got.get('scratch') if b.get('mail_codes')
                                 else None, lang=lang, display=str(b.get('display') or
                                                                   tokrow.get('display') or ''),
                                 by=who, pending=bool(b.get('pending')),
                                 portal_url=h.portal_link())
                steps = mail_send(h.store, msg, [to])
                out['mail_steps'] = steps
                out['message'] += '; the QR code was sent to %s' % to
                h.store.add_event('mail', '%s sent the token of %s to %s%s%s' % (
                    who, name, to, ' with its recovery codes' if b.get('mail_codes') else '',
                    mail_reply_words(steps)), who=who)
                mailed_set(h.store, name, to, lang, b.get('mail_codes'), who)
            except MailError as e:
                out['mail_error'] = str(e)
                out['mail_steps'] = e.steps
                h.store.add_event('mail', 'the token of %s could not be sent to %s: %s' % (
                    name, to, e), 'warn', who=who)
        return out
    if not h.store.token(name):
        raise ApiError(404, 'there is no token for %s' % name)
    if act == 'code_now':
        # The code the phone shows right now (1.0.40): a full administrator
        # only - it signs that person in for half a minute - and every look
        # written down. Not the key: the code ages out by itself.
        h.me('fulladmin')
        # As the key itself (1.0.44): the code signs that person in, so it is
        # shown only where the key may be.
        if not CONFIG.get('admin_show_key'):
            raise ApiError(403, 'showing the key of a token is switched off '
                                '(Settings -> The tokens)')
        tok = h.store.token(name)
        if not tok:
            raise ApiError(404, 'there is no token %s' % name)
        secret = unseal_secret(tok.get('secret') or '', token_bind(tok.get('name')))
        if not secret:
            raise ApiError(409, 'the key of this token cannot be opened on this machine')
        key = b32_clean(secret)
        digits = int(tok.get('digits') or 6)
        period = int(tok.get('period') or 30)
        algo = tok.get('algorithm') or 'SHA1'
        now = time.time()
        step = totp_step(now, period)
        # Written down whatever the page says (1.0.44): once per person and
        # token in five minutes, so the page asking for the next code every
        # half minute does not fill the events.
        seen_key = (who, name)
        with CODE_NOW_LOCK:
            last = CODE_NOW_SEEN.get(seen_key, 0)
            if b.get('first') or now - last > 300:
                CODE_NOW_SEEN[seen_key] = now
                fresh = True
            else:
                fresh = False
            if len(CODE_NOW_SEEN) > 2000:
                CODE_NOW_SEEN.clear()
        if fresh:
            h.store.add_event('tokens', '%s looked at the code the token of %s shows now'
                              % (who, name), 'warn', who=who)
        return {'code': hotp(key, step, digits, algo), 'next': hotp(key, step + 1, digits, algo),
                'period': period, 'digits': digits, 'now': now,
                'ends': (step + 1) * period, 'state': tok.get('state')}
    if act == 'show':
        # The key of somebody's second factor: a full administrator only,
        # where the setting allows it, and every look written down.
        h.me('fulladmin')
        if not CONFIG.get('admin_show_key'):
            raise ApiError(403, 'showing the key of a token is switched off '
                                '(Settings -> The tokens)')
        tok = h.store.token(name)
        staged = bool(tok.get('pending_secret')) and b.get('which') == 'waiting'
        secret = unseal_secret((tok.get('pending_secret') if staged else tok.get('secret')) or '',
                               token_bind(tok.get('name')))
        if not secret:
            raise ApiError(409, 'the key of this token cannot be opened (the key file of the '
                                'database is not the one it was sealed with)')
        if staged:
            # The waiting key in its own shape (1.0.32), not the old token's.
            sh = tk.staged_shape(name)
            got = tk.picture(name, secret, sh['digits'], sh['period'], sh['algorithm'],
                             sh['issuer'] or None)
        else:
            got = tk.picture(name, secret, tok.get('digits'), tok.get('period'),
                             tok.get('algorithm'), tok.get('issuer'))
        got['name'] = name
        got['scratch'] = []
        h.store.add_event('tokens', '%s looked at the key of the %stoken of %s'
                          % (who, 'waiting ' if staged else '', name), 'warn', who=who)
        return {'made': got}
    if act == 'codes':
        # The recovery codes left, shown again: the same rule as the key.
        h.me('fulladmin')
        if not CONFIG.get('admin_show_key'):
            raise ApiError(403, 'showing the key of a token is switched off '
                                '(Settings -> The tokens)')
        tok = h.store.token(name)
        codes = open_codes(tok.get('scratch_sealed'), token_bind(tok.get('name')))
        if codes is None:
            raise ApiError(409, 'the recovery codes of this token were not kept to be shown '
                                'again (it was made by an older version); make new ones')
        h.store.add_event('tokens', '%s looked at the recovery codes of %s' % (who, name),
                          'warn', who=who)
        return {'scratch': codes}
    if act == 'mail':
        # The token's QR code mailed again (1.0.27). The key leaves the
        # machine as when it is shown, so the same rule: a full administrator,
        # where showing keys is allowed.
        h.me('fulladmin')
        if not CONFIG.get('admin_show_key'):
            raise ApiError(403, 'showing - and so mailing - the key of a token is switched off '
                                '(Settings -> The tokens)')
        to = str(b.get('mail_to') or '').strip()
        if not re.match(r'^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$', to):
            raise ApiError(400, '%s is not a mail address' % (to or 'nothing'))
        tok = h.store.token(name)
        secret = unseal_secret(tok.get('secret') or '', token_bind(tok.get('name')))
        if not secret:
            raise ApiError(409, 'the key of this token cannot be opened (the key file of the '
                                'database is not the one it was sealed with)')
        got = tk.picture(name, secret, tok.get('digits'), tok.get('period'),
                         tok.get('algorithm'), tok.get('issuer'))
        codes = None
        if b.get('mail_codes'):
            kept = open_codes(tok.get('scratch_sealed'), token_bind(tok.get('name')))
            if kept is None:
                raise ApiError(409, 'the recovery codes of this token were not kept to be sent '
                                    'again; send it without them, or make new ones first')
            codes = [c['c'] for c in kept if not c.get('used')]
        lang = str(b.get('mail_lang') or CONFIG.get('mail_lang') or 'cs')
        lang = lang if lang in MAIL_WORDS else 'cs'
        try:
            msg = token_mail(to, name, got, codes=codes, lang=lang,
                             display=str(tok.get('display') or ''), by=who,
                             pending=tok.get('state') == 'pending',
                             portal_url=h.portal_link())
            steps = mail_send(h.store, msg, [to])
        except MailError as e:
            h.store.add_event('mail', 'the token of %s could not be sent to %s: %s' % (
                name, to, e), 'warn', who=who)
            return {'sent': False, 'said': str(e), 'steps': e.steps}
        mailed_set(h.store, name, to, lang, codes, who)
        h.store.add_event('mail', '%s sent the token of %s to %s again%s%s' % (
            who, name, to, ' with its recovery codes' if codes else '',
            mail_reply_words(steps)), 'warn', who=who)
        return {'sent': True, 'steps': steps, 'message': 'sent to %s' % to,
                'mailed': mailed_get(h.store, name)}
    if act in ('disable', 'enable'):
        h.store.token_write(name, {'state': 'disabled' if act == 'disable' else 'active',
                                   'failures': 0, 'fail_times': '[]', 'locked_until': None})
        h.store.add_event('tokens', '%s switched the token of %s %s' % (
            who, name, 'off' if act == 'disable' else 'on'), who=who)
        return {'message': 'switched %s' % ('off' if act == 'disable' else 'on')}
    if act == 'delete':
        h.store.token_drop(name)
        mailed_drop(h.store, name)
        tk._staged_forget(name)
        h.store.add_event('tokens', '%s took away the token of %s' % (who, name), 'warn',
                          who=who)
        return {'message': 'the token of %s is gone' % name}
    if act == 'scratch':
        # New recovery codes are working credentials of somebody else that
        # leave no trace on their phone (1.0.33): the same rule as showing a
        # key - a full administrator, where that is allowed - and a warning
        # in the events.
        h.me('fulladmin')
        if not CONFIG.get('admin_show_key'):
            raise ApiError(403, 'new recovery codes are shown to whoever makes them, and showing '
                                'codes and keys is switched off (Settings -> The tokens)')
        codes = tk.new_scratch(name, who)
        h.store.add_event('tokens', '%s made new recovery codes for %s' % (who, name), 'warn',
                          who=who)
        return {'scratch': codes, 'message': '%d new recovery codes' % len(codes)}
    if act == 'unlock':
        h.store.token_write(name, {'failures': 0, 'fail_times': '[]', 'locked_until': None})
        h.store.add_event('tokens', '%s let %s try again at once' % (who, name), who=who)
        return {'message': 'the wrong codes are forgotten'}
    if act == 'rename':
        # Into another realm: the part after the @ changes, and with it the
        # name the VPN has to send. The key and the history stay; the
        # recovery codes are made again under the new name where they were
        # kept to be shown, since their hashes are of the name too. (1.0.11)
        to = norm_name(b.get('to'))
        # The same rule as a new token's (1.0.44).
        if not to or not re.match(r'^[^\s@,;=]+(@[A-Za-z0-9.-]+)?$', to) or len(to) > 180:
            raise ApiError(400, 'that is not a name: a name, or a name@realm - no spaces, '
                                'commas, semicolons or =, 180 characters at most')
        if to == norm_name(name):
            raise ApiError(400, 'that is the name it has')
        if h.store.token(to):
            raise ApiError(409, 'there is a token for %s already' % to)
        tok = h.store.token(name)
        if tok.get('pending_secret'):
            raise ApiError(409, 'a new key is waiting for a code from it: confirm it or throw it '
                                'away first')
        fields = {'name': to}
        codes = open_codes(tok.get('scratch_sealed'), token_bind(tok.get('name')))
        kept = True
        # Its sealed secrets are tied to its name: sealed again for the new
        # one (1.0.33), or they would no longer open.
        plain = unseal_secret(tok.get('secret') or '', token_bind(tok.get('name')))
        if plain:
            fields['secret'] = seal_secret(plain, token_bind(to))
        if codes is not None:
            fields['scratch'] = json.dumps([scratch_hash(to, c['c']) if isinstance(c, dict)
                                            else scratch_hash(to, c) for c in codes
                                            if not (isinstance(c, dict) and c.get('used'))])
            fields['scratch_sealed'] = seal_codes(codes, token_bind(to))
        elif tok.get('scratch_left'):
            kept = False
            fields.update(scratch='[]', scratch_left=0)
        # Moved to somebody else, the owner's name is theirs now (1.0.19).
        if norm_name(to).split('@', 1)[0] != norm_name(name).split('@', 1)[0]:
            fields['display'] = ''
        h.store.db.update('tokens', tok['id'], fields)
        h.store.db.run('UPDATE otp_log SET name = ? WHERE name = ?', (to, tok['name']))
        # Where its mail went goes with it - but only within the same
        # person: somebody else's token is not mailed to the old address.
        was = mailed_get(h.store, name)
        mailed_drop(h.store, name)
        if was and not fields.get('display') == '':
            mailed_set(h.store, to, was.get('to'), was.get('lang'), was.get('codes'),
                       was.get('by'))
        if fields.get('display') == '':
            h.d.fill_names_later([to])
        h.store.add_event('tokens', '%s moved the token of %s to %s' % (who, tok['name'], to),
                          'warn', who=who)
        return {'name': to, 'message': 'the token is now %s%s' % (
            to, '' if kept else '; its recovery codes were not kept to be made again under the '
                                'new name, so make new ones')}
    if act == 'note':
        h.store.token_write(name, {'note': str(b.get('note') or '')[:400]})
        h.store.add_event('tokens', '%s changed the note of %s' % (who, name), who=who)
        return {'message': 'the note is saved'}
    if act == 'window':
        w = int(b.get('window', -1))
        if not -1 <= w <= 20:
            raise ApiError(400, 'the window is -1 (the setting) or 0 to 20 steps')
        h.store.token_write(name, {'window_steps': w})
        h.store.add_event('tokens', '%s set the clock drift of %s to %s' % (
            who, name, 'the setting' if w < 0 else '%d step(s)' % w), who=who)
        return {'message': 'saved'}
    if act == 'test':
        ok, said, facts = tk.check(name, str(b.get('code') or ''), how='test',
                                   src=h.client_ip(), dry=not b.get('use'))
        return {'good': ok, 'said': said, 'facts': facts}
    if act == 'confirm':
        ok, said = tk.confirm(name, str(b.get('code') or ''), how='admin', src=h.client_ip())
        if ok:
            h.store.add_event('tokens', '%s confirmed the token of %s' % (who, name), who=who)
        return {'good': ok, 'said': said}
    if act == 'drop_staged':
        tk.drop_staged(name)
        h.store.add_event('tokens', '%s threw away the replacement waiting for %s' % (who, name),
                          who=who)
        return {'message': 'the waiting replacement is gone; the old token stays'}
    raise ApiError(400, 'no such thing to do to a token: %s' % act)


def totp_files_in_zip(b64, label, out):
    """The .totp files inside a ZIP the page sent (1.0.33) - a totpcgi
    folder zipped, or another otp's export. Read in memory with limits on
    everything: how big, how many, how far it unpacks. Nothing is written to
    disk and no name inside is used as a path."""
    try:
        raw = base64.b64decode(str(b64), validate=True)
    except (ValueError, binascii.Error):
        out.append({'name': label, 'said': 'not imported: not a ZIP the page could send'})
        return []
    got = []
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos = z.infolist()
            if len(infos) > 50000:
                raise ValueError('more than 50 000 files in it')
            total = 0
            for info in infos:
                base = info.filename.replace('\\', '/').rsplit('/', 1)[-1]
                if info.is_dir() or not base.endswith('.totp') or base.startswith('.') or \
                        '__MACOSX/' in info.filename:
                    continue
                if info.file_size > 64 * 1024:
                    out.append({'name': base, 'said': 'not imported: too big for a .totp file'})
                    continue
                total += info.file_size
                if total > 64 * 1024 * 1024:
                    raise ValueError('it unpacks to more than 64 MB')
                with z.open(info) as f:
                    data = f.read(64 * 1024 + 1)
                if len(data) > 64 * 1024:
                    out.append({'name': base, 'said': 'not imported: too big for a .totp file'})
                    continue
                got.append({'name': base, 'text': data.decode('utf-8', 'replace')})
    except (zipfile.BadZipFile, ValueError, RuntimeError, NotImplementedError) as e:
        out.append({'name': label, 'said': 'not imported: %s' % e})
        return []
    if not got:
        out.append({'name': label, 'said': 'not imported: no .totp file in it'})
    return got


@route('POST', '/api/token/import')
def _token_import(h):
    s = h.me('fulladmin')
    b = h.body()
    out = []
    files = []
    for one in b.get('files') or []:
        if one.get('zip'):
            files.extend(totp_files_in_zip(one.get('zip'), str(one.get('name') or 'the ZIP'),
                                           out))
        else:
            files.append(one)
    for one in files:
        fname = os.path.basename(str(one.get('name') or ''))
        name = fname[:-5] if fname.endswith('.totp') else fname
        try:
            said = import_totp(h.store, name, str(one.get('text') or ''), 'import:' + s['name'],
                               replace=bool(b.get('replace')))
        except ValueError as e:
            said = 'not imported: %s' % e
        out.append({'name': norm_name(name), 'said': said})
    h.store.add_event('tokens', '%s imported %d token file(s)' % (s['name'], len(out)),
                      who=s['name'])
    # Their owners' names from the directory, as an enrolment on the pages
    # would have given them - in the background, the list is not kept waiting.
    h.d.fill_names_later([o['name'] for o in out if str(o['said']).startswith('imported')],
                         by=s['name'])
    return {'done': out}


# ---- clients, realms, directories -----------------------------------------------------
@route('GET', '/api/clients')
def _clients(h):
    s = h.me()
    clients = h.store.clients()
    if s['role'] != 'fulladmin':
        # Not even the last two characters to whoever cannot change it (1.0.33).
        for c in clients:
            c['secret'] = '••••••' if c.get('secret') else ''
    return {'clients': clients, 'realms': [r['name'] + ' (' + (r['suffix'] or '-')
                                                     + ')' for r in h.store.realms()],
            'suffixes': [r['suffix'] for r in h.store.realms() if r['suffix'] not in ('*', '')],
            'may_change': s['role'] == 'fulladmin'}


@route('POST', '/api/clients')
def _clients_do(h):
    s = h.me('fulladmin')
    b = h.body()
    act = b.get('action')
    if act == 'save':
        c = b.get('client') or {}
        ident = h.store.client_save(c, s['name'])
        h.store.add_event('clients', '%s saved the RADIUS client %s (%s)' % (
            s['name'], c.get('name'), c.get('address')), who=s['name'])
        h.d.changed('clients')
        return {'id': ident, 'message': 'the client %s is saved' % c.get('name')}
    if act == 'delete':
        one = next((c for c in h.store.clients() if c['id'] == int(b.get('id') or 0)), None)
        h.store.client_drop(int(b.get('id') or 0))
        h.store.add_event('clients', '%s took away the RADIUS client %s' % (
            s['name'], (one or {}).get('name')), 'warn', who=s['name'])
        h.d.changed('clients')
        return {'message': 'the client is gone'}
    if act == 'secret':
        h.me('fulladmin')
        one = next((c for c in h.store.clients(with_secret=True)
                    if c['id'] == int(b.get('id') or 0)), None)
        if not one:
            raise ApiError(404, 'no such client')
        h.store.add_event('clients', '%s looked at the shared secret of %s' % (
            s['name'], one['name']), who=s['name'])
        return {'secret': one['secret']}
    raise ApiError(400, 'no such thing to do to a client')


@route('GET', '/api/realms')
def _realms(h):
    s = h.me()
    return {'realms': h.store.realms(), 'directories': [d['name'] for d in
                                                       h.store.directories()],
            'reply_attrs': list(REPLY_ATTRS), 'may_change': s['role'] == 'fulladmin'}


@route('POST', '/api/realms')
def _realms_do(h):
    s = h.me('fulladmin')
    b = h.body()
    act = b.get('action')
    if act == 'save':
        r = b.get('realm') or {}
        ident = h.store.realm_save(r, s['name'])
        h.store.add_event('realms', '%s saved the realm %s' % (s['name'], r.get('name')),
                          who=s['name'])
        h.d.changed('realms')
        return {'id': ident, 'message': 'the realm %s is saved' % r.get('name')}
    if act == 'delete':
        h.store.realm_drop(int(b.get('id') or 0))
        h.store.add_event('realms', '%s took away a realm' % s['name'], 'warn', who=s['name'])
        h.d.changed('realms')
        return {'message': 'the realm is gone'}
    if act == 'try':
        name = Authenticator.full_name(str(b.get('user') or ''), str(b.get('realm') or ''))
        realm = h.store.realm_for(name)
        return {'name': name, 'realm': realm['name'] if realm else None}
    raise ApiError(400, 'no such thing to do to a realm')


@route('GET', '/api/directories')
def _dirs(h):
    s = h.me()
    dirs = h.store.directories()
    if s['role'] != 'fulladmin':
        for d in dirs:
            if d.get('bind_pw'):
                d['bind_pw'] = '••••••'
    return {'directories': dirs, 'may_change': s['role'] == 'fulladmin'}


@route('POST', '/api/directories')
def _dirs_do(h):
    b = h.body()
    act = b.get('action')
    if act in ('save', 'delete'):
        s = h.me('fulladmin')
        if act == 'save':
            one = b.get('directory') or {}
            ident = h.store.directory_save(one, s['name'])
            h.store.add_event('directories', '%s saved the directory %s' % (
                s['name'], one.get('name')), who=s['name'])
            h.d.changed('directories')
            return {'id': ident, 'message': 'the directory %s is saved' % one.get('name')}
        h.store.directory_drop(int(b.get('id') or 0))
        h.store.add_event('directories', '%s took away a directory' % s['name'], 'warn',
                          who=s['name'])
        h.d.changed('directories')
        return {'message': 'the directory is gone'}
    if act == 'whois':
        # What the directory says about one person - an account here (asked of
        # the directory administrators sign in against) or the owner of a
        # token (asked of the directory of the realm the name falls in).
        h.me()
        who = str(b.get('user') or '').strip()
        if not who:
            raise ApiError(400, 'who?')
        realm = None
        if b.get('kind') == 'account':
            dname = str(CONFIG.get('admin_directory') or '')
        else:
            realm = h.store.realm_for(who)
            dname = (realm or {}).get('directory') or ''
        ad = h.d.dirs.get(dname.lower()) if dname else None
        if not ad:
            raise ApiError(404, 'no directory answers for %s' % who)
        bare, how = admin_name_parts(who)
        if realm and realm.get('lookup') in ('upn', 'sam'):
            how = realm['lookup']
            bare = who if how == 'upn' else who.split('@', 1)[0]
        t = time.time()
        try:
            entry = ad.find_user(bare, how)
            groups = ad.groups_of(entry, True) if entry else []
        except LdapUnreachable as e:
            log('the directory could not be reached: %s' % e, 'warn')
            raise ApiError(503, 'the directory cannot be reached just now')
        # Each group with where it lives and what it gives here (1.0.19, as
        # isemon's person card): an administrators' role, or the way into a
        # realm - the ones that matter are drawn first, as cards.
        listed = []
        seen = set()
        realms = [r for r in h.store.realms() if r.get('enabled')]
        for dn, cn in sorted(groups, key=lambda g: str(g[1]).lower()):
            if dn.lower() in seen:
                continue
            seen.add(dn.lower())
            gives = []
            for key, role in ROLE_GROUP_KEYS:
                if group_matches(dn_list(CONFIG.get(key)), [(dn, cn)]):
                    gives.append({'role': role})
            for r in realms:
                if r.get('groups') and group_matches(r['groups'], [(dn, cn)]):
                    gives.append({'realm': r['name']})
            listed.append({'name': cn, 'dn': dn, 'gives': gives})
        acc = h.store.account(who) if b.get('kind') == 'account' else None
        tok = h.store.token(who) if b.get('kind') != 'account' else None
        return {'entry': entry, 'groups': sorted({cn for _, cn in groups}, key=str.lower),
                'group_list': listed, 'realm': (realm or {}).get('name') or '',
                'role': (acc or {}).get('role') or '', 'token': bool(tok),
                'token_state': (tok or {}).get('state') or '',
                'directory': ad.name, 'took_ms': int((time.time() - t) * 1000)}
    if act == 'people':
        # People in the directory of a realm whose names hold what is typed -
        # what the boxes offer while somebody types a name (1.0.19).
        h.me('tokenadmin')
        like = str(b.get('like') or '').strip()
        rname = str(b.get('realm') or '').strip().lower()
        realm = next((r for r in h.store.realms() if r['name'].lower() == rname
                      or str(r.get('suffix') or '').lower() == rname.lstrip('@')), None)
        if not realm:
            realm = h.store.realm_for(like) if '@' in like else None
        dname = str(b.get('directory') or '').strip()
        if dname:
            # One directory by its name, as the Look a name up box asks it:
            # the people as that directory names them.
            ad = h.d.dirs.get(dname.lower())
            if not ad:
                return {'people': []}
            try:
                found = ad.find_users(like.split('@', 1)[0], int(b.get('limit') or 20))
            except LdapUnreachable as e:
                log('the directory could not be reached: %s' % e, 'warn')
                raise ApiError(503, 'the directory cannot be reached just now')
            return {'people': [{'name': (u['upn'] or u['sam'] or '').lower(),
                                'display': u['display'], 'mail': u['mail'],
                                'disabled': u['disabled'], 'token': ''} for u in found]}
        if not realm or not realm.get('directory'):
            return {'people': [], 'realm': (realm or {}).get('name') or ''}
        ad = h.d.dirs.get(str(realm['directory']).lower())
        if not ad:
            return {'people': [], 'realm': realm['name']}
        try:
            found = ad.find_users(like.split('@', 1)[0], int(b.get('limit') or 20))
        except LdapUnreachable as e:
            log('the directory could not be reached: %s' % e, 'warn')
            raise ApiError(503, 'the directory cannot be reached just now')
        suffix = str(realm.get('suffix') or '')
        out = []
        for u in found:
            if realm.get('lookup') == 'upn' and u['upn']:
                name = u['upn'].lower()
            elif suffix and suffix != '*':
                name = '%s@%s' % ((u['sam'] or '').lower(), suffix.lower())
            else:
                name = (u['upn'] or u['sam'] or '').lower()
            if realm.get('token_name') == 'bare':
                name = name.split('@', 1)[0]
            tok = h.store.token(name) if name else None
            out.append({'name': name, 'display': u['display'], 'mail': u['mail'],
                        'disabled': u['disabled'], 'token': (tok or {}).get('state') or ''})
        return {'people': out, 'realm': realm['name']}
    if act == 'ca':
        s = h.me('fulladmin')
        one = next((x for x in h.store.directories() if x['id'] == int(b.get('id') or 0)), None)
        if not one:
            raise ApiError(404, 'there is no such directory')
        pem = str(b.get('ca') or '').strip()
        mode = str(b.get('mode') or ('add' if pem else 'clear'))
        before = len(one.get('ca_list') or [])
        try:
            h.store.directory_set_ca(one['id'], pem, mode, str(b.get('fingerprint') or ''))
        except ValueError as e:
            raise ApiError(400, str(e))
        after = next((x for x in h.store.directories() if x['id'] == one['id']), {})
        n = len(after.get('ca_list') or [])
        words = {'add': 'added %d certificate(s) to' % max(0, n - before),
                 'set': 'replaced', 'drop': 'took a certificate out of',
                 'clear': 'took away'}.get(mode, 'changed')
        h.store.add_event('directories', '%s %s the certificate authorities of %s (%d kept)' % (
            s['name'], words, one['name'], n), who=s['name'])
        h.d.changed('directories')
        if mode == 'add' and n == before:
            msg = 'every one of those certificates is kept already'
        else:
            msg = '%s keeps %d certificate(s)' % (one['name'], n)
        return {'message': msg, 'ca_list': after.get('ca_list') or []}
    if act == 'try':
        h.me('fulladmin')
        if not CONFIG.get('admin_directory'):
            raise ApiError(400, 'no directory signs administrators in yet: choose one in '
                                '"Sign administrators in against the directory" and save')
        said = admin_ask_directory(h, str(b.get('user') or ''), str(b.get('password') or ''))
        if said is None:
            raise ApiError(404, 'the directory %s is not set up' % CONFIG.get('admin_directory'))
        said.pop('entry', None)
        return {'tried': said}
    h.me('tokenadmin')
    ad = h.d.dirs.get(str(b.get('name') or '').lower())
    if not ad:
        raise ApiError(404, 'there is no directory called %s (switched on)' % b.get('name'))
    if act == 'check':
        return {'check': ad.check()}
    if act == 'groups':
        groups = ad.find_groups(str(b.get('like') or ''), limit=5000)
        return {'groups': groups, 'capped': len(groups) >= 5000}
    if act == 'lookup':
        who = str(b.get('user') or '').strip()
        how = str(b.get('how') or ('upn' if '@' in who else 'sam'))
        t = time.time()
        entry = ad.find_user(who, how)
        groups = ad.groups_of(entry, True) if entry else []
        return {'entry': entry, 'groups': [cn for _, cn in groups],
                'took_ms': int((time.time() - t) * 1000)}
    raise ApiError(400, 'no such thing to do with a directory')


# ---- trying it --------------------------------------------------------------------------
@route('POST', '/api/radtest')
def _radtest(h):
    s = h.me('tokenadmin')
    b = h.body()
    node = str(b.get('node') or '').strip()
    if node and node != node_name():
        # Asked on another node of the cluster (1.0.45): through the
        # database both open, the password sealed with the key both have.
        return radtest_elsewhere(h.store, node, s['name'], h.client_ip(), b)
    server = str(b.get('server') or '127.0.0.1')
    if server not in ('127.0.0.1', '::1', 'localhost'):
        h.me('fulladmin')
    return radtest_do(h.store, h.d, s['name'], h.client_ip(), b)


def radtest_do(store, daemon, by, src, b):
    """One test of a name and a password, on this node - asked on its pages,
    or by another node of the cluster for its pages."""
    user = str(b.get('user') or '')
    password = str(b.get('password') or '')
    how = str(b.get('how') or 'udp')
    if how == 'direct':
        client = next((c for c in store.clients() if c['id'] == int(b.get('client') or 0)),
                      None)
        realm = (client or {}).get('realm') or str(b.get('realm') or '')
        d = daemon.auth.decide(user, password, realm, src=src, rid='', how='test')
        store.radius_add({
            'ts': d.began, 'client': '%s (a test by %s)' % ((client or {}).get('name') or
                                                            'no client', by),
            'nas_ip': '', 'src': src, 'packet': 'Access-Request',
            'username': d.user or user, 'realm': d.realm, 'calling': '', 'called': '',
            'result': d.result, 'reason': d.reason, 'otp': d.otp, 'rid': '',
            'took_ms': int((time.time() - d.began) * 1000), 'attrs': '[]',
            'reply': json.dumps(d.reply), 'steps': json.dumps(d.steps), 'device': '',
            'tunnel': ''})
        return {'result': d.result, 'reason': d.reason, 'steps': d.steps, 'reply': d.reply,
                'user': d.user, 'realm': d.realm, 'how': 'direct', 'node': node_name()}
    secret = str(b.get('secret') or '')
    if not secret:
        local = store.client_for('127.0.0.1')
        if not local:
            raise ApiError(400, 'there is no client for 127.0.0.1 to send the test from: add '
                           'one (the installer makes "localhost"), or give the secret')
        secret = local['_secret']
    port = int(b.get('port') or CONFIG.get('radius_auth_port') or 1812)
    server = str(b.get('server') or '127.0.0.1')
    code, words, took = radius_ask(server, port, secret, user, password)
    row = store.db.row("SELECT id FROM radius_log WHERE username = ? ORDER BY id DESC "
                       "LIMIT 1", (Authenticator.full_name(
                           user, (store.client_for('127.0.0.1') or {}).get('realm', '')),))
    return {'result': {2: 'accept', 3: 'reject', 11: 'challenge'}.get(code, str(code)),
            'answer': words, 'took_ms': took, 'row': row['id'] if row else None,
            'how': 'udp', 'node': node_name(), 'cli': 'radtest %s %s %s %d <secret>' % (
                user, '******', server, port)}


RADTEST_WAIT_S = 25


def radtest_elsewhere(store, node, by, src, b):
    alive = {n['name']: n for n in ha_nodes(store)}
    if node not in alive:
        raise ApiError(404, 'there is no node called %s' % node)
    if not alive[node].get('alive'):
        raise ApiError(409, '%s has not been heard from for %d s' % (
            node, int(alive[node].get('age') or 0)))
    ident = secrets.token_hex(8)
    ask = {'by': by, 'src': src, 'at': time.time(), 'from': node_name(),
           'user': str(b.get('user') or ''), 'how': str(b.get('how') or 'udp'),
           'client': b.get('client'), 'realm': str(b.get('realm') or ''),
           'password': seal_secret(str(b.get('password') or ''), 'radtest:' + ident)}
    store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)',
                 ('radtest:ask:%s:%s' % (node, ident), json.dumps(ask)))
    k_ans = 'radtest:answer:' + ident
    t0 = time.time()
    try:
        while time.time() - t0 < RADTEST_WAIT_S:
            got = store.get_meta(k_ans)
            if got:
                out = json.loads(got)
                if out.get('error'):
                    raise ApiError(int(out.get('status') or 400), out['error'])
                return out
            time.sleep(0.3)
        raise ApiError(504, '%s did not answer the test within %d s' % (node, RADTEST_WAIT_S))
    finally:
        store.db.run('DELETE FROM meta WHERE k IN (?, ?)',
                     ('radtest:ask:%s:%s' % (node, ident), k_ans))


def radtest_serve(daemon):
    """Tests the other node's pages asked of this one (1.0.45)."""
    store = daemon.store
    me = node_name()
    rows = [r for r in store.db.rows("SELECT k, v FROM meta WHERE k LIKE 'radtest:ask:%'")
            if r['k'].startswith('radtest:ask:%s:' % me)]
    for r in rows:
        ident = r['k'].rsplit(':', 1)[1]
        # Taken once: the row out first, so a second look does not run it again.
        store.db.run('DELETE FROM meta WHERE k = ?', (r['k'],))
        try:
            ask = json.loads(r['v'] or '{}')
            if time.time() - float(ask.get('at') or 0) > RADTEST_WAIT_S:
                continue
            ask['password'] = unseal_secret(ask.get('password') or '', 'radtest:' + ident)
            out = radtest_do(store, daemon, '%s on %s' % (ask.get('by'), ask.get('from')),
                             ask.get('src') or '', ask)
        except ApiError as e:
            out = {'error': str(e), 'status': e.status}
        except Exception as e:                          # noqa: BLE001
            out = {'error': 'the test could not be made on %s: %s' % (me, e), 'status': 500}
        try:
            store.db.run('INSERT INTO meta (k, v) VALUES (?, ?)',
                         ('radtest:answer:' + ident, json.dumps(out, default=str)))
        except Exception as e:                          # noqa: BLE001
            log('the answer to a test asked by the other node could not be written: %s' % e,
                'warn')


# ---- settings, accounts, events, the database --------------------------------------------
@route('GET', '/api/settings')
def _settings(h):
    s = h.me()
    full = s['role'] == 'fulladmin'
    return {'settings': h.d.settings_state(full), 'may_change': full, 'panes': PANES,
            'only_when': ONLY_WHEN, 'config_file': str(CONFIG_FILE),
            'database': h.store.db.where(), 'directories': [d['name'] for d in
                                                            h.store.directories()],
            'realms': [r['suffix'] for r in h.store.realms()
                       if r.get('suffix') and r['suffix'] != '*'],
            'isemon': h.d.shipper.state() if h.d.shipper else {},
            'node': node_name(), 'nodes': h.d.cluster_nodes(),
            'cluster': bool(CONFIG.get('ha_mode')) or len(h.d.cluster_nodes()) > 1}


@route('POST', '/api/settings')
def _settings_do(h):
    s = h.me('fulladmin')
    b = h.body()
    asked = b.get('settings') or {}
    moved = [k for k in asked if k in ('db_engine', 'db_host', 'db_port', 'db_name', 'db_user',
                                         'db_password') and
             not (k == 'db_password' and is_masked(asked[k])) and
             str(asked[k]) != str(CONFIG.get(k) if CONFIG.get(k) is not None else '')]
    if moved:
        # Saved here, the next restart opened a database nothing had been
        # carried into (1.0.37). The way to another one is the four steps.
        raise ApiError(400, 'the database is changed on Settings - The database with its own '
                            'steps: Try it, Set it up, Carry everything across, Start using it '
                            '(%s not saved)' % ', '.join(moved))
    try:
        return h.d.save_settings(asked, by=s['name'], node=b.get('node'))
    except BadSetting as e:
        raise ApiError(400, str(e))


@route('POST', '/api/isemon')
def _isemon_do(h):
    s = h.me('fulladmin')
    if not h.d.shipper:
        raise ApiError(503, 'nothing is being sent from this process')
    h.d.shipper.put('otp', 'daemon', 'a test from otp %s, sent by %s - isemon reads nothing '
                    'from this line' % (__version__, s['name']))
    h.d.shipper.flush(3)
    time.sleep(0.3)
    return {'isemon': h.d.shipper.state()}


@route('GET', '/api/users')
def _users(h):
    s = h.me()
    return {'users': h.store.accounts(), 'may_change': s['role'] == 'fulladmin',
            'roles': [{'role': r, 'words': ROLE_WORDS[r]} for r in ROLES_ALL]}


@route('POST', '/api/users')
def _users_do(h):
    s = h.me('fulladmin')
    b = h.body()
    act, name = b.get('action'), str(b.get('name') or '').strip()
    who = s['name']
    if act == 'add':
        h.store.add_account(name, b.get('role') or 'readonly', b.get('password'),
                            note=b.get('note') or '', must_change=b.get('must_change', 1))
        h.store.add_event('accounts', '%s made the account %s (%s)' % (who, name,
                                                                         b.get('role')), who=who)
        return {'message': 'the account %s is made' % name}
    acc = h.store.account(name)
    if not acc:
        raise ApiError(404, 'there is no account called %s' % name)
    if act in ('delete', 'disable') or (act == 'role' and b.get('role') != 'fulladmin'):
        if acc['role'] == 'fulladmin' and not h.store.fulladmins_left(but=name):
            raise ApiError(400, 'that is the last full administrator who can sign in')
    if act == 'delete':
        h.store.drop_account(name)
        h.store.add_event('accounts', '%s removed the account %s' % (who, name), 'warn', who=who)
        return {'message': 'the account %s is gone' % name}
    if act == 'role':
        h.store.set_account(name, role=b.get('role'))
        h.store.add_event('accounts', '%s made %s %s' % (who, name,
                                                         ROLE_WORDS.get(b.get('role'))), who=who)
        return {'message': 'saved'}
    if act == 'reset_cols':
        h.store.put_user_cols(acc['name'], {})
        h.store.add_event('accounts', '%s put the columns of every table back as they come '
                          'for %s' % (who, acc['name']), who=who)
        return {'message': 'the columns of %s are back as they come; they see it at their '
                           'next page load' % acc['name']}
    if act == 'password':
        h.store.set_account(name, password=b.get('password'), must_change=int(bool(
            b.get('must_change', 1))))
        h.store.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ?',
                       ('admin', name.lower()))
        h.store.add_event('accounts', '%s set a new password for %s; their sign-ins are ended'
                          % (who, name), 'warn', who=who)
        return {'message': 'the password is set'}
    if act in ('disable', 'enable'):
        h.store.set_account(name, disabled=1 if act == 'disable' else 0)
        if act == 'disable':
            h.store.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ?',
                           ('admin', name.lower()))
        h.store.add_event('accounts', '%s switched %s %s' % (who, name, 'off' if
                                                            act == 'disable' else 'on'), who=who)
        return {'message': 'saved'}
    raise ApiError(400, 'no such thing to do to an account')


@route('GET', '/api/sessions')
def _sessions(h):
    h.me('fulladmin')
    # The list is of who could still ask: the ones that sat too long are
    # tidied first (1.0.15), not shown as signed in for hours.
    h.store.sessions_tidy(int(CONFIG.get('session_idle_min') or 120) * 60,
                          int(CONFIG.get('portal_session_min') or 15) * 60)
    return {'sessions': h.store.sessions()}


@route('POST', '/api/sessions')
def _sessions_do(h):
    s = h.me('fulladmin')
    ident = int(h.body().get('id') or 0)
    row = h.store.db.row('SELECT kind, name, ip FROM sessions WHERE id = ?', (ident,))
    h.store.session_drop(ident)
    h.store.add_event('sign-ins', '%s ended the sign-in of %s%s' % (
        s['name'], (row or {}).get('name') or '?', (' from %s' % row['ip']) if row and
        row.get('ip') else ''), 'warn', who=s['name'])
    return {'message': 'ended'}


def time_span(h, lq):
    """The time picker's window (1.0.53), `from` and `to` as seconds since
    1970, added to what the search box asked."""
    since, until = h.num('from', 0, 0, 10 ** 11), h.num('to', 0, 0, 10 ** 11)
    parts, args = ([lq.sql] if lq.sql else []), list(lq.args or [])
    if since:
        parts.append('ts >= ?')
        args.append(since)
    if until:
        parts.append('ts < ?')
        args.append(until)
    lq.sql, lq.args = ' AND '.join('(%s)' % x for x in parts), args
    return since, until


@route('GET', '/api/events')
def _events(h):
    h.me()
    lq, bad = list_query('events', h.arg('q'))
    if bad:
        return {'rows': [], 'total': 0, 'q_error': bad, 'kinds': h.store.event_kinds()}
    time_span(h, lq)
    rows, total = h.store.events(h.num('limit', 100, 1, 1000), h.num('offset', 0),
                                 lq.words, h.arg('kind'), extra=(lq.sql, lq.args))
    return {'rows': rows, 'total': total, 'kinds': h.store.event_kinds()}


@route('GET', '/api/enrolment')
def _enrolment(h):
    h.me()
    since = h.num('since', 0, 0, 10 ** 9)
    lq, bad = list_query('enrolment', h.arg('q'))
    if bad:
        return {'rows': [], 'total': 0, 'q_error': bad, 'counts': {}, 'on': True}
    t_from, t_to = time_span(h, lq)
    rows, total = h.store.enrolment(h.num('limit', 100, 1, 1000), h.num('offset', 0),
                                    lq.words, h.arg('step'), since, extra=(lq.sql, lq.args))
    return {'rows': rows, 'total': total,
            'counts': h.store.enrolment_counts(since, t_from, t_to),
            'on': bool(CONFIG.get('portal'))}


@route('GET', '/api/mail')
def _mail(h):
    h.me()
    return {'mode': CONFIG.get('mail_mode') or 'off', 'ca_list': describe_certificates(
        mail_ca_pem(h.store)), 'from': CONFIG.get('mail_from') or '',
        'lang': CONFIG.get('mail_lang') or 'cs', 'codes': bool(CONFIG.get('mail_codes'))}


@route('POST', '/api/mail')
def _mail_do(h):
    b = h.body()
    act = str(b.get('action') or '')
    if act == 'test':
        s = h.me('fulladmin')
        to = str(b.get('to') or '').strip()
        if not re.match(r'^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$', to):
            raise ApiError(400, 'a mail address to send it to')
        began = time.time()
        try:
            lang = str(b.get('lang') or 'cs')
            if b.get('kind') == 'token':
                # A token's mail as it would go, with a key made up for it
                # (1.0.27): whether that gets through - pictures, codes and
                # all - is not the same question as whether a line of text
                # does. The key opens nothing.
                fake = base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')
                pic = h.d.tokens.picture('novak@example.cz', fake)
                msg = token_mail(to, 'novak@example.cz', pic,
                                 codes=['%08d' % secrets.randbelow(10 ** 8) for _ in range(5)],
                                 lang=lang if lang in MAIL_WORDS else 'cs',
                                 display='Jan Novák' if lang == 'cs' else 'John Doe',
                                 by=s['name'])
            else:
                msg = test_mail(to, lang)
            steps = mail_send(h.store, msg, [to])
        except MailError as e:
            h.store.add_event('mail', 'a test mail to %s failed: %s' % (to, e), 'warn',
                              who=s['name'])
            return {'sent': False, 'said': str(e), 'steps': e.steps,
                    'took_ms': int((time.time() - began) * 1000)}
        h.store.add_event('mail', '%s sent a test mail%s to %s%s' % (
            s['name'], ' shaped as a token\'s' if b.get('kind') == 'token' else '', to,
            mail_reply_words(steps)), who=s['name'])
        return {'sent': True, 'said': 'sent to %s' % to, 'steps': steps,
                'took_ms': int((time.time() - began) * 1000)}
    if act == 'ca':
        s = h.me('fulladmin')
        mode = str(b.get('mode') or 'add')
        try:
            got = mail_ca_set(h.store, b.get('ca'), mode, str(b.get('fingerprint') or ''))
        except ValueError as e:
            raise ApiError(400, str(e))
        h.store.add_event('settings', '%s %s the certificate authorities of the mail server'
                          % (s['name'], {'add': 'added to', 'drop': 'took one out of'}.get(
                              mode, 'emptied')), who=s['name'])
        return {'ca_list': got, 'message': 'the mail server keeps %d certificate(s)' % len(got)}
    if act == 'mail_of':
        # A person's mail address out of the directory of their realm, for
        # the box beside "Make a token" (1.0.20).
        h.me('tokenadmin')
        who = str(b.get('user') or '').strip()
        realm = h.store.realm_for(who)
        ad = h.d.dirs.get(str((realm or {}).get('directory') or '').lower())
        if not ad:
            return {'mail': '', 'display': ''}
        how = realm.get('lookup') if realm.get('lookup') in ('upn', 'sam') else (
            'upn' if '@' in who else 'sam')
        try:
            entry = ad.find_user(who if how == 'upn' else who.split('@', 1)[0], how)
        except Exception:
            entry = None
        return {'mail': (entry or {}).get('mail') or '', 'display': (entry or {}).get('display')
                or ''}
    raise ApiError(400, 'no such thing to do')


@route('GET', '/api/log')
def _log(h):
    h.me('fulladmin')
    return {'lines': log_tail(h.num('lines', 400, 10, 5000)), 'file': str(LOG_DIR / 'otp.log')}


def _db_files(h):
    db = h.store.db
    disk, grew, parts = db_disk(h.store)
    return {'copies': kept_copies(), 'dumps': kept_dumps(db.engine), 'dump': dump_info(db.engine),
            'keep': int(CONFIG.get('backup_keep') or 14), 'disk': disk, 'growth': grew,
            'parts': parts, 'cache': db_cache(h.store), 'drivers': drivers_state(),
            'erasable': db_erasable(h.store), 'tune': tune_state(h.store),
            'backup_dir': str(BACKUP_DIR), 'dump_dir': str(DUMP_DIR)}


@route('GET', '/api/db')
def _db(h):
    h.me()
    db = h.store.db
    files = _db_files(h)
    return dict(files, **{'engine': db.engine, 'words': ENGINE_WORDS.get(db.engine), 'where': db.where(),
            'version': db.version(), 'size': db.size(), 'free': db_free_inside(db),
            'counts': h.store.counts(), 'tables': db_table_sizes(db), 'backups': backups(),
            'key': str(sealing_key_path()), 'key_there': bool(sealing_key()),
            'config_file': str(CONFIG_FILE), 'job': job_read(), 'node': node_name(),
            'tuned': bool(json.loads(h.store.get_meta('tune_before:' + node_name()) or '{}')),
            'retain': {k: CONFIG.get(k) for k in ('retain_radius_days', 'retain_otp_days',
                                                    'retain_events_days')}})


def _kept_path(name, kind):
    name = os.path.basename(str(name or ''))
    if not NAME_RE.match(name):
        raise ApiError(404, 'there is no such file')
    folder = DUMP_DIR if kind == 'dump' else BACKUP_DIR
    path = folder / name
    if not path.is_file():
        raise ApiError(404, 'there is no such file: %s' % name)
    return path


@route('GET', '/api/db/download')
def _db_download(h):
    s = h.me('fulladmin')
    name, kind = h.arg('name'), h.arg('kind')
    if name:
        path = _kept_path(name, kind)
        h.store.add_event('backups', '%s downloaded %s' % (s['name'], path.name), who=s['name'])
        h.send_file(path, path.name)
        return None
    # Made now, for the machine somebody is sitting at, and not kept here.
    tmp = Path(tempfile.mkdtemp(prefix='otp-download-', dir=str(STATE_DIR)))
    try:
        if kind == 'dump':
            path = make_dump(h.store, 'download', folder=tmp)
        else:
            import gzip
            path = tmp / ('otp-copy-%s-download.json.gz' % _stamp())
            dump_tables(h.store.db, path)
            # The key that opens the tokens goes inside a downloaded copy:
            # without it the copy cannot give anybody their token back.
            key = sealing_key()
            if key:
                with_key = tmp / 'k.json.gz'
                with gzip.open(str(path), 'rt', encoding='utf-8') as src, \
                        gzip.open(str(with_key), 'wt', encoding='utf-8') as dst:
                    head = json.loads(src.readline())
                    head['key'] = key.hex()
                    dst.write(json.dumps(head) + '\n')
                    shutil.copyfileobj(src, dst, 1 << 20)
                with_key.replace(path)
        h.store.add_event('backups', '%s downloaded %s, made for it' % (s['name'], path.name),
                          who=s['name'])
        h.send_file(path, path.name)
    finally:
        shutil.rmtree(str(tmp), ignore_errors=True)
    return None


@route('POST', '/api/db/restore')
def _db_restore(h):
    s = h.me('fulladmin')
    fd, tmp = tempfile.mkstemp(prefix='otp-upload-', dir=str(STATE_DIR))
    os.close(fd)
    tmp = Path(tmp)
    try:
        h.body_to_file(tmp, 4 * 1024 ** 3)
        if h.arg('check'):
            said, why = db_file_peek(tmp, h.store.db.engine)
            if said is None:
                raise ApiError(400, why)
            return {'says': said}
        try:
            got = db_file_restore(h.store, tmp, s['name'], from_name='the page')
        except ValueError as e:
            raise ApiError(400, str(e))
        h.d.reload_all('a database was put back') if hasattr(h.d, 'reload_all') else None
        BIND_STRICT['tokens'] = False
        bind_tokens(h.store)
        return got
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


@route('POST', '/api/db')
def _db_do(h):
    s = h.me('fulladmin')
    act = h.body().get('action')
    if act == 'backup':
        out = make_backup(h.store, 'by %s' % s['name'])
        return {'message': 'a copy was made: %s' % out.name}
    if act == 'tidy':
        return {'message': 'tidied: %s' % h.store.tidy()}
    b = h.body()
    if act == 'job':
        return {'job': job_read()}
    if act == 'dump':
        try:
            out = make_dump(h.store, 'by-hand')
        except ValueError as e:
            raise ApiError(400, str(e))
        return {'name': out.name, 'bytes': out.stat().st_size,
                'message': 'made: %s' % out.name}
    if act in ('restore_kept', 'delete'):
        path = _kept_path(b.get('name'), b.get('kind'))
        if act == 'delete':
            for f in (path, _key_beside(path)):
                try:
                    f.unlink()
                except OSError:
                    pass
            h.store.add_event('backups', '%s deleted %s' % (s['name'], path.name), 'warn',
                              who=s['name'])
            return {'message': '%s is deleted' % path.name}
        if b.get('check'):
            said, why = db_file_peek(path, h.store.db.engine)
            if said is None:
                raise ApiError(400, why)
            return {'says': said}
        try:
            got = db_file_restore(h.store, path, s['name'], key_file=_key_beside(path),
                                  from_name=path.name)
        except ValueError as e:
            raise ApiError(400, str(e))
        if hasattr(h.d, 'reload_all'):
            h.d.reload_all('a database was put back')
        BIND_STRICT['tokens'] = False
        bind_tokens(h.store)
        return got
    if act == 'erase':
        try:
            return {'job': db_erase_job(h.store, list(b.get('groups') or []),
                                        bool(b.get('tidy')), s['name'])}
        except ValueError as e:
            raise ApiError(400, str(e))
    if act == 'tune_restart':
        try:
            return tune_restart(h.store, s['name'])
        except ValueError as e:
            raise ApiError(400, str(e))
    if CONFIG.get('ha_mode') and act in ('move', 'use', 'empty'):
        raise ApiError(409, 'this node is one of a cluster: its database is not moved from here '
                            '(switch the replication off first - Settings → High availability)')
    try:
        if act in ('try', 'setup', 'empty', 'move', 'use'):
            c = engine_asked(b.get('settings') or {})
            words = ENGINE_WORDS.get(c['db_engine'])
            if act == 'try':
                got = db_try(c)
                got['in_use'] = same_database(c, h.store.db)
                return got
            if act == 'setup':
                if c['db_engine'] == 'sqlite':
                    raise ApiError(400, 'the file on this machine needs no setting up')
                first = db_try(c) if c.get('db_password') else {'reached': False}
                fresh = ''
                if first.get('reached') and first.get('writable'):
                    made = ['the database and the account are there already, and it gets in']
                else:
                    who = str(b.get('admin_user') or '').strip()
                    if not who:
                        raise ApiError(400, 'an administrator of that server is needed to make '
                                            'a database and an account on it')
                    if not c.get('db_password'):
                        fresh = c['db_password'] = db_password_made()
                    made = db_make(c, who, str(b.get('admin_password') or ''))
                keep = {k: c[k] for k in DB_KEYS if k != 'db_engine'}
                write_file_settings(keep)
                far = db_open(c)
                try:
                    far.make_tables()
                    far.add_missing_columns()
                finally:
                    far.close()
                got = db_try(c)
                h.store.add_event('settings', '%s set up %s at %s' % (s['name'], words,
                                                                       db_where(c)), who=s['name'])
                return {'made': made, 'password': fresh, 'kept_in': str(CONFIG_FILE),
                        'try': got, 'message': '%s at %s is ready' % (words, db_where(c))}
            if same_database(c, h.store.db) and act in ('empty', 'move'):
                raise ApiError(400, 'that is the database in use; this only ever touches the '
                                    'other one')
            if act == 'empty':
                got = db_try(c)
                if not got.get('reached'):
                    raise ApiError(400, got.get('trouble') or 'it cannot be reached')
                gone = db_empty(c)
                h.store.add_event('settings', '%s emptied %s at %s' % (s['name'], words,
                                                                        db_where(c)), 'warn',
                                  who=s['name'])
                return {'message': 'emptied: %d table(s) thrown away' % len(gone)}
            if act == 'move':
                got = db_try(c)
                if not got.get('reached'):
                    raise ApiError(400, got.get('trouble') or 'it cannot be reached')
                if not got.get('writable'):
                    raise ApiError(400, 'that account may not write to it')
                if got.get('rows'):
                    raise ApiError(400, 'there are %d record(s) in it already. Moving into a '
                                        'database that is not empty would mix two '
                                        'installations; empty it first if it really is spare.'
                                   % got['rows'])
                return {'job': db_move(h.store, c, s['name'])}
            if act == 'use':
                if same_database(c, h.store.db):
                    raise ApiError(400, 'that is the database in use already')
                got = db_try(c)
                if not got.get('reached'):
                    raise ApiError(400, got.get('trouble') or 'it cannot be reached')
                if not got.get('rows') and not b.get('even_empty'):
                    raise ApiError(400, 'it is empty: carry everything across first')
                # An older copy is not taken for this one (1.0.37): going back
                # to a database left behind by an earlier move opened what it
                # held then, and everything since was out of sight.
                if not b.get('even_older'):
                    try:
                        far = db_open(c)
                        try:
                            there = float(far.value('SELECT MAX(ts) FROM events') or 0)
                        finally:
                            far.close()
                        here = float(h.store.db.value('SELECT MAX(ts) FROM events') or 0)
                    except Exception:                   # noqa: BLE001
                        there = here = 0
                    if there and here and there < here - 60:
                        raise ApiError(409, 'it holds an older copy: its newest event is from '
                                            '%s, this one\'s from %s. Empty it and carry '
                                            'everything across first, so nothing written '
                                            'since is left behind.' % (
                                                datetime.fromtimestamp(there).strftime(
                                                    '%d-%m-%Y %H:%M'),
                                                datetime.fromtimestamp(here).strftime(
                                                    '%d-%m-%Y %H:%M')))
                write_file_settings({k: c[k] for k in DB_KEYS})
                h.store.add_event('settings', '%s switched the database to %s at %s; the '
                                  'daemon starts again on it' % (s['name'], words, db_where(c)),
                                  'warn', who=s['name'])
                log('the database is now %s; starting again on it' % db_where(c), 'warn')
                # systemd starts it again (Restart=always), on the new one.
                threading.Timer(1.5, lambda: os.kill(os.getpid(), signal.SIGTERM)).start()
                return {'message': 'the daemon starts again on %s in a moment' % words,
                        'restarting': True}
        if act == 'check':
            got = db_check(h.store.db)
            h.store.add_event('settings', '%s checked the database: %s' % (
                s['name'], 'nothing broken' if got['ok'] else 'TROUBLE'),
                'info' if got['ok'] else 'warn', who=s['name'])
            return got
        if act == 'statistics':
            return {'message': db_statistics(h.store.db)}
        if act == 'give_back':
            by = s['name']

            def work(progress):
                got = db_give_back(h.store, progress)
                h.store.add_event('settings', '%s gave the disk back: %s -> %s'
                                  % (by, got['before'], got['after']), who=by)
                return got
            return {'job': db_job('giving the disk back', work)}
        if act == 'prune':
            days = 0 if b.get('everything') else int(b.get('days') or 0)
            if days < 1 and not b.get('everything'):
                raise ApiError(400, 'older than how many days? 1 at least')
            gone = db_prune(h.store, days)
            h.store.add_event('settings', '%s forgot the requests and checks older than %d '
                              'day(s): %s' % (s['name'], days, gone), 'warn', who=s['name'])
            return {'message': 'forgotten: %d request(s), %d check(s) of a code'
                    % (gone['radius_log'], gone['otp_log'])}
        if act == 'tune_plan':
            return tune_plan_for(h.store, b.get('machine') or {})
        if act == 'tune_apply':
            return tune_apply(h.store, b.get('machine') or {}, str(b.get('admin_user') or ''),
                              str(b.get('admin_password') or ''), s['name'])
        if act == 'tune_undo':
            return tune_undo(h.store, str(b.get('admin_user') or ''),
                             str(b.get('admin_password') or ''), s['name'])
    except ApiError:
        raise
    except ValueError as e:
        raise ApiError(400, str(e))
    except Exception as e:
        raise ApiError(400, str(e).split('\n')[0][:300])
    raise ApiError(400, 'no such thing to do to the database')


@route('GET', '/api/export')
def _export(h):
    s = h.me('fulladmin')
    whole = h.arg('secrets') == '1'
    settings = h.store.settings_saved()
    # Secrets kept in the database are sealed with this machine's key
    # (1.0.33): exported as they are, they came back sealed twice and opened
    # nowhere. Opened for an export with the secrets, left out otherwise.
    for k in SEALED_KEYS:
        if k in settings:
            if whole and settings[k]:
                settings[k] = unseal_secret(settings[k]) or ''
            else:
                settings.pop(k)
    out = {'otp': __version__, 'made': time.time(),
           'settings': settings,
           'clients': h.store.clients(with_secret=whole),
           'realms': h.store.realms(),
           'directories': h.store.directories(with_secret=whole)}
    if whole:
        h.store.add_event('settings', 'the configuration was exported with the secrets in it',
                          'warn', who=s['name'])
    return {'config': out}


@route('POST', '/api/import')
def _import(h):
    s = h.me('fulladmin')
    conf = h.body().get('config') or {}
    if not isinstance(conf, dict):
        raise ApiError(400, 'the configuration is not an object')
    for part in ('directories', 'realms', 'clients'):
        if not isinstance(conf.get(part) or [], list) or \
                not all(isinstance(x, dict) for x in conf.get(part) or []):
            raise ApiError(400, '%s is not a list of objects' % part)
    if not isinstance(conf.get('settings') or {}, dict):
        raise ApiError(400, 'settings is not an object')
    # Checked before anything is saved (1.0.44): a realm naming a directory
    # that neither is here nor comes with it stopped the import halfway.
    dirs = set(x['name'].lower() for x in h.store.directories()) | \
        set(str(d.get('name') or '').lower() for d in conf.get('directories') or [])
    for r in conf.get('realms') or []:
        if r.get('directory') and str(r['directory']).lower() not in dirs:
            raise ApiError(400, 'the realm %s names the directory %s, which is neither here '
                                'nor in the file - nothing was imported'
                           % (r.get('name'), r['directory']))
    said = collections.Counter()
    try:
        for d in conf.get('directories') or []:
            d = dict(d)
            old = h.store.directory(d.get('name'))
            d['id'] = old['id'] if old else None
            h.store.directory_save(d, s['name'])
            said['directories'] += 1
        for r in conf.get('realms') or []:
            r = dict(r)
            old = next((x for x in h.store.realms() if x['name'] == r.get('name')), None)
            r['id'] = old['id'] if old else None
            h.store.realm_save(r, s['name'])
            said['realms'] += 1
        for c in conf.get('clients') or []:
            c = dict(c)
            old = next((x for x in h.store.clients() if x['name'] == c.get('name')), None)
            c['id'] = old['id'] if old else None
            if is_masked(c.get('secret')) and not old:
                continue
            h.store.client_save(c, s['name'])
            said['clients'] += 1
        if conf.get('settings'):
            h.d.save_settings({k: v for k, v in conf['settings'].items() if k in DEFAULTS and not
                               (k in SEALED_KEYS and str(v or '').startswith('sealed:'))},
                              s['name'])
            said['settings'] = len(conf['settings'])
    except (ValueError, BadSetting) as e:
        if said:
            raise ApiError(400, '%s - imported before it stopped: %s' % (e, ', '.join(
                '%s %d' % kv for kv in sorted(said.items()))))
        raise
    finally:
        # Whatever was saved is in use, even when something after it was not
        # (1.0.44).
        if said:
            h.d.changed('all')
            h.store.add_event('settings', '%s imported a configuration: %s' % (
                s['name'], dict(said)), who=s['name'])
    return {'message': 'imported: %s' % ', '.join('%s %d' % kv for kv in sorted(said.items()))}


# ---- the enrolment pages -------------------------------------------------------------
def portal_me(h):
    s = h.session('portal')
    if not s:
        raise ApiError(401, 'not signed in, or the sign-in has run out')
    # Switched off while somebody was signed in, it is off for them too (1.0.33).
    if not CONFIG.get('portal'):
        h.store.session_end(h.headers.get('X-Otp-Session'))
        raise ApiError(403, 'enrolling a token here is switched off')
    return s


@route('GET', '/api/portal/info')
def _portal_info(h):
    return {'on': bool(CONFIG.get('portal')), 'title': CONFIG.get('portal_title') or '',
            'hint': CONFIG.get('portal_hint') or '', 'help': CONFIG.get('portal_help') or '',
            'lang': CONFIG.get('ui_lang') or 'cs', 'issuer': CONFIG.get('totp_issuer') or '',
            'site': CONFIG.get('site_name') or short_host()}


@route('POST', '/api/portal/login')
def _portal_login(h):
    if not CONFIG.get('portal'):
        raise ApiError(403, 'enrolling a token here is switched off')
    b = h.body()
    name = str(b.get('name') or '').strip()
    password = str(b.get('password') or '')
    key = h.throttle('portal', int(CONFIG.get('portal_tries') or 5),
                     int(CONFIG.get('portal_wait_min') or 15), name=name)
    full = Authenticator.full_name(name, CONFIG.get('portal_realm') or
                                   CONFIG.get('default_realm') or '')
    realm = h.store.realm_for(full) if full else None
    if not any(r.get('directory') for r in h.store.realms()):
        # Nobody can enrol yet - and the one trying is most likely the
        # administrator who has just installed this, at the wrong door.
        raise ApiError(503, 'nobody can enrol here yet: no realm with a directory is set up. '
                            'Administrators sign in at /admin/')
    if not realm or not realm.get('directory'):
        h.failed(key)
        raise ApiError(401, 'the name or the password is not right')
    ad = h.d.auth.directory(realm['directory'])
    if not ad:
        raise ApiError(503, 'the directory of this realm is not set up')
    how = realm.get('lookup') if realm.get('lookup') in ('upn', 'sam') else (
        'upn' if '@' in full else 'sam')
    try:
        entry = ad.find_user(full, how)
        if not entry:
            raise LdapError('there is no such account')
        if entry.get('disabled'):
            raise LdapError('the account is disabled')
        ad.password_ok(entry, password)
    except LdapUnreachable as e:
        log('the enrolment pages could not reach the directory: %s' % e, 'warn')
        raise ApiError(503, 'the directory cannot be reached just now')
    except LdapError as e:
        h.failed(key)
        h.store.add_event('enrolment', '%s could not sign in to the enrolment pages from %s: %s'
                          % (full, h.client_ip(), e), 'warn', who=full)
        raise ApiError(401, 'the name or the password is not right')
    # The realm's groups always: nobody enrols a token the VPN would refuse.
    # "Who may enrol" can only narrow that further, never widen it.
    who = CONFIG.get('portal_who') or 'realm_groups'
    musts = []
    if realm.get('groups'):
        musts.append(realm['groups'])
    if who == 'groups' and dn_list(CONFIG.get('portal_groups')):
        musts.append([{'group': g} for g in dn_list(CONFIG.get('portal_groups'))])
    if musts:
        have = ad.groups_of(entry, bool(realm.get('nested', 1)))
        if not all(group_matches(w, have) for w in musts):
            names = ', '.join(cn_of(w.get('group') or '') or w.get('group') or ''
                              for m in musts for w in m[:6])
            h.store.add_event('enrolment', '%s may not enrol a token: in none of the groups '
                              '(%s)' % (full, names), 'warn', who=full)
            h.d.tokens._said(Authenticator.token_name(full, realm), False,
                             'Not in the groups of the realm %s: may not enrol' % realm['name'],
                             'portal', h.client_ip(), '')
            raise ApiError(403, 'this account may not have a token here - ask the '
                           'administrator')
    tname = Authenticator.token_name(full, realm)
    # The same person under another spelling (1.0.44): DOMAIN\\name, another
    # realm on the same directory, other letters' case. A token they have
    # already under any of them is the one this session is about, so that
    # the directory password alone never makes a second one.
    if not h.store.token(tname):
        same = portal_same_person(h.store, realm, entry)
        if same:
            h.store.add_event('enrolment', '%s signed in as %s: the token %s is theirs already'
                              % (full, tname, same), 'warn', who=same)
            tname = same
    token = h.store.session_new('portal', tname, 'portal', h.client_ip(),
                                max(1, int(CONFIG.get('portal_session_min') or 15)) / 60.0 * 4,
                                {'display': entry.get('display') or '', 'dn': entry['dn'],
                                 'realm': realm['name'], 'login': full})
    h.store.add_event('enrolment', '%s signed in to the enrolment pages from %s'
                      % (tname, h.client_ip()), who=tname)
    return {'token': token, 'name': tname}


def portal_same_person(store, realm, entry):
    """The name of a token the directory entry already has under another
    spelling: its userPrincipalName, its account name with the suffix of
    any realm on the same directory, or bare - '' when none."""
    sam = str(entry.get('sam') or '').strip()
    upn = str(entry.get('upn') or '').strip()
    names = []
    if upn:
        names.append(upn)
    if sam:
        names.append(sam)
        for r in store.realms():
            if str(r.get('directory') or '').lower() != str(realm.get('directory') or '').lower():
                continue
            suf = str(r.get('suffix') or '')
            if suf and suf != '*':
                names.append('%s@%s' % (sam, suf))
    seen = set()
    for n in names:
        for cand in (n, n.lower()):
            if cand in seen:
                continue
            seen.add(cand)
            if store.token(cand):
                return norm_name(cand)
    want = set(x.lower() for x in names)
    if want:
        row = store.db.row('SELECT name FROM tokens WHERE LOWER(name) IN (%s)'
                           % ','.join('?' * len(want)), tuple(sorted(want)))
        if row:
            return row['name']
    return ''


@route('POST', '/api/portal/logout')
def _portal_logout(h):
    h.store.session_end(h.headers.get('X-Otp-Session'))
    return {}


def portal_state(h, s):
    tok = h.store.token(s['name'])
    shown = h.store.token_shown(tok)
    return {'name': s['name'], 'display': (s.get('data') or {}).get('display') or '',
            'token': shown, 'confirm': bool(CONFIG.get('portal_confirm')),
            'reissue': bool(CONFIG.get('portal_reissue')),
            'show_secret': bool(CONFIG.get('portal_show_secret')),
            'show_scratch': bool(CONFIG.get('portal_scratch')),
            'title': CONFIG.get('portal_title') or '', 'help': CONFIG.get('portal_help') or ''}


@route('GET', '/api/portal/me')
def _portal_whoami(h):
    s = h.session('portal')
    if not s:
        return {'me': None}
    if not CONFIG.get('portal'):
        # Switched off meanwhile: nothing more of it shown (1.0.44).
        h.store.session_end(h.headers.get('X-Otp-Session'))
        return {'me': None}
    return {'me': portal_state(h, s)}


def _picture_for_page(got):
    if not CONFIG.get('portal_show_secret'):
        got = dict(got)
        got.pop('secret', None)
        got.pop('secret_spaced', None)
    if not CONFIG.get('portal_scratch'):
        got = dict(got)
        got['scratch'] = []
    return got


@route('POST', '/api/portal/enroll')
def _portal_enroll(h):
    s = portal_me(h)
    tok = h.store.token(s['name'])
    if tok and tok.get('state') != 'pending':
        raise ApiError(409, 'there is a token already; it can be replaced with a code from it')
    confirm = bool(CONFIG.get('portal_confirm'))
    got = h.d.tokens.enroll(s['name'], 'self', pending=confirm,
                            display=(s.get('data') or {}).get('display') or '')
    h.store.add_event('enrolment', '%s enrolled a token for themselves%s' % (
        s['name'], ', waiting for a code' if confirm else ''), who=s['name'])
    return {'made': _picture_for_page(got), 'confirm': confirm}


@route('POST', '/api/portal/confirm')
def _portal_confirm(h):
    s = portal_me(h)
    ok, said = h.d.tokens.confirm(s['name'], str(h.body().get('code') or ''), 'portal',
                                  h.client_ip())
    if ok:
        h.store.add_event('enrolment', '%s confirmed their token' % s['name'], who=s['name'])
    return {'good': ok, 'said': said, 'me': portal_state(h, s)}


@route('POST', '/api/portal/reissue')
def _portal_reissue(h):
    s = portal_me(h)
    if not CONFIG.get('portal_reissue'):
        raise ApiError(403, 'a token can only be replaced by an administrator here')
    b = h.body()
    key = h.throttle('portal', int(CONFIG.get('portal_tries') or 5),
                     int(CONFIG.get('portal_wait_min') or 15), name=s['name'])
    realm = h.store.realm_for((s.get('data') or {}).get('login') or s['name'])
    ad = h.d.auth.directory(realm['directory']) if realm else None
    if not ad:
        raise ApiError(503, 'the directory of this realm is not set up')
    try:
        ad.password_ok({'dn': (s.get('data') or {}).get('dn')}, str(b.get('password') or ''))
    except LdapUnreachable as e:
        log('the enrolment pages could not reach the directory: %s' % e, 'warn')
        raise ApiError(503, 'the directory cannot be reached just now')
    except LdapError:
        h.failed(key)
        # 403, not 401 (1.0.33): a 401 signs the page out, and the person
        # lost the words saying what was wrong.
        raise ApiError(403, 'the password is not right')
    ok, said, _f = h.d.tokens.check(s['name'], str(b.get('code') or ''), how='portal',
                                    src=h.client_ip())
    if not ok:
        h.failed(key)
        raise ApiError(403, 'the code from the old token was not taken: %s' % said)
    if CONFIG.get('portal_confirm'):
        got = h.d.tokens.stage_replacement(s['name'], 'self')
    else:
        got = h.d.tokens.enroll(s['name'], 'self', pending=False)
    h.store.add_event('enrolment', '%s is replacing their token' % s['name'], who=s['name'])
    return {'made': _picture_for_page(got), 'confirm': bool(CONFIG.get('portal_confirm'))}


@route('POST', '/api/portal/cancel')
def _portal_cancel(h):
    s = portal_me(h)
    tok = h.store.token(s['name'])
    if tok and tok.get('pending_secret'):
        h.d.tokens.drop_staged(s['name'])
        h.store.add_event('enrolment', '%s stopped replacing their token' % s['name'],
                          who=s['name'])
    elif tok and tok.get('state') == 'pending':
        h.store.token_drop(s['name'])
        h.store.add_event('enrolment', '%s threw away the token they had not confirmed'
                          % s['name'], who=s['name'])
    return {'me': portal_state(h, s)}


class ApiHttpServer(ThreadingHTTPServer):
    """The API's HTTP server, with room for many connections waiting at once
    (1.0.33): the default queue of five dropped the sixth of twenty pages
    asking at the same moment."""
    request_queue_size = 256
    daemon_threads = True


class ApiServer(object):
    def __init__(self, daemon):
        self.daemon = daemon
        self.httpd = None

    def start(self):
        api_token(make=True)
        port = int(CONFIG.get('api_port') or 9861)
        self.httpd = ApiHttpServer(('127.0.0.1', port), ApiHandler)
        self.httpd.daemon_threads = True
        self.httpd.daemon = self.daemon
        threading.Thread(target=self.httpd.serve_forever, name='api', daemon=True).start()
        log('the API is on 127.0.0.1:%d' % port)

    def stop(self):
        try:
            self.httpd.shutdown()
        except Exception:
            pass


# ---- maintenance and upgrades (1.0.37) -----------------------------------------------
def _upgrade_view(h):
    meta = None
    try:
        meta = json.loads(h.store.get_meta('upgrade:pkg') or 'null')
    except ValueError:
        meta = None
    nodes = []
    for n in ha_nodes(h.store):
        n = dict(n)
        n['maintenance'] = maintenance_row(h.store, n['name'])
        nodes.append(n)
    if not nodes:
        nodes = [{'name': node_name(), 'version': __version__, 'me': True, 'alive': True,
                  'maintenance': maintenance_row(h.store)}]
    ok, why = upgrade_checks(h.store, meta)
    return {'node': node_name(), 'version': __version__, 'nodes': nodes, 'package': meta,
            'plan': upgrade_plan(h.store), 'ready': ok, 'not_ready': why,
            'mode': CONFIG.get('ha_mode') or '',
            'helper': UPGRADE_HELPER.exists(),
            'path_unit': Path('/etc/systemd/system/otp-upgrade.path').exists(),
            'log': upgrade_log_tail(120)}


@route('GET', '/api/upgrade')
def _upgrade(h):
    h.me('fulladmin')
    return _upgrade_view(h)


@route('POST', '/api/upgrade/package')
def _upgrade_package(h):
    s = h.me('fulladmin')
    UPGRADE_DIR.mkdir(mode=0o750, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='incoming-', suffix='.tar.gz', dir=str(UPGRADE_DIR))
    os.close(fd)
    tmp = Path(tmp)
    try:
        h.body_to_file(tmp, UPGRADE_MOST)
        try:
            info = upgrade_inspect(tmp)
        except ValueError as e:
            h.store.add_event('starting and stopping', '%s sent a package that was refused: %s'
                              % (s['name'], e), 'warn', who=s['name'])
            raise ApiError(400, str(e))
        if info.get('older'):
            raise ApiError(400, '%s is older than %s, which runs here: going back is done on '
                                'the command line' % (info['version'], info.get('installed')))
        plan = upgrade_plan(h.store)
        if plan and plan['state'] == 'running':
            raise ApiError(409, 'an upgrade is going on: wait for it, or stop it first')
        meta = upgrade_store_package(h.store, tmp, info, s['name'])
        h.store.add_event('starting and stopping', '%s sent otp %s (signed by %s), ready to '
                          'be put in' % (s['name'], meta['version'], meta.get('signed_by')),
                          'warn', who=s['name'])
        return dict(_upgrade_view(h), message='otp %s is checked and ready' % meta['version'])
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


@route('POST', '/api/upgrade')
def _upgrade_do(h):
    s = h.me('fulladmin')
    b = h.body()
    act = b.get('action')
    try:
        if act == 'start':
            upgrade_start(h.store, s['name'])
            return dict(_upgrade_view(h), message='the upgrade has begun')
        if act == 'cancel':
            upgrade_cancel(h.store, s['name'])
            return dict(_upgrade_view(h), message='the upgrade is stopped')
        if act == 'maintenance':
            name = str(b.get('node') or node_name())
            if name not in [n['name'] for n in ha_nodes(h.store)] + [node_name()]:
                raise ValueError('there is no node %s' % name)
            on = bool(b.get('on'))
            maintenance_set(h.store, on, str(b.get('why') or 'by hand'), s['name'], name)
            return dict(_upgrade_view(h), message='%s: maintenance %s' % (
                name, 'on' if on else 'off'))
        if act == 'forget':
            plan = upgrade_plan(h.store)
            if plan and plan['state'] == 'running':
                raise ValueError('an upgrade is going on with it')
            h.store.db.run("DELETE FROM meta WHERE k LIKE 'upgrade:piece:%'")
            h.store.db.run("DELETE FROM meta WHERE k = 'upgrade:pkg'")
            return dict(_upgrade_view(h), message='the package is forgotten')
    except ValueError as e:
        raise ApiError(400, str(e))
    raise ApiError(400, 'no such thing to do')


# ---- high availability (1.0.13) ---------------------------------------------------
CODE_NOW_SEEN = {}
CODE_NOW_LOCK = threading.Lock()


@route('GET', '/api/ha')
def _ha(h):
    h.me()
    return {'node': node_name(), 'address': node_address(), 'nodes': ha_nodes(h.store),
            'replication': ha_repl_state(h.store), 'job': job_read(),
            'checks': ha_checks(h.store), 'engine': h.store.db.engine,
            'mode': CONFIG.get('ha_mode') or '',
            'db_where': h.store.db.where(), 'db_host': CONFIG.get('db_host') or '',
            'config_file': str(CONFIG_FILE), 'version': __version__, 'lb': lb_facts(h.store),
            'errbase': _json_meta(h.store, 'ha:errbase:' + node_name()) or {}}


def lb_facts(store):
    """What the load balancer guides on the pages fill in (1.0.52): the real
    names, addresses and ports of this installation."""
    server_name, proxies = '', []
    for p in NGINX_CONF_PATHS:
        try:
            text = Path(p).read_text()
        except OSError:
            continue
        m = re.search(r'(?m)^\s*listen[^;]*443[^;]*;[\s\S]*?^\s*server_name\s+([^;\s]+)', text)
        if m:
            server_name = m.group(1)
        b = re.search(r'# REALIP-BEGIN(.*?)# REALIP-END', text, re.S)
        if b:
            proxies = re.findall(r'set_real_ip_from\s+([^;\s]+);', b.group(1))
        break
    v = vip_conf(store)
    clients = [{'name': c.get('name'), 'address': c.get('address')} for c in store.clients()
               if c.get('enabled')][:20]
    return {'server_name': server_name, 'trusted': proxies,
            'auth_port': int(CONFIG.get('radius_auth_port') or 1812),
            'acct_port': int(CONFIG.get('radius_acct_port') or 0),
            'vip': {'on': bool(v.get('on')), 'address': v.get('address') or '',
                    'fqdn': v.get('fqdn') or ''},
            'clients': clients}


@route('GET', '/api/ha/history')
def _ha_history(h):
    h.me()
    return {'rows': ha_history(h.store, h.num('limit', 300, 1, 2000), h.num('from', 0, 0, 10 ** 11),
                               h.num('to', 0, 0, 10 ** 11)), 'node': node_name()}


@route('POST', '/api/ha')
def _ha_do(h):
    s = h.me('fulladmin')
    b = h.body()
    act = b.get('action')
    if act == 'errors':
        return repl_errors(h.store, ask_log=bool(b.get('log', True)))
    if act == 'history_clear':
        # What the nodes saw is deleted; what was done by hand stays in
        # Events (the audit) and is only no longer shown here (1.0.56).
        now = time.time()
        n = h.store.db.run("DELETE FROM events WHERE kind = 'ha' AND ts <= ?", (now,))
        h.store.set_meta('ha:history_cleared', str(now))
        h.store.add_event('settings', '%s cleared the cluster\'s history' % s['name'], 'warn',
                          who=s['name'])
        return {'message': 'the history is cleared', 'gone': n if isinstance(n, int) else None}
    if act == 'errors_clear':
        repl_errors_clear(h.store, s['name'])
        h.store.add_event('settings', '%s cleared the replication errors of %s (counted from now '
                          'on)' % (s['name'], node_name()), who=s['name'])
        return {'message': 'cleared: the errors are counted from now on', **repl_errors(
            h.store, ask_log=False)}
    if act == 'bundle':
        try:
            if CONFIG.get('ha_mode') == 'replicated':
                # The second node of two replicating ones - or the same one
                # again, after it was lost or reinstalled.
                data = {'mode': 'replicated', 'key': sealing_key().hex(),
                        'pg_major': int(h.store.db.value('SHOW server_version_num')) // 10000,
                        'slot': 3 - int(CONFIG.get('ha_slot') or 1),
                        'db': {'db_name': CONFIG.get('db_name'), 'db_user': CONFIG.get('db_user'),
                               'db_password': CONFIG.get('db_password')},
                        'peer': {'name': node_name(), 'slot': int(CONFIG.get('ha_slot') or 1),
                                 'address': CONFIG.get('ha_address') or node_address(),
                                 'port': int(CONFIG.get('db_port') or 5432)},
                        'cluster': CONFIG.get('site_name') or 'otp'}
                data['db']['db_host'] = data['peer']['address']
            else:
                data = ha_bundle_data(h.store, str(b.get('db_host') or '').strip())
        except ValueError as e:
            raise ApiError(400, str(e))
        phrase = ha_passphrase()
        locked = bundle_lock(data, phrase)
        h.store.add_event('settings', '%s made a bundle for a second node to join this one '
                          '(the database at %s)' % (s['name'], data['db']['db_host']), 'warn',
                          who=s['name'])
        return {'bundle': locked, 'passphrase': phrase, 'db_host': data['db'].get('db_host', ''),
                'mode': data.get('mode') or 'shared',
                'name': 'otp-join-%s-%s.json' % (node_name(), datetime.now().strftime('%Y%m%d'))}
    if act == 'join':
        try:
            data = bundle_open(b.get('bundle'), str(b.get('passphrase') or ''))
            if data.get('mode') == 'replicated':
                raise ValueError('this bundle makes this node replicate with its own PostgreSQL, '
                                 'which takes root on this machine (installing and setting up '
                                 'PostgreSQL): copy it here and run  otp --ha-join FILE  as root')
            got = ha_join(data, str(b.get('name') or '').strip(), bool(b.get('even_if_data')),
                          s['name'])
        except ValueError as e:
            raise ApiError(400, str(e))
        h.store.add_event('settings', '%s joined this node to the cluster of %s; it starts '
                          'again on %s' % (s['name'], (data.get('peer') or {}).get('name', '?'),
                                           got['where']), 'warn', who=s['name'])
        log('joining the cluster: starting again on %s' % got['where'], 'warn')
        threading.Timer(1.5, lambda: os.kill(os.getpid(), signal.SIGTERM)).start()
        got['restarting'] = True
        return got
    if act in ('pause', 'resume', 'pause_in', 'pause_out', 'resume_in', 'resume_out', 'stop',
               'refresh'):
        try:
            return ha_control(h.store, act, s['name'])
        except (ValueError, DbError) as e:
            raise ApiError(400, str(e).split('\n')[0][:400])
        except Exception as e:                          # noqa: BLE001
            raise ApiError(400, str(e).split('\n')[0][:400])
    if act == 'resync':
        try:
            return {'job': ha_resync_job(h.store, s['name'])}
        except ValueError as e:
            raise ApiError(400, str(e))
    if act == 'forget':
        try:
            ha_forget(h.store, str(b.get('name') or ''))
        except ValueError as e:
            raise ApiError(400, str(e))
        h.store.add_event('settings', '%s took the node %s off the list' % (s['name'], b.get('name')),
                          who=s['name'])
        return {'message': 'gone from the list; it comes back by itself if it is still running'}
    raise ApiError(400, 'no such thing to do')


# ---- TLS and the cluster's web address (1.0.47) ------------------------------------
@route('GET', '/api/web')
def _web(h):
    me = h.me()
    store = h.store
    nodes = []
    for n in ha_nodes(store):
        one = {k: n.get(k) for k in ('name', 'me', 'alive', 'address', 'version', 'maintenance',
                                     'age', 'host')}
        one['web'] = web_state(store) if n['me'] else (n.get('web') or {})
        nodes.append(one)
    if not any(x['me'] for x in nodes):
        nodes.insert(0, {'name': node_name(), 'me': True, 'alive': True,
                         'address': node_address(), 'web': web_state(store)})
    v = vip_conf(store)
    holder = [x['name'] for x in nodes if (x.get('web') or {}).get('vip_here')]
    return {'node': node_name(), 'cluster': bool(CONFIG.get('ha_mode')), 'nodes': nodes,
            'vip': dict(v, prefer_now=vip_prefer(store, v) if CONFIG.get('ha_mode') else '',
                        holder=holder),
            'tls': {t: tls_view(tls_profile(store, t)) for t in tls_targets(store)},
            'presets': TLS_PRESETS, 'dh': DH_WORDS,
            'may': me.get('role') == 'fulladmin'}


@route('POST', '/api/web')
def _web_do(h):
    s = h.me('fulladmin')
    who = s['name']
    b = h.body()
    act = str(b.get('action') or '')
    store = h.store
    target = str(b.get('target') or '')
    if act.startswith('tls_'):
        if target not in tls_targets(store):
            raise ApiError(400, 'there is no node or address called %s' % target)
        prof = tls_profile(store, target) or {}
        words = 'the web address' if target == 'vip' else target
    if act in ('tls_upload', 'tls_selfsigned'):
        if act == 'tls_upload':
            pfx = b''
            if b.get('pfx'):
                try:
                    pfx = base64.b64decode(str(b['pfx']), validate=True)
                except (ValueError, binascii.Error):
                    raise ApiError(400, 'the PFX / PKCS#12 file did not arrive whole')
                if len(pfx) > 200000:
                    raise ApiError(400, 'that is far bigger than any certificate file')
            pending = unseal_secret(prof['pending_key'], 'web:tls') if prof.get('pending_key') \
                else ''
            got = cert_bundle(b.get('cert'), b.get('key'), b.get('chain'), b.get('root'), pfx,
                              str(b.get('password') or ''), pending)
            how = 'uploaded'
        else:
            names = [x.strip() for x in re.split(r'[\s,;]+', str(b.get('names') or '')) if x.strip()]
            key, crt = make_selfsigned(str(b.get('cn') or '').strip(), names,
                                       int(b.get('days') or 825), str(b.get('kind') or 'rsa2048'),
                                       org=str(b.get('org') or ''))
            got = cert_bundle(crt, key)
            how = 'self-signed, made here'
        info = got['info']
        if info.get('not_after') and info['not_after'] < time.time():
            raise ApiError(400, 'this certificate ran out on %s' % stamp(info['not_after']))
        prof.update(cert=got['cert'], chain=got['chain'], root=got['root'],
                    key=seal_secret(got['key'], 'web:tls'), info=info,
                    chain_info=got['chain_info'], root_info=got['root_info'],
                    verify=got['verify'], how=how)
        prof.pop('pending_key', None)
        prof.pop('csr', None)
        prof.setdefault('preset', 'standard')
        prof.setdefault('dh', 'none')
        tls_save(store, target, prof, who)
        store.add_event('settings', '%s put a certificate in for %s: %s (until %s)' % (
            who, words, info.get('subject'), stamp(info.get('not_after')) if info.get('not_after') else '?'), 'warn', who=who)
        return {'message': 'the certificate of %s is kept; the node%s put%s it in within a few '
                           'seconds' % (words, 's' if target == 'vip' else '',
                                        '' if target == 'vip' else 's'),
                'tls': tls_view(prof)}
    if act == 'tls_csr':
        names = [x.strip() for x in re.split(r'[\s,;]+', str(b.get('names') or '')) if x.strip()]
        key, csr = make_csr(str(b.get('cn') or '').strip(), names, str(b.get('kind') or 'rsa2048'),
                            org=str(b.get('org') or ''), unit=str(b.get('unit') or ''),
                            country=str(b.get('country') or ''), city=str(b.get('city') or ''))
        prof.update(pending_key=seal_secret(key, 'web:tls'), csr=csr,
                    csr_at=time.time(), csr_cn=str(b.get('cn') or ''))
        tls_save(store, target, prof, who)
        store.add_event('settings', '%s made a certificate request for %s (%s)'
                        % (who, words, b.get('cn')), who=who)
        return {'message': 'the request is made: give it to your certificate authority, then '
                           'upload what it sends back - the key waits here', 'csr': csr,
                'tls': tls_view(prof)}
    if act == 'tls_csr_drop':
        prof.pop('pending_key', None)
        prof.pop('csr', None)
        tls_save(store, target, prof, who)
        return {'message': 'the request and its waiting key are gone', 'tls': tls_view(prof)}
    if act == 'tls_policy':
        prof.update(tls_policy_checked(b))
        tls_save(store, target, prof, who)
        store.add_event('settings', '%s changed the TLS settings of %s: %s, DH %s%s' % (
            who, words, prof['preset'], prof['dh'],
            ', HSTS %d s' % prof['hsts'] if prof.get('hsts') else ''), who=who)
        slow = prof['dh'] in ('gen3072', 'gen4096')
        return {'message': 'the TLS settings of %s are kept%s' % (
            words, '; making the DH parameters takes a while' if slow else ''),
                'tls': tls_view(prof)}
    if act == 'tls_forget':
        store.db.run('DELETE FROM meta WHERE k = ?', ('web:tls:' + target,))
        store.add_event('settings', '%s: otp no longer looks after the TLS of %s (nginx keeps '
                        'what it has)' % (who, words), 'warn', who=who)
        return {'message': 'otp no longer looks after the TLS of %s; nginx keeps the files it '
                           'has' % words}
    if act == 'tls_pem':
        if not prof.get('cert'):
            raise ApiError(404, 'no certificate is kept for %s' % words)
        return {'pem': prof['cert'] + (prof.get('chain') or ''), 'csr': prof.get('csr') or ''}
    if act in ('vip_save', 'vip_on', 'vip_off', 'vip_move'):
        if not CONFIG.get('ha_mode'):
            raise ApiError(409, 'the web address is for a cluster: make this node one of two '
                                'first (Settings - High availability)')
    if act == 'vip_save':
        v = vip_set(store, who, **vip_checked(b, store))
        store.add_event('settings', '%s set the web address: %s%s, VRRP id %d' % (
            who, v['address'], ' (%s)' % v['fqdn'] if v['fqdn'] else '', v['vrid']), who=who)
        return {'message': 'the web address is kept%s' % (
            '; each node puts it in within a few seconds' if v.get('on') else
            ' - turn it on when ready')}
    if act == 'vip_on':
        v = vip_conf(store)
        if not v.get('address'):
            raise ApiError(400, 'give the address first')
        vip_set(store, who, on=True)
        store.add_event('settings', '%s turned the web address %s on' % (who, v['address']),
                        'warn', who=who)
        return {'message': 'the web address is on: each node installs keepalived if it has to '
                           'and the address comes up on %s' % vip_prefer(store)}
    if act == 'vip_off':
        vip_set(store, who, on=False)
        store.add_event('settings', '%s turned the web address off' % who, 'warn', who=who)
        return {'message': 'the web address is off: keepalived stops on both nodes'}
    if act == 'vip_mode':
        mode = str(b.get('mode') or '')
        if mode not in ('back', 'stays'):
            raise ApiError(400, 'back or stays')
        changes = {'mode': mode}
        if mode == 'back':
            to = str(b.get('prefer') or '')
            if to and to not in {n['name'] for n in ha_nodes(store)}:
                raise ApiError(400, 'there is no node called %s' % to)
            if to:
                changes['prefer'] = to
        vip_set(store, who, **changes)
        v = vip_conf(store)
        store.add_event('settings', '%s: the web address %s' % (who, (
            'always goes back to %s' % vip_prefer(store, v)) if mode == 'back' else
            'stays where it is - it moves only when that node fails or by hand'), 'warn',
            who=who)
        return {'message': 'kept'}
    if act == 'vip_move':
        to = str(b.get('to') or '')
        nodes = {n['name']: n for n in ha_nodes(store)}
        if to not in nodes:
            raise ApiError(400, 'there is no node called %s' % to)
        if not nodes[to].get('alive'):
            raise ApiError(409, '%s is not answering: the address cannot go there' % to)
        if vip_conf(store).get('mode') == 'stays':
            vip_set(store, who, move_to=to, move_at=time.time())
            store.add_event('settings', '%s moved the web address to %s (it stays there)'
                            % (who, to), 'warn', who=who)
            return {'message': 'the web address goes to %s within a few seconds and stays '
                               'there' % to}
        vip_set(store, who, prefer=to)
        store.add_event('settings', '%s moved the web address to %s' % (who, to), 'warn', who=who)
        return {'message': 'the web address goes to %s within a few seconds (if it is healthy)'
                           % to}
    if act == 'retry':
        node = str(b.get('node') or node_name())
        store.set_meta('web:retry:' + node, str(time.time()))
        return {'message': '%s tries again within a few seconds' % node}
    raise ApiError(400, 'no such thing to do')


# ---- the local firewall, who may reach which pages (1.0.52) ---------------------------
@route('GET', '/api/firewall')
def _firewall(h):
    me = h.me()
    store = h.store
    nodes = []
    for n in ha_nodes(store):
        w = web_state(store) if n['me'] else (n.get('web') or {})
        nodes.append({'name': n['name'], 'me': n['me'], 'alive': n.get('alive'),
                      'address': n.get('address'), 'version': n.get('version'),
                      'fw': w.get('fw') or {}, 'access': w.get('access') or {},
                      'state': w.get('state') or '', 'said': w.get('said') or [],
                      'current': w.get('current'), 'waiting': w.get('waiting'),
                      'progress': w.get('progress'),
                      'auto': fw_auto(store, n['name'])})
    if not any(x['me'] for x in nodes):
        w = web_state(store)
        nodes.insert(0, {'name': node_name(), 'me': True, 'alive': True,
                         'address': node_address(), 'fw': w.get('fw') or {},
                         'access': w.get('access') or {}, 'state': w.get('state') or '',
                         'said': w.get('said') or [], 'current': w.get('current'),
                         'waiting': w.get('waiting'), 'progress': w.get('progress'),
                         'auto': fw_auto(store, node_name())})
    c = fw_conf(store)
    a = access_conf(store)
    if not a:
        # Not set here yet: what nginx says now, from this node.
        now = next((x['access'] for x in nodes if x['me']), {}) or {}
        a = {k: {'any': bool((now.get(k) or {}).get('any', k == 'health')),
                 'from': list((now.get(k) or {}).get('from') or [])} for k in ACCESS_WORDS}
        a['from_nginx'] = True
    return {'node': node_name(), 'cluster': bool(CONFIG.get('ha_mode')), 'nodes': nodes,
            'conf': {'on': bool(c.get('on')), 'set': bool(c.get('set')), 'off': c.get('off') or [],
                     'rules': c.get('rules') or [], 'by': c.get('by'), 'at': c.get('at')},
            'access': a, 'access_words': ACCESS_WORDS,
            'inner': {x['name']: cluster_addresses(store, x['name']) for x in nodes},
            'optional': list(FW_AUTO_OPTIONAL), 'may': me.get('role') == 'fulladmin'}


@route('POST', '/api/firewall')
def _firewall_do(h):
    s = h.me('fulladmin')
    who = s['name']
    b = h.body()
    act = str(b.get('action') or '')
    store = h.store
    c = fw_conf(store)
    if act == 'rule_check':
        return {'rule': fw_rule_checked(b.get('rule') if isinstance(b.get('rule'), dict) else {},
                                        store)}
    if act == 'save':
        # Everything at once, from the save bar (1.0.54).
        raw = b.get('rules') or []
        if not isinstance(raw, list) or len(raw) > 200:
            raise ApiError(400, 'two hundred rules at most')
        rules = []
        for x in raw:
            if not isinstance(x, dict):
                raise ApiError(400, 'a rule is not an object')
            r = fw_rule_checked(x, store)
            r['id'] = re.sub(r'[^0-9a-z]', '', str(x.get('id') or ''))[:16] or secrets.token_hex(4)
            if r['id'].startswith('n'):
                r['id'] = secrets.token_hex(4)
            rules.append(r)
        off = [k for k in (b.get('off') or []) if k in FW_AUTO_OPTIONAL]
        was = fw_conf(store)
        said = []
        if 'access' in b and isinstance(b.get('access'), dict):
            a = access_checked_api(b['access'])
            store.set_meta('web:access', json.dumps(dict(a, at=time.time(), by=who)))
            said.append('who may reach the pages: %s' % '; '.join(
                '%s %s' % (k, 'everybody' if v['any'] else ', '.join(v['from']))
                for k, v in a.items()))
        on = bool(b.get('on'))
        if on != bool(was.get('on')):
            said.append('otp\'s firewall rules %s' % ('on' if on else 'off'))
        if rules != (was.get('rules') or []):
            said.append('%d rule(s) of your own' % len(rules))
        if sorted(off) != sorted(was.get('off') or []):
            said.append('turned off: %s' % (', '.join(off) or 'nothing'))
        fw_set(store, who, on=on, off=off, rules=rules)
        if said:
            store.add_event('settings', '%s changed the firewall and access: %s'
                            % (who, ' · '.join(said)), 'warn', who=who)
        return {'message': 'saved; each node puts it in within a few seconds'}
    if act in ('on', 'off'):
        fw_set(store, who, on=act == 'on')
        store.add_event('settings', '%s turned otp\'s firewall rules %s' % (who, act), 'warn',
                        who=who)
        return {'message': 'otp\'s rules are %s; each node puts that in within a few seconds'
                           % ('on' if act == 'on' else 'taken away (the rest of the firewall '
                                                       'stays as it was)')}
    if act == 'auto':
        key = str(b.get('key') or '')
        if key not in FW_AUTO_OPTIONAL:
            raise ApiError(400, 'that one cannot be turned off')
        off = [k for k in c.get('off') or [] if k != key]
        if not b.get('on'):
            off.append(key)
        fw_set(store, who, off=off)
        store.add_event('settings', '%s turned the firewall rule for %s %s' % (
            who, key, 'on' if b.get('on') else 'off'), 'warn', who=who)
        return {'message': 'kept'}
    if act in ('rule_add', 'rule_save'):
        r = fw_rule_checked(b.get('rule') if isinstance(b.get('rule'), dict) else {}, store)
        rules = list(c.get('rules') or [])
        if act == 'rule_add':
            if len(rules) >= 200:
                raise ApiError(400, 'two hundred rules at most')
            r['id'] = secrets.token_hex(4)
            rules.append(r)
        else:
            i = next((i for i, x in enumerate(rules) if x.get('id') == b.get('id')), None)
            if i is None:
                raise ApiError(404, 'no such rule')
            r['id'] = rules[i]['id']
            rules[i] = r
        fw_set(store, who, rules=rules)
        store.add_event('settings', '%s %s a firewall rule: %s %s%s%s (%s)' % (
            who, 'added' if act == 'rule_add' else 'changed', r['action'], r['proto'],
            ' ' + r['port'] if r['port'] else '', ' from ' + r['source'] if r['source'] else '',
            r['scope']), 'warn', who=who)
        return {'message': 'kept', 'id': r['id']}
    if act == 'rule_drop':
        rules = [x for x in c.get('rules') or [] if x.get('id') != b.get('id')]
        fw_set(store, who, rules=rules)
        store.add_event('settings', '%s took a firewall rule away' % who, 'warn', who=who)
        return {'message': 'gone'}
    if act == 'rule_move':
        rules = list(c.get('rules') or [])
        i = next((i for i, x in enumerate(rules) if x.get('id') == b.get('id')), None)
        if i is None:
            raise ApiError(404, 'no such rule')
        j = i + (-1 if b.get('dir') == 'up' else 1)
        if 0 <= j < len(rules):
            rules[i], rules[j] = rules[j], rules[i]
            fw_set(store, who, rules=rules)
        return {'message': 'moved'}
    if act == 'access':
        a = access_checked_api(b)
        store.set_meta('web:access', json.dumps(dict(a, at=time.time(), by=who)))
        store.add_event('settings', '%s set who may reach the pages: %s' % (who, '; '.join(
            '%s %s' % (k, 'everybody' if v['any'] else ', '.join(v['from'])) for k, v in a.items())),
            'warn', who=who)
        return {'message': 'kept; each node\'s nginx takes it within a few seconds (the other '
                           'node and the web address are always let in)'}
    raise ApiError(400, 'no such thing to do')


# ---------------------------------------------------------------------------
# The command line
# ---------------------------------------------------------------------------
# Everything the pages can do, and the accounts and passwords besides - which
# are handled by talking to the database directly, never through the API,
# because the moment the command line is most needed is the moment nobody
# can sign in. In colour on a terminal and plain anywhere else, `[ ok ]` and
# `[fail]` standing in for the colours, exactly as isemon does it.

# ---------------------------------------------------------------------------
# Colour - as isemon does it
# ---------------------------------------------------------------------------
# colorama when it is installed, and the same escape sequences written by hand
# when it is not. A nicety, never a dependency: a server being put right at two
# in the morning is not the one to find that the token server will not start
# because a colour library is missing. colorama adds a Windows console, a
# terminal reset however the program ends, and nothing else on Linux.
try:
    import colorama
    from colorama import Fore as _Fore, Style as _Style
    HAVE_COLORAMA = True
except Exception:                       # not installed, or installed broken
    colorama = None
    HAVE_COLORAMA = False

    class _Fore(object):
        RED = '\033[31m'; GREEN = '\033[32m'; YELLOW = '\033[33m'
        BLUE = '\033[34m'; MAGENTA = '\033[35m'; CYAN = '\033[36m'
        WHITE = '\033[37m'; RESET = '\033[39m'

    class _Style(object):
        BRIGHT = '\033[1m'; DIM = '\033[2m'; NORMAL = '\033[22m'
        RESET_ALL = '\033[0m'

_COLORAMA_READY = False


def start_colour():
    global _COLORAMA_READY
    if _COLORAMA_READY or not HAVE_COLORAMA:
        return
    _COLORAMA_READY = True
    try:
        if hasattr(colorama, 'just_fix_windows_console'):
            colorama.just_fix_windows_console()
        else:
            colorama.init()
    except Exception:
        pass


ANSI = re.compile(r'\033\[[0-9;]*m')


def plain_len(text):
    """How wide something looks, the colour taken out."""
    return len(ANSI.sub('', str(text)))


def plain_pad(text, width):
    return str(text) + ' ' * max(0, width - plain_len(text))


class Palette(object):
    """Every colour the command line uses, in one place."""

    def __init__(self, on):
        self.on = bool(on)
        if self.on:
            start_colour()

        def code(*parts):
            return ''.join(parts) if self.on else ''

        self.c_ok = code(_Fore.GREEN)
        self.c_warn = code(_Fore.YELLOW)
        self.c_bad = code(_Style.BRIGHT, _Fore.RED)
        self.c_info = code(_Fore.CYAN)
        self.c_head = code(_Style.BRIGHT, _Fore.CYAN)
        self.c_key = code(_Fore.WHITE)
        self.c_addr = code(_Fore.MAGENTA)
        self.c_hi = code(_Style.BRIGHT)
        self.c_dim = code(_Style.DIM)
        self.off = code(_Style.RESET_ALL)
        try:
            self.width = max(60, min(120, shutil.get_terminal_size((100, 24)).columns))
        except Exception:
            self.width = 100

    def paint(self, text, colour):
        if not self.on or not colour:
            return str(text)
        return '%s%s%s' % (colour, text, self.off)

    def good(self, t):
        return self.paint(t, self.c_ok)

    def bad(self, t):
        return self.paint(t, self.c_bad)

    def warn(self, t):
        return self.paint(t, self.c_warn)

    def info(self, t):
        return self.paint(t, self.c_info)

    def dim(self, t):
        return self.paint(t, self.c_dim)

    soft = dim

    def head(self, t):
        return self.paint(t, self.c_head)

    def bold(self, t):
        return self.paint(t, self.c_hi)

    hi = bold

    def addr(self, t):
        return self.paint(t, self.c_addr)

    def ok_line(self, t):
        return (self.good('✔ ') if self.on else '[ ok ] ') + str(t)

    def warn_line(self, t):
        return (self.warn('! ') if self.on else '[warn] ') + str(t)

    def bad_line(self, t):
        return (self.bad('✘ ') if self.on else '[fail] ') + str(t)


def colour_wanted(no_color=False, stream=None):
    """What the person asked for, then NO_COLOR, then FORCE_COLOR, then the
    terminal itself - in that order, as isemon decides it."""
    if no_color or os.environ.get('NO_COLOR') is not None:
        return False
    if os.environ.get('FORCE_COLOR') or os.environ.get('CLICOLOR_FORCE'):
        return True
    if str(os.environ.get('TERM') or '').lower() in ('dumb', '') \
            and not os.environ.get('TERM_PROGRAM'):
        return False
    try:
        return bool((stream or sys.stdout).isatty())
    except Exception:
        return False


def table(rows, heads, widths=None):
    if not rows:
        return '  (none)'
    cols = list(zip(*([heads] + [[str(c) for c in r] for r in rows])))
    w = widths or [min(48, max(len(x) for x in col)) for col in cols]
    out = ['  ' + '  '.join(h.upper().ljust(w[i]) for i, h in enumerate(heads))]
    for r in rows:
        out.append('  ' + '  '.join(str(c)[:w[i]].ljust(w[i]) for i, c in enumerate(r)))
    return '\n'.join(out)


def ask_password(prompt='password', twice=True):
    said = os.environ.get('OTP_PASSWORD')
    if said:
        return said
    first = getpass.getpass('%s: ' % prompt)
    if twice:
        again = getpass.getpass('and again: ')
        if first != again:
            raise SystemExit('those two are not the same')
    return first


class HelpfulParser(argparse.ArgumentParser):
    """An ArgumentParser whose help is isemon's: two columns, in colour.
    Anything going wrong in the drawing falls back to argparse's own."""
    palette = None

    def format_help(self):
        try:
            return help_text(self, self.palette or Palette(False))
        except Exception:
            return super(HelpfulParser, self).format_help()

    def error(self, message):
        pal = self.palette or Palette(False)
        sys.stderr.write('%s\n' % pal.bad_line(message))
        sys.stderr.write(pal.dim('try:  otp --help') + '\n')
        raise SystemExit(2)


def help_option_words(action):
    names = ', '.join(action.option_strings)
    if action.nargs == 0:
        return names, ''
    if action.metavar:
        meta = ' '.join(action.metavar) if isinstance(action.metavar, tuple) else action.metavar
    elif action.choices:
        meta = '{%s}' % ','.join(str(c) for c in action.choices)
    else:
        meta = action.dest.upper()
    if action.nargs in ('+', '*'):
        meta += ' ...'
    return names, meta


def help_text(parser, pal):
    """The whole of --help, in the width of this terminal."""
    import textwrap
    width = pal.width
    out = ['%s %s' % (pal.head('otp'), pal.bold(__version__)),
           pal.dim('a one-time password server: RADIUS, TOTP, the enrolment of tokens and '
                   'Active Directory, in one Python file'),
           '',
           '%s otp %s' % (pal.paint('usage:', pal.c_key), pal.dim('[--json] [--no-color] '
                                                                  '[what to do]')),
           pal.dim('       otp is the same command; with nothing at all it says what it is doing')]
    every = [a for g in parser._action_groups for a in g._group_actions]
    left = min(34, max([len(' '.join(x for x in help_option_words(a) if x))
                        for a in every] or [20]) + 2)
    for group in parser._action_groups:
        actions = [a for a in group._group_actions if a.help != argparse.SUPPRESS]
        if not actions:
            continue
        out.append('')
        out.append(pal.head((group.title or '').upper()))
        if group.description:
            for line in textwrap.wrap(group.description, width - 2):
                out.append('  ' + pal.dim(line))
        for action in actions:
            names, meta = help_option_words(action)
            painted = pal.good(names) + (' ' + pal.warn(meta) if meta else '')
            says = action.help or ''
            if (action.default not in (None, False, argparse.SUPPRESS)
                    and action.nargs != 0 and action.default != []):
                says += ' [%s]' % action.default
            lines = textwrap.wrap(says, max(24, width - left - 4)) or ['']
            if plain_len(painted) > left:
                out.append('  ' + painted)
                lines_at = 0
            else:
                out.append('  %s  %s' % (plain_pad(painted, left), lines[0]))
                lines_at = 1
            for more in lines[lines_at:]:
                out.append('  %s  %s' % (' ' * left, more))
    out.append('')
    out.append(pal.head('THINGS PEOPLE ACTUALLY TYPE'))
    wide = min(36, max(len(c.split('\n')[0]) for c, _ in HELP_EXAMPLES) + 2)
    for command, says in HELP_EXAMPLES:
        first, *rest = command.split('\n')
        if len(first) + 2 > wide:
            out.append('  ' + pal.info(first) + ('' if rest or not says else ''))
            for r in rest:
                out.append('  ' + pal.info(r))
            if says:
                out.append('  %s  %s' % (' ' * wide, pal.dim(says)))
        else:
            out.append('  %s%s' % (plain_pad(pal.info(first), wide), pal.dim(says)))
            for r in rest:
                out.append('  ' + pal.info(r))
    out.append('')
    for note in ('the pages are at https://<this machine>/ (enrolment) and /admin/ · '
                 'the configuration is %s' % CONFIG_FILE,
                 'typed with nothing at all it is --status; systemd runs the daemon as '
                 '--daemon, and only one runs at a time',
                 'colour is off when this is piped, and with --no-color or NO_COLOR=1'
                 + ('' if HAVE_COLORAMA else ' (colorama is not installed; colour is '
                                             'written by hand)')):
        for line in textwrap.wrap(note, width - 4):
            out.append('  ' + pal.dim(line))
    out.append('')
    return '\n'.join(out)


def build_parser():
    p = HelpfulParser(prog='otp', add_help=False, usage='otp [--json] [--no-color] [what to do]',
                      description='a one-time password server: RADIUS, TOTP, the enrolment '
                                  'of tokens and Active Directory, in one Python file',
                      formatter_class=lambda prog: argparse.RawDescriptionHelpFormatter(
                          prog, max_help_position=36, width=100))
    g = p.add_argument_group('EVERYWHERE')
    g.add_argument('-h', '--help', action='store_true', help='this, and stop')
    g.add_argument('--version', action='store_true', help='which version this is, and stop')
    g.add_argument('--config', metavar='FILE', help='use this config file')
    g.add_argument('--no-color', '--no-colour', action='store_true', dest='no_color',
                   help='plain text, no colour')
    g.add_argument('--json', action='store_true', help='answer as JSON where it makes sense')
    g.add_argument('--daemon', action='store_true',
                   help='run the daemon in the foreground (what systemd starts); one at a time')
    g.add_argument('--debug', action='store_true', help='say everything, this run only')
    g = p.add_argument_group('LOOKING', 'Reading what it knows. None of these change anything.')
    g.add_argument('--status', action='store_true', help='what it is doing, in one screen')
    g.add_argument('--check', action='store_true', help='a health check, every part of it')
    g.add_argument('--log', action='store_true', help='the RADIUS requests, newest first')
    g.add_argument('--rejects', action='store_true', help='with --log: only the refusals')
    g.add_argument('--request', type=int, metavar='ID',
                   help='one RADIUS request, every attribute and every step of the decision')
    g.add_argument('--otp-log', action='store_true', help='every check of a code')
    g.add_argument('--tokens', action='store_true', help='who has a token')
    g.add_argument('--token', metavar='NAME', help='one token, and what it has been doing')
    g.add_argument('--events', action='store_true', help='this daemon’s own events')
    g.add_argument('--limit', type=int, default=40, metavar='N', help='how many rows [40]')
    g.add_argument('--hours', type=float, default=24, metavar='N', help='the last N hours [24]')
    g.add_argument('--search', metavar='TEXT', default='', help='only rows holding this')
    g = p.add_argument_group('TOKENS')
    g.add_argument('--enroll', metavar='NAME', help='make a token for NAME (replacing any) and '
                   'show its QR code in the terminal')
    g.add_argument('--pending', action='store_true', help='with --enroll: not in use until a '
                   'code from it is confirmed (--confirm)')
    g.add_argument('--no-qr', action='store_true', help='with --enroll: no QR code, the key only')
    g.add_argument('--invert', action='store_true', help='the QR code for a light terminal')
    g.add_argument('--confirm', nargs=2, metavar=('NAME', 'CODE'), help='confirm a waiting token')
    g.add_argument('--verify', nargs=2, metavar=('NAME', 'CODE'),
                   help='is CODE right for NAME now? (uses nothing up)')
    g.add_argument('--disable-token', metavar='NAME', help='switch a token off, keeping it')
    g.add_argument('--enable-token', metavar='NAME', help='switch it on again')
    g.add_argument('--delete-token', metavar='NAME', help='take a token away for good')
    g.add_argument('--scratch', metavar='NAME', help='new recovery codes for NAME')
    g.add_argument('--unlock', metavar='NAME', help='forget the wrong codes, so NAME may try '
                   'again at once')
    g.add_argument('--import-totpcgi', metavar='DIR', help='bring the *.totp files of a totpcgi '
                   'server over')
    g.add_argument('--import-legacy', metavar='ROOT', help='bring a whole totpcgi + FreeRADIUS '
                   'server over: its clients, realms, directory, groups, settings and tokens '
                   '(ROOT holds etc/raddb and etc/totpcgi)')
    g.add_argument('--replace', action='store_true', help='with the imports: replace what is '
                   'here already')
    g = p.add_argument_group('RADIUS')
    g.add_argument('--radtest', nargs='+', metavar='ARG', help='USER CODE [SERVER [PORT '
                   '[SECRET]]] - ask the way radtest does; the server is this one, the secret '
                   'that of the client for 127.0.0.1, unless given')
    g.add_argument('--clients', action='store_true', help='the RADIUS clients')
    g.add_argument('--add-client', metavar='NAME', help='add (or change) a client: with '
                   '--address and --secret, and --realm for names that come without one')
    g.add_argument('--address', metavar='ADDR', help='an address or a range (10.0.0.0/24)')
    g.add_argument('--secret', metavar='TEXT', help='the shared secret')
    g.add_argument('--realm', metavar='REALM', help='the realm added to names without one')
    g.add_argument('--del-client', metavar='NAME', help='take a client away')
    g.add_argument('--realms', action='store_true', help='the realms')
    g.add_argument('--add-realm', metavar='NAME', help='add (or change) a realm: --suffix, '
                   '--directory, --lookup, --groups, --mode')
    g.add_argument('--suffix', metavar='TEXT', default=None, help='what follows the @ '
                   '(example.cz), * for every name, "" for names without one')
    g.add_argument('--directory', metavar='NAME', help='the directory to look people up in')
    g.add_argument('--lookup', choices=('upn', 'sam', 'none'), help='how names are looked up')
    g.add_argument('--groups', metavar='G1;G2', help='the groups, any one of which lets in')
    g.add_argument('--mode', choices=('otp', 'password_otp', 'password'),
                   help='what the password is: the code, the directory password followed by '
                        'the code, or the directory password alone')
    g.add_argument('--del-realm', metavar='NAME', help='take a realm away')
    g = p.add_argument_group('ACTIVE DIRECTORY')
    g.add_argument('--directories', action='store_true', help='the directories')
    g.add_argument('--add-directory', metavar='NAME', help='add (or change) one: --hosts, '
                   '--base, --bind-dn, --bind-pw, --tls, --port, --no-verify')
    g.add_argument('--hosts', metavar='H1,H2', help='its servers, in order')
    g.add_argument('--base', metavar='DN', help='where to look: DC=example,DC=local')
    g.add_argument('--bind-dn', metavar='WHO', help='the account it reads with')
    g.add_argument('--bind-pw', metavar='PASS', help='its password (or OTP_BIND_PW)')
    g.add_argument('--tls', choices=('ldaps', 'starttls', 'none'), help='how it is reached')
    g.add_argument('--port', type=int, metavar='N', help='its port')
    g.add_argument('--no-verify', action='store_true', help='do not check its certificate')
    g.add_argument('--ca', metavar='FILE', help='the certificate authority (PEM) that signed it')
    g.add_argument('--del-directory', metavar='NAME', help='take one away')
    g.add_argument('--directory-test', metavar='NAME', help='reach every server of it, step by '
                   'step')
    g.add_argument('--directory-user', nargs=2, metavar=('NAME', 'USER'),
                   help='what the directory says about one person, groups and all')
    g = p.add_argument_group('THE SETTINGS AND THE ACCOUNTS')
    g.add_argument('--settings', action='store_true', help='every setting, as it stands')
    g.add_argument('--set', action='append', metavar='KEY=VALUE', help='change one (again for '
                   'more)')
    g.add_argument('--users', action='store_true', help='who may open the administration pages')
    g.add_argument('--add-user', metavar='NAME', help='make an account (--role)')
    g.add_argument('--role', choices=ROLES_ALL, default=None, help='its role (with --add-user read-only when not given)')
    g.add_argument('--passwd', metavar='NAME', help='set or reset a password (OTP_PASSWORD '
                   'in the environment for a script)')
    g.add_argument('--set-role', metavar='NAME', help='change what an account may do (--role)')
    g.add_argument('--del-user', metavar='NAME', help='remove an account')
    g.add_argument('--disable-user', metavar='NAME', help='stop an account signing in')
    g.add_argument('--enable-user', metavar='NAME', help='let it sign in again')
    g.add_argument('--note', metavar='TEXT', default='', help='a note beside what is made')
    g = p.add_argument_group('THE DATABASE AND ISEMON')
    g.add_argument('--fill-names', action='store_true', help='every token without its owner\'s '
                   'name given it from the directory of its realm')
    g.add_argument('--backup', action='store_true', help='a copy of the database, now')
    g.add_argument('--restore', metavar='FILE', help='put a copy back (--yes)')
    g.add_argument('--tidy', action='store_true', help='delete what has been kept long enough')
    g.add_argument('--isemon-test', action='store_true', help='send one line to isemon’s '
                   'receivers and say what happened')
    g = p.add_argument_group('MAINTENANCE AND UPGRADES')
    g.add_argument('--maintenance', choices=('on', 'off', 'status'), help='this node out of '
                   'service (RADIUS not answered, /healthz 503) or back; status says which')
    g.add_argument('--node', metavar='NAME', help='with --maintenance: another node of the '
                   'cluster rather than this one')
    g.add_argument('--why', metavar='TEXT', help='with --maintenance on: why, for the events')
    g.add_argument('--upgrade-status', action='store_true', help='the package sent on the pages '
                   'and how an upgrade started there is going')
    g.add_argument('--rename-from-opt', action='store_true', help=argparse.SUPPRESS)
    g.add_argument('--upgrade-cancel', action='store_true', help='stop an upgrade started on '
                   'the pages: the nodes not yet begun stay as they are')
    g = p.add_argument_group('HIGH AVAILABILITY (TWO NODES, ONE POSTGRESQL)')
    g.add_argument('--ha-status', action='store_true', help='the nodes of the cluster and how '
                   'long since each was heard from')
    g.add_argument('--ha-setup', action='store_true', help='the wizard, on the first node (as '
                   'root): checks, opens PostgreSQL to the second node, writes the bundle')
    g.add_argument('--ha-bundle', metavar='FILE', help='only the bundle for the second node, '
                   'locked with a passphrase that is printed once')
    g.add_argument('--ha-join', metavar='FILE', help='on the second node (as root): join the '
                   'cluster the bundle came from')
    g.add_argument('--ha-peer', metavar='ADDRESS', help='the other node\'s address (for '
                   '--ha-setup)')
    g.add_argument('--ha-peer-port', type=int, metavar='N', default=None,
                   help='the other node\'s PostgreSQL port (5432)')
    g.add_argument('--ha-address', metavar='ADDRESS', help='this node\'s address as the other '
                   'reaches it (default: the one it uses to reach the outside)')
    g.add_argument('--ha-shared', action='store_true', help='with --ha-setup: both nodes open '
                   'one PostgreSQL elsewhere, instead of each its own, replicated')
    g.add_argument('--ha-pause', nargs='?', const='both', choices=('both', 'in', 'out'),
                   help='stop replicating for now (in: what this node takes, out: what the '
                   'other takes from it); it waits in the slot, up to %s' % HA_SLOT_KEEP)
    g.add_argument('--ha-resume', nargs='?', const='both', choices=('both', 'in', 'out'),
                   help='replicate again, from where it stopped')
    g.add_argument('--ha-stop', action='store_true', help='replication off for good: each node '
                   'goes on alone (--yes)')
    g.add_argument('--ha-resync', action='store_true', help='rebuild this node from the other: '
                   'its tables emptied and every row copied over')
    g.add_argument('--ha-compare', action='store_true', help='the rows of every table here and '
                   'on the other node, side by side: are they the same?')
    g.add_argument('--ha-renamed', metavar='OLD', help='this node was called OLD: what was '
                   'kept under that name (its own settings, maintenance, certificate, place in '
                   'the web address) carried to its name now, and OLD off the list')
    g.add_argument('--ha-forget', metavar='NAME', help='take a node off the list for good (one '
                   'that was removed or reinstalled under another name)')
    g.add_argument('--ha-standalone', action='store_true', help='leave the cluster and go on '
                   'alone, keeping everything: replication off, the other node forgotten, '
                   'config.json one server\'s again (--yes)')
    g.add_argument('--ha-db-host', metavar='HOST', help='the database\'s address as the other '
                   'node reaches it (default: this machine\'s)')
    g.add_argument('--node-name', metavar='NAME', help='this node\'s name (--ha-join, '
                   '--ha-setup)')
    g.add_argument('--trusted-proxy', action='append', metavar='CIDR', help='the load '
                   'balancer\'s address: nginx takes the client\'s from X-Forwarded-For when '
                   'it comes from there (again for more)')
    g = p.add_argument_group('TLS AND THE WEB ADDRESS (VIP)')
    g.add_argument('--web-status', action='store_true', help='the certificates of the nodes and '
                   'of the web address, their TLS settings, and where the address is')
    g.add_argument('--tls-for', metavar='TARGET', help='which: a node\'s name, or vip (the web '
                   'address) [this node]')
    g.add_argument('--tls-import', nargs='+', metavar='FILE', help='a certificate in: PEM '
                   'files (certificate, key, chain, root - in any order, or all in one) or a '
                   '.pfx / .p12; its password in OTP_TLS_PASSWORD')
    g.add_argument('--tls-preset', choices=['standard', 'intermediate', 'modern'],
                   help='the protocols and ciphers: standard (TLS 1.2+1.3, ECDHE), intermediate '
                   '(Mozilla, with DHE), modern (TLS 1.3 only)')
    g.add_argument('--tls-dh', choices=sorted(DH_WORDS), help='the DH parameters')
    g.add_argument('--tls-hsts', type=int, metavar='SECONDS', help='Strict-Transport-Security '
                   '(0 = none)')
    g.add_argument('--vip-set', metavar='ADDRESS/PREFIX', help='the web address (192.0.2.10/24), '
                   'with --vip-fqdn, --vip-vrid, --vip-iface')
    g.add_argument('--vip-fqdn', metavar='NAME', help='its host name')
    g.add_argument('--vip-vrid', type=int, metavar='N', help='its VRRP id, 1-255 [51]')
    g.add_argument('--vip-iface', action='append', metavar='NODE=IFACE', help='the interface '
                   'it goes on, on that node (again for the other; default: the one with the '
                   'node\'s address)')
    g.add_argument('--vip', choices=['on', 'off'], help='the web address on or off')
    g.add_argument('--vip-move', metavar='NODE', help='the web address to that node')
    g.add_argument('--vip-return', metavar='NODE|stay', help='where the web address goes back '
                   'to when it is well: a node (always back to it), or "stay" (it stays where it '
                   'is until that node fails or it is moved by hand)')
    g.add_argument('--web-retry', action='store_true', help='this node asks root again for what '
                   'failed')
    g.add_argument('--yes', action='store_true', help='do not ask')
    return p


HELP_EXAMPLES = [
    ('otp', 'what it is doing (the same as --status)'),
    ('otp --check', 'every part of it: the key, the copies, PHP, clients, realms, directories'),
    ('otp --enroll novak@example.cz', 'a token, with the QR code to scan off the terminal'),
    ('otp --radtest novak 123456', 'what radtest asks, from this machine'),
    ('otp --log --rejects', 'who was refused, and why'),
    ('otp --request 42', 'every step of one decision'),
    ("otp --add-client ASA --address 192.0.2.1 --secret 'something long' --realm example.cz", ''),
    ("otp --add-directory AD --hosts dc1.example.local,dc2.example.local \\\n"
     "    --base DC=example,DC=local --bind-dn otp@example.local --bind-pw '...'", ''),
    ("otp --add-realm example.cz --suffix example.cz --directory AD --lookup upn \\\n"
     "    --groups 'VPN_USERS;VPN_ADMINS'", ''),
    ('otp --import-legacy /root/old-otp', 'everything from a totpcgi + FreeRADIUS server'),
    ('otp --set isemon=1 --set isemon_targets=isemon.example.local:514/tcp', ''),
    ('otp --ha-setup --ha-peer 192.0.2.12', 'make this the first node of two; then copy the '
     'bundle over'),
    ('otp --ha-join /root/otp-join-otp1.json', 'on the second node: join'),
]



def become_service_user():
    """Run as the daemon's own account when started as root, so that nothing
    the command line writes - the database file and its journal, a copy, the
    key of the tokens - ends up root's and out of the daemon's reach."""
    if os.geteuid() != 0 or os.environ.get('OTP_STAY_ROOT'):
        return
    try:
        import pwd
        import grp
        pw = pwd.getpwnam(SERVICE_USER)
    except (KeyError, ImportError):
        return
    try:
        groups = [g.gr_gid for g in grp.getgrall() if SERVICE_USER in g.gr_mem]
        os.setgroups(sorted(set(groups + [pw.pw_gid])))
        os.setgid(pw.pw_gid)
        os.setuid(pw.pw_uid)
    except OSError as e:
        sys.stderr.write('otp: could not become %s (%s); going on as root\n' % (SERVICE_USER, e))


def chown_to_service(path, mode=None):
    """A file root just wrote, given to the daemon's account."""
    if os.geteuid() != 0:
        return
    try:
        import pwd
        pw = pwd.getpwnam(SERVICE_USER)
        os.chown(str(path), pw.pw_uid, pw.pw_gid)
        if mode is not None:
            os.chmod(str(path), mode)
    except (KeyError, OSError, ImportError):
        pass


NGINX_CONF_PATHS = ('/etc/nginx/conf.d/otp.conf', '/etc/nginx/sites-enabled/otp.conf',
                    '/etc/nginx/sites-available/otp.conf')


def nginx_trusted_proxies(cidrs, pal):
    """The load balancer's addresses into nginx: the client's own address is
    then taken from X-Forwarded-For when a request comes from one of them -
    for the allow lists, the sign-in throttle and every log."""
    conf = next((p for p in NGINX_CONF_PATHS if os.path.exists(p)), None)
    if not conf:
        print(pal.bad_line('no nginx configuration of otp was found (%s)'
                           % ', '.join(NGINX_CONF_PATHS)))
        return False
    for c in cidrs:
        address_net(c)
    text = Path(conf).read_text()
    block = ('    # REALIP-BEGIN - the load balancer(s), written by otp --trusted-proxy\n'
             + ''.join('    set_real_ip_from %s;\n' % c for c in cidrs)
             + ('    real_ip_header X-Forwarded-For;\n    real_ip_recursive on;\n' if cidrs else '')
             + '    # REALIP-END\n')
    if '# REALIP-BEGIN' in text:
        text = re.sub(r'    # REALIP-BEGIN.*?# REALIP-END\n', lambda m: block, text, flags=re.S)
    else:
        # ...in the HTTPS server, which is the one with the pages - not the
        # first block in the file, which is the port-80 redirect. The block
        # whose `listen` names 443 is the one; failing that, the last one.
        heads = list(re.finditer(r'server\s*\{[^\n]*\n', text))
        if not heads:
            print(pal.bad_line('no server block was found in %s' % conf))
            return False
        chosen = heads[-1]
        for i, h in enumerate(heads):
            end = heads[i + 1].start() if i + 1 < len(heads) else len(text)
            if re.search(r'^\s*listen\s[^;]*\b443\b', text[h.end():end], re.M):
                chosen = h
                break
        text = text[:chosen.end()] + block + text[chosen.end():]
    Path(conf + '.before-realip').write_text(Path(conf).read_text())
    Path(conf).write_text(text)
    got = subprocess.run(['nginx', '-t'], capture_output=True, text=True)
    if got.returncode != 0:
        Path(conf).write_text(Path(conf + '.before-realip').read_text())
        print(pal.bad_line('nginx did not take it, so it was put back: %s'
                           % (got.stderr.strip().split('\n')[-1])))
        return False
    subprocess.run(['systemctl', 'reload', 'nginx'], capture_output=True)
    print(pal.ok_line('nginx takes the client\'s address from X-Forwarded-For when it comes '
                      'from %s' % ', '.join(cidrs) if cidrs else 'nginx trusts no proxy'))
    return True


def cli_ha(args, pal):
    """The high-availability wizard and its parts, as root."""
    def ask(prompt, default=''):
        if args.yes or not sys.stdin.isatty():
            return default
        got = input('%s%s: ' % (prompt, ' [%s]' % default if default else '')).strip()
        return got or default

    if os.geteuid() != 0 and (args.ha_setup or args.ha_join or args.trusted_proxy):
        raise SystemExit('otp: run this as root - it changes PostgreSQL, nginx and the key '
                         'of the tokens')
    os.environ['OTP_STAY_ROOT'] = '1'
    load_config(saved=None)
    if args.trusted_proxy and not (args.ha_setup or args.ha_join):
        return 0 if nginx_trusted_proxies(args.trusted_proxy, pal) else 1

    if args.ha_join:
        try:
            bundle = Path(args.ha_join).read_text()
        except OSError as e:
            raise SystemExit('otp: %s' % e)
        phrase = os.environ.get('OTP_HA_PASSPHRASE') or getpass.getpass(
            'The passphrase printed with the bundle: ')
        try:
            data = bundle_open(bundle, phrase)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        peer = data.get('peer') or {}
        if data.get('mode') == 'replicated':
            return cli_ha_join_replicated(args, pal, data, ask)
        print(pal.head('joining the cluster of %s' % (peer.get('name') or '?'))
              + pal.dim('  (%s)' % db_where(data['db'])))
        name = args.node_name or ask('This node\'s name', socket.gethostname().split('.')[0])
        try:
            store0 = Storage(open_db())
            HA_STORE['store'] = store0
        except Exception:                               # noqa: BLE001
            pass
        try:
            got = ha_join(data, name, even_if_data=args.yes)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        chown_to_service(sealing_key_path(), 0o600)
        chown_to_service(CONFIG_FILE, 0o640)
        print(pal.ok_line('the database: %s (%s record(s) in it)' % (got['where'], got['rows'])))
        print(pal.ok_line('the key that opens the tokens is the cluster\'s'))
        if args.trusted_proxy:
            nginx_trusted_proxies(args.trusted_proxy, pal)
        if not os.environ.get('OTP_HA_NO_RESTART'):
            subprocess.run(['systemctl', 'restart', 'otp'], capture_output=True)
            print(pal.ok_line('otp started again on it as %s' % name))
        print(pal.dim('  Both nodes are in the list:  otp --ha-status'))
        print(pal.dim('  Sign in with the accounts of the cluster - the ones of this node were '
                      'in its own database, which is no longer used.'))
        return 0

    if args.ha_resync:
        return cli_ha_resync(args, pal)
    if args.ha_standalone:
        return cli_ha_standalone(args, pal)
    # --ha-setup and --ha-bundle: the first node.
    store = Storage(open_db())
    load_config(saved=store.settings_saved())
    HA_STORE['store'] = store
    host0 = str(CONFIG.get('db_host') or '')
    if store.db.engine == 'postgres' and host0 in ('', 'localhost', '127.0.0.1', '::1') \
            and not args.ha_shared and (args.ha_setup or CONFIG.get('ha_mode') == 'replicated'):
        return cli_ha_setup_replicated(args, pal, store, ask)
    print(pal.head('high availability - the first node') + pal.dim('  (%s)' % node_name()))
    bad = False
    for c in ha_checks(store):
        if c['ok'] and not c.get('warn'):
            print(pal.ok_line(c['says']))
        elif c.get('warn'):
            print(pal.warn_line(c['says']))
        else:
            print(pal.bad_line(c['says']))
            bad = True
    if bad:
        return 1
    host = str(CONFIG.get('db_host') or '')
    local = host in ('', 'localhost', '127.0.0.1', '::1')
    db_host = args.ha_db_host or (node_address() if local else host)
    if args.ha_setup:
        peer = args.ha_peer or ask('The other node\'s address')
        if local:
            if not peer:
                raise SystemExit('otp: the other node\'s address is needed: --ha-peer ADDRESS')
            try:
                peer_address(peer)
            except ValueError as e:
                raise SystemExit('otp: %s' % e)
            try:
                for line in pg_open_to(peer, CONFIG.get('db_name'), CONFIG.get('db_user')):
                    print(pal.ok_line('PostgreSQL: %s' % line))
            except ValueError as e:
                raise SystemExit('otp: PostgreSQL could not be opened to %s: %s' % (peer, e))
            if True:
                listen = pg_local_admin('SELECT pending_restart FROM pg_settings WHERE '
                                        "name = 'listen_addresses'")
                if listen == 't':
                    unit = tune_restart_unit() or 'postgresql'
                    if args.yes or ask('PostgreSQL has to start again to listen on the network '
                                       '- restart %s now? (yes/no)' % unit, 'yes') == 'yes':
                        subprocess.run(['systemctl', 'restart', unit], capture_output=True)
                        print(pal.ok_line('%s started again' % unit))
                    else:
                        print(pal.bad_line('restart %s before the other node joins' % unit))
            firewall_peer(peer, pal, 5432)
        if args.trusted_proxy:
            nginx_trusted_proxies(args.trusted_proxy, pal)
        name = args.node_name
        if name and name != node_name():
            write_file_settings({'node_name': name})
            chown_to_service(CONFIG_FILE, 0o640)
    data = ha_bundle_data(store, db_host)
    phrase = ha_passphrase()
    target = Path(args.ha_bundle or '/root/otp-join-%s.json' % node_name())
    target.write_text(json.dumps(bundle_lock(data, phrase), indent=1) + '\n')
    os.chmod(str(target), 0o600)
    store.add_event('settings', 'a bundle for a second node was made on the command line '
                    '(the database at %s)' % db_host, 'warn', who='command line')
    print('')
    print(pal.ok_line('the bundle for the second node: %s' % target))
    print('  ' + pal.bold('its passphrase, shown only now: ') + pal.info(phrase))
    print('')
    print(pal.head('on the second node'))
    print('  1. install the same version:   ./install.sh --with-db postgres --yes')
    print('  2. copy the bundle over:       scp %s root@SECOND:/root/' % target)
    print('  3. join:                       otp --ha-join /root/%s' % target.name)
    print('')
    print(pal.head('in front of both'))
    print('  HTTPS: round robin, no stickiness needed; health check  GET /healthz  (200 = up).')
    print('  RADIUS: give the VPN both nodes as servers (or balance UDP 1812/1813 to both).')
    print('  The load balancer\'s address on both nodes:  otp --trusted-proxy CIDR')
    return 0


def firewall_peer(peer, pal, port=5432):
    """firewalld letting the other node - one address - reach PostgreSQL."""
    if shutil.which('firewall-cmd'):
        a = peer_address(peer)
        rule = ('rule family="%s" source address="%s/%d" port port="%d" protocol="tcp" accept'
                % ('ipv4' if a.version == 4 else 'ipv6', a, 32 if a.version == 4 else 128,
                   port))
        subprocess.run(['firewall-cmd', '--permanent', '--add-rich-rule=' + rule],
                       capture_output=True)
        subprocess.run(['firewall-cmd', '--reload'], capture_output=True)
        print(pal.ok_line('firewalld lets %s reach PostgreSQL (TCP %d)' % (peer, port)))


def cli_ha_setup_replicated(args, pal, store, ask):
    """The first node of two, each with its own PostgreSQL, replicating."""
    say = lambda t: print(pal.ok_line(t))
    print(pal.head('high availability - the first node, replicated') + pal.dim(
        '  (%s: a PostgreSQL on each node, replicating both ways)' % node_name()))
    peer = args.ha_peer or CONFIG.get('ha_peer') or ask('The other node\'s address')
    if not peer:
        raise SystemExit('otp: the other node\'s address is needed: --ha-peer ADDRESS')
    try:
        peer_address(peer)
    except ValueError as e:
        raise SystemExit('otp: %s' % e)
    port = int(CONFIG.get('db_port') or 5432)
    name, user, pw = CONFIG.get('db_name'), CONFIG.get('db_user'), CONFIG.get('db_password')
    try:
        restart, major = pg_prepare_local(port, peer, name, user, pw, say)
        if restart:
            if args.yes or ask('PostgreSQL has to start again for this (wal_level = logical, '
                               'listening on the network) - restart it now? (yes/no)',
                               'yes') == 'yes':
                pg_restart_local(port)
                say('PostgreSQL started again')
                store.db.close()
                store.db.connect()
            else:
                raise SystemExit('otp: restart PostgreSQL, then run this again')
        pg_publication(port, name)
        say('PostgreSQL publishes every table of %s (inserts, updates, deletes)' % name)
        ha_sequences(store.db, 1)
        say('this node numbers its rows odd, the other even - they never collide')
    except ValueError as e:
        raise SystemExit('otp: %s' % e)
    firewall_peer(peer, pal, port)
    if args.trusted_proxy:
        nginx_trusted_proxies(args.trusted_proxy, pal)
    me = args.ha_address or CONFIG.get('ha_address') or node_address()
    changes = {'ha_mode': 'replicated', 'ha_slot': 1, 'ha_peer': peer,
               'ha_peer_port': int(args.ha_peer_port or 5432), 'ha_address': me}
    if args.node_name:
        changes['node_name'] = args.node_name
    write_file_settings(changes)
    chown_to_service(CONFIG_FILE, 0o640)
    load_config(saved=store.settings_saved())
    data = {'mode': 'replicated', 'key': sealing_key().hex(), 'pg_major': major, 'slot': 2,
            'db': {'db_name': name, 'db_user': user, 'db_password': pw},
            'peer': {'name': node_name(), 'address': me, 'port': port, 'slot': 1},
            'cluster': CONFIG.get('site_name') or 'otp'}
    phrase = ha_passphrase()
    target = Path(args.ha_bundle or '/root/otp-join-%s.json' % node_name())
    target.write_text(json.dumps(bundle_lock(data, phrase), indent=1) + '\n')
    os.chmod(str(target), 0o600)
    store.add_event('settings', 'this node became the first of two, replicating with %s; a '
                    'bundle for the second was made on the command line' % peer, 'warn',
                    who='command line')
    if not os.environ.get('OTP_HA_NO_RESTART'):
        subprocess.run(['systemctl', 'restart', 'otp'], capture_output=True)
    print('')
    say('the bundle for the second node: %s' % target)
    print('  ' + pal.bold('its passphrase, shown only now: ') + pal.info(phrase))
    print('')
    print(pal.head('on the second node (%s)' % peer))
    print('  1. install the same version:   ./install.sh --with-db postgres --yes')
    print('  2. copy the bundle over:       scp %s root@%s:/root/' % (target, peer))
    print('  3. join:                       otp --ha-join /root/%s --node-name NAME' % target.name)
    print('     It installs PostgreSQL %d there if it is missing, copies every row from this '
          'node' % major)
    print('     and sets both directions of the replication up. The same command rebuilds it '
          'after a reinstall.')
    return 0


def cli_ha_join_replicated(args, pal, data, ask):
    say = lambda t: print(pal.ok_line(t))
    peer = data.get('peer') or {}
    db = data.get('db') or {}
    name, user, pw = db.get('db_name'), db.get('db_user'), db.get('db_password')
    print(pal.head('joining %s - a PostgreSQL on each node, replicating both ways'
                   % (peer.get('name') or '?')))
    node = args.node_name or ask('This node\'s name', socket.gethostname().split('.')[0])
    port = int(FILE_CONFIG.get('db_port') or 5432) if FILE_CONFIG.get('db_engine') == 'postgres' \
        else 5432
    try:
        if not pg_local_running(port):
            pg_install_local(int(data.get('pg_major') or 16), say)
        restart, major = pg_prepare_local(port, peer['address'], name, user, pw, say)
        if restart:
            pg_restart_local(port)
            say('PostgreSQL started again')
        firewall_peer(peer['address'], pal, port)
        local = db_open({'db_engine': 'postgres', 'db_host': '127.0.0.1', 'db_port': port,
                         'db_name': name, 'db_user': user, 'db_password': pw})
        local.make_tables()
        local.add_missing_columns()
        pg_publication(port, name)
        remote = db_open({'db_engine': 'postgres', 'db_host': peer['address'],
                          'db_port': int(peer.get('port') or 5432), 'db_name': name,
                          'db_user': user, 'db_password': pw})
        me = args.ha_address or node_address()
        got = ha_rebuild(local, remote, int(data.get('slot') or 2), int(peer.get('slot') or 1),
                         me, port, peer['address'], int(peer.get('port') or 5432),
                         name, user, pw, lambda t: print(pal.dim('  ' + t)))
        remote.close()
        local.close()
    except (ValueError, DbError) as e:
        raise SystemExit('otp: %s' % e)
    now = sealing_key()
    if now and now.hex() != data['key']:
        write_replacing(sealing_key_path().with_name('secrets.key.before-join'), now.hex() + '\n',
                        0o600)
    write_replacing(sealing_key_path(), data['key'] + '\n', 0o600)
    chown_to_service(sealing_key_path(), 0o600)
    write_file_settings({'db_engine': 'postgres', 'db_host': '127.0.0.1', 'db_port': port,
                         'db_name': name, 'db_user': user, 'db_password': pw,
                         'node_name': node, 'ha_mode': 'replicated',
                         'ha_slot': int(data.get('slot') or 2), 'ha_peer': peer['address'],
                         'ha_peer_port': int(peer.get('port') or 5432), 'ha_address': me})
    chown_to_service(CONFIG_FILE, 0o640)
    say('every row of %s is here: %d' % (peer.get('name') or 'the other node', got['rows']))
    say('both directions replicate: this node -> %s and %s -> this node'
        % (peer.get('name'), peer.get('name')))
    if args.trusted_proxy:
        nginx_trusted_proxies(args.trusted_proxy, pal)
    if not os.environ.get('OTP_HA_NO_RESTART'):
        subprocess.run(['systemctl', 'restart', 'otp'], capture_output=True)
        say('otp started again as %s, on its own PostgreSQL' % node)
    print(pal.dim('  otp --ha-status shows both nodes and both directions.'))
    return 0


def cli_ha_resync(args, pal):
    load_config(saved=None)
    if CONFIG.get('ha_mode') != 'replicated':
        raise SystemExit('otp: this node does not replicate (ha_mode is not "replicated")')
    if not args.yes:
        raise SystemExit('otp: this empties this node\'s tables and copies every row from '
                         '%s - again with --yes' % CONFIG.get('ha_peer'))
    # The daemon stopped while the rows come over (1.0.47): it is another
    # process, and its heartbeat written meanwhile met the same row coming
    # from the other node - the copy stopped there for good.
    stopped = False
    if os.geteuid() == 0 and not os.environ.get('OTP_HA_NO_RESTART') and \
            subprocess.run(['systemctl', 'is-active', '--quiet', 'otp']).returncode == 0:
        subprocess.run(['systemctl', 'stop', 'otp'], capture_output=True)
        stopped = True
        print(pal.dim('  otp is stopped on this node while it is rebuilt (the other node answers)'))
    try:
        local = open_db()
        # What is here kept first, as the pages do (1.0.47): a rebuild
        # replaces all of it.
        try:
            kept = make_backup(Storage(local), 'before this node was rebuilt from the other, '
                               'on the command line')
            print(pal.ok_line('a copy of what was here: %s' % kept))
        except Exception as e:                          # noqa: BLE001
            raise SystemExit('otp: no copy of what is here could be made, so nothing was '
                             'changed: %s' % e)
        remote = ha_peer_db()
        got = ha_rebuild(local, remote, int(CONFIG.get('ha_slot') or 2),
                         3 - int(CONFIG.get('ha_slot') or 2),
                         CONFIG.get('ha_address') or node_address(),
                         int(CONFIG.get('db_port') or 5432), CONFIG.get('ha_peer'),
                         int(CONFIG.get('ha_peer_port') or 5432), CONFIG.get('db_name'),
                         CONFIG.get('db_user'), CONFIG.get('db_password'),
                         lambda t: print(pal.dim('  ' + t)))
    except (ValueError, DbError) as e:
        raise SystemExit('otp: %s' % e)
    finally:
        if stopped:
            subprocess.run(['systemctl', 'start', 'otp'], capture_output=True)
            print(pal.dim('  otp is started again on this node'))
    print(pal.ok_line('rebuilt from %s: %d row(s)' % (CONFIG.get('ha_peer'), got['rows'])))
    return 0


def cli_ha_standalone(args, pal):
    """This node out of the cluster, on its own, with everything it has
    (1.0.47): the replication taken away (as --ha-stop), what is left of it
    in this PostgreSQL removed, the other nodes forgotten, and config.json
    a single server's again. The database, the key, the settings, the
    tokens and the accounts stay as they are."""
    if os.geteuid() != 0:
        raise SystemExit('otp: run this as root - it writes config.json and restarts otp')
    if not CONFIG.get('ha_mode') and not args.yes:
        raise SystemExit('otp: this node is not one of a cluster (ha_mode is empty)')
    if not args.yes:
        raise SystemExit('otp: this takes this node out of the cluster for good: the replication '
                         'goes, the other node is forgotten, and it answers alone with what it '
                         'has - again with --yes')
    say = lambda t: print(pal.ok_line(t))
    try:
        store = Storage(open_db())
    except DbError as e:
        raise SystemExit('otp: %s' % e)
    load_config(saved=store.settings_saved())
    HA_STORE['store'] = store
    mode = CONFIG.get('ha_mode') or ''
    if mode == 'replicated' and store.db.engine == 'postgres':
        try:
            say(ha_control(store, 'stop', by='command line')['message'])
        except Exception as e:                          # noqa: BLE001
            print(pal.warn_line('the replication: %s' % str(e).split('\n')[0][:200]))
        # Whatever is left of it here - the other node gone for good, or
        # names from before - taken away too.
        for r in store.db.rows("SELECT subname FROM pg_subscription WHERE subname LIKE "
                               "'o__!_from!_%' ESCAPE '!'"):
            ha_drop_sub(store.db, r['subname'])
            say('the subscription %s is gone' % r['subname'])
        for r in store.db.rows("SELECT slot_name FROM pg_replication_slots WHERE slot_name "
                               "LIKE 'o__!_from!_%' ESCAPE '!'"):
            try:
                _ha_drop_slot(store.db, r['slot_name'])
                say('the replication slot %s is gone (nothing is kept for the other node '
                    'any more)' % r['slot_name'])
            except Exception as e:                      # noqa: BLE001
                print(pal.warn_line('the slot %s: %s' % (r['slot_name'], e)))
    for n in ha_nodes(store):
        if n['me']:
            continue
        ha_forget(store, n['name'])
        store.db.run('DELETE FROM meta WHERE k IN (?, ?)',
                     ('maint:' + n['name'], 'upgrade:node:' + n['name']))
        say('%s is off the list of nodes' % n['name'])
    write_file_settings({'ha_mode': '', 'ha_slot': 0, 'ha_peer': '', 'ha_address': '',
                         'ha_peer_port': DEFAULTS.get('ha_peer_port')})
    chown_to_service(CONFIG_FILE, 0o640)
    say('%s: a single server again (the database, the key and the node\'s name are kept)'
        % CONFIG_FILE)
    store.add_event('settings', '%s left the cluster on the command line and answers alone'
                    % node_name(), 'warn', who='command line')
    store.db.close()
    if not os.environ.get('OTP_HA_NO_RESTART'):
        subprocess.run(['systemctl', 'restart', 'otp'], capture_output=True)
        say('otp started again, alone')
    if mode == 'shared':
        print(pal.warn_line('the other node still opens the same database: stop it or '
                            'uninstall it there, or it goes on answering from it'))
    print(pal.dim('  The other node, if it still runs: otp --ha-standalone --yes there too, '
                  'or uninstall it.'))
    return 0


def cli_ha_compare(store, pal, as_json=False):
    """Every table counted here and on the other node (1.0.47)."""
    if CONFIG.get('ha_mode') != 'replicated':
        raise SystemExit('otp: this node does not replicate (ha_mode is %r) - with one shared '
                         'database there is nothing to compare' % (CONFIG.get('ha_mode') or ''))
    try:
        far = ha_peer_db()
    except Exception as e:                              # noqa: BLE001
        raise SystemExit('otp: the other node\'s PostgreSQL cannot be reached: %s'
                         % str(e).split('\n')[0][:200])
    rows, same = [], True
    try:
        for t in TABLES:
            if t == 'meta':
                q = ("SELECT COUNT(*) FROM meta WHERE " + ' AND '.join(
                    "k NOT LIKE '%s%%'" % p for p in META_TRANSIENT))
                here_n, there_n = store.db.value(q), far.value(q)
                here_m = there_m = None
            else:
                here_n = store.db.value('SELECT COUNT(*) FROM %s' % t)
                there_n = far.value('SELECT COUNT(*) FROM %s' % t)
                if 'id' in [c.lower() for c in store.db.columns(t)]:
                    here_m = store.db.value('SELECT MAX(id) FROM %s' % t)
                    there_m = far.value('SELECT MAX(id) FROM %s' % t)
                else:
                    here_m = there_m = None
            ok = int(here_n or 0) == int(there_n or 0) and here_m == there_m
            same = same and ok
            rows.append((t, here_n, there_n, here_m, there_m, ok))
    finally:
        far.close()
    if as_json:
        print(json.dumps({'same': same, 'tables': [dict(zip(
            ('table', 'here', 'there', 'max_id_here', 'max_id_there', 'same'), r))
            for r in rows]}, default=str))
        return 0 if same else 4
    print(table([(t, str(a), str(b), str(c if c is not None else '-'),
                  str(d if d is not None else '-'), 'same' if ok else 'DIFFERENT')
                 for t, a, b, c, d, ok in rows],
                ['table', 'rows here (%s)' % node_name(), 'rows there', 'last id here',
                 'last id there', '']))
    if same:
        print(pal.ok_line('both nodes hold the same rows'))
    else:
        print(pal.warn_line('they differ. A moment after a change that is normal (the logs '
                            'grow on both): ask again in a few seconds. If it stays so, see '
                            'otp --ha-status; the node that was away is rebuilt with '
                            'otp --ha-resync --yes ON THAT NODE.'))
    return 0 if same else 4


def cli_web(args, pal, store):
    """TLS and the web address on the command line (1.0.47)."""
    who = 'command line'
    me = node_name()
    target = args.tls_for or me
    if (args.tls_import or args.tls_preset or args.tls_dh or args.tls_hsts is not None) and \
            target not in tls_targets(store):
        raise ValueError('there is no node or address called %s (a node\'s name, or vip)'
                         % target)
    said = []
    if args.tls_import:
        pem, pfx = '', b''
        for raw in args.tls_files:
            if b'-----BEGIN' in raw:
                pem += raw.decode('utf-8', 'replace') + '\n'
            else:
                if pfx:
                    raise ValueError('one .pfx / .p12 at a time')
                pfx = raw
        prof = tls_profile(store, target) or {}
        pending = unseal_secret(prof['pending_key'], 'web:tls') if prof.get('pending_key') else ''
        got = cert_bundle(cert=pem, pfx=pfx, password=os.environ.get('OTP_TLS_PASSWORD', ''),
                          pending_key=pending)
        prof.update(cert=got['cert'], chain=got['chain'], root=got['root'],
                    key=seal_secret(got['key'], 'web:tls'), info=got['info'],
                    chain_info=got['chain_info'], root_info=got['root_info'],
                    verify=got['verify'], how='imported on the command line')
        prof.pop('pending_key', None)
        prof.pop('csr', None)
        prof.setdefault('preset', 'standard')
        prof.setdefault('dh', 'none')
        tls_save(store, target, prof, who)
        i = got['info']
        said.append('%s: %s, until %s, %d in the chain, root %s%s' % (
            target, i.get('subject'), stamp(i.get('not_after')), len(got['chain_info']),
            'given' if got['root'] else 'not given',
            ', chain checked' if got['verify'] == 'ok' else
            (' - the chain does not check: %s' % got['verify'] if got['verify'] else '')))
        store.add_event('settings', 'a certificate was put in for %s on the command line: %s'
                        % (target, i.get('subject')), 'warn', who=who)
    if args.tls_preset or args.tls_dh or args.tls_hsts is not None:
        prof = tls_profile(store, target) or {}
        pol = tls_policy_checked({'preset': args.tls_preset or prof.get('preset') or 'standard',
                                  'protocols': prof.get('protocols'),
                                  'ciphers': prof.get('ciphers'),
                                  'dh': args.tls_dh or prof.get('dh') or 'none',
                                  'prefer': prof.get('prefer'),
                                  'hsts': args.tls_hsts if args.tls_hsts is not None
                                  else prof.get('hsts') or 0})
        prof.update(pol)
        tls_save(store, target, prof, who)
        said.append('%s: %s, DH %s, HSTS %s' % (target, pol['preset'], pol['dh'],
                                               pol['hsts'] or 'off'))
    if args.vip_set or args.vip or args.vip_move or args.vip_return:
        if not CONFIG.get('ha_mode'):
            raise ValueError('the web address is for a cluster: otp --ha-setup first')
    if args.vip_set:
        v = vip_conf(store)
        ifaces = dict(v.get('ifaces') or {})
        for one in args.vip_iface or []:
            if '=' not in one:
                raise ValueError('--vip-iface NODE=IFACE')
            k, val = one.split('=', 1)
            ifaces[k.strip()] = val.strip()
        got = vip_checked({'address': args.vip_set, 'fqdn': args.vip_fqdn
                           if args.vip_fqdn is not None else v.get('fqdn'),
                           'vrid': args.vip_vrid or v.get('vrid') or 51, 'ifaces': ifaces},
                          store)
        vip_set(store, who, **got)
        said.append('the web address: %s%s, VRRP id %d' % (
            got['address'], ' (%s)' % got['fqdn'] if got['fqdn'] else '', got['vrid']))
    if args.vip:
        v = vip_conf(store)
        if args.vip == 'on' and not v.get('address'):
            raise ValueError('give the address first: --vip-set 192.0.2.10/24')
        vip_set(store, who, on=args.vip == 'on')
        store.add_event('settings', 'the web address was turned %s on the command line'
                        % args.vip, 'warn', who=who)
        said.append('the web address is %s' % args.vip)
    if args.vip_return:
        if args.vip_return == 'stay':
            vip_set(store, who, mode='stays')
            said.append('the web address stays where it is: it moves only when that node fails '
                        'or by hand')
        else:
            if args.vip_return not in {n['name'] for n in ha_nodes(store)}:
                raise ValueError('there is no node called %s' % args.vip_return)
            vip_set(store, who, mode='back', prefer=args.vip_return)
            said.append('the web address always goes back to %s' % args.vip_return)
        store.add_event('settings', 'the web address: %s, on the command line' % said[-1],
                        'warn', who=who)
    if args.vip_move:
        names = {n['name']: n for n in ha_nodes(store)}
        if args.vip_move not in names:
            raise ValueError('there is no node called %s' % args.vip_move)
        if vip_conf(store).get('mode') == 'stays':
            vip_set(store, who, move_to=args.vip_move, move_at=time.time())
        else:
            vip_set(store, who, prefer=args.vip_move)
        store.add_event('settings', 'the web address was moved to %s on the command line'
                        % args.vip_move, 'warn', who=who)
        said.append('the web address goes to %s (when it is healthy)' % args.vip_move)
    if args.web_retry:
        store.set_meta('web:retry:' + me, str(time.time()))
        said.append('%s asks root again' % me)
    for w in said:
        print(pal.ok_line(w))
    if said:
        print(pal.dim('  each node puts it in within a few seconds: otp --web-status'))
        return 0
    # --web-status
    v = vip_conf(store)
    beats = {n['name']: n for n in ha_nodes(store)}
    if args.json:
        print(json.dumps({'vip': v, 'nodes': {k: (b.get('web') if not b['me'] else web_state(store))
                                               for k, b in beats.items()},
                          'tls': {t: tls_view(tls_profile(store, t)) for t in tls_targets(store)}},
                         default=str))
        return 0
    print(pal.head('the web address (VIP)'))
    if not CONFIG.get('ha_mode'):
        print(pal.dim('  one server: no web address (it is for a cluster)'))
    elif not v.get('address'):
        print(pal.dim('  not set: otp --vip-set 192.0.2.10/24 --vip-fqdn otp.example.cz'))
    else:
        print('  %s%s, VRRP id %s, %s, meant to be on %s' % (
            v['address'], ' (%s)' % v['fqdn'] if v.get('fqdn') else '', v.get('vrid') or 51,
            pal.good('ON') if v.get('on') else pal.dim('off'), vip_prefer(store, v)))
    for name, b in sorted(beats.items()):
        # What the daemons said in their heartbeats - not this command's own
        # look, which knows nothing of the daemon's health checks.
        w = b.get('web') or {}
        line = '%-16s %s' % (name, 'HOLDS THE ADDRESS' if w.get('vip_here') else
                             (w.get('role') or '-'))
        hl = w.get('health') or {}
        if v.get('on'):
            line += '  health: %s' % ('ok' if hl.get('ok') else 'NOT OK - %s' % (hl.get('why') or '?'))
        line += '  root: %s%s' % (w.get('state') or 'nothing asked yet',
                                  '' if w.get('current') or not w.get('state') else ' (not current)')
        print(('  ' + line) if b.get('alive') else pal.bad_line(line + ' (not answering)'))
        for s in (w.get('said') or [])[-3:]:
            print(pal.dim('      ' + s))
    print(pal.head('TLS'))
    for t in tls_targets(store):
        prof = tls_profile(store, t)
        b = beats.get(t, {})
        now = (b.get('web') or {}).get('cert_now') if t != 'vip' else None
        if t == me:
            now = web_state(store).get('cert_now')
        i = (prof or {}).get('info') or now or {}
        left = (float(i['not_after']) - time.time()) / 86400 if i.get('not_after') else None
        print('  %-16s %s%s' % (t, i.get('subject') or pal.dim('no certificate of its own'),
                                ', until %s (%d days)' % (stamp(i['not_after']), left)
                                if left is not None else ''))
        if prof:
            print(pal.dim('                   %s, DH %s%s%s' % (
                prof.get('preset') or 'standard', prof.get('dh') or 'none',
                ', HSTS %s s' % prof['hsts'] if prof.get('hsts') else '',
                ', a request waits for its certificate' if prof.get('pending_key') else '')))
        elif t != 'vip':
            print(pal.dim('                   as install.sh made it (otp does not look after it)'))
    return 0


def cli_store():
    become_service_user()
    load_config(saved=None)
    try:
        db = open_db()
    except DbError as e:
        raise SystemExit('otp: %s' % e)
    store = Storage(db)
    load_config(saved=store.settings_saved())
    return store


def bump(store):
    store.set_meta('conf_serial', '%.6f:%s' % (time.time(), node_name()))


def cli_main(argv=None):
    global _LOG_TO_STDERR
    said = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    pal = Palette(colour_wanted(any(x in ('--no-color', '--no-colour') for x in said))
                  and '--json' not in said)
    parser.palette = pal
    args = parser.parse_args(argv)
    if args.help:
        sys.stdout.write(parser.format_help())
        return 0
    if args.version:
        print('%s %s%s' % (pal.head('otp'), pal.bold(__version__), '' if HAVE_COLORAMA
                           else pal.dim('  (colorama is not installed; colour is written by '
                                        'hand)')))
        return 0
    global CONFIG_FILE
    if args.config:
        CONFIG_FILE = Path(args.config)
    if args.debug:
        FROM_ARGV['debug'] = True
    acted = any(v not in (None, False, [], '') for k, v in vars(args).items()
                if k not in ('no_color', 'json', 'debug', 'config', 'limit', 'hours', 'search',
                             'role', 'note', 'yes', 'replace', 'invert', 'pending', 'no_qr',
                             'rejects', 'suffix'))
    if args.daemon:
        return run_daemon()
    if not acted:
        # Nothing asked for. Under systemd (or anything else that is not a
        # person at a terminal) that is the daemon, as it always was; typed by
        # somebody, it is the question they meant - what is it doing - and
        # never a second daemon beside the one that is running.
        if os.environ.get('INVOCATION_ID') or not sys.stdin.isatty():
            return run_daemon()
        args.status = True
        acted = True
        if not args.json:
            print(pal.dim('(otp --help for everything it does; the daemon itself is '
                          'systemctl status otp)'))
    _LOG_TO_STDERR = False
    if args.rename_from_opt:
        return rename_from_opt(lambda words: print(pal.ok_line(words)))
    if args.ha_setup or args.ha_join or args.ha_bundle or args.trusted_proxy or args.ha_resync \
            or args.ha_standalone:
        return cli_ha(args, pal)
    # Read as whoever typed it, before the service's account takes over
    # (1.0.47): a certificate in root's folder is not the otp account's to read.
    args.tls_files = []
    for f in args.tls_import or []:
        try:
            args.tls_files.append(Path(f).read_bytes())
        except OSError as e:
            raise SystemExit('otp: %s' % e)
    store = cli_store()
    if args.ha_compare:
        return cli_ha_compare(store, pal, args.json)
    if args.web_status or args.tls_import or args.tls_preset or args.tls_dh or \
            args.tls_hsts is not None or args.vip_set or args.vip or args.vip_move or args.vip_return or \
            args.web_retry:
        try:
            return cli_web(args, pal, store)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
    if args.ha_renamed:
        said = node_carry(store, args.ha_renamed.strip(), node_name(), by='command line')
        try:
            NODE_NAME_FILE.write_text(node_name() + '\n')
        except OSError:
            pass
        print(pal.ok_line('%s is now %s; carried over: %s' % (
            args.ha_renamed, node_name(), ', '.join(said) or 'nothing (it had nothing of its own)')))
        return 0
    if args.ha_forget:
        if args.ha_forget == node_name():
            raise SystemExit('otp: that is this node')
        if not store.get_meta('node:' + args.ha_forget):
            raise SystemExit('otp: there is no node called %s in the list' % args.ha_forget)
        ha_forget(store, args.ha_forget)
        store.db.run('DELETE FROM meta WHERE k IN (?, ?)',
                     ('maint:' + args.ha_forget, 'upgrade:node:' + args.ha_forget))
        store.add_event('settings', '%s was taken off the list of nodes on the command line'
                        % args.ha_forget, 'warn', who='command line')
        print(pal.ok_line('%s is off the list (if it still runs, it writes itself back within '
                          'fifteen seconds)' % args.ha_forget))
        return 0
    if args.ha_pause or args.ha_resume or args.ha_stop:
        if args.ha_stop and not args.yes:
            raise SystemExit('otp: this takes replication away; the nodes then go their own '
                             'ways - again with --yes')
        act = 'stop' if args.ha_stop else ('pause' if args.ha_pause else 'resume')
        which = args.ha_pause or args.ha_resume
        if which in ('in', 'out'):
            act += '_' + which
        try:
            print(pal.ok_line(ha_control(store, act)['message']))
        except Exception as e:                          # noqa: BLE001
            raise SystemExit('otp: %s' % str(e).split('\n')[0])
        return 0
    if args.maintenance:
        name = args.node or node_name()
        if args.maintenance == 'status':
            row = maintenance_row(store, name)
            if args.json:
                print(json.dumps(dict(row, node=name), default=str))
            else:
                print(('%s: in maintenance since %s%s' % (
                    name, datetime.fromtimestamp(float(row.get('at') or 0)).strftime(
                        '%d-%m-%Y %H:%M:%S'), (' - ' + row['why']) if row.get('why') else ''))
                      if row.get('on') else '%s: in service' % name)
            return 0 if not row.get('on') else 3
        if args.maintenance == 'on' and not args.node:
            maintenance_ensure(store)
        try:
            maintenance_set(store, args.maintenance == 'on', args.why or 'on the command line',
                            'command line', name)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        print(pal.ok_line('%s: %s' % (name, 'in maintenance - RADIUS is not answered and '
                                      '/healthz says 503' if args.maintenance == 'on'
                                      else 'back in service')))
        return 0
    if args.upgrade_cancel:
        try:
            upgrade_cancel(store, 'command line')
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        print(pal.ok_line('the upgrade is stopped; the nodes not begun stay as they are'))
        return 0
    if args.upgrade_status:
        meta = json.loads(store.get_meta('upgrade:pkg') or 'null')
        plan = upgrade_plan(store)
        if args.json:
            print(json.dumps({'package': meta, 'plan': plan}, indent=2, default=str))
            return 0
        print('package: %s' % ('otp %s (%s bytes, signed by %s, sent by %s)' % (
            meta['version'], meta['bytes'], meta.get('signed_by'), meta.get('by'))
            if meta else 'none sent'))
        if not plan:
            print('no upgrade started on the pages')
            return 0
        print('upgrade to %s, started by %s: %s' % (plan['version'], plan.get('by'),
                                                     plan['state']))
        for st in plan['steps']:
            print('  %-20s %-11s %s' % (st['name'], st.get('state') or 'waiting',
                                        st.get('said') or ''))
        return 0
    if args.ha_status:
        rows = ha_nodes(store)
        if args.json:
            out = lambda data: print(json.dumps(data, indent=2, default=str))
            out({'node': node_name(), 'nodes': rows})
            return 0
        print(pal.head('the cluster') + pal.dim('  (this node: %s, database %s)'
                                              % (node_name(), store.db.where())))
        if not rows:
            print('  ' + pal.dim('no node has written a heartbeat yet - is the daemon running?'))
        for n in rows:
            mark = pal.ok_line if n['alive'] else pal.bad_line
            print(mark('%-16s %-15s %s  heard %s ago%s' % (
                n['name'], n.get('address') or '', n.get('version') or '?',
                human_span(n["age"]), '  (this one)' if n['me'] else '')))
        if store.db.engine != 'postgres':
            print(pal.dim('  one node: a cluster needs PostgreSQL - see otp --ha-setup'))
        rep = ha_repl_state(store)
        if rep['mode'] == 'replicated':
            print(pal.head('replication') + pal.dim('  (this node is %d of 2; the other: %s)'
                                                    % (int(rep['slot']), rep['peer'])))
            for r in rep['incoming']:
                # Errors counted so far do not make a running one bad (1.0.47):
                # every time the other node was away is one, for good.
                ok = r['enabled'] and r['running']
                line = 'in  <- %-12s %s, last heard %s%s' % (
                    rep['peer'], 'running' if r['running'] else
                    ('PAUSED' if not r['enabled'] else 'NOT RUNNING'),
                    human_span(time.time() - float(r['last_msg'])) + ' ago' if r.get('last_msg')
                    else 'never', ', %d error(s) counted so far (each time the other was away '
                    'is one)' % r['apply_errors'] if r['apply_errors'] else '')
                print((pal.ok_line if ok else pal.bad_line)(line))
            if not rep['incoming']:
                print(pal.bad_line('in  <- nothing is taken from the other node'))
            for r in rep['outgoing']:
                ok = r['active'] and r['wal_status'] != 'lost'
                print((pal.ok_line if ok else pal.bad_line)(
                    'out -> %-12s %s, %s behind, WAL %s' % (
                        rep['peer'], 'taken' if r['active'] else 'NOT TAKEN (the other is away '
                        'or paused)', bytes_words(r['behind']), r['wal_status'])))
            if not rep['outgoing']:
                print(pal.bad_line('out -> nothing is taken from this node'))
            if rep.get('lost'):
                print(pal.bad_line('the other node was away too long: rebuild it from this one '
                                   '(otp --ha-resync --yes, there)'))
        return 0
    out = lambda data: print(json.dumps(data, indent=2, default=str, ensure_ascii=False))
    who = 'command line'

    if args.status or args.check:
        d = Daemon(store, serve=False)
        s = d.status()
        try:
            import urllib.request
            req = urllib.request.Request('http://127.0.0.1:%d/api/health'
                                         % int(CONFIG.get('api_port') or 9861))
            with urllib.request.urlopen(req, timeout=3) as r:
                alive = json.loads(r.read().decode()).get('ok')
        except Exception:
            alive = False
        listening = []
        for kind, port in (('auth', CONFIG.get('radius_auth_port')),
                           ('acct', CONFIG.get('radius_acct_port'))):
            if not port:
                continue
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                probe.bind((str(CONFIG.get('radius_bind') or '0.0.0.0'), int(port)))
                listening.append((kind, port, False))
            except OSError:
                listening.append((kind, port, True))
            finally:
                probe.close()
        s['daemon_alive'] = alive
        s['ports'] = listening
        if args.json:
            out(s)
            return 0
        print(pal.head('otp %s on %s' % (__version__, s['host'])))
        print((pal.ok_line if alive else pal.bad_line)(
            'the daemon %s' % ('answers on 127.0.0.1:%s' % CONFIG.get('api_port') if alive
                               else 'is not answering - systemctl status otp')))
        for kind, port, taken in listening:
            print((pal.ok_line if taken else pal.bad_line)(
                'UDP %s (%s) %s' % (port, kind, 'is being listened on' if taken
                                    else 'is free: nothing answers RADIUS there')))
        print(pal.ok_line('the database: %s (%s)' % (store.db.where(), store.db.version())))
        t = s['tokens']
        print('  tokens: %d in use, %d waiting for a code, %d switched off; %d used in the '
              'last 30 days' % (t.get('active', 0), t.get('pending', 0), t.get('disabled', 0),
                                t.get('used_30d', 0)))
        print('  clients %d, realms %d, directories %d' % (s['clients'], s['realms'],
                                                          s['directories']))
        print('  the last 24 h: %s let in, %s refused' % (pal.good(s['day']['accept']),
                                                         pal.bad(s['day']['reject'])))
        if s.get('last'):
            print('  the last request: %s %s %s' % (stamp(s['last']['ts']),
                                                   s['last']['username'], s['last']['result']))
        print('  isemon: %s' % (('sending to %s as "%s"' % (
            CONFIG.get('isemon_targets') or '(nowhere!)', str(CONFIG.get('isemon_hostname')
                                                              or short_host())))
                                if CONFIG.get('isemon') else 'not sent'))
        for p in s['problems']:
            print(pal.bad_line(p))
        bad = 0
        if args.check:
            print(pal.head('checking every part of it'))
            def said(ok, text, hint=''):
                print((pal.ok_line if ok else pal.bad_line)(text))
                if hint and not ok:
                    print(pal.dim('    ' + hint))
                return 0 if ok else 1
            key = sealing_key_path()
            bad += said(key.is_file(), 'the key of the tokens: %s' % key,
                        'without it no token can be opened - put back the .key beside the '
                        'latest copy in %s' % BACKUP_DIR)
            copies = backups()
            if copies:
                age = (time.time() - copies[0]['at']) / 3600.0
                bad += said(age < 26 or not CONFIG.get('backup_daily'),
                            'the latest copy of the database: %s, %.0f h ago'
                            % (copies[0]['name'], age), 'otp --backup makes one now')
            else:
                print(pal.dim('  no copy of the database yet (the first is made at %s; '
                              'otp --backup makes one now)' % CONFIG.get('backup_at')))
            ph = php_state()
            if ph.get('version'):
                bad += said(bool(ph.get('fixed')), 'PHP %s %s' % (
                    ph['version'], 'has the php2shell fix' if ph.get('fixed')
                    else 'does NOT have the php2shell fix (CVE-2026-109618/109619)'),
                    './install.sh --upgrade puts it right')
            dirs = {d['name']: d for d in store.directories(with_secret=True)}
            clients = store.clients()
            if not clients:
                bad += said(False, 'no RADIUS client: nothing may ask this server',
                            'Settings -> Clients, or otp --add-client')
            for c in clients:
                print(pal.ok_line('client %s (%s)%s' % (
                    c['name'], c['address'],
                    ', adds @%s' % c['realm'] if c.get('realm') else '')))
            for r in store.realms():
                d = r.get('directory') or ''
                if d and d not in dirs:
                    bad += said(False, 'realm %s asks the directory %s, which is not set up'
                                % (r['name'], d), 'Settings -> Active Directory')
                else:
                    print(pal.ok_line('realm %s: %s, %s' % (
                        r['name'], 'directory ' + d if d else 'no directory - the code alone',
                        {'otp': 'the code', 'password_otp': 'the password then the code',
                         'password': 'the directory password'}.get(r.get('auth_mode'),
                                                                   r.get('auth_mode') or 'the code'))))
            if not dirs:
                print(pal.dim('  no directory to check (Settings -> Active Directory)'))
            for one in dirs.values():
                c = Directory(one).check()
                for srv in c['servers']:
                    line = 'directory %s, %s: %s' % (one['name'], srv['host'], '; '.join(
                        '%s%s' % (st['what'], (' (%s)' % st['said']) if st['said'] else '')
                        for st in srv['steps']))
                    bad += said(srv['ok'], line)
            if CONFIG.get('isemon'):
                targets = syslog_targets(CONFIG.get('isemon_targets') or '')
                bad += said(bool(targets), 'isemon: %s' % (', '.join(
                    '%s:%s/%s' % t[:3] for t in targets) or 'switched on, but sent nowhere'),
                    'Settings -> isemon: where to send them')
        return 0 if alive and not s['problems'] and not bad else 1

    if args.log or args.rejects:
        rows, total = store.radius_rows(hours=args.hours, q=args.search,
                                        result='reject' if args.rejects else 'access',
                                        limit=args.limit)
        if args.json:
            out({'rows': rows, 'total': total})
            return 0
        print(table([(r['id'], stamp(r['ts']), r['username'], r['client'], r['calling'] or '-',
                      pal.good('accept') if r['result'] == 'accept' else pal.bad(r['result']),
                      r['reason'] or r['otp'] or '') for r in rows],
                    ['id', 'when', 'name', 'client', 'from', 'result', 'why'],
                    [6, 19, 28, 14, 16, 16 if pal.on else 7, 60]))
        print(pal.dim('  %d of %d in the last %s h' % (len(rows), total, args.hours)))
        return 0

    if args.request:
        r = store.radius_row(args.request)
        if not r:
            raise SystemExit('there is no request %d' % args.request)
        if args.json:
            out(r)
            return 0
        print(pal.head('request %d, %s, from %s (%s)' % (r['id'], stamp(r['ts']), r['client'],
                                                       r['src'])))
        print('  %s: %s %s' % (r['username'], (pal.good if r['result'] == 'accept'
                                               else pal.bad)(r['result']), r['reason'] or ''))
        for st in r['steps']:
            print('  ' + (pal.ok_line if st.get('ok') else pal.bad_line)(
                '%s%s%s' % (st['what'], (' - ' + st['said']) if st.get('said') else '',
                            pal.dim(' (%d ms)' % st['ms']) if 'ms' in st else '')))
        print(pal.dim('  asked:'))
        for k, v in r['attrs']:
            print('    %s = %s' % (k, v))
        print(pal.dim('  answered:'))
        for k, v in r['reply']:
            print('    %s = %s' % (k, v))
        return 0

    if args.otp_log:
        rows, total = store.otp_rows(hours=args.hours, q=args.search, limit=args.limit)
        if args.json:
            out({'rows': rows, 'total': total})
            return 0
        print(table([(stamp(r['ts']), r['name'], pal.good('yes') if r['ok'] else pal.bad('no'),
                      r['said'], r['how'], r['src']) for r in rows],
                    ['when', 'name', 'ok', 'said', 'how', 'from'],
                    [19, 30, 12 if pal.on else 3, 40, 8, 20]))
        return 0

    if args.tokens:
        rows, total = store.tokens(q=args.search, limit=args.limit if '--limit' in sys.argv else 1000)
        if args.json:
            out({'rows': rows, 'total': total})
            return 0
        print(table([(r['name'], r['state'], stamp(r['created']), stamp(r['last_used'])
                      if r['last_used'] else 'never', r['scratch_left'], r['failures'] or 0,
                      r['created_by'] or '') for r in rows],
                    ['name', 'state', 'made', 'last used', 'codes', 'wrong', 'by'],
                    [34, 9, 19, 19, 5, 5, 22]))
        print(pal.dim('  %d token(s)' % total))
        return 0

    if args.token:
        tok = store.token_shown(store.token(args.token))
        checks, _ = store.otp_rows(hours=24 * 365, name=norm_name(args.token), limit=args.limit)
        if args.json:
            out({'token': tok, 'checks': checks})
            return 0
        if not tok:
            print(pal.bad_line('%s has no token' % norm_name(args.token)))
            return 1
        for k in ('name', 'state', 'created', 'created_by', 'activated', 'last_used',
                  'last_from', 'scratch_left', 'failures', 'digits', 'period', 'algorithm',
                  'window_steps', 'note'):
            v = tok.get(k)
            if k in ('created', 'activated', 'last_used'):
                v = stamp(v) if v else 'never'
            print('  %-14s %s' % (k, v if v not in (None, '') else '-'))
        print(table([(stamp(r['ts']), pal.good('yes') if r['ok'] else pal.bad('no'), r['said'],
                      r['how']) for r in checks], ['when', 'ok', 'said', 'how'],
                    [19, 12 if pal.on else 3, 44, 8]))
        return 0

    if args.events:
        rows, total = store.events(args.limit, 0, args.search)
        if args.json:
            out({'rows': rows, 'total': total})
            return 0
        print(table([(stamp(r['ts']), r['kind'], r['who'] or '', r['words']) for r in rows],
                    ['when', 'kind', 'who', 'what'], [19, 22, 18, 90]))
        return 0

    tk = Tokens(store)
    if args.enroll:
        got = tk.enroll(args.enroll, 'cli', pending=args.pending, note=args.note or None)
        store.add_event('tokens', 'a token for %s was made on the command line'
                        % got['name'], who=who)
        if args.json:
            out(got)
            return 0
        print(pal.head('a token for %s%s' % (got['name'], ' - waiting for a code (otp '
                                                         '--confirm NAME CODE)' if args.pending
                                             else '')))
        if not args.no_qr:
            print(QrCode(got['uri']).terminal(invert=args.invert))
        print('  key:      %s' % got['secret_spaced'])
        print('  in full:  %s' % got['uri'])
        if got['scratch']:
            print('  recovery codes, each good once:  %s' % '  '.join(got['scratch']))
        return 0

    if args.confirm:
        ok, said = tk.confirm(args.confirm[0], args.confirm[1], 'cli')
        print((pal.ok_line if ok else pal.bad_line)(said))
        return 0 if ok else 1

    if args.verify:
        ok, said, facts = tk.check(args.verify[0], args.verify[1], how='cli', dry=True)
        if args.json:
            out({'ok': ok, 'said': said, 'facts': facts})
        else:
            print((pal.ok_line if ok else pal.bad_line)('%s%s' % (said, (
                ' (%+d step)' % facts['off']) if facts.get('off') else '')))
        return 0 if ok else 1

    for flag, state in (('disable_token', 'disabled'), ('enable_token', 'active')):
        name = getattr(args, flag)
        if name:
            if not store.token(name):
                raise SystemExit('%s has no token' % norm_name(name))
            store.token_write(name, {'state': state, 'failures': 0, 'fail_times': '[]', 'locked_until': None})
            store.add_event('tokens', 'the token of %s was switched %s on the command line'
                            % (norm_name(name), 'off' if state == 'disabled' else 'on'), who=who)
            print(pal.ok_line('the token of %s is %s' % (norm_name(name), state)))
            return 0

    if args.delete_token:
        if not store.token(args.delete_token):
            raise SystemExit('%s has no token' % norm_name(args.delete_token))
        store.token_drop(args.delete_token)
        # What was kept beside it goes too, as on the pages (1.0.44).
        for k in ('staged:', 'mailed:'):
            store.db.run('DELETE FROM meta WHERE k = ?', (k + norm_name(args.delete_token),))
        store.add_event('tokens', 'the token of %s was taken away on the command line'
                        % norm_name(args.delete_token), 'warn', who=who)
        print(pal.ok_line('gone'))
        return 0

    if args.scratch:
        if not store.token(args.scratch):
            raise SystemExit('otp: %s has no token' % norm_name(args.scratch))
        codes = tk.new_scratch(args.scratch)
        store.add_event('tokens', 'new recovery codes for %s were made on the command line'
                        % norm_name(args.scratch), 'warn', who=who)
        print('  ' + '  '.join(codes))
        return 0

    if args.unlock:
        if not store.token(norm_name(args.unlock)):
            raise SystemExit('no token %s' % norm_name(args.unlock))
        store.token_write(norm_name(args.unlock), {'failures': 0, 'fail_times': '[]', 'locked_until': None})
        print(pal.ok_line('the wrong codes of %s are forgotten' % norm_name(args.unlock)))
        return 0

    if args.import_totpcgi:
        n = collections.Counter()
        for f in sorted(Path(args.import_totpcgi).glob('*.totp')):
            try:
                said = import_totp(store, f.name[:-5], f.read_text(errors='replace'), 'import',
                                   args.replace)
            except ValueError as e:
                said = 'not imported: %s' % e
            n[said.split(' ')[0]] += 1
            print('  %-40s %s' % (norm_name(f.name[:-5]), said))
        store.add_event('import', 'totpcgi files imported from %s: %s' % (
            args.import_totpcgi, dict(n)), who=who)
        args.fill_names = True

    if args.import_legacy:
        got = import_legacy(store, args.import_legacy, 'import', args.replace,
                            say=lambda t: print('  ' + t))
        bump(store)
        print(pal.ok_line('brought over: %s' % ', '.join('%s %d' % kv for kv in
                                                         sorted(got.items()))))
        args.fill_names = True

    if args.fill_names:
        print(pal.dim('  the owners\' names, from the directory of each token\'s realm...'))
        got = Daemon(store, serve=False).fill_names(by='command line')
        print(pal.ok_line('%d token(s) given their owner\'s name; %d not found, %d with no '
                          'directory to ask, %d could not be asked'
                          % (got['filled'], got['not_found'], got['no_directory'],
                             got['trouble'])))
        return 0

    if args.radtest:
        a = args.radtest
        if len(a) < 2:
            raise SystemExit('otp --radtest USER CODE [SERVER [PORT [SECRET]]]')
        user, code = a[0], a[1]
        server = a[2] if len(a) > 2 else '127.0.0.1'
        port = int(a[3]) if len(a) > 3 else int(CONFIG.get('radius_auth_port') or 1812)
        secret = a[4] if len(a) > 4 else None
        if secret is None:
            local = store.client_for('127.0.0.1')
            if not local:
                raise SystemExit('there is no client for 127.0.0.1: give the secret as the '
                                 'fifth word')
            secret = local['_secret']
        print(pal.dim('Sent Access-Request to %s:%d, User-Name = "%s", User-Password = "******"'
                      % (server, port, user)))
        try:
            got, words, took = radius_ask(server, port, secret, user, code)
        except RadiusError as e:
            print(pal.bad_line(str(e)))
            return 2
        print(((pal.good if got == ACCESS_ACCEPT else pal.bad)('Received %s' % CODE_WORDS.get(
            got, got))) + pal.dim(' in %d ms' % took))
        for k, v in words:
            if k != 'Message-Authenticator':
                print('    %s = %s' % (k, v))
        row = store.db.row('SELECT id FROM radius_log ORDER BY id DESC LIMIT 1')
        if row and server in ('127.0.0.1', 'localhost', '::1'):
            print(pal.dim('  every step of it: otp --request %d' % row['id']))
        return 0 if got == ACCESS_ACCEPT else 1

    if args.clients:
        rows = store.clients()
        if args.json:
            out(rows)
            return 0
        print(table([(c['name'], c['address'], c['realm'] or '-', 'yes' if c['require_ma']
                      else 'no', 'on' if c['enabled'] else 'off', stamp(c['last_seen'])
                      if c['last_seen'] else 'never') for c in rows],
                    ['name', 'address', 'realm added', 'needs MA', 'state', 'last asked']))
        return 0

    if args.add_client:
        old = next((c for c in store.clients() if c['name'].lower() == args.add_client.lower()),
                   None)
        data = {'id': old['id'] if old else None, 'name': args.add_client,
                'address': args.address or (old or {}).get('address'),
                'secret': args.secret if args.secret is not None else (
                    None if old else ask_password('the shared secret')),
                'realm': args.realm if args.realm is not None else (old or {}).get('realm', ''),
                'require_ma': (old or {}).get('require_ma', 0), 'enabled': 1,
                'note': args.note or (old or {}).get('note', '')}
        store.client_save(data, who)
        bump(store)
        store.add_event('clients', 'the client %s was saved on the command line'
                        % args.add_client, who=who)
        print(pal.ok_line('the client %s is saved' % args.add_client))
        return 0

    if args.del_client:
        one = next((c for c in store.clients() if c['name'].lower() == args.del_client.lower()),
                   None)
        if not one:
            raise SystemExit('there is no client called %s' % args.del_client)
        store.client_drop(one['id'])
        bump(store)
        print(pal.ok_line('gone'))
        return 0

    if args.realms:
        rows = store.realms()
        if args.json:
            out(rows)
            return 0
        print(table([(r['name'], r['suffix'] or '(none)', r['auth_mode'], r['directory'] or '-',
                      r['lookup'], '; '.join(g['group'] for g in r['groups']) or '(anybody)')
                     for r in rows], ['name', 'takes @', 'password is', 'directory', 'lookup',
                                      'groups'], [16, 16, 13, 12, 6, 70]))
        return 0

    if args.add_realm:
        old = next((r for r in store.realms() if r['name'].lower() == args.add_realm.lower()),
                   None) or {}
        groups = old.get('groups') or []
        if args.groups is not None:
            groups = [{'group': g, 'reply': ''} for g in dn_list(args.groups)]
        store.realm_save({'id': old.get('id'), 'name': args.add_realm,
                          'suffix': args.suffix if args.suffix is not None else old.get(
                              'suffix', args.add_realm),
                          'directory': args.directory if args.directory is not None
                          else old.get('directory', ''),
                          'lookup': args.lookup or old.get('lookup') or 'upn',
                          'auth_mode': args.mode or old.get('auth_mode') or 'otp',
                          'groups': groups, 'check_disabled': old.get('check_disabled', 1),
                          'nested': old.get('nested', 1), 'reply': old.get('reply', ''),
                          'enabled': 1, 'token_name': old.get('token_name', 'whole'),
                          'note': args.note or old.get('note', '')}, who)
        bump(store)
        print(pal.ok_line('the realm %s is saved' % args.add_realm))
        return 0

    if args.del_realm:
        one = next((r for r in store.realms() if r['name'].lower() == args.del_realm.lower()),
                   None)
        if not one:
            raise SystemExit('there is no realm called %s' % args.del_realm)
        store.realm_drop(one['id'])
        bump(store)
        print(pal.ok_line('gone'))
        return 0

    if args.directories:
        rows = store.directories()
        if args.json:
            out(rows)
            return 0
        print(table([(d['name'], d['hosts'], '%s/%s' % (d['tls'], d['port']), d['base'],
                      d['bind_dn'], 'checked' if d['verify'] else 'NOT checked')
                     for d in rows], ['name', 'servers', 'how', 'base', 'reads as',
                                      'certificate']))
        return 0

    if args.add_directory:
        old = store.directory(args.add_directory) or {}
        ca = None
        if args.ca:
            ca = Path(args.ca).read_text()
        pw = args.bind_pw if args.bind_pw is not None else os.environ.get('OTP_BIND_PW')
        data = {'id': old.get('id'), 'name': args.add_directory,
                'hosts': args.hosts or old.get('hosts'), 'base': args.base or old.get('base'),
                'bind_dn': args.bind_dn if args.bind_dn is not None else old.get('bind_dn', ''),
                'bind_pw': pw if pw is not None else (None if old else ''),
                'tls': args.tls or old.get('tls') or 'ldaps',
                'port': args.port or (old.get('port') if not args.tls else None),
                'verify': 0 if args.no_verify else old.get('verify', 1),
                'nested': old.get('nested', 1), 'enabled': 1,
                'user_attr': old.get('user_attr') or 'sAMAccountName',
                'note': args.note or old.get('note', '')}
        if ca is not None:
            data['ca'] = ca
        store.directory_save(data, who)
        bump(store)
        print(pal.ok_line('the directory %s is saved' % args.add_directory))
        return 0

    if args.del_directory:
        one = store.directory(args.del_directory)
        if not one:
            raise SystemExit('there is no directory called %s' % args.del_directory)
        store.directory_drop(one['id'])
        bump(store)
        print(pal.ok_line('gone'))
        return 0

    if args.directory_test or args.directory_user:
        name = args.directory_test or args.directory_user[0]
        one = store.directory(name, with_secret=True)
        if not one:
            raise SystemExit('there is no directory called %s' % name)
        ad = Directory(one)
        if args.directory_test:
            c = ad.check()
            if args.json:
                out(c)
                return 0
            for srv in c['servers']:
                print(pal.bold('  %s:%d' % (srv['host'], srv['port'])))
                for st in srv['steps']:
                    print('    ' + (pal.ok_line if st['ok'] else pal.bad_line)(
                        st['what'] + ((' - ' + st['said']) if st['said'] else '')))
            return 0 if c['ok'] else 1
        user = args.directory_user[1]
        entry = ad.find_user(user, 'upn' if '@' in user else 'sam')
        if not entry:
            print(pal.bad_line('the directory has nobody called %s' % user))
            return 1
        groups = ad.groups_of(entry, True)
        if args.json:
            out({'entry': entry, 'groups': groups})
            return 0
        for k in ('dn', 'upn', 'sam', 'display', 'mail', 'disabled', 'expires'):
            print('  %-10s %s' % (k, entry.get(k)))
        print('  groups:   %s' % ', '.join(sorted(cn for _, cn in groups)))
        return 0

    if args.settings:
        d = Daemon(store, serve=False)
        rows = d.settings_state(True)
        if args.json:
            out(rows)
            return 0
        for s in rows:
            print('  %-28s %-34s %s' % (s['key'], json.dumps(s['value'], ensure_ascii=False)[:34],
                                       pal.dim(s['source_says'])))
        return 0

    if args.set:
        d = Daemon(store, serve=False)
        want = {}
        for one in args.set:
            if '=' not in one:
                raise SystemExit('--set takes KEY=VALUE')
            k, v = one.split('=', 1)
            want[k.strip()] = v
        try:
            said = d.save_settings(want, by=who)
        except (BadSetting, OSError) as e:
            raise SystemExit('otp: %s' % e)
        print(pal.ok_line(said['message']))
        return 0

    if args.users:
        rows = store.accounts()
        if args.json:
            out({'users': rows})
            return 0
        print(table([(a['name'], ROLE_WORDS.get(a['role'], a['role']), a['source'] or 'local',
                      'off' if a['disabled'] else 'on', stamp(a['last_in']) if a['last_in']
                      else 'never', a['note'] or '') for a in rows],
                    ['name', 'role', 'from', 'state', 'last signed in', 'note']))
        return 0

    if args.add_user:
        pw = ask_password('a password for %s' % args.add_user)
        try:
            store.add_account(args.add_user, args.role or 'readonly', pw, note=args.note)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        store.add_event('accounts', 'the account %s was made on the command line, as %s'
                        % (args.add_user, args.role or 'readonly'), who=who)
        print(pal.ok_line('%s may now sign in, as %s' % (args.add_user, args.role or 'readonly')))
        return 0

    if args.passwd:
        pw = ask_password('a new password for %s' % args.passwd)
        try:
            store.set_account(args.passwd, password=pw, must_change=0)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        # As the pages do (1.0.44): a new password ends the old sign-ins.
        store.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ?',
                     ('admin', args.passwd.lower()))
        store.add_event('accounts', 'the password of %s was set on the command line'
                        % args.passwd, who=who)
        print(pal.ok_line('the password of %s is set' % args.passwd))
        return 0

    for flag in ('set_role', 'del_user', 'disable_user', 'enable_user'):
        name = getattr(args, flag)
        if not name:
            continue
        try:
            acc = store.account(name)
            if not acc:
                raise ValueError('there is no account called %s' % name)
            if flag == 'set_role' and not args.role:
                raise ValueError('which role? --set-role %s --role %s' % (name, '|'.join(ROLES_ALL)))
            if (flag in ('del_user', 'disable_user') or (flag == 'set_role' and args.role != 'fulladmin')) \
                    and acc.get('role') == 'fulladmin' and not store.fulladmins_left(but=name):
                raise ValueError('that is the last full administrator who can sign in')
            if flag == 'set_role':
                store.set_account(name, role=args.role)
            elif flag == 'del_user':
                store.drop_account(name)
            else:
                store.set_account(name, disabled=1 if flag == 'disable_user' else 0)
        except ValueError as e:
            raise SystemExit('otp: %s' % e)
        store.add_event('accounts', '%s: %s on the command line' % (name, flag.replace('_', ' ')),
                        who=who)
        print(pal.ok_line('done'))
        return 0

    if args.backup:
        got = make_backup(store, 'on the command line')
        print(pal.ok_line('%s, and the key beside it' % got))
        return 0

    if args.restore:
        if not args.yes:
            raise SystemExit('this replaces everything in %s with the copy; again with --yes'
                             % store.db.where())
        # The same restore as the pages (1.0.44): every kind of copy, a copy
        # of what is replaced made first, the key beside it or in it.
        if not Path(args.restore).is_file():
            raise SystemExit('otp: there is no file %s' % args.restore)
        try:
            got = db_file_restore(store, args.restore, 'command line',
                                  key_file=_key_beside(args.restore))
        except (ValueError, OSError) as e:
            raise SystemExit('otp: %s' % e)
        BIND_STRICT['tokens'] = False
        bind_tokens(store)
        print(pal.ok_line('put back (%s); what it replaced is kept as %s; %s'
                          % (DUMP_WORDS.get(got['kind'], got['kind']), got['safety'], got['key'])))
        return 0

    if args.tidy:
        print(pal.ok_line('tidied: %s' % store.tidy()))
        return 0

    if args.isemon_test:
        if not CONFIG.get('isemon_targets'):
            raise SystemExit('nothing to send to: otp --set isemon_targets=HOST:514')
        sh = Shipper()
        CONFIG['isemon'] = 1
        sh.configure()
        sh.put('otp', 'daemon', 'a test from otp %s on the command line - isemon reads nothing '
               'from this line' % __version__)
        sh.flush(3)
        time.sleep(0.5)
        st = sh.state()
        for t in st['targets']:
            if t in st['trouble']:
                print(pal.bad_line('%s: %s' % (t, st['trouble'][t])))
            else:
                print(pal.ok_line('%s: sent (%d)' % (t, st['sent'].get(t, 0))))
        return 0

    build_parser().print_help()
    return 2


_DAEMON_LOCK = None


def daemon_lock():
    """One daemon at a time. A second one - started by hand beside the
    service - would share nothing and answer half the requests."""
    global _DAEMON_LOCK
    import fcntl
    path = Path(STATE_DIR) / 'otp.lock'
    try:
        fd = os.open(str(path), os.O_RDWR | os.O_CREAT, 0o644)
    except OSError:
        fd = os.open(str(path), os.O_RDONLY)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        try:
            pid = os.read(os.open(str(path), os.O_RDONLY), 32).decode().strip()
        except OSError:
            pid = ''
        raise SystemExit('otp is running already%s - this one stops here.\n'
                         '  what it is doing:  otp --status\n'
                         '  the service:       systemctl status otp'
                         % (' (pid %s)' % pid if pid else ''))
    try:
        os.ftruncate(fd, 0)
        os.write(fd, str(os.getpid()).encode())
    except OSError:
        pass
    _DAEMON_LOCK = fd


def run_daemon():
    become_service_user()
    load_config()
    daemon_lock()
    log_open()
    try:
        db = open_db()
        store = Storage(db)
    except Exception as e:
        log('the database %s could not be opened: %s' % (CONFIG.get('db_engine'), e), 'error')
        raise SystemExit(1)
    load_config(saved=store.settings_saved())
    log_open()
    if not store.accounts():
        pw = secrets.token_urlsafe(12)
        store.add_account('admin', 'fulladmin', pw, note='made on the first start',
                          must_change=1)
        try:
            write_replacing(STATE_DIR / 'first-login.txt', 'name: admin\npassword: %s\n' % pw,
                            0o600)
        except OSError:
            pass
        store.add_event('accounts', 'there was no account, so admin was made; its password '
                        'is in %s' % (STATE_DIR / 'first-login.txt'), 'warn')
    Daemon(store).run()
    return 0


if __name__ == '__main__':
    try:
        sys.exit(cli_main())
    except KeyboardInterrupt:
        sys.exit(130)
    except (ValueError, OSError, LdapError, DbError) as e:
        # Said as one line, not a trace (1.0.44): a missing file, a name
        # with a comma, a realm that is not there.
        if isinstance(e, BrokenPipeError):
            sys.exit(0)
        if '--daemon' in sys.argv:
            raise                       # the service keeps its whole trace
        sys.stderr.write('otp: %s\n' % e)
        sys.exit(1)
    except BrokenPipeError:
        sys.exit(0)
