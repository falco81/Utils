# JsonViewer

Total Commander Lister plugin for pretty-printed JSON viewing. Handles
deeply-nested documents, embedded `data:image/…;base64,` images, and
2 MB+ files without breaking a sweat.

## Layout

```
+---------------------------------------------------+
| [ Search box ]  ◀ ▶   1 | 2 | 3 | All             |
+----------------------+----------------------------+
| Tree view (left)     | Detail pane (right)        |
|                      |  • image  → decoded         |
|  { root              |  • string → text + URLs     |
|    ├ "video": "…"    |  • int    → value + time    |
|    ├ "cues": […]     |             interpretation  |
|    │   [0]           |  • object → summary + list  |
|    │   ▶ "face": img |                            |
+----------------------+----------------------------+
| filename | JSON path | size                       |
+---------------------------------------------------+
```

## Features

- **Split view**: Tree of the whole document on the left, detail of
  the selected node on the right. Drag the vertical splitter to
  resize.
- **Base64 image preview**: `data:image/*;base64,…` values are
  decoded and rendered in the detail pane (JPEG / PNG / GIF / WebP
  via GDI+).
- **Lazy tree**: Only children of expanded nodes are inserted, so
  files with thousands of items open instantly.
- **Search** (`Ctrl+F` or type in the toolbar): matches keys *and*
  values, case-insensitive. `F3` jumps to next hit and expands the
  path.
- **URL detection**: URLs and email addresses in string values are
  clickable in the detail pane (RichEdit `EM_AUTOURLDETECT`).
- **Timestamp interpretation**: Integers/floats that look like Unix
  timestamps (seconds or milliseconds, 2000..2100) are shown with
  their UTC date in the detail pane.
- **Copy**: `Ctrl+C` copies the current value; `Ctrl+Shift+C` copies
  the JSON path (`$.cues[3].face`). Right-click on the tree for the
  context menu.
- **Collapse depth**: Toolbar buttons `1`, `2`, `3`, `All` collapse
  the tree to the given depth (or fully expand — capped at 8 levels
  to avoid runaway on huge files).
- **Persistent window state**: Position and size of TC's Lister
  window are remembered between sessions.

## Configuration

Settings live in `JsonViewer.ini` next to TC's own `wincmd.ini`.

| Key                 | Default | Meaning                         |
| ------------------- | ------- | ------------------------------- |
| `SplitPosition`     | 40      | Left pane width, in percent     |
| `FontSize`          | 14      | Detail-pane font size           |
| `WrapDetailText`    | 1       | Wrap long strings in detail     |
| `RememberWindowSize`| 1       | Persist Lister placement         |
| `MaximizeOnOpen`    | 0       | Maximize on every open          |
| `AutoExpandDepth`   | 2       | Initial expand depth (0 = none) |
| `DecodeImages`      | 1       | Render base64 image data URLs   |

## Installation

Total Commander → **Configuration → Plugins → Lister plugins → Add**,
point at `pluginst.inf` inside the ZIP.

## Building from source

`make all` cross-compiles both DLLs with MinGW under Linux (`g++-mingw-w64`
is enough; see `build-linux.sh`). Under Windows use `build-windows.bat`
which drives MSYS2's MinGW toolchains.
