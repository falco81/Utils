// JsonViewer — Total Commander Lister plugin for pretty JSON viewing.
//
// Layout:
//   +--------------------------------------------------+
//   | Toolbar: [search box] [prev] [next]  [1|2|3|All] |
//   +---------------------+----------------------------+
//   | TreeView (left)     |  DetailView (right)        |
//   |  <resizable split>  |                            |
//   +---------------------+----------------------------+
//   | Status bar: path | size | encoding               |
//   +--------------------------------------------------+
//
// Exports:
//   ListGetDetectString  → *.json,*.jsonl (via extension check)
//   ListLoad / ListLoadW → open a file
//   ListCloseWindow      → save window state, tear down
//   ListSearchText[W]    → Ctrl+F handler forwarded by TC
//   ListSendCommand      → misc commands (copy, print, ...)
//   ListSetDefaultParams → receive INI path from TC

#include "listplug.h"
#include "json.h"
#include "base64.h"
#include "tree_model.h"
#include "detail_view.h"
#include "ini_settings.h"

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <string>
#include <memory>
#include <vector>
#include <cstdio>
#include <cwchar>

#pragma comment(lib, "comctl32.lib")

namespace {

// ---------------------------------------------------------------------------
// Globals & helpers
// ---------------------------------------------------------------------------
HINSTANCE g_hInstance = nullptr;
std::wstring g_iniPath;
jv::IniSettings g_settings;

// String helpers.
std::wstring U8ToW(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(),
                                nullptr, 0);
    std::wstring r(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), r.data(), n);
    return r;
}
std::string WToU8(const std::wstring& s) {
    if (s.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(),
                                nullptr, 0, nullptr, nullptr);
    std::string r(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(),
                        r.data(), n, nullptr, nullptr);
    return r;
}
std::string AnsiToU8(const char* s) {
    if (!s) return {};
    int nw = MultiByteToWideChar(CP_ACP, 0, s, -1, nullptr, 0);
    std::wstring w(nw ? nw - 1 : 0, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s, -1, w.data(), nw);
    return WToU8(w);
}
std::wstring AnsiToW(const char* s) {
    if (!s) return {};
    int nw = MultiByteToWideChar(CP_ACP, 0, s, -1, nullptr, 0);
    std::wstring w(nw ? nw - 1 : 0, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s, -1, w.data(), nw);
    return w;
}

// Load full file as UTF-8 (best-effort). Returns empty string + err
// on failure.
bool ReadWholeFile(const std::wstring& path, std::string& out,
                   std::string& err) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ,
                           nullptr, OPEN_EXISTING,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) {
        err = "Failed to open file (error " +
              std::to_string(GetLastError()) + ")";
        return false;
    }
    LARGE_INTEGER li{};
    GetFileSizeEx(h, &li);
    if (li.QuadPart > (LONGLONG)(256 * 1024 * 1024)) {
        CloseHandle(h);
        err = "File is larger than 256 MB — refusing to load.";
        return false;
    }
    out.resize((size_t)li.QuadPart);
    DWORD done = 0;
    if (li.QuadPart > 0 &&
        !ReadFile(h, out.data(), (DWORD)li.QuadPart, &done, nullptr)) {
        err = "Read failed";
        CloseHandle(h);
        return false;
    }
    CloseHandle(h);

    // Detect UTF-16 LE/BE BOMs and transcode to UTF-8 so the parser
    // (which expects UTF-8) works uniformly.
    if (out.size() >= 2) {
        unsigned char b0 = (unsigned char)out[0];
        unsigned char b1 = (unsigned char)out[1];
        if (b0 == 0xFF && b1 == 0xFE) {
            const wchar_t* wp = (const wchar_t*)(out.data() + 2);
            size_t wlen = (out.size() - 2) / 2;
            int n = WideCharToMultiByte(CP_UTF8, 0, wp, (int)wlen,
                                        nullptr, 0, nullptr, nullptr);
            std::string u8(n, '\0');
            WideCharToMultiByte(CP_UTF8, 0, wp, (int)wlen,
                                u8.data(), n, nullptr, nullptr);
            out = std::move(u8);
        }
        // BE handling omitted — extremely rare for JSON.
    }
    return true;
}

// ---------------------------------------------------------------------------
// Constants (control IDs, class names)
// ---------------------------------------------------------------------------
constexpr int ID_TREE       = 5000;
constexpr int ID_DETAIL     = 5001;
constexpr int ID_SEARCH     = 5010;
constexpr int ID_BTN_PREV   = 5011;
constexpr int ID_BTN_NEXT   = 5012;
constexpr int ID_BTN_LVL1   = 5013;
constexpr int ID_BTN_LVL2   = 5014;
constexpr int ID_BTN_LVL3   = 5015;
constexpr int ID_BTN_LVLALL = 5016;
constexpr int ID_SPLIT      = 5020;

constexpr UINT TIMER_APPLY_WINSTATE = 0x7F01;

const wchar_t* kViewerClass = L"JsonViewerHostV1";
const wchar_t* kSplitClass  = L"JsonViewerSplitV1";

// Layout constants.
constexpr int kToolbarHeight = 32;
constexpr int kSplitWidth    = 5;
// (no status bar — TC's own Lister status band already shows the
//  filename+size at the very bottom of the frame, and the detail
//  panel's header shows the JSON path. Adding one on top was pure
//  duplication and looked broken.)

// ---------------------------------------------------------------------------
// Plugin instance
// ---------------------------------------------------------------------------
struct PluginInst {
    HWND        parentList = nullptr;
    HWND        hwnd       = nullptr;

    // Children
    HWND        hSearch    = nullptr;
    HWND        hBtnPrev   = nullptr;
    HWND        hBtnNext   = nullptr;
    HWND        hBtnLvl1   = nullptr;
    HWND        hBtnLvl2   = nullptr;
    HWND        hBtnLvl3   = nullptr;
    HWND        hBtnLvlAll = nullptr;
    HWND        hSplit     = nullptr;
    HWND        hTree      = nullptr;
    HWND        hTooltip   = nullptr;   // shared tooltip control

    // Original WNDPROCs saved before subclassing (so we can chain).
    WNDPROC     origTreeProc   = nullptr;
    WNDPROC     origSearchProc = nullptr;

    jv::TreeModel                model;
    std::unique_ptr<jv::DetailView> detail;

    std::wstring filePath;
    int          splitPct   = 40;    // % width for tree pane
    bool         dragging   = false;
    bool         placementApplied = false;
    HTREEITEM    lastFound  = nullptr;
    std::string  lastNeedle;
};

// ---------------------------------------------------------------------------
// Forward decls
// ---------------------------------------------------------------------------
LRESULT CALLBACK ViewerProc(HWND h, UINT m, WPARAM wp, LPARAM lp);
LRESULT CALLBACK SplitProc (HWND h, UINT m, WPARAM wp, LPARAM lp);
void LayoutChildren(PluginInst* p);
void DoFind(PluginInst* p, bool forward, bool wrap);
void OnTreeSelChanged(PluginInst* p);
void UpdateStatusBar(PluginInst* p);
void CopyPathToClipboard(PluginInst* p);
void CopyValueToClipboard(PluginInst* p);

// ---------------------------------------------------------------------------
// Window placement (against TC's Lister top-level window)
// ---------------------------------------------------------------------------
HWND ListerTopLevel(HWND host) {
    if (!host) return nullptr;
    HWND root = GetAncestor(host, GA_ROOT);
    return root ? root : host;
}

void ApplyWindowState(HWND host) {
    HWND lister = ListerTopLevel(host);
    if (!lister) return;
    if (g_settings.maximizeOnOpen) {
        ShowWindow(lister, SW_MAXIMIZE);
        return;
    }
    if (!g_settings.rememberWinSize) return;
    if (g_settings.lastWinW <= 0 || g_settings.lastWinH <= 0) return;
    WINDOWPLACEMENT wp = {}; wp.length = sizeof(wp);
    GetWindowPlacement(lister, &wp);
    wp.showCmd = g_settings.lastWinMax ? SW_SHOWMAXIMIZED : SW_SHOWNORMAL;
    wp.rcNormalPosition.left   = g_settings.lastWinX;
    wp.rcNormalPosition.top    = g_settings.lastWinY;
    wp.rcNormalPosition.right  = g_settings.lastWinX + g_settings.lastWinW;
    wp.rcNormalPosition.bottom = g_settings.lastWinY + g_settings.lastWinH;
    SetWindowPlacement(lister, &wp);
}

void CaptureWindowState(HWND host) {
    HWND lister = ListerTopLevel(host);
    if (!lister) return;
    WINDOWPLACEMENT wp = {}; wp.length = sizeof(wp);
    if (!GetWindowPlacement(lister, &wp)) return;
    g_settings.lastWinMax = (wp.showCmd == SW_SHOWMAXIMIZED);
    if (!g_settings.lastWinMax) {
        RECT& r = wp.rcNormalPosition;
        g_settings.lastWinX = r.left;
        g_settings.lastWinY = r.top;
        g_settings.lastWinW = r.right - r.left;
        g_settings.lastWinH = r.bottom - r.top;
    }
    if (!g_iniPath.empty()) g_settings.SaveWindowState(g_iniPath);
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------
void LayoutChildren(PluginInst* p) {
    if (!p || !p->hwnd) return;
    RECT r; GetClientRect(p->hwnd, &r);

    // Toolbar row (top).
    int x = 6, y = 5, tbH = kToolbarHeight - 6;
    if (p->hSearch) {
        SetWindowPos(p->hSearch, nullptr, x, y, 260, tbH,
                     SWP_NOZORDER | SWP_NOACTIVATE);
        x += 268;
    }
    if (p->hBtnPrev) {
        SetWindowPos(p->hBtnPrev, nullptr, x, y, 30, tbH,
                     SWP_NOZORDER | SWP_NOACTIVATE);
        x += 34;
    }
    if (p->hBtnNext) {
        SetWindowPos(p->hBtnNext, nullptr, x, y, 30, tbH,
                     SWP_NOZORDER | SWP_NOACTIVATE);
        x += 42;
    }
    if (p->hBtnLvl1)   { SetWindowPos(p->hBtnLvl1,   nullptr, x,    y, 30, tbH,
                                     SWP_NOZORDER|SWP_NOACTIVATE); }
    if (p->hBtnLvl2)   { SetWindowPos(p->hBtnLvl2,   nullptr, x+34, y, 30, tbH,
                                     SWP_NOZORDER|SWP_NOACTIVATE); }
    if (p->hBtnLvl3)   { SetWindowPos(p->hBtnLvl3,   nullptr, x+68, y, 30, tbH,
                                     SWP_NOZORDER|SWP_NOACTIVATE); }
    if (p->hBtnLvlAll) { SetWindowPos(p->hBtnLvlAll, nullptr, x+102,y, 40, tbH,
                                     SWP_NOZORDER|SWP_NOACTIVATE); }

    // Content area fills everything below the toolbar. No status bar
    // of our own — TC's Lister already renders one at the very
    // bottom, and duplicating it looked broken.
    int contentY = kToolbarHeight;
    int contentH = r.bottom - kToolbarHeight;
    if (contentH < 60) contentH = 60;

    int treeW = (r.right * p->splitPct) / 100;
    if (treeW < 100) treeW = 100;
    if (treeW > r.right - 200) treeW = r.right - 200;
    int detX  = treeW + kSplitWidth;
    int detW  = r.right - detX;

    if (p->hTree) {
        SetWindowPos(p->hTree, nullptr, 0, contentY, treeW, contentH,
                     SWP_NOZORDER | SWP_NOACTIVATE);
    }
    if (p->hSplit) {
        SetWindowPos(p->hSplit, nullptr, treeW, contentY,
                     kSplitWidth, contentH,
                     SWP_NOZORDER | SWP_NOACTIVATE);
    }
    if (p->detail && p->detail->Hwnd()) {
        p->detail->Resize(detX, contentY, detW, contentH);
    }
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------
void DoFind(PluginInst* p, bool forward, bool wrap) {
    if (!p || !p->hTree) return;
    wchar_t buf[256] = {};
    GetWindowTextW(p->hSearch, buf, 256);
    if (!buf[0]) return;
    std::string needle = WToU8(buf);
    HTREEITEM start = (needle == p->lastNeedle) ? p->lastFound : nullptr;
    (void)forward;         // backward search not implemented — just cycle
    HTREEITEM h = p->model.FindNext(p->hTree, start, needle,
                                    /*keys*/ true, /*values*/ true, wrap);
    if (h) {
        p->lastFound = h;
        p->lastNeedle = needle;
    } else {
        MessageBeep(MB_ICONASTERISK);
    }
}

// ---------------------------------------------------------------------------
// Selection change
// ---------------------------------------------------------------------------
void OnTreeSelChanged(PluginInst* p) {
    if (!p || !p->hTree || !p->detail) return;
    HTREEITEM h = TreeView_GetSelection(p->hTree);
    if (!h) { p->detail->ShowNode("", nullptr); return; }
    const jv::NodeInfo* n = p->model.Info(h);
    if (!n) { p->detail->ShowNode("", nullptr); return; }
    std::string path = p->model.PathFor(h);
    p->detail->ShowNode(path, n->value);
    UpdateStatusBar(p);
}

// UpdateStatusBar used to update three STATIC labels at the bottom.
// Those labels are gone; this is now a no-op left for future hooking.
void UpdateStatusBar(PluginInst* /*p*/) {}

// ---------------------------------------------------------------------------
// Clipboard
// ---------------------------------------------------------------------------
void CopyStringToClipboard(HWND owner, const std::wstring& w) {
    if (!OpenClipboard(owner)) return;
    EmptyClipboard();
    size_t bytes = (w.size() + 1) * sizeof(wchar_t);
    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (hMem) {
        void* p = GlobalLock(hMem);
        memcpy(p, w.data(), bytes);
        GlobalUnlock(hMem);
        SetClipboardData(CF_UNICODETEXT, hMem);
    }
    CloseClipboard();
}

void CopyPathToClipboard(PluginInst* p) {
    if (!p || !p->hTree) return;
    HTREEITEM h = TreeView_GetSelection(p->hTree);
    if (!h) return;
    CopyStringToClipboard(p->hwnd, U8ToW(p->model.PathFor(h)));
}

void CopyValueToClipboard(PluginInst* p) {
    if (!p || !p->detail) return;
    CopyStringToClipboard(p->hwnd, U8ToW(p->detail->CurrentValueAsText()));
}

// ---------------------------------------------------------------------------
// Splitter proc
// ---------------------------------------------------------------------------
LRESULT CALLBACK SplitProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    PluginInst* p = (PluginInst*)GetWindowLongPtrW(GetParent(h),
                                                    GWLP_USERDATA);
    switch (m) {
        case WM_SETCURSOR:
            SetCursor(LoadCursor(nullptr, IDC_SIZEWE));
            return 1;
        case WM_LBUTTONDOWN:
            SetCapture(h);
            if (p) p->dragging = true;
            return 0;
        case WM_LBUTTONUP:
            if (p) p->dragging = false;
            ReleaseCapture();
            if (p && !g_iniPath.empty()) {
                g_settings.splitPosition = p->splitPct;
                g_settings.SaveOptions(g_iniPath);
            }
            return 0;
        case WM_MOUSEMOVE:
            if (p && p->dragging) {
                POINT pt = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
                ClientToScreen(h, &pt);
                ScreenToClient(p->hwnd, &pt);
                RECT r; GetClientRect(p->hwnd, &r);
                int newPct = (pt.x * 100) / r.right;
                if (newPct < 15) newPct = 15;
                if (newPct > 85) newPct = 85;
                if (newPct != p->splitPct) {
                    p->splitPct = newPct;
                    LayoutChildren(p);
                }
            }
            return 0;
        case WM_ERASEBKGND: {
            HDC dc = (HDC)wp;
            RECT r; GetClientRect(h, &r);
            FillRect(dc, &r, GetSysColorBrush(COLOR_BTNFACE));
            return 1;
        }
    }
    return DefWindowProcW(h, m, wp, lp);
}

// ---------------------------------------------------------------------------
// Hotkey forwarding — keys pressed inside child controls (tree /
// search box) must reach the host so Esc closes the viewer, F3
// searches, Ctrl+F focuses the search box, Ctrl+C/Ctrl+Shift+C copy.
// ---------------------------------------------------------------------------
static bool IsInterestingHotkey(WPARAM vk, bool ctrl, bool shift) {
    if (vk == VK_ESCAPE || vk == VK_F3)          return true;
    if (ctrl && (vk == 'F' || vk == 'C'))        return true;
    (void)shift;
    return false;
}

// Common WNDPROC used for both the tree control and the search box.
// Intercepts host-level hotkeys and posts them to the host so
// ViewerProc's WM_KEYDOWN handler can respond. All other messages
// pass through to the original control.
LRESULT CALLBACK HotkeyForwardProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    // Locate our host by walking up until we find a window whose
    // class matches kViewerClass — GetParent gives that directly
    // because both the tree and the search box are direct children.
    HWND host = GetParent(h);
    PluginInst* p = host ? (PluginInst*)GetWindowLongPtrW(host,
                                                          GWLP_USERDATA)
                         : nullptr;
    WNDPROC orig = nullptr;
    if (p) {
        if (h == p->hTree)        orig = p->origTreeProc;
        else if (h == p->hSearch) orig = p->origSearchProc;
    }
    if (m == WM_KEYDOWN && p) {
        bool ctrl  = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
        bool shift = (GetKeyState(VK_SHIFT)   & 0x8000) != 0;
        if (IsInterestingHotkey(wp, ctrl, shift)) {
            PostMessageW(host, WM_KEYDOWN, wp, lp);
            // For Esc/F3/Ctrl+F we don't want the tree or edit to
            // also react (Esc in an EDIT clears selection, F3 does
            // nothing useful). Ctrl+C in an EDIT does copy the
            // selected text — that's usually what the user wants —
            // so let it through.
            if (wp == VK_ESCAPE || wp == VK_F3 || (ctrl && wp == 'F')) {
                return 0;
            }
        }
    }
    // Suppress the "unhandled character" beep. Windows' message loop
    // runs TranslateMessage regardless of whether we returned 0 from
    // WM_KEYDOWN, and Esc (0x1B) has an associated WM_CHAR. When
    // that WM_CHAR reaches a tree/edit control with nothing to do,
    // the control asks the system to beep. We swallow it here.
    if (m == WM_CHAR && (wp == 0x1B /*Esc*/
                      || wp == 0x06 /*Ctrl+F*/
                      || wp == 0x0A /*Ctrl+Enter, hypothetically*/)) {
        return 0;
    }
    if (orig) return CallWindowProcW(orig, h, m, wp, lp);
    return DefWindowProcW(h, m, wp, lp);
}

// Route a WM_MOUSEWHEEL that landed on the viewer to whichever child
// window sits under the cursor. Windows sends WM_MOUSEWHEEL to the
// focused window by default; without this routing the detail-pane
// image would ignore the wheel unless the user clicked into it first.
LRESULT RouteWheelToChildUnderCursor(HWND host, UINT m, WPARAM wp, LPARAM lp) {
    POINT pt = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };  // screen coords
    HWND target = WindowFromPoint(pt);
    if (target && target != host && IsChild(host, target)) {
        return SendMessageW(target, m, wp, lp);
    }
    return DefWindowProcW(host, m, wp, lp);
}

// ---------------------------------------------------------------------------
// Tooltip control — one shared instance covers all toolbar buttons.
// ---------------------------------------------------------------------------
void AddTooltip(HWND hTooltip, HWND hCtl, const wchar_t* text) {
    if (!hTooltip || !hCtl) return;
    TOOLINFOW ti = {};
    ti.cbSize   = sizeof(ti);
    ti.uFlags   = TTF_IDISHWND | TTF_SUBCLASS;
    ti.hwnd     = GetParent(hCtl);
    ti.uId      = (UINT_PTR)hCtl;
    ti.lpszText = (LPWSTR)text;
    SendMessageW(hTooltip, TTM_ADDTOOLW, 0, (LPARAM)&ti);
}

// ---------------------------------------------------------------------------
// Main window proc
// ---------------------------------------------------------------------------
LRESULT CALLBACK ViewerProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    PluginInst* p = (PluginInst*)GetWindowLongPtrW(h, GWLP_USERDATA);
    switch (m) {
        case WM_NCCREATE: {
            CREATESTRUCT* cs = (CREATESTRUCT*)lp;
            SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)cs->lpCreateParams);
            break;
        }
        case WM_SIZE:
            if (p) LayoutChildren(p);
            return 0;
        case WM_ERASEBKGND: {
            HDC dc = (HDC)wp;
            RECT r; GetClientRect(h, &r);
            // Toolbar band gets the button-face colour; children
            // cover the rest.
            RECT top = { 0, 0, r.right, kToolbarHeight };
            FillRect(dc, &top, GetSysColorBrush(COLOR_BTNFACE));
            return 1;
        }
        case WM_CTLCOLORSTATIC: {
            HDC dc = (HDC)wp;
            SetBkColor(dc, GetSysColor(COLOR_BTNFACE));
            SetTextColor(dc, GetSysColor(COLOR_BTNTEXT));
            return (LRESULT)GetSysColorBrush(COLOR_BTNFACE);
        }
        case WM_CTLCOLOREDIT: {
            // Toolbar search box — leave default.
            return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
        }
        case WM_TIMER:
            if (wp == TIMER_APPLY_WINSTATE) {
                KillTimer(h, TIMER_APPLY_WINSTATE);
                if (p && !p->placementApplied) {
                    p->placementApplied = true;
                    ApplyWindowState(h);
                }
                return 0;
            }
            break;
        case WM_MOUSEWHEEL:
            // Route to the child under cursor (e.g. detail image
            // pane for zoom) so the user doesn't have to click the
            // pane first.
            return RouteWheelToChildUnderCursor(h, m, wp, lp);
        case WM_KEYDOWN: {
            bool ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
            if (ctrl && wp == 'F') {
                if (p && p->hSearch) {
                    SetFocus(p->hSearch);
                    SendMessageW(p->hSearch, EM_SETSEL, 0, -1);
                }
                return 0;
            }
            if (wp == VK_F3) {
                bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
                if (p) DoFind(p, !shift, true);
                return 0;
            }
            if (ctrl && wp == 'C') {
                CopyValueToClipboard(p);
                return 0;
            }
            if (ctrl && (GetKeyState(VK_SHIFT) & 0x8000) && wp == 'C') {
                CopyPathToClipboard(p);
                return 0;
            }
            if (wp == VK_ESCAPE) {
                // Forward to TC's Lister to close.
                if (p && p->parentList)
                    PostMessageW(p->parentList, WM_KEYDOWN, VK_ESCAPE, 0);
                return 0;
            }
            break;
        }
        case WM_COMMAND: {
            int id = LOWORD(wp);
            int code = HIWORD(wp);
            if (!p) break;
            if (id == ID_SEARCH && code == EN_CHANGE) {
                // Live find on typing. Reset lastFound so next F3 starts
                // from top.
                p->lastFound = nullptr;
                DoFind(p, true, true);
                return 0;
            }
            if (id == ID_BTN_PREV) { DoFind(p, false, true); return 0; }
            if (id == ID_BTN_NEXT) { DoFind(p, true,  true); return 0; }
            if (id == ID_BTN_LVL1) { p->model.CollapseToDepth(p->hTree,1); return 0; }
            if (id == ID_BTN_LVL2) { p->model.CollapseToDepth(p->hTree,2); return 0; }
            if (id == ID_BTN_LVL3) { p->model.CollapseToDepth(p->hTree,3); return 0; }
            if (id == ID_BTN_LVLALL){ p->model.ExpandAll(p->hTree);        return 0; }
            break;
        }
        case WM_NOTIFY: {
            NMHDR* hdr = (NMHDR*)lp;
            if (hdr && hdr->hwndFrom == p->hTree) {
                if (hdr->code == TVN_SELCHANGEDW || hdr->code == TVN_SELCHANGEDA) {
                    OnTreeSelChanged(p);
                    return 0;
                }
                if (hdr->code == TVN_ITEMEXPANDINGW ||
                    hdr->code == TVN_ITEMEXPANDINGA) {
                    NMTREEVIEWW* tv = (NMTREEVIEWW*)hdr;
                    if (tv->action == TVE_EXPAND && p) {
                        p->model.OnExpanding(p->hTree, tv->itemNew.hItem);
                    }
                    return 0;
                }
                if (hdr->code == NM_RCLICK) {
                    // Right-click context menu on tree — copy path/value.
                    POINT pt; GetCursorPos(&pt);
                    HMENU menu = CreatePopupMenu();
                    AppendMenuW(menu, MF_STRING, 1001,
                                L"Copy value\tCtrl+C");
                    AppendMenuW(menu, MF_STRING, 1002,
                                L"Copy JSON path\tCtrl+Shift+C");
                    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
                    AppendMenuW(menu, MF_STRING, 1010,
                                L"Expand this branch");
                    AppendMenuW(menu, MF_STRING, 1011,
                                L"Collapse this branch");
                    int cmd = TrackPopupMenu(menu,
                        TPM_LEFTALIGN | TPM_RETURNCMD, pt.x, pt.y, 0, h, nullptr);
                    DestroyMenu(menu);
                    if (cmd == 1001) CopyValueToClipboard(p);
                    else if (cmd == 1002) CopyPathToClipboard(p);
                    else if (cmd == 1010) {
                        HTREEITEM sel = TreeView_GetSelection(p->hTree);
                        if (sel) TreeView_Expand(p->hTree, sel, TVE_EXPAND);
                    } else if (cmd == 1011) {
                        HTREEITEM sel = TreeView_GetSelection(p->hTree);
                        if (sel) TreeView_Expand(p->hTree, sel, TVE_COLLAPSE);
                    }
                    return 1;
                }
                if (hdr->code == NM_DBLCLK) {
                    HTREEITEM sel = TreeView_GetSelection(p->hTree);
                    if (sel) TreeView_Expand(p->hTree, sel, TVE_TOGGLE);
                    return 0;
                }
                if (hdr->code == NM_RETURN) {
                    HTREEITEM sel = TreeView_GetSelection(p->hTree);
                    if (sel) TreeView_Expand(p->hTree, sel, TVE_TOGGLE);
                    return 1;
                }
            }
            break;
        }
    }
    return DefWindowProcW(h, m, wp, lp);
}

// ---------------------------------------------------------------------------
// Window / class registration
// ---------------------------------------------------------------------------
void RegisterViewerClass() {
    static bool done = false;
    if (done) return;
    done = true;
    WNDCLASSEXW c = { sizeof(c) };
    c.style         = CS_HREDRAW | CS_VREDRAW;
    c.lpfnWndProc   = ViewerProc;
    c.hInstance     = g_hInstance;
    c.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    c.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    c.lpszClassName = kViewerClass;
    RegisterClassExW(&c);

    WNDCLASSEXW s = { sizeof(s) };
    s.style         = CS_HREDRAW | CS_VREDRAW;
    s.lpfnWndProc   = SplitProc;
    s.hInstance     = g_hInstance;
    s.hCursor       = LoadCursor(nullptr, IDC_SIZEWE);
    s.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    s.lpszClassName = kSplitClass;
    RegisterClassExW(&s);
}

// ---------------------------------------------------------------------------
// Create UI
// ---------------------------------------------------------------------------
HWND CreateChildren(PluginInst* p) {
    HFONT uiFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

    // Toolbar controls.
    p->hSearch = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
        0, 0, 100, 22, p->hwnd, (HMENU)(INT_PTR)ID_SEARCH,
        g_hInstance, nullptr);
    SendMessageW(p->hSearch, WM_SETFONT, (WPARAM)uiFont, TRUE);
    SendMessageW(p->hSearch, EM_SETCUEBANNER, TRUE,
                 (LPARAM)L"Search keys and values… (Ctrl+F)");

    auto mkBtn = [&](int id, const wchar_t* text) {
        HWND b = CreateWindowExW(0, L"BUTTON", text,
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_TABSTOP,
            0, 0, 30, 22, p->hwnd, (HMENU)(INT_PTR)id,
            g_hInstance, nullptr);
        SendMessageW(b, WM_SETFONT, (WPARAM)uiFont, TRUE);
        return b;
    };
    p->hBtnPrev   = mkBtn(ID_BTN_PREV,   L"◀");
    p->hBtnNext   = mkBtn(ID_BTN_NEXT,   L"▶");
    p->hBtnLvl1   = mkBtn(ID_BTN_LVL1,   L"1");
    p->hBtnLvl2   = mkBtn(ID_BTN_LVL2,   L"2");
    p->hBtnLvl3   = mkBtn(ID_BTN_LVL3,   L"3");
    p->hBtnLvlAll = mkBtn(ID_BTN_LVLALL, L"All");

    // Shared tooltip control for all toolbar buttons.
    p->hTooltip = CreateWindowExW(WS_EX_TOPMOST,
        TOOLTIPS_CLASSW, nullptr,
        WS_POPUP | TTS_ALWAYSTIP,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        p->hwnd, nullptr, g_hInstance, nullptr);
    if (p->hTooltip) {
        SendMessageW(p->hTooltip, TTM_SETMAXTIPWIDTH, 0, 400);
        AddTooltip(p->hTooltip, p->hBtnPrev,
                   L"Previous match (Shift+F3)");
        AddTooltip(p->hTooltip, p->hBtnNext,
                   L"Next match (F3)");
        AddTooltip(p->hTooltip, p->hBtnLvl1,
                   L"Collapse tree to depth 1 (top-level keys only)");
        AddTooltip(p->hTooltip, p->hBtnLvl2,
                   L"Collapse tree to depth 2");
        AddTooltip(p->hTooltip, p->hBtnLvl3,
                   L"Collapse tree to depth 3");
        AddTooltip(p->hTooltip, p->hBtnLvlAll,
                   L"Expand every node (up to 8 levels)");
    }

    // Tree.
    p->hTree = CreateWindowExW(WS_EX_CLIENTEDGE, WC_TREEVIEWW, L"",
        WS_CHILD | WS_VISIBLE | WS_TABSTOP
        | TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT
        | TVS_SHOWSELALWAYS | TVS_FULLROWSELECT,
        0, 0, 100, 100, p->hwnd, (HMENU)(INT_PTR)ID_TREE,
        g_hInstance, nullptr);
    SendMessageW(p->hTree, WM_SETFONT, (WPARAM)uiFont, TRUE);

    // Splitter.
    p->hSplit = CreateWindowExW(0, kSplitClass, L"",
        WS_CHILD | WS_VISIBLE,
        0, 0, kSplitWidth, 100, p->hwnd, (HMENU)(INT_PTR)ID_SPLIT,
        g_hInstance, nullptr);

    // Detail.
    p->detail = std::make_unique<jv::DetailView>();
    p->detail->Create(p->hwnd, g_hInstance);
    jv::DetailStyle ds;
    ds.fontSize     = g_settings.fontSize;
    ds.wrap         = g_settings.wrapDetailText;
    ds.decodeImages = g_settings.decodeImages;
    p->detail->SetStyle(ds);

    // Subclass tree + search box so their internal WNDPROC doesn't
    // eat our hotkeys (Esc/F3/Ctrl+F/Ctrl+C). Without this, pressing
    // Esc after clicking into the tree does nothing.
    p->origTreeProc = (WNDPROC)SetWindowLongPtrW(
        p->hTree, GWLP_WNDPROC, (LONG_PTR)HotkeyForwardProc);
    p->origSearchProc = (WNDPROC)SetWindowLongPtrW(
        p->hSearch, GWLP_WNDPROC, (LONG_PTR)HotkeyForwardProc);

    return p->hwnd;
}

// ---------------------------------------------------------------------------
// Load path
// ---------------------------------------------------------------------------
HWND DoLoad(HWND parent, const std::wstring& file) {
    // Load INI (once per process).
    static bool iniLoaded = false;
    if (!iniLoaded) { g_settings.Load(g_iniPath); iniLoaded = true; }

    RegisterViewerClass();
    INITCOMMONCONTROLSEX icc = { sizeof(icc),
        ICC_TREEVIEW_CLASSES | ICC_BAR_CLASSES | ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icc);

    auto p = new PluginInst;
    p->parentList = parent;
    p->splitPct   = g_settings.splitPosition;
    p->filePath   = file;

    p->hwnd = CreateWindowExW(0, kViewerClass, L"",
        WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN,
        0, 0, 100, 100, parent, nullptr, g_hInstance, p);
    if (!p->hwnd) { delete p; return nullptr; }

    CreateChildren(p);

    // Read + parse.
    std::string src, err;
    if (!ReadWholeFile(file, src, err)) {
        p->model.LoadFromUtf8("null");
    } else {
        std::string perr = p->model.LoadFromUtf8(std::move(src));
        if (!perr.empty()) {
            std::wstring msg = L"Failed to parse JSON:\n\n" + U8ToW(perr);
            MessageBoxW(parent, msg.c_str(), L"JsonViewer",
                        MB_OK | MB_ICONWARNING);
        }
    }
    p->model.PopulateInto(p->hTree, g_settings.autoExpandDepth);

    LayoutChildren(p);
    OnTreeSelChanged(p);
    UpdateStatusBar(p);

    // Defer window placement; TC finishes its own placement first.
    SetTimer(p->hwnd, TIMER_APPLY_WINSTATE, 100, nullptr);
    return p->hwnd;
}

} // namespace

// ===========================================================================
// TC exports
// ===========================================================================
extern "C" {

__declspec(dllexport)
void __stdcall ListGetDetectString(char* buf, int maxlen) {
    // Match by extension. TC also lets us peek at the first 8 KB, but
    // extension check is simpler and matches user expectation.
    const char* det = "EXT=\"JSON\"|EXT=\"JSONL\"|EXT=\"JSONC\"";
    lstrcpynA(buf, det, maxlen);
}

__declspec(dllexport)
HWND __stdcall ListLoad(HWND parent, char* fileToLoad, int /*ShowFlags*/) {
    return DoLoad(parent, AnsiToW(fileToLoad));
}

__declspec(dllexport)
HWND __stdcall ListLoadW(HWND parent, wchar_t* fileToLoad, int /*ShowFlags*/) {
    return DoLoad(parent, fileToLoad ? std::wstring(fileToLoad)
                                     : std::wstring());
}

__declspec(dllexport)
void __stdcall ListCloseWindow(HWND listWin) {
    if (!listWin) return;
    PluginInst* p = (PluginInst*)GetWindowLongPtrW(listWin, GWLP_USERDATA);
    if (p) CaptureWindowState(listWin);
    if (p && !g_iniPath.empty()) {
        g_settings.SaveOptions(g_iniPath);
    }
    KillTimer(listWin, TIMER_APPLY_WINSTATE);
    DestroyWindow(listWin);
    delete p;
}

__declspec(dllexport)
int __stdcall ListSearchText(HWND listWin, char* searchStr, int /*flags*/) {
    if (!listWin || !searchStr) return LISTPLUGIN_ERROR;
    PluginInst* p = (PluginInst*)GetWindowLongPtrW(listWin, GWLP_USERDATA);
    if (!p) return LISTPLUGIN_ERROR;
    SetWindowTextW(p->hSearch, AnsiToW(searchStr).c_str());
    DoFind(p, true, true);
    return LISTPLUGIN_OK;
}

__declspec(dllexport)
int __stdcall ListSearchTextW(HWND listWin, wchar_t* searchStr, int /*flags*/) {
    if (!listWin || !searchStr) return LISTPLUGIN_ERROR;
    PluginInst* p = (PluginInst*)GetWindowLongPtrW(listWin, GWLP_USERDATA);
    if (!p) return LISTPLUGIN_ERROR;
    SetWindowTextW(p->hSearch, searchStr);
    DoFind(p, true, true);
    return LISTPLUGIN_OK;
}

__declspec(dllexport)
int __stdcall ListSendCommand(HWND listWin, int command, int /*parameter*/) {
    if (!listWin) return LISTPLUGIN_ERROR;
    PluginInst* p = (PluginInst*)GetWindowLongPtrW(listWin, GWLP_USERDATA);
    if (!p) return LISTPLUGIN_ERROR;
    if (command == lc_copy) {
        CopyValueToClipboard(p);
        return LISTPLUGIN_OK;
    }
    if (command == lc_selectall) {
        // No-op; the tree doesn't have a natural "select all" — beep.
        MessageBeep(MB_ICONASTERISK);
        return LISTPLUGIN_OK;
    }
    return LISTPLUGIN_ERROR;
}

__declspec(dllexport)
void __stdcall ListSetDefaultParams(ListDefaultParamStruct* dps) {
    if (!dps || dps->size < (int)sizeof(int) * 4) return;
    if (dps->DefaultIniName[0]) {
        std::wstring w = AnsiToW(dps->DefaultIniName);
        // Use the directory that holds wincmd.ini for our own INI.
        size_t slash = w.find_last_of(L"\\/");
        if (slash != std::wstring::npos) w = w.substr(0, slash + 1);
        else w.clear();
        w += L"JsonViewer.ini";
        g_iniPath = std::move(w);
    }
}

} // extern "C"

// ===========================================================================
// DLL entry
// ===========================================================================
BOOL WINAPI DllMain(HINSTANCE hInst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_hInstance = hInst;
        DisableThreadLibraryCalls(hInst);
    }
    return TRUE;
}
