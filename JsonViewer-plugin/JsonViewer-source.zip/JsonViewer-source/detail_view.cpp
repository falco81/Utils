#include "detail_view.h"
#include "base64.h"

// GDI+ for image decoding & rendering.
#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>
#include <objidl.h>
#include <gdiplus.h>
#include <richedit.h>
#include <commctrl.h>
#include <cstdio>
#include <cwchar>
#include <cctype>
#include <ctime>

#pragma comment(lib, "gdiplus.lib")

namespace jv {

// ---------------------------------------------------------------------------
// GDI+ token — initialised once per process.
// ---------------------------------------------------------------------------
static ULONG_PTR g_gdiplusToken = 0;
static void EnsureGdiPlus() {
    if (g_gdiplusToken) return;
    Gdiplus::GdiplusStartupInput inp;
    Gdiplus::GdiplusStartup(&g_gdiplusToken, &inp, nullptr);
}

// ---------------------------------------------------------------------------
// Small string helpers
// ---------------------------------------------------------------------------
static std::wstring U8ToW(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(),
                                nullptr, 0);
    std::wstring r(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), r.data(), n);
    return r;
}

// LF → CRLF so multi-line EDIT displays correctly.
static std::wstring LfToCrLf(const std::wstring& in) {
    std::wstring out;
    out.reserve(in.size() + in.size() / 32);
    for (wchar_t c : in) {
        if (c == L'\n') out += L"\r\n";
        else if (c != L'\r') out += c;
    }
    return out;
}

// Detect looks-like-a-timestamp integer:
//   - seconds in [946684800, 4102444800)  → 2000-01-01 .. 2100-01-01
//   - milliseconds in [946684800000, 4102444800000)
static bool TimestampFromInt(int64_t v, std::wstring& out) {
    const int64_t kSec2000 = 946684800LL;
    const int64_t kSec2100 = 4102444800LL;
    time_t t = 0;
    if (v >= kSec2000 && v < kSec2100) {
        t = (time_t)v;
    } else if (v >= kSec2000 * 1000 && v < kSec2100 * 1000) {
        t = (time_t)(v / 1000);
    } else {
        return false;
    }
    struct tm gm;
#ifdef _WIN32
    gmtime_s(&gm, &t);
#else
    gm = *gmtime(&t);
#endif
    wchar_t buf[64];
    swprintf(buf, 64, L"%04d-%02d-%02d %02d:%02d:%02d UTC",
             gm.tm_year + 1900, gm.tm_mon + 1, gm.tm_mday,
             gm.tm_hour, gm.tm_min, gm.tm_sec);
    out = buf;
    return true;
}

static bool TimestampFromReal(double v, std::wstring& out) {
    if (v > 946684800.0 && v < 4102444800.0) {
        return TimestampFromInt((int64_t)v, out);
    }
    return false;
}

// ---------------------------------------------------------------------------
// Window classes
// ---------------------------------------------------------------------------
static const wchar_t* kContainerClass = L"JsonViewerDetailV1";
static const wchar_t* kImageClass     = L"JsonViewerImgV1";

static void RegisterClasses(HINSTANCE hInst) {
    static bool done = false;
    if (done) return;
    done = true;
    WNDCLASSEXW c = { sizeof(c) };
    c.style         = CS_HREDRAW | CS_VREDRAW;
    c.lpfnWndProc   = DetailView::ContainerProc;
    c.hInstance     = hInst;
    c.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    c.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    c.lpszClassName = kContainerClass;
    RegisterClassExW(&c);

    WNDCLASSEXW ic = { sizeof(ic) };
    ic.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    ic.lpfnWndProc   = DetailView::ImageProc;
    ic.hInstance     = hInst;
    ic.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    ic.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    ic.lpszClassName = kImageClass;
    RegisterClassExW(&ic);
}

// ---------------------------------------------------------------------------
// Ctor / dtor
// ---------------------------------------------------------------------------
DetailView::~DetailView() {
    DisposeBitmap();
    if (hFontUi_)   DeleteObject(hFontUi_);
    if (hFontMono_) DeleteObject(hFontMono_);
}

void DetailView::DisposeBitmap() {
    if (bitmap_) {
        delete (Gdiplus::Bitmap*)bitmap_;
        bitmap_ = nullptr;
    }
    if (scaledCache_) {
        delete (Gdiplus::Bitmap*)scaledCache_;
        scaledCache_ = nullptr;
    }
    bitmapW_ = bitmapH_ = 0;
    cachedZoom_ = -1.0;
    cachedW_ = cachedH_ = 0;
    zoom_ = 0.0;
    panX_ = panY_ = 0;
    panDragging_ = false;
}

HWND DetailView::Create(HWND parent, HINSTANCE hInst) {
    EnsureGdiPlus();
    RegisterClasses(hInst);

    hWnd_ = CreateWindowExW(0, kContainerClass, L"",
        WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN,
        0, 0, 100, 100, parent, nullptr, hInst, this);
    if (!hWnd_) return nullptr;

    // Load RichEdit20 so we can use EM_AUTOURLDETECT.
    LoadLibraryW(L"riched20.dll");

    hHeader_ = CreateWindowExW(0, L"STATIC", L"",
        WS_CHILD | WS_VISIBLE | SS_LEFT | SS_NOPREFIX,
        0, 0, 100, 40, hWnd_, nullptr, hInst, nullptr);

    hText_ = CreateWindowExW(WS_EX_CLIENTEDGE, L"RichEdit20W", L"",
        WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL
        | ES_MULTILINE | ES_READONLY,
        0, 40, 100, 60, hWnd_, nullptr, hInst, nullptr);
    if (hText_) {
        SendMessageW(hText_, EM_AUTOURLDETECT, AURL_ENABLEURL, 0);
        SendMessageW(hText_, EM_SETEVENTMASK, 0, ENM_LINK | ENM_MOUSEEVENTS);
    }

    hImage_ = CreateWindowExW(WS_EX_CLIENTEDGE, kImageClass, L"",
        WS_CHILD | SS_OWNERDRAW,        // start hidden
        0, 40, 100, 60, hWnd_, nullptr, hInst, this);
    if (hImage_) {
        SetWindowLongPtrW(hImage_, GWLP_USERDATA, (LONG_PTR)this);
    }

    // Data-URL toolbar row (Rendered / Raw / Save…). Hidden by
    // default and only shown when the selected node is a data URL.
    hBtnRendered_ = CreateWindowExW(0, L"BUTTON", L"Rendered",
        WS_CHILD | BS_AUTORADIOBUTTON | BS_PUSHLIKE | WS_GROUP | WS_TABSTOP,
        0, 0, 90, 24, hWnd_, (HMENU)(INT_PTR)7001, hInst, nullptr);
    hBtnRaw_ = CreateWindowExW(0, L"BUTTON", L"Raw",
        WS_CHILD | BS_AUTORADIOBUTTON | BS_PUSHLIKE | WS_TABSTOP,
        0, 0, 90, 24, hWnd_, (HMENU)(INT_PTR)7002, hInst, nullptr);
    hBtnSave_ = CreateWindowExW(0, L"BUTTON", L"Save as…",
        WS_CHILD | BS_PUSHBUTTON | WS_TABSTOP,
        0, 0, 110, 24, hWnd_, (HMENU)(INT_PTR)7003, hInst, nullptr);

    RebuildFonts();
    return hWnd_;
}

void DetailView::RebuildFonts() {
    if (hFontUi_)   { DeleteObject(hFontUi_);   hFontUi_ = nullptr; }
    if (hFontMono_) { DeleteObject(hFontMono_); hFontMono_ = nullptr; }
    hFontUi_ = CreateFontW(-14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
    hFontMono_ = CreateFontW(-style_.fontSize, 0, 0, 0,
        FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    if (hHeader_) SendMessageW(hHeader_, WM_SETFONT, (WPARAM)hFontUi_,  TRUE);
    if (hText_)   SendMessageW(hText_,   WM_SETFONT, (WPARAM)hFontMono_,TRUE);
    if (hBtnRendered_) SendMessageW(hBtnRendered_, WM_SETFONT,
                                    (WPARAM)hFontUi_, TRUE);
    if (hBtnRaw_)      SendMessageW(hBtnRaw_,      WM_SETFONT,
                                    (WPARAM)hFontUi_, TRUE);
    if (hBtnSave_)     SendMessageW(hBtnSave_,     WM_SETFONT,
                                    (WPARAM)hFontUi_, TRUE);
}

void DetailView::SetStyle(const DetailStyle& s) {
    style_ = s;
    RebuildFonts();
    Layout();
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------
void DetailView::Resize(int x, int y, int w, int h) {
    if (!hWnd_) return;
    SetWindowPos(hWnd_, nullptr, x, y, w, h,
                 SWP_NOZORDER | SWP_NOACTIVATE);
    Layout();
}

void DetailView::Layout() {
    if (!hWnd_) return;
    RECT r; GetClientRect(hWnd_, &r);
    const int kHdr = 42;
    const int kTb  = 30;

    if (hHeader_) {
        SetWindowPos(hHeader_, nullptr, 4, 4, r.right - 8, kHdr - 8,
                     SWP_NOZORDER | SWP_NOACTIVATE);
    }

    // Only show the toolbar row for data URL values — everything
    // else has nothing to toggle and nothing meaningful to save.
    bool wantTb = currentIsDataUrl_;
    int tbH = wantTb ? kTb : 0;
    auto placeBtn = [&](HWND h, int x, int w, int y) {
        if (!h) return;
        ShowWindow(h, wantTb ? SW_SHOW : SW_HIDE);
        if (wantTb) {
            SetWindowPos(h, nullptr, x, y, w, kTb - 6,
                         SWP_NOZORDER | SWP_NOACTIVATE);
        }
    };
    int tbY = kHdr + 2;
    placeBtn(hBtnRendered_, 4,        90, tbY);
    placeBtn(hBtnRaw_,      98,       60, tbY);
    // Save on the far right.
    placeBtn(hBtnSave_, r.right - 116, 112, tbY);

    int contentY = kHdr + tbH;
    int contentH = r.bottom - contentY;
    if (contentH < 0) contentH = 0;

    bool showImage = (bitmap_ != nullptr) && !showRaw_;
    if (hImage_) {
        ShowWindow(hImage_, showImage ? SW_SHOW : SW_HIDE);
        if (showImage) {
            SetWindowPos(hImage_, nullptr, 0, contentY,
                         r.right, contentH,
                         SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }
    if (hText_) {
        ShowWindow(hText_, showImage ? SW_HIDE : SW_SHOW);
        if (!showImage) {
            SetWindowPos(hText_, nullptr, 0, contentY,
                         r.right, contentH,
                         SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }
}

// ---------------------------------------------------------------------------
// Content — dispatch by JSON kind
// ---------------------------------------------------------------------------
void DetailView::UpdateHeader(const std::string& path,
                              const mj::Json* value) {
    if (!hHeader_) return;
    std::wstring wpath = U8ToW(path);
    std::wstring wtype = L"—";
    std::wstring wsize;
    if (value) {
        using K = mj::JKind;
        switch (value->Kind()) {
            case K::Null: wtype = L"null"; break;
            case K::Bool: wtype = L"bool"; break;
            case K::Int:  wtype = L"integer"; break;
            case K::Real: wtype = L"number"; break;
            case K::Str: {
                const auto& s = value->AsStr();
                if (LooksLikeImageDataUrl(s)) wtype = L"image (data URL)";
                else                          wtype = L"string";
                wchar_t buf[48];
                swprintf(buf, 48, L"  ·  %zu chars", s.size());
                wsize = buf;
                break;
            }
            case K::Arr: {
                size_t n = value->AsArr().size();
                wtype = L"array";
                wchar_t buf[48];
                swprintf(buf, 48, L"  ·  %zu %ls", n,
                         n == 1 ? L"item" : L"items");
                wsize = buf;
                break;
            }
            case K::Obj: {
                size_t n = value->AsObj().size();
                wtype = L"object";
                wchar_t buf[48];
                swprintf(buf, 48, L"  ·  %zu %ls", n,
                         n == 1 ? L"key" : L"keys");
                wsize = buf;
                break;
            }
        }
    }
    std::wstring text = wpath + L"\r\n" + wtype + wsize;
    SetWindowTextW(hHeader_, text.c_str());
}

void DetailView::ShowImage(const std::vector<uint8_t>& bytes,
                           const std::string& mime) {
    DisposeBitmap();
    if (bytes.empty()) return;
    // Create IStream over a globally-allocated buffer.
    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, bytes.size());
    if (!hMem) return;
    {
        void* p = GlobalLock(hMem);
        memcpy(p, bytes.data(), bytes.size());
        GlobalUnlock(hMem);
    }
    IStream* stream = nullptr;
    if (CreateStreamOnHGlobal(hMem, TRUE, &stream) != S_OK) {
        GlobalFree(hMem);
        return;
    }
    auto* bmp = new Gdiplus::Bitmap(stream);
    stream->Release();
    if (bmp->GetLastStatus() != Gdiplus::Ok) {
        delete bmp;
        return;
    }
    bitmap_  = bmp;
    bitmapW_ = (int)bmp->GetWidth();
    bitmapH_ = (int)bmp->GetHeight();
    if (hImage_) InvalidateRect(hImage_, nullptr, TRUE);
    (void)mime;
}

void DetailView::ShowTextEdit(const std::wstring& text) {
    if (!hText_) return;
    // Set the wrap style based on options. RichEdit uses
    // ES_AUTOHSCROLL. We toggle the extended style at message time.
    std::wstring crlf = LfToCrLf(text);
    SetWindowTextW(hText_, crlf.c_str());
    // Re-detect URLs after content change.
    SendMessageW(hText_, EM_AUTOURLDETECT, AURL_ENABLEURL, 0);
    // Reset selection to start so RichEdit doesn't scroll wildly.
    SendMessageW(hText_, EM_SETSEL, 0, 0);
    SendMessageW(hText_, EM_SCROLLCARET, 0, 0);
}

void DetailView::ShowNode(const std::string& path, const mj::Json* value) {
    // Remember for re-renders (mode toggle).
    currentPath_  = path;
    currentValue_ = value;
    UpdateHeader(path, value);
    DisposeBitmap();
    currentText_.clear();
    currentRawString_.clear();
    currentIsDataUrl_ = false;
    currentDataMime_.clear();
    currentDataBytes_.clear();

    if (!value) {
        ShowTextEdit(L"(no selection)");
        Layout();
        return;
    }
    using K = mj::JKind;
    switch (value->Kind()) {
        case K::Null:
            currentText_ = "null";
            ShowTextEdit(L"null");
            break;
        case K::Bool:
            currentText_ = value->AsBool() ? "true" : "false";
            ShowTextEdit(value->AsBool() ? L"true" : L"false");
            break;
        case K::Int: {
            char b[32]; snprintf(b, 32, "%lld", (long long)value->AsInt());
            currentText_ = b;
            std::wstring w = U8ToW(currentText_);
            std::wstring ts;
            if (TimestampFromInt(value->AsInt(), ts)) {
                w += L"\r\n\r\n[Timestamp interpretation: " + ts + L"]";
            }
            ShowTextEdit(w);
            break;
        }
        case K::Real: {
            char b[64]; snprintf(b, 64, "%.17g", value->AsReal());
            currentText_ = b;
            std::wstring w = U8ToW(currentText_);
            std::wstring ts;
            if (TimestampFromReal(value->AsReal(), ts)) {
                w += L"\r\n\r\n[Timestamp interpretation: " + ts + L"]";
            }
            ShowTextEdit(w);
            break;
        }
        case K::Str: {
            const auto& s = value->AsStr();
            currentText_ = s;
            currentRawString_ = s;

            // Universal data URL handling: parses any MIME. The
            // renderer chooses the display strategy based on the top
            // MIME category (image → image, text → text, else →
            // summary + Save prompt).
            std::string mime;
            std::vector<uint8_t> bytes;
            if (jv::ParseDataUrl(s, mime, bytes)) {
                currentIsDataUrl_  = true;
                currentDataMime_   = mime;
                currentDataBytes_  = std::move(bytes);

                // Sync toolbar radio state.
                Button_SetCheck(hBtnRendered_,
                                showRaw_ ? BST_UNCHECKED : BST_CHECKED);
                Button_SetCheck(hBtnRaw_,
                                showRaw_ ? BST_CHECKED : BST_UNCHECKED);

                if (showRaw_) {
                    ShowTextEdit(U8ToW(s));
                    break;
                }
                // Rendered: dispatch by MIME.
                if (mime.compare(0, 6, "image/") == 0
                    && style_.decodeImages) {
                    ShowImage(currentDataBytes_, mime);
                } else if (mime.compare(0, 5, "text/") == 0) {
                    std::string txt(
                        (const char*)currentDataBytes_.data(),
                        currentDataBytes_.size());
                    ShowTextEdit(U8ToW(txt));
                } else {
                    // Binary blob — describe it and let the user save.
                    wchar_t buf[256];
                    size_t nb = currentDataBytes_.size();
                    swprintf(buf, 256,
                        L"Binary data\r\n\r\n"
                        L"MIME type:      %hs\r\n"
                        L"Encoded (base64): %zu chars\r\n"
                        L"Decoded size:   %zu bytes\r\n\r\n"
                        L"Use \"Save as…\" to write it to disk, or "
                        L"switch to Raw to see the data URL text.",
                        mime.c_str(), s.size(), nb);
                    ShowTextEdit(buf);
                }
                break;
            }
            // Plain string (not a data URL).
            ShowTextEdit(U8ToW(s));
            break;
        }
        case K::Arr: {
            const auto& arr = value->AsArr();
            std::wstring w;
            wchar_t buf[64];
            swprintf(buf, 64, L"Array with %zu %ls\r\n\r\n", arr.size(),
                     arr.size() == 1 ? L"item" : L"items");
            w = buf;
            size_t n = arr.size() < 30 ? arr.size() : 30;
            for (size_t i = 0; i < n; ++i) {
                swprintf(buf, 64, L"[%zu]  ", i);
                w += buf;
                const auto& v = arr[i];
                switch (v.Kind()) {
                    case K::Str: {
                        const auto& sv = v.AsStr();
                        if (jv::LooksLikeDataUrl(sv))
                            w += L"<data URL>";
                        else {
                            std::wstring wv = U8ToW(sv);
                            if (wv.size() > 100) { wv.resize(100); wv += L"…"; }
                            for (auto& c : wv) if (c == L'\n') c = L' ';
                            w += L"\"" + wv + L"\"";
                        }
                        break;
                    }
                    case K::Int:  { char b[32]; snprintf(b,32,"%lld",
                                    (long long)v.AsInt()); w += U8ToW(b); break; }
                    case K::Real: { char b[32]; snprintf(b,32,"%g",v.AsReal());
                                    w += U8ToW(b); break; }
                    case K::Bool: w += v.AsBool() ? L"true" : L"false"; break;
                    case K::Null: w += L"null"; break;
                    case K::Arr:  { swprintf(buf, 64, L"[array of %zu]",
                                    v.AsArr().size()); w += buf; break; }
                    case K::Obj:  { swprintf(buf, 64, L"{object with %zu keys}",
                                    v.AsObj().size()); w += buf; break; }
                }
                w += L"\r\n";
            }
            if (arr.size() > n) {
                swprintf(buf, 64, L"...and %zu more.", arr.size() - n);
                w += buf;
            }
            ShowTextEdit(w);
            break;
        }
        case K::Obj: {
            const auto& obj = value->AsObj();
            std::wstring w;
            wchar_t buf[64];
            swprintf(buf, 64, L"Object with %zu %ls\r\n\r\n", obj.size(),
                     obj.size() == 1 ? L"key" : L"keys");
            w = buf;
            for (const auto& kv : obj) {
                w += U8ToW(kv.first) + L":  ";
                const auto& v = kv.second;
                switch (v.Kind()) {
                    case K::Str: {
                        const auto& sv = v.AsStr();
                        if (jv::LooksLikeDataUrl(sv))
                            w += L"<data URL>";
                        else {
                            std::wstring wv = U8ToW(sv);
                            if (wv.size() > 100) { wv.resize(100); wv += L"…"; }
                            for (auto& c : wv) if (c == L'\n') c = L' ';
                            w += L"\"" + wv + L"\"";
                        }
                        break;
                    }
                    case K::Int:  { char b[32]; snprintf(b,32,"%lld",
                                    (long long)v.AsInt()); w += U8ToW(b); break; }
                    case K::Real: { char b[32]; snprintf(b,32,"%g",v.AsReal());
                                    w += U8ToW(b); break; }
                    case K::Bool: w += v.AsBool() ? L"true" : L"false"; break;
                    case K::Null: w += L"null"; break;
                    case K::Arr:  { swprintf(buf, 64, L"[array of %zu]",
                                    v.AsArr().size()); w += buf; break; }
                    case K::Obj:  { swprintf(buf, 64, L"{object with %zu keys}",
                                    v.AsObj().size()); w += buf; break; }
                }
                w += L"\r\n";
            }
            ShowTextEdit(w);
            break;
        }
    }
    Layout();
}

void DetailView::RerenderCurrent() {
    // ShowNode also does Layout etc. Cheap enough to just re-run.
    ShowNode(currentPath_, currentValue_);
}

void DetailView::OnToolbarCommand(int id) {
    if (id == 7001 && showRaw_) {
        showRaw_ = false;
        RerenderCurrent();
    } else if (id == 7002 && !showRaw_) {
        showRaw_ = true;
        RerenderCurrent();
    } else if (id == 7003) {
        SaveCurrentToFile(GetParent(hWnd_));
    }
}

std::string DetailView::CurrentValueAsText() const {
    return currentText_;
}

// ---------------------------------------------------------------------------
// Save-as
// ---------------------------------------------------------------------------
namespace {
    // Turn the trailing segment of a JSON path into a filename stem
    // ("$.cues[32].face" → "face", "$.cues[32]" → "item_32").
    std::string LastPathSegment(const std::string& path) {
        if (path.empty() || path == "$") return "data";
        size_t dot = path.rfind('.');
        size_t br  = path.rfind('[');
        if (dot != std::string::npos
            && (br == std::string::npos || dot > br)) {
            std::string s = path.substr(dot + 1);
            if (!s.empty()) return s;
        }
        if (br != std::string::npos) {
            size_t rb = path.find(']', br);
            if (rb != std::string::npos && rb > br + 1) {
                std::string idx = path.substr(br + 1, rb - br - 1);
                if (idx.size() >= 2 && idx.front() == '"'
                                    && idx.back() == '"') {
                    return idx.substr(1, idx.size() - 2);
                }
                return "item_" + idx;
            }
        }
        return "data";
    }
    // Replace anything that isn't safe on a filesystem with '_'.
    void SanitizeFilename(std::string& s) {
        for (char& c : s) {
            unsigned char u = (unsigned char)c;
            if (u < 0x20 || c == '/' || c == '\\' || c == ':' || c == '*'
                || c == '?' || c == '"' || c == '<' || c == '>' || c == '|') {
                c = '_';
            }
        }
        while (!s.empty() && (s.back() == ' ' || s.back() == '.')) {
            s.pop_back();
        }
        if (s.empty()) s = "data";
    }
    // Build a NUL-terminated GetSaveFileName filter block, e.g.
    // "JPEG (*.jpg)\0*.jpg\0All files (*.*)\0*.*\0"
    std::vector<wchar_t> BuildFilter(const std::string& mime,
                                     const std::string& ext) {
        std::vector<wchar_t> out;
        auto push = [&](const std::wstring& w) {
            out.insert(out.end(), w.begin(), w.end());
            out.push_back(L'\0');
        };
        if (!mime.empty() && !ext.empty()) {
            std::wstring mw(mime.begin(), mime.end());
            std::wstring ew(ext.begin(), ext.end());
            push(mw + L" (*" + ew + L")");
            push(L"*" + ew);
        }
        push(L"All files (*.*)");
        push(L"*.*");
        out.push_back(L'\0');
        return out;
    }
}

bool DetailView::SaveCurrentToFile(HWND ownerForDialog) {
    // Nothing selected → nothing to save. Save is offered for both
    // data URLs and plain strings (the latter get written as UTF-8
    // text).
    if (!currentValue_) return false;
    if (currentValue_->Kind() != mj::JKind::Str) return false;

    std::string ext, mimeForFilter;
    const uint8_t* bytes = nullptr;
    size_t nbytes = 0;
    // Local storage in case we need to encode text to UTF-8 (for a
    // plain string save).
    std::vector<uint8_t> textBuf;
    if (currentIsDataUrl_) {
        ext = jv::MimeToExtension(currentDataMime_);
        mimeForFilter = currentDataMime_;
        bytes  = currentDataBytes_.data();
        nbytes = currentDataBytes_.size();
    } else {
        ext = ".txt";
        mimeForFilter = "text/plain";
        textBuf.assign(currentRawString_.begin(), currentRawString_.end());
        bytes  = textBuf.data();
        nbytes = textBuf.size();
    }

    // Suggested filename: <last-path-segment><ext>.
    std::string stem = LastPathSegment(currentPath_);
    SanitizeFilename(stem);
    std::string suggested = stem + ext;

    wchar_t nameBuf[MAX_PATH];
    {
        std::wstring w(suggested.begin(), suggested.end());
        wcsncpy(nameBuf, w.c_str(), MAX_PATH - 1);
        nameBuf[MAX_PATH - 1] = L'\0';
    }
    auto filter = BuildFilter(mimeForFilter, ext);
    std::wstring extW(ext.begin() + 1, ext.end()); // drop leading '.'

    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner   = ownerForDialog;
    ofn.lpstrFile   = nameBuf;
    ofn.nMaxFile    = MAX_PATH;
    ofn.lpstrFilter = filter.data();
    ofn.lpstrDefExt = extW.c_str();
    ofn.Flags       = OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY
                    | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (!GetSaveFileNameW(&ofn)) return false;

    HANDLE h = CreateFileW(nameBuf, GENERIC_WRITE, 0, nullptr,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) {
        MessageBoxW(ownerForDialog,
            L"Could not open the target file for writing.",
            L"JsonViewer — Save", MB_OK | MB_ICONERROR);
        return false;
    }
    DWORD written = 0;
    if (nbytes > 0) {
        if (!WriteFile(h, bytes, (DWORD)nbytes, &written, nullptr)
            || written != nbytes) {
            CloseHandle(h);
            MessageBoxW(ownerForDialog,
                L"Write failed.", L"JsonViewer — Save",
                MB_OK | MB_ICONERROR);
            return false;
        }
    }
    CloseHandle(h);
    return true;
}

// ---------------------------------------------------------------------------
// Container window proc
// ---------------------------------------------------------------------------
LRESULT CALLBACK DetailView::ContainerProc(HWND hwnd, UINT msg,
                                           WPARAM wp, LPARAM lp) {
    DetailView* self = (DetailView*)GetWindowLongPtrW(hwnd, GWLP_USERDATA);
    switch (msg) {
        case WM_NCCREATE: {
            CREATESTRUCT* cs = (CREATESTRUCT*)lp;
            SetWindowLongPtrW(hwnd, GWLP_USERDATA,
                              (LONG_PTR)cs->lpCreateParams);
            break;
        }
        case WM_SIZE:
            if (self) self->Layout();
            return 0;
        case WM_COMMAND: {
            if (self && HIWORD(wp) == BN_CLICKED) {
                int id = LOWORD(wp);
                if (id == 7001 || id == 7002 || id == 7003) {
                    self->OnToolbarCommand(id);
                    return 0;
                }
            }
            break;
        }
        case WM_NOTIFY: {
            NMHDR* hdr = (NMHDR*)lp;
            if (hdr && hdr->code == EN_LINK) {
                ENLINK* el = (ENLINK*)lp;
                if (el->msg == WM_LBUTTONUP) {
                    // Retrieve the clicked URL text and open with shell.
                    HWND edit = hdr->hwndFrom;
                    TEXTRANGEW tr = {};
                    wchar_t buf[2048];
                    tr.chrg = el->chrg;
                    tr.lpstrText = buf;
                    LRESULT n = SendMessageW(edit, EM_GETTEXTRANGE,
                                             0, (LPARAM)&tr);
                    if (n > 0) {
                        buf[(size_t)n < 2047 ? (size_t)n : 2047] = 0;
                        ShellExecuteW(hwnd, L"open", buf, nullptr, nullptr,
                                      SW_SHOWNORMAL);
                    }
                    return 1;
                }
            }
            break;
        }
        case WM_ERASEBKGND: {
            HDC dc = (HDC)wp;
            RECT r; GetClientRect(hwnd, &r);
            FillRect(dc, &r, GetSysColorBrush(COLOR_BTNFACE));
            return 1;
        }
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

// ---------------------------------------------------------------------------
// Image window proc — owner-drawn rendering with zoom + pan.
//
// UX:
//   - Initial state: show at 100% if it fits, otherwise scale to fit
//     (aspect-preserving). Small images DO NOT get upscaled by default.
//   - Mouse wheel: zoom in/out around cursor (1.25× per notch).
//   - Left-click drag: pan (when the image is bigger than the
//     viewport, or when zoomed in past auto-fit).
//   - Double-click: reset to auto-fit / 100%.
// ---------------------------------------------------------------------------
namespace {
    // Effective zoom given the "0 = auto" convention. `outFitting`
    // reports whether we're currently auto-fitting (used to decide
    // whether panning is even meaningful).
    double EffectiveZoom(double zoom, int bw, int bh, int cw, int ch,
                         bool* outFitting = nullptr) {
        if (zoom > 0.0) {
            if (outFitting) *outFitting = false;
            return zoom;
        }
        if (bw <= 0 || bh <= 0 || cw <= 0 || ch <= 0) {
            if (outFitting) *outFitting = true;
            return 1.0;
        }
        if (bw <= cw && bh <= ch) {
            if (outFitting) *outFitting = true;
            return 1.0;      // fits at native resolution — no scaling
        }
        double sx = (double)cw / bw;
        double sy = (double)ch / bh;
        if (outFitting) *outFitting = true;
        return sx < sy ? sx : sy;
    }
}

LRESULT CALLBACK DetailView::ImageProc(HWND hwnd, UINT msg,
                                       WPARAM wp, LPARAM lp) {
    DetailView* self = (DetailView*)GetWindowLongPtrW(hwnd, GWLP_USERDATA);
    switch (msg) {
        case WM_ERASEBKGND:
            // WM_PAINT does all painting into a memory DC, so we
            // never want the OS to fill the client with a solid
            // brush first (that's exactly what caused the pan
            // tearing before).
            return 1;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC dc = BeginPaint(hwnd, &ps);
            RECT r; GetClientRect(hwnd, &r);
            int cw = r.right, ch = r.bottom;
            if (cw > 0 && ch > 0) {
                // Double-buffer via a memory DC + bitmap. Everything
                // is composed off-screen, then blitted in one shot —
                // zero flicker regardless of how fast the user pans.
                HDC memDC = CreateCompatibleDC(dc);
                HBITMAP memBmp = CreateCompatibleBitmap(dc, cw, ch);
                HGDIOBJ oldBmp = SelectObject(memDC, memBmp);
                RECT full = { 0, 0, cw, ch };
                FillRect(memDC, &full, GetSysColorBrush(COLOR_WINDOW));

                if (self && self->bitmap_) {
                    auto* src = (Gdiplus::Bitmap*)self->bitmap_;
                    int bw = self->bitmapW_, bh = self->bitmapH_;
                    double zoom = EffectiveZoom(self->zoom_, bw, bh,
                                                cw, ch);
                    int sw = (int)(bw * zoom);
                    int sh = (int)(bh * zoom);
                    if (sw < 1) sw = 1;
                    if (sh < 1) sh = 1;

                    // Rebuild the scaled cache if zoom (or size)
                    // changed. This is the expensive step; keeping
                    // the cache means pan mouse-moves are just a
                    // fast native-size blit.
                    if (!self->scaledCache_
                        || self->cachedZoom_ != zoom
                        || self->cachedW_    != sw
                        || self->cachedH_    != sh) {
                        if (self->scaledCache_) {
                            delete (Gdiplus::Bitmap*)self->scaledCache_;
                            self->scaledCache_ = nullptr;
                        }
                        auto* cached = new Gdiplus::Bitmap(
                            sw, sh, PixelFormat32bppPARGB);
                        Gdiplus::Graphics gc(cached);
                        gc.SetInterpolationMode(
                            Gdiplus::InterpolationModeHighQualityBilinear);
                        gc.SetPixelOffsetMode(
                            Gdiplus::PixelOffsetModeHighQuality);
                        gc.DrawImage(src, 0, 0, sw, sh);
                        self->scaledCache_ = cached;
                        self->cachedZoom_  = zoom;
                        self->cachedW_     = sw;
                        self->cachedH_     = sh;
                    }
                    // Fast blit at native-size — no scaling, no
                    // interpolation. This is what makes pan smooth.
                    Gdiplus::Graphics g(memDC);
                    int dx = (cw - sw) / 2 + self->panX_;
                    int dy = (ch - sh) / 2 + self->panY_;
                    g.DrawImage((Gdiplus::Bitmap*)self->scaledCache_,
                                dx, dy);
                }
                BitBlt(dc, 0, 0, cw, ch, memDC, 0, 0, SRCCOPY);
                SelectObject(memDC, oldBmp);
                DeleteObject(memBmp);
                DeleteDC(memDC);
            }
            EndPaint(hwnd, &ps);
            return 0;
        }
        case WM_MOUSEWHEEL: {
            if (!self || !self->bitmap_) break;
            RECT r; GetClientRect(hwnd, &r);
            int cw = r.right, ch = r.bottom;
            int bw = self->bitmapW_, bh = self->bitmapH_;
            double oldZoom = EffectiveZoom(self->zoom_, bw, bh, cw, ch);

            POINT pt = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
            ScreenToClient(hwnd, &pt);

            int delta = GET_WHEEL_DELTA_WPARAM(wp);
            double step = (delta > 0) ? 1.25 : 1.0 / 1.25;
            double newZoom = oldZoom * step;
            if (newZoom < 0.05) newZoom = 0.05;
            if (newZoom > 32.0) newZoom = 32.0;

            // Zoom around cursor: keep the image point under the
            // cursor stationary after zoom.
            double imgX = (pt.x - cw / 2.0 - self->panX_) / oldZoom;
            double imgY = (pt.y - ch / 2.0 - self->panY_) / oldZoom;
            self->zoom_ = newZoom;
            self->panX_ = (int)(pt.x - cw / 2.0 - imgX * newZoom);
            self->panY_ = (int)(pt.y - ch / 2.0 - imgY * newZoom);
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        case WM_LBUTTONDOWN: {
            if (!self || !self->bitmap_) break;
            SetFocus(hwnd);
            SetCapture(hwnd);
            self->panDragging_ = true;
            self->panDragStart_ = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
            self->panDragOrigX_ = self->panX_;
            self->panDragOrigY_ = self->panY_;
            return 0;
        }
        case WM_MOUSEMOVE: {
            if (!self || !self->panDragging_) break;
            int mx = GET_X_LPARAM(lp);
            int my = GET_Y_LPARAM(lp);
            self->panX_ = self->panDragOrigX_ +
                          (mx - self->panDragStart_.x);
            self->panY_ = self->panDragOrigY_ +
                          (my - self->panDragStart_.y);
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        case WM_LBUTTONUP: {
            if (self && self->panDragging_) {
                self->panDragging_ = false;
                ReleaseCapture();
            }
            return 0;
        }
        case WM_LBUTTONDBLCLK: {
            if (!self) break;
            self->zoom_ = 0.0;
            self->panX_ = self->panY_ = 0;
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        case WM_SETCURSOR: {
            if (!self || !self->bitmap_) break;
            RECT r; GetClientRect(hwnd, &r);
            double zoom = EffectiveZoom(self->zoom_,
                                        self->bitmapW_, self->bitmapH_,
                                        r.right, r.bottom);
            bool pannable = ((int)(self->bitmapW_ * zoom) > r.right)
                         || ((int)(self->bitmapH_ * zoom) > r.bottom);
            LPCWSTR c = pannable ? IDC_SIZEALL : IDC_ARROW;
            SetCursor(LoadCursor(nullptr, c));
            return TRUE;
        }
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

} // namespace jv
