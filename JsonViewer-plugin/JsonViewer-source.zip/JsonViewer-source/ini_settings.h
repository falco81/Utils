// Simple INI persistence for the JsonViewer plugin. Lives at a path
// TC gives us via ListSetDefaultParams (typically %APPDATA%\GHISLER\)
// or, as a fallback, next to the DLL.
#pragma once

#include <string>

namespace jv {

struct IniSettings {
    // Layout
    int  splitPosition   = 40;     // % width of left tree pane
    int  fontSize        = 14;     // Detail-panel font size
    bool wrapDetailText  = true;   // Wrap long strings in detail

    // Behaviour
    bool rememberWinSize = true;
    bool maximizeOnOpen  = false;
    int  autoExpandDepth = 2;      // 0=only root, 1..N=expand N levels
    bool decodeImages    = true;   // Auto-render base64 image data URLs

    // Persisted window placement (of TC's Lister top-level window).
    int  lastWinX = -1, lastWinY = -1;
    int  lastWinW = -1, lastWinH = -1;
    bool lastWinMax = false;

    void Load(const std::wstring& iniPath);
    void SaveOptions(const std::wstring& iniPath) const;
    void SaveWindowState(const std::wstring& iniPath) const;
};

} // namespace jv
