#include "ini_settings.h"

#include <windows.h>
#include <string>

namespace jv {

static const wchar_t* kSection = L"JsonViewer";

static int  ReadInt (const wchar_t* key, int def, const std::wstring& p) {
    return GetPrivateProfileIntW(kSection, key, def, p.c_str());
}
static bool ReadBool(const wchar_t* key, const wchar_t* def,
                     const std::wstring& p) {
    wchar_t buf[8] = {};
    GetPrivateProfileStringW(kSection, key, def, buf, 8, p.c_str());
    return (buf[0] == L'1' || buf[0] == L'y' || buf[0] == L'Y'
                            || buf[0] == L't' || buf[0] == L'T');
}
static void WriteInt(const wchar_t* key, int v, const std::wstring& p) {
    wchar_t buf[32];
    swprintf(buf, 32, L"%d", v);
    WritePrivateProfileStringW(kSection, key, buf, p.c_str());
}
static void WriteBool(const wchar_t* key, bool v, const std::wstring& p) {
    WritePrivateProfileStringW(kSection, key, v ? L"1" : L"0", p.c_str());
}

void IniSettings::Load(const std::wstring& iniPath) {
    if (iniPath.empty()) return;

    splitPosition   = ReadInt (L"SplitPosition",    40,  iniPath);
    fontSize        = ReadInt (L"FontSize",         14,  iniPath);
    wrapDetailText  = ReadBool(L"WrapDetailText",   L"1", iniPath);

    rememberWinSize = ReadBool(L"RememberWindowSize", L"1", iniPath);
    maximizeOnOpen  = ReadBool(L"MaximizeOnOpen",     L"0", iniPath);
    autoExpandDepth = ReadInt (L"AutoExpandDepth",    2,   iniPath);
    decodeImages    = ReadBool(L"DecodeImages",       L"1", iniPath);

    lastWinX        = ReadInt (L"LastWinX",  -1, iniPath);
    lastWinY        = ReadInt (L"LastWinY",  -1, iniPath);
    lastWinW        = ReadInt (L"LastWinW",  -1, iniPath);
    lastWinH        = ReadInt (L"LastWinH",  -1, iniPath);
    lastWinMax      = ReadBool(L"LastWinMaximized", L"0", iniPath);

    // Clamp.
    if (fontSize < 8)  fontSize = 8;
    if (fontSize > 32) fontSize = 32;
    if (splitPosition < 15)  splitPosition = 15;
    if (splitPosition > 85)  splitPosition = 85;
    if (autoExpandDepth < 0) autoExpandDepth = 0;
    if (autoExpandDepth > 10) autoExpandDepth = 10;
}

void IniSettings::SaveOptions(const std::wstring& iniPath) const {
    if (iniPath.empty()) return;

    WriteInt (L"SplitPosition",     splitPosition,   iniPath);
    WriteInt (L"FontSize",          fontSize,        iniPath);
    WriteBool(L"WrapDetailText",    wrapDetailText,  iniPath);

    WriteBool(L"RememberWindowSize", rememberWinSize, iniPath);
    WriteBool(L"MaximizeOnOpen",     maximizeOnOpen,  iniPath);
    WriteInt (L"AutoExpandDepth",    autoExpandDepth, iniPath);
    WriteBool(L"DecodeImages",       decodeImages,    iniPath);
}

void IniSettings::SaveWindowState(const std::wstring& iniPath) const {
    if (iniPath.empty()) return;

    WriteInt (L"LastWinX", lastWinX, iniPath);
    WriteInt (L"LastWinY", lastWinY, iniPath);
    WriteInt (L"LastWinW", lastWinW, iniPath);
    WriteInt (L"LastWinH", lastWinH, iniPath);
    WriteBool(L"LastWinMaximized", lastWinMax, iniPath);
}

} // namespace jv
