// TreeModel wraps a parsed JSON document and manages the mapping to
// Win32 TreeView items. Population is lazy — a node's children are
// created only when the user expands it. This keeps files with
// thousands of items (e.g. subtitle cues) responsive.
#pragma once

#include "json.h"

#include <windows.h>
#include <commctrl.h>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace jv {

struct NodeInfo {
    const mj::Json*   value  = nullptr;    // pointer into the parsed doc
    std::string       key;                 // "" for array items / root
    int               indexInParent = -1;  // >= 0 for array items
    HTREEITEM         parentItem = nullptr;
    HTREEITEM         self       = nullptr;
    bool              populated  = false;  // children already added?
};

class TreeModel {
public:
    // Parse the JSON text. Returns empty string on success, or an
    // error message describing the parse failure.
    std::string LoadFromUtf8(std::string utf8);

    // Attach to an already-created TreeView control and populate it
    // with the root. autoExpandDepth = 0 shows only the root row.
    void PopulateInto(HWND hTree, int autoExpandDepth);

    // Called from TVN_ITEMEXPANDING (before expansion) to lazily
    // create children for `item`.
    void OnExpanding(HWND hTree, HTREEITEM item);

    // Return NodeInfo for a TreeView item. Never null when the item
    // was created by us.
    const NodeInfo* Info(HTREEITEM item) const;

    // Build a JSONPath-like string ("$.cues[3].face") for the item.
    std::string PathFor(HTREEITEM item) const;

    // Find the next TreeView item (breadth-first from `startAfter`)
    // whose key contains `needle` (UTF-8, case-insensitive) or whose
    // scalar string value contains `needle`. Returns nullptr if none.
    // Guarantees the path is fully expanded so the item is visible.
    HTREEITEM FindNext(HWND hTree, HTREEITEM startAfter,
                       const std::string& needle,
                       bool searchKeys, bool searchValues,
                       bool wrap);

    // Collapse all nodes deeper than `keepDepth` (root == 0).
    void CollapseToDepth(HWND hTree, int keepDepth);

    // Expand every currently-populated node.
    void ExpandAll(HWND hTree);

    // The parsed document (may be null on parse failure).
    const mj::Json* Root() const { return doc_ ? doc_.get() : nullptr; }

    // Storage: source text (for re-parsing after edits, future).
    const std::string& SourceUtf8() const { return source_; }

private:
    std::unique_ptr<mj::Json>           doc_;
    std::string                         source_;
    std::unordered_map<HTREEITEM, NodeInfo> map_;
    HTREEITEM                           rootItem_ = nullptr;

    // Insert a single row and return its HTREEITEM.
    HTREEITEM InsertNode(HWND hTree, HTREEITEM parent, HTREEITEM after,
                         const mj::Json& value,
                         const std::string& key, int indexInParent);

    // Insert direct children of `parentItem` into the tree.
    void PopulateChildren(HWND hTree, HTREEITEM parentItem);

    // Recursively (up to depth) expand children.
    void ExpandRecursive(HWND hTree, HTREEITEM item, int remainingDepth);

    // Recursively collapse anything with depth > keepDepth.
    void CollapseRecursive(HWND hTree, HTREEITEM item,
                           int currentDepth, int keepDepth);
};

// Compose the display label for a JSON node:
//   dict {5 keys}        for objects
//   list [12 items]      for arrays
//   "key": <value>       otherwise
// The `value` shown for primitives is truncated so the tree row stays
// short. Bytes are UTF-16 for TreeView consumption.
std::wstring MakeLabel(const std::string& key,
                       int indexInParent,
                       const mj::Json& value,
                       int maxValueChars = 80);

} // namespace jv
