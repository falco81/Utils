// Minimal Base64 decoder for `data:image/...;base64,...` URLs found
// in JSON values. Skips whitespace and returns the raw bytes.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace jv {

// Decode a base64 string into raw bytes. Whitespace and '=' padding
// are handled. Returns true on success. On invalid input returns
// false and leaves `out` in an unspecified state.
bool DecodeBase64(const char* data, size_t len, std::vector<uint8_t>& out);

// If `s` starts with "data:<mime>;base64,<payload>", split out the
// mime and decode the payload. Returns true on success. On any
// mismatch returns false and leaves outputs empty.
bool ParseDataUrl(const std::string& s,
                  std::string& mimeOut,
                  std::vector<uint8_t>& bytesOut);

// Heuristic: does the string look like a data-URL for an image
// (data:image/*;base64,...)?
bool LooksLikeImageDataUrl(const std::string& s);

// True for ANY base64 data URL (data:<mime>;base64,...) — image,
// audio, video, PDF, plain text, unknown binary, whatever. Cheap
// prefix check; safe to call on every string node in a large tree.
bool LooksLikeDataUrl(const std::string& s);

// Fast MIME extractor. Parses only the header ("data:<mime>;base64")
// without decoding the payload. The tree walk needs this for
// hundreds/thousands of nodes without paying the base64 tax on each.
bool GetDataUrlMime(const std::string& s, std::string& mimeOut);

// Map a MIME type ("image/jpeg", "application/pdf", …) to a plausible
// filename extension (".jpg", ".pdf", …). Returns ".bin" for
// unknown MIMEs so Save-as-file always yields *something* sensible.
std::string MimeToExtension(const std::string& mime);

} // namespace jv
