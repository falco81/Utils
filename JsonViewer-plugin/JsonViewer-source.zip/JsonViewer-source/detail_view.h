// DetailView is the right pane. Given a selected JSON node it shows:
//   - a small header (type badge, path, size)
//   - a body that adapts to the node:
//       * image  → decoded bitmap (GDI+)
//       * string → text (URLs/emails auto-detected & clickable)
//       * numbers → value + (optionally) timestamp interpretation
//       * bool/null → value
//       * object/array → summary + list of keys / first N items
#pragma once

#include "json.h"

#include <windows.h>
#include <string>
#include <vector>

namespace jv {

struct DetailStyle {
    int  fontSize      = 14;
    bool wrap          = true;
    bool decodeImages  = true;
};

class DetailView {
public:
    DetailView() = default;
    ~DetailView();

    // Create the composite window (a container that in turn owns a
    // header label, an EDIT for text/summary content, and a paint
    // area for images).
    HWND Create(HWND parent, HINSTANCE hInst);

    HWND Hwnd() const { return hWnd_; }

    // Reposition inside the parent.
    void Resize(int x, int y, int w, int h);

    // Update the pane to reflect the given node. `path` is displayed
    // in the header. If value is null the pane blanks out.
    void ShowNode(const std::string& path, const mj::Json* value);

    // Style / options.
    void SetStyle(const DetailStyle& s);

    // Copy helpers (invoked from the host).
    std::string CurrentValueAsText() const;      // current node value

    // True when the current selection is a base64 data URL (any MIME).
    // The host uses this to enable the "Save as file..." context
    // menu item on the tree.
    bool IsCurrentDataUrl() const { return currentIsDataUrl_; }

    // Prompt for a filename and write the decoded data URL bytes,
    // or (for plain-text selections) the raw string as UTF-8. No-op
    // when there is nothing to save. Returns true on successful save.
    bool SaveCurrentToFile(HWND ownerForDialog);

    // Public because RegisterClasses() (a free function outside the
    // class) needs to install them as WNDCLASSEX.lpfnWndProc.
    static LRESULT CALLBACK ContainerProc(HWND h, UINT msg,
                                          WPARAM wp, LPARAM lp);
    static LRESULT CALLBACK ImageProc(HWND h, UINT msg,
                                      WPARAM wp, LPARAM lp);

private:
    HWND      hWnd_       = nullptr;
    HWND      hHeader_    = nullptr;
    HWND      hText_      = nullptr;   // multi-line EDIT (Rich w/ URLs)
    HWND      hImage_     = nullptr;   // ownerdrawn STATIC for images

    // Small toolbar row visible when the current node is a data URL:
    //   [Rendered]  [Raw]     [Save as…]
    // Two BS_AUTORADIOBUTTON | BS_PUSHLIKE for the mode toggle plus
    // one BS_PUSHBUTTON. Hidden when the selection isn't a data URL.
    HWND      hBtnRendered_ = nullptr;
    HWND      hBtnRaw_      = nullptr;
    HWND      hBtnSave_     = nullptr;

    HFONT     hFontUi_    = nullptr;
    HFONT     hFontMono_  = nullptr;

    // Image state.
    void*     bitmap_     = nullptr;   // GdiPlus::Bitmap*
    int       bitmapW_    = 0;
    int       bitmapH_    = 0;

    // Pre-scaled bitmap cache — populated on first paint at each
    // zoom level, invalidated when zoom / image changes. Panning
    // then reduces to a plain blit which is essentially free.
    void*     scaledCache_  = nullptr; // GdiPlus::Bitmap*
    double    cachedZoom_   = -1.0;
    int       cachedW_      = 0;
    int       cachedH_      = 0;

    // Zoom & pan state. zoom_ = 0 means auto-fit (used on freshly
    // loaded images). Non-zero means the user has explicitly zoomed.
    // panX_/panY_ shift the drawn image in screen pixels from
    // centred.
    double    zoom_       = 0.0;
    int       panX_       = 0;
    int       panY_       = 0;
    // Panning drag state.
    bool      panDragging_    = false;
    POINT     panDragStart_   = {};
    int       panDragOrigX_   = 0;
    int       panDragOrigY_   = 0;

    DetailStyle       style_;
    std::string       currentText_;         // current node value as text
    std::string       currentPath_;         // JSON path of selection
    // Currently-loaded string (raw source, i.e. the *actual* value).
    // For a data URL this is the whole "data:..." string; for plain
    // text it's the string itself.
    std::string       currentRawString_;
    bool              currentIsDataUrl_ = false;
    std::string       currentDataMime_;
    std::vector<uint8_t> currentDataBytes_;
    bool              showRaw_          = false;   // user toggled to raw
    // Remember the last selected node so mode toggles can re-render.
    const mj::Json*   currentValue_     = nullptr;

    void DisposeBitmap();
    void RebuildFonts();
    void ShowImage(const std::vector<uint8_t>& bytes,
                   const std::string& mime);
    void ShowTextEdit(const std::wstring& text);
    void UpdateHeader(const std::string& path, const mj::Json* value);
    void Layout();
    // Called from container's WM_COMMAND when a toolbar button is
    // clicked.
    void OnToolbarCommand(int id);
    // Refresh the content pane after showRaw_ flipped.
    void RerenderCurrent();
};

} // namespace jv
