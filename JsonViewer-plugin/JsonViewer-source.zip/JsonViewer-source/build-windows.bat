@echo off
REM Windows build via MSYS2. Adjust the paths if you installed MSYS2
REM somewhere other than C:\msys64. Requires both mingw-w64-{i686,x86_64}
REM toolchains.
setlocal
if not defined MSYS2 set MSYS2=C:\msys64
set OLDPATH=%PATH%
set PATH=%MSYS2%\mingw64\bin;%MSYS2%\mingw32\bin;%MSYS2%\usr\bin;%PATH%
where mingw32-make >nul 2>nul
if errorlevel 1 (
    echo mingw32-make not found. Install MSYS2 mingw-w64-x86_64-toolchain.
    exit /b 1
)
mingw32-make clean
mingw32-make all
if errorlevel 1 goto :fail
echo.
echo Built:
dir /b jsonviewer.wlx jsonviewer.wlx64 JsonViewer-plugin.zip
goto :end
:fail
echo Build failed.
exit /b 1
:end
set PATH=%OLDPATH%
