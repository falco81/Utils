#include "tree_model.h"
#include "base64.h"

#include <commctrl.h>
#include <cwchar>
#include <cwctype>
#include <algorithm>
#include <cctype>

namespace jv {

// ---------------------------------------------------------------------------
// UTF-8 <-> UTF-16 helpers
// ---------------------------------------------------------------------------
static std::wstring U8ToW(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(),
                                nullptr, 0);
    std::wstring r(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), r.data(), n);
    return r;
}
static std::string WToU8(const std::wstring& s) {
    if (s.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(),
                                nullptr, 0, nullptr, nullptr);
    std::string r(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(),
                        r.data(), n, nullptr, nullptr);
    return r;
}

// Lowercase ASCII only — good enough for case-insensitive JSON search.
static std::string LowerAscii(const std::string& s) {
    std::string r = s;
    for (auto& c : r) {
        if (c >= 'A' && c <= 'Z') c += 32;
    }
    return r;
}

// ---------------------------------------------------------------------------
// Label formatting
// ---------------------------------------------------------------------------
static std::wstring PrimitiveText(const mj::Json& v, int maxChars) {
    using K = mj::JKind;
    switch (v.Kind()) {
        case K::Null:  return L"null";
        case K::Bool:  return v.AsBool() ? L"true" : L"false";
        case K::Int: {
            wchar_t buf[32]; swprintf(buf, 32, L"%lld",
                                      (long long)v.AsInt());
            return buf;
        }
        case K::Real: {
            wchar_t buf[64];
            double d = v.AsReal();
            // Prefer compact representation; %g strips trailing zeros.
            swprintf(buf, 64, L"%g", d);
            return buf;
        }
        case K::Str: {
            const std::string& s = v.AsStr();
            // Image data URLs get an obvious label instead of first 80 chars
            // of base64 gibberish.
            if (LooksLikeImageDataUrl(s)) {
                wchar_t buf[64];
                std::string mime;
                std::vector<uint8_t> _dummy;
                (void)ParseDataUrl(s, mime, _dummy);
                if (mime.empty()) mime = "image";
                swprintf(buf, 64, L"[%hs image, %zu chars]",
                         mime.c_str(), s.size());
                return buf;
            }
            std::wstring w = U8ToW(s);
            if ((int)w.size() > maxChars) {
                w.resize(maxChars);
                w += L"…";
            }
            // Collapse newlines for the tree row.
            for (auto& c : w) if (c == L'\n' || c == L'\r') c = L' ';
            std::wstring quoted = L"\"" + w + L"\"";
            return quoted;
        }
        default: return L"";
    }
}

std::wstring MakeLabel(const std::string& key,
                       int indexInParent,
                       const mj::Json& value,
                       int maxValueChars) {
    using K = mj::JKind;
    std::wstring prefix;
    if (!key.empty()) {
        prefix = L"\"" + U8ToW(key) + L"\": ";
    } else if (indexInParent >= 0) {
        wchar_t buf[24]; swprintf(buf, 24, L"[%d]: ", indexInParent);
        prefix = buf;
    }

    if (value.Kind() == K::Obj) {
        size_t n = value.AsObj().size();
        wchar_t buf[64]; swprintf(buf, 64, L"{%zu %ls}", n,
                                  n == 1 ? L"key" : L"keys");
        return prefix + buf;
    }
    if (value.Kind() == K::Arr) {
        size_t n = value.AsArr().size();
        wchar_t buf[64]; swprintf(buf, 64, L"[%zu %ls]", n,
                                  n == 1 ? L"item" : L"items");
        return prefix + buf;
    }
    return prefix + PrimitiveText(value, maxValueChars);
}

// ---------------------------------------------------------------------------
// Load / parse
// ---------------------------------------------------------------------------
std::string TreeModel::LoadFromUtf8(std::string utf8) {
    source_ = std::move(utf8);
    doc_.reset();
    // Strip UTF-8 BOM.
    size_t start = 0;
    if (source_.size() >= 3
        && (unsigned char)source_[0] == 0xEF
        && (unsigned char)source_[1] == 0xBB
        && (unsigned char)source_[2] == 0xBF) {
        start = 3;
    }
    try {
        std::string body = (start == 0)
            ? source_
            : source_.substr(start);
        mj::Json parsed = mj::Parse(body);
        doc_ = std::make_unique<mj::Json>(std::move(parsed));
    } catch (const std::exception& e) {
        return e.what();
    }
    return {};
}

// ---------------------------------------------------------------------------
// TreeView population (lazy)
// ---------------------------------------------------------------------------
HTREEITEM TreeModel::InsertNode(HWND hTree, HTREEITEM parent, HTREEITEM after,
                                const mj::Json& value,
                                const std::string& key,
                                int indexInParent) {
    std::wstring label = MakeLabel(key, indexInParent, value);
    TVINSERTSTRUCTW ins = {};
    ins.hParent      = parent;
    ins.hInsertAfter = after ? after : TVI_LAST;
    ins.item.mask    = TVIF_TEXT | TVIF_CHILDREN | TVIF_PARAM;
    ins.item.pszText = label.data();
    // "cChildren = 1" adds the [+] expand button. We use I_CHILDRENCALLBACK
    // for containers to let the OS ask us at draw time.
    bool hasKids = (value.Kind() == mj::JKind::Obj && !value.AsObj().empty())
                || (value.Kind() == mj::JKind::Arr && !value.AsArr().empty());
    ins.item.cChildren = hasKids ? 1 : 0;
    HTREEITEM h = TreeView_InsertItem(hTree, &ins);
    if (!h) return nullptr;

    NodeInfo n;
    n.value         = &value;
    n.key           = key;
    n.indexInParent = indexInParent;
    n.parentItem    = parent;
    n.self          = h;
    n.populated     = !hasKids;    // leaves are trivially "populated"
    map_[h] = std::move(n);
    return h;
}

void TreeModel::PopulateChildren(HWND hTree, HTREEITEM parentItem) {
    auto it = map_.find(parentItem);
    if (it == map_.end() || it->second.populated) return;
    const mj::Json* v = it->second.value;
    if (!v) return;

    if (v->Kind() == mj::JKind::Obj) {
        const auto& obj = v->AsObj();
        for (size_t i = 0; i < obj.size(); ++i) {
            InsertNode(hTree, parentItem, nullptr,
                       obj[i].second, obj[i].first, -1);
        }
    } else if (v->Kind() == mj::JKind::Arr) {
        const auto& arr = v->AsArr();
        for (size_t i = 0; i < arr.size(); ++i) {
            InsertNode(hTree, parentItem, nullptr, arr[i], "", (int)i);
        }
    }
    // Note: iterator `it` may have been invalidated by unordered_map
    // rehash from InsertNode. Re-lookup before writing.
    auto& info = map_[parentItem];
    info.populated = true;
}

void TreeModel::PopulateInto(HWND hTree, int autoExpandDepth) {
    TreeView_DeleteAllItems(hTree);
    map_.clear();
    rootItem_ = nullptr;
    if (!doc_) return;

    rootItem_ = InsertNode(hTree, TVI_ROOT, nullptr, *doc_, "root", -1);
    if (!rootItem_) return;

    // Expand progressively so the user sees something without having
    // to click. Depth 2 covers most files well.
    if (autoExpandDepth > 0) {
        ExpandRecursive(hTree, rootItem_, autoExpandDepth);
    }
    TreeView_SelectItem(hTree, rootItem_);
}

void TreeModel::ExpandRecursive(HWND hTree, HTREEITEM item, int remainingDepth) {
    if (!item || remainingDepth <= 0) return;
    PopulateChildren(hTree, item);
    TreeView_Expand(hTree, item, TVE_EXPAND);
    HTREEITEM c = TreeView_GetChild(hTree, item);
    while (c) {
        ExpandRecursive(hTree, c, remainingDepth - 1);
        c = TreeView_GetNextSibling(hTree, c);
    }
}

void TreeModel::OnExpanding(HWND hTree, HTREEITEM item) {
    PopulateChildren(hTree, item);
}

const NodeInfo* TreeModel::Info(HTREEITEM item) const {
    auto it = map_.find(item);
    return (it == map_.end()) ? nullptr : &it->second;
}

// ---------------------------------------------------------------------------
// Path composition
// ---------------------------------------------------------------------------
std::string TreeModel::PathFor(HTREEITEM item) const {
    if (!item) return "";
    // Build in reverse.
    std::vector<std::string> parts;
    HTREEITEM cur = item;
    while (cur) {
        auto it = map_.find(cur);
        if (it == map_.end()) break;
        const NodeInfo& n = it->second;
        if (n.parentItem == nullptr) break;    // stop *before* pseudo-root
        if (n.indexInParent >= 0) {
            char buf[24]; snprintf(buf, 24, "[%d]", n.indexInParent);
            parts.push_back(buf);
        } else if (!n.key.empty()) {
            // Bracket-quote keys with special chars, else use dot form.
            bool safe = true;
            for (char c : n.key) {
                if (!(isalnum((unsigned char)c) || c == '_')) {
                    safe = false; break;
                }
            }
            if (safe) parts.push_back("." + n.key);
            else       parts.push_back("[\"" + n.key + "\"]");
        }
        cur = n.parentItem;
    }
    std::string out = "$";
    for (auto it = parts.rbegin(); it != parts.rend(); ++it) out += *it;
    return out;
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

// Traverse the in-memory JSON depth-first, returning nodes visited in
// order. We compare against `needle`; on match we return the path
// through JSON, then walk the tree following that path (populating
// as necessary) to find the corresponding HTREEITEM.
namespace {
    struct MatchPath {
        std::vector<std::pair<std::string,int>> steps; // (key, index)
    };

    bool DfsFind(const mj::Json& node,
                 const std::string& needleLower,
                 bool searchKeys, bool searchValues,
                 MatchPath& current,
                 std::vector<MatchPath>& allHits) {
        // Test scalar values.
        if (searchValues) {
            if (node.Kind() == mj::JKind::Str) {
                std::string lo = LowerAscii(node.AsStr());
                if (lo.find(needleLower) != std::string::npos) {
                    allHits.push_back(current);
                }
            } else if (node.Kind() == mj::JKind::Int
                    || node.Kind() == mj::JKind::Real
                    || node.Kind() == mj::JKind::Bool) {
                // Render to text and compare.
                char buf[64];
                if (node.Kind() == mj::JKind::Int) {
                    snprintf(buf, 64, "%lld", (long long)node.AsInt());
                } else if (node.Kind() == mj::JKind::Real) {
                    snprintf(buf, 64, "%g", node.AsReal());
                } else {
                    snprintf(buf, 64, "%s", node.AsBool() ? "true" : "false");
                }
                std::string lo = LowerAscii(buf);
                if (lo.find(needleLower) != std::string::npos) {
                    allHits.push_back(current);
                }
            }
        }
        // Recurse.
        if (node.Kind() == mj::JKind::Obj) {
            for (const auto& kv : node.AsObj()) {
                if (searchKeys) {
                    std::string lo = LowerAscii(kv.first);
                    if (lo.find(needleLower) != std::string::npos) {
                        current.steps.push_back({kv.first, -1});
                        allHits.push_back(current);
                        current.steps.pop_back();
                    }
                }
                current.steps.push_back({kv.first, -1});
                DfsFind(kv.second, needleLower,
                        searchKeys, searchValues, current, allHits);
                current.steps.pop_back();
            }
        } else if (node.Kind() == mj::JKind::Arr) {
            const auto& arr = node.AsArr();
            for (size_t i = 0; i < arr.size(); ++i) {
                current.steps.push_back({"", (int)i});
                DfsFind(arr[i], needleLower,
                        searchKeys, searchValues, current, allHits);
                current.steps.pop_back();
            }
        }
        return false;
    }
} // anon

// Find the HTREEITEM sitting at the given (key,index) path from the
// root, populating on the way as needed. Returns nullptr on
// mismatch (shouldn't happen for a path derived from our own doc).
static HTREEITEM ResolvePath(HWND hTree, TreeModel* self,
                             HTREEITEM rootItem,
                             const MatchPath& p) {
    HTREEITEM cur = rootItem;
    for (const auto& step : p.steps) {
        self->OnExpanding(hTree, cur);           // populate children
        HTREEITEM c = TreeView_GetChild(hTree, cur);
        while (c) {
            const NodeInfo* n = self->Info(c);
            if (n) {
                if (step.second >= 0) {
                    if (n->indexInParent == step.second) break;
                } else {
                    if (n->key == step.first) break;
                }
            }
            c = TreeView_GetNextSibling(hTree, c);
        }
        if (!c) return nullptr;
        cur = c;
    }
    return cur;
}

HTREEITEM TreeModel::FindNext(HWND hTree, HTREEITEM startAfter,
                              const std::string& needle,
                              bool searchKeys, bool searchValues,
                              bool wrap) {
    if (!doc_ || !rootItem_ || needle.empty()) return nullptr;
    std::vector<MatchPath> hits;
    MatchPath cur;
    (void)DfsFind(*doc_, LowerAscii(needle),
                  searchKeys, searchValues, cur, hits);
    if (hits.empty()) return nullptr;

    // Where is `startAfter` in DFS order? We match by resolving each
    // hit to an HTREEITEM until we get past `startAfter`.
    // For simplicity: iterate hits, resolve, remember the first
    // HTREEITEM after the currently-focused item (if any).
    HTREEITEM firstMatch = nullptr;
    HTREEITEM afterMatch = nullptr;
    bool passed = (startAfter == nullptr);
    for (const auto& mp : hits) {
        HTREEITEM h = ResolvePath(hTree, this, rootItem_, mp);
        if (!h) continue;
        if (!firstMatch) firstMatch = h;
        if (passed) {
            if (h != startAfter) {
                afterMatch = h;
                break;
            }
        }
        if (h == startAfter) passed = true;
    }
    HTREEITEM chosen = afterMatch;
    if (!chosen && wrap) chosen = firstMatch;
    if (chosen) {
        // Make sure the path is expanded (Resolve populated, but not
        // necessarily expanded).
        HTREEITEM p = TreeView_GetParent(hTree, chosen);
        while (p) { TreeView_Expand(hTree, p, TVE_EXPAND);
                    p = TreeView_GetParent(hTree, p); }
        TreeView_EnsureVisible(hTree, chosen);
        TreeView_SelectItem(hTree, chosen);
    }
    return chosen;
}

// ---------------------------------------------------------------------------
// Collapse / expand
// ---------------------------------------------------------------------------
void TreeModel::CollapseRecursive(HWND hTree, HTREEITEM item,
                                  int currentDepth, int keepDepth) {
    if (!item) return;
    HTREEITEM c = TreeView_GetChild(hTree, item);
    // Leaf: whether expanded or collapsed makes no visual difference
    // and calling TreeView_Expand just wastes a SendMessage. For a
    // file like gender_report with 1147 cue entries, skipping these
    // is the difference between "instant" and "a second of freeze".
    if (!c) return;
    while (c) {
        CollapseRecursive(hTree, c, currentDepth + 1, keepDepth);
        c = TreeView_GetNextSibling(hTree, c);
    }
    if (currentDepth > keepDepth) {
        TreeView_Expand(hTree, item, TVE_COLLAPSE);
    } else {
        TreeView_Expand(hTree, item, TVE_EXPAND);
    }
}

// RAII helper: freeze the tree's repaints for the duration of a bulk
// operation. Without this every InsertItem / Expand triggers a
// partial repaint, which is what makes level 1/2/3 buttons feel
// glacially slow on large files.
namespace {
    struct FreezeRedraw {
        HWND h; HCURSOR oldCur;
        FreezeRedraw(HWND w)
            : h(w),
              oldCur(SetCursor(LoadCursor(nullptr, IDC_WAIT))) {
            SendMessageW(h, WM_SETREDRAW, FALSE, 0);
        }
        ~FreezeRedraw() {
            SendMessageW(h, WM_SETREDRAW, TRUE, 0);
            RedrawWindow(h, nullptr, nullptr,
                         RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN);
            SetCursor(oldCur);
        }
    };
}

void TreeModel::CollapseToDepth(HWND hTree, int keepDepth) {
    if (!rootItem_) return;
    FreezeRedraw freeze(hTree);
    ExpandRecursive(hTree, rootItem_, keepDepth);
    CollapseRecursive(hTree, rootItem_, 0, keepDepth);
    TreeView_EnsureVisible(hTree, rootItem_);
}

void TreeModel::ExpandAll(HWND hTree) {
    if (!rootItem_) return;
    // For huge documents this can be slow (all 1147 cues get inserted).
    // We cap at a reasonable depth to avoid runaway.
    FreezeRedraw freeze(hTree);
    ExpandRecursive(hTree, rootItem_, 8);
}

} // namespace jv
