#include "base64.h"

#include <cctype>
#include <cstring>

namespace jv {

// Standard base64 alphabet lookup. 255 = invalid.
static const uint8_t* B64Table() {
    static uint8_t t[256];
    static bool inited = false;
    if (!inited) {
        for (int i = 0; i < 256; ++i) t[i] = 255;
        const char* alpha =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        for (int i = 0; i < 64; ++i) t[(unsigned char)alpha[i]] = (uint8_t)i;
        // URL-safe variants — some producers use these; harmless to accept.
        t[(unsigned char)'-'] = 62;
        t[(unsigned char)'_'] = 63;
        inited = true;
    }
    return t;
}

bool DecodeBase64(const char* data, size_t len,
                  std::vector<uint8_t>& out) {
    const uint8_t* tab = B64Table();
    out.clear();
    out.reserve((len * 3) / 4 + 4);
    uint32_t buf = 0;
    int bits = 0;
    for (size_t i = 0; i < len; ++i) {
        unsigned char c = (unsigned char)data[i];
        if (c == '=') break;                // padding — stop here
        if (c == '\r' || c == '\n' || c == ' ' || c == '\t') continue;
        uint8_t v = tab[c];
        if (v == 255) return false;         // stray char
        buf = (buf << 6) | v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back((uint8_t)((buf >> bits) & 0xFF));
        }
    }
    return true;
}

bool ParseDataUrl(const std::string& s,
                  std::string& mimeOut,
                  std::vector<uint8_t>& bytesOut) {
    mimeOut.clear();
    bytesOut.clear();
    // Expected shape: data:<mime>;base64,<payload>
    if (s.size() < 12) return false;
    if (s.compare(0, 5, "data:") != 0) return false;
    size_t semi = s.find(';', 5);
    if (semi == std::string::npos) return false;
    // Accept `;base64` OR `;charset=...;base64`. Locate the base64 tag.
    size_t b64 = s.find(";base64", semi);
    if (b64 == std::string::npos) return false;
    size_t comma = s.find(',', b64);
    if (comma == std::string::npos) return false;
    mimeOut = s.substr(5, semi - 5);
    const char* payload = s.data() + comma + 1;
    size_t plen = s.size() - (comma + 1);
    return DecodeBase64(payload, plen, bytesOut);
}

bool LooksLikeImageDataUrl(const std::string& s) {
    // Cheap prefix check — avoids scanning huge strings when we're
    // just deciding whether to try the full parse.
    if (s.size() < 22) return false;
    if (s.compare(0, 11, "data:image/") != 0) return false;
    return s.find(";base64,", 11) != std::string::npos;
}

bool LooksLikeDataUrl(const std::string& s) {
    // Same shape as above but for any MIME. 12 == length of the
    // shortest legal data URL header ("data:x/x;base64,").
    if (s.size() < 16) return false;
    if (s.compare(0, 5, "data:") != 0) return false;
    return s.find(";base64,") != std::string::npos;
}

bool GetDataUrlMime(const std::string& s, std::string& mimeOut) {
    mimeOut.clear();
    if (s.size() < 16) return false;
    if (s.compare(0, 5, "data:") != 0) return false;
    // MIME runs from index 5 to the first ';' (or ',' if there are
    // no parameters). We tolerate parameters like
    // "data:text/plain;charset=utf-8;base64,..." — the MIME is only
    // the text up to the first ';'.
    size_t end = s.find_first_of(",;", 5);
    if (end == std::string::npos) return false;
    // Reject if no ";base64" tag at all.
    if (s.find(";base64,", end) == std::string::npos) return false;
    mimeOut = s.substr(5, end - 5);
    return true;
}

std::string MimeToExtension(const std::string& mime) {
    // Lowercase the input so we match consistently.
    std::string lo;
    lo.reserve(mime.size());
    for (char c : mime) {
        if (c >= 'A' && c <= 'Z') c += 32;
        lo.push_back(c);
    }
    // Handful of common types; unknown → generic ".bin". These are
    // the ones actually likely to appear as data URLs in JSON.
    struct Pair { const char* mime; const char* ext; };
    static const Pair kMap[] = {
        // Images
        { "image/jpeg", ".jpg" },
        { "image/jpg",  ".jpg" },
        { "image/png",  ".png" },
        { "image/gif",  ".gif" },
        { "image/webp", ".webp" },
        { "image/bmp",  ".bmp" },
        { "image/tiff", ".tif" },
        { "image/svg+xml",  ".svg" },
        { "image/x-icon",   ".ico" },
        // Audio
        { "audio/mpeg", ".mp3" },
        { "audio/mp3",  ".mp3" },
        { "audio/wav",  ".wav" },
        { "audio/ogg",  ".ogg" },
        { "audio/x-wav",".wav" },
        { "audio/flac", ".flac" },
        // Video
        { "video/mp4",  ".mp4" },
        { "video/webm", ".webm" },
        { "video/x-matroska", ".mkv" },
        { "video/quicktime",  ".mov" },
        { "video/x-msvideo",  ".avi" },
        // Documents
        { "application/pdf",  ".pdf" },
        { "application/json", ".json" },
        { "application/xml",  ".xml" },
        { "application/zip",  ".zip" },
        { "application/gzip", ".gz" },
        { "application/octet-stream", ".bin" },
        { "application/msword", ".doc" },
        { "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          ".docx" },
        { "application/vnd.ms-excel", ".xls" },
        { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          ".xlsx" },
        // Text
        { "text/plain",       ".txt" },
        { "text/html",        ".html" },
        { "text/css",         ".css" },
        { "text/javascript",  ".js" },
        { "text/csv",         ".csv" },
        { "text/markdown",    ".md" },
        { "application/javascript", ".js" },
        // Fonts
        { "font/woff",  ".woff" },
        { "font/woff2", ".woff2" },
        { "font/ttf",   ".ttf" },
        { "font/otf",   ".otf" },
    };
    for (const auto& p : kMap) {
        if (lo == p.mime) return p.ext;
    }
    // Reasonable default per top-level category.
    if (lo.compare(0, 6, "image/") == 0) return ".img";
    if (lo.compare(0, 6, "audio/") == 0) return ".audio";
    if (lo.compare(0, 6, "video/") == 0) return ".video";
    if (lo.compare(0, 5, "text/")  == 0) return ".txt";
    return ".bin";
}

} // namespace jv
