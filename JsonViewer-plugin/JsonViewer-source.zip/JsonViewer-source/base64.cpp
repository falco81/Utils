#include "base64.h"

#include <cctype>
#include <cstring>

namespace jv {

// Standard base64 alphabet lookup. 255 = invalid.
static const uint8_t* B64Table() {
    static uint8_t t[256];
    static bool inited = false;
    if (!inited) {
        for (int i = 0; i < 256; ++i) t[i] = 255;
        const char* alpha =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        for (int i = 0; i < 64; ++i) t[(unsigned char)alpha[i]] = (uint8_t)i;
        // URL-safe variants — some producers use these; harmless to accept.
        t[(unsigned char)'-'] = 62;
        t[(unsigned char)'_'] = 63;
        inited = true;
    }
    return t;
}

bool DecodeBase64(const char* data, size_t len,
                  std::vector<uint8_t>& out) {
    const uint8_t* tab = B64Table();
    out.clear();
    out.reserve((len * 3) / 4 + 4);
    uint32_t buf = 0;
    int bits = 0;
    for (size_t i = 0; i < len; ++i) {
        unsigned char c = (unsigned char)data[i];
        if (c == '=') break;                // padding — stop here
        if (c == '\r' || c == '\n' || c == ' ' || c == '\t') continue;
        uint8_t v = tab[c];
        if (v == 255) return false;         // stray char
        buf = (buf << 6) | v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back((uint8_t)((buf >> bits) & 0xFF));
        }
    }
    return true;
}

bool ParseDataUrl(const std::string& s,
                  std::string& mimeOut,
                  std::vector<uint8_t>& bytesOut) {
    mimeOut.clear();
    bytesOut.clear();
    // Expected shape: data:<mime>;base64,<payload>
    if (s.size() < 12) return false;
    if (s.compare(0, 5, "data:") != 0) return false;
    size_t semi = s.find(';', 5);
    if (semi == std::string::npos) return false;
    // Accept `;base64` OR `;charset=...;base64`. Locate the base64 tag.
    size_t b64 = s.find(";base64", semi);
    if (b64 == std::string::npos) return false;
    size_t comma = s.find(',', b64);
    if (comma == std::string::npos) return false;
    mimeOut = s.substr(5, semi - 5);
    const char* payload = s.data() + comma + 1;
    size_t plen = s.size() - (comma + 1);
    return DecodeBase64(payload, plen, bytesOut);
}

bool LooksLikeImageDataUrl(const std::string& s) {
    // Cheap prefix check — avoids scanning huge strings when we're
    // just deciding whether to try the full parse.
    if (s.size() < 22) return false;
    if (s.compare(0, 11, "data:image/") != 0) return false;
    // Require ';base64' to appear before we accept as image data URL.
    // The MIME suffix (png/jpeg/gif/webp/svg+xml/…) may vary; we
    // don't restrict it here.
    return s.find(";base64,", 11) != std::string::npos;
}

} // namespace jv
