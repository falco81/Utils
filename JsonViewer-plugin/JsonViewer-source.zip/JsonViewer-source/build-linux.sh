#!/bin/sh
# Cross-compile JsonViewer under Linux. Requires the MinGW-w64
# toolchain (Debian/Ubuntu: apt install g++-mingw-w64; Fedora: dnf
# install mingw64-gcc-c++ mingw32-gcc-c++; Arch: pacman -S mingw-w64-gcc).
set -e
cd "$(dirname "$0")"
if ! command -v x86_64-w64-mingw32-g++ > /dev/null; then
    echo "MinGW-w64 not found. Install g++-mingw-w64 first."
    exit 1
fi
make clean
make all
echo
echo "Built:"
ls -la jsonviewer.wlx jsonviewer.wlx64 JsonViewer-plugin.zip
