# Plex Helper – Skip & Auto Unlock (Firefox)

Firefox version of the extension for the Plex Web client. Same features and UI
as the Chrome build:

1. **Custom skip step** – the forward button (and the "." / right-arrow keys)
   jumps by your own value instead of Plex's fixed 30s.
2. **Auto unlock** (optional) – picks your profile and types your PIN for you.

## Settings
Toolbar icon → right-click → *Manage extension* → *Preferences* (Options),
or `about:addons` → this add-on → *Preferences*.

## Install for yourself (temporary – gone after you restart Firefox)
1. Open `about:debugging#/runtime/this-firefox`
2. **Load Temporary Add-on…**
3. Select the `manifest.json` in this folder
4. Reload Plex (Ctrl+F5)

A temporary add-on is removed when Firefox restarts. For a permanent install,
see below.

## Permanent install
Firefox only installs add-ons that are **signed by Mozilla**. Two options:

**A) Sign it on AMO (recommended, free)**
1. Create a free developer account: https://addons.mozilla.org/developers/
2. Zip the *contents* of this folder (so `manifest.json` is at the zip root).
3. *Submit a New Add-on* → choose **"On your own"** (self-distribution) if you
   don't want it listed publicly, or **"On this site"** to list it.
4. Mozilla signs the package; you download the signed `.xpi` and install it by
   opening it in Firefox. It then stays installed and auto-updates (for
   self-hosted, via an `update_url` you provide).

Self-distribution (unlisted) keeps it private – nobody finds it in the add-on
store, but it is still signed so it installs normally.

**B) Firefox Developer Edition / ESR / Nightly**
These builds let you disable signature enforcement
(`xpinstall.signatures.required = false` in `about:config`) and install an
unsigned `.xpi` directly. Regular Firefox does **not** allow this.

## Differences from the Chrome build
- `main.js` is injected into the page by `content.js` (via a `<script>` tag and
  `web_accessible_resources`) instead of Chrome's manifest `"world": "MAIN"`.
  The skip logic itself is identical.
- `manifest.json` adds `browser_specific_settings.gecko` (add-on ID + minimum
  Firefox version) and the `web_accessible_resources` entry for `main.js`.
- Requires **Firefox 128+** (MV3 + storage).

## Security (same as Chrome build)
The PIN is kept in `storage.local`: it stays on this device and is not synced.
It is stored **unencrypted** – anyone who can use this Firefox profile can read
it, so the PIN no longer protects your profile from other users of this
computer. On a shared machine, leave auto unlock disabled. Auto unlock is tried
only once per page load, so a wrong PIN is never retried in a loop.

## Compatibility
Tested against Plex Web 4.159.0. The skip button is matched by
`data-testid="skipForwardButton"`; the unlock flow uses Plex's
`.user-select-list` tiles and `input.pin-input`.
