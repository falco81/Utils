<?php
/**
 * index.php — Plex server status page.
 * Reads data.json produced by the collector (runs as root via a systemd timer).
 * Does nothing privileged itself: no shell, no SMART, no disk access.
 */
declare(strict_types=1);

/**
 * PHP falls back to UTC when date.timezone isn't set in php.ini, which makes
 * every timestamp here disagree with the server's own clock. Follow the system
 * zone instead, so the clock shown means what the shell would say.
 */
function use_system_timezone(): void {
    if (ini_get('date.timezone') && strcasecmp((string) ini_get('date.timezone'), 'UTC') !== 0) return;
    $tz = '';
    if (is_readable('/etc/timezone')) $tz = trim((string) @file_get_contents('/etc/timezone'));
    if ($tz === '' && is_link('/etc/localtime')) {
        $target = (string) @readlink('/etc/localtime');
        if (preg_match('#zoneinfo/(.+)$#', $target, $m)) $tz = $m[1];
    }
    if ($tz !== '' && in_array($tz, timezone_identifiers_list(), true)) date_default_timezone_set($tz);
}
use_system_timezone();

/**
 * The language of the dashboard (plexmon 2.0): the same files and the same
 * engine as Settings (lang/*.json, assets/i18n.js) - the page is written in
 * English and the words are swapped as they appear. The visitor's own choice
 * (the EN / CS switch at the top), else Settings → About → Language of the
 * pages, else Czech.
 */
function dash_lang(): string {
    $known = [];
    foreach (@glob(__DIR__ . '/lang/*.json') ?: [] as $f) {
        $c = basename($f, '.json');
        if (preg_match('/^[a-z]{2,3}$/', $c)) $known[$c] = $f;
    }
    $want = (string) ($_COOKIE['plexmon_lang'] ?? '');
    if ($want === '' || !isset($known[$want]) && $want !== 'en') {
        $want = trim((string) @file_get_contents('/run/plexmon/ui-lang')) ?: 'cs';
    }
    return ($want === 'en' || isset($known[$want])) ? $want : 'en';
}
function dash_lang_pack(string $code): ?string {
    if ($code === 'en') return null;
    $raw = @file_get_contents(__DIR__ . '/lang/' . $code . '.json');
    $all = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($all)) return null;
    $pack = ['code' => $code, 'strings' => [], 'patterns' => [], 'rich' => []];
    foreach (['strings', 'patterns', 'rich'] as $part) {
        foreach (($all[$part] ?? []) as $e) {
            if (!is_array($e)) continue;
            $from = (string) ($e['source'] ?? ''); $to = (string) ($e['text'] ?? '');
            if ($from === '' || $to === '' || $to === $from) continue;
            if ($part === 'patterns') $pack[$part][] = [$from, $to]; else $pack[$part][$from] = $to;
        }
    }
    $pack['strings'] = (object) $pack['strings'];
    $pack['rich'] = (object) $pack['rich'];
    return json_encode($pack, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES);
}
$DASH_LANG = dash_lang();
$DASH_PACK = dash_lang_pack($DASH_LANG);

const DATA_FILE = __DIR__ . '/data.json';
// ---- live activity -------------------------------------------------------
require_once __DIR__ . '/plexmon-api.php';

// Live now-playing + activity: the daemon already has both, fresh.
if (isset($_GET['live']) || isset($_GET['sessions'])) {
    plexmon_relay('/sessions');
    exit;
}

// Poster art: the daemon cached each poster next to data.json, so we just serve
// the file. Falls back to the daemon if for some reason it isn't there yet.
if (isset($_GET['art'])) {
    $key = (string) $_GET['art'];
    if (!preg_match('#^/library/[A-Za-z0-9/_.\-]+$#', $key)) { http_response_code(400); exit; }
    $file = __DIR__ . '/art-' . substr(md5($key), 0, 16) . '.jpg';
    if (is_file($file)) {
        header('Content-Type: image/jpeg');
        header('Cache-Control: private, max-age=600');
        readfile($file);
        exit;
    }
    // Not cached yet — ask the daemon to fetch it live. This is what makes the
    // poster show up immediately instead of only after a collection pass.
    [$status, $body] = plexmon_call('/art?key=' . rawurlencode($key));
    if ($status === 200 && strlen($body) > 200) {
        header('Content-Type: image/jpeg');
        header('Cache-Control: private, max-age=600');
        echo $body;
        exit;
    }
    http_response_code(404);
    exit;
}

// Apple TV remote: relayed to the daemon, which owns the pyatv credentials.
// The page never holds them, and the token guards every action just as it does
// for waking disks.
if (isset($_GET['atv'])) {
    $action = (string) $_GET['atv'];
    if (!in_array($action, ['cmd', 'pair', 'pin', 'rescan', 'unpair'], true)) {
        http_response_code(400);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'message' => 'unknown action']);
        exit;
    }
    $q = [];
    foreach (['id', 'c', 'pin', 'kind', 'playing'] as $k) {
        if (isset($_GET[$k])) $q[$k] = (string) $_GET[$k];
    }
    // Pairing waits for a person to pick up the remote and accept a prompt on
    // the television. The default eight seconds is the shortest link in the
    // chain — the daemon would still be waiting patiently while this gave up.
    $wait = ($action === 'pair') ? 200.0 : 20.0;
    plexmon_relay('/atv/' . $action . ($q ? '?' . http_build_query($q) : ''),
                  'POST', true, $wait);
    exit;
}

// Wake all disks — handed straight to the daemon, which owns the probe files and
// the SMART refresh. No sudo, no shell_exec, no privileges on the web side.
if (isset($_GET['wake'])) {
    plexmon_relay('/wake', 'POST', true);
    exit;
}
if (isset($_GET['wakecheck'])) {
    plexmon_relay('/wakecheck');
    exit;
}

// Full-resolution history for panning, straight from the daemon's file.
// NOTE: ?series=full is NOT served by handing over history-full.json as-is.
// The browser expects {t, charts} — the timestamps together with rebuilt chart
// definitions. Returning the raw history gave it new timestamps while the chart
// data arrays stayed at their down-sampled length, so everything past the old
// end simply vanished. The full response is built further down, from the same
// code that builds the embedded charts.

// The daemon writes data.json into this directory; the whole page renders from
// it. (The dynamic endpoints above are the only things that talk to the daemon
// API directly — everything below is a plain read of the snapshot file.)
$data = is_readable(DATA_FILE)
    ? json_decode((string) file_get_contents(DATA_FILE), true)
    : null;

function h($s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }

function human_uptime(int $s): string {
    $d = intdiv($s, 86400); $s %= 86400;
    $hh = intdiv($s, 3600);  $s %= 3600;
    $mm = intdiv($s, 60);
    $out = [];
    if ($d)  $out[] = "{$d}d";
    if ($hh) $out[] = "{$hh}h";
    if (!$d) $out[] = "{$mm}m";
    return implode(' ', $out);
}

function bytes(int $b): string {
    $u = ['B', 'KB', 'MB', 'GB', 'TB']; $i = 0; $v = (float) $b;
    while ($v >= 1024 && $i < count($u) - 1) { $v /= 1024; $i++; }
    return round($v, $i >= 2 ? 1 : 0) . ' ' . $u[$i];
}

function free_space($sizeB, $usedB): ?array {
    // What is left, and how to say it. The unit follows the amount remaining
    // rather than the size of the disk: on a nearly full 8 TB drive "0.05 TB
    // free" tells you nothing, while "48 GB free" is something you can act on.
    // Precision tightens as the number shrinks, for the same reason — nobody
    // needs a decimal place on 648 GB, and everybody wants one on 4.2 GB.
    if ($sizeB === null || $usedB === null) return null;
    $free = (float) $sizeB - (float) $usedB;
    if ($free < 0) return null;

    if ($free >= 1e12) {
        $txt = round($free / 1e12, $free >= 1e13 ? 1 : 2) . ' TB';
    } elseif ($free >= 1e9) {
        $g = $free / 1e9;
        $txt = ($g >= 100 ? round($g) : round($g, 1)) . ' GB';
    } elseif ($free >= 1e6) {
        $txt = round($free / 1e6) . ' MB';
    } elseif ($free >= 1e3) {
        $txt = round($free / 1e3) . ' KB';
    } else {
        return ['full', 'crit'];      // "0 KB free" is a strange way to say this
    }
    // Only shout when any disk of any size would be in trouble. A data drive at
    // 94 % is normal and is not worth colouring; ten gigabytes left is not.
    $level = $free < 5e9 ? 'crit' : ($free < 2e10 ? 'warn' : '');
    return [$txt, $level];
}


function temp_class(?int $t, array $thr, array $d = []): string {
    if ($t === null) return 'muted';
    // A drive that publishes its own limits knows better than our defaults:
    // NVMe media is rated far hotter than a spinning disk.
    // The daemon resolves this per disk (drive's own limits, then NVMe
    // defaults, then the global ones) so both sides agree on the line.
    $crit = $d['temp_crit_eff'] ?? $d['temp_crit_own'] ?? ($thr['temp_crit'] ?? 58);
    $warn = $d['temp_warn_eff'] ?? $d['temp_warn_own'] ?? ($thr['temp_warn'] ?? 50);
    if ($t >= $crit) return 'crit';
    if ($t >= $warn) return 'warn';
    return 'ok';
}

function lat_class(?float $ms): string {
    if ($ms === null) return '';
    if ($ms < 100) return 'good';
    if ($ms < 500) return 'slow';
    return 'bad';
}

/** Resolve power + I/O into one human state: [label, css-class, is_asleep]. */
function disk_state(array $d): array {
    $power = $d['power'] ?? 'unknown';
    $io    = $d['io'] ?? 'idle';
    // a wake request is spinning this disk up right now
    if ($power === 'spinning') return ['Spinning up', 'read', false];
    if ($power === 'standby')  return ['Standby',  'standby', true];
    if ($power === 'sleeping') return ['Sleeping', 'sleep',   true];
    if ($io === 'write')       return ['Writing',  'write',   false];
    if ($io === 'read')        return ['Reading',  'read',    false];
    if ($power === 'active')   return ['Idle',     'idle',    false];
    return ['Active', 'unknown', false];
}

/** Plain-language explanation of a state — none of these are faults. */
function state_help(string $cls): array {
    return [
        'write'   => ['The disk was being written to when this was sampled.',
                      'Normal activity. The system disk shows this most of the time because Plex writes its database, logs and metadata continuously.'],
        'read'    => ['The disk was being read from when this was sampled.',
                      'Normal activity — playback, a library scan or thumbnail generation.'],
        'idle'    => ['Spinning and ready, with no I/O during the sample.',
                      'The healthy resting state for a disk that is in use.'],
        'standby' => ['Spun down to save power.',
                      'SMART values shown here are from the last time the disk was awake — it is never woken just to draw this page.'],
        'sleep'   => ['In a deeper sleep state than standby.',
                      'SMART values shown here are cached from when the disk was last awake.'],
        'unknown' => ['Power state could not be read from this device.',
                      'Some USB bridges do not report it. Harmless.'],
    ][$cls] ?? ['', ''];
}

const PALETTE = ['#58a6ff', '#3fb950', '#d29922', '#a371f7', '#f85149', '#2dd4bf', '#f0883e'];

// only used if data.json predates the thresholds field; the collector normally supplies them
$thr    = $data['thresholds'] ?? ['temp_warn' => 60, 'temp_crit' => 70];
$cpuThr = ['temp_warn' => 70, 'temp_crit' => 85];   // CPUs run hotter than disks
$overall = $data['overall'] ?? 'unknown';
$overallLabel = ['ok' => 'All healthy', 'warn' => 'Warning', 'crit' => 'Problem', 'unknown' => 'Unknown'][$overall] ?? 'Unknown';
$age = $data ? time() - ($data['generated'] ?? time()) : null;

if ($data && !empty($data['disks'])) {
    usort($data['disks'], function ($a, $b) {
        $am = $a['mount'] ?? null; $bm = $b['mount'] ?? null;
        if ($am === null && $bm === null) return strcmp($a['dev'], $b['dev']);
        if ($am === null) return 1;
        if ($bm === null) return -1;
        return strnatcmp($am, $bm);
    });
}

// Build the chart definitions here so the browser only has to draw them.
// With ?series=full the same code runs against the full-resolution history and
// the result is returned as JSON — that way panning uses every recorded sample
// without duplicating any of this logic in JavaScript.
$wantFull = isset($_GET['series']) && $_GET['series'] === 'full';
if ($wantFull) {
    $fullFile = __DIR__ . '/history-full.json';
    $full = is_readable($fullFile) ? json_decode((string) file_get_contents($fullFile), true) : null;
    if (is_array($full) && !empty($full['t'])) $data['history'] = $full;
}
$hist = $data['history'] ?? [];
$ht   = $hist['t'] ?? [];
$charts = [];
if (count($ht) >= 2) {
    $charts[] = [
        'id' => 'api', 'title' => 'API response time', 'unit' => ' ms', 'min' => 0,
        'note' => 'A steady climb is the early sign the database wants a REINDEX / VACUUM / ANALYZE pass.',
        'series' => [
            ['label' => '/hubs (home screen)', 'color' => '#58a6ff', 'data' => $hist['perf']['hb'] ?? []],
            ['label' => '/library/sections',   'color' => '#3fb950', 'data' => $hist['perf']['ls'] ?? []],
            ['label' => '/identity',           'color' => '#8b94a3', 'data' => $hist['perf']['id'] ?? []],
        ],
    ];

    $tempS = []; $capS = []; $cycS = []; $parkS = []; $wrS = []; $rdS = []; $errS = []; $ci = 0;
    foreach (($hist['disks'] ?? []) as $dh) {
        $col = PALETTE[$ci % count(PALETTE)];
        if (array_filter($dh['temp'], fn($v) => $v !== null)) {
            $tempS[] = ['label' => $dh['label'], 'color' => $col, 'data' => $dh['temp']];
        }
        // Counters are charted as what they are: increments at the moments they
        // happened, which the browser adds into buckets to suit the range on
        // screen. A rolling "per day" line drawn over nine events in seventeen
        // hours mostly showed the shape of its own window sliding along.
        $ssD = counter_deltas($ht, $dh['ss'] ?? []);
        if (array_filter($ssD, fn($v) => $v)) {
            $cycS[] = ['label' => $dh['label'], 'color' => $col, 'data' => $ssD];
        }
        $lcD = counter_deltas($ht, $dh['lc'] ?? []);
        if (array_filter($lcD, fn($v) => $v)) {
            $parkS[] = ['label' => $dh['label'], 'color' => $col, 'data' => $lcD];
        }
        // LBA counts are sector counts; scale to GB so the number means something
        $ub = $dh['unit_b'] ?? 512;
        $wr = counter_deltas($ht, $dh['lw'] ?? []);
        if (array_filter($wr, fn($v) => $v)) {
            $wrS[] = ['label' => $dh['label'], 'color' => $col,
                      'data' => array_map(fn($v) => $v === null ? null : round($v * $ub / 1e9, 3), $wr)];
        }
        $rd = counter_deltas($ht, $dh['lr'] ?? []);
        if (array_filter($rd, fn($v) => $v)) {
            $rdS[] = ['label' => $dh['label'], 'color' => $col,
                      'data' => array_map(fn($v) => $v === null ? null : round($v * $ub / 1e9, 3), $rd)];
        }
        // Error counters are charted only if something actually happened —
        // otherwise it is a flat zero line that tells you nothing.
        foreach ([['crc', 'CRC'], ['errs', 'sector errors']] as [$fld, $what]) {
            $vals = array_filter($dh[$fld] ?? [], fn($v) => $v !== null);
            if ($vals && max($vals) > 0) {
                $errS[] = ['label' => $dh['label'] . ' ' . $what, 'color' => $col, 'data' => $dh[$fld]];
            }
        }
        // Real units, not percent: 94% of an 8 TB disk and 94% of a 1 TB disk
        // are very different amounts of space, and only TB tells you how much
        // you can still put there.
        $used = $dh['used'] ?? [];
        if (array_filter($used, fn($v) => $v !== null)) {
            $capS[] = [
                'label'   => $dh['label'],
                'color'   => $col,
                'data'    => array_map(fn($v) => $v === null ? null : round($v / 1e12, 3), $used),
                'total_b' => $dh['total_b'] ?? null,
            ];
        }
        $ci++;
    }
    if ($tempS) {
        $charts[] = [
            'id' => 'temp', 'title' => 'Disk temperatures', 'unit' => ' °C',
            'note' => 'Gaps are periods a disk was asleep — it is never woken just to read a temperature.',
            'bands' => [
                ['at' => $thr['temp_warn'], 'color' => '#d29922', 'label' => 'warn ' . $thr['temp_warn'] . '°'],
                ['at' => $thr['temp_crit'], 'color' => '#f85149', 'label' => 'crit ' . $thr['temp_crit'] . '°'],
            ],
            'series' => $tempS,
        ];
    }
    if ($capS) {
        $charts[] = [
            'id' => 'cap', 'title' => 'Capacity used', 'unit' => ' TB', 'min' => 0,
            'series' => $capS,
        ];
    }
    if ($cycS) {
        $charts[] = [
            'id' => 'cyc', 'title' => 'Spin-ups', 'unit' => '', 'min' => 0, 'kind' => 'bars',
            'note' => 'How hard the spin-down policy works the motors. Each bar counts the '
                    . 'spin-ups in one slice of time, because that is what a counter has '
                    . 'to say — nine events across a day is nine events, not a curve.',
            'series' => $cycS,
        ];
    }
    if ($wrS || $rdS) {
        $charts[] = [
            'id' => 'thr', 'title' => 'Data written', 'unit' => ' GB', 'min' => 0, 'kind' => 'bars',
            'note' => 'How much each volume actually takes in — useful for spotting which '
                    . 'disk carries the write load.',
            'series' => $wrS ?: $rdS,
        ];
    }
    if ($rdS && $wrS) {
        $charts[] = [
            'id' => 'thrd', 'title' => 'Data read', 'unit' => ' GB', 'min' => 0, 'kind' => 'bars',
            'series' => $rdS,
        ];
    }
    if ($parkS) {
        $charts[] = [
            'id' => 'park', 'title' => 'Head parks', 'unit' => '', 'min' => 0, 'kind' => 'bars',
            'note' => 'Heads park far more often than the motor stops. Rated for 600,000 cycles.',
            'series' => $parkS,
        ];
    }
    if ($errS) {
        $charts[] = [
            'id' => 'err', 'title' => 'Error counters', 'unit' => '', 'min' => 0,
            'note' => 'Only drives with a non-zero counter appear here. Any step up is worth '
                    . 'investigating — CRC errors point at the cable or bridge, sector errors at the disk.',
            'series' => $errS,
        ];
    }
    if (array_filter($hist['sys']['cpu'] ?? [], fn($v) => $v !== null)) {
        $charts[] = [
            'id' => 'cpu', 'title' => 'CPU temperature', 'unit' => ' °C',
            'bands' => [['at' => $cpuThr['temp_warn'], 'color' => '#d29922', 'label' => 'warn ' . $cpuThr['temp_warn'] . '°']],
            'series' => [['label' => 'CPU', 'color' => '#f0883e', 'data' => $hist['sys']['cpu']]],
        ];
    }
    $charts[] = [
        'id' => 'load', 'title' => 'Load average', 'unit' => '', 'min' => 0,
        'note' => 'Above the core count means tasks are queuing for CPU.',
        'bands' => [['at' => (float) ($data['system']['ncpu'] ?: 1), 'color' => '#d29922',
                     'label' => $data['system']['ncpu'] . ' cores']],
        'series' => [['label' => '1 min', 'color' => '#2dd4bf', 'data' => $hist['sys']['load'] ?? []]],
    ];
    if (array_filter($hist['srv']['sess'] ?? [], fn($v) => $v !== null)) {
        $charts[] = [
            'id' => 'sess', 'title' => 'Active streams', 'unit' => '', 'min' => 0,
            'note' => 'Concurrent playbacks. Pair this with CPU temperature and load to see '
                    . 'what transcoding actually costs you.',
            'series' => [['label' => 'streams', 'color' => '#f0883e', 'data' => $hist['srv']['sess']]],
        ];
    }
    if (array_filter($hist['srv']['db'] ?? [], fn($v) => $v !== null)) {
        $dbS = [['label' => 'library.db', 'color' => '#58a6ff',
                 'data' => array_map(fn($v) => $v === null ? null : round($v / 1048576, 1), $hist['srv']['db'])]];
        if (array_filter($hist['srv']['wal'] ?? [], fn($v) => $v !== null)) {
            $dbS[] = ['label' => 'WAL', 'color' => '#d29922',
                      'data' => array_map(fn($v) => $v === null ? null : round($v / 1048576, 1), $hist['srv']['wal'])];
        }
        $charts[] = [
            'id' => 'db', 'title' => 'Database size', 'unit' => ' MB', 'min' => 0,
            'note' => 'A WAL that keeps growing instead of being checkpointed is worth a look.',
            'series' => $dbS,
        ];
    }
    $charts[] = [
        'id' => 'mem', 'title' => 'Memory used', 'unit' => ' %', 'min' => 0, 'max' => 100,
        'series' => [['label' => 'RAM', 'color' => '#a371f7', 'data' => $hist['sys']['mem'] ?? []]],
    ];
}

// JSON endpoint for the lazy full-resolution fetch.
if ($wantFull) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        't' => $ht,
        'charts' => array_map(fn($c) => [
            'id' => $c['id'], 'unit' => $c['unit'] ?? '', 'min' => $c['min'] ?? null,
            'max' => $c['max'] ?? null, 'bands' => $c['bands'] ?? [],
            // without this the browser redraws a bar chart as a line
            'kind' => $c['kind'] ?? 'line',
            'series' => array_map(fn($s) => ['label' => $s['label'], 'color' => $s['color'],
                                             'data' => $s['data']], $c['series']),
        ], $charts),
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Turn a cumulative SMART counter into a per-day rate.
 *
 * Charting the raw counter would just draw a line that only ever goes up; what
 * actually matters is how fast it climbs, because that is what the spin-down
 * policy costs the drive. Readings are sparse (a sleeping disk isn't polled),
 * so each rate is derived from the gap to the previous real reading.
 */
function counter_deltas(array $times, array $counts): array {
    // How much the counter moved since the previous reading, at the moment the
    // move was seen. This is the raw truth about a counter — nine spin-ups in
    // seventeen hours is nine numbers, not a curve — and it lets the chart add
    // them into whatever buckets the visible range calls for.
    $out = array_fill(0, count($counts), null);
    $prev = null;
    foreach ($counts as $i => $v) {
        if ($v === null || !isset($times[$i])) continue;
        if ($prev !== null) {
            $d = $v - $counts[$prev];
            // negative means the counter reset or the disk was swapped
            if ($d >= 0) $out[$i] = $d;
        }
        $prev = $i;
    }
    return $out;
}


function rate_per_day(array $times, array $counts, int $window = 21600,
                     int $minWin = 3600): array {
    // A per-day figure from a counter that ticks a handful of times a day only
    // means something averaged over hours. One spin-up seen across five minutes
    // extrapolates to 288 a day; across nineteen minutes, to 76 — both nonsense
    // for a drive that really spins up three times a day. So each reading is
    // compared against the oldest one still inside a six-hour trailing window,
    // and nothing is reported until that window is at least an hour wide.
    // The cost is an empty chart for the first hour after the history is reset,
    // which is the honest answer: we cannot yet say what the daily rate is.
    $out = array_fill(0, count($counts), null);
    $pts = [];
    foreach ($counts as $i => $v) if ($v !== null && isset($times[$i])) $pts[] = $i;
    foreach ($pts as $pi => $i) {
        $j = null;
        for ($k = $pi - 1; $k >= 0; $k--) {
            if ($times[$i] - $times[$pts[$k]] <= $window) $j = $pts[$k];
            else break;
        }
        if ($j === null) continue;
        $dt = $times[$i] - $times[$j];
        $dv = $counts[$i] - $counts[$j];
        // negative means the counter reset or the disk was swapped: skip it
        if ($dt >= $minWin && $dv >= 0) $out[$i] = round($dv / $dt * 86400, 1);
    }
    return $out;
}


/** Least-squares slope per day; used to project when a disk fills up. */
function trend_per_day(array $times, array $vals): ?float {
    $pts = [];
    foreach ($vals as $i => $v) if ($v !== null && isset($times[$i])) $pts[] = [(float) $times[$i], (float) $v];
    if (count($pts) < 8) return null;
    if ($pts[count($pts) - 1][0] - $pts[0][0] < 6 * 3600) return null;
    $n = count($pts); $sx = $sy = $sxy = $sxx = 0.0;
    foreach ($pts as [$t, $v]) { $sx += $t; $sy += $v; $sxy += $t * $v; $sxx += $t * $t; }
    $den = $n * $sxx - $sx * $sx;
    if (abs($den) < 1e-9) return null;
    return (($n * $sxy - $sx * $sy) / $den) * 86400;
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($DASH_LANG) ?>"<?= $DASH_PACK ? ' class="i18n-wait"' : '' ?>>
<head>
<?php if ($DASH_PACK): ?>
<script>window.OTP_LANG_PACK = <?= $DASH_PACK ?>;</script>
<?php endif; ?>
<script src="assets/i18n.js?v=2.0.0"></script>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="dark">
<title>Plex — server status<?= isset($data['hostname']) ? ' · ' . h($data['hostname']) : '' ?></title>
<style>
  html.i18n-wait body{visibility:hidden}
  .navlinks{display:flex;gap:8px;align-items:center;margin-right:14px}
  .navlinks a,.navlinks button{font:inherit;font-size:12.5px;color:var(--tx-dim);background:var(--panel);
    border:1px solid var(--line);border-radius:8px;padding:5px 10px;text-decoration:none;cursor:pointer}
  .navlinks a:hover,.navlinks button:hover{color:var(--tx);border-color:var(--tx-mut)}
  .navlinks .langs{display:flex;border:1px solid var(--line);border-radius:8px;overflow:hidden}
  .navlinks .langs button{border:0;border-radius:0;padding:5px 8px}
  .navlinks .langs button.on{color:var(--tx);background:var(--panel2)}
  :root{
    --bg:#0d1117; --panel:#161b22; --panel2:#1c222b; --line:#262c37;
    --tx:#e6e9ef; --tx-dim:#8b94a3; --tx-mut:#5b6472;
    --ok:#3fb950; --warn:#d29922; --crit:#f85149; --info:#58a6ff; --write:#a371f7; --sleep:#6e7681;
    --ok-bg:rgba(63,185,80,.12); --warn-bg:rgba(210,153,34,.12);
    --crit-bg:rgba(248,81,73,.13); --info-bg:rgba(88,166,255,.12);
    --write-bg:rgba(163,113,247,.14); --sleep-bg:rgba(110,118,129,.14);
    --r:14px;
  }
  *{box-sizing:border-box}
  html{-webkit-text-size-adjust:100%}
  body{margin:0;background:var(--bg);color:var(--tx);
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    -webkit-font-smoothing:antialiased;padding:26px max(16px,env(safe-area-inset-left)) 56px}
  .wrap{max-width:1240px;margin:0 auto}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}

  header{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:16px}
  header h1{font-size:20px;margin:0;font-weight:650;letter-spacing:.2px}
  header .host{color:var(--tx-dim);font-weight:400}
  .spacer{flex:1}
  .updated{color:var(--tx-mut);font-size:13px;text-align:right;line-height:1.35}

  /* tabs */
  .tabs{display:flex;gap:4px;margin-bottom:20px;border-bottom:1px solid var(--line);flex-wrap:wrap}
  .tabs button{appearance:none;background:none;border:0;border-bottom:2px solid transparent;
    color:var(--tx-dim);font:inherit;font-weight:600;font-size:14px;padding:9px 15px;
    cursor:pointer;border-radius:8px 8px 0 0;transition:color .15s,border-color .15s}
  .tabs button:hover{color:var(--tx)}
  .tabs button[aria-selected="true"]{color:var(--info);border-bottom-color:var(--info)}
  .panel[hidden]{display:none}

  h3.sec{font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;
         color:var(--tx-mut);margin:24px 0 12px}

  .pill{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:999px;
        font-weight:600;font-size:14px;border:1px solid transparent}
  .pill .dot{width:9px;height:9px;border-radius:50%;flex:0 0 auto}
  .pill.ok{background:var(--ok-bg);color:var(--ok);border-color:rgba(63,185,80,.3)}
  .pill.warn{background:var(--warn-bg);color:var(--warn);border-color:rgba(210,153,34,.3)}
  .pill.crit{background:var(--crit-bg);color:var(--crit);border-color:rgba(248,81,73,.3)}
  .pill.unknown{background:var(--panel2);color:var(--tx-dim)}
  .pill.ok .dot{background:var(--ok)} .pill.warn .dot{background:var(--warn)}
  .pill.crit .dot{background:var(--crit);animation:pulse 1.4s infinite} .pill.unknown .dot{background:var(--tx-mut)}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
  @keyframes blink{0%,100%{opacity:1}50%{opacity:.45}}

  .grid{display:grid;gap:14px}
  .top{grid-template-columns:repeat(auto-fit,minmax(215px,1fr))}
  .perf{grid-template-columns:repeat(auto-fit,minmax(230px,1fr))}
  .charts{grid-template-columns:repeat(auto-fit,minmax(520px,1fr))}
  .disks{grid-template-columns:repeat(auto-fill,minmax(320px,1fr))}
  .full{grid-column:1/-1}

  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:17px 19px}
  .card h2{margin:0 0 13px;font-size:12px;font-weight:700;letter-spacing:.7px;
           text-transform:uppercase;color:var(--tx-mut)}

  .kv{display:flex;justify-content:space-between;align-items:baseline;padding:5px 0;font-size:14px;gap:12px}
  .kv .k{color:var(--tx-dim)} .kv .v{font-weight:600;text-align:right}
  .kv+.kv{border-top:1px solid rgba(38,44,55,.6)}
  .big{font-size:29px;font-weight:700;line-height:1.1;margin:2px 0}
  .sub{color:var(--tx-mut);font-size:13px}
  .sub.cap{display:flex;justify-content:space-between;align-items:baseline;gap:12px}
  .freeval{white-space:nowrap}
  .freeval.warn{color:var(--warn)}
  .freeval.crit{color:var(--crit)}
  .flag{color:var(--ok)} .flag.warn{color:var(--warn)} .flag.crit{color:var(--crit)} .flag.muted{color:var(--tx-mut)}

  /* activity */
  .job{display:flex;gap:11px;padding:11px 0;align-items:flex-start}
  .job+.job{border-top:1px solid rgba(38,44,55,.7)}
  .job .ico{width:9px;height:9px;border-radius:50%;margin-top:7px;flex:0 0 auto;animation:blink 1.6s infinite}
  .job.bif .ico,.job.chapter .ico{background:var(--write)}
  .job.playback .ico{background:var(--warn)}
  .job.scan .ico{background:var(--info)}
  .job.loudness .ico,.job.analysis .ico,.job.other .ico{background:var(--tx-dim)}
  .job .jb{min-width:0;flex:1}
  .job .jt{font-weight:650;font-size:14px}
  .job.playback .jt{color:var(--warn)}
  .job .jw{color:var(--tx-mut);font-size:12.5px}
  .job .jf{font-size:13px;margin-top:4px;word-break:break-word}
  .job .jm{color:var(--tx-mut);font-size:12px;white-space:nowrap;text-align:right}
  .idle-note{color:var(--ok);font-size:14px;font-weight:600}

  /* charts */
  .crangewrap{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
  .crange{display:flex;gap:6px;flex-wrap:wrap}
  .crange button:disabled{opacity:.38;cursor:not-allowed}
  .pannote{display:inline-flex;align-items:center;gap:8px;font-size:12.5px;color:var(--info);
    background:var(--info-bg);border:1px solid rgba(88,166,255,.3);border-radius:999px;padding:3px 6px 3px 12px}
  .pannote button{appearance:none;background:var(--info);color:#0d1117;border:0;border-radius:999px;
    padding:2px 10px;font-size:12px;font-weight:700;cursor:pointer}
  /* charts are draggable to scroll through history */
  .cwrap{cursor:grab}
  .cwrap.grabbing{cursor:grabbing}
  .cwrap svg{user-select:none;-webkit-user-select:none}
  .crange button{appearance:none;background:var(--panel);border:1px solid var(--line);color:var(--tx-dim);
    font:inherit;font-size:13px;font-weight:600;padding:6px 13px;border-radius:9px;cursor:pointer}
  .crange button[aria-pressed="true"]{background:var(--info-bg);border-color:rgba(88,166,255,.4);color:var(--info)}
  .cwrap{position:relative}
  .cwrap svg{display:block;width:100%;height:auto;touch-action:pan-y}
  .legend{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:10px;font-size:12.5px;color:var(--tx-dim)}
  .legend .li{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
  .legend i{width:9px;height:9px;border-radius:2px;display:inline-block;flex:0 0 auto}
  .legend b{color:var(--tx);font-weight:600}
  .ctip{position:absolute;pointer-events:none;z-index:20;background:var(--panel2);
    border:1px solid var(--line);border-radius:9px;padding:8px 10px;font-size:12.5px;
    box-shadow:0 8px 24px rgba(0,0,0,.5);opacity:0;transition:opacity .1s;white-space:nowrap}
  .ctip .ct{color:var(--tx-mut);margin-bottom:5px}
  .ctip .cr{display:flex;align-items:center;gap:7px;line-height:1.5}
  .ctip .cr i{width:8px;height:8px;border-radius:2px;flex:0 0 auto}
  .ctip .cr b{margin-left:auto;padding-left:12px}
  .nodata{color:var(--tx-mut);font-size:13px;padding:26px 0;text-align:center}

  .lat{display:flex;justify-content:space-between;align-items:baseline;padding:6px 0;gap:10px}
  .lat+.lat{border-top:1px solid rgba(38,44,55,.6)}
  .lat .ep{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;color:var(--tx-dim)}
  .lat .ms{font-weight:700;white-space:nowrap}
  .lat .ms.good{color:var(--ok)} .lat .ms.slow{color:var(--warn)} .lat .ms.bad{color:var(--crit)}

  .disk{transition:opacity .3s}
  .disk.asleep{opacity:.66}
  .disk .dhead{display:flex;align-items:center;gap:9px;margin-bottom:4px;flex-wrap:wrap}
  .disk .dname{font-size:17px;font-weight:700}
  .badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;letter-spacing:.4px;text-transform:uppercase}
  .badge.usb{background:var(--info-bg);color:var(--info)}
  .badge.nvme{background:rgba(163,113,247,.14);color:#a371f7}
  .badge.sata{background:var(--panel2);color:var(--tx-dim)}
  .disk .model{color:var(--tx-dim);font-size:12.5px;margin-bottom:13px;word-break:break-word}
  .disk .mnt{color:var(--info);font-weight:600}

  .state{display:inline-flex;align-items:center;gap:7px;padding:5px 12px;border-radius:999px;
         font-size:13px;font-weight:700;letter-spacing:.3px;border:1px solid transparent}
  .state .sdot{width:8px;height:8px;border-radius:50%;flex:0 0 auto}
  .state.idle{background:var(--ok-bg);color:var(--ok);border-color:rgba(63,185,80,.3)}
  .state.idle .sdot{background:var(--ok)}
  .state.read{background:var(--info-bg);color:var(--info);border-color:rgba(88,166,255,.35)}
  .state.read .sdot{background:var(--info);animation:blink 1.6s infinite}
  .state.write{background:var(--write-bg);color:var(--write);border-color:rgba(163,113,247,.35)}
  .state.write .sdot{background:var(--write);animation:blink 1.2s infinite}
  .state.standby,.state.sleep{background:var(--sleep-bg);color:var(--sleep);border-color:rgba(110,118,129,.3)}
  .state.standby .sdot,.state.sleep .sdot{background:var(--sleep)}
  .state.unknown{background:var(--panel2);color:var(--tx-dim)}
  .state.unknown .sdot{background:var(--tx-mut)}

  .temp{display:flex;align-items:baseline;gap:8px;margin:13px 0;flex-wrap:wrap}
  .temp .t{font-size:33px;font-weight:800;line-height:1}
  .temp .t.ok{color:var(--ok)} .temp .t.warn{color:var(--warn)}
  .temp .t.crit{color:var(--crit)} .temp .t.muted{color:var(--tx-mut)}
  .temp .health{margin-left:auto}

  .bar{height:8px;border-radius:6px;background:var(--panel2);overflow:hidden;margin:6px 0 4px}
  .bar>i{display:block;height:100%;border-radius:6px;background:var(--info)}
  .bar.warn>i{background:var(--warn)} .bar.crit>i{background:var(--crit)}

  .attrs{display:grid;grid-template-columns:1fr 1fr;gap:6px 16px;margin-top:13px;
         padding-top:13px;border-top:1px solid var(--line);font-size:13px}
  .attrs .a{display:flex;justify-content:space-between;gap:8px}
  .attrs .a .an{color:var(--tx-mut)} .attrs .a .av{font-weight:600}
  .attrs .a .av.bad{color:var(--crit)}
  .cachenote{font-size:11px;color:var(--tx-mut)}

  /* now playing */
  .now{grid-template-columns:repeat(auto-fit,minmax(340px,1fr))}
  .idlecard{color:var(--tx-mut);text-align:center;padding:22px}
  .livewarn{margin-left:10px;font-weight:400;text-transform:none;letter-spacing:0;
    color:var(--warn);font-size:11.5px}
  .np{display:flex;gap:14px;padding:14px}
  /* The frame simply takes the shape of the artwork: fixed width, height from
     the image itself. No aspect-ratio to crop against and no max-height to
     letterbox against — whatever Plex hands us is shown whole.
     align-self keeps flexbox from stretching the frame to the card's height,
     which would show its background as bands above and below the image. */
  /* PIN dialog for pairing an Apple TV */
  .pinmask{position:fixed;inset:0;background:rgba(6,9,14,.72);backdrop-filter:blur(3px);
           display:flex;align-items:center;justify-content:center;z-index:90;
           opacity:0;pointer-events:none;transition:opacity .16s ease}
  .pinmask.on{opacity:1;pointer-events:auto}
  .pinbox{background:var(--panel);border:1px solid var(--line);border-radius:14px;
          padding:26px 30px 22px;width:min(92vw,380px);text-align:center;
          box-shadow:0 18px 50px rgba(0,0,0,.55);transform:translateY(8px);
          transition:transform .16s ease}
  .pinmask.on .pinbox{transform:none}
  .pinbox h3{margin:0 0 4px;font-size:16px;font-weight:600;color:var(--tx)}
  .pinbox .pinsub{font-size:12.5px;color:var(--tx-dim);margin-bottom:18px;line-height:1.45}
  .pindigits{display:flex;gap:10px;justify-content:center;margin-bottom:16px}
  .pindigits input{width:52px;height:62px;text-align:center;font-size:26px;font-weight:600;
                   color:var(--tx);background:var(--panel2);border:1px solid var(--line);
                   border-radius:10px;outline:none;transition:border-color .12s,box-shadow .12s;
                   -moz-appearance:textfield}
  .pindigits input::-webkit-outer-spin-button,
  .pindigits input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
  .pindigits input:focus{border-color:var(--info);box-shadow:0 0 0 3px var(--info-bg)}
  .pindigits input.filled{border-color:#3a4250}
  .pinerr{font-size:12.5px;color:var(--crit);min-height:17px;margin-bottom:12px}
  .pinacts{display:flex;gap:10px;justify-content:center}
  .pinacts button{border-radius:8px;padding:8px 18px;font-size:13px;cursor:pointer;
                  border:1px solid var(--line);background:var(--panel2);color:var(--tx)}
  .pinacts button.go{background:var(--info-bg);border-color:rgba(88,166,255,.4);color:var(--info)}
  .pinacts button:disabled{opacity:.5;cursor:default}

  /* Bottom of a now-playing card: stream details on the left, the remote on
     the right, where there is room for buttons big enough to hit. */
  /* The rule belongs to the whole footer, not to the details block — hung off
     .rows it stopped where the text stopped and looked snapped off. */
  .npfoot{display:flex;align-items:flex-start;gap:24px;margin-top:10px;
          padding-top:9px;border-top:1px solid var(--line)}
  /* Higher specificity on purpose: the generic .np .rows rule sits further down
     the sheet and would otherwise win, putting its own short rule back and
     leaving two lines stacked above the stream details. */
  .np .npfoot > .rows{flex:0 1 auto;min-width:0;margin-top:0;padding-top:0;
                      border-top:none}
  /* Takes the space left over and centres in it, so the remote sits toward the
     middle of the card rather than pinned against the right edge. */
  .bucketnote{color:var(--tx-mut);font-size:11px;margin-left:4px}
  .atv{display:flex;flex-direction:column;align-items:center;gap:8px;
       flex:1 1 auto;padding-top:2px}
  .atvrow{display:flex;align-items:center;gap:10px}
  .atvname{font-size:12px;color:var(--tx-mut)}
  .atvbtn{background:var(--panel2);color:var(--tx);border:1px solid var(--line);
          border-radius:11px;width:52px;height:44px;font-size:20px;line-height:1;
          cursor:pointer;display:inline-flex;align-items:center;justify-content:center;
          transition:border-color .12s,color .12s,background .12s}
  .atvbtn:hover:not(:disabled){border-color:var(--info);color:var(--info);
                               background:var(--info-bg)}
  .atvbtn:active:not(:disabled){transform:translateY(1px)}
  .atvbtn:disabled{opacity:.45;cursor:default}
  .atvbtn.big{width:62px;height:44px;font-size:23px}
  .atvbtn.pair{width:auto;height:34px;padding:0 14px;font-size:12.5px}
  @media (max-width:780px){
    .npfoot{flex-direction:column;gap:14px}
    .atv{margin-left:0;align-items:flex-start}
  }
  .atvmsg{font-size:12px;color:var(--tx-mut)}
  .np{position:relative}
  .atvunpair{position:absolute;top:9px;right:12px;z-index:2;
             font-size:10.5px;letter-spacing:.02em;color:var(--tx-mut);
             text-decoration:none;opacity:.25;padding:2px 6px;border-radius:5px;
             transition:opacity .14s,color .14s,background .14s}
  .atvunpair:hover{opacity:1;color:var(--crit);background:var(--crit-bg)}
  .atvunpair.arm{opacity:1;color:var(--crit);background:var(--crit-bg)}
  .atvmsg.bad{color:var(--crit)}
  .np .art{width:132px;flex:0 0 auto;align-self:flex-start;
    border-radius:8px;overflow:hidden;background:var(--panel2)}
  .np .art img{width:100%;height:auto;display:block}
  .np .art span{display:block;text-align:center;padding:56px 0;color:var(--tx-mut);font-size:24px}
  .np .meta{flex:1;min-width:0}
  .np .t1{font-weight:700;font-size:15px;line-height:1.3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .np .t2{color:var(--tx-dim);font-size:13px;margin-top:2px}
  .np .who{display:flex;align-items:center;gap:7px;margin-top:8px;font-size:12.5px;color:var(--tx-dim);flex-wrap:wrap}
  .np .st{display:inline-flex;align-items:center;gap:5px;font-weight:700;font-size:12px;
    padding:2px 8px;border-radius:999px}
  .np .st.playing{background:var(--ok-bg);color:var(--ok)}
  .np .st.paused{background:var(--sleep-bg);color:var(--sleep)}
  .np .st.buffering{background:var(--warn-bg);color:var(--warn)}
  .np .pbar{height:5px;border-radius:4px;background:var(--panel2);overflow:hidden;margin:9px 0 4px}
  .np .pbar i{display:block;height:100%;background:var(--info);border-radius:4px;transition:width 1s linear}
  .np .times{display:flex;justify-content:space-between;font-size:11.5px;color:var(--tx-mut)}
  .np .rows{margin-top:10px;padding-top:9px;border-top:1px solid var(--line);
    display:grid;grid-template-columns:auto 1fr;gap:3px 10px;font-size:12.5px}
  .np .rk{color:var(--tx-mut)}
  .np .rv{color:var(--tx)}
  .np .dec{font-size:11px;font-weight:700;padding:1px 6px;border-radius:5px;margin-left:6px}
  .np .dec.direct{background:var(--ok-bg);color:var(--ok)}
  .np .dec.transcode{background:var(--warn-bg);color:var(--warn)}
  .np .dec.copy{background:var(--info-bg);color:var(--info)}
  .np .vol{font-family:ui-monospace,Menlo,Consolas,monospace;color:var(--info)}

  /* wake control */
  .sechead{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
  .sechead .sec{margin-bottom:12px}
  .wakebox{margin:26px 0 12px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}
  #wakebtn{appearance:none;background:var(--panel);border:1px solid var(--line);color:var(--tx-dim);
    padding:6px 14px;border-radius:9px;font-size:12.5px;font-weight:600;cursor:pointer}
  #wakebtn:hover:not(:disabled){color:var(--tx);border-color:var(--info)}
  #wakebtn:disabled{opacity:.5;cursor:default}
  .wakeprog{display:flex;align-items:center;gap:10px;font-size:12.5px;color:var(--tx-dim)}
  .wakeprog .wbar{width:140px;height:6px;border-radius:4px;background:var(--panel2);overflow:hidden}
  .wakeprog .wbar i{display:block;height:100%;width:0;background:var(--info);border-radius:4px;
    transition:width .4s linear}
  .wakeprog.done .wbar i{background:var(--ok)}
  .wakeprog.fail .wbar i{background:var(--crit)}
  .wakeprog.done .wtxt{color:var(--ok)}
  .wakeprog.fail .wtxt{color:var(--crit)}
  .recent{display:flex;gap:14px;flex-wrap:wrap;margin-top:7px;font-size:12.5px;color:var(--tx-mut)}
  .recent b{color:var(--tx);font-weight:700;font-size:13.5px}

  /* collapsible full attribute list */
  .moreattrs{margin-top:11px;border-top:1px solid var(--line);padding-top:10px}
  .moreattrs summary{cursor:pointer;list-style:none;font-size:12.5px;color:var(--tx-dim);
    display:flex;align-items:center;gap:8px;user-select:none;padding:2px 0}
  .moreattrs summary::-webkit-details-marker{display:none}
  .moreattrs summary::before{content:"▸";color:var(--tx-mut);transition:transform .15s;display:inline-block}
  .moreattrs[open] summary::before{transform:rotate(90deg)}
  .moreattrs summary:hover{color:var(--tx)}
  .moreattrs summary span{margin-left:auto;font-size:11px;color:var(--tx-mut);
    background:var(--panel2);border-radius:9px;padding:1px 7px}
  .mgrid{display:grid;grid-template-columns:1fr;gap:5px;margin-top:10px;font-size:13px}
  .mgrid .a{display:flex;justify-content:space-between;gap:10px;padding:3px 0}
  .mgrid .a+.a{border-top:1px solid rgba(38,44,55,.5)}
  .mgrid .an{color:var(--tx-mut)} .mgrid .av{font-weight:600;text-align:right}
  .mgrid .av.bad{color:var(--crit)}

  .tip{position:relative;display:inline-flex}
  .tip .pill,.tip .state{cursor:help}
  .tip .why{position:absolute;top:calc(100% + 10px);left:0;z-index:60;
    min-width:290px;max-width:430px;padding:12px 14px;
    background:var(--panel2);border:1px solid var(--line);border-radius:11px;
    box-shadow:0 12px 34px rgba(0,0,0,.55);
    opacity:0;visibility:hidden;transform:translateY(-4px);
    transition:opacity .15s,transform .15s,visibility .15s;text-align:left;font-weight:400}
  .tip:hover .why,.tip:focus-within .why{opacity:1;visibility:visible;transform:translateY(0)}
  .tip .why::before{content:"";position:absolute;bottom:100%;left:18px;
    border:7px solid transparent;border-bottom-color:var(--line)}
  .why h4{margin:0 0 8px;font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .why ul{margin:0;padding:0;list-style:none}
  .why li{display:flex;gap:8px;padding:4px 0;font-size:13px;line-height:1.45;color:var(--tx)}
  .why li+li{border-top:1px solid rgba(38,44,55,.6)}
  .why li .lv{flex:0 0 auto;width:7px;height:7px;border-radius:50%;margin-top:7px}
  .why li.crit .lv{background:var(--crit)}
  .why li.warn .lv{background:var(--warn)}
  .why .allgood{font-size:13px;color:var(--ok)}
  .tip-sm .why{min-width:250px;max-width:320px;left:auto;right:0;padding:10px 12px}
  .tip-sm .why::before{left:auto;right:16px}
  .tip-sm .why p{margin:0;font-size:12.5px;line-height:1.5;color:var(--tx)}
  .tip-sm .why p+p{margin-top:7px;color:var(--tx-dim)}

  .empty{background:var(--crit-bg);border:1px solid rgba(248,81,73,.3);color:#ffb3ae;
         padding:20px;border-radius:var(--r);text-align:center}
  footer{margin-top:26px;text-align:center;color:var(--tx-mut);font-size:12px}

  @media (max-width:1100px){ .charts{grid-template-columns:1fr} }
  @media (max-width:900px){
    .tip .why{min-width:0;width:min(86vw,400px)}
    header h1{font-size:18px}
  }
  @media (max-width:560px){
    body{padding:18px 12px 40px}
    .disks{grid-template-columns:1fr}
    .updated{text-align:left}
    .tabs button{padding:9px 12px;font-size:13px}
  }
</style>
</head>
<body>
<div class="wrap">

<?php if (!$data): ?>
  <div class="empty">
    <strong>No data yet.</strong><br>
    Run the collector: <span class="mono">systemctl start plex-status.service</span>
    and check that <span class="mono"><?= h(DATA_FILE) ?></span> was created.
  </div>
<?php else:
  $sys  = $data['system'];
  $plex = $data['plex'];
  $reasons = $data['reasons'] ?? [];
  $activity = $data['activity'] ?? [];
?>

  <header>
    <h1>Plex server <span class="host">· <?= h($data['hostname']) ?></span></h1>
    <span class="tip" tabindex="0">
      <span class="pill <?= h($overall) ?>"><span class="dot"></span><?= h($overallLabel) ?><?= $reasons ? ' · ' . count($reasons) : '' ?></span>
      <span class="why">
        <h4><?= $reasons ? 'Why this status' : 'Status' ?></h4>
        <?php if ($reasons): ?>
          <ul>
          <?php foreach ($reasons as $r): ?>
            <li class="<?= h($r['level']) ?>"><span class="lv"></span><span><?= h($r['text']) ?></span></li>
          <?php endforeach; ?>
          </ul>
        <?php elseif ($overall !== 'ok'): ?>
          <div class="sub">No details recorded — run the collector again.</div>
        <?php else: ?>
          <div class="allgood">All checks passed — no warnings.</div>
        <?php endif; ?>
      </span>
    </span>
    <div class="spacer"></div>
    <div class="navlinks">
      <span class="langs" data-no-i18n>
        <button type="button" data-lang="en" class="<?= $DASH_LANG === 'en' ? 'on' : '' ?>" title="English">EN</button>
        <button type="button" data-lang="cs" class="<?= $DASH_LANG === 'cs' ? 'on' : '' ?>" title="Čeština">CS</button>
      </span>
      <a href="settings/" title="Accounts, certificates and TLS, automatic certificates, upgrades - signing in is needed">Settings</a>
    </div>
    <div class="updated">
      updated <?= $age < 90 ? "{$age}s ago" : human_uptime((int) $age) . ' ago' ?><br>
      <span class="mono"><?= h(date('H:i:s', $data['generated'])) ?></span>
    </div>
  </header>

  <div class="tabs" role="tablist">
    <button role="tab" data-tab="overview" aria-selected="true">Overview</button>
    <button role="tab" data-tab="trends" aria-selected="false">Trends<?= $charts ? '' : ' (no data yet)' ?></button>
  </div>

  <!-- ============ OVERVIEW ============ -->
  <section class="panel" id="tab-overview">

    <div class="grid top">
      <div class="card">
        <h2>Plex</h2>
        <div class="big flag <?= $plex['active'] ? 'ok' : 'crit' ?>"><?= $plex['active'] ? 'Running' : 'Stopped' ?></div>
        <div class="sub">web <?= h($plex['web_version'] ?? '—') ?> · server <?= h($plex['version'] ?? '—') ?></div>
        <?php if (($plex['sessions'] ?? null) !== null): ?>
          <div class="kv" style="margin-top:9px"><span class="k">Active streams</span><span class="v"><?= (int) $plex['sessions'] ?></span></div>
        <?php endif; ?>
      </div>

      <div class="card">
        <h2>Load</h2>
        <div class="big"><?= h($sys['load'][0]) ?></div>
        <div class="sub"><?= h($sys['load'][1]) ?> / <?= h($sys['load'][2]) ?> · <?= (int) $sys['ncpu'] ?> CPU</div>
        <?php if ($sys['cpu_temp'] !== null): ?>
          <div class="kv" style="margin-top:9px"><span class="k">CPU temp</span>
            <span class="v flag <?= temp_class($sys['cpu_temp'], $cpuThr) ?>"><?= (int) $sys['cpu_temp'] ?> °C</span></div>
        <?php endif; ?>
      </div>

      <div class="card">
        <h2>Memory</h2>
        <?php $mp = $sys['mem_total'] ? (int) round($sys['mem_used'] / $sys['mem_total'] * 100) : 0; ?>
        <div class="big"><?= $mp ?><span style="font-size:16px;color:var(--tx-mut)"> %</span></div>
        <div class="sub"><?= bytes((int) $sys['mem_used']) ?> / <?= bytes((int) $sys['mem_total']) ?></div>
        <div class="bar <?= $mp >= 90 ? 'crit' : ($mp >= 75 ? 'warn' : '') ?>" style="margin-top:11px"><i style="width:<?= $mp ?>%"></i></div>
      </div>

      <div class="card">
        <h2>System</h2>
        <div class="big" style="font-size:22px"><?= human_uptime((int) $sys['uptime_s']) ?></div>
        <div class="sub">uptime</div>
        <div style="margin-top:11px">
          <div class="sub" style="margin-bottom:2px">Kernel</div>
          <div class="mono" style="font-size:12px;word-break:break-all"><?= h($sys['kernel']) ?></div>
        </div>
      </div>
    </div>

    <!-- what Plex is doing right now -->
    <h3 class="sec">Activity</h3>
    <div class="card" id="activitycard">
      <?php if (!$activity): ?>
        <div class="idle-note">Idle</div>
        <div class="sub" style="margin-top:4px">No transcoding, analysis or library scan running.</div>
      <?php else:
        $tcpu = 0.0; foreach ($activity as $j) $tcpu += $j['cpu']; ?>
        <?php foreach ($activity as $j): ?>
          <div class="job <?= h($j['kind']) ?>">
            <span class="ico"></span>
            <span class="jb">
              <span class="jt"><?= h($j['label']) ?></span>
              <div class="jw"><?= h($j['why']) ?></div>
              <?php if ($j['file']): ?>
                <div class="jf"><?= h($j['file']) ?>
                  <?php if ($j['library']): ?><span class="sub">· <?= h($j['library']) ?></span><?php endif; ?>
                </div>
                <div class="sub mono" style="font-size:11.5px"><?= h($j['dir']) ?></div>
              <?php endif; ?>
            </span>
            <span class="jm"><?= h(human_uptime((int) $j['runtime_s'])) ?><br><?= round($j['cpu']) ?> % CPU</span>
          </div>
        <?php endforeach; ?>
        <div class="sub" style="margin-top:11px">
          <?= count($activity) ?> process(es) · <?= round($tcpu) ?> % CPU total.
          Background jobs are triggered by your "asap" settings whenever new media is added.
        </div>
      <?php endif; ?>
    </div>

    <?php $np = $data['now_playing'] ?? []; ?>
    <h3 class="sec">Now playing<span id="npcount"><?= $np ? ' · ' . count($np) : '' ?></span>
      <span class="livewarn" id="livewarn" hidden></span></h3>
    <div class="grid now" id="nowplaying">
      <?php if (!$np): ?>
        <div class="card idlecard" id="npidle">Nothing is playing right now.</div>
      <?php endif; ?>
    </div>


    <?php
      $perf   = $data['perf'] ?? [];
      $direct = $perf['direct'] ?? [];
      $pxy    = $perf['proxy'] ?? null;
      $pdb    = $perf['db'] ?? [];
    if ($direct || $pdb): ?>
    <h3 class="sec">Performance</h3>
    <div class="grid perf">
      <div class="card">
        <h2>API response</h2>
        <?php foreach (['/identity' => 'baseline, no DB access', '/library/sections' => 'library list',
                        '/hubs' => 'home screen — the heavy one'] as $ep => $desc):
                $v = $direct[$ep] ?? null; if (!$v) continue; ?>
          <div class="lat">
            <span><span class="ep"><?= h($ep) ?></span><br><span class="sub"><?= h($desc) ?></span></span>
            <span class="ms <?= lat_class((float) $v['median_ms']) ?>"><?= number_format((float) $v['median_ms'], 1) ?> ms</span>
          </div>
        <?php endforeach; ?>
        <div class="sub" style="margin-top:8px">median over one reused connection</div>
      </div>

      <?php if ($pxy): ?>
      <div class="card">
        <h2>Reverse proxy</h2>
        <?php if (!empty($pxy['error'])): ?>
          <div class="big flag crit" style="font-size:20px">unreachable</div>
          <div class="sub"><?= h($pxy['url']) ?></div>
          <div class="sub" style="margin-top:8px">Plex answers locally, so the fault is in
            nginx / TLS / DNS rather than in Plex.</div>
        <?php else:
          $ov = $pxy['overhead_ms'];
          $ovc = $ov === null ? '' : ($ov < 3 ? 'ok' : ($ov < 15 ? 'warn' : 'crit')); ?>
          <div class="big flag <?= $ovc ?>"><?= $ov === null ? '—' : sprintf('%+.1f', $ov) ?><span style="font-size:15px"> ms</span></div>
          <div class="sub">added per request vs. reaching Plex directly</div>
          <div class="sub" style="margin-top:8px">
            <?php if ($ov !== null && $ov < 3): ?>Negligible — the proxy is not a bottleneck,
              so anything slow is Plex-side.
            <?php elseif ($ov !== null && $ov < 15): ?>Noticeable but minor.
            <?php else: ?>High — check upstream keepalive in nginx.<?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <?php if ($pdb): ?>
      <div class="card">
        <h2>Database</h2>
        <div class="big" style="font-size:24px"><?= bytes((int) ($pdb['bytes'] ?? 0)) ?></div>
        <div class="sub">library.db</div>
        <div class="kv" style="margin-top:9px"><span class="k">WAL</span>
          <span class="v"><?= bytes((int) ($pdb['wal_bytes'] ?? 0)) ?></span></div>
        <?php if (isset($pdb['free_pct'])): ?>
          <div class="kv"><span class="k">Free pages</span>
            <span class="v flag <?= $pdb['free_pct'] >= 25 ? 'warn' : '' ?>"><?= h($pdb['free_pct']) ?> %</span></div>
        <?php endif; ?>
        <?php if (!empty($pdb['backup_count'])): ?>
          <div class="kv"><span class="k">Plex backups</span>
            <span class="v"><?= (int) $pdb['backup_count'] ?> · <?= bytes((int) $pdb['backup_bytes']) ?></span></div>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="sechead">
      <h3 class="sec">Disks</h3>
      <div class="wakebox">
        <button type="button" id="wakebtn">Wake all disks</button>
        <div class="wakeprog" id="wakeprog" hidden>
          <div class="wbar"><i></i></div>
          <span class="wtxt"></span>
        </div>
      </div>
    </div>
    <div class="grid disks">
    <?php foreach ($data['disks'] as $d):
        $tran = strtolower($d['tran']);
        $tclass = temp_class($d['temp'], $thr, $d);
        $pct = $d['fs_pct'];
        $barcls = ($pct === null || $d['mount'] !== '/') ? ''
                  : ($pct >= 95 ? 'crit' : ($pct >= 90 ? 'warn' : ''));
        [$stLabel, $stClass, $asleep] = disk_state($d);

        if ($d['smart_ok'] === true)      { $hlabel = 'SMART OK';     $hcls = 'ok'; }
        elseif ($d['smart_ok'] === false) { $hlabel = 'SMART FAILED'; $hcls = 'crit'; }
        else                              { $hlabel = 'SMART N/A';    $hcls = 'muted'; }
    ?>
      <div class="card disk<?= $asleep ? ' asleep' : '' ?>">
        <div class="dhead">
          <span class="dname mono"><?= h($d['dev']) ?></span>
          <span class="badge <?= $tran === 'usb' ? 'usb' : ($tran === 'nvme' ? 'nvme' : 'sata') ?>"><?= h($d['tran']) ?></span>
          <?php
            [$hh1, $hh2] = state_help($stClass);
            $psrc = $d['power_src'] ?? '';
            $inferred = str_starts_with((string) $psrc, 'inferred') || ($d['power_reliable'] ?? true) === false;
            $idle = $d['idle_for_s'] ?? null;
          ?>
          <span class="tip tip-sm" tabindex="0" style="margin-left:auto">
            <span class="state <?= $stClass ?>"><span class="sdot"></span><?= $stLabel ?></span>
            <span class="why">
              <p><?= h($hh1) ?></p>
              <p><?= h($hh2) ?></p>
              <?php if ($inferred): ?>
                <p>This USB bridge does not report power state, so it is worked out from disk
                   activity<?= $idle !== null ? ' (idle for ' . h(human_uptime((int) $idle)) . ')' : '' ?>.</p>
              <?php endif; ?>
            </span>
          </span>
        </div>
        <div class="model">
          <?php if ($d['mount'] !== null): ?><span class="mnt mono"><?= h($d['mount']) ?></span> · <?php endif; ?>
          <?= h($d['size']) ?> · <?= h($d['model']) ?> · <span class="mono"><?= h($d['serial']) ?></span>
        </div>

        <div class="temp">
          <span class="t <?= $tclass ?>"><?= $d['temp'] !== null ? (int) $d['temp'] : '—' ?><?php if ($d['temp'] !== null): ?><span style="font-size:16px;font-weight:600"> °C</span><?php endif; ?></span>
          <?php if (!empty($d['smart_stale'])): ?><span class="cachenote">cached<?= ($d['cache_age'] ?? null) !== null ? ' ' . h(human_uptime((int) $d['cache_age'])) . ' ago' : '' ?></span>
          <?php elseif (!empty($d['smart_limited'])): ?><span class="cachenote">bridge exposes health only</span><?php endif; ?>
          <span class="pill <?= $hcls === 'muted' ? 'unknown' : $hcls ?> health"><span class="dot"></span><?= $hlabel ?></span>
        </div>

        <?php if ($d['mount'] !== null): ?>
          <div class="kv" style="padding-top:0"><span class="k">Usage</span><span class="v"><?= $pct !== null ? $pct . ' %' : '—' ?></span></div>
          <div class="bar <?= $barcls ?>"><i style="width:<?= (int) $pct ?>%"></i></div>
          <?php $fr = free_space($d['fs_size_b'] ?? null, $d['fs_used_b'] ?? null); ?>
          <div class="sub cap">
            <span><?= h($d['fs_used'] ?? '?') ?> / <?= h($d['fs_size'] ?? '?') ?></span>
            <?php if ($fr !== null): ?>
              <span class="freeval <?= $fr[1] ?>"><?= h($fr[0]) ?> free</span>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <div class="sub flag muted">not mounted</div>
        <?php endif; ?>

        <div class="attrs">
        <?php if ($tran === 'nvme'): ?>
          <div class="a"><span class="an">Endurance used</span>
            <span class="av"><?= $d['nvme_used'] !== null ? (int) $d['nvme_used'] . ' %' : '—' ?></span></div>
          <div class="a"><span class="an">Spare left</span>
            <span class="av <?= ($d['nvme_spare'] !== null && $d['nvme_spare'] < 20) ? 'bad' : '' ?>"><?= $d['nvme_spare'] !== null ? (int) $d['nvme_spare'] . ' %' : '—' ?></span></div>
          <div class="a"><span class="an">Media errors</span>
            <span class="av <?= (int) $d['nvme_media_err'] > 0 ? 'bad' : '' ?>"><?= $d['nvme_media_err'] ?? '—' ?></span></div>
          <div class="a"><span class="an">Power-on</span>
            <span class="av"><?= $d['poh'] !== null ? number_format((int) $d['poh'], 0, '.', ' ') . ' h' : '—' ?></span></div>
        <?php else: ?>
          <div class="a"><span class="an">Reallocated</span>
            <span class="av <?= (int) $d['realloc'] > 0 ? 'bad' : '' ?>"><?= $d['realloc'] ?? '—' ?></span></div>
          <div class="a"><span class="an">Pending</span>
            <span class="av <?= (int) $d['pending'] > 0 ? 'bad' : '' ?>"><?= $d['pending'] ?? '—' ?></span></div>
          <div class="a"><span class="an">Uncorrectable</span>
            <span class="av <?= (int) $d['uncorrect'] > 0 ? 'bad' : '' ?>"><?= $d['uncorrect'] ?? '—' ?></span></div>
          <div class="a"><span class="an">Power-on</span>
            <span class="av"><?= $d['poh'] !== null ? number_format((int) $d['poh'], 0, '.', ' ') . ' h' : '—' ?></span></div>
          <div class="a"><span class="an">Spin-ups</span>
            <span class="av"><?= $d['start_stop'] !== null ? number_format((int) $d['start_stop'], 0, '.', ' ') : '—' ?></span></div>
          <div class="a"><span class="an">Head parks</span>
            <span class="av"><?= $d['load_cycle'] !== null ? number_format((int) $d['load_cycle'], 0, '.', ' ') : '—' ?></span></div>
        <?php endif; ?>
        </div>

        <?php
          // Everything else lives behind a disclosure so the card stays scannable.
          $lbaW = $d['lba_written'] ?? null; $lbaR = $d['lba_read'] ?? null;
          $nvW  = $d['nvme_written'] ?? null; $nvR = $d['nvme_read'] ?? null;
          $wrTb = $lbaW !== null ? $lbaW * 512 / 1e12 : ($nvW !== null ? $nvW * 512000 / 1e12 : null);
          $rdTb = $lbaR !== null ? $lbaR * 512 / 1e12 : ($nvR !== null ? $nvR * 512000 / 1e12 : null);
          $more = [];
          if ($d['crc_err'] !== null)       $more['Interface CRC errors'] = [(int) $d['crc_err'], (int) $d['crc_err'] > 0];
          if ($d['reported_unc'] !== null)  $more['Reported uncorrectable'] = [(int) $d['reported_unc'], (int) $d['reported_unc'] > 0];
          if ($d['spin_retry'] !== null)    $more['Spin retries'] = [(int) $d['spin_retry'], (int) $d['spin_retry'] > 0];
          if ($d['cmd_timeout'] !== null)   $more['Command timeouts'] = [number_format((int) $d['cmd_timeout'], 0, '.', ' '), false];
          if ($d['offretract'] !== null)    $more['Emergency head retracts'] = [(int) $d['offretract'], false];
          if ($d['power_cycle'] !== null)   $more['Power cycles'] = [(int) $d['power_cycle'], false];
          if ($d['spinup_ms'] !== null && $d['spinup_ms'] > 0) $more['Spin-up time'] = [$d['spinup_ms'] . ' ms', false];
          if ($wrTb !== null)               $more['Data written'] = [number_format($wrTb, 1) . ' TB', false];
          if ($rdTb !== null)               $more['Data read'] = [number_format($rdTb, 1) . ' TB', false];
          if (($d['tmax'] ?? null) !== null) {
              $rangeTxt = ($d['tmin'] ?? null) !== null
                  ? $d['tmin'] . '–' . $d['tmax'] . ' °C'
                  : 'max ' . $d['tmax'] . ' °C';
              $more['Lifetime temp'] = [$rangeTxt, $d['tmax'] >= ($thr['temp_crit'] ?? 58)];
          }
          if ($d['unsafe_shutdown'] !== null) $more['Unsafe shutdowns'] = [(int) $d['unsafe_shutdown'], false];
          if ($d['err_log'] !== null)       $more['Error log entries'] = [(int) $d['err_log'], (int) $d['err_log'] > 0];
          if ($d['margin'] !== null)        $more['Closest to threshold'] = [$d['margin_attr'] . ' (+' . $d['margin'] . ')', $d['margin'] <= 0];
          if (!empty($d['selftest']))       $more['Last self-test'] = [$d['selftest']['type'] . ' — ' . $d['selftest']['status'], !$d['selftest']['passed']];
        ?>
        <?php if ($more): ?>
        <details class="moreattrs">
          <summary>All SMART values<span><?= count($more) ?></span></summary>
          <div class="mgrid">
          <?php foreach ($more as $k => [$v, $bad]): ?>
            <div class="a"><span class="an"><?= h($k) ?></span>
              <span class="av <?= $bad ? 'bad' : '' ?>"><?= h((string) $v) ?></span></div>
          <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>

        <?php
          // Absolute counts mean little without a timescale — the rate is what
          // tells you whether the spin-down policy is wearing the drive out.
          $ssc = $d['start_stop'] ?? null; $poh = $d['poh'] ?? null;
          if ($ssc !== null && $poh > 100):
              $perYear = $ssc / ($poh / 8766);
              $lcc = $d['load_cycle'] ?? null;
              $lccYear = $lcc !== null ? $lcc / ($poh / 8766) : null; ?>
          <div class="sub" style="margin-top:9px">
            ≈<?= number_format($perYear, 0, '.', ' ') ?> spin-ups/year<?php
              if ($lccYear !== null): ?> · ≈<?= number_format($lccYear, 0, '.', ' ') ?> head parks/year<?php endif; ?>
          </div>
          <?php
            $s1 = $d['spinups_1h'] ?? null; $s24 = $d['spinups_24h'] ?? null;
            if ($s1 !== null || $s24 !== null): ?>
            <div class="recent">
              <span>Spin-ups <b><?= $s1 !== null ? (int) $s1 : '—' ?></b> last hour</span>
              <span><b><?= $s24 !== null ? (int) $s24 : '—' ?></b> last 24 h</span>
            </div>
          <?php endif; ?>
        <?php endif; ?>

        <?php if (!empty($d['stable_since']) && $d['smart_ok'] === true):
                $stable = time() - (int) $d['stable_since']; ?>
          <div class="sub" style="margin-top:9px">No error-counter change in
            <?= h(human_uptime($stable)) ?> of monitoring.</div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    </div>
  </section>

  <!-- ============ TRENDS ============ -->
  <section class="panel" id="tab-trends" hidden>
    <?php if (!$charts): ?>
      <div class="card"><div class="nodata">
        History is still being collected — charts appear once the collector has run at
        least twice.
      </div></div>
    <?php else: ?>
      <div class="crangewrap">
        <div class="crange" id="ranges">
          <button data-h="6">6 h</button>
          <button data-h="24" aria-pressed="true">24 h</button>
          <button data-h="72">3 d</button>
          <button data-h="168">7 d</button>
          <button data-h="0">All</button>
        </div>
        <span class="sub" id="rangenote"></span>
        <span class="sub" id="resnote"></span>
        <span class="pannote" id="pannote" hidden></span>
      </div>
      <div class="grid charts">
        <?php foreach ($charts as $c): ?>
          <div class="card <?= $c['id'] === 'api' ? 'full' : '' ?>">
            <h2><?= h($c['title']) ?></h2>
            <div class="cwrap" data-chart="<?= h($c['id']) ?>"></div>
            <?php if (!empty($c['note'])): ?>
              <div class="sub" style="margin-top:9px"><?= h($c['note']) ?></div>
            <?php endif; ?>
            <?php if ($c['id'] === 'cap'):
              $proj = [];
              foreach ($c['series'] as $s) {
                  $rate = trend_per_day($ht, $s['data']);       // TB per day
                  $last = null;
                  for ($k = count($s['data']) - 1; $k >= 0; $k--) {
                      if ($s['data'][$k] !== null) { $last = (float) $s['data'][$k]; break; }
                  }
                  if ($last === null) continue;
                  $totalTb = ($s['total_b'] ?? null) ? $s['total_b'] / 1e12 : null;
                  // below ~1 GB/day the slope is indistinguishable from noise
                  if ($rate === null || $rate < 0.001) continue;
                  $gbDay = $rate * 1000;
                  $txt = $s['label'] . ' +' . ($gbDay >= 10 ? round($gbDay) : round($gbDay, 1)) . ' GB/day';
                  if ($totalTb !== null && $last < $totalTb) {
                      $days = ($totalTb - $last) / $rate;
                      if ($days < 3650) {
                          $txt .= ', full in ~' . ($days < 60 ? round($days) . ' d'
                                : ($days < 730 ? round($days / 30) . ' mo' : round($days / 365, 1) . ' y'));
                      }
                  }
                  $proj[] = $txt;
              } ?>
              <div class="sub" style="margin-top:9px">
                <?= $proj ? h(implode(' · ', $proj)) : 'No measurable growth yet — projections appear once a trend forms.' ?>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <footer>
    data.json age <?= (int) $age ?>s · collector runs as root via systemd timer ·
    disks are never woken to draw this page · auto-refresh 60s
  </footer>

<?php endif; ?>
</div>

<script>
document.querySelectorAll('.navlinks .langs button').forEach(function (b) {
  b.onclick = function () {
    document.cookie = 'plexmon_lang=' + b.dataset.lang + '; path=/; max-age=31536000; samesite=strict'
      + (location.protocol === 'https:' ? '; secure' : '');
    location.reload();
  };
});
</script>
<script>
(function () {
  "use strict";

  // ---- chart data ----
  // Declared FIRST: show() below can trigger a draw straight away when the page
  // is loaded on #trends, and reaching these as `undefined` would throw and take
  // the rest of this script (button handlers included) down with it.
  var HIST = <?= json_encode($ht ? ['t' => $ht] : ['t' => []], JSON_UNESCAPED_SLASHES) ?>;
  var CHARTS = <?= json_encode(array_map(function ($c) {
      return ['id' => $c['id'], 'unit' => $c['unit'] ?? '', 'min' => $c['min'] ?? null,
              'max' => $c['max'] ?? null, 'bands' => $c['bands'] ?? [],
              'kind' => $c['kind'] ?? 'line',
              'series' => array_map(fn($s) => ['label' => $s['label'], 'color' => $s['color'], 'data' => $s['data']], $c['series'])];
  }, $charts), JSON_UNESCAPED_SLASHES) ?>;

  // ---- tabs (state kept in the URL so the auto-refresh doesn't lose it) ----
  var tabs = document.querySelectorAll('.tabs button');
  function show(name) {
    document.querySelectorAll('.panel').forEach(function (p) {
      p.hidden = (p.id !== 'tab-' + name);
    });
    tabs.forEach(function (b) { b.setAttribute('aria-selected', b.dataset.tab === name ? 'true' : 'false'); });
    if (name === 'trends') { loadFull(); drawAll(); }
  }
  tabs.forEach(function (b) {
    b.addEventListener('click', function () {
      location.hash = b.dataset.tab;
      show(b.dataset.tab);
    });
  });
  var initial = (location.hash || '').replace('#', '') || 'overview';
  if (initial !== 'trends' && initial !== 'overview') initial = 'overview';
  show(initial);

  // reload keeps the hash, so you stay on the tab you were reading
  // Reloading mid-drag would yank the view back to "now", so hold off while the
  // user is reading history and retry shortly after.
  (function autoReload() {
    setTimeout(function () {
      if (panOffset > 0) { autoReload(); return; }
      location.reload();
    }, 60000);
  })();

  var rangeH = 24;
  var panOffset = 0;        // seconds shifted back from "now"
  var fullLoaded = false;   // full-resolution history fetched yet?

  /**
   * Pull the full-resolution series once the user actually looks at Trends.
   * data.json only carries a down-sampled copy so the first paint stays quick;
   * this brings in every recorded sample so panning has something to reveal.
   */
  function loadFull() {
    if (fullLoaded) return;
    fullLoaded = true;
    // Guard: an exception raised here would abort the rest of this script and
    // take the range buttons and panning with it. Charts already have the
    // down-sampled data, so failing quietly is the right fallback.
    if (typeof fetch !== 'function') return;
    try {
      fetch('?series=full', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        if (!j || !j.t || j.t.length < 2) return;
        HIST.t = j.t;
        // match incoming series to the charts already on the page
        (j.charts || []).forEach(function (nc) {
          var cur = CHARTS.filter(function (c) { return c.id === nc.id; })[0];
          if (cur) cur.series = nc.series;
        });
        var n = document.getElementById('resnote');
        if (n) n.textContent = j.t.length + ' samples loaded';
        drawAll();
      })
      .catch(function () { /* keep the embedded low-res data */ });
    } catch (e) { /* no full-resolution data; the embedded series still work */ }
  }

  /** Drag left/right on any chart to move through history. */
  function attachPan(el) {
    var dragging = false, startX = 0, startPan = 0, moved = false;
    function span() {
      var T = HIST.t || [];
      return T.length > 1 ? T[T.length - 1] - T[0] : 0;
    }

    /**
     * Zoom around a fixed point: whatever moment sits under the pointer stays
     * under the pointer, which is what makes wheel and pinch feel predictable.
     * rangeH is a float here, so zooming isn't limited to the button presets.
     */
    function zoomAt(factor, clientX) {
      var T = HIST.t || [];
      if (T.length < 2) return;
      var total = span(), last = T[T.length - 1];
      var cur = rangeH > 0 ? rangeH * 3600 : total;
      var next = Math.min(total, Math.max(360, cur * factor));   // floor: 6 minutes
      var r = el.getBoundingClientRect();
      var f = r.width ? Math.min(1, Math.max(0, (clientX - r.left) / r.width)) : 0.5;
      var to = last - panOffset, from = to - cur;
      var anchor = from + f * cur;                                // time under the pointer
      var from2 = anchor - f * next;
      panOffset = Math.min(Math.max(0, total - next), Math.max(0, last - (from2 + next)));
      rangeH = (next >= total - 1) ? 0 : next / 3600;             // fully zoomed out == "All"
      if (rangeH === 0) panOffset = 0;
      drawAll();
    }

    el.addEventListener('wheel', function (e) {
      if (!e.deltaY) return;
      e.preventDefault();
      zoomAt(e.deltaY > 0 ? 1.25 : 1 / 1.25, e.clientX);
    }, { passive: false });

    // pinch to zoom (iPad and any other multi-touch screen)
    var pinchDist = 0;
    function dist(t) {
      var dx = t[0].clientX - t[1].clientX, dy = t[0].clientY - t[1].clientY;
      return Math.sqrt(dx * dx + dy * dy);
    }
    el.addEventListener('touchstart', function (e) {
      if (e.touches.length === 2) { pinchDist = dist(e.touches); dragging = false; }
    }, { passive: true });
    el.addEventListener('touchmove', function (e) {
      if (e.touches.length !== 2 || !pinchDist) return;
      e.preventDefault();
      var d2 = dist(e.touches);
      if (Math.abs(d2 - pinchDist) < 4) return;
      var mid = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      zoomAt(pinchDist / d2, mid);
      pinchDist = d2;
    }, { passive: false });
    el.addEventListener('touchend', function (e) {
      if (e.touches.length < 2) pinchDist = 0;
    });

    function down(e) {
      if (e.touches && e.touches.length > 1) return;   // two fingers = pinch, not pan
      if (rangeH === 0) return;               // "All" already shows everything
      dragging = true; moved = false;
      startX = (e.touches ? e.touches[0].clientX : e.clientX);
      startPan = panOffset;
      el.classList.add('grabbing');
    }
    function move(e) {
      if (!dragging) return;
      var x = (e.touches ? e.touches[0].clientX : e.clientX);
      var dx = x - startX;
      if (Math.abs(dx) > 3) moved = true;
      // one chart width == the visible window, so dragging maps 1:1 to time
      var secPerPx = (rangeH * 3600) / Math.max(1, el.clientWidth);
      var next = startPan + dx * secPerPx;
      var maxPan = Math.max(0, span() - rangeH * 3600);
      panOffset = Math.min(maxPan, Math.max(0, next));
      if (e.cancelable && moved) e.preventDefault();
      drawAll();
    }
    function up() {
      dragging = false;
      el.classList.remove('grabbing');
    }
    el.addEventListener('mousedown', down);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    el.addEventListener('touchstart', down, { passive: true });
    el.addEventListener('touchmove', move, { passive: false });
    el.addEventListener('touchend', up);
  }

  var rb = document.getElementById('ranges');

  /**
   * A range button is only meaningful once the history is longer than the
   * window it selects — otherwise every button shows the same full series and
   * clicking them looks broken. Lock the ones that cannot crop anything yet and
   * say how much history there actually is.
   */
  function syncRanges() {
    if (!rb) return;
    var T = HIST.t || [];
    var spanH = T.length > 1 ? (T[T.length - 1] - T[0]) / 3600 : 0;

    // A preset is only meaningful once the history outlasts it; otherwise every
    // button shows the same full series and clicking them looks broken.
    var usable = null, matched = false;
    rb.querySelectorAll('button').forEach(function (b) {
      var hrs = parseInt(b.dataset.h, 10);
      var ok = hrs === 0 || spanH > hrs * 1.02;
      b.disabled = !ok;
      b.title = ok ? '' : 'Needs more than ' + b.textContent.trim() + ' of history';
      if (ok && hrs > 0 && usable === null) usable = hrs;
      // wheel/pinch zoom lands between the presets, so highlight one only on an
      // exact match rather than pretending a preset is active
      var on = ok && Math.abs(hrs - rangeH) < 0.01;
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      if (on) matched = true;
    });

    var note = document.getElementById('rangenote');
    if (note) {
      var txt;
      if (spanH < 1)       txt = Math.max(1, Math.round(spanH * 60)) + ' min of history so far';
      else if (spanH < 48) txt = spanH.toFixed(1) + ' h of history so far';
      else                 txt = Math.round(spanH / 24) + ' d of history';
      if (!matched && rangeH > 0) {
        txt = (rangeH < 1 ? Math.round(rangeH * 60) + ' min' : rangeH.toFixed(1) + ' h') + ' window · ' + txt;
      }
      note.textContent = txt + (usable === null ? ' — longer ranges unlock as it builds up' : '');
    }

    var pn = document.getElementById('pannote');
    if (pn) {
      if (panOffset > 60) {
        var h = panOffset / 3600;
        pn.innerHTML = 'viewing ' + (h < 48 ? h.toFixed(1) + ' h' : Math.round(h / 24) + ' d')
                     + ' back <button type="button" id="pannow">now</button>';
        pn.hidden = false;
        var nb = document.getElementById('pannow');
        if (nb) nb.onclick = function () { panOffset = 0; drawAll(); };
      } else {
        pn.hidden = true;
      }
    }
  }

  if (rb) {
    rb.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b || b.disabled) return;
      rangeH = parseInt(b.dataset.h, 10);
      panOffset = 0;                     // a new window always starts at "now"
      rb.querySelectorAll('button').forEach(function (x) {
        x.setAttribute('aria-pressed', x === b ? 'true' : 'false');
      });
      drawAll();
    });
  }

  function fmtTime(ts, span) {
    var d = new Date(ts * 1000);
    var t = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    if (span > 172800) return d.toLocaleDateString([], { day: 'numeric', month: 'numeric' }) + ' ' + t;
    return t;
  }

  // Bucket width for a bar chart: aim for a couple of dozen bars across the
  // window, then round to a slice a person recognises. Ten-minute bars over a
  // week would be a smear; daily bars over six hours would be one column.
  function bucketSize(span) {
    var want = span / 26;
    var steps = [300, 600, 900, 1800, 3600, 7200, 10800, 21600, 43200, 86400,
                 172800, 604800];
    for (var i = 0; i < steps.length; i++) if (want <= steps[i]) return steps[i];
    return steps[steps.length - 1];
  }

  function bucketLabel(slot) {
    if (slot < 3600) return 'per ' + Math.round(slot / 60) + ' min';
    if (slot < 86400) return 'per ' + Math.round(slot / 3600) + ' h';
    return 'per ' + Math.round(slot / 86400) + ' d';
  }

  function draw(wrap, cfg) {
    var T = HIST.t || [];
    if (T.length < 2) { wrap.innerHTML = '<div class="nodata">Not enough history yet.</div>'; return; }

    // Visible window: rangeH wide, shifted back by panOffset seconds. Panning
    // is what makes a week of five-minute samples explorable instead of just
    // squashed into one screen.
    var last = T[T.length - 1], first = T[0];
    var from = 0, to = last;
    if (rangeH > 0) {
      to = last - panOffset;
      from = to - rangeH * 3600;
      if (from < first) { from = first; to = Math.min(last, first + rangeH * 3600); }
      if (to > last) { to = last; from = to - rangeH * 3600; }
    }
    var idx = [];
    for (var i = 0; i < T.length; i++) if (T[i] >= from && T[i] <= to) idx.push(i);
    if (idx.length < 2) idx = T.map(function (_, i) { return i; });
    var times = idx.map(function (i) { return T[i]; });
    var series = cfg.series.map(function (s) {
      return { label: s.label, color: s.color, data: idx.map(function (i) { return s.data[i]; }) };
    });

    var W = 900, H = 260, padL = 48, padR = 14, padT = 14, padB = 26;
    var all = [];
    series.forEach(function (s) { s.data.forEach(function (v) { if (v !== null && v !== undefined) all.push(+v); }); });
    if (!all.length) { wrap.innerHTML = '<div class="nodata">No data in this range.</div>'; return; }

    var lo = Math.min.apply(null, all), hi = Math.max.apply(null, all);
    (cfg.bands || []).forEach(function (b) { hi = Math.max(hi, +b.at); });
    if (hi - lo < 0.5) hi = lo + 1;
    var pad = (hi - lo) * 0.12;
    var min = cfg.min !== null && cfg.min !== undefined ? cfg.min : Math.max(0, lo - pad);
    var max = cfg.max !== null && cfg.max !== undefined ? cfg.max : hi + pad;
    if (max - min < 0.001) max = min + 1;

    var n = times.length;
    // Position points by TIME, not by their position in the array. With an
    // index-based axis an outage collapses to a single step and silently
    // stretches everything around it — an eight-hour gap made the rest of the
    // day look like it was missing. By time, a gap is simply a gap.
    // Span the axis over the window the user asked for, not merely over the
    // samples that happen to fall inside it — otherwise zooming into a period
    // with an outage silently stretches the little data there is across the
    // whole width. With no zoom ("All") the data's own extent is the window.
    var tA = rangeH > 0 ? from : times[0];
    var tB = rangeH > 0 ? to : times[n - 1];
    if (!(tB > tA)) { tA = times[0]; tB = times[n - 1]; }
    var tSpan = (tB - tA) || 1;
    var X = function (i) { return padL + ((times[i] - tA) / tSpan) * (W - padL - padR); };
    // Typical spacing, so an interruption can be told apart from normal cadence.
    var stepGaps = [];
    for (var gi = 1; gi < n; gi++) stepGaps.push(times[gi] - times[gi - 1]);
    stepGaps.sort(function (a, b) { return a - b; });
    var medGap = stepGaps.length ? stepGaps[Math.floor(stepGaps.length / 2)] : 0;
    // Generous, because the sampling is not perfectly regular: a wake adds
    // extra samples close together, which drags the median down until ordinary
    // five-minute gaps look like outages and the line falls apart into dots.
    // Only a genuine interruption should break it.
    var gapLimit = Math.max(medGap * 4, 900);
    var Y = function (v) { return padT + (1 - ((v - min) / (max - min))) * (H - padT - padB); };

    var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="xMidYMid meet">';
    for (var g = 0; g <= 3; g++) {
      var val = min + (max - min) * g / 3, yy = Y(val).toFixed(1);
      svg += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + yy + '" y2="' + yy + '" stroke="#262c37"/>'
           + '<text x="' + (padL - 8) + '" y="' + (+yy + 4) + '" text-anchor="end" font-size="12" fill="#5b6472">'
           + (Math.abs(max - min) < 5 ? val.toFixed(1) : Math.round(val)) + '</text>';
    }
    (cfg.bands || []).forEach(function (b) {
      if (b.at < min || b.at > max) return;
      var yy = Y(+b.at).toFixed(1);
      svg += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + yy + '" y2="' + yy
           + '" stroke="' + b.color + '" stroke-dasharray="4 4" opacity=".55"/>'
           + '<text x="' + (W - padR) + '" y="' + (+yy - 5) + '" text-anchor="end" font-size="11" fill="'
           + b.color + '" opacity=".85">' + b.label + '</text>';
    });
    var span = times[n - 1] - times[0];
    // Labels at fixed fractions of the time axis, so they read evenly even when
    // the samples themselves are unevenly spaced.
    [0, 0.5, 1].forEach(function (f) {
      var at = tA + f * tSpan;
      var x = padL + f * (W - padL - padR);
      var a = f === 0 ? 'start' : (f === 1 ? 'end' : 'middle');
      svg += '<text x="' + x.toFixed(1) + '" y="' + (H - 7) + '" text-anchor="' + a
           + '" font-size="12" fill="#5b6472">' + fmtTime(at, span) + '</text>';
    });

    // ---- bars -------------------------------------------------------------
    // Counter charts are drawn as totals per slice of time. The increments
    // arrive at the moments they were seen; adding them into buckets sized for
    // the visible range is what turns them into something readable, and it says
    // only what actually happened — an empty slice is an empty slice.
    var isBars = cfg.kind === 'bars';
    var slot = 0, base = 0, nb = 0, totals = null, bmax = 0;
    if (isBars) {
      slot = bucketSize(tSpan);
      base = Math.floor(tA / slot) * slot;
      nb = Math.max(1, Math.ceil((tB - base) / slot));
      totals = series.map(function (s) {
        var acc = new Array(nb).fill(0);
        s.data.forEach(function (v, i) {
          if (v === null || v === undefined || !isFinite(v)) return;
          if (i >= times.length) return;
          var b = Math.floor((times[i] - base) / slot);
          if (b >= 0 && b < nb) acc[b] += +v;
        });
        return acc;
      });
      totals.forEach(function (a) { a.forEach(function (v) { if (v > bmax) bmax = v; }); });
      if (bmax <= 0) {
        wrap.innerHTML = '<div class="nodata">Nothing recorded in this range.</div>';
        return;
      }
      // The grid belongs to the bucket totals, not to the raw increments.
      svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="xMidYMid meet">';
      for (var gg = 0; gg <= 3; gg++) {
        var bv = bmax * gg / 3;
        var by = (padT + (1 - gg / 3) * (H - padT - padB)).toFixed(1);
        svg += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + by + '" y2="' + by
             + '" stroke="#262c37"/>'
             + '<text x="' + (padL - 8) + '" y="' + (+by + 4) + '" text-anchor="end" font-size="12" fill="#5b6472">'
             + (bmax < 5 ? bv.toFixed(1) : Math.round(bv)) + '</text>';
      }
      [0, 0.5, 1].forEach(function (f) {
        var at = tA + f * tSpan, x = padL + f * (W - padL - padR);
        var a = f === 0 ? 'start' : (f === 1 ? 'end' : 'middle');
        svg += '<text x="' + x.toFixed(1) + '" y="' + (H - 7) + '" text-anchor="' + a
             + '" font-size="12" fill="#5b6472">' + fmtTime(at, tSpan) + '</text>';
      });
      var plotW = W - padL - padR, plotH = H - padT - padB;
      var slotW = plotW / nb, lanes = totals.length;
      var bw = Math.max(1.5, Math.min(slotW / lanes - 0.6, 26));
      totals.forEach(function (acc, si) {
        acc.forEach(function (v, bi) {
          if (!v) return;
          var x = padL + bi * slotW + (slotW - bw * lanes) / 2 + si * bw;
          var h = Math.max(1.5, v / bmax * plotH);
          svg += '<rect x="' + x.toFixed(1) + '" y="' + (padT + plotH - h).toFixed(1)
               + '" width="' + bw.toFixed(1) + '" height="' + h.toFixed(1)
               + '" fill="' + series[si].color + '" opacity=".88" rx="1.5"/>';
        });
      });
    }

    if (!isBars) series.forEach(function (s) {
      var seg = [];
      var flush = function () {
        if (seg.length > 1) svg += '<polyline points="' + seg.join(' ') + '" fill="none" stroke="' + s.color
          + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>';
        else if (seg.length === 1) { var p = seg[0].split(','); svg += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="2.4" fill="' + s.color + '"/>'; }
        seg = [];
      };
      s.data.forEach(function (v, i) {
        if (v === null || v === undefined) { flush(); return; }
        // Don't draw through a period we have no readings for: a straight line
        // across it would claim continuity we never measured.
        if (i > 0 && times[i] - times[i - 1] > gapLimit) flush();
        seg.push(X(i).toFixed(1) + ',' + Y(+v).toFixed(1));
      });
      flush();
    });
    svg += '<line class="cross" x1="0" x2="0" y1="' + padT + '" y2="' + (H - padB)
         + '" stroke="#8b94a3" stroke-width="1" opacity="0"/>';
    svg += '</svg>';

    var leg = '<div class="legend">';
    series.forEach(function (s, si) {
      var shown = null;
      if (isBars) {
        // The total in view, which is the question a bar chart answers.
        shown = totals[si].reduce(function (a, b) { return a + b; }, 0);
        if (!shown) shown = 0;
      } else {
        for (var i = s.data.length - 1; i >= 0; i--) if (s.data[i] !== null && s.data[i] !== undefined) { shown = s.data[i]; break; }
      }
      leg += '<span class="li"><i style="background:' + s.color + '"></i>' + s.label
           + (shown !== null ? ' <b>' + (Math.round(shown * 10) / 10) + cfg.unit + '</b>' : '') + '</span>';
    });
    if (isBars) leg += '<span class="bucketnote">' + bucketLabel(slot) + '</span>';
    leg += '</div>';

    wrap.innerHTML = svg + leg + '<div class="ctip"></div>';
    if (!wrap.dataset.pan) { wrap.dataset.pan = '1'; attachPan(wrap); }

    // hover / touch readout
    var el = wrap.querySelector('svg'), tip = wrap.querySelector('.ctip'),
        cross = wrap.querySelector('.cross');
    function move(ev) {
      var r = el.getBoundingClientRect();
      var cx = (ev.touches ? ev.touches[0].clientX : ev.clientX) - r.left;
      var rel = (cx / r.width) * W;
      // Which sample is nearest the cursor in time (the axis is time-based,
      // so the array position no longer maps to the x coordinate).
      var frac = (rel - padL) / (W - padL - padR);
      if (frac < 0) frac = 0; if (frac > 1) frac = 1;
      var want = tA + frac * tSpan, i = 0, bestD = Infinity;
      // Bars answer for a slice of time, so the readout follows the slice under
      // the cursor rather than the nearest single reading.
      var bi = -1;
      if (isBars) {
        bi = Math.floor((want - base) / slot);
        if (bi < 0) bi = 0; if (bi >= nb) bi = nb - 1;
      }
      for (var k = 0; k < n; k++) {
        var dd = Math.abs(times[k] - want);
        if (dd < bestD) { bestD = dd; i = k; }
      }
      // Where the crosshair sits: on the slice for bars, on the sample for lines.
      var cx2 = isBars
        ? padL + (bi + 0.5) * ((W - padL - padR) / nb)
        : X(i);
      cross.setAttribute('x1', cx2); cross.setAttribute('x2', cx2); cross.setAttribute('opacity', '.5');
      var head = isBars
        ? fmtTime(base + bi * slot, tSpan) + '–' + fmtTime(base + (bi + 1) * slot, tSpan)
        : fmtTime(times[i], span);
      var html = '<div class="ct">' + head + '</div>';
      var any = false;
      series.forEach(function (s, si) {
        var v = isBars ? totals[si][bi] : s.data[i];
        var missing = (v === null || v === undefined);
        html += '<div class="cr"><i style="background:' + s.color + '"></i>' + s.label
              + '<b>' + (missing ? '—' : (Math.round(v * 10) / 10) + cfg.unit) + '</b></div>';
        if (!missing && (!isBars || v)) any = true;
      });
      tip.innerHTML = html;
      tip.style.opacity = any ? '1' : '.75';
      var px = (cx2 / W) * r.width;
      tip.style.left = Math.min(Math.max(px - tip.offsetWidth / 2, 0), r.width - tip.offsetWidth) + 'px';
      tip.style.top = '4px';
    }
    el.addEventListener('mousemove', move);
    el.addEventListener('touchstart', move, { passive: true });
    el.addEventListener('touchmove', move, { passive: true });
    el.addEventListener('mouseleave', function () { tip.style.opacity = '0'; cross.setAttribute('opacity', '0'); });
  }

  // ---- now playing ----------------------------------------------------
  var NP = <?= json_encode($data['now_playing'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
  var NP_AT = <?= (int) ($data['generated'] ?? time()) ?>;
  var DISKS = <?= json_encode(array_map(fn($d) => ['dev' => $d['dev'], 'tran' => $d['tran']],
                                        $data['disks'] ?? []), JSON_UNESCAPED_SLASHES) ?>;

  function hms(ms) {
    var s = Math.max(0, Math.floor(ms / 1000));
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
  }
  // Plex reports 'burn' when it renders subtitles into the picture — that is a
  // full transcode of the video, so it must not be mistaken for direct play.
  function decClass(d) {
    if (!d) return '';
    d = String(d).toLowerCase();
    if (d.indexOf('transcode') >= 0 || d.indexOf('burn') >= 0) return 'transcode';
    if (d.indexOf('copy') >= 0) return 'copy';
    return 'direct';
  }
  function decLabel(d) {
    if (!d) return '';
    d = String(d).toLowerCase();
    if (d.indexOf('burn') >= 0) return 'Burned in';
    if (d.indexOf('transcode') >= 0) return 'Transcode';
    if (d.indexOf('copy') >= 0) return 'Stream copy';
    return 'Direct Play';
  }
  // Prefer the live proxy, fall back to the collector's cached copy, then to a
  // plain glyph — a broken image icon would just look like a bug.
  function art(s) {
    var cached = s.thumb ? esc(s.thumb) : '';
    var onerr = cached
      ? "this.onerror=null;this.src='" + cached + "'"
      : "this.onerror=null;this.parentNode.innerHTML='<span>&#9835;</span>'";
    if (s.art) {
      return '<img src="?art=' + encodeURIComponent(s.art) + '" alt="" loading="lazy" onerror="'
           + onerr + '">';
    }
    return cached ? '<img src="' + cached + '" alt="">' : '<span>&#9835;</span>';
  }

  function esc(x) {
    return String(x == null ? '' : x).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  // What the rendered card actually depends on. Rebuilding the DOM every second
  // would throw the poster away and re-insert it each tick, which is exactly
  // what makes the image flicker — so the markup is only regenerated when one
  // of these changes, and the moving parts are updated in place instead.
  var npSig = null;
  function npSignature() {
    return JSON.stringify(NP.map(function (s) {
      // Deliberately without s.state: it changes on every play and pause, and a
      // rebuild would tear out the transport buttons under the user's finger —
      // clicks landing mid-rebuild vanished, and a re-enabled fresh button let
      // the next click fire the command twice. The badge is synced in place.
      return [s.show, s.title, s.season, s.episode, s.user, s.product, s.player,
              s.video, s.video_dec, s.audio, s.audio_dec, s.subs, s.subs_dec,
              s.volume, s.bandwidth, s.duration_ms, s.art, s.thumb,
              s.atv ? s.atv.ident + ':' + (s.atv.paired ? 1 : 0) : ''];
    }));
  }

  /** Advance just the progress bar and elapsed time — no DOM replacement. */
  function tickNP() {
    var box = document.getElementById('nowplaying');
    if (!box || !NP.length) return;
    NP.forEach(function (s, i) {
      var card = box.children[i];
      if (!card) return;
      var off = s.offset_ms || 0;
      if (s.state === 'playing') off += (Date.now() / 1000 - NP_AT) * 1000;
      var dur = s.duration_ms || 0;
      if (dur) off = Math.min(off, dur);
      var bar = card.querySelector('.pbar i');
      if (bar) bar.style.width = (dur ? off / dur * 100 : 0).toFixed(2) + '%';
      var t = card.querySelector('.times span');
      if (t) t.textContent = hms(off);
      // Keep the playing/paused badge current without touching anything else.
      var st = card.querySelector('.who .st');
      var want = (s.state || '?');
      if (st && st.textContent !== want) {
        st.textContent = want;
        st.className = 'st ' + want.toLowerCase();
      }
    });
  }

  function renderNP() {
    var box = document.getElementById('nowplaying');
    if (!box) return;
    var cnt = document.getElementById('npcount');
    if (cnt) cnt.textContent = NP.length ? ' · ' + NP.length : '';
    if (!NP.length) {
      if (npSig !== 'idle') {
        box.innerHTML = '<div class="card idlecard">Nothing is playing right now.</div>';
        npSig = 'idle';
      }
      return;
    }
    var sig = npSignature();
    if (sig === npSig) { tickNP(); return; }   // same content: just move the bar
    npSig = sig;
    box.innerHTML = NP.map(function (s, i) {
      // The collector only samples every so often, so advance the position
      // ourselves while something is actually playing — otherwise the bar would
      // sit still and look broken between refreshes.
      var off = s.offset_ms || 0;
      if (s.state === 'playing') off += (Date.now() / 1000 - NP_AT) * 1000;
      var dur = s.duration_ms || 0;
      if (dur) off = Math.min(off, dur);
      var pct = dur ? (off / dur * 100) : 0;

      var head = s.show || s.title || 'Unknown';
      var sub = '';
      if (s.show && (s.season != null || s.episode != null)) {
        sub = 'S' + (s.season != null ? s.season : '?') +
              ' · E' + (s.episode != null ? s.episode : '?') +
              (s.title ? ' — ' + s.title : '');
      } else if (s.year) { sub = String(s.year); }

      var rows = '';
      function row(k, v, dec) {
        if (!v) return;
        rows += '<div class="rk">' + k + '</div><div class="rv">' + esc(v) +
                (dec ? '<span class="dec ' + decClass(dec) + '">' + decLabel(dec) + '</span>' : '') +
                '</div>';
      }
      row('Video', s.video, s.video_dec);
      row('Audio', s.audio, s.audio_dec);
      row('Subtitles', s.subs, s.subs_dec);
      if (s.volume) rows += '<div class="rk">Reading from</div><div class="rv vol">' + esc(s.volume) + '</div>';

      var st = (s.state || '').toLowerCase();
      // Tucked into the corner of the card, well away from the transport
      // buttons: forgetting a pairing should take deliberate aim.
      var unpair = (s.atv && s.atv.paired)
        ? '<a href="#" class="atvunpair" data-atv-unpair="' + esc(s.atv.ident) + '" ' +
          'data-kind="' + esc(s.atv.kind || 'appletv') + '" ' +
          'title="forget the credentials stored for this TV">unpair</a>' : '';
      return '<div class="card np">' + unpair +
        '<div class="art">' + art(s) + '</div>' +
        '<div class="meta">' +
          '<div class="t1">' + esc(head) + '</div>' +
          (sub ? '<div class="t2">' + esc(sub) + '</div>' : '') +
          '<div class="pbar"><i style="width:' + pct.toFixed(1) + '%"></i></div>' +
          '<div class="times"><span>' + hms(off) + '</span><span>' + hms(dur) + '</span></div>' +
          '<div class="who">' +
            '<span class="st ' + st + '">' + esc(s.state || '?') + '</span>' +
            (s.user ? '<span>' + esc(s.user) + '</span>' : '') +
            (s.product ? '<span>' + esc(s.product) + (s.player ? ' — ' + esc(s.player) : '') + '</span>' : '') +
            (s.bandwidth ? '<span>' + (s.bandwidth / 1000).toFixed(1) + ' Mbps' +
                           (s.local ? ' local' : ' remote') + '</span>' : '') +
          '</div>' +
          '<div class="npfoot">' +
            (rows ? '<div class="rows">' + rows + '</div>' : '<div></div>') +
            atvControls(s) +
          '</div>' +
        '</div></div>';
    }).join('');
  }

  // ---- PIN dialog -------------------------------------------------------
  // Four boxes rather than one field: the code on the television is four digits
  // and typing it should feel like the device asked for it, not like a browser
  // alert. Returns a promise for the code, or null if the user backs out.
  var pinDlg = null;
  function askPin(deviceName) {
    if (!pinDlg) {
      pinDlg = document.createElement('div');
      pinDlg.className = 'pinmask';
      pinDlg.innerHTML =
        '<div class="pinbox" role="dialog" aria-modal="true">' +
          '<h3>Pair with <span class="pinname"></span></h3>' +
          '<div class="pinsub">Type the four-digit code shown on the television.</div>' +
          '<div class="pindigits">' +
            '<input type="text" inputmode="numeric" maxlength="1" autocomplete="off">' +
            '<input type="text" inputmode="numeric" maxlength="1" autocomplete="off">' +
            '<input type="text" inputmode="numeric" maxlength="1" autocomplete="off">' +
            '<input type="text" inputmode="numeric" maxlength="1" autocomplete="off">' +
          '</div>' +
          '<div class="pinerr"></div>' +
          '<div class="pinacts">' +
            '<button type="button" class="cancel">Cancel</button>' +
            '<button type="button" class="go" disabled>Pair</button>' +
          '</div>' +
        '</div>';
      document.body.appendChild(pinDlg);
    }
    var boxes = [].slice.call(pinDlg.querySelectorAll('.pindigits input'));
    var go = pinDlg.querySelector('.go'), cancel = pinDlg.querySelector('.cancel');
    var err = pinDlg.querySelector('.pinerr');
    pinDlg.querySelector('.pinname').textContent = deviceName || 'the TV';
    boxes.forEach(function (b) { b.value = ''; b.classList.remove('filled'); });
    err.textContent = '';
    go.disabled = true;
    pinDlg.classList.add('on');
    setTimeout(function () { boxes[0].focus(); }, 60);

    var code = function () { return boxes.map(function (b) { return b.value; }).join(''); };
    var sync = function () {
      boxes.forEach(function (b) { b.classList.toggle('filled', !!b.value); });
      go.disabled = code().length !== 4;
    };

    return new Promise(function (resolve) {
      function close(val) {
        pinDlg.classList.remove('on');
        boxes.forEach(function (b) { b.oninput = b.onkeydown = b.onpaste = null; });
        go.onclick = cancel.onclick = null;
        document.removeEventListener('keydown', onKey);
        resolve(val);
      }
      function onKey(e) {
        if (e.key === 'Escape') close(null);
        else if (e.key === 'Enter' && code().length === 4) close(code());
      }
      boxes.forEach(function (b, i) {
        b.oninput = function () {
          b.value = b.value.replace(/\D/g, '').slice(0, 1);
          sync();
          if (b.value && i < boxes.length - 1) boxes[i + 1].focus();
          if (code().length === 4) go.focus();
        };
        b.onkeydown = function (e) {
          // Backspace on an empty box steps back, which is what everyone expects
          if (e.key === 'Backspace' && !b.value && i > 0) { boxes[i - 1].focus(); e.preventDefault(); }
          if (e.key === 'ArrowLeft' && i > 0) boxes[i - 1].focus();
          if (e.key === 'ArrowRight' && i < boxes.length - 1) boxes[i + 1].focus();
        };
        b.onpaste = function (e) {
          var t = (e.clipboardData || window.clipboardData).getData('text') || '';
          var digits = t.replace(/\D/g, '').slice(0, 4);
          if (!digits) return;
          e.preventDefault();
          digits.split('').forEach(function (d, k) { if (boxes[k]) boxes[k].value = d; });
          sync();
          (boxes[Math.min(digits.length, 3)]).focus();
        };
      });
      go.onclick = function () { if (code().length === 4) close(code()); };
      cancel.onclick = function () { close(null); };
      document.addEventListener('keydown', onKey);
      pinDlg.onclick = function (e) { if (e.target === pinDlg) close(null); };
    });
  }

  function pinError(msg) {
    if (!pinDlg) return;
    var e = pinDlg.querySelector('.pinerr');
    if (e) e.textContent = msg || '';
  }

  // ---- Apple TV remote --------------------------------------------------
  // Plex cannot drive its own Apple TV app, so the collector talks to the
  // device directly over Apple's Companion protocol. Buttons only appear for a
  // stream we can actually match to a paired device.
  function atvControls(s) {
    if (!s.atv) return '';
    var id = esc(s.atv.ident), name = esc(s.atv.name || 'TV');
    var kind = esc(s.atv.kind || 'appletv');
    if (!s.atv.paired) {
      return '<div class="atv">' +
               '<span class="atvname">' + name + '</span>' +
               '<button class="atvbtn pair" data-atv-pair="' + id + '" ' +
                 'data-kind="' + kind + '">Pair this TV</button>' +
               '<span class="atvmsg"></span>' +
             '</div>';
    }
    var btn = function (cmd, glyph, title, cls) {
      return '<button class="atvbtn' + (cls || '') + '" data-atv="' + id + '" ' +
             'data-kind="' + kind + '" data-cmd="' + cmd + '" title="' + title + '">' +
             glyph + '</button>';
    };
    return '<div class="atv">' +
      '<span class="atvname">' + name + '</span>' +
      '<div class="atvrow">' +
        btn('skip_backward', '&#9198;', 'back') +
        btn('play_pause', '&#9199;', 'play / pause', ' big') +
        btn('skip_forward', '&#9197;', 'forward') +
      '</div>' +
      '<span class="atvmsg"></span></div>';
  }

  // One delegated handler: the panel is rebuilt on every poll, so listeners
  // bound to individual buttons would not survive.
  document.addEventListener('click', function (ev) {
    // Unpairing asks twice, but without a dialog: the link turns into "sure?"
    // and only the second click acts. Deliberate enough not to happen by
    // accident, quiet enough not to dominate the card.
    var u = ev.target.closest ? ev.target.closest('[data-atv-unpair]') : null;
    if (u) {
      ev.preventDefault();
      if (!u.classList.contains('arm')) {
        u.classList.add('arm');
        u.textContent = 'sure?';
        clearTimeout(u._t);
        u._t = setTimeout(function () {
          u.classList.remove('arm'); u.textContent = 'unpair';
        }, 4000);
        return;
      }
      clearTimeout(u._t);
      u.textContent = 'forgetting…';
      fetch('?atv=unpair&id=' + encodeURIComponent(u.getAttribute('data-atv-unpair')) +
            '&kind=' + encodeURIComponent(u.getAttribute('data-kind') || 'appletv'),
            { method: 'POST', cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          u.textContent = j.ok ? 'forgotten' : (j.message || 'failed');
          if (j.ok) {
            // Redraw at once: the daemon has already corrected its device list,
            // so the controls must not linger as if the TV were still paired.
            npSig = null;
            NP.forEach(function (s) {
              if (s.atv && s.atv.ident === u.getAttribute('data-atv-unpair')) {
                s.atv.paired = false;
              }
            });
            renderNP();   // the controls must actually go, so a rebuild is right
            setTimeout(function () { location.reload(); }, 700);
          }
        })
        .catch(function (e) { u.textContent = String(e.message || e); });
      return;
    }

    var b = ev.target.closest ? ev.target.closest('[data-atv],[data-atv-pair]') : null;
    if (!b) return;
    // The buttons sit in a row inside the block, so look for the panel rather
    // than assuming the message element is a direct sibling.
    var box = b.closest('.atv') || b.parentNode;
    var msg = box.querySelector('.atvmsg');
    var say = function (t, bad) { if (msg) { msg.textContent = t; msg.className = 'atvmsg' + (bad ? ' bad' : ''); } };

    if (b.hasAttribute('data-atv-pair')) {
      var id = b.getAttribute('data-atv-pair');
      b.disabled = true; say('starting…');
      var tvName = box.querySelector('.atvname');
      tvName = tvName ? tvName.textContent : 'the TV';
      var kind = b.getAttribute('data-kind') || 'appletv';
      say(kind === 'appletv' ? 'starting…' : 'accept the prompt on the TV…');
      fetch('?atv=pair&id=' + encodeURIComponent(id) + '&kind=' + encodeURIComponent(kind),
            { method: 'POST', cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          b.disabled = false;
          if (!j.ok) { say(j.message || 'failed', true); return; }
          // LG and Samsung ask on their own screen and are done once accepted;
          // only an Apple TV shows a code that has to be typed back.
          if (j.needs_pin === false) {
            say('paired — reloading');
            setTimeout(function () { location.reload(); }, 900);
            return;
          }
          say('');
          return askPin(tvName).then(function (pin) {
            if (!pin) { say('cancelled'); return; }
            pinError('pairing…');
            return fetch('?atv=pin&id=' + encodeURIComponent(id) + '&pin=' + encodeURIComponent(pin),
                         { method: 'POST', cache: 'no-store' })
              .then(function (r) { return r.json(); })
              .then(function (k) {
                if (k.ok) {
                  say('paired — reloading');
                  setTimeout(function () { location.reload(); }, 1000);
                } else {
                  // Keep the dialog shut but say why on the card, so the code can
                  // be retried without hunting for the message.
                  say(k.message || 'pairing failed', true);
                }
              });
          });
        })
        .catch(function (e) { b.disabled = false; say(String(e.message || e), true); });
      return;
    }

    var id2 = b.getAttribute('data-atv'), cmd = b.getAttribute('data-cmd');
    // A command now returns in milliseconds, so the disabled state alone is too
    // brief to swallow a bouncy double-click.
    if (b._busy && Date.now() - b._busy < 400) return;
    b._busy = Date.now();
    b.disabled = true; say('');
    // Show the change immediately. The television has to tell Plex, and Plex has
    // to tell us, which takes a moment — waiting for that round trip before
    // moving the badge makes a working button feel broken.
    if (cmd === 'play_pause') {
      NP.forEach(function (sn) {
        if (sn.atv && sn.atv.ident === id2) {
          sn.state = (sn.state === 'playing') ? 'paused' : 'playing';
          expectState(id2, sn.state);
        }
      });
      tickNP();          // in place — the buttons stay exactly where they are
    }
    // LG has no play/pause toggle, so it needs to know which way to go; the
    // state we already display is exactly that answer.
    var nowPlaying = '1';
    NP.forEach(function (sn) {
      if (sn.atv && sn.atv.ident === id2 && sn.state !== 'playing') nowPlaying = '0';
    });
    fetch('?atv=cmd&id=' + encodeURIComponent(id2) +
          '&kind=' + encodeURIComponent(b.getAttribute('data-kind') || 'appletv') +
          '&playing=' + nowPlaying +
          '&c=' + encodeURIComponent(cmd),
          { method: 'POST', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (!j.ok) say(j.message || 'failed', true); })
      .catch(function (e) { say(String(e.message || e), true); })
      .then(function () { b.disabled = false; pollSoon(); });
  });

  // ---- activity -------------------------------------------------------
  var ACT = <?= json_encode($activity ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
  var actSig = null;

  function dur(s) {
    s = Math.max(0, Math.floor(s));
    var d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    var out = [];
    if (d) out.push(d + 'd');
    if (h) out.push(h + 'h');
    if (!d) out.push(m + 'm');
    return out.join(' ');
  }

  function renderACT() {
    var card = document.getElementById('activitycard');
    if (!card) return;
    var sig = JSON.stringify(ACT.map(function (j) {
      return [j.kind, j.label, j.file, j.library, Math.round(j.cpu), Math.round(j.runtime_s / 5)];
    }));
    if (sig === actSig) return;      // nothing changed: leave the DOM alone
    actSig = sig;

    if (!ACT.length) {
      card.innerHTML = '<div class="idle-note">Idle</div>' +
        '<div class="sub" style="margin-top:4px">No transcoding, analysis or library scan running.</div>';
      return;
    }
    var tcpu = 0;
    var html = ACT.map(function (j) {
      tcpu += j.cpu || 0;
      return '<div class="job ' + esc(j.kind) + '">' +
        '<span class="ico"></span>' +
        '<span class="jb">' +
          '<span class="jt">' + esc(j.label) + '</span>' +
          '<div class="jw">' + esc(j.why) + '</div>' +
          (j.file ? '<div class="jf">' + esc(j.file) +
                    (j.library ? '<span class="sub">· ' + esc(j.library) + '</span>' : '') + '</div>' +
                    '<div class="sub mono" style="font-size:11.5px">' + esc(j.dir) + '</div>' : '') +
        '</span>' +
        '<span class="jm">' + dur(j.runtime_s) + '<br>' + Math.round(j.cpu) + ' % CPU</span>' +
      '</div>';
    }).join('');
    card.innerHTML = html +
      '<div class="sub" style="margin-top:11px">' + ACT.length + ' process(es) · ' +
      Math.round(tcpu) + ' % CPU total. Background jobs are triggered by your "asap" ' +
      'settings whenever new media is added.</div>';
  }

  // One request refreshes both live panels, so poll it for a
  // near-live panel without reloading the whole page
  // After a press we show the new state at once, but Plex needs a moment to
  // hear about it from the television. Without this the next poll would report
  // the old state, the badge would snap back, and a second later flip again —
  // exactly the flicker that made the buttons feel unpredictable.
  var atvExpect = {};       // ident -> { state, until }

  function expectState(ident, state) {
    atvExpect[ident] = { state: state, until: Date.now() + 6000 };
  }

  function applyExpected(list) {
    var now = Date.now();
    list.forEach(function (s) {
      var e = s.atv && atvExpect[s.atv.ident];
      if (!e) return;
      if (now > e.until) { delete atvExpect[s.atv.ident]; return; }
      if (s.state === e.state) { delete atvExpect[s.atv.ident]; return; }
      s.state = e.state;    // hold ours until the server agrees or time runs out
    });
    return list;
  }

  function pollSessions() {
    if (typeof fetch !== 'function') return;
    try {
      fetch('?live=1&_=' + Date.now(), { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) {
          if (!j) return;
          if (j.sessions) {
            NP = applyExpected(j.sessions);
            NP_AT = j.generated || NP_AT;
            renderNP();
          }
          if (j.activity) { ACT = j.activity; renderACT(); }
          var warn = document.getElementById('livewarn');
          if (warn) {
            if (j.live === false && j.why) {
              warn.textContent = 'not live: ' + j.why;
              warn.hidden = false;
            } else {
              warn.hidden = true;
            }
          }
        })
        .catch(function () {});
    } catch (e) {}
  }
  renderNP();
  setInterval(tickNP, 1000);        // moves the bar without touching the poster

  // Poll faster while something is playing. Ten seconds is fine for an idle
  // server, but this panel now carries playback controls, and a pause that
  // takes ten seconds to show on screen reads as "nothing happened".
  var pollTimer = null;
  function schedulePoll(ms) {
    clearTimeout(pollTimer);
    pollTimer = setTimeout(function () {
      pollSessions();
      schedulePoll(NP.length ? 4000 : 10000);
    }, ms);
  }
  // Ask again shortly after a command, so the new state appears at once rather
  // than whenever the next scheduled poll happens to land.
  function pollSoon() {
    setTimeout(pollSessions, 400);
    setTimeout(pollSessions, 1500);
    schedulePoll(NP.length ? 4000 : 10000);
  }
  pollSessions();
  schedulePoll(4000);

  // ---- wake all disks -------------------------------------------------
  // No helper service and no privileges: the button asks the page to read a
  // probe file off each data volume, and that read is what spins the disk up.
  // Verification is direct — a woken disk answers a 1 s probe, a sleeping one
  // cannot — so this reports what the disks are actually doing, not just that
  // a request was sent.
  (function () {
    var btn = document.getElementById('wakebtn');
    var box = document.getElementById('wakeprog');
    if (!btn || !box) return;
    var bar = box.querySelector('.wbar i'), txt = box.querySelector('.wtxt');
    var LIMIT = 240;      // spin-up plus a full SMART pass over five disks
    var awakeSeen = false;

    function fail(msg) {
      box.className = 'wakeprog fail';
      bar.style.width = '100%';
      txt.textContent = msg;
      btn.disabled = false;
    }

    btn.addEventListener('click', function () {
      if (typeof fetch !== 'function') { alert('This browser cannot send the request.'); return; }
      btn.disabled = true;
      box.hidden = false;
      box.className = 'wakeprog';
      bar.style.width = '3%';
      txt.textContent = 'spinning up…';
      var t0 = Date.now() / 1000;

      // Take the collector's own last-read timestamp first and wait for that
      // number to CHANGE. Comparing it against the browser's clock instead —
      // which is what this used to do — fails whenever the two machines are a
      // few seconds apart, and the first press then always looked like it
      // never refreshed SMART.
      fetch('data.json?_=' + Date.now(), { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .catch(function () { return null; })
        .then(function (d0) {
          var base = (d0 && d0.last_smart_read) || 0;
          return fetch('?wake=1', { cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
              if (!j || !j.ok) throw new Error(j && j.error ? j.error : 'request refused');
              txt.textContent = 'spinning up ' + j.disks.length + ' disks…' +
                                (j.refresh ? '' : ' (SMART refresh not permitted)');
              setTimeout(function () { poll(t0, j.disks.length, !!j.refresh, base); }, 2500);
            });
        })
        .catch(function (e) { fail('failed: ' + e.message); });
    });

    /**
     * Two things have to land: every disk answering a probe (proof they woke),
     * and a data.json newer than the click in which no disk is serving cached
     * SMART (proof the values on screen are fresh). If the collector refresh
     * wasn't permitted, the first alone finishes the job and we say so.
     */
    function poll(t0, total, wantFresh, base) {
      var elapsed = Date.now() / 1000 - t0;
      if (elapsed > LIMIT) {
        if (awakeSeen) {
          box.className = 'wakeprog done';
          bar.style.width = '100%';
          txt.textContent = 'disks awake — SMART refreshes on the next collector pass';
          btn.disabled = false;
        } else {
          fail('timed out — the disks did not answer');
        }
        return;
      }

      Promise.all([
        fetch('?wakecheck=1&_=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.json(); }),
        wantFresh ? fetch('data.json?_=' + Date.now(), { cache: 'no-store' })
                      .then(function (r) { return r.ok ? r.json() : null; })
                      .catch(function () { return null; })
                  : Promise.resolve(null),
      ]).then(function (res) {
        var chk = res[0], data = res[1];
        if (!chk || !chk.ok) throw new Error(chk && chk.error ? chk.error : 'check failed');

        var awake = chk.awake >= chk.total;
        if (awake) awakeSeen = true;
        // last_smart_read is a timestamp the collector persists, so it stays
        // true even when the regular five-minute run rewrites data.json from
        // cache moments later and clears every from_cache flag.
        // A change in the collector's own timestamp, not a comparison against
        // this browser's clock — no dependency on the two agreeing.
        var fresh = !wantFresh || (data && (data.last_smart_read || 0) > base);

        var pct = (chk.total ? chk.awake / chk.total : 0) * (wantFresh ? 70 : 100);
        if (awake && wantFresh) pct = fresh ? 100 : 85;
        bar.style.width = Math.max(5, pct).toFixed(0) + '%';

        if (awake && fresh) {
          box.className = 'wakeprog done';
          bar.style.width = '100%';
          var temps = data ? (data.disks || []).filter(function (d) {
              return d.temp != null && (d.tran || '').toLowerCase() !== 'nvme';
            }).map(function (d) { return d.temp; }) : [];
          txt.textContent = 'all ' + chk.total + ' disks awake' +
            (wantFresh ? ', SMART refreshed' : '') +
            (temps.length ? ' (' + Math.min.apply(null, temps) + '–' +
                            Math.max.apply(null, temps) + ' °C)' : '');
          if (wantFresh) setTimeout(function () { location.reload(); }, 1500);
          else setTimeout(function () { btn.disabled = false; }, 3000);
          return;
        }

        txt.textContent = !awake
          ? chk.awake + ' of ' + chk.total + ' awake… ' + Math.max(0, Math.round(LIMIT - elapsed)) + 's'
          : 'reading SMART… ' + Math.max(0, Math.round(LIMIT - elapsed)) + 's';
        setTimeout(function () { poll(t0, total, wantFresh, base); }, 2000);
      }).catch(function () {
        // A hiccup in one poll must not lose the baseline, or the next poll
        // would compare against zero and declare success immediately.
        setTimeout(function () { poll(t0, total, wantFresh, base); }, 2500);
      });
    }
  })();

  function drawAll() {
    // Drawing into a hidden panel would size every chart against a zero-width
    // container and produce empty SVGs, so wait until Trends is actually shown.
    var panel = document.getElementById('tab-trends');
    if (!panel || panel.hidden) return;
    syncRanges();
    CHARTS.forEach(function (cfg) {
      var wrap = document.querySelector('[data-chart="' + cfg.id + '"]');
      if (wrap) draw(wrap, cfg);
    });
  }

  // Draw once the DOM is ready, and again after a resize so the SVG geometry
  // matches the new width (rotating an iPad, or dragging a window narrower).
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', drawAll);
  } else {
    drawAll();
  }
  var rzT;
  window.addEventListener('resize', function () {
    clearTimeout(rzT);
    rzT = setTimeout(drawAll, 150);
  });
})();
</script>
</body>
</html>
