const SYNC_DEFAULTS = {
  skipEnabled: true,
  skipSeconds: 10,
  remapKeyboard: true,
  relabelButton: true,
  autoUnlock: false,
  profileName: "",
};
const LOCAL_DEFAULTS = { pin: "" };

const els = {
  skipEnabled: document.getElementById("skipEnabled"),
  skipSeconds: document.getElementById("skipSeconds"),
  remapKeyboard: document.getElementById("remapKeyboard"),
  relabelButton: document.getElementById("relabelButton"),
  autoUnlock: document.getElementById("autoUnlock"),
  profileName: document.getElementById("profileName"),
  pin: document.getElementById("pin"),
};
const saved = document.getElementById("saved");

function flash(msg) {
  saved.textContent = msg;
  clearTimeout(flash._t);
  flash._t = setTimeout(() => (saved.textContent = ""), 1500);
}

// Load stored values
chrome.storage.sync.get(SYNC_DEFAULTS, (cfg) => {
  els.skipEnabled.checked = !!cfg.skipEnabled;
  els.skipSeconds.value = cfg.skipSeconds;
  els.remapKeyboard.checked = !!cfg.remapKeyboard;
  els.relabelButton.checked = !!cfg.relabelButton;
  els.autoUnlock.checked = !!cfg.autoUnlock;
  els.profileName.value = cfg.profileName || "";
});
// The PIN lives in storage.local so it never leaves this device.
chrome.storage.local.get(LOCAL_DEFAULTS, (cfg) => {
  els.pin.value = cfg.pin || "";
});

function save() {
  let n = parseInt(els.skipSeconds.value, 10);
  if (!Number.isFinite(n)) n = SYNC_DEFAULTS.skipSeconds;
  n = Math.min(120, Math.max(1, n));
  els.skipSeconds.value = n;

  const pin = (els.pin.value || "").replace(/\D/g, "").slice(0, 4);
  els.pin.value = pin;

  chrome.storage.sync.set({
    skipEnabled: els.skipEnabled.checked,
    skipSeconds: n,
    remapKeyboard: els.remapKeyboard.checked,
    relabelButton: els.relabelButton.checked,
    autoUnlock: els.autoUnlock.checked,
    profileName: els.profileName.value.trim(),
  });
  chrome.storage.local.set({ pin }, () => {
    if (els.autoUnlock.checked && pin.length !== 4) flash("Saved — PIN must be 4 digits");
    else flash("Saved ✓");
  });
}

Object.values(els).forEach((el) => el.addEventListener("change", save));
