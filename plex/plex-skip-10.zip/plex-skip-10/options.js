const DEFAULTS = {
  skipSeconds: 10,
  plexDefault: 30,
  remapKeyboard: true,
  relabelButton: true,
};

const els = {
  skipSeconds: document.getElementById("skipSeconds"),
  remapKeyboard: document.getElementById("remapKeyboard"),
  relabelButton: document.getElementById("relabelButton"),
};
const saved = document.getElementById("saved");

function flash(msg) {
  saved.textContent = msg;
  clearTimeout(flash._t);
  flash._t = setTimeout(() => (saved.textContent = ""), 1500);
}

// Načíst uložené hodnoty
chrome.storage.sync.get(DEFAULTS, (cfg) => {
  els.skipSeconds.value = cfg.skipSeconds;
  els.remapKeyboard.checked = !!cfg.remapKeyboard;
  els.relabelButton.checked = !!cfg.relabelButton;
});

function save() {
  let n = parseInt(els.skipSeconds.value, 10);
  if (!Number.isFinite(n)) n = DEFAULTS.skipSeconds;
  n = Math.min(120, Math.max(1, n));
  els.skipSeconds.value = n;
  chrome.storage.sync.set(
    {
      skipSeconds: n,
      remapKeyboard: els.remapKeyboard.checked,
      relabelButton: els.relabelButton.checked,
    },
    () => flash("Saved ✓")
  );
}

els.skipSeconds.addEventListener("change", save);
els.remapKeyboard.addEventListener("change", save);
els.relabelButton.addEventListener("change", save);
