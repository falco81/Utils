# Plex – Skip Forward 10s

Chrome rozšíření, které v Plex Web klientovi změní tlačítko „přeskočit vpřed
o 30 s" tak, aby skákalo jen o **10 s** (nebo o kolik si nastavíš).

## Instalace (načtení jako „unpacked")

1. Otevři `chrome://extensions`
2. Vpravo nahoře zapni **Režim pro vývojáře** (Developer mode)
3. Klikni na **Načíst rozbalené** (Load unpacked)
4. Vyber tuto složku (`plex-skip-10`)
5. Obnov stránku Plexu (`plex.falco81.net`) a přehraj video – tlačítko vpřed teď skáče o 10 s

## Změna hodnoty / dalších voleb

Nahoře v `content.js`:

- `SKIP_SECONDS` – o kolik sekund skákat vpřed (výchozí `10`)
- `REMAP_KEYBOARD` – nastav na `true`, když chceš stejné chování i pro klávesy
  `.` a šipku vpravo (jinak zůstanou na 30 s)
- `RELABEL_BUTTON` – přepíše textový tooltip tlačítka na novou hodnotu

Po úpravě klikni v `chrome://extensions` u rozšíření na ↻ (reload) a obnov Plex.

## Poznámky

- Číslo „30" nakreslené uvnitř ikony je grafika (SVG). Rozšíření mění chování
  a tooltip; samotné číslo v ikonce zůstane 30, dokud by se nevyměnila i ikona
  (křehčí, láme se to při aktualizacích Plexu).
- Tlačítko **zpět** už je v Plexu 10 s, takže to neřešíme.
- Funguje na doménách `plex.falco81.net` a `app.plex.tv`. Další server přidáš
  do `matches` v `manifest.json`.
- Testováno proti Plex Web 4.159.0 (identifikátor tlačítka `skipForwardButton`).
  Ten je sémantický, takže by měl přežít i budoucí aktualizace.
