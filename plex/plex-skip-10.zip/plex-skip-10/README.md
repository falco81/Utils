# Plex Helper – Skip & Auto Unlock

A Chrome extension for the Plex Web client:

1. **Custom skip step** – the forward button (and the "." / right-arrow keys)
   jumps by your own value instead of Plex's fixed 30s.
2. **Auto unlock** (optional) – picks your profile and types your PIN for you.

## Settings
Extension icon → or `chrome://extensions` → *Details* → *Extension options*.

## Auto unlock – how it works
- Set the **profile name** exactly as it appears on the Plex tile, and your
  4-digit **PIN**.
- On the user-select screen the extension clicks your profile, then fills the
  PIN field. Plex submits by itself once 4 digits are present.
- Each step runs **only once per page load**. A wrong stored PIN is never
  retried in a loop, so it cannot lock your account — you just finish by hand
  and correct the settings.

### Security
The PIN is kept in `chrome.storage.local`: it stays on this device and is
**not** synced to your Google account. It is, however, stored **unencrypted** —
extensions have no encrypted storage. Anyone who can use this Chrome profile
can read it, which means the PIN no longer protects your profile from other
people using this computer. On a shared machine, leave auto unlock disabled.

## Install for yourself (without publishing)
1. `chrome://extensions` → enable **Developer mode**
2. **Load unpacked** → select this folder
3. Reload Plex (Ctrl+F5)

## Turning it into a "normal" plugin (auto-update, no developer mode)
Publish it to the Chrome Web Store:
1. Developer account: https://chrome.google.com/webstore/devconsole – one-time
   $5 registration fee.
2. Zip this folder (without this README and without `.git`).
3. *Add new item* → upload the ZIP → fill in description, a 128×128 icon, at
   least one 1280×800 screenshot and a 440×280 promo tile.
4. Set **visibility** to *Private* / *Unlisted* for personal use, or *Public*.
5. Submit for review (usually a few days).

Note: an extension that stores a PIN and fills login forms will draw closer
review attention. For a personal tool, *Private* visibility is the simplest
route.

## Compatibility
Tested against Plex Web 4.159.0. The skip button is matched by
`data-testid="skipForwardButton"`; the unlock flow uses Plex's
`.user-select-list` tiles and `input.pin-input`.
