# Plex – Skip Forward 10s

A Chrome extension that changes the forward-skip step in the Plex Web client
(both the button and the "." / right-arrow keys) from 30s to a custom value.

## Settings
Extension icon → or `chrome://extensions` → *Details* → *Extension options*.
You can change: number of seconds, whether to also affect the keyboard, and
whether to rewrite the button tooltip.

## Install for yourself (without publishing)
1. `chrome://extensions` → enable **Developer mode**
2. **Load unpacked** → select this folder
3. Reload Plex (Ctrl+F5)

## Turning it into a "normal" plugin (auto-update, no developer mode)
Publish it to the Chrome Web Store:
1. Developer account: https://chrome.google.com/webstore/devconsole – one-time
   $5 registration fee.
2. Zip this folder (without this README and without `.git`).
3. *Add new item* → upload the ZIP → fill in description, a 128×128 icon, at
   least one 1280×800 screenshot and a 440×280 promo tile.
4. Set **visibility**:
   - *Private* / *Unlisted* – for personal use (not discoverable in search,
     installed via a direct link, but works like a normal extension including
     automatic updates).
   - *Public* – publicly discoverable.
5. Submit for review (usually a few days).

Updating = upload a new version (bump `version` in `manifest.json`); it goes
through review again.
