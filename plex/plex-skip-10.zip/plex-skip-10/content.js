(() => {
  "use strict";

  const FWD_SELECTOR = '[data-testid="skipForwardButton"]';

  // Výchozí hodnoty (uživatel je mění na stránce nastavení rozšíření).
  const DEFAULTS = {
    skipSeconds: 10,     // o kolik sekund skákat vpřed
    plexDefault: 30,     // kolik skáče Plex nativně (jen pro detekci)
    remapKeyboard: true, // srovnat i klávesy "." a šipku vpravo
    relabelButton: true, // upravit tooltip/popisek tlačítka
  };
  let cfg = { ...DEFAULTS };

  // ── načtení a živá aktualizace nastavení ───────────────────────────────────
  try {
    chrome.storage?.sync.get(DEFAULTS, (v) => { cfg = { ...DEFAULTS, ...v }; relabel(); });
    chrome.storage?.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      for (const k in changes) cfg[k] = changes[k].newValue;
      relabel();
    });
  } catch (_) { /* storage nedostupné → jedeme na DEFAULTS */ }

  // ── pomocné ────────────────────────────────────────────────────────────────
  const findVideo = () => {
    const vids = [...document.querySelectorAll("video")];
    if (!vids.length) return null;
    const playing = vids.find(v => !v.paused && !v.ended && v.readyState > 2);
    if (playing) return playing;
    return vids.sort(
      (a, b) => (isFinite(b.duration) ? b.duration : 0) - (isFinite(a.duration) ? a.duration : 0)
    )[0];
  };

  const onFwdButton = (e) =>
    e.target instanceof Element && e.target.closest(FWD_SELECTOR);

  // ── zapamatovat pozici před skokem (tlačítko) ──────────────────────────────
  let armed = null;
  const arm = (e) => {
    if (!onFwdButton(e)) return;
    const v = findVideo();
    if (v) armed = { pos: v.currentTime, t: performance.now(), v };
  };
  ["pointerdown", "mousedown", "touchstart"].forEach((type) =>
    window.addEventListener(type, arm, true)
  );

  // ── klávesy "." a ArrowRight (v Plexu taky +30 s) ──────────────────────────
  window.addEventListener("keydown", (e) => {
    if (!cfg.remapKeyboard) return;
    const tag = (e.target && e.target.tagName) || "";
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(tag) || e.target?.isContentEditable) return;
    if (e.key === "." || e.key === "ArrowRight") {
      const v = findVideo();
      if (v) armed = { pos: v.currentTime, t: performance.now(), v };
    }
  }, true);

  // ── po skoku srovnat velký posun vpřed na skipSeconds ──────────────────────
  const onSeeked = (ev) => {
    if (!armed) return;
    const v = armed.v || ev.target;
    if (performance.now() - armed.t > 1500) { armed = null; return; }
    const delta = v.currentTime - armed.pos;
    if (delta > cfg.skipSeconds + 1.5) {
      const pos = armed.pos;
      armed = null;
      const dur = isFinite(v.duration) ? v.duration : Infinity;
      v.currentTime = Math.max(0, Math.min(dur - 0.25, pos + cfg.skipSeconds));
    } else {
      armed = null;
    }
  };

  const hookVideos = () => {
    document.querySelectorAll("video").forEach((v) => {
      if (v.__skip10hooked) return;
      v.__skip10hooked = true;
      v.addEventListener("seeked", onSeeked);
    });
  };

  // ── přepsat popisek tlačítka (číslo "30" v ikoně je grafika) ───────────────
  function relabel() {
    if (!cfg.relabelButton) return;
    const label = `Skip Forward ${cfg.skipSeconds} Seconds`;
    document.querySelectorAll(FWD_SELECTOR).forEach((btn) => {
      if (btn.getAttribute("title") !== null && btn.getAttribute("title") !== label)
        btn.setAttribute("title", label);
      if (btn.getAttribute("aria-label")) btn.setAttribute("aria-label", label);
    });
  }

  new MutationObserver(() => { hookVideos(); relabel(); })
    .observe(document.documentElement, { childList: true, subtree: true });
  hookVideos();
  relabel();
})();
