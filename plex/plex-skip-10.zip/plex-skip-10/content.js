(() => {
  "use strict";

  // ══════════════════════════════════════════════════════════════════════════
  //  Plex Web helper: custom skip-forward step + optional PIN auto-unlock
  // ══════════════════════════════════════════════════════════════════════════

  const FWD_SELECTOR = '[data-testid="skipForwardButton"]';

  const SYNC_DEFAULTS = {
    skipEnabled: true,    // master switch for the skip-step override
    skipSeconds: 10,      // how many seconds to skip forward
    remapKeyboard: true,  // also affect "." and ArrowRight
    relabelButton: true,  // rewrite the button tooltip
    autoUnlock: false,    // auto-select profile + enter PIN
    profileName: "",      // profile (home user) to pick, e.g. "Falco"
  };
  // Stored separately in storage.local so it never leaves this device.
  const LOCAL_DEFAULTS = { pin: "" };

  let cfg = { ...SYNC_DEFAULTS, ...LOCAL_DEFAULTS };

  // Forward the skip settings to the MAIN-world script (it has no chrome.*).
  // Only skip settings are sent - never the PIN.
  function pushConfig() {
    document.dispatchEvent(new CustomEvent("plexHelper:config", {
      detail: {
        skipEnabled: cfg.skipEnabled,
        skipSeconds: cfg.skipSeconds,
        remapKeyboard: cfg.remapKeyboard,
      },
    }));
  }

  // main.js patches currentTime directly, which is the clean path (one seek).
  // If it is unavailable, we fall back to correcting after the seek.
  let mainActive = false;
  document.addEventListener("plexHelper:mainReady", () => { mainActive = true; });

  try {
    chrome.storage?.sync.get(SYNC_DEFAULTS, (v) => { Object.assign(cfg, v); relabel(); pushConfig(); });
    chrome.storage?.local.get(LOCAL_DEFAULTS, (v) => { Object.assign(cfg, v); });
    chrome.storage?.onChanged.addListener((changes) => {
      for (const k in changes) cfg[k] = changes[k].newValue;
      // settings changed → allow the unlock flow to try again
      unlock.profileTried = false;
      unlock.pinTried = false;
      relabel();
      pushConfig();
    });
  } catch (_) { /* storage unavailable → run on defaults */ }

  // ──────────────────────────────────────────────────────────────────────────
  //  Part 1 – skip forward step
  // ──────────────────────────────────────────────────────────────────────────
  const findVideo = () => {
    const vids = [...document.querySelectorAll("video")];
    if (!vids.length) return null;
    const playing = vids.find(v => !v.paused && !v.ended && v.readyState > 2);
    if (playing) return playing;
    return vids.sort(
      (a, b) => (isFinite(b.duration) ? b.duration : 0) - (isFinite(a.duration) ? a.duration : 0)
    )[0];
  };

  const onFwdButton = (e) =>
    e.target instanceof Element && e.target.closest(FWD_SELECTOR);

  let armed = null;
  const arm = (e) => {
    if (mainActive) return;            // main.js handles it without a stutter
    if (!cfg.skipEnabled || !onFwdButton(e)) return;
    const v = findVideo();
    if (v) armed = { pos: v.currentTime, t: performance.now(), v };
  };
  ["pointerdown", "mousedown", "touchstart"].forEach((type) =>
    window.addEventListener(type, arm, true)
  );

  window.addEventListener("keydown", (e) => {
    if (mainActive) return;            // main.js handles it without a stutter
    if (!cfg.skipEnabled || !cfg.remapKeyboard) return;
    const tag = (e.target && e.target.tagName) || "";
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(tag) || e.target?.isContentEditable) return;
    if (e.key === "." || e.key === "ArrowRight") {
      const v = findVideo();
      if (v) armed = { pos: v.currentTime, t: performance.now(), v };
    }
  }, true);

  const onSeeked = (ev) => {
    if (!armed) return;
    const v = armed.v || ev.target;
    if (performance.now() - armed.t > 1500) { armed = null; return; }
    const delta = v.currentTime - armed.pos;
    if (delta > cfg.skipSeconds + 1.5) {
      const pos = armed.pos;
      armed = null;
      const dur = isFinite(v.duration) ? v.duration : Infinity;
      v.currentTime = Math.max(0, Math.min(dur - 0.25, pos + cfg.skipSeconds));
    } else {
      armed = null;
    }
  };

  const hookVideos = () => {
    document.querySelectorAll("video").forEach((v) => {
      if (v.__skipHooked) return;
      v.__skipHooked = true;
      v.addEventListener("seeked", onSeeked);
    });
  };

  function relabel() {
    if (!cfg.skipEnabled || !cfg.relabelButton) return;
    const label = `Skip Forward ${cfg.skipSeconds} Seconds`;
    document.querySelectorAll(FWD_SELECTOR).forEach((btn) => {
      if (btn.getAttribute("title") !== null && btn.getAttribute("title") !== label)
        btn.setAttribute("title", label);
      if (btn.getAttribute("aria-label")) btn.setAttribute("aria-label", label);
    });
  }

  // ──────────────────────────────────────────────────────────────────────────
  //  Part 2 – auto profile select + PIN
  //
  //  Plex's user-select modal is a Backbone/Marionette view:
  //    ul.tile-list.user-select-list  → profile tiles (click the <a>)
  //    .user-select-modal-pin-container input.pin-input → PIN field
  //  Plex submits by itself as soon as the field holds 4 digits.
  //
  //  Each step is attempted only ONCE per page load. That is deliberate: a
  //  wrong stored PIN must not be retried in a loop, which could lock the
  //  account. After a failed attempt you finish by hand and fix the settings.
  // ──────────────────────────────────────────────────────────────────────────
  const unlock = { profileTried: false, pinTried: false };

  const visible = (el) => !!(el && el.offsetParent !== null);

  // Set a value so that framework listeners notice it (native setter + events).
  function setNativeValue(input, value) {
    const proto = Object.getPrototypeOf(input);
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(input, value);
    else input.value = value;
  }

  function pickProfile() {
    if (unlock.profileTried) return;
    const wanted = (cfg.profileName || "").trim().toLowerCase();
    if (!wanted) return;

    const list = document.querySelector("ul.user-select-list");
    if (!visible(list)) return;

    const items = [...list.querySelectorAll("li")];
    if (!items.length) return;

    const match = items.find((li) => {
      if (li.classList.contains("disabled")) return false;
      const text = (li.textContent || "").trim().toLowerCase();
      const alt = (li.querySelector("img")?.getAttribute("alt") || "").trim().toLowerCase();
      return text === wanted || alt === wanted ||
             (text.length > 0 && text.includes(wanted));
    });
    if (!match) return;

    unlock.profileTried = true;
    (match.querySelector("a") || match).click();
  }

  function fillPin() {
    if (unlock.pinTried) return;
    const pin = (cfg.pin || "").replace(/\D/g, "");
    if (pin.length !== 4) return; // Plex PINs are 4 digits

    const input = document.querySelector(".user-select-modal-pin-container input.pin-input");
    if (!input || !visible(input.closest(".user-select-modal-pin-container"))) return;

    unlock.pinTried = true;

    // Plex's onInput handler auto-submits once the field contains 4 digits,
    // so a single input event after setting the value is enough.
    input.focus();
    setNativeValue(input, pin);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    // Fallback for builds that wait for a submit instead.
    setTimeout(() => {
      const form = document.querySelector("#pin-form");
      if (form && visible(form) && input.value.length === 4) {
        form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
      }
    }, 400);
  }

  function autoUnlockTick() {
    if (!cfg.autoUnlock) return;
    pickProfile();
    fillPin();
  }

  // ──────────────────────────────────────────────────────────────────────────
  new MutationObserver(() => { hookVideos(); relabel(); autoUnlockTick(); })
    .observe(document.documentElement, { childList: true, subtree: true });
  hookVideos();
  relabel();
  autoUnlockTick();
  pushConfig();   // also serves as a handshake ping to main.js
})();
