(() => {
  "use strict";

  // ─── Nastavení ─────────────────────────────────────────────────────────────
  const SKIP_SECONDS   = 10;    // o kolik sekund má tlačítko vpřed skákat
  const PLEX_DEFAULT   = 30;    // kolik skáče Plex nativně (pro detekci)
  const REMAP_KEYBOARD = true;  // srovnat i klávesy "." a šipku vpravo na SKIP_SECONDS
  const RELABEL_BUTTON = true;  // upravit tooltip/popisek tlačítka
  // ───────────────────────────────────────────────────────────────────────────

  const FWD_SELECTOR = '[data-testid="skipForwardButton"]';

  // Hlavní přehrávané <video> (Plex má i skrytá video pro náhledy).
  const findVideo = () => {
    const vids = [...document.querySelectorAll("video")];
    if (!vids.length) return null;
    const playing = vids.find(v => !v.paused && !v.ended && v.readyState > 2);
    if (playing) return playing;
    return vids.sort(
      (a, b) => (isFinite(b.duration) ? b.duration : 0) - (isFinite(a.duration) ? a.duration : 0)
    )[0];
  };

  const onFwdButton = (e) =>
    e.target instanceof Element && e.target.closest(FWD_SELECTOR);

  // Když se zmáčkne tlačítko vpřed, zapamatujeme si pozici PŘED skokem.
  // (pointerdown/mousedown/touchstart přijdou dřív, než Plex provede seek.)
  let armed = null;
  const arm = (e) => {
    if (!onFwdButton(e)) return;
    const v = findVideo();
    if (v) armed = { pos: v.currentTime, t: performance.now(), v };
  };
  ["pointerdown", "mousedown", "touchstart"].forEach((type) =>
    window.addEventListener(type, arm, true)
  );

  // Když Plex skočí (nebo skočí klávesa), srovnáme velký skok vpřed na SKIP_SECONDS.
  const onSeeked = (ev) => {
    if (!armed) return;
    const v = armed.v || ev.target;
    if (performance.now() - armed.t > 1500) { armed = null; return; }
    const delta = v.currentTime - armed.pos;
    // Reagujeme jen na výrazný skok vpřed (Plexových ~30 s), ne na krok zpět
    // ani na drobné posuny.
    if (delta > SKIP_SECONDS + 1.5) {
      const pos = armed.pos;
      armed = null; // nejdřív odjistit, ať se náš vlastní seek nekoriguje znovu
      const target = Math.min((isFinite(v.duration) ? v.duration : Infinity) - 0.25,
                              pos + SKIP_SECONDS);
      v.currentTime = Math.max(0, target);
    } else {
      armed = null;
    }
  };

  // Připojit posluchač 'seeked' na každé <video>, i na nově vzniklá.
  const hookVideos = () => {
    document.querySelectorAll("video").forEach((v) => {
      if (v.__skip10hooked) return;
      v.__skip10hooked = true;
      v.addEventListener("seeked", onSeeked);
    });
  };

  // Volitelně: klávesy "." a ArrowRight (v Plexu taky +30 s) → jen je „naarmujeme",
  // srovnání pak udělá stejný onSeeked.
  if (REMAP_KEYBOARD) {
    window.addEventListener("keydown", (e) => {
      const tag = (e.target && e.target.tagName) || "";
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(tag) || e.target?.isContentEditable) return;
      if (e.key === "." || e.key === "ArrowRight") {
        const v = findVideo();
        if (v) armed = { pos: v.currentTime, t: performance.now(), v };
      }
    }, true);
  }

  // Volitelně: přepsat textový popisek tlačítka (číslo "30" v ikoně je grafika).
  const relabel = () => {
    if (!RELABEL_BUTTON) return;
    const label = `Skip Forward ${SKIP_SECONDS} Seconds`;
    document.querySelectorAll(FWD_SELECTOR).forEach((btn) => {
      if (btn.getAttribute("title") !== null && btn.getAttribute("title") !== label)
        btn.setAttribute("title", label);
      if (btn.getAttribute("aria-label")) btn.setAttribute("aria-label", label);
    });
  };

  // Sledovat změny DOM (React průběžně překresluje ovládací prvky i <video>).
  new MutationObserver(() => { hookVideos(); relabel(); })
    .observe(document.documentElement, { childList: true, subtree: true });
  hookVideos();
  relabel();
})();
