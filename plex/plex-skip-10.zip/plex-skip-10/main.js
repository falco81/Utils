(() => {
  "use strict";

  // ══════════════════════════════════════════════════════════════════════════
  //  Runs in the PAGE's JS world (world: "MAIN"), so it can patch the DOM
  //  prototypes that Plex itself uses.
  //
  //  Instead of letting Plex seek +30s and correcting afterwards (two seeks,
  //  visible stutter), we intercept the assignment to video.currentTime and
  //  rewrite the target value BEFORE the seek happens. Result: one single
  //  seek, straight to +10s.
  // ══════════════════════════════════════════════════════════════════════════

  const FWD_SELECTOR = '[data-testid="skipForwardButton"]';
  const ARM_WINDOW_MS = 1200; // how long after a click/keypress a seek counts as "the skip"

  let cfg = { skipEnabled: true, skipSeconds: 10, remapKeyboard: true };
  let armedUntil = 0;

  // Settings arrive from the isolated content script (it owns chrome.storage).
  document.addEventListener("plexHelper:config", (e) => {
    if (e.detail && typeof e.detail === "object") Object.assign(cfg, e.detail);
    // Re-announce: the isolated script may have missed our initial signal.
    document.dispatchEvent(new CustomEvent("plexHelper:mainReady"));
  });

  const arm = () => { armedUntil = performance.now() + ARM_WINDOW_MS; };

  // Arm on the skip-forward button.
  ["pointerdown", "mousedown", "touchstart"].forEach((type) =>
    window.addEventListener(type, (e) => {
      if (!cfg.skipEnabled) return;
      if (e.target instanceof Element && e.target.closest(FWD_SELECTOR)) arm();
    }, true)
  );

  // Arm on the keys Plex maps to +30s.
  window.addEventListener("keydown", (e) => {
    if (!cfg.skipEnabled || !cfg.remapKeyboard) return;
    const tag = (e.target && e.target.tagName) || "";
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(tag) || e.target?.isContentEditable) return;
    if (e.key === "." || e.key === "ArrowRight") arm();
  }, true);

  // ── patch currentTime ─────────────────────────────────────────────────────
  const proto = HTMLMediaElement.prototype;
  const desc = Object.getOwnPropertyDescriptor(proto, "currentTime");
  if (!desc || !desc.set || !desc.get) return;

  // Decide the real target for a requested seek.
  const rewrite = function (el, requested) {
    if (!cfg.skipEnabled) return requested;
    if (performance.now() > armedUntil) return requested;

    const cur = desc.get.call(el);
    if (!isFinite(cur) || !isFinite(requested)) return requested;

    const delta = requested - cur;
    // Only touch a clearly-forward jump bigger than what we want (Plex's ~30s).
    // Scrubbing, small nudges and any backward seek pass through untouched.
    if (delta <= cfg.skipSeconds + 1.5) return requested;

    armedUntil = 0; // consume the arm: one rewrite per click
    const dur = el.duration;
    const cap = isFinite(dur) ? dur - 0.25 : Infinity;
    return Math.max(0, Math.min(cap, cur + cfg.skipSeconds));
  };

  Object.defineProperty(proto, "currentTime", {
    configurable: true,
    enumerable: desc.enumerable,
    get: desc.get,
    set: function (value) {
      desc.set.call(this, rewrite(this, Number(value)));
    },
  });

  // Some players use fastSeek() instead.
  if (typeof proto.fastSeek === "function") {
    const origFastSeek = proto.fastSeek;
    proto.fastSeek = function (value) {
      return origFastSeek.call(this, rewrite(this, Number(value)));
    };
  }

  // Tell the isolated script the fast path is live, so it can disable its
  // after-the-fact correction fallback.
  document.dispatchEvent(new CustomEvent("plexHelper:mainReady"));
})();
