#!/usr/bin/env python3
"""The two roads a one-tap link may be opened by, and the code on the second.

A link's secret used to travel in the address, where a web server log, a
proxy, a browser history and the robot that fetches a link preview all keep a
copy - and that last one physically presses the link when the address is
pasted into a message. The header road puts the same secret in a header of a
POST, where none of them can see it, and a six-digit code from a phone can be
asked for on top.

Nothing here needs a broker or a web server.

    ZIGMON_CONFIG=/tmp/zt.json PYTHONPATH=. python3 test/taps.py
"""
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.argv = ['zigmon']
import zigmon                                            # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-taps-check.db'
zigmon.CONFIG['api_port'] = 19701
zigmon.CONFIG['token_file'] = '/tmp/zigmon-taps-token'
Path(zigmon.CONFIG['db_file']).unlink(missing_ok=True)
d = zigmon.Daemon()

# -- the maths, against the examples in RFC 6238 ------------------------------
RFC = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ'
for when, want in ((59, '287082'), (1111111109, '081804'),
                   (1234567890, '005924'), (2000000000, '279037')):
    got = zigmon.totp_at(RFC, when // zigmon.TOTP_STEP)
    assert got == want, 'RFC 6238 at %d gave %s, wanted %s' % (when, got, want)
print('TOTP: four test vectors from RFC 6238, all four right')

# -- which road is open -------------------------------------------------------
d.save_taps([{'name': 'Lamp', 'target': 'notify', 'do': 'on'}])
token = d.taps()[0]['token']


def opened(way, code='', ask=False):
    ok, answer = d.tap(token, '1.2.3.4', ask=ask, way=way, code=code)
    return ok, (answer if isinstance(answer, str) else dict(answer))


for mode, by_link, by_header in (('link', True, False), ('both', True, True), ('header', False, True)):
    zigmon.CONFIG['tap_mode'] = mode
    assert opened('link')[0] is by_link, '%s: the address should be %s' % (mode, 'open' if by_link else 'shut')
    assert opened('header')[0] is by_header, '%s: the header should be %s' % (mode, 'open' if by_header else 'shut')
    print('%-6s address %-7s header %s' % (mode, 'opens' if by_link else 'refused',
                                           'opens' if by_header else 'refused'))

def outward(answer):
    """What the phone is actually sent, whichever shape came back inside."""
    if isinstance(answer, dict):
        return int(answer.get('status') or 403), answer.get('error')
    return 404, answer


# A road that is shut must answer word for word what an address that does not
# exist answers, or an old log tells whoever reads it that its link is real.
zigmon.CONFIG['tap_mode'] = 'header'
assert outward(opened('link')[1]) == outward(d.tap('not-a-real-token', '1.2.3.4')[1]), \
    'a shut road gives itself away by answering differently from an unknown link'
print('a shut road answers exactly as an unknown link does')

# A shut road is not somebody guessing. The secret was right; this is a
# shortcut that has not been changed over. Counted as a wrong try, ten presses
# of a watch face nobody has rewritten shut the links for a minute - taking
# the new shortcut down with them - and each one cost a second of a web
# server worker.
for _ in range(20):
    ok, answer = opened('link')
    assert not ok
    assert isinstance(answer, dict) and answer['status'] == 404, \
        'an old-style press is counted as a guess: %r' % (answer,)
assert d.tap_may_try('1.2.3.4'), 'twenty presses of an old shortcut shut the links'
was = time.time()
opened('link')
assert time.time() - was < 0.2, 'an old-style press is still made to wait'
print('an old shortcut is refused the same way, and costs nothing')

# -- the code -----------------------------------------------------------------
d.save_tap_keys([{'name': 'Falco iPhone'}])
secret = d.tap_keys()[0]['secret']
zigmon.CONFIG['tap_code'] = 1
assert d.tap_code_wanted()

ok, answer = opened('header')
assert not ok and answer['status'] == 403, 'a header with no code was let through'
ok, answer = opened('header', code='000000')
assert not ok and answer['status'] == 403, 'six wrong digits were let through'

def code_from(steps_back=0):
    # read the clock for each one: a window that turns over between two lines
    # of this test would otherwise make it fail for no reason
    return zigmon.totp_at(secret, int(time.time() // zigmon.TOTP_STEP) - steps_back)


assert opened('header', code=code_from())[0], 'the code showing now was refused'
# A code is good while its own window is open - somebody in a doorway presses
# twice - and refused for ever after, which is what makes a secret read out of
# a log next week worth nothing.
assert opened('header', code=code_from())[0], 'the second press inside the same code was refused'
assert opened('header', code=code_from(1))[0], 'a clock a step slow was refused'
assert not opened('header', code=code_from(3))[0], 'a code a minute and a half old was taken'
assert not opened('header', code=code_from(20160))[0], 'a code from a week ago was taken'
print('the code: this window and one either side, and nothing older')

# asking how things stand touches nothing and needs no code
assert opened('header', ask=True)[0], 'asking was refused'

# -- a new secret for the same phone -----------------------------------------
# A secret seen by the wrong person is replaced, not the phone taken away:
# taking it away would be a second decision - about which links it may open -
# that nobody asked to make.
was = d.tap_keys()[0]['secret']
kept = d.tap_keys()[0]['id']
fresh = zigmon.totp_secret()
d.store.set_meta('tap_keys', __import__('json').dumps(
    [dict(k, secret=fresh) if k['id'] == kept else k for k in d.tap_keys()]))
assert d.tap_keys()[0]['id'] == kept, 'rolling the secret changed which phone it is'
assert d.tap_keys()[0]['name'] == 'Falco iPhone', 'rolling the secret lost the name'
assert not d.tap_key_for(zigmon.totp_at(was, int(time.time() // zigmon.TOTP_STEP))), \
    'the old secret still opens things'
assert d.tap_key_for(zigmon.totp_at(fresh, int(time.time() // zigmon.TOTP_STEP))), \
    'the new secret does not open anything'
secret = fresh
print('a phone can be given a new secret without losing its name or its links')

# -- the wait before reading a socket back ------------------------------------
# Only where there is a socket to read. A link on a notification, on heating,
# on a Zigbee switch or on a sequence has nothing to come back for, and the
# third of a second was spent on the wrist for nothing at every press.
zigmon.CONFIG['tap_code'] = 0
started = time.time()
assert opened('header')[0], 'the press was refused'
spent = time.time() - started
assert spent < 0.1, 'a link with nothing to read back still waits %.2f s' % spent
print('a press with nothing to read back answers at once (%.0f ms)' % (spent * 1000))

# and where there IS a socket, the wait is still taken and the state is read
# twice: once to see whether it is worth waiting for, once for the answer
reads = []
real_state = d.tap_state


def counted(targets):
    reads.append(time.time())
    return 'on', 'on'                 # as a socket would answer


d.tap_state = counted
started = time.time()
assert opened('header')[0]
spent = time.time() - started
d.tap_state = real_state
assert len(reads) == 2, 'the state was read %d time(s), wanted twice' % len(reads)
assert 0.3 < spent < 0.6, 'a socket was not given its moment to answer (%.2f s)' % spent
print('a press on a socket still waits for it (%.0f ms)' % (spent * 1000))
zigmon.CONFIG['tap_code'] = 1

# -- the other second factor: Duo approves it --------------------------------
# The watch cannot make a six-digit code, so the code has to be finished on
# the phone. Duo asks the person instead and has a watch app of its own, so
# the press is approved where it was made. Nothing about it is asked of the
# shortcut beyond coming back for the answer.
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'duo'
for key in ('duo_host', 'duo_ikey', 'duo_skey', 'duo_user'):
    zigmon.CONFIG[key] = ''
ok, answer = opened('header')
assert not ok and answer['status'] == 503, 'a link asked Duo while Duo was not set up'
zigmon.CONFIG.update({'duo_host': 'api-test.duosecurity.com', 'duo_ikey': 'DI', 'duo_skey': 's',
                      'duo_user': 'somebody'})

asked = []


def _yes(what, who=''):
    asked.append(what)
    time.sleep(0.3)
    return True, 'approved'


d.duo_push = _yes
ok, answer = opened('header')
assert ok and answer['state'] == 'waiting' and answer.get('ticket'), \
    'the press did not come back with a ticket: %r' % (answer,)
ticket = answer['ticket']
got, state = d.tap_waiting(ticket, 5)
assert got and state['state'] == 'done', 'an approved press did not happen: %r' % (state,)
assert asked and 'notification' in asked[0], 'Duo was not told what it was approving: %r' % (asked,)
# asking again says the same thing rather than doing it twice
again = d.tap_waiting(ticket, 1)
assert again[1]['state'] == 'done'
d.duo_push = lambda what, who='': (False, 'denied')
ok, answer = opened('header')
assert d.tap_waiting(answer['ticket'], 5)[1]['state'] == 'refused', 'a refused press was let through'
assert d.tap_waiting('not-a-ticket', 1)[1]['status'] == 404, 'a ticket nobody made was answered'
print('Duo: a press waits to be approved, and happens only if it is')

# The signature Duo checks. Two ways of writing the canonical form are in use
# - the one the Auth API documents and the one the published client defaults
# to - and an account takes one and calls the other "Invalid signature in
# request credentials", which says nothing about which. Both are written out,
# so both must keep their shape.
_when = 'Tue, 21 Aug 2012 17:25:06 -0700'
_ikey, _skey = 'DIWJ8X6AEYOR5OMC6TQ1', 'Zh5eGmUq9zpfQnyUIu5OL9iWoMMv5ZNmk3zLJ4Ep'
_params = {'factor': 'push', 'username': 'somebody'}
_shapes = set()
for _v, _d in zigmon.DUO_WAYS:
    _one = zigmon.duo_sign(_ikey, _skey, 'POST', 'api-XXXXXXXX.duosecurity.com', '/auth/v2/auth',
                           _when, _params, _v, _d)
    assert _one.startswith('Basic '), 'v%s %s is not an Authorization header' % (_v, _d)
    assert _one == zigmon.duo_sign(_ikey, _skey, 'POST', 'api-XXXXXXXX.duosecurity.com',
                                   '/auth/v2/auth', _when, _params, _v, _d), \
        'v%s %s signed the same request two ways' % (_v, _d)
    assert _one != zigmon.duo_sign(_ikey, _skey, 'POST', 'api-XXXXXXXX.duosecurity.com',
                                   '/auth/v2/auth', _when, {'factor': 'push', 'username': 'else'}, _v, _d), \
        'v%s %s does not sign the parameters' % (_v, _d)
    _shapes.add(_one)
assert len(_shapes) == len(zigmon.DUO_WAYS), 'two ways of signing give the same answer, so one is wrong'
print('Duo: all %d ways of signing keep their shape, and differ from each other' % len(zigmon.DUO_WAYS))

# And which way an account takes is found out rather than assumed: four ways
# of signing are in use between the versions of the canonical form and the two
# digests, and an account takes one and calls the other three a bad signature
# without saying which. Each is tried in turn and the one that answers is
# written down.
_tried = []


def _only_sha1(method, path, params, host, version, digest, timeout):
    _tried.append('%s:%s' % (version, digest))
    if (version, digest) != ('2', 'sha1'):
        raise ValueError('Invalid signature in request credentials')
    return {'time': 1}


zigmon.CONFIG.update({'duo_host': 'api-x.duosecurity.com', 'duo_ikey': 'DI', 'duo_skey': 'sk'})
d.duo_lib = lambda timeout=20: None        # the machine without Duo's own package
d._duo_once = _only_sha1
d.duo_call('GET', '/auth/v2/check', {})
assert _tried == ['2:sha512', '2:sha1'], 'it did not walk the ways in order: %r' % (_tried,)
_tried.clear()
d.duo_call('GET', '/auth/v2/check', {})
assert _tried == ['2:sha1'], 'it asked all over again instead of remembering: %r' % (_tried,)
assert d.store.get_meta('duo_way') == '2:sha1', 'the way that worked was not written down'
print('Duo: the way of signing is found once and then remembered')

# Duo's own package is the reference for every detail of the signing, so it is
# used wherever the machine has it, and what is written out here is only for a
# machine that has not.
_lib_tried = []
d._duo_way = None
d.store.set_meta('duo_way', '')


class _PretendLib(object):
    def json_api_call(self, method, path, params):
        _lib_tried.append(path)
        return {'time': 1}


d.duo_lib = lambda timeout=20: _PretendLib()
assert d.duo_call('GET', '/auth/v2/check', {}) == {'time': 1}
assert _lib_tried == ['/auth/v2/check'], 'the package was there and was not used'
_tried.clear()
assert not _tried, 'it signed for itself while the package was answering'
d.duo_lib = lambda timeout=20: None
d.duo_call('GET', '/auth/v2/check', {})
assert _tried, 'without the package it did not sign for itself'
print('Duo: the package is used where it is installed, and not needed where it is not')

# What the endpoint answers is a `result` - waiting, allow or deny. The
# published client's own auth_status() turns that into `waiting` and
# `success`, and this asks the endpoint directly, so it gets neither: reading
# those off the raw answer made every press refused a fifth of a second after
# it was made, before the phone had finished buzzing.
d.duo_push = zigmon.Daemon.duo_push.__get__(d)     # the real one again, not the stub above
_answers = []


def _push_then(*seq):
    _answers[:] = list(seq)

    def call(method, path, params, timeout=20):
        if path.endswith('/auth'):
            return {'txid': 't-1'}
        return _answers.pop(0) if _answers else {'result': 'waiting'}
    d.duo_call = call


_push_then({'result': 'waiting', 'status': 'pushed'}, {'result': 'allow', 'status_msg': 'Approved'})
assert d.duo_push('a lamp') == (True, 'Approved'), 'a press waiting on the phone was called refused'
_push_then({'result': 'deny', 'status_msg': 'Login request denied.'})
assert d.duo_push('a lamp')[0] is False, 'a refused press was let through'
# and the shape the package's own auth_status() hands back is read too
_push_then({'waiting': True}, {'waiting': False, 'success': True, 'status_msg': 'ok'})
assert d.duo_push('a lamp') == (True, 'ok'), 'the package\u2019s own shape was misread'
print('Duo: a press waits while Duo says it is waiting, and only then is it answered')

# An account with three devices cannot be asked to guess which one Duo's own
# "auto" will pick - it is as likely to be the iPad on a shelf as the phone in
# a pocket. What preauth says is kept, so the dashboard can offer the list,
# and the one chosen is what the press is addressed to.
_pre = {'result': 'auth', 'devices': [
    {'device': 'DP111', 'display_name': 'iPad 2019', 'capabilities': ['auto', 'push']},
    {'device': 'DP333', 'display_name': 'iPhone16', 'capabilities': ['auto', 'push', 'sms']}]}
d.duo_call = lambda m, p, params, timeout=20: {} if p.endswith('check') else _pre
assert d.duo_check()[0], 'the test refused an account that can take a push'
assert [x['device'] for x in d.duo_devices()] == ['DP111', 'DP333'], 'the devices were not kept'
assert [x['name'] for x in d.status()['duo_devices']] == ['iPad 2019', 'iPhone16'], \
    'the dashboard is not told what it may choose between'
d.save_config_overrides({'duo_device': 'DP333'})
_sent = {}


def _watch(m, p, params, timeout=20):
    if p.endswith('/auth'):
        _sent.update(params)
        return {'txid': 't'}
    return {'result': 'allow', 'status_msg': 'ok'}


d.duo_call = _watch
d.duo_push('a lamp')
assert _sent.get('device') == 'DP333', 'the press was not addressed to the chosen device: %r' % (_sent,)
zigmon.CONFIG['duo_device'] = 'auto'
d.duo_push('a lamp')
assert _sent.get('device') == 'auto', 'auto stopped meaning auto'
print('Duo: the press goes to the device that was chosen, not the one Duo would pick')

# A press that has to be approved is answered when it is approved, not with a
# ticket to come back for: coming back is three more actions in a shortcut,
# and a person standing at a door is waiting either way.
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'duo'
zigmon.CONFIG['duo_wait_s'] = 10
d.duo_push = lambda what, who='': (time.sleep(0.4) or (True, 'approved'))
_started = time.time()
_ok, _answer = d.tap(token, '1.2.3.4', way='header')
assert _ok and _answer.get('ticket'), 'the press did not start'
_ok, _answer = d.tap_waiting(_answer['ticket'], 5)
assert _ok and _answer['state'] == 'done', 'waiting on the ticket did not give the outcome'
assert time.time() - _started >= 0.4, 'it answered before the approval could arrive'
print('Duo: the outcome can be waited for on the one request that made it')

# A key pasted from a web page brings a space or a newline with it more often
# than not, and Duo refuses a key with one stuck to it in exactly the words it
# refuses a wrong key with.
d.save_config_overrides({'duo_host': ' api-x.duosecurity.com \n', 'duo_ikey': ' DI ',
                         'duo_skey': 'SK\n', 'duo_user': ' falco '})
for _k, _want in (('duo_host', 'api-x.duosecurity.com'), ('duo_ikey', 'DI'),
                  ('duo_skey', 'SK'), ('duo_user', 'falco')):
    assert zigmon.CONFIG[_k] == _want, '%s was stored as %r' % (_k, zigmon.CONFIG[_k])
print('Duo: what is pasted in is stored without the whitespace around it')

# Nothing is thrown away by choosing one factor over the other.
_before = [k['secret'] for k in d.tap_keys()]
zigmon.CONFIG['tap_factor'] = 'totp'
assert [k['secret'] for k in d.tap_keys()] == _before, 'the phones lost their secrets'
zigmon.CONFIG['tap_factor'] = 'duo'
assert str(zigmon.CONFIG['duo_ikey']), 'the Duo keys were lost'
zigmon.CONFIG['tap_factor'] = 'totp'
zigmon.CONFIG['tap_code'] = 1
assert opened('header', code=code_from())[0], 'a code stopped working after a turn through Duo'
print('both factors keep what is theirs, whichever is chosen')

# -- what the dashboard may see ----------------------------------------------
state = d.status()
assert secret not in repr(state), 'a code secret went out with the status'
assert [k.get('secret') for k in state['tap_keys']] == [None], 'the phones went out with their secrets'
assert all('secret' not in k for k in state['tap_keys'])
print('the phones go out by name; the secrets stay in the daemon')

# Choosing a factor and demanding one are two decisions. Refusing both at once
# made the choice impossible to make: Duo's boxes are not asked for until Duo
# is the factor, and Duo could not be made the factor until its boxes were
# filled in - so there was nowhere to type them. The choice stands; the demand
# is what gives way, and says so.
zigmon.CONFIG['tap_mode'] = 'header'
for _k in ('duo_host', 'duo_ikey', 'duo_skey', 'duo_user'):
    zigmon.CONFIG[_k] = ''
d.save_config_overrides({'tap_factor': 'duo', 'tap_code': 1})
assert zigmon.CONFIG['tap_factor'] == 'duo', 'Duo could not be chosen before it was set up'
assert not zigmon.CONFIG['tap_code'], 'a factor nothing can answer was left demanded'
assert 'Duo' in (d.last_config_note or ''), 'nothing was said about why it was switched off'
d.save_config_overrides({'duo_host': 'api-x.duosecurity.com', 'duo_ikey': 'DI',
                         'duo_skey': 'sk', 'duo_user': 'falco'})
d.save_config_overrides({'tap_code': 1})
assert zigmon.CONFIG['tap_code'] and not d.last_config_note, 'it could not be switched on once Duo was set up'
print('Duo can be chosen first and filled in afterwards, which is the only order there is')

# -- the switch that would lock everybody out --------------------------------
zigmon.CONFIG['tap_mode'] = 'link'
zigmon.CONFIG['tap_code'] = 0
zigmon.CONFIG['tap_factor'] = 'totp'
d.store.set_meta('tap_keys', '[]')
d.save_config_overrides({'tap_code': 1, 'tap_mode': 'header'})
assert not zigmon.CONFIG.get('tap_code'), 'a code was demanded with no phone to show one'
assert 'phone' in (d.last_config_note or ''), 'nothing was said about why'
print('a code with no phone to show one is not demanded, and it is said why')


# -- and what this daemon writes down about it --------------------------------
# A secret in an address is a secret in the log. The header road exists
# because a URL is written down everywhere it goes, and the daemon's own debug
# log was one of those places: a link opened by its address went in whole.
# Enough is left to tell two links apart and no more.
_hide = zigmon.ApiHandler.hide_secrets
_line = _hide('"GET /api/tap/%s HTTP/1.1" 200 -' % token)
assert token not in _line, 'a link secret is still written into the log: %s' % _line
assert token[-4:] in _line, 'nothing is left to tell one link from another: %s' % _line
assert 'my-push-word' not in _hide('"GET /index.php?api=sms-incoming&secret=my-push-word HTTP/1.1"'), \
    'the word a forwarded message carries is still written down'
assert token not in _hide('"GET /index.php?t=%s&ask HTTP/1.1" 200 -' % token), \
    'the older address form is still written down whole'
assert _hide('"GET /api/status HTTP/1.1" 200 -') == '"GET /api/status HTTP/1.1" 200 -', \
    'an ordinary line was changed'
assert '{plugs_on_list.nl}' in _hide('"GET /api/message-preview?text={plugs_on_list.nl}"'), \
    'something that is not a secret was blotted out'
print('a secret in an address does not reach the log')

# Behind a server of its own, every press arrives from that server. What it
# says the caller was is worth showing - the proxy's address on every line
# tells nobody anything - but it is a claim, not proof, since anyone may send
# that header. It is shown as a claim, and guesses are counted against the
# address the request really came from, or a guesser would pick a new claim
# per try and the counter would never fill.


class _Pretend(object):
    def __init__(self, headers):
        self.headers = headers
        self.client_address = ('127.0.0.1', 1)
    _who = zigmon.ApiHandler._who


assert _Pretend({'X-Zigmon-Client': '10.8.0.1'})._who() == '10.8.0.1'
_said = _Pretend({'X-Zigmon-Client': '10.8.0.1', 'X-Zigmon-Via': '89.24.5.7, 10.8.0.1'})._who()
assert _said == '10.8.0.1 (says 89.24.5.7)', 'a claim is not shown as a claim: %r' % _said
assert _said.split(' (')[0] == '10.8.0.1', 'the counting would be done against the claim'
assert _Pretend({'X-Zigmon-Client': '1.2.3.4', 'X-Zigmon-Via': '1.2.3.4'})._who() == '1.2.3.4', \
    'a proxy that agrees with itself is said twice'
print('a caller a proxy claims is shown as a claim, and never counted as one')

# The names of stored files come from outside. None of them may name a place
# outside the folder they belong in.
_bad = ['../../../../etc/passwd', '/etc/shadow', 'a/../../../tmp/x', 'ok.db; rm -rf /',
        '..%2f..%2fetc%2fpasswd', 'x' * 300, '\x00etc/passwd', '....//....//etc/passwd',
        'zigmon-db-../../evil.sqlite', 'zigmon-db-x.sqlite/../../../evil']
for _nm in _bad:
    try:
        _p = d.db_backup_path(_nm)
        raise AssertionError('a backup name reached %s' % _p)
    except ValueError:
        pass
_made = re.sub(r'[^0-9A-Za-z._-]', '-', '../../../../etc/passwd')
assert '/' not in _made, 'a separator survived the sanitising'
print('%d hostile file names, none of them naming a place outside the folder' % len(_bad))

# A copy of the house is the same house: the same settings, the same links,
# the same phones. And a file that opens a garage is not made by somebody who
# meant to keep a copy of their layout - the secrets go in only when asked
# for, and without them the restore still works, with fresh ones.
zigmon.CONFIG['tap_mode'] = 'header'
d.save_config_overrides({'tap_mode': 'header', 'tap_factor': 'duo', 'duo_user': 'somebody',
                         'duo_skey': 'THESECRETKEY'})
_plain = json.dumps(d.export_settings())
_full = json.dumps(d.export_settings(secrets=True))
_token = d.taps()[0]['token']
_phone = d.tap_keys()[0]['secret'] if d.tap_keys() else ''
for _secret in [x for x in ('THESECRETKEY', _token, _phone) if x]:
    assert _secret not in _plain, 'a secret is in the ordinary export'
    assert _secret in _full, 'a secret is missing from the one that asked for them'
for _key in ('settings', 'taps', 'tap_keys'):
    assert _key in json.loads(_plain), 'an export without %s is not a copy of the house' % _key
assert json.loads(_plain)['settings'].get('tap_factor') == 'duo', 'Settings are not carried'
assert json.loads(_full)['holds_secrets'] and not json.loads(_plain)['holds_secrets']
print('an export is a copy of the house, and holds no secret unless it is asked for')

# One link, one question at a time. A secret that has leaked can be pressed as
# fast as the network allows, and every press would be a push at somebody's
# phone and a request held open here waiting for an answer: the phone made
# unusable and the web server's workers with it, by somebody who has to be
# right about nothing but the secret.
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'duo'
zigmon.CONFIG.update({'duo_host': 'h', 'duo_ikey': 'i', 'duo_skey': 's', 'duo_user': 'u'})
_asked = []


def _slow(what, who=''):
    _asked.append(time.time())
    time.sleep(0.8)
    return True, 'approved'


d.duo_push = _slow
_tickets = [d.tap(token, '1.2.3.4', way='header')[1]['ticket'] for _ in range(20)]
assert len(set(_tickets)) == 1, 'twenty presses started %d questions' % len(set(_tickets))
time.sleep(1.2)
assert len(_asked) == 1, 'the phone was pushed %d times for one press' % len(_asked)
assert d.tap_waiting(_tickets[0], 3)[1]['state'] == 'done', 'the one question never finished'
print('a link pressed twenty times over asks once, and holds one request open')

# Each held request is a connection here and a web server worker with it, and
# there are only so many of those. Past the ceiling a press is answered at
# once with its ticket, and whoever wants the outcome comes back for it; the
# press itself is unaffected, since it is already asked.
_was_ceiling = d.HOLD_AT_ONCE
d.HOLD_AT_ONCE = 2
assert d.may_hold() and d.may_hold(), 'the first two were not let through'
assert not d.may_hold(), 'the ceiling did not hold'
d.let_go()
assert d.may_hold(), 'letting one go did not make room'
d.let_go(); d.let_go()
d.HOLD_AT_ONCE = _was_ceiling
print('only so many requests are held at once, and the rest are answered at once')

# Calling one off is not undoing it - nothing has happened yet. It tells the
# press that nobody is going to answer, so an approval arriving half a minute
# later finds it called off and does nothing.
_acted = []
d.duo_push = lambda what, who='': (time.sleep(0.6) or (True, 'approved'))
_real_do = d.tap_do
d.tap_do = lambda found, **kw: (_acted.append(found['name']) or (True, {'message': 'done'}))
_ok, _answer = d.tap(token, '1.2.3.4', way='header')
_ticket = _answer['ticket']
_seen = [x for x in d.approvals()['waiting'] if x['ticket'] == _ticket]
assert _seen, 'a press waiting to be approved is not on the list'
assert _seen[0]['link'] and _seen[0]['what'] and _seen[0]['left'] > 0, \
    'the list does not say what it would do or how long it has: %r' % (_seen[0],)
assert d.approval_stop(_ticket, who='the dashboard') == [_seen[0]['link']], 'it was not called off'
assert d.tap_waiting(_ticket, 1)[1]['state'] == 'stopped', 'the shortcut was not told'
time.sleep(1.0)
assert not _acted, 'the approval arrived afterwards and the thing happened anyway'
assert any(x['ticket'] == _ticket and x['state'] == 'stopped' for x in d.approvals()['recent']), \
    'it is not in what became of them'
d.tap_do = _real_do
print('a press can be called off, and an approval arriving after that does nothing')

# What a link does, said the way the rest of the page says it. A link that
# tells you something does not "own tell" anything: the two halves of its
# record are a target and an action, and read straight out they make nonsense
# of the one kind of link whose target is not a thing at all.
assert d.tap_words({'target': 'tell', 'do': 'house'}).startswith('tell you '), \
    'a telling link reads as nonsense: %r' % d.tap_words({'target': 'tell', 'do': 'house'})
assert 'own tell' not in d.tap_words({'target': 'tell', 'do': 'own'})
# and the device by the name Duo shows, not by the twenty letters of its id
d.store.set_meta('duo_devices', __import__('json').dumps(
    [{'device': 'DPQDHZC82JJ1TL6F00EB', 'name': 'iPhone16', 'capabilities': ['push']}]))
assert d.duo_device_name('DPQDHZC82JJ1TL6F00EB') == 'iPhone16', 'the device is shown by its id'
assert d.duo_device_name('auto') == '' and d.duo_device_name('DPNOSUCH') == 'DPNOSUCH'
print('a waiting press says what it would do and which device was rung, in words')

# The finished ones can be thrown away like any other recorded thing; what is
# still waiting is left alone, having not become anything yet.
d.duo_push = lambda what, who='': (time.sleep(5) or (True, 'approved'))
d.tap(token, '1.2.3.4', way='header')
_before = len(d.approvals()['waiting'])
assert d.approvals_forget() >= 0
assert len(d.approvals()['waiting']) == _before, 'erasing the history took a waiting press with it'
assert not d.approvals()['recent'], 'the history was not erased'
d.approval_stop(None)
print('the record of the finished ones can be erased, and the waiting ones are left')

# Every press is written down, not only the ones that wait for somebody: the
# list is worth looking at only if what is not in it did not happen. And it is
# in the database, so a restart does not lose it.
d.store.forget_tap_log()
zigmon.CONFIG['tap_mode'] = 'both'
zigmon.CONFIG['tap_code'] = 0
d.tap(token, '192.168.40.170', way='link')
d.tap(token, '192.168.40.170', way='header')
d.tap(token, '192.168.40.170', way='link', ask=True)
d.tap('not-a-real-token', '89.24.5.7', way='header')
d.store.flush()
_rows = d.approvals()['recent']
assert len(_rows) == 4, 'four presses were written down as %d' % len(_rows)
_roads = {r['way'] for r in _rows}
assert _roads == {'by its address', 'by a header'}, 'the road is not said: %r' % _roads
assert any(r['state'] == 'refused' for r in _rows), 'a refused press is not in the list'
assert any(r['state'] == 'asked' for r in _rows), 'a press that only asked is not in the list'
assert all('none' in r['factor'] for r in _rows), 'it claims something checked these: %r' % _rows[0]
# the same through a code, and through Duo
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'totp'
d.tap(token, '10.0.0.2', way='header', code='000000')
zigmon.CONFIG['tap_factor'] = 'duo'
d.duo_push = lambda what, who='': (time.sleep(0.3) or (True, 'approved'))
d.tap(token, '10.0.0.2', way='header')
time.sleep(0.9)
d.store.flush()
_by = {r['factor'] for r in d.approvals()['recent']}
assert 'a code' in _by and 'Duo' in _by, 'what checked a press is not said: %r' % _by
assert len([r for r in d.approvals()['recent'] if r['state'] == 'done' and r['factor'] == 'Duo']) == 1, \
    'one press approved through Duo was written down twice'
# and it survives a restart, because it is in the database and not in memory
_kept = len(d.store.tap_log(500))
d._waiting.clear()
assert len(d.approvals()['recent']) == _kept, 'the list lives in memory and would not survive a restart'
assert d.approvals_forget() == _kept and not d.approvals()['recent'], 'it could not be erased'
print('every press is written down with its road and what checked it, and it keeps')

# -- what the web server does with the address --------------------------------
# The address is the same for every link and carries no secret, so opening it
# in a browser - the first thing anybody does to see whether it is there - must
# be answered rather than refused. A bare 403 from nginx says nothing about
# why, and that is what it said at first.
conf = (Path(__file__).resolve().parent.parent / 'deploy' / 'nginx-zigmon.conf').read_text()
block = conf[conf.index('location = /tap {'):]
block = block[:block.index('\n    }')]
assert '$request_method != POST' in block, 'the header address is not held to POST'
assert 'return 405' in block and 'X-Zigmon-Tap' in block, \
    'a browser opening the header address is refused without being told why'
assert 'deny all' not in block, 'a bare refusal is back'
print('the header address answers a browser instead of refusing it')

print('\nboth roads, the code, the switch and the web server behave')
