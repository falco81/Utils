# zigmon

Monitoring, history and control for every sensor that reaches an MQTT broker
through Zigbee2MQTT — and, optionally, for Shelly WiFi devices publishing to
the same broker. The same shape as `upsmon`: a Python daemon that owns the
data, SQLite for history, and a PHP dashboard behind nginx that only relays
JSON.

* `install.sh` — sets the whole thing up on AlmaLinux 9, and can upgrade or remove it
* `zigmon.py` — the daemon and the command-line tool, one file (standard library + paho-mqtt)
* `web/index.php`, `web/zigmon-api.php` — the dashboard and its thin API client
* `deploy/` — systemd unit, logrotate rules, sample configuration, nginx server block
* `INSTALL.md` — the AlmaLinux 9 walkthrough, by hand

## Installing

```bash
sudo ./install.sh
```

Packages, service user, configuration, the broker account, systemd unit, log
rotation, nginx with TLS, php-fpm, SELinux, firewall, and a check that it all
works. `--dry-run` shows what it would do, `--upgrade` replaces the program
files, `--uninstall` removes it while keeping the recorded history. Every
question has a command-line option; `--help` lists them.

## How the pieces fit

```
Zigbee sensors ──► SLZB-06 ──► Zigbee2MQTT ──┐
                                             │      AlmaLinux 9
Shelly WiFi (H&T, Plug) ─────────────────────┤   ┌────────────────────────────────────────┐
                                             ▼   │ zigmon.service   (user "zigmon")       │
                                        mosquitto│   subscribes to zigbee2mqtt/#, shellies/#│
                                       1883/8883 │   writes /var/lib/zigmon/history.db    │
                                             ────►   serves 127.0.0.1:9849, token-guarded │
                                                 │        ↑                               │
                                                 │ php-fpm ← nginx :443 ← browser         │
                                                 └────────────────────────────────────────┘
```

The daemon is the only thing that talks to the broker. PHP relays JSON and
holds no credentials; the two endpoints that change something (opening the
network for joining, erasing history) send a token read from a file the
browser never sees, and are guarded by a PIN on top. Nothing in the chain
needs root.

## What it watches

**Every device Zigbee2MQTT knows.** The bridge's device list gives the model,
vendor, description and — through the "exposes" definition — the label and
unit of every value the device reports. Nothing is specific to a model: a
temperature sensor, a button, a contact, a plug with power metering all land
in the same tables and on the same dashboard. New devices appear by
themselves the moment they pair.

**Shelly smart plugs**, optionally, over local RPC exactly as upsmon does it:
the watts actually being drawn, voltage, current, power factor, frequency,
the plug's own temperature, the energy total and the runtime and switching
counters. Any number of plugs; each can be switched and its counters reset
from the dashboard, and **a Zigbee button can be bound to it** — single press
toggles the fridge, long press switches it off, whatever you set up on the
Control tab. The editor offers only devices that can send an action, and for
each one the exact actions its Zigbee2MQTT definition declares (plus any it
has actually sent), so nothing has to be typed or guessed.

**Shelly WiFi sensors**, three ways, all optional: over MQTT (anything under
`shellies/<name>/status/…`), polled over RPC when the sensor has an address
and answers (an H&T on USB power), or **pushed by webhook** from a battery
sensor that sleeps and cannot be polled — the daemon can listen for those
on a port of its own, exactly as upsmon did.

**The bridge itself**: online/offline, version, channel, whether the network
is open for joining, and the events it publishes (join, leave, interview,
rename).

## Why it is built this way

**Readings are rows, not columns.** `(device, key, value)` rather than a fixed
schema, because what one sensor reports is not what the next one does, and a
device added next month should need no code change.

**History is keyed by address, not by name.** Renaming a device in
Zigbee2MQTT keeps its history; the rename shows up as an event. A device that
reports before the bridge has listed it is filed under its name and moved
across when the address arrives.

**SQLite in two layers.** Full-resolution samples for a fortnight, hourly
averages with min and max for two years. A year of history for a dozen
sensors is a few megabytes, and a year-long chart costs a few hundred rows.

**A bursty device does not flood the table.** Readings arriving within
`sample_interval` of the previous one replace it rather than adding a row —
some devices send four messages for one measurement.

**Availability is inferred as well as reported.** Zigbee2MQTT publishes
`availability` when that feature is on; when it is not, a device that has
been silent longer than a battery sensor's reporting interval is flagged
anyway. A device that reports is by definition reachable, whatever the last
availability message said.

**Button presses are events, not readings.** `action` values go to the event
log with a timestamp; there is nothing to chart in a press.

**Button bindings run in the daemon, not the browser.** A press arrives over
MQTT, the daemon looks the binding up and talks to the plug over RPC; nothing
depends on a dashboard being open. Each switch is an event with the button
and the action that caused it.

**A plug reset is verified, not assumed.** The plug answers
`Switch.ResetCounters` with success whether or not it understood the counter
name, so the values are read back and compared.

**Requests to a plug are paced.** Gen3 firmware with authentication answers
429 when requests arrive closer together than about a second, and the digest
challenge is reused rather than renegotiated on every call.

**A missed reading does not blank the panel.** The last values stay on screen,
greyed out and dated, and after a restart they come from the recorded
snapshots until a fresh reading lands.

**The daemon never gives up.** paho reconnects to the broker by itself with
backoff; the systemd unit restarts the daemon without limit if it ever
crashes; a broker that is down for an hour simply means an hour without data.

**An error inside an endpoint answers rather than raises.** The dashboard
polls every five seconds; one bad payload from one device must not stop the
feed or bury the journal.

## The dashboard

Six tabs. **Overview**: counts, bridge state, permit-join state, a socket
panel per plug with a switch and its live figures, a card per sensor with its
main readings, battery, signal and last report — a button's card shows the
**last press, big**, with which button and how long ago, glowing green for a
moment when it lands (live, under a second), and its gestures as small
chips; a multi-button remote is folded to "4 buttons" plus each gesture
once instead of a 28-item list — and 6h/24h/7d charts of
temperature and humidity across all devices. **History**: pick a
device, pick 6 hours to a year, one chart per value it reports. **Devices**:
the table. **Events**: joins, leaves, renames, availability changes, button
presses, bridge state. **Control**: open or close the Zigbee network, switch each plug and reset
its counters, edit the button bindings, erase recorded data, forget a device
— all behind the PIN. **All values**: everything
every device reports, with the description Zigbee2MQTT gives for it.

**The overview can be rearranged.** While editing is unlocked, drag any
socket row or device card where you want it; the order is saved the moment
you drop it (`POST /api/order`), lives in the daemon, and every browser sees
the same layout. Newly added devices go to the end. While locked, dragging
is off.

Every Zigbee device also shows **which router or coordinator it talks
through** — "via Router" on its Overview card (hover for the link quality
and how fresh the information is) and a "Connected through" line on All
values. The daemon asks Zigbee2MQTT for the raw network map every
`networkmap_interval` seconds (default 300, `0` turns it off; the answer
also survives a restart), so after moving a device or adding a router give
it a few minutes to reflect re-parenting.

Charts read each series' own rhythm: a thermometer that wakes every four
hours draws an unbroken line, and lines are always continuous, start to finish, whatever a source's
rhythm. Shading real outages on top — where a normally chatty source went
quiet for a while — is an opt-in setting (`chart_outages` in
config.json, or Settings on the dashboard); off by default, it applies to
every chart at once.

**Three more tabs join Plugs: Sensors and Buttons.** Every non-plug device
that reports measurements lives on Sensors; every button/remote lives on
Buttons. Both are full catalogs, unlocked-editable and reorderable by drag,
independent of Overview.

**Overview is yours to design.** While unlocked, an "Add to Overview" row
lets you place any plug, sensor, or button onto Overview; a small × on each
card removes it, and dragging reorders freely — plugs and sensor/button
tiles can sit in any order together. A fresh install shows everything (the
same combined view as before), so nothing looks empty until you start
customizing; from the first add or remove, Overview remembers your own
layout in the daemon, shared across every browser. It has nothing to do
with the Plugs/Sensors/Buttons tabs, which always show the full catalog.

**Zigbee gateways** now cover two kinds of hardware: a SMLIGHT SLZB-06 or
similar (plain HTTP JSON on `/ha_info`/`/ha_sensors`) and a **Shelly device
with the Zigbee component acting as a router** — e.g. a Power Strip 4
Gen4 — read over the same local JSON-RPC API (`/rpc`, digest auth) already
used for Shelly plugs, via `Shelly.GetStatus`, `Zigbee.GetStatus` and
`Zigbee.GetConfig`. **Detect** tries the SLZB path first and falls back to
the Shelly one automatically, remembers which one answered (`kind` in
`config.json`), and — for a router — offers the matching device on the
mesh as the target if there is exactly one, or one whose model matches
what Detect read. `zigmon gateway <name> dump` and the background poller
follow the same two-protocol logic, so a Shelly-based gateway needs no
extra setup once Detect has run once.

**Zigbee gateways** (a SMLIGHT SLZB-06 or similar) can be read over the
network for their own health — uptime, board temperature, Wi-Fi/Ethernet
and socket state — on top of what Zigbee2MQTT reports. Add one on the
Control tab, in **Zigbee gateways** (name, address, and — if the device's
"web server authentication" is switched on — a username and password sent
as HTTP Basic Auth), or in `config.json` for a read-only entry:

```json
"zigbee_gateways": [
  {"name": "Router", "host": "192.168.1.51", "target": "Router",
   "username": "admin", "password": "..."}
]
```

`target` is either the name an existing Zigbee router already has (its
readings *extend* that device — nothing is duplicated) or the literal
string `"coordinator"` for the local coordinator, which has no device row
of its own and gets a small synthetic one. `username`/`password` are
optional and only needed when the gateway's own web login is enabled.
Polled every `gateway_poll_interval` seconds (default 30) from the
documented `/ha_info` and `/ha_sensors` endpoints, plus `/metrics` (the
device's own Prometheus output — free heap, board temperature, Wi-Fi RSSI
and whatever else the firmware exposes, parsed generically since the
format is self-describing). Whatever comes back lands under a `gw.` prefix
in All values and gets recorded to history too — free heap over time is
often the earliest sign of a coordinator that is about to lock up. **Detect** on the row does the
same from the dashboard: it reads model, firmware, radio and mode, fills
the name if empty and suggests the target (coordinator, or the one router
on the mesh). Run
`zigmon gateway <name> dump` (or `--host <ip> dump` for one not yet in
config.json) to see exactly what your firmware returns before relying on
any particular field.

**A multi-relay strip reads as one box.** Its header carries what is the
box's — model, firmware, address, mains voltage and frequency, box
temperature, total power, Wi-Fi — and each channel row underneath shows
only its own power, current, energy, on-time and switch count, with the
same full-size switch button a single plug has. **Find Shelly devices → Add**
runs Detect on the spot, so a found box arrives with the right kind,
its relays and their names.

**Plugs are added as devices, not as relays.** In Plugs and sensors one
block is one box: address, password and a *device state* entered once.
**Detect** asks the box what it is (model, MAC, firmware) and how many
relays it has, and lays out one channel row per relay with the names the
device itself uses — a Pro 4PM becomes four channels in one click. The
device state wins: *monitor only* or *disabled* there applies to every
channel and locks their selects; *enabled* lets each channel keep its own
choice (a single channel can still be monitor-only or disabled). Passwords,
addresses and the device state are stored once per channel underneath, so
bindings, rules, history and the strip ordering on the Plugs tab work
exactly as before (the whole strip is dragged; channels reorder inside it).
In `config.json` the same is `"host_state": "enabled|monitor|disabled|optional"`
on each channel entry.

**A device that may be unplugged.** The fourth device state, *enabled, may
be unplugged* (`"host_state": "optional"`), is for a box that loses power
as part of normal life — a lamp on a switched outlet, a plug behind a
socket that gets turned off. It behaves exactly like *enabled* while the
box answers. When it stops answering, nothing is treated as a fault: no
warning event, no notification, no place in *needs attention*, the device
stays *ok*; its socket row goes grey and says *unplugged* with the last
reading, and bindings, rules and schedules aimed at it fail fast and
quietly (a two-second probe instead of the full timeout, so no thread and
no other device waits on it). It keeps being probed on the normal poll
interval, so the moment it has power again it is live — readings, switch,
bindings — with an *answering again* line in the log and nothing else to
clean up.

**Silence quiet-alerts for buttons** (Settings → Alert thresholds, on by
default) — a button or remote only reports when pressed, so going quiet for
hours or days is normal for it, not a fault. With this on, buttons never
turn WARN/CRIT or count toward "needs attention" just for being silent;
switch it off to get the old behavior back. Plugs were already exempt.

**On/off is a switch, everywhere.** One iOS-style toggle is used for every
enable/disable in the dashboard: the boolean settings (outage shading,
chart icons, daily backup, Zigbee2MQTT in the backup), the notification
categories and per-device custom picks, and — new — an enabled switch at
the start of every binding, rule and schedule row: off keeps the row but
the daemon ignores it (dimmed in the list). Backup time is a time picker,
tokens are masked, numbers have sensible steps.

**The way to a device's charts** is always the same small chart icon in
the top-right corner of its card or row, shown on hover — never the name,
never the whole card (a plug's row has the switch on it). It is on by
default and can be switched off per kind under Settings → Charts or in
`config.json` (`link_plugs`, `link_sensors`, `link_buttons`).

**Click the status pill** (or the Needs-attention card) for the details
behind it: a dialog listing every problem in one place — broker or bridge
down, each device flagged by a threshold with the reason and its last
report, every unreachable plug with the error — worst first; a device name
opens its History. When all is well it says so, with a one-line summary.

**Forget this device works without visiting Devices first.** The list it
offers was filled while the Devices tab was painted, so once painting became
per-tab that list stayed empty for anyone who went straight to Control, and
the button did nothing at all. It is filled from Control as well now, and
says which of the two went wrong instead of failing quietly.

**A tick paints only the tab you are looking at**, and only the parts
whose data actually changed (each grid and editor keeps a signature of its
slice of state; "x min ago" texts repaint once a minute). A hidden tab is
painted the moment it is shown. With a few dozen devices a refresh costs a
few milliseconds instead of hundreds, so a click on a socket repaints in
~30 ms even on a big mesh.

**`zigmon --map` scans the mesh on demand.** The map is otherwise refreshed
every `networkmap_interval` seconds (five minutes by default, `0` turns it
off), which is fine to live with but slow to wait for after moving a device.
The command asks Zigbee2MQTT for a fresh scan, waits for the answer, and
prints who talks through whom — and if the bridge does not answer in time it
says so and shows what it last knew.

**One coordinator, not two.** The coordinator is not listed as a device of
its own — a gateway entry stands in for it — but anything Zigbee2MQTT
published under its friendly name used to be adopted as a separate, silent
record, so it appeared twice and the gateway's Target offered a choice
between two things that were the same. Its name now points at the one
record, an existing stray copy is folded away on the next device list, and
Target lists the coordinator once. It also carries what Detect read — model
and firmware under its name, like every other device — and the network map
calls it by that name rather than the bare word `coordinator`. Any device a
gateway extends does the same: a range extender reads
`SMLIGHT SLZB-06Mg26U · Router · v3.3.8.dev3` rather than just `Router`,
in its card and in the Devices table. The firmware is added to what
Zigbee2MQTT already says rather than replacing it, so the two never fight
over the row.

**Rules compare with `=` and `≠` too**, next to the four inequalities — for
a reading that is a state rather than a level. Equality is matched with the
tolerance floats need, so a sensor reporting 21.0 matches a 21 typed in.

**A gateway poll no longer hides a silent mesh.** When a device's record is
extended by a gateway read over the network, that poll also refreshed the
“last report” age — so a router whose Zigbee side had gone quiet still looked
seconds fresh. The two are now tracked apart, and when they drift more than
two minutes the card says `Zigbee 30 min ago` next to the age, so the mesh
cannot hide behind Wi-Fi. A router with nothing of its own to report is only
heard from when the bridge pings it, every ten minutes or so, so under a
quarter of an hour the note is plain grey; it turns orange past that.

**A WiFi tab, for looking at.** Between Devices and Events, tiles for the
controller, each access point and each wireless network, and a list of
everything joined — with the ones assigned to a person marked. An access
point tile carries its clients per radio and channel, processor, memory and
uptime, and each one is recorded as a device of its own, so its history
charts like any sensor and it can be dragged onto the Overview.

The device list is a summary: it names the features and the interfaces
(“ports”, “radios”) without giving either, so each access point is read a
second time for the radios that carry its channel, width and Wi-Fi
generation, and for its ports — which are reported even where the controller gives a
socket's rating but not its live speed, or names a port without saying
whether it is up. If the tab is emptier than the controller's own pages, `zigmon --wifi-probe`
shows the outline of its replies — the field names, with the
values shortened and anything that looks like a key left out. Those names
have moved between firmware revisions, and guessing at them from the outside
is exactly how an empty tab happens: a controller answering
`features: ["accessPoint"]` was being compared against `ACCESS_POINT` and
every device it listed was quietly dropped. Spellings are now compared
without case or punctuation, the SSID is taken from whichever key carries
it, and a controller whose devices are not recognised at all says so on the
tab rather than showing nothing.

**The access points can be asked directly.** The controller's key interface
will not say which network a client is on, nor its signal or channel; the
points themselves know all three. Under **Control → Presence**, switch on
*Read them over SSH*, give the username they use, and either a password or a
key — which can be **generated here**, its public half shown for pasting
into the controller under Settings → System → Device SSH Authentication and
its private half downloadable once, or uploaded if you already have one.
Their addresses come from the controller, so nothing has to be typed twice.
Switching this on also **stops the controller being signed in to**: the
sign-in existed to get exactly these three things, and a controller that
locks an account out after a few failures is not worth troubling for
something already in hand. A setup carried over from before is moved to the
API key on its own and says so in Events. `zigmon --wifi-probe` reports on
the points now rather than on a sign-in nothing is using.

Each point also measures its own way out — latency, jitter and packet loss
to the gateway and to whatever carries it — which is how an access point
that is fine in itself but sits behind a bad wire tells you so; the
controller cannot see that at all. It says which switch and port it is
plugged into, where it sends its reports and what went wrong the last time
it could not, and how it is bearing up: how much of the flash's write life
is gone, why it last started, whether it has ever crashed, its board
revision and its addresses.

Some of it is turned into something to act on rather than only read. The
spectrum scan says how busy every channel in each band is, so a radio
sitting on a crowded one is shown the **quieter channels going spare** — on
a 2.4 GHz radio at 35% airtime, knowing channel 7 is at 18% is the whole
decision. A 5 GHz radio on a **radar channel** is marked DFS, because a
point told to leave one takes its network with it and that looks like a
fault. And a client's **retry rate** — how much of what it sends has to go
out again — catches one struggling long before its signal looks bad: an
iPad at –64 dBm repeating 18% of its frames is having a worse time than a
plug at –65 dBm repeating 2%.

What each point sees of the neighbourhood comes back too: every other
network on the air with its channel, width, signal and security, merged
across the points so one network seen twice is one line with the nearest
sighting, and listed on the tab with the ones sharing a channel with your
own marked — those are the ones dividing the airtime with you. Your own
networks are left out, including the hidden ones a point broadcasts, which
are recognised by the hardware their address comes from rather than by a
name they do not have. and the airtime in use and interference on each channel a radio
sits on. `info` is a shell function rather than a program on this firmware,
so several ways of asking are tried until one answers.

Nothing is ever written to a point. The commands are a fixed list in the
source — `info` and `mca-dump`, neither of which changes anything — and
none of it is built from anything typed or received; asking for anything
else is refused before a connection is made. What comes back fills in each client's network, signal, noise and margin,
channel, width, Wi-Fi generation, stream count, VLAN, negotiated rates,
retries, experience and whether it is dozing; each point's temperature per
radio, load, experience, serial, kernel and the speed and error counts of
its wired uplink; and the real number of clients on each network, which the
key interface cannot count at all. The field names follow a dump from a
U7-Pro rather than what looks likely — the channel and its width sit on each
wireless network, not on the radio; `signal` is dBm while `rssi` is the
margin above the noise floor; rates are counted in kilobits. A point that does not answer is noted on its own tile and the others carry
on. What they said is held between rounds: the controller is asked every
thirty seconds and the points every few minutes, and without that the signal
and the network would appear once and then vanish for the next several
rounds — which looked exactly like the reading being unreliable.

**A device is called what you called it.** The controller carries the name
somebody typed; the point reports the hostname the device announces for
itself. The first wins, and the second is shown beside it where the two
differ, so `iPhone16` stays `iPhone16` rather than turning into
`Jan--iPhone16` every few minutes.

How much is on show depends on which interface the controller is asked
over, and the tab says which one actually answered. Signing in is not free — the controller counts attempts and starts
answering `429 too many requests` — so a session is opened once and kept for
half an hour rather than signing in for every read, and never logged out,
since logging out is what forces the next read to sign in again. Twenty-two
reads now cost one sign-in instead of twenty-two. A sign-in that succeeds is not yet a session: UniFi OS wants a cross-site
token on every read, and that token rotates — a fresh one comes back under
`x-updated-csrf-token` rather than the name it was first sent under, so both
are watched for, and `/api/users/self` supplies it on the controllers that
withhold it from the sign-in altogether. The session is then **extended**
through `/api/auth/refresh`, the way the controller's own pages do, rather
than signed in again when it ages: twelve reads and four renewals cost one
sign-in. `rememberMe` is sent too, for the longer session it buys. Without it the sign-in
reports 200 and every read that follows reports 401, which looks like a
password problem and is not one. There are also two doors — UniFi OS answers
on `/api/auth/login`, the classic controller on `/api/login` — and a self-hosted server may refuse one
while letting the other through, so both are tried. A **rejected** username and password is a different matter from a busy
controller: it is tried once and then left alone until the stored details
change, because repeating a wrong password is exactly what locks an account
out of its own controller — and a controller answering
`AUTHENTICATION_FAILED_LIMIT_REACHED` is counting failed sign-ins, not
traffic, so that is read as a rejection too. Where the controller really is
asking for a pause it says for how long; that wait is honoured and doubles
with each refusal in a row, rather than being retried the moment it lapses
and renewing the lockout forever, and the key covers the gap. Reads are serialised and their answers held for a few seconds, so several
people looking at once, or somebody leaning on the refresh button, cost the
controller one round rather than one each: sixteen simultaneous polls make
one read of the clients, one of the devices and one sign-in. `zigmon
--wifi-probe` prints what the controller answers to each question, sign-in
included, for when the tab is thinner than it should be, and `zigmon --reset-order wifi` puts the cards back in their default
arrangement. The same command covers every set of cards that can be
rearranged — `overview`, `wifi`, `plugs`, `sensors`, `buttons`, `devices`,
`groups`, or `all` — and only forgets the order: nothing about the cards
themselves changes. **Access** offers three
choices: the API key, a username and password, or **both** — which signs in
for the fuller picture and keeps the key as the fallback, so a controller
that stops accepting the sign-in still fills the tab rather than emptying
it. The **API key** interface grew a great deal in 10.6: it lists the access
points with each radio's channel, width and Wi-Fi generation, the wireless
networks with their security and the VLAN behind each, and per client the
name, address, kind (wireless, wired, VPN or Teleport), whether it is a
guest, since when, and which access point carries it. What it does not report, on any version, is **which network a client is
joined to** — the access field on a client holds an authorisation type and
nothing else — nor its signal or channel. Where that is unknown it is left
blank rather than counted as nothing: a network nobody can be counted on
says so instead of claiming zero clients. Signing in with a **username and password** reaches what the controller's
own pages use: its `clients/active`, which already carries the signal, the
channel, the negotiated rates, the VLAN and the name of the access point —
with the older `stat/sta` as the fallback for controllers without it. That
shows: per client the
Wi-Fi generation and stream count, band, channel and channel width, signal,
throughput and total usage, experience and VLAN; per access point each radio
with its channel, width and airtime in use, its uplink and its experience;
and the real list of networks with their security, bands and the VLAN each
sits on — 6 GHz radios included, which the band mapping had been getting
wrong.

All of it is deliberately slow and second in line: the network is asked
about every three minutes on its own thread, readings are kept only when
they move, and nothing in the house waits on any of it. With a controller
that accepts a connection and then never answers, message handling stays at
0.10 ms and every reading still arrives.

**Presence: who is at home, and rules that care.** Whether a phone is on the
house Wi-Fi answers *is anyone in* well enough, and needs nothing installed
on the phone. **Control → Presence** takes a UniFi controller — an API key,
or a username and password on older firmware — lists the clients it can see,
and lets each one be assigned to a person. Someone is in when any of their
devices is on the network, so a watch or a laptop covers for a sleeping
phone.

Arriving is believed at once; leaving only after a grace period, ten minutes
by default. A phone parks its radio while its owner is asleep in the next
room, and without that delay the house would report them walking out every
night.

**A phone can be named instead of addressed.** Phones rotate their Wi-Fi
address now — iOS *Private Wi-Fi Address*, Android *randomised MAC* — and a
person listed by an address that has since changed is out for good, however
often the controller sees the phone under its new one. **+ by name** in
the People editor stores `name:iPhone16` instead: the device matches by
the name the controller shows, whatever its address is today. An **out**
tag says under it why the person counts as out — not among the clients
listed, last seen when, the grace that applies — so a wrong address or a
too-short *Gone after* is visible at a glance.

**A phone can say where it is itself.** The Wi-Fi has a floor: the
controller lists a phone a few seconds after it has joined, and only once it
has joined - by which time you are already inside. A handset's own geofence
trips while its owner is down the street. Switch **From their phone** on for
a person, press **Setup**, and you get two links to put in the handset:

    …/index.php?api=presence-report&state=home&token=…
    …/index.php?api=presence-report&state=away&token=…

**Setup** is the whole walkthrough, not just the links: the Location
Services setting the phone needs, each screen of the automation in order,
what to type where, how to test it, and what happens when. Every value that
belongs in the phone — the URL, the topic, the message with the token in it
— is a chip you tap to copy, and hovering one shows it as a **QR code** for
the phone to scan. That is as far as automation goes, and the limit is
Apple's: a personal automation cannot be shared or imported at all, and
since iOS 15 an unsigned shortcut file cannot be added to a phone either —
so the automation itself is always made by hand. The QR at least keeps a
24-character token from being typed twice. If a presence topic is set, the ntfy way is
what it walks through and the direct link is offered underneath; if not,
the other way round. Android is the same request from Tasker or MacroDroid. It travels over mobile data to the same address the dashboard
lives at, so a phone reports from the street, before it is on the Wi-Fi at
all.

The two sources are merged rather than swapped. **Arriving is taken at
once** - triggers fire, and the Wi-Fi confirms it moments later. **Leaving
is taken only if the controller cannot see them either**: a geofence that
wanders is common, and a phone sitting on the home network is not a phone
that has left, so a reported departure asks the controller once, quickly,
before it counts. A phone's word stands for half an hour unconfirmed, then
the Wi-Fi has the say again - a lost or flat handset cannot strand anybody.
Every *out* tag says which source decided it.

The token is what proves a request is that person's phone; it is per person,
never shown in the dashboard's own status, and *Make a new token* stops an
old link working. Losing one is worth what it can do: flip that person's
presence, and nothing else. Wrong tokens are counted and slowed to a crawl.

**Nothing has to be reachable from the internet for this.** Set a
**presence topic** on the Wi-Fi controller card - `https://ntfy.sh/` plus a
long random name - and the phone publishes `home <token>` there instead,
while the daemon holds an outbound stream to it. The topic is public, which
is why the token travels inside the message and why nothing but a name and a
state ever goes over it.

**Walking in is noticed before the hall sensor gets a word in.** The
controller is asked every *poll_s* (30 s by default, 3 s at the least) - and
for a minute after anybody has come or gone, every five seconds, since a
second person often walks in right behind the first. But
a rule limited to *nobody home* does not trust an answer that old: when it
is about to fire and the last look at the network is more than
`presence_fresh_s` old (4 s by default; `-1` switches this off), it asks
the controller again first, with a three-second timeout, and decides on
what it hears. Your phone joins the Wi-Fi at the door, the sensor trips two
seconds later, the rule asks, finds you in, and stays quiet. Only that rule
waits for the answer: rules run on a thread of their own and buttons,
reports and plugs never queue behind them.

What it is for:

- **Sensor rules take an `only when`**: nobody home, someone home, or one
  named person in or out. `motion` and `motion while the house is empty` are
  different things, and now they can be written differently.
- **Anything that switches something can send a notification instead** — a
  rule, a button, a scene, a schedule, a presence trigger.
- **Coming and going switches things**: per person, or once for the house
  when the first one gets in or the last one leaves. That last one is for
  turning everything off behind you.
- The Overview carries a chip per person, green when they are in, with the
  device they were seen as and when. `zigmon --presence` says the same on a
  terminal.

A gated rule stays quiet when nobody has been set up or the controller is
unreachable, rather than guessing. The key or password is stored in the
daemon's database and never sent back to the page — only whether one is
held. Presence settings travel in the settings backup with everything else.

**A button can take something over.** A light on a motion rule is a nuisance
the moment somebody wants it to stay on: they press the switch, and the
sensor turns it off again as they walk past. Switch **By hand** on for that
button's binding and while its press leaves the target on, rules, schedules
and window-closing leave it alone; the same button switching it off gives it
back. A pulse never takes anything over, and a hold expires by itself after
`manual_hold_s` (four hours by default, `0` for never) so a forgotten one
cannot strand a plug. The plug card shows `by hand` while it lasts, saying
who took it and how long is left, and clicking that gives it back at once.
When the binding's target is a scene or a sequence, the hold lands on every
light the scene switches, one by one and by what the scene did to each: the
ones it turned on are taken over, the ones it turned off are given back, a
toggle is read back to see where it landed. A scene of three lights pressed
by hand is then three holds, and the motion sensor over any of them keeps
its hands off until the same button (or the card) gives them back.

**A critical alert is logged in its own words.** That is the one somebody
comes back to and reads, so Events keeps the message as it was written, in
whatever language it was written in; what set it off is on the rule's own
line directly beneath, so nothing is lost. The quieter ones stay as the
daemon describing itself — `sent "Doorbell": a doorbell press` — rather than
repeating their words in the middle of its own English.

**One message, one alert, however many rules point at it.** The repeat
window silenced a duplicate notification but not the event or the band
behind it, so two rules watching the same sensor — an OR rule and the single
rule it replaced, say — raised the same alert twice while only telling you
once. The window now governs all three together. The rules editor also marks a rule when another one fires on exactly the
same crossing and does exactly the same thing to the same target. Only that:
a pair switching on above and off below is the pattern this very card
recommends, and a thermostat's dead band is two rules on one sensor by
design.

**Each side of an OR is its own event.** A rule fires when its condition
becomes true, and a pair joined by OR was treated as one condition: with two
motion sensors covering a hallway, whichever tripped second was never heard
while the first was still occupied — the combined condition had not stopped
being true, so there was no edge to fire on. Two separate rules worked,
which is the tell. Each side now carries its own edge, so both are
announced; AND keeps the combined edge, which is what it means. The event
and the message also name the reading that actually tripped rather than the
other sensor's, and a rule whose first source has never reported no longer
sits silent when its second one does.

**Nothing on the message path waits for the database.** A critical message
and a hand taking something over both record themselves in the settings
table, and that write stood behind the lock: during a VACUUM of a 135 MB
database one motion report took 770 ms to become an alert. Those writes now
join the same queue as events — the in-memory copy is updated at once, every
reader sees it, and the row lands when the lock is free. The same report
during the same VACUUM: 0.7 ms. The band of standing alerts is also
repainted only when the alerts change, not on every tick.

**A notification is not switched on.** Picking a message as the target now
hides the Do column, the pulse delay and the way-back threshold, and says
`sends the message` instead — in rules, button bindings, scenes, schedules
and presence triggers alike. They were offered before and meant nothing.

**Presence is worked out once a second, not once a rule.** A gated rule asks
who is home on every message it might match, and each ask rebuilt the whole
answer; with thirty such rules that halved what the message path could
carry. The answer can only change when the controller is asked again, so it
is held briefly: 11,400 messages a second back to 22,000.

**A request with no PIN is not a wrong PIN.** Anything privileged that
arrived without one was counted as a failed guess, so five stray requests —
a stale tab, a bug in the page — locked the owner out for five minutes with
“too many wrong PINs” while they were typing the right one. Only an actual
guess counts now; guessing is still limited exactly as before.

**Notifications say what you wrote.** *Messages*, under Alerts & energy, are
named texts picked as a target anywhere something is switched. Write
`{device}`, `{value}`, `{key}`, `{unit}`, `{label}`, `{target}`, `{action}`,
`{person}`, `{time}`, `{date}`, `{home}`, `{away}` or `{origin}` and the
facts of the moment are filled in — anything not known then is left out
rather than printed as a placeholder. The device that set it off also
offers `{model}`, `{battery}`, `{signal}`, `{temperature}`, `{humidity}`;
the moment offers `{weekday}`, `{sunrise}`, `{sunset}`, `{daylight}`
(day/night; the sun needs `latitude`/`longitude`), `{home_count}`; the
house offers `{attention}` (devices needing attention), `{attention_list}`,
`{alerts}` (standing critical alerts) and `{uptime}`.

**Any device, right now: `{Name.key}`.** Write the device's name as the
dashboard shows it (or its alias), a dot, and a key from *All values* —
`{Temp-Venek.temperature}`, `{Plug-UPS.switch.apower}`,
`{PIR-Vchod.occupancy}` — and the current reading is put in, whatever set
the message off. `{Name.state}` is on/off/unplugged of a plug or switch,
`{Name.age}` how long since it last reported, and `.battery`, `.signal`,
`.model`, `.name` work too. Names are matched case-insensitively; a device
or key that does not exist simply vanishes from the text. So a night-time
motion alert can read *Motion at {device}, outside {Temp-Venek.temperature}
°C, entrance light {Light-Vchod.state}*.

**The editor completes them like an IDE.** Type `{` in a message's text or
title (or press Ctrl+Space anywhere) and a list drops down at the cursor:
every fact with what it means and an example value taken from the live
dashboard, and every device by name. Keep typing to narrow it; Up/Down
move, Enter or Tab take, Esc closes. Taking a device puts `{Name.` in and
the list changes to that device's own readings with their current values —
`humidity → 71 %` — plus `state`, `age`, `battery`, `signal`, `model`,
`name`. The `{ } Facts` button shows the same catalogue grouped, with the
examples. Each says how long before the same message may be sent again, because a
tripping sensor will otherwise fill a phone, and whether it is **critical**:
sent at the highest priority the channel allows, written to Events as a
problem, and left standing in a band across the top of the page until
somebody clears it — which needs the PIN, and leaves it in Events either
way. A notification arrives while you are asleep; the band is still there in
the morning. The text runs to as many lines as it needs, and two buttons put things into
it where the cursor is: **Facts** for the placeholders, so nobody has to
remember them, and **Emoji** for a symbol, which both channels carry. A
message can also carry its own heading and a picture — a camera snapshot,
say; the phone fetches that itself, so the address has to be reachable from
wherever the phone is. The card shows what each will read like as it is
typed, and sends one on demand. Without a message, the notification carries the automatic
description, which is fine for testing and poor at three in the morning.

**The coordinator's card reads like a router's.** It was the one device
whose card said “no measurements” while its gateway was being polled
perfectly well — it has no link quality and no parent, so it fell through to
the branch for a sensor with nothing to show. It now says it is holding the
network and carries the same board temperature, Wi-Fi and uptime a router
does, or, when no gateway is set up for it, says where to set one up.

**A router card shows what the box itself reports.** A range extender used
to show only that it routes, its link quality and how long it has been in
the network — anything read over its own network API sat in All values and
nowhere else. When a gateway is set up for it, the card now carries the few
figures worth a glance: the sockets of a strip added up, board temperature,
Wi-Fi, uptime. Keys differ per vendor, so they are matched by shape rather
than named one by one.

**A router shows its route too.** Only end devices have a parent; two
routers are siblings, so a mains-powered router used to show no route at
all - the one thing worth knowing about it. The network map's sibling links
are now read as well, and a router carries its strongest neighbour with the
wording to match: `next to coordinator` rather than `via`. The mesh tree
lists them under it.

**A Zigbee switch is told the state, not asked to flip.** Toggling now
sends the explicit `ON` or `OFF` the last report says is the opposite,
exactly as the Zigbee2MQTT frontend does; `TOGGLE` is only used when the
channel has never reported. Some converters - the Shelly Power Strip 4
Gen4's among them - ignore `TOGGLE`, which made a binding look dead. And because a publish the broker refuses looks like success from here, a
set that is never confirmed within six seconds now says which half failed:
the daemon subscribes to the whole base topic, so a command the broker
accepted comes straight back to it. Echo but no action means Zigbee2MQTT
ignored it; no echo means the daemon's MQTT user may not publish there.
`zigmon --check` tests the same thing directly, without waiting for a
button press. On a broker with an ACL the daemon's user needs more than
read access — reading the whole base topic is not enough to *switch*
anything:

```
user zigmon
topic read  zigbee2mqtt/#
topic write zigbee2mqtt/bridge/request/#     # pairing, network map
topic write zigbee2mqtt/+/set                # switching a Zigbee device
topic write zigbee2mqtt/+/+/set              # ...one of its endpoints
```

The probe publishes to `zigbee2mqtt/zigmon-selftest/set` — the same shape a
real command uses, so it tests the permission that actually matters.
Zigbee2MQTT notes once that it does not know a device by that name, which
is expected and harmless — and that one complaint is kept out of the event
log, since it is ours rather than a fault.

**Detect names the relays the way the device does.** It reads the device's
own name and each output's name over the local API and combines them —
`PlugX4-TVLoznice-AppleTV` — with the MQTT prefix preset to the same thing
in lower case, `plugx4-tvloznice-appletv`. A single-relay plug is just the
device name. An output the device leaves unnamed falls back to its number,
and a device that reports no names at all never overwrites a name someone
chose. Anything it renames is listed in the result line, so nothing changes
quietly.

**Control is split into four sections** - Devices, Automation, Alerts &
energy, System - reached from a row of pills under the Editing card, so the
tab shows the handful of cards you came for instead of seventeen at once.
The choice lives in the address (`#control/automation`), so a bookmark or a
reload comes back where you were. Every card still exists and behaves
exactly as before; a section only decides which are on screen.

**A multi-relay box is read in one request.** Asking each channel
separately meant a four-way strip answered thirteen requests per round and,
with the pacing between them, spent most of every fifteen seconds busy with
its own polling - so a click on one of its sockets had to queue behind that.
One `Shelly.GetStatus` now covers every channel: thirteen requests become
one, and the box is busy 7% of the time instead of 80%.

**Commands jump the queue at the device.** Only one request is in flight
per box (that is all the hardware serves anyway), and a switch command goes
ahead of any poll still waiting - while the pacing delay itself is taken
outside that gate, so a waiting poll never holds the box shut.

**The card shows the new state at once.** A plug on Wi-Fi can take a moment
to answer; the socket flips immediately and dims until confirmed, and the
next refresh carries the truth, so a refused switch corrects itself.

**The energy summary is not recomputed from scratch.** Six spans per plug
over the whole samples table is most of what that card costs; yesterday,
last month and last year are periods that have ended and can never change,
so they are worked out once and kept, and the whole answer is held for
fifteen seconds so several open tabs cost one pass rather than one each.
Restarting a plug's counters throws the kept figures away.

**A gateway no longer fills the database with things that never change.**
Asked for its status, a box hands over everything it knows — its serial
numbers, memory sizes, counter reset stamps, per-minute arrays — and all of
it was written every thirty seconds. On one real installation that was 63%
of a 135 MB file, and 45% of every row stored was a value that had never
once changed. Bookkeeping keys are no longer recorded at all, and a gateway
reading is written when it moves, with a point every fifteen minutes so a
flat line still has one. Six polls of an idle strip now write eighteen rows
where they used to write eight hundred.

**A deleted device stays deleted.** A message under a name Zigbee2MQTT has
never listed used to create a device — which is right while the bridge has
not answered yet, and wrong afterwards: a broker replaying a retained
message for a device that was removed put the ghost straight back, every
restart, however often it was erased. Once the device list has arrived, a
name that is not on it is refused, and the log says once an hour which
topic it was. **Look for leftovers** lists those topics too, and offers to
clear them: the daemon writes the empty retained message that deletes each
one and reports which the broker actually took. Doing that needs its MQTT
user to be allowed to write there — `topic write zigbee2mqtt/#` — and when
the broker refuses, the message says so and names the topic, to clear by
hand with `mosquitto_pub -r -n`. A device usually has more than one retained
topic, `…/availability` besides its state, and each is listed separately:
clearing only one leaves the other putting the device back.

**Look for leftovers** on the Recorded data card finds what is still held
for devices the dashboard no longer shows — a rename or a removal leaves the
old name's recordings behind, and on one real installation that was 779,000
readings, 69% of the file. The scan counts them, lists the devices it found
in the Forget dropdown marked `⚠ … gone`, so a single one can be picked out,
and offers to erase the lot. Nothing belonging to a device still in use is
touched. Erasing history, events, everything or one device runs behind that panel
too, and each says in the daemon's log what it is starting and what it
finished with. The card is full width now that it holds all of this.

The size shown is also honest: SQLite reuses its write-ahead journal in
place, so after a compaction that file can sit at the size of the whole
database and was being counted into the total — a 135 MB database read as
270 MB. The journal is folded back in after every compaction and once an
hour besides, and the two are shown apart when one is there.

**Clear out noise** on the Database card applies the same judgement to what
is already stored: it counts first and removes only when asked again. On
that installation it took the file from 135 MB to 60 MB, and every
measurement that ever moved is still there.

**A database job says what it is doing while it does it.** Check, Optimise
and Back up can take a while on a large file, and a button that goes quiet
for half a minute reads as a broken one. Each now opens a panel with a
running bar, the seconds counting up, and the daemon's own log as it
arrives — the job announces its start and its finish there, with the file
size before and after. The panel stays afterwards with the result and how
long it took, green or red. The log is read from its end, not from its
start: it is asked for every second while a job runs, and a log that has
grown for months would otherwise be read whole each time.

**Nothing in the command line is cut to fit.** The listings used fixed
column widths, so a name or an id wider than the guess lost its end — an id
you cannot copy is not an id. Every table now measures its own contents and
sizes each column to the widest thing in it, numbers line up on the right,
and colour marks the level, the state and what a rule or binding does.

**Maintenance leaves the dashboard alone.** Checking, optimising, backing
up or erasing all hold SQLite for as long as they take, and anything that
had to fetch one more row in the meantime waited with them — the page went
to “Connecting…” for a second or two. Three things caused it: resolving a
name still went to the database, the header's row counts were counted
afresh on every refresh, and the caches were emptied a moment before a
VACUUM so the next read landed behind it. Names now resolve from the list
already in memory, the counts are kept for half a minute and never block —
the last ones are shown while the file is busy — and an erase refills what
the dashboard needs before it starts compacting, dropping only the device
it actually removed.

**Reading never makes anyone wait either.** The rows the hot paths need —
a device and its name, the actions a button has sent, a plug's counter
stamp, the whole device list the dashboard rebuilds from — are held in
memory and kept current as they change, instead of being fetched from the
database on every switch and every refresh. A poll that finds nothing new
about its plug no longer rewrites the row either. So a switch command and a
dashboard refresh cost the same whether the database is idle or busy: a
Zigbee command went from 915 ms to 0.2 ms during a VACUUM, and a status
build from 870 ms to 2 ms.

**Recording never makes anyone wait.** Everything the daemon writes while
handling a message — samples, snapshots, events, last-seen — goes onto a
queue drained by one background thread, and the config lists that decide
what to fire (bindings, rules, scenes, sequences, schedules) are held in
memory. So the automation path touches no database lock at all: a VACUUM
or an online backup, which hold SQLite for as long as they take, can no
longer stall a button press or back up the MQTT client thread. Maintenance
flushes the queue first, so a backup still captures everything.

**Switching is close to instant, and stays that way under load.** Per-host
pacing (so one relay is never hammered) used to sit behind one lock shared
by every plug — a slow background poll on any device could stall a click
on an unrelated one by up to a second. Pacing is now per host, so devices
never wait on each other. A command that meets a device's own HTTP 429
(rate limited) also fails fast — one short retry instead of the patient
multi-attempt backoff that suits an unattended background poll.

**Switching is close to instant.** A command to a plug takes a priority
lane past the polling pace (`plug_command_gap`, default 0.05 s, vs.
`plug_min_request_gap` for background polls), a toggle is a single
`Switch.Toggle` round trip, and the dashboard repaints the moment the relay
confirms — the power and energy figures follow from a background poll a
second later, so nobody waits for them. Click-to-repaint is typically
~100 ms on a LAN; a Zigbee button or a motion sensor reaches the relay
within a few milliseconds of its MQTT message (the relay is driven before
the event is even written to disk). Both gaps are tunable under
Settings → Polling.

It updates **live**: besides the five-second refresh, the page keeps one
long-poll request open (`/api/wait`) that the daemon answers the moment
anything visible changes — a report arriving, a plug switching, a binding or
rule firing, the bridge going up or down. A button press shows on every open
dashboard in well under a second; the five-second tick stays as the safety
net, and if the wait endpoint is unreachable the page simply behaves as
before. Each open tab holds one php-fpm worker for up to 25 s at a time,
which the default pool of dozens absorbs without noticing. Refreshing pauses
when the tab is hidden and can be paused by hand from the indicator in the
corner. Control buttons carry a
plain label and an icon; resting the pointer on one for five seconds
reveals the exact request behind it and what it does.

**The Control tab is locked by default.** Nothing there that changes
something works until editing is unlocked with the PIN for a chosen time
(5 min to 4 h) — from the lock pill in the header, the Editing card on the
tab, or simply by clicking any action, which offers to unlock first. The
socket buttons on the Overview follow the same mode: while editing is
unlocked they switch at once; while locked, each click asks for the PIN on
its own, without unlocking anything. While unlocked
nothing asks for the PIN again; the header counts the time down, and it
locks itself when the time is up or when you click *Lock now*. The daemon
issues a session token for the period and forgets it at the end, so an
expired session cannot be replayed; another tab, a restart of the daemon or
its own timer all relock the page. There are no browser pop-ups — the PIN
dialogue is the only one, the same as upsmon's: one box per digit, a wrong
PIN shakes and clears the boxes and asks again in place.

**Every chart pans and zooms**, as in upsmon: drag to move the window,
wheel to zoom around the pointer, pinch on a touch screen, double-click or
the *reset view* button to return. The view survives the five-second
refresh while it is zoomed. Nothing is re-fetched while panning. The tab icon is coloured by
the overall verdict.

## Rooms and heating

**A room is a name and the things in it.** Under Control → Automation, make
rooms and drop devices into them: a thermometer, a valve, a window sensor,
the plugs that live there. Nothing is forced — anything unassigned simply
stays out of the way. Rooms group the energy table, and they give the
Heating screen something to hold a temperature for.

**The Heating tab holds a temperature per room.** Each room has three
numbers — *comfort*, *eco* and *night* — and a plan of which one applies
when: a time, a level, and the days it runs on. The room reads its own
thermometer — several in the room are averaged, a valve's own measurement
is used only if there is nothing better — and whichever level is current is
pushed to every valve in the room. When a room has no thermometer, or has
several and one of them is the one that matters, the **Thermometer** choice
on its card picks the reading it holds against: the room's own are offered
first, then any other on the dashboard, marked *elsewhere*. *Right
now* overrides the plan with one level until it is put back to *follow the
plan*.

**Away** drops every room to one temperature until it is switched off —
the holiday switch. **An open window** in a room drops that room to 5 °C
while it is open, and picks up where it left off when it is shut; the
window sensor just has to be in the same room. With **Heating control**
off nothing is sent at all and the valves keep whatever they were last
told.

**A knob turns a number.** *Set to* on a numeric target has three moods:
**to** a value, **up by** a step, **down by** a step. Bind a rotary
button's *rotate_right* to a valve's target temperature *up by 0.5* and
*rotate_left* to *down by 0.5* and the knob is a thermostat dial; the
daemon keeps inside the range the device announced. It works for any number
a device will accept — a bulb's brightness, a blind's position.

A radiator head is a sleeping device, and a knob is handled with that in
mind: quick clicks accumulate on what was last *sent* rather than on a
report that is minutes old, the card shows the new number the instant the
knob moves, and a burst of clicks goes out as one message a quarter-second
after the last click, carrying the final number — ten messages queued in
the bridge and delivered one by one when the head wakes were what made a
knob feel dead. What no software can do is light the head's own display: a
Tuya head wakes its screen for its own dial, not for a value arriving over
the radio.

**What the sensor reads, while you set the rule.** Hovering the source,
the reading or the threshold of a sensor rule shows the device's current
values in a card, the chosen reading marked and the rest listed under it,
with when it last reported; a binding's device shows its last press. A
threshold is set against what is, not from memory.

**A hand on the room, not on the valve.** There are two ways to turn a
knob at a radiator. Pointed at the valve's own target temperature it sets
the head directly — and the room's plan knows nothing of it, keeps its own
number, and pushes it back at the next change of level. Pointed at 🔥
*temperature in ⟨room⟩* the knob turns the *room*: the card shows *set by
hand, 22.5 °C until 22:00, then the plan again*, every valve in the room
follows, a window still stops it, and when the plan's next step comes the
hand is lifted and the plan has the room back (four hours, if there is no
plan). That is the one to use — the same thing a hotel thermostat does when
you nudge it. The card has the same hand on it: **By hand** with a slider, the number
beside it, and *for how long*. The slider only speaks when it is let go —
dragging it moves the reading, not the valves — and arrow keys step half a
degree. While any control is in use — a slider held, a dropdown open, a cursor in a
field — the page stops rebuilding cards, so a reading landing mid-gesture
cannot close the menu, discard what was typed or pull the tile out from
under the thumb; it catches up the moment you let go — until the plan's next step by default,
or a fixed 1 / 2 / 4 / 8 / 24 hours that holds through whatever the plan
does meanwhile. The presets are one tap away on the same line — **Comfort · Eco · Night
· Off · Plan** — and a button can do the same: *heating in ⟨room⟩ set to
comfort* on one press, or **set to next** to cycle plan → comfort → eco →
night → plan on a single button. *Back to the plan now* on the card, or
*set to plan*, lifts a hand-set number early.

*Where the "until" comes from:* with a plan, the hand lasts until the plan
would next change level — set 22 at 15:00 with a *night* step at 22:00 and
it reads *until 22:00*; the plan's own steps are the natural moment to give
the room back. With no plan, or with a level picked on the preset buttons,
four hours. A fixed length chosen on the card or sent with a target
(`hold_s`) overrides both.

**Heating is a target like a plug.** Every place that offers a target — a
button binding, a sensor rule, a scene, a schedule, a presence trigger —
also offers 🔥 *heating control* and 🔥 *heating away mode* (on, off,
toggle) and 🔥 *heating in ⟨room⟩* with **set to** plan / comfort / eco /
night / off. So *everybody left → away on*, *first one home → away off*,
*the bedroom button → bedroom to night*, *22:30 → every room to night* are
ordinary entries, and a *Leaving* scene can switch the lights off and the
heating to away in one go. Setting a room's level this way is the same as
pressing one of the preset buttons on its card; *plan* hands it back to the
plan.

**Which sensors count as a room's windows.** With *stop for an open window*
on, the card lists the door and window sensors — the room's own first,
the rest marked *elsewhere*. Unticked, every contact in the room counts;
tick some and only those do, so a balcony door can stop the radiator while
the door to the hall does not.

**Control can be paused per room as well as for the house.** The
*Heating control* switch at the top stops everything; the **Control**
switch beside a room's temperature stops that room alone. Off, the room
keeps its plan, its three temperatures and its thermometer, but nothing is
sent — the heads keep whatever they were last told — and the card says
so. It is a target too: 🔥 *heating control in ⟨room⟩* takes on, off or
toggle from any binding, rule, scene, schedule or presence trigger, so a
button by the bed can hand the bedroom's valve back to its own dial for
the night and a schedule can take it back in the morning.

**A room without heating is switched off as a room.** The switch beside a
room's name on its card says whether it is heated at all. Off, the card
folds down to its title, nothing is ever sent for it, and it drops out of
the *heating in ⟨room⟩* targets — a bathroom with electric underfloor
heating on a plug, or a hallway with no radiator, is still a room for the
energy table and the sensors in it, just not one the Heating tab argues
with.

A valve's own card (Sensors) carries the same slider for its target, and
shows what it is doing rather than what it is configured with: the settings
a head keeps — its minimum and maximum, its own comfort/eco numbers, the
window-detection parameters — stay in *All values* and out of the headline,
and `position` on a head reads *valve open*. A remote's headline is the last
thing pressed or turned, not its cell voltage.

**What each head is doing is on the card.** A line per valve: what it is
holding, what its own thermometer reads (with the offset if one is set), how
far the valve is open, whether it is heating, its mode and its battery.
**Close** shuts the valves in that room. Where a head has an *off* mode
that is what is sent, because a set point of five does not actually close a
valve whose own thermometer sits on the radiator and reads warmer than the
room — it just carries on regulating; heads without an off mode get five
degrees, frost protection only. Any preset other than *Off* opens the head
again.
which is the same as the *Off* preset and is why it is offered on the room
rather than on the single head: a head shut on its own would be reopened by
the room on the next round. On a head that is in no room the button is its
own: the head's *off* mode where it has one, its lowest number where it does
not. **Match the room** sets the head's `local_temperature_calibration` so its
reading agrees with the room's thermometer — a head sits on the radiator and
runs warm, and the offset is there for exactly this.

**One vocabulary, not three.** A TuYa head has its own preset list —
*schedule, manual, boost, complex, comfort, eco, away* — which is the
firmware's own language and means nothing to the plan: *away* is the head's
away temperature, *schedule* is the head's weekly programme, *comfort* is a
number stored in the head. Zigmon's five — **Comfort, Eco, Night, Off,
Plan** — belong to the room, and they are what a button, a rule, a scene
and the Heating tab all speak. So when a head is in a room, its own card
offers exactly those five and the room's slider, not the firmware's list;
the head is kept in manual underneath and its own words never appear. A head
that is in no room keeps its raw controls, since then there is nothing else
driving it, and says so on the card with where to put it.

**A head with a mind of its own is taken off it.** A TuYa/Immax TS0601
radiator head keeps its own weekly programme, an away mode and a preset,
and while any of those is in charge a set point sent to it is obeyed for a
moment and then overwritten by its own schedule — which is what makes such
a head look like it ignores the dashboard. Before driving one, zigmon puts it in **manual** (`preset`), clears **away
mode**, and clears **force** — that last one pins the valve open or shut
whatever the set point says, and a head left on `force: open` heats flat out
and looks like it is ignoring the dashboard.

The mode needs care, because the words lie. On a TS0601 head `heat` means
*heat continuously without regulating* and `auto` means *hold the set
point* — the opposite of what they read like, and Zigbee2MQTT says so on
the device page. Those heads give themselves away by also exposing a
`preset`, which is what decides schedule versus manual there, so zigmon asks
for **auto** on them and **heat** on a plain thermostat that has no preset.
Every one of these is sent only when the head's own report says it is not
already there, so it is a message or two the first time and nothing
afterwards.

**The valves are simply the ones in the room.** There is nothing to
configure beyond putting a head into a room under Control → Automation →
Rooms; any device there with a target temperature is driven, and the card
names them. A head not in any room is left alone.

A valve is only told something when the wanted temperature has actually
changed, because a radiator head is a sleeping device and re-sending the
same number every minute would keep its radio awake for nothing. The same
reason means a change takes effect when the head next talks to the mesh —
seconds to a few minutes.

**A socket can be marked as a light.** In Plugs and sensors each channel has
a *What it is* column: **a socket** or **a light**. A light is polled,
switched, bound, ruled and recorded exactly like any other plug; what the
mark changes is how it reads.

A light also *reads* as one: its icon is a bulb rather than a socket
wherever it appears — its card, the device lists, and every dropdown that
offers a target — and the dropdowns group the lights together and sort by
name only within the group, so picking one is not a hunt through the
sockets.

**The energy table groups by room, and opens closed.** Each room is a line of
its own carrying the room's totals, and what is not in a room sits under
*Not in a room*; with no rooms set up at all, the sockets of one physical box
make a line instead (a four-way strip is one row, `PlugX4-TVLoznice · 4
sockets`) and the rest sit under *Single plugs*. Everything starts folded, so
the card is a handful of lines rather than a wall of numbers; click a group
to open it, **Open every group** for the lot, and what you opened is still
open after a reload. Every plug still
opens its last thirty days as bars, and so does *All plugs*.

**A monthly summary** goes out on the first of the month: what last month
drank, what it cost, the five biggest, and the totals by room. `zigmon
--monthly` prints it on demand; `"monthly_summary": false` in `config.json`
switches the notification off.

**Devices are sorted by what they are.** A device's kind is read from what
it reports, not from its name: ♨️ a radiator valve, 🎛️ a knob, 🔘 a button,
🚶 a motion sensor, 🚪 a door or window contact, 🌡️ a thermometer, 🔌 a
socket, 💡 a light, 📡 a router or coordinator. Every list and dropdown
groups by that and sorts by name inside the group, so picking the valve or
the PIR is not a hunt.

**Moving cards is a mode of its own.** Unlocking editing used to make every
tile on the Overview, Sensors, Plugs and WiFi draggable at once, which meant
a slider or a menu on a card could not be used without the card coming
along. There is a **Rearrange** switch beside the lock now — on the tabs that have
movable cards (Overview, Plugs, Sensors, Buttons, WiFi, Heating) and nowhere
else — off by default,
and while it is off the cards stay put and their controls work normally. On,
the movable cards are outlined, their controls are held inert, and a card
can be dragged where it belongs; the order is saved as before. It goes back
off when editing locks. The Heating cards move too, and the order they are
left in is the order the rooms keep everywhere else.

**Sections.** Every editor under Control can be folded into named
sections — *Ložnice*, *Workshop*, *TV* — with **➕ section** at the bottom
of the list. A section is a fold with a name, a count, a rename and a
remove (its rows go back to *Everything else*); it opens closed, and what
you open stays open for the session. Rows drag into a section, between
sections and within one; a section drags above another by the handle on its
header. Each section header has its own **➕** that adds a new row straight
into that section, and every row has a **Move to** menu — a click on its
handle or a right-click on the row — listing the sections, *Everything else*,
and *New section…*. All of it is part of that editor's unsaved changes and is written by
its **Save** button — the section a row sits in travels with the row, and
the order of the sections with the editor — so it survives restarts and
backups. Sections are for the eye only: a binding fires the same whether it
sits in a section or not, and the order the daemon considers rows in is the
order they are shown, top to bottom across the sections.

**Lists can be dragged into order.** Every editor under Control — button
bindings, sensor rules, scenes, rooms, sequences, schedules, people,
presence triggers, messages, devices and gateways — has a handle on the left
of each row. Drag it and the row moves; the new order is part of that
section's unsaved changes, and its **Save** button writes it like any other
edit. It is not decoration: bindings, rules and scene steps are considered
in the order they are listed, so being able to move one above another is
part of saying what should happen. A device drags with all its channels, a
rule with its clock line, a gateway with what it reported. Entries from
`config.json` have no handle, since they are not ours to reorder. The
handle only appears while editing is unlocked.

## Commands over MQTT

A Shelly Gen2+ box can take its commands over the broker as well as over
HTTP: with *RPC over MQTT* on, it listens on `<prefix>/rpc` and does what
the message says. Under Plugs and sensors every box has an **MQTT** strip:
a switch, the box's prefix, and the broker, username and password the box
should use. With the switch on, zigmon sends the box's commands — switch,
pulse, reboot, reset counters — as one publish to `<prefix>/rpc` instead of
opening a TCP connection and an HTTP round trip; HTTP stays as the fallback
when the broker is down. The box's pushes are read as before.

**Set the box up** writes it all into the box (`MQTT.SetConfig`: broker,
credentials, prefix, RPC over MQTT and status notifications on) and restarts
it, so nothing has to be typed into the box's own web page. The connection
type is the one the box's page offers: **TLS, no validation** (encrypted,
the certificate not checked — `ssl_ca: "*"`, the box's default with a TLS
broker and the pre-filled choice when this daemon's own broker uses TLS),
**TLS with a CA on the box** (`ca.pem` uploaded to the box beforehand), or
**No TLS** on the plain port; the port in the broker field follows the
choice. The box's own password is the one already stored for that address,
so the page need not carry it.

**Each box has its own broker account.** The user and password on a box's
MQTT strip belong to that box and are kept with it, like its HTTP password:
the field reads **(kept)** once one is stored, blank leaves it alone, and the
bin beside it clears this box's own. `plug_mqtt_user` and
`plug_mqtt_password` in `config.json` are only the fallback for a box that
has none — handy when every box does share one account, which is the usual
arrangement
— and their prefixes live under `plug_mqtt_root` (*shellies*), so the MQTT
strip comes pre-filled with the shared account and a suggested prefix such
as `shellies/plug-tst`, and *Set the box up* uses the shared password when
the field is left blank. One ACL block then covers every box:

```
user plug
topic readwrite shellies/#
topic write zigmon/rpc

user zigmon
topic read  shellies/#
topic write shellies/+/rpc
topic readwrite zigmon/#
```

(the zigmon lines on top of the zigbee2mqtt ones it already has; `kill
-HUP` mosquitto to reload). A box publishes its reports under its prefix
and answers RPC on `zigmon/rpc`; zigmon writes commands to `<prefix>/rpc`
and pings itself on `zigmon/ping`.

**What the broker must allow** (Control → System) lists every topic this
dashboard needs — the Zigbee feed, the `set` topics, `zigmon/#` for the
answers and the round-trip ping, and for each box with MQTT on its own
`<prefix>/rpc` and `<prefix>/#` for both accounts — and ticks each against
what `/etc/mosquitto/acl` actually allows, reading the file the way the
broker does (`user`/`topic` lines, `+` and `#`). What is missing is shown
in red and repeated underneath as a block to paste in;
`kill -HUP $(pidof mosquitto)` reloads it. `zigmon --check` prints the same
list and the same block. Set `mqtt_acl_file` when the file is elsewhere; a
broker on another machine simply says the file could not be read and lists
the lines anyway.

Mosquitto keeps its ACL to itself (`0600 mosquitto:mosquitto`), so the
daemon needs one read on it. `install.sh` asks for exactly that — `setfacl
-m u:zigmon:r /etc/mosquitto/acl`, or the mosquitto group and `0640` where
there is no `setfacl` — and when it cannot, the check and the card print the
command to run rather than leaving a puzzle.

**Test MQTT** on the strip asks the box over the broker and says which link
in the chain is broken rather than only that nothing came back. It listens
to the command topic itself: when its own message comes back, the publish
went through and the silence is the box's side — the prefix, its *Enable
RPC over MQTT*, or its way back on `zigmon/rpc`; when even that does not
return, the broker dropped the message, which it does without a word when
the ACL forbids it. Either way the answer names the missing ACL line if the
file has one. **Which road a command took** is in the event and in the log: *switched on
from the dashboard (over MQTT)*, and *went over HTTP after MQTT stayed
silent* when the fallback had to step in. **Talking to the boxes** in the
settings has two switches for this: **MQTT only** stops the fallback
altogether, so a box set up for MQTT is driven over MQTT alone and a silence
is reported rather than papered over (off by default; boxes without MQTT are
unaffected either way), and **Debug** writes every command, every MQTT
message in and out, and every decision to the log — with a second switch to
put the same in Events, where they can be read without a shell. Debug is a
great deal of writing; it is meant to be switched on while something is
being chased and off again afterwards.

Every command works the same way, without waiting: the box acts on the
publish, so the answer is watched for in a thread of its own rather than
held against the button. When it does not come within two seconds — a
broker drops a message the ACL forbids without a word — the same command
goes over HTTP, the log says so once per box per ten minutes, and it lands
in the events.

Two actions that only a box can do, **reboot the box** and **reset its
counters**, are in every Do list for a plug target — bindings, rules,
scenes, schedules — over MQTT or HTTP alike.

## A head turned by hand

Zigmon only writes to a valve when the room's wish changes, so turning the
knob on the head has always stuck: nothing puts it back until the plan moves
on or somebody picks a preset. That is right for a quick "warmer for the
evening" and wrong for a head somebody nudged in passing, so both are now
choices.

**By hand on the head** is a room mode beside Comfort, Eco, Night, Off and
Plan. In it the room is the head's own business — nothing here writes to it
at all, and the card shows what it is holding. Picking any other mode takes
the room back.

**Put the room's setting back**, in the settings, is the other way: give it a
number of minutes and a head that has drifted from what the room asked for by
more than *heating_enforce_delta* (0.4 °C by default) is told again after that
long, with an event saying so — *"Topeni-Loznice was left at 24.0 °C, Loznice
wants 21.0 °C - saying so again"*. Zero, the default, leaves a turned knob
alone. The grace period matters: a head reports its own turning within
seconds, and putting it back instantly would make the knob useless.

## The SMS tab

Between Devices and WiFi: everything the gateway has said and heard, and a
place to write. **Inbox**, **Outbox** and **Everything** are the three views;
each message shows who it was (a person's name where the number is known),
what it said, when, and whether it got through. The arrow beside one answers
it — an incoming message fills in its number, an outgoing one fills in the
text as well — and the bin forgets a single message, or *Forget them all*
the lot. Nothing there is unsent by forgetting it; it is only the record
this end.

Writing one works like an alert: tick whoever it goes to (anybody with a
number on their card) or type a number, then write. **Ctrl+Space** — or just
typing `{` — offers every fact with an example of what it would say now, a
device name and a dot lists that device's own readings, and **Emoji** is
there too. Underneath, the preview shows the message as it will actually
arrive, filled in, with the character count and how many parts it will take.

## An SMS gateway

A box with a SIM card — a Teltonika TRB140 and its relatives — so an alert
still arrives when the internet does not, and so a phone with no data can
switch something. **Control → System → SMS gateway** takes its address, port,
username and password, and which of the two interfaces it speaks: `cgi` (the
older query one, `/cgi-bin/sms_send`) or `rpc` (RutOS's JSON API, which is
logged into for a token). **Test** with a number sends one real message;
without one it only asks the gateway whether it is there and whether the
password is right. **Send one now** and **Read the inbox** are there for when
something looks wrong.

**Who it involves** is a grid on the same card, one line per person: their
number as it stands on their card under Presence, and two ticks — *gets
alerts* and *may command*. An alert goes to everybody ticked on the left,
alongside ntfy and Telegram; only the numbers ticked on the right may ask
for anything, and a number on a card that has not been ticked is refused by
name rather than treated as a stranger. Having a number is not permission
by itself. The two boxes above take extra numbers that belong to nobody on
the list.

**The gateway is a device of its own.** Once it is switched on it is asked
about itself on the same beat that reads the inbox, and what it says —
signal, reference signal, quality, signal-to-noise, operator, network, SIM
state, and how many messages went each way today — is recorded like any
other device's readings. It appears among the sensors as 📶 *SMS-Gateway*
with its signal as the headline, charts in History like everything else, and
can be the source of a rule: *signal below −100 dBm for ten minutes → tell
me* is written the same way as any other.

**A person has a number.** Put it on their card under Presence and three
things follow: a text from that number is known to be theirs, so `{person}`
can be quoted in the answer and *away* needs no name; that number may give
commands without being listed anywhere else; and an alert can be addressed
to the person rather than to a number — a message's **By SMS to** takes names
as well as numbers, and empty means the gateway's own list.

**Being at home is a target.** 👤 *Falco being home* takes on, off and
toggle from a button, a rule, a schedule or a text, and goes in by the same
door a phone's shortcut uses, so arriving and leaving fire exactly as they
would. 👤 *whoever sent the message being home* is the useful one for SMS:
one command, *away*, serves the whole household.

**A number nobody owns** is reported and does nothing: an event, and a
notification saying who wrote and what they wrote.

**What a text message may do** (Control → Automation) is the other
direction: a word to listen for and what it switches, from the same target
list everything else uses — *lights off*, *heating eco*, *away*. Only numbers ticked for
commands may do so, matched on the last nine digits so `+420777123456` and
`777123456` are one phone; a line can be opened to
anybody, which is meant for questions rather than switches. The answer that
goes back is yours to write and may quote any fact, including
`{sms_from}` and `{sms_text}`: *"Inside 21.5 C, heating yes, 2 devices
quiet."* A line with an answer and no target switches nothing — a way to ask
the house how it is. Right-click a command to try it without a phone.

**The gateway can push instead of being asked.** Give **sms_push_secret** a
word and the settings card prints the address to paste into the gateway's own
*SMS forwarding to HTTP* page; a message then arrives in a second rather than
waiting for the next look in the inbox. That one path is the only one that
accepts the agreed word in place of the API token, and nothing else on it
does. Polling stays as the fallback.

**The modem is asked over its own bus.** RutOS answers `gsm.modem0` on
`/ubus`, which knows far more than the status page: signal, reference signal,
quality, signal-to-noise, operator, network mode, SIM state, cell, roaming,
the modem's temperature and **how much data the SIM has spent this month and
today** — all recorded as readings, so `{data_month_mb}` can go in an alert
and a rule can watch the signal. **sms_status_via** chooses `auto` (the bus,
falling back to the status page), `ubus` or `cgi`.

**Numbers go out the way the gateway asks for them** — 00 and the country
code, per Teltonika's own documentation — while they are written +420 777 123
456 everywhere a person sees them; **sms_number_format** turns that off.
Sending to a group the gateway itself knows is written `group:name`.

**Test** now says what it found: *"the gateway answered — Vodafone CZ on LTE,
signal −71 dBm, SIM ready, 700 MB this month, 0 messages in the inbox"*.

The inbox is read on its own thread, so a gateway that has gone away cannot
hold up the heating or the watchdogs.

## One summary of the day

Set **digest_at** (Control → System → Settings) to a time and one message
goes out then, instead of a dozen during the day: what the month has drawn
so far and which sockets drew most of it, how many rules fired and how many
switches happened, which devices have gone quiet past the patience their
kind is allowed, which batteries are at or below 30 %, which sockets are not
answering, and the worst warning of the day. Empty means none.

## Watching over things

Two things nobody watches for themselves, both under Control → System →
*Watching over things*:

- **A device that has gone quiet.** A thermometer speaks every few minutes
  and a PIR at least when somebody walks past, so silence far longer than
  its kind ever manages means a flat cell, a lost route or a device that has
  left. Each kind has its own patience — a thermometer an hour, motion six,
  a radiator head three, a contact twelve, a button a week, a router fifteen
  minutes — and each is a setting. One word per device, not a repeated one.
- **A mesh that keeps losing devices.** Zigbee2MQTT says "left the network"
  one device at a time and a bad night buries the log in them; they are
  counted by the hour and said once, above the threshold you set.

**How devices reach the mesh** keeps which router each device goes through
and how often that has changed — a device that keeps swapping routers is one
whose commands sometimes take the long way round.

**Going back a step** keeps what each Save replaced, the last twenty by
default (`snapshots_keep`). *Put back* restores a version and keeps the
current one first, so a step back can be stepped forward again. A version
can be thrown away with the bin beside it, or the whole list at once with
*Throw them all away* — neither touches what is in force, and the next Save
starts the list again. It is not
the backup: a backup answers "how was it last week", this answers "what did
I just do".

## What it costs

The Overview carries a card in money: what the metered sockets have counted
since the first of the month, what that comes to by month's end at the same
daily rate (and how that compares with last month), last month itself, and
which sockets most of it went to. It uses the sockets' own totals, so it
counts what was used while the dashboard was not looking. `price_per_kwh`,
`standing_charge_month` and `currency` are settings.

## Find anything

**Ctrl+K** (⌘K) opens one search over every device, socket, room, scene,
sequence, rule, binding and tab. Arrows choose, Enter goes there, Escape
closes; the card it lands on is scrolled to and outlined for a moment.

## Action groups

The other way round: several things switched under one name. *The lights
downstairs*, *everything in the workshop* — pick the sockets, lights, Zigbee
switches, valves or rooms that belong together, and the group appears in
every target column under 🎯 *Action groups*. Unlike a scene, which is a
fixed list of actions, a group is a **target**: one button can switch it on
and another off, a rule can drive it, a schedule can turn it off at
midnight. Groups cannot contain groups.

## Sensor groups

Several sensors read as one. *Any PIR downstairs*, *how many windows are
open*, *the coldest room*: pick the sensors, the reading to take from each,
and how to put them together — **any**, **all**, **how many are on**, the
**sum**, the **average**, the **highest**, the **lowest**, or the **gap**
between the ends. The group then behaves like any other source: a rule can
watch it, the History tab can chart it, an alert can quote it, and it sorts
into its own 🧩 part of every source list.

Two filters keep a group honest. **Quiet after** leaves out members that
have said nothing for that many minutes, so a sensor that has stopped
reporting cannot drag an average along with a reading from last week; and
**room** counts only the members in one room, so a single group kept for a
whole floor can be asked about the bedroom. What was left out is shown
beside the group's current value.

It also remembers **which member last moved it**, which is what makes a group
worth having in an alert: the message can say `{group}` and `{value}` for the
group as a whole, and `{trigger}`, `{trigger_value}`, `{trigger_ago}` and
`{members}` for the sensor that actually set it off — *"PIR downstairs says
1 — moved by PIR-Kuchyne, 3 sensors"*. Groups live under Control →
Automation with the same sections, drag handles, right-click menu and hover
readings as the other editors.

## Where the time goes

Control → System → **Where the time goes** shows, live, every stretch
between a press and a click, so a lag can be placed rather than guessed at:

- *daemon: message → dashboard* — from the broker handing over a report to
  this page being woken (a millisecond or so);
- *daemon: status build*, *clock thread late by*, *writes waiting* — the
  daemon's own work, and whether the machine is keeping up with it;
- *browser: last repaint* — how long this page took to draw the last update;
- *broker round trip* — a message out and back through mosquitto;
- *Zigbee command → device echo* — from publishing a `set` to the device
  reporting the new value back: a router answers in a few hundred
  milliseconds, a sleeping head when it wakes;
- one line per Shelly box — how long it took to answer its last poll.

Green is fine, amber is worth a look, red is where the lag lives. `zigmon
--diag` prints the same figures first. The network-map scan, which makes the
coordinator walk the whole mesh for several seconds while commands wait,
now runs every half hour rather than every five minutes
(`networkmap_interval`).

## Command line

```bash
zigmon --status                       # every device with its latest readings
zigmon --devices                      # the device table
zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
zigmon --events                       # the event log
zigmon --watch                        # live feed straight from the broker
zigmon --watch --bridge --raw         # including bridge/* topics, untruncated
zigmon --permit-join on               # open the network for four minutes
zigmon --plug                         # every plug, live from the device
zigmon --plug-on Lednice              # switch a plug; also --plug-off, --plug-toggle
zigmon --plug-pulse Lednice --ms 3000 # flip, hold 3 s, flip back
zigmon --plug-reset Lednice --types aenergy,switch_on
zigmon --bindings                     # which button action drives which plug
zigmon shelly Lednice dump            # the Shelly toolkit, see below
zigmon --reset-data history           # erase: all, history, events, or a device name
zigmon --check                        # is the whole system healthy
zigmon --diag                         # settings, API latency, database size
zigmon                                # run the daemon in the foreground
```

## The full Shelly toolkit

Everything the standalone Shelly reader in upsmon could do, ported whole and
addressed by the name a device has in the configuration — the address and
password come from there. Each command has its own `--help`.

```
zigmon shelly [NAME] <command> [options]
```

| reading | |
|---|---|
| `discover` | find Shelly devices on the LAN over multicast DNS, with a diagnosis when nothing answers |
| `info` | identity, firmware, auth and Matter state |
| `dump` | every value the device exposes, every component |
| `methods [COMPONENT] [--examples]` | every RPC method it supports, with a note on what each is for |
| `poll` | a live table. `--interval`, `--count`, `--csv FILE` |
| `watch` | the same, pushed over the device's websocket |
| `listen`, `serve` | receive webhooks, or an outbound websocket |

| controlling | |
|---|---|
| `on`, `off`, `toggle` | switch the relay |
| `reset-counters [type…]` | no type means every counter |
| `reboot [--wait]` | restart, optionally waiting for it to come back |

| configuring | |
|---|---|
| `config [COMPONENT] ['{JSON}']` | read or write a component's settings — a write is read back and the keys the firmware dropped are listed |
| `matter status\|on\|off\|code` | Matter, and the pairing code |
| `ble status\|on\|off\|rpc-on\|rpc-off` | radio and RPC over Bluetooth |
| `call METHOD ['{JSON}']` | anything the above does not cover |

```bash
zigmon shelly Lednice dump
zigmon shelly Lednice config switch:0 '{"auto_off": true, "auto_off_delay": 300}'
zigmon shelly Lednice ble on --reboot
zigmon shelly Lednice methods Switch --examples
zigmon shelly --host 172.16.16.13 --password secret info
zigmon shelly discover
```

`--host`, `--password`, `--switch-id`, `--json` and `--no-color` work
anywhere, before the command or after it. With no name, the first
configured plug is assumed. `watch` needs a device without a password, the
websocket carrying no authentication. `discover` does not cross subnets.
`ble` and `matter` take effect after a reboot, which `--reboot` will do.

## Sensors over RPC and webhooks

```json
"sensors": [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}],
"sensor_listen": true,
"sensor_listen_host": "0.0.0.0",
"sensor_listen_port": 8088
```

A sensor with an address is polled like a plug; while it sleeps the poll
simply fails quietly. A battery sensor pushes instead — point its webhook at
`http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=NAME` (`bp` for battery
percent, `bv` for volts, `rssi`). JSON bodies are accepted as well. Each
source becomes a device like any other; `zigmon shelly listen` shows what
arrives without recording it, and the Control tab's daemon card counts the
pushes.

## API

Read endpoints are open on the loopback; the two that change something
require `X-Zigmon-Token` and, when configured, the PIN.

| endpoint | returns |
|---|---|
| `GET /api/status` | every device: identity, latest values with labels and units, verdict and reasons; the bridge; counts |
| `GET /api/health` | daemon uptime, broker connection, message count, database statistics |
| `GET /api/devices` | the device list (same shape as in status) |
| `GET /api/device?id=NAME` | one device, plus the keys it has history for and the full exposes map |
| `GET /api/history?device=NAME&keys=temperature,humidity&range=24h&points=600` | rows of `{ts, key…}`, hourly beyond two weeks |
| `GET /api/events?limit=100&device=NAME` | the event log |
| `GET /api/keys?device=NAME` | which values have history |
| `POST /api/permit-join` | `{"enable": true, "time": 254, "pin": "…"}` |
| `POST /api/unlock` | `{"pin": "…", "minutes": 15}` → `{"token", "until"}`; the token then replaces the PIN as `session` in every other POST |
| `POST /api/lock` | `{"session": "…"}` ends it early |
| `POST /api/reset` | `{"scope": "all|history|events|device", "device": "…", "pin": "…"}` |

The plugs:

| endpoint | returns |
|---|---|
| `GET /api/plugs` | every plug: state, live figures, each counter with its value and the date it started from |
| `GET /api/plug?name=Lednice&refresh=1` | one plug, optionally read again first |
| `POST /api/plug/switch` | `{"name": "Lednice", "on": false}`, `{"name": "…", "toggle": true}` or `{"name": "…", "pulse": true, "ms": 5000}` — needs the PIN |
| `POST /api/plug/reset` | `{"name": "Lednice", "types": ["aenergy"]}`, or `[]` for every counter — needs the PIN |
| `GET /api/bindings` | the button bindings |
| `POST /api/bindings` | `{"bindings": [{"device": "Button", "action": "single", "plug": "Lednice", "do": "toggle"}]}` — replaces the list, needs the PIN. `do` is `toggle`, `on`, `off` or `pulse` with `pulse_ms`; `plug` may be `*` for every plug, and the same button and action may drive any number of rows — all matching rows fire in parallel |

**Devices can be renamed and deleted from the Devices tab.** Renaming a
Zigbee device goes through Zigbee2MQTT itself (`bridge/request/device/rename`),
so the friendly name — and the MQTT topic — change everywhere, permanently;
history stays, because everything is keyed by the IEEE address. A Shelly
seen over MQTT or a webhook gets a dashboard alias instead (the topic cannot
be renamed from here); the table then shows the alias with the topic
underneath. Plugs and sensors added on the Control tab are named there.
Deleting a device erases every reading, event and snapshot recorded for it,
and takes out any binding or rule that used it as the source (each removal
is logged); a plug used as the *target* of other rules stays, since the plug
itself was not deleted. If the device reports again it simply reappears,
fresh, under its default name. Bindings and rules store the device id, not
the name, so renaming breaks nothing. `POST /api/device/rename`.

**Zigbee switches are targets too.** Anything in the network with a
settable on/off state — a SONOFF ZBM5 wall-switch channel, a bulb, a relay
module — appears in the binding and rule editors marked ⚡ alongside the
Shelly plugs, one entry per channel (`Svetla · L1`). The daemon drives them
by publishing `{"state_l1": "ON"|"OFF"|"TOGGLE"}` to
`zigbee2mqtt/<name>/set`; toggle and pulse work (a pulse with an unknown
current state falls back to a blind double TOGGLE), the switch's own report
comes back through the bridge and repaints the dashboard, and every command
is logged as an event with its origin. `*` (all plugs) deliberately never
includes them. The daemon's broker account must be allowed to **write**
`zigbee2mqtt/+/set` — if commands vanish silently, that is the mosquitto
ACL (`topic readwrite zigbee2mqtt/#` for the zigmon user covers it).

**Thermostatic valves.** A radiator head — an IMMAX NEO 07703L, a Moes, any
Tuya TS0601 head, a Danfoss — is a device with values to set rather than a
state to flip, and it is handled as one. Its card shows what it measures,
what it is holding and how far the valve is open, and carries the controls:
**Target − 21.5 °C +** and the modes the head itself names (*off · heat ·
auto*, or its presets). Half a degree per press, within the limits the head
reports.

The same things are targets everywhere else: in the binding, rule, scene,
schedule and presence-trigger editors the head appears as
`TRV-Obyvak · target temperature` and `TRV-Obyvak · mode`, and the *Do*
column offers **set to …** with a number box carrying the head's own range,
or the list of its modes. So *at 06:30 on weekdays set the living-room head
to 21.5*, *when everybody leaves set every head to 16*, *the hall button
sets the bedroom head to 18* are all ordinary entries — a schedule, a
presence trigger, a binding.

Underneath it is one publish of `{"current_heating_setpoint": 21.5}` or
`{"system_mode": "off"}` to `zigbee2mqtt/<name>/set`, logged as an event
with its origin. A valve is a sleeping device: it collects what was sent for
it when it next talks to the mesh, which is anywhere from seconds to a few
minutes, so nothing waits on a confirmation — the card repaints when the
head reports its new state itself. Pairing is Zigbee2MQTT's business; once
it is in the network zigmon picks it up like any other device.

**Notifications.** Configure a channel in `config.json` — `notify_ntfy`
(a topic URL such as `https://ntfy.sh/moje-tajne-slovo`; subscribe to the
same topic in the ntfy app) and/or `notify_telegram_token` +
`notify_telegram_chat` — and pick on the Control tab what is worth a push:
critical problems, warnings, devices going quiet, every rule that fires.
The same story repeats at most once per 15 minutes; there is a test button.
Below the global choices sits a per-device list: any plug or sensor can be
set to **mute** (nothing about it, ever), **critical only**, or
**everything about it** (warnings, going quiet, rules touching it) —
overriding the global choices for that one device.

**Scenes** are named bundles of actions ("Vecer": lamp on, chandelier off,
TV plug on) edited on the Control tab, runnable from there and available as
🎬 targets for button bindings and rules. A step can carry **after N s**
(from the scene start, fractions allowed): steps without it fire at once,
together, so `0 / 2 / 5` makes a small cascade.

**Rules: AND or OR between the two conditions.** The second condition
(already there for "occupancy AND temperature", say) now has an AND/OR
choice. Two PIRs covering one room: one rule `occupancy ≥ 1 OR occupancy ≥ 1`
(the two sensors) → on; a second `occupancy ≤ 0 AND occupancy ≤ 0` → off,
so the light turns on the moment either one sees motion and off only once
both have gone quiet — two rules instead of four. Applies to both live
firing and Dry run.

**A strip's sockets switch in the order written.** A Shelly strip has no
"set them all" call — every socket is its own `Switch.Set` — so a scene that
switches four of them sends four commands. They used to go from four
threads at once and land in whatever order the threads happened to run, so
the strip clicked in a different order every time. Now the k-th command to
the same box in a scene waits k × `plug_command_gap` (20 ms) before it goes:
the order is the order the actions are written in, every time, and a
four-way strip is done inside a tenth of a second. Drag the actions in the
scene to choose the order.

**The automation itself can be switched.** A rule, a schedule, or a whole
section of button bindings is a target like any other, so *away* can silence
the motion rules and a button can turn the bedroom's buttons off for the
night: pick 🧰 *the rule …*, 🧰 *the schedule …* or 🧰 *the buttons in "…"*
in any target column and give it **on**, **off** or **toggle**. A rule
switched off keeps its place and simply does not fire.

**Sequences** turn one button into a cycle: the first press runs step 1,
the next press — minutes or days later — step 2, and so on, then around
again; the position is remembered across restarts. A step is a scene — many
targets at once or with delays — or any single target with an action: a
plug on, a light off, a valve set to 19, a room's heating to night. Bind a
button to
the 🔁 entry to advance; bind another button (or the same button's long
press) to the ↺ entry to run the optional *reset* — a scene, or a single
target with an action, all off say — and start over. Edited on the Control tab, with Advance/Reset buttons and
a "next press: step N — scene" line.

**Rules grew up.** Besides the clock window: an optional **AND** condition
against any second reading (`occupancy ≥ 1 AND illuminance ≤ 50`), a
**must-hold-for** time in seconds (no motion for 600 s, a washer under 5 W
for 180 s — the stretch completes even if the source goes quiet), a
**way-back threshold** folding a hysteresis pair into one rule (`≥ 65 → on,
back at 55` switches off past 55), and windows that take **sunrise/sunset**
with minute offsets (`sunset-30`–`23:30`; set `latitude` and `longitude`
in `config.json`).

**Energy** on the Overview: today / yesterday / this month / last month /
this year / last year per plug, with an **All plugs** total row at the
bottom when there is more than one — click its name for the same 30-day
bar chart as any single plug, summed across all of them, computed reset-proof from the meters' own counters; set
`price_per_kwh` (and `currency`) to see money next to the kWh. On the
Control tab, an **Energy summary** card restarts those sums from zero, now,
per plug or for all — a baseline marker, not a data wipe: history and the
plug's own meters stay, and a restarted plug carries ↺ next to its name.

**Settings on the dashboard.** The safe-to-change slice of `config.json`
lives in a Settings card on Control: alert thresholds, polling intervals,
price/currency, latitude/longitude, notification channels. Saved values are
stored in the daemon's database, apply immediately (no restart) and win
over the file; putting a value back to what the file says drops the
override, and overridden fields carry a blue edge with the file's value in
the tooltip. Connection, ports, paths and the PIN stay file-only.

**Database card** (Control): the file's size and row counts, the last
roll-up, **DB latency** (a trivial read and write, measured by the daemon)
and **app latency** (browser → daemon → back, plus the daemon's own time to
answer), with four buttons — **Check integrity** (SQLite's own check),
**Optimise** (ANALYZE + VACUUM; pauses writes while it runs), **Back up
database now** (a consistent copy via SQLite's online backup, into the
backups folder, kept `backup_keep` deep) and a **list of the backups on the server**,
each with **Download** (the file itself, to keep off-site), **Restore**
(replaces the live contents; the state right before is saved as its own
backup first, so a mistaken restore can be undone) and **Delete**; plus
**Upload a backup** to put a file back into the list — it travels in pieces
of a few MB and is checked to be a healthy zigmon database before it is
accepted. (Uploads need `client_max_body_size 6m` in nginx; the upgrade
raises it from the old 16k.)

**Backup**: one button downloads every dashboard-made setting (devices with
passwords, bindings, rules, scenes, layout, aliases, notification choices)
as a JSON file; import replaces them wholesale. The dashboard also carries
a PWA manifest, so "Add to home screen" gives it an icon and a standalone
window on a phone.

**Sensor rules** drive a plug from any numeric reading, not just a button:
source device, value, comparison (≥ ≤ > <), threshold, plug (or all plugs)
and the action, including pulse. Any device with numbers works as a source —
a thermometer, a plug's own power draw, Wi-Fi signal, battery. Rules are
edge-triggered: one fires when its condition **becomes** true, not on every
report while it stays true, and a per-rule cooldown (default 300 s) stops a
value dancing on the line from hammering the relay. Two rules make a
thermostat with a dead band: `temperature ≥ 30 → on`, `temperature ≤ 27 →
off`. Each rule can be limited to a **clock window** (`from`/`to`, `22:00`–`06:00`
crosses midnight; empty means around the clock) and can name a **safe state
for when the window closes** (`window_end`: `off` or `on`) — a
motion-driven light is switched off when its night window ends, whether or
not anyone walked past at that moment, and the rule re-arms freshly when
the window opens again. Outside its hours a rule does not fire at all.
Yes/no readings — occupancy, contact, ON/OFF states — count as 1 and 0, so
`occupancy ≥ 1 → on` with the sensor's own clear-timeout makes a motion
light. Edited on the Control tab, which shows each rule's current reading
and whether it holds; `GET/POST /api/rules`; `zigmon --rules` on the
command line.

A **pulse** flips the socket and flips it back after the delay: off → wait
→ on when the plug is on (a power-cycle for whatever is plugged in), on →
wait → off when it is off. The way back is retried three times and, if it
still fails, logged as a critical event; a second pulse while one is running
is refused.

Plugs and sensors are managed on the **Control tab** — add, test, remove,
save behind the PIN; the daemon starts polling at once, no restart. *Test*
asks the device who it is and fills in whether it is a plug or a sensor;
*Find Shelly devices* runs a multicast DNS query from the server and offers
what answered on this subnet. Passwords are kept in the daemon's database
(readable by the daemon alone) and never sent back to the browser — the
field shows "(kept)" and stays blank. The same endpoints:

| endpoint | |
|---|---|
| `GET /api/managed` | plugs and sensors, without passwords |
| `POST /api/managed` | `{"plugs": [...], "sensors": [...]}` — replaces the dashboard-managed list; omit `password` to keep it, `clear_password: true` to drop it |
| `POST /api/managed/test` | `{"host": "…", "password": "…"}` → model, firmware, whether it has a switch |
| `POST /api/managed/discover` | what mDNS finds in three seconds |

Every entry can be **disabled without deleting it** — the State column on
the tab, or `"enabled": false` on the entry in `config.json` or in the
`POST /api/managed` body. A disabled plug or sensor is not polled, cannot be
switched and disappears from the lists, but its history stays, and bindings
and rules that point at it are kept (they simply do not fire, and the plug
shows as "(disabled)" in their editors) — enable it again and everything
carries on where it left off.

`config.json` still works and wins: entries under `"plugs"` and `"sensors"`
there are shown on the tab as read-only and cannot be duplicated from the
dashboard. `mqtt_name` is the device's own MQTT prefix (whatever its *MQTT prefix*
setting says — `plugtst`, `shellies/xxx`, …). Fill it in and two things
happen: the daemon does not record the device twice, and it **subscribes to
that prefix and learns about relay changes the instant they happen** — a
press of the button on the plug, its web page, the Shelly app. Without it,
an outside change waits for the next poll (up to `plug_poll_interval`,
15 s). With it, the dashboard repaints in well under a second, with the
source in the event ("switched on (button)"). A plug shows up as a
device like any other, so History and All values cover it too, and `zigmon
shelly NAME …` addresses both kinds of entry.

`device` and `id` accept the friendly name or the IEEE address.

## Broker account

The daemon needs a broker login with these rights (the installer can create
it in a local mosquitto):

```
user zigmon
topic read zigbee2mqtt/#
topic write zigbee2mqtt/bridge/request/#
topic read shellies/#
```

## What was verified

Without a broker in the build environment, against replayed messages from a
real Zigbee2MQTT 2.13 with Shelly BLU H&T ZB, BLU Button Tough ZB, a Shelly
H&T Gen3 and a Plug M Gen3 over `shellies/`:

* device discovery from `bridge/devices`, readings before the list arrives,
  rename, removal, availability, button actions, bridge events
* every API endpoint, token and PIN handling, erasing by scope
* the plugs against a mock Shelly Plug M Gen3 with SHA-256 digest
  authentication: polling, switching, per-counter resets including ones the
  firmware only pretends to clear, and a button press toggling the plug
  through a binding
* the dashboard driven in a headless browser through every tab, chart
  rendering, the PIN dialogue and a reset
* the whole Shelly toolkit against the same mock: info, dump, methods,
  config read and write with keys the firmware drops, ble and matter
  switches, on/off/toggle, counter resets, call, poll to CSV, reboot --wait,
  and the discovery diagnosis on a network with no answer
* a polled sensor, GET and POST webhook pushes, and a push carrying nothing usable
* the installer's dry run

Current version: **3.29.1**

3.29.1 — nothing could be added to or taken off the Overview, and that was
mine: 3.26.1 stopped a list of things that are not records from erasing
everything, and the Overview does not save records. It saves the names of the
cards it shows, which are plain text, so every add and every remove was
refused as nonsense — *22 of the cards for the Overview in that request are
not cards for the Overview at all (str)*, which was at least honest about
what it thought.

Each list is guarded against what it is not: records where records are meant,
names where names are. A list of numbers is still refused either way.
`test/replay.py` adds a card, takes it off, and tries to save three numbers
over the lot.

3.29.0 — a new strip on Overview, **What it is drawing**, above what it costs.
Six figures: the house this moment, and of that the sockets and the lights
with how many of each are on; then the most it has drawn in the last hour,
today and this week.

Adding up each socket's own highest would have been easy and wrong — they
peak at different moments, and the sum of those is a number no meter ever
read. The peak is the house totalled over a window and the highest of those
taken, so it is a figure that actually happened. The day and the week come
from the hourly figures, which cost eight milliseconds; the last hour is kept
minute by minute in the daemon, because asking the samples table for it takes
a second and a half, which is not a thing to do while somebody is looking at
a page. Both together cost **0.02 ms**, and `status()` is 4.2.

`{power_sockets}`, `{power_lights}` and `{power_peak_today}` join `{power_now}`,
so a message can say it too.

3.28.2 — the other half of the same fault. 3.28.0 taught the watchdog which
*roads* the house uses; it still never asked whether the house wanted to hear
about this **kind** of thing at all. The switch marked *a device going quiet,
unreachable or back* is exactly what "Temp-Venek has gone quiet" is, and with
it off the message went out anyway — by every road that was open.

All three of the watchdog's messages ask now: a device gone quiet, several at
once, and a mesh losing its members. With the switch off nothing is sent and
it is still written down in Events, which is where one goes looking
afterwards. Each switch carries a line saying what it covers, since *crit*
and *offline* both sound like they might own this one.

Checked in all four combinations of that switch and the SMS road, and
`test/switches.py` keeps both halves.

3.28.1 — the lines went in and the broker still was not told, and telling
somebody what to type is a poor answer when the thing doing the telling could
have done it. `zigmon --acl mend` is run by whoever has the run of the
machine; the daemon is not. So when the daemon reports that it could not
signal mosquitto, the command tries it here, in the process the person
started, and says what was done rather than what the daemon could not do:
*added 2 line(s); mosquitto was asked to read it again*. Where even that is
refused, the old advice stands. The line about where the copy is kept is on
its own line now, instead of running on after a block of instructions.

3.28.0 — *Temp-Venek has gone quiet* arrived by text with the text road
switched off, and it was right to: only alerts **about a device** ever went
past the switches in Notifications on their way out. Every other message — a
device gone quiet, a mesh losing its members, a text from a number nobody
knows, a rule that fired — called the notifier directly, where each road
defaulted to yes. Eleven callers, none of them saying which road, all of them
texting. So *SMS off* was true of some messages and not of others, with
nothing to say which.

A road not named now means *whatever the house is set to*. Naming one is
still allowed and still obeyed, for the cases that mean it — a reply to
somebody who wrote in goes by text, because that is what they used, and a
device with roads of its own keeps them. `test/switches.py` puts a
thermometer forty hours in the past and checks that it texts when the road is
on and does not when it is off.

3.27.1 — and the line was written only by a fresh install, so nobody
upgrading ever got it: the same shape of fault as a switch that is saved and
never read, this time in the installer. An upgrade now writes it, and
re-installs the systemd unit while it is there, since the unit changes with
the program.

`test/version.py` compares what a fresh install does against what an upgrade
does and refuses a release where an upgrade skips a step that is not about
first-time setup. Checked against the fault itself: with the step taken out
again, it fails and names it.

3.27.0 — the lines went in and then the broker was never told, because one
user may not signal another user's process: this daemon runs as `zigmon` and
mosquitto as `mosquitto`, so the polite HUP came back *Operation not
permitted*. The ACL was right and the broker was still working from the old
one, which is the quietest way for this to go wrong.

The signal is still tried first, and systemd is asked when it is refused
(`systemctl kill -s HUP mosquitto`, then `reload`, then the same under
`sudo -n`). The installer writes the one line that lets that work —
`/etc/sudoers.d/zigmon`, allowing exactly that one command and nothing else —
and removes it again on uninstall. Where none of it is allowed, the message
says what to type and what to add to make it unnecessary next time.

3.26.3 — **all sockets** sits among the sockets now, the way **all lights**
already sat among the lights, rather than alone under a heading of its own.
Each is the first line of its group, since it is what somebody reaches for
before reading fifty names.

3.26.2 — mending the ACL failed after doing exactly what it asked for, which
is the worst kind of advice. The copy of the old file was being written
*beside* it, and creating a new file in `/etc/mosquitto` needs the run of the
directory — so `setfacl` on the one file was good advice that could not
possibly work, and the failure was then blamed on the file, which was
writable all along.

The copy now goes next to the database, where this daemon may always write,
and the message says where it is. If the ACL itself really is unwritable, the
advice adds the other thing worth checking — whether systemd is holding /etc
shut for the service. Tried against a directory that refuses new files, as
theirs does: four lines added, the copy kept, the file correct.

3.26.1 — another pass for faults and for slowness, and it turned up the worst
bug of the lot. **A list of things that are not records erased everything.**
Send `[1, 2, 3]` where the rules should be and every validator did what it
has always done — skip what it does not recognise — so the list cleaned itself
down to nothing, and that nothing was saved over twenty-four rules. Fourteen
bindings, six scenes, seven rooms and the people went the same way. The guard
against this had only ever checked that the thing sent *was* a list.

It is refused now, in words: *3 of the rules in that request are not rules at
all (int) — nothing was changed*. Deleting the last row is still allowed,
because that is somebody meaning it. `test/replay.py` now tries six shapes of
bad save and one honest empty one.

Everything else came back clean. Seventeen hot paths, none over 3.3 ms.
Seventy-five seconds of storm in three windows with no drift — 5.5, 4.7 and
5.0 ms — nothing lost, nothing failed, thirteen threads and the same memory
at the end as at the start. Sixteen reads, none over 60 ms. No method defined
twice, nothing written to the database that is never read, no id used that is
not made, no name the page calls that the relay cannot serve. Quiet, a report
reaches the page in **1.5 ms**.

3.26.0 — every control in the whole application, counted and checked: **2233
buttons, 3125 boxes, 3147 lists and 20 text areas** across all six tabs and
the five sections of Control. Every one of them either has a handler or has
its value read somewhere. None is a decoration.

Then the deeper question — whether what a control writes survives being
saved — and that found a real one. **A scene could not be called Ložnice.**
Names were checked against English letters only, so Ž, ě, á and every other
letter of the language this house is run in were refused, with nothing but
"needs a sensible name" to explain it. Scenes, sequences and renamed devices
all used that rule. A name may now hold letters of any language, digits,
spaces and a little punctuation — and still not a slash, a control character
or an empty string.

Saving a scene from the summary rather than the editor answered *internal
error: int object is not iterable*, because the overview carries how many
steps a scene has rather than the steps. It now says what it got and what it
expected. **`test/roundtrip.py`** writes into every editor, saves, and reads
back — and one of the things it writes is a scene called *Ložnice večer*.

3.25.1 — a second pass over Control, from three directions at once. What the
editors write into a record, against what the daemon reads out of it: every
field lands somewhere. What the daemon keeps, against what the page can set:
every field is reachable. And every setting the daemon will accept, against
what the page offers: two were missing and are now shown - how long a room
set by hand keeps its setting, and how often the forecast is fetched.

Then the check that would have caught the debug switch on the day it was
written: **switches, tried both ways:
  debug                    changes what happens
  watchdog                 changes what happens
  sms_queue                changes what happens
  sms_stranger_alert       changes what happens

every switch checked changes what the daemon does** puts the daemon in a state where a setting
matters, turns it on, turns it off, and looks at what the daemon *does*.
Saved is not the same as heeded, and only one of those had ever been tested.
It refuses a release where a switch makes no difference either way.

3.25.0 — after the debug switch, a sweep for anything else that looks like a
setting and is not one. Every tunable was checked against where it is
actually read, and every button and switch on the page against whether
anything happens when it is used. Four settings appeared to be read nowhere
and are read by the page rather than the daemon; the seven `silent_after_*`
are looked up by name and so invisible to a plain search; four buttons
appeared to have nothing behind them and are wired through the row they sit
in. Nothing else was pretending.

**All plugs** took the lights with it, which is wrong at bedtime: *everything
off* should not take the fridge, and *all the lights* should not take the
workshop PC. It is now **all sockets**, and **all lights** beside it - the
same thing for the ones whose role says light. On your house that is fourteen
and eight. Anything already written as *all plugs* keeps working and now means
the sockets; `test/replay.py` refuses a release where either takes one of the
other's.

3.24.0 — the prefix, and the other half of the MQTT switch.

**One box, one prefix.** The field in each socket's row is read-only, since a
box publishes under one name and four sockets cannot each have their own; the
one to type in is in the MQTT strip under the box. Where the rows already
disagree - as yours do, `plugx4-tvobyvak-1` to `-4` - the strip now shows what
they were all reaching for (`plugx4-tvobyvak`) rather than whichever happened
to be first, says in so many words that the sockets have four different
prefixes and only one of them can be right, and settles all four when saved.

**Switching MQTT off here only ever stopped us using it.** The box went on
logging in to the broker, publishing its status to nobody and holding a
connection for nothing. With the switch off, the button now reads **Switch
MQTT off on the box** and does exactly that: `MQTT.SetConfig enable false` and
a restart. It is the only thing in the strip that stays alive when the switch
is off, because it is the only thing one wants then.

3.23.1 — the trace did its job on its first outing. Two findings from one
log.

**Presence over ntfy has never worked.** The listener reached for `urllib`
without importing it, so every attempt died on its first line with a
NameError - caught, written at debug level, and therefore invisible for as
long as the debug switch was writing to a bin. It is imported now.

**A box that is already on the broker now says so.** The strip in that log
reports `mqtt: connected` in its own status while being driven over HTTP,
where each socket is a round trip and the box answers one at a time. Said
once per box, in the log and the events, since it is a setting away from
being four publishes instead.

3.23.0 — the debug switch was writing to a bin. It set a flag, and the line
that decides whether a debug message is kept never looked at that flag: it
waited for `log_level` to say debug as well. So the switch marked *write
every command and every MQTT message to the log* had, for its whole life,
written nothing. It writes now.

And it writes properly. With it on, the log is a trace: every HTTP request
with the address it went to, the method, the body, what came back, and how
long it took; every MQTT message either way with its topic, payload and
quality of service; every wait for a box, saying how long and how many were
in hand and queued; every scene line as it fires. Each stamped to the
millisecond, because a stamp to the second cannot answer a question about
latency - which is what an event log stamped to the second had been doing to
all of us.

    15:24:13.255  MQTT in  zigbee2mqtt/Button - {action: single}
    15:24:13.256  command toggle -> PlugX4-TVObyvak-1 - scene Test
    15:24:13.256  box 127.0.0.1: a command waited 0.0 ms (1 in hand, 0 queued)
    15:24:13.257  http -> 127.0.0.1 POST /rpc fresh {method: Switch.Toggle, ...}
    15:24:13.259  http <- 127.0.0.1 200 in 2.4 ms {result: {was_on: true}}

About fifteen kilobytes a minute on a quiet house, so it is a switch: turn it
on to find something and off again afterwards. With it off, not one line is
written that was not written before, and the timing is unchanged - a report
still reaches the page in 1.7 ms.

3.22.0 — found at last, and it was invisible by design. A small box answers
**429 Too Many Requests** when asked too often, and every switch was followed
by a confirming read of the box: a strip of four meant eight requests inside
a second at a device happiest with one or two. When it said 429, the command
retried after **two seconds** - and since the retry then succeeded, the only
trace was a line at debug level. Nothing in the events, nothing on the card:
a strip that worked, slowly, for no reason anyone could see. Over the broker
none of this exists, which is why MQTT was instant all along.

Two things. A strip switched together is now confirmed with **one read of the
box**, not four, so the burst is five requests rather than eight. And a
command told 429 waits what the box asks for and half a second at most, says
so at warning level, and the card and `zigmon --diag` show which box has
been asking for mercy and how often.

Against a box allowing five requests a second: 2.99.5 did the first press in
257 ms and then **2311, 2323, and a failure**; this does **210 ms every
time**. `test/replay.py` refuses a release where four switches need more
than one confirming read.

3.21.3 — comparing against 2.99.5, which you were right to say had been
quick, showed what I had broken and why. Every switch is followed by a
confirming read of the box, and a box answers one thing at a time. In 2.99.5
all four commands of a strip were put in hand at once, so they sat in the
queue together and the confirming reads had to wait behind them: four
commands, four round trips. Sending them one after another instead - which I
did to make the order certain - let each confirming read slip in between, so
every socket after the first cost two round trips rather than one.

They are all put in hand at once again, and the order is kept by the thing
that was missing all along: **a queue**. A lock is not a queue - it hands
itself to whichever thread the system happens to wake, which is why four
sockets clicked in a different order every time. A command now takes a ticket
and is served in the order it asked.

Against a box that takes a quarter of a second to answer: **2.99.5 did a
strip of four in 1260 ms, this does it in 1010** - which is four round trips,
the floor for a box that answers one thing at a time - and in the order
written, four runs out of four.

3.21.2 — and keeping the connection open was the wrong medicine, which is my
fault: yesterday it was quick, and this morning it was not. A box closes an
idle connection after a few seconds and does not always say so. Writing into
that dead socket succeeds - the data goes nowhere - and the answer then never
comes, so the call sits there until the timeout. Three seconds a socket, four
sockets on a strip: exactly the extreme lag you were seeing, and only over
HTTP, because the broker connection is the broker's business and never goes
stale under us.

A kept connection is now only used again if it was used moments ago
(`plug_keepalive_s`, three seconds), which is precisely when it helps - the
four commands of one scene - and never between one press and the next. A
connection dropped silently in between costs **one millisecond** instead of a
three-second timeout, and setting the number to zero goes back to a new
connection every time, exactly as it was the night before.

3.21.1 — *Add them for me* failed with a message blaming permission, which
was wrong: systemd keeps /etc shut for this service (`ProtectSystem=strict`),
and a read-only filesystem is not a permission at all. The unit now allows
the one directory the broker keeps its ACL in, so a fresh install can mend
it; on a machine already running, the message says exactly what to type
(`systemctl edit zigmon`, one line, restart) instead of sending somebody to
chmod a file that was never the problem. The other two cases — a file that
truly refuses the write, and anything else — each say their own thing.

The ACL list also now says the thing standing behind it: a box given a
different MQTT prefix for each of its sockets asks for four sets of lines and
only one of them can ever be right. Both your strips are like that, and this
is the page where somebody looks when a command goes out and nothing happens.

3.21.0 — measured end to end rather than argued about. A button pressed on
the broker, through the binding, the scene and four sockets on one box, to the
dashboard seeing all four switched: **54 ms**, six presses running.

Which raises the question of what the events were showing, and the answer is
that **an event is stamped to the second**. Two things a hundredth of a second
apart land on either side of a tick and read as a second apart; a strip that
switches in fifty milliseconds can look like four sockets clicking over two
seconds. The log was not lying about the order, only about the spacing.

So there is now a figure that cannot mislead: **the last switch commands**, on
the card and in `zigmon --diag`, one line per socket, saying what that
command cost from asking to answered. Everything above it in the list is the
daemon; that line is the box and the network. If a scene feels slow, that is
where to look — and if those numbers are small while it still feels slow,
the lag is not in the switching at all.

3.20.2 — four at once made it far worse for you, and that is the answer: a
small box does not want company, it wants to be left to answer one thing at a
time. Asking four things of it at once makes it queue them itself, or drop
them and be asked again, which is how a fifth of a second becomes several.

So the default is one again, and one is now the *fast* path rather than the
slow one. A box that takes one thing at a time is sent them one at a time, by
one worker, **with nothing added between them** - the box's own answer is the
only wait there is, and the order is certain because one worker cannot get
ahead of itself. Both the breath between starts and the command gap were
written for a world where nothing else stopped a box being hammered; the box
answering one at a time already does. A strip of four went from **152 ms to
six**, in order, on the same box.

Every shape was measured again on a real box afterwards: a strip, a strip
with two sockets of their own, two told plainly *on*, one by itself, and a
step with a delay of its own. All correct, and the four guards still pass.

3.20.1 — measured against a real box rather than guessed at, and the rest of
the wait was mine. A strip of four took 155 ms of which the box needed three:
the daemon was leaving `plug_command_gap` between one socket and the next,
and then `_wait_turn` left it again inside each. Both were written when a box
could only answer one thing at a time. What protects a box now is how many it
will take at once, so where that is more than one, the breath between starts
is a hair — enough to fix the order, nothing more — and the gap itself is
shared between them rather than paid per socket. **155 ms to 25**, in order,
on the same box with the same settings.

Where a box is still set to one at a time, nothing changes: it is paced
exactly as before. Every shape was measured again afterwards — a strip, a
strip with two sockets of their own, two sockets told plainly *on*, one
socket by itself, and everything at once — and the four guards in
`test/replay.py` still pass.

3.20.0 — the extreme lag had a cause of its own, and your configuration
showed it. Commands and polls shared one mark of when the box was last
spoken to, and a poll reserves its next turn a whole second ahead
(`plug_min_request_gap`). A press landing just after a poll therefore waited
out that second before anything moved — a socket that answers in a fifth of a
second looked like a socket that took one. They keep their own marks now: a
command waits only for the command before it, while a poll still waits for
whatever went last, so no box is asked twice in a breath. Measured on your
own numbers, a press landing straight behind a poll went from **1000 ms to
1 ms**.

It also noticed something in your setup worth saying out loud: the four
sockets of one strip are each given an MQTT prefix of their own
(`plugx4-tvobyvak-1` to `-4`), and both of your strips are like it. A box
publishes under one prefix, so at most one of the four can be right; over
MQTT the other three would send commands to a topic nothing listens on. The
daemon says so now, in the log and in the events, whenever it finds one box
wearing several names.

3.19.2 — writing out a complete configuration turned up a fault of my own:
`plug_commands_at_once` had been added to the settings the dashboard may
change, but not to the defaults, so it worked and was invisible. The default
is there, and `test/tables.py` now refuses a release where a setting can be
changed but has nothing to change from.

3.19.1 — over HTTP a strip was slow for a reason nothing in the scene could
fix: a box was allowed one request at a time, so four sockets meant four round
trips one after another — six hundred milliseconds on a box across the house,
where the broker does the same in one. A poll still has the box to itself, but
a few *commands* may now be in flight together: `plug_commands_at_once`,
four by default, one for a box that cannot abide company. Four sockets in
**150 ms instead of 601**, and a poll waiting behind them as it always did.

Mixed scenes are unaffected by any of it: each box is judged on its own, so a
scene naming two sockets over MQTT and three over HTTP sends the first lot in
one breath and the second as fast as that box will answer.

3.19.0 — **Save as text** on the Events tab. It writes what the filters have
left — every page of it, not the one on screen — as a tab-separated file, with
a heading saying when it was saved and what was being shown, so a file kept
for later still says what it is. The name carries the date and time, and the
whole thing is made in the browser, so nothing is asked of the daemon.

3.18.1 — you asked whether the other shapes still work, and one did not: a
Zigbee light in a scene full of sockets was left out of the decision and went
on flipping by itself, so the thing yesterday's fix was meant to stop could
still happen to the light. It joins the rest now — whatever is on decides for
everything named, sockets and lights alike.

Six shapes were walked through: three channels of one box with two sockets of
their own, the same with one of them already on, a scene where two lines say
*on* and two say *toggle* (each keeps its own meaning), a strip that is off
beside a light that is on, one socket by itself, and a scene mixing all three
kinds. `test/replay.py` keeps the last of those, with a light of its own so it
does not depend on what any database happens to hold.

3.18.0 — a strip of four told to *toggle* was four sockets each flipping on
its own. One press while they were out of step left them out of step, and
every press after that shuffled them again: on a four-way strip that reads as
random, which is exactly what you were watching. A toggle over more than one
socket is now one decision for the lot — anything on means all off, all off
means all on — and each is told plainly rather than asked to flip, which is
also what a box would rather hear. Written as one line or as four makes no
difference; a single socket on its own still toggles.

And it is instant over the broker. The breath between commands exists because
a box answering HTTP can take only one at a time; over MQTT there is no such
queue, so a strip driven that way goes out in one breath — **1.6 ms from the
first command to the last, where it had been 63**.

3.17.0 — the broker's ACL can be mended from here. **Add them for me** on the
card, or `zigmon --acl mend`, puts exactly the missing lines into each user's
own block — nothing else in the file is touched, since it is the broker's own
and full of things this daemon knows nothing about: other users, other
topics, the order somebody chose, their comments. A copy of the file as it
stands is kept beside it first, the result is read back and checked, and if
the check fails the copy goes back. Then mosquitto is sent a HUP, which makes
it read the file again without dropping a single client — a restart would
drop them all.

`zigmon --acl` prints the same table the card shows, for when the dashboard is
not to hand.

3.16.2 — and I had gone too far the other way. Judging a shut room by the
head's mode was right, but not knowing the mode counted as *off*, so a head
that had not spoken since the house started was left alone whatever anybody
did to it. Not knowing counts as not off now: the head is switched off again,
once, and said so in words that match what was done — *"Topeni-Obyvak was
switched on by hand and Obyvak is off — switching it off again"* rather than
talking about degrees, which is not what a shut room is set by.

3.16.1 — you were right to ask, and the answer explains yesterday's flood.

A room that is shut — *off*, or a window open — is shut by switching the head
off, not by sending it a low number. That is correct, and it is what happens:
your four heads are all reporting `system_mode: off`, doing exactly as they
were told. But the watch for a hand-turned knob was comparing the head's *set
point* against the five degrees the room nominally wants, and a head that is
off keeps reporting whatever number it last held — thirty, in two of your
rooms. So it read as drift, every time, for ever. A shut room is judged by the
head's mode now: off is right, whatever number it is showing.

A room that wants heat is unaffected — a head turned by hand there is still
put back, and still put into manual first so that the head's own programme
does not fight it.

3.16.0 — two faults you caught, both mine.

**A head that would not listen was told for ever.** Told at once means told at
once, but the head answers with what it is still set to, and that answer was
taken as fresh news that it had been turned by hand — so the house told it
again, and again, several times a second. A head is a battery device and that
is how one is flattened in an evening. The same head is now told no oftener
than `heating_enforce_gap_s` (two minutes), at most
`heating_enforce_tries` times (three), and then the house says once that it
will not take the value and leaves it alone until the head says otherwise. Put
right by hand, or accepted by the head, the counting starts afresh. Nothing is
sent to a head that is already where it should be — that was true before and
is still true; what you were watching was one head refusing, over and over.

**Quiet after was being overruled.** Setting it to five hours still brought an
alert after one, because a built-in expectation per kind of device — a
thermometer speaks within the hour — won over it. Those are guesses about
devices; *quiet after* is what somebody actually asked for. The longer of the
two wins now: a kind may ask for more patience than the house, never for less.
The setting says as much in its own words, rather than the bare *Quiet warn*
that read like the only thing governing it.

3.15.4 — a proper look for anything that could be making it slow, and nothing
found that needs fixing.

The work done for every message that arrives is **nine to fourteen
microseconds**, the watch on a radiator head a single microsecond, and waking
the page a tenth of a millisecond. Nothing on the half-minute beat touches
the network — the four things that do are each put on a thread of their own.
The store's lock is never held while anything slow happens, and the write
queue never grew past nought.

Ninety seconds of storm in three windows showed no drift: 2.7, 2.9 and 2.9 ms
median, and the thread count and memory the same at the end as at the start.
Three strips fired at once sent twelve commands in **0.06 s**, each box in
its own order; one scene fired forty times over sent all hundred and sixty
and came back to seven threads.

Quiet, a report reaches the page in **1.5 ms**.

3.15.3 — and it was slower, as you said. Keeping a strip in order, I had it
wait for each socket to answer before starting the next, which turns one round
trip into four: a four-socket strip took **0.66 s where it had taken 0.21**,
and worse on a box further away. What has to be in order is the sending — the
box acts on the commands as they arrive — not the finishing. One worker starts
them in order, twenty milliseconds apart, and they fly at once. Back to
**0.21 s**, and still in order.

The guard in `test/replay.py` was measuring the wrong thing too: it watched
which socket *finished* first, which parallel sending makes meaningless. It
now notes the moment each command is handed over, with the last of the strip
answering fastest — exactly what used to shuffle the order.

3.15.2 — you were right, and I am sorry: keeping a strip's sockets in order
broke the scenes it was not thinking about. The sockets were gathered into a
list and sent after the loop had finished — but a step with a delay of its own
runs long after that loop, so its sockets went into a list nobody read again
and were never switched at all. Each batch now sends its own, so a step with a
delay works as it always did; and steps that share a delay are one batch, so
four sockets told to go in a second go in the order they are written rather
than racing from four threads.

`test/replay.py` now runs four shapes of scene — a strip alone, a lone socket
beside a strip, a step with its own delay, four steps sharing one — and
refuses a release where any of them switches the wrong things or switches
them out of order.

3.15.1 — an access point was listed under *The SMS gateway*. It had been
given the modem's own mark — set once with the rest of the icons, then
quietly set again to the modem's a hundred lines further down — and the lists
group by the mark, so the two ended up under one heading. An access point has
a mark of its own now, a globe, told apart at a glance from the Zigbee
router's dish and the modem's bars, and it has its own heading: **Wi-Fi**.

3.15.0 — putting a hand-turned head back could only be asked for in whole
minutes, and was off unless somebody had thought to set it. It is a choice
now, in words: **leave it**, **put it back as soon as the head says
otherwise**, or after five, fifteen, thirty or sixty minutes.

*As soon as* means what it says. The half-minute round was the only thing
watching before, so a knob turned by hand could stand for the best part of a
minute; a head's own report is now the moment — when it says it is set to
something the room did not ask for, and the room is not on manual, the room's
wish goes back there and then. Nothing else on the head wakes it: a battery
reading or a temperature passes without a word.

A room set to **manual** is untouched by any of this, as it always was: that
is what manual is for.

3.14.0 — the help was sixty lines aligned by hand, so a command longer than
its neighbours ran into their column and eleven of them had nothing said about
them at all. It is a table of pairs now — the command, and what it does — laid
out at the moment it is printed: one column for every description, set by the
lines that fit rather than by the longest, and a command past that column
keeps its words on the next line under the same margin. It follows the width
of the terminal, so a narrow window folds rather than spills.

Eleven examples were given words, and four that were missing were added:
`zigmon modem credit`, **`zigmon modem ussd '*123#'`**, `zigmon sms raw` and
`zigmon sms waiting`. Sixty-one in all, and `test/version.py` refuses a
release where one of them has nothing said about it.

3.13.3 — the target lists put anything they did not recognise under
*Sockets*, so yesterday's six new targets and the *answer only* line for a
text message all ended up among the plugs. Sorting them is now the same
question as naming them: **What the house does to itself** has its own
section at the foot of the list, beside *Automation on and off*, and **Just
an answer** has one at the head. The placeholder used to be dropped in above
the first heading with no heading of its own, which is what made it read as
belonging to whatever came next.

An access point was a *sensor*, since nothing said otherwise — it has its own
kind and its own section now, and sorts between the modem and the routers.

3.13.2 — the credit was read as whatever number came first in the operator's
message, which is as likely to be a phone number or a date as a balance. A
figure has to look like money now: standing beside a currency, or written
after a word like *kredit* or *balance*, or carrying decimals — and never a
number followed by GB, MB or a per cent sign, which is a data allowance
talking. `sms_credit_pattern` takes a pattern of your own for an operator
that words it some other way.

**`zigmon modem ussd '*123#'`** sends any code and prints what comes back in
full, wrapped to the terminal, saying underneath what it read as money and
whether anything was recorded. `zigmon modem credit` still uses the code from
the settings.

3.13.1 — a check over the whole of it for faults and for slowness, and one
thing worth guarding against.

Under a storm — six motion sensors, eight thermometers and three buttons all
reporting twelve times a second, two pages polling and searching, an editor
saving in a loop — the daemon rose to four hundred and sixty-five threads
before settling back to thirteen. Nothing broke and nothing was lost, but a
remote with a stuck button can ask for work faster than the work finishes,
and the answer to that should not be threads until it falls over. Past two
hundred pieces of work in hand a scene is dropped, said once a minute in the
log and written down in the events. Asked four hundred times with each socket
taking two seconds, two hundred were done and two hundred refused, and the
thread count held.

Timings on the tenth of September's database: quiet, a report reaches the
page in **1.4 ms** with a worst case of 4.9; under that whole storm, 5.3 ms
with a worst case of 42. Twenty hot paths measured, none over four
milliseconds except the modem status, whose thirty-one are a refused
connection to a gateway that is not there — the honest cost of asking.

3.13.0 — the four sockets of one strip in one scene clicked in a different
order every time, and now and then one answered so late it read as a flicker.
Each socket was going off on a thread of its own and all four then queued for
the same box; a Python lock hands itself to whichever thread happens to be
woken, not to whichever waited longest, so the head start each was given
counted for nothing. The sockets on one box are done by one worker now, in
the order they are written, each after the last has gone — and
`test/replay.py` runs a four-way strip three times over, with the last socket
answering fastest to tempt the race, and refuses a release that comes out in
any other order.

**A button can now tell the house what to do with itself.** Six new targets:
hush every alert for an hour or overnight, clear the standing alerts, ask
every socket and the modem where they stand, take a backup, send the daily
summary. A hushed house still writes everything down; it simply says nothing
until the time is up. They sit in every target list beside the sockets and
the scenes, so a rule, a schedule, a text message or a button by the door can
all reach them.

3.12.0 — two things an action could not say, and ten things a message could
not ask.

**On for a while.** `for:10m`, `for:30m`, `for:2h` and `off-for:30m` switch
now and switch back after — a cellar light, a fan, a pump, a socket muted for
half an hour. Every editor offers them and a text message takes them, so the
same words work wherever an action is written. It is not the old *pulse*,
which is a blink measured in milliseconds.

**A nudge from where it is now.** `step:+1`, `step:-0.5` and their kin read
what a settable target is at and set it that much higher or lower — a degree
warmer than whatever the plan says, without knowing what the plan says. If
there is nothing to nudge from, it says so and leaves it alone.

**Ten more facts**, about the house rather than one device: `{power_now}`
what everything is drawing, `{plugs_on}` and `{plugs_on_list}`,
`{coldest_room}` and `{warmest_room}`, `{rooms_heating}`, `{devices_quiet}`,
`{uptime}`, `{version}` and `{credit}`. A hundred and three now, every one
offered in the picker and filled by the daemon.

3.11.2 — a pass over the whole of it. One thing found: three readings were
described twice in the table of names and units — *pressure*, *window
detection* and *away mode* — and since Python keeps the last of two, the
earlier description was dead text that could be edited to no effect. The
duplicates are gone, and **`test/tables.py`** now refuses a release where a
hand-kept table says the same thing twice, or a class defines the same method
twice.

Everything else came back clean: every setting the daemon reads is offered
and every one offered is read, nothing written to the database goes unread,
no name on the page goes unserved, no id used without being made, no icon
named that does not exist, and all twelve editors refused four kinds of
nonsense each with the rules, scenes, rooms and people untouched. Quiet, a
report reaches the page in 1.5 ms.

3.11.1 — the credit was being asked for and kept, but never shown: it sits on
the gateway's card now, beside the signal and the data. How often to ask is a
list rather than a number — never, every six hours, twice a day, once a day,
once a week — and both it and the code moved up beside the other message
settings, out of *rarely needed*. On a contract SIM, leave the code empty and
nothing is ever asked.

3.11.0 — four things a text can now do.

**A command may take what follows it.** Switch on *takes a value* and
*heating 22* sets twenty-two degrees, *heating eco* sets eco — one command
instead of one per number. A number becomes `set:22`, a word the house knows
(on, off, comfort, eco, night, plan, manual) becomes that, and anything else
gets a short reply saying so rather than doing something unintended.

**A text can ask about a thing.** *Temp-Venek*, *temp loznice*, *Plug-UPS* —
the name of a room, a socket or a device, and it answers: *"Loznice: 23.3 °C
wants 20.0 not heating"*, *"Plug-UPS is on, 145 W"*. It looks for what is
called exactly that first, and only then for what the words are part of, so a
sensor called *Temp* does not answer every question with the word temp in it.

**help** replies with what the house understands, and it is what an
unrecognised text gets back too.

**The credit on a prepaid SIM.** `sms_credit_code` (`*101#` on most Czech
networks) is sent to the network with the API's own USSD call, on a button or
every so many hours; the answer arrives as the operator wrote it, is kept, and
the number in it becomes a reading — so a chart shows the credit going down
and a rule can watch it. `zigmon modem credit` asks from the command line.

3.10.2 — a walk over every control on the Control page, section by section:
thirteen cards in System and eighteen elsewhere, some fifteen hundred boxes,
lists and switches between them. Each was asked whether it has a label, is
the right kind of thing, carries a mark where its neighbours do, and shows
its words in full. One fault: the **Setup…** button on a person's card, which
gives the link for their phone's shortcut, was the only button in Control
without a mark; it has the link icon now. The forty-three lists that came
back empty are the action pickers on rows pointed at a notification — hidden,
as they should be, and none of them visible to anybody.

3.10.1 — yesterday's three roads were the house's only: a device that already
had its own notification override could say *what* was worth saying but not
*which way* to say it, and the code that read the override was looking for
something the page never wrote. Each device now has a second picker beside
its own — *by whatever the house uses*, *push only, no text*, *push and a
text*, *a text only*, *ntfy only*, *Telegram only* — and what it says wins
over the house. A freezer that must reach a phone in the night can have the
text while nothing else does.

3.10.0 — an audit of where every alert goes, and two things wrong with it.

**A written message** has had three switches of its own since 3.0.0 —
ntfy, Telegram, SMS, and who by text. **The ones the daemon writes itself** —
a battery running down, a device gone quiet, a rule firing, a socket that
will not answer, the daily summary — had none: they went down every road
that was configured, and once a gateway existed that included a text. They
have the same three switches now, under Notifications, and **a text is off
unless it is asked for**, since it costs money and wakes a phone at night. A
device that already has its own notification override can carry its own
choice of roads too.

**The forecast was being watched for going quiet.** The watchdog is for
sensors with batteries and radios, and it had been left to consider anything
that was not a socket — so the weather card, the modem card and a sensor
group could all be reported as having fallen silent, which is how a text
saying *Outside has gone quiet* came to arrive. None of them is watched now;
each says elsewhere when it cannot be reached.

3.9.3 — the blue frame round a settings box was not the pointer or the
cursor: it is the mark for a setting whose saved value differs from what
config.json says, which is what *weather_place* had become the moment it was
typed in. It looked exactly like a focused box, so it read as something stuck.
It is a blue edge down the left side and a dot beside the label now, which
cannot be mistaken for either, and the note above says so in those words.

3.9.2 — a pass over the tenth of September's database (1.73 million samples,
63 devices, 24 rules, integrity clean) and over what more than one thread
touches at once.

The database holds nothing it should not. What looked at first like a fault —
a motion rule firing eight hundred times to switch a light off and never once
to switch it on — is the configuration saying so: two of those *on* rules are
switched off, and a third only fires in the dark. No duplicated rows, no
row written twice for one moment, the roll-up doing its work.

One real fault in the sweep for races: the list of messages already dealt
with was trimmed by sorting the keys and keeping the last two hundred, which
keeps the ones whose slot number sorts highest rather than the ones that came
last — so on a busy line the wrong ones were forgotten and a message could be
acted on twice. It keeps them in the order they arrived now. Everything else
that several threads touch is either behind a lock or a deque, which is safe
by nature.

Measured on that database, with a storm of messages, two pages polling and
searching, an editor saving in a loop and the history being charted all at
once: a report reaches the page in **4.1 ms**, and quiet, **1.4 ms with a
worst case of 2.4**. A motion sensor whose rules fire takes 4.1 ms, a button
2.3 ms, a thermometer 1.4 ms. Nothing failed, nothing was lost, and the
write queue never grew.

3.9.1 — the sweep in 3.9.0 covered the Settings card; this one covers the
rest. Every control on every tab was walked — five and a half thousand of
them, eighty-two of which are settings — and two disagreed with what the
daemon says: the word the modem must send with a forwarded message was shown
on screen rather than hidden, and how often to look for messages was a list on
one card and a number everywhere else. Both agree now, and the numbers people
type phone numbers into ask for a keypad rather than a keyboard.
`test/inputs.py` refuses a release where the page draws a different kind of
box from the one the daemon declares.

3.9.0 — a walk through every box on the page, asking of each whether it is
the right kind of box.

The Settings card kept its own hand-written list of which settings were
yes-or-no questions, and the list had fallen behind: **weather** and
**preheat** were drawn as number boxes wanting a 1 or a 0. The daemon says
what kind each setting is now — a switch, a number, a decimal, words, a
clock, a password, or a fixed set — and the page draws what it is told, so a
setting added tomorrow gets the right box without anyone remembering to say
so. All fifty-seven shown were checked against what the daemon says, and all
fifty-seven agree.

**digest_at** is a clock rather than four characters to mistype, the four
settings with a fixed set of answers are lists, and the four that hold a
secret are not shown on screen. In the editors, the second and third
condition of a rule take a number the way the first always did, a phone
number asks for a phone keypad, and a picture's address asks for an address.

3.8.1 — a place could not be typed into the box asking for one. The Settings
page guessed what kind of box each setting wanted from the look of its name —
anything not obviously words got a number box — so *weather_place* and
anything else added since would take digits and nothing else. The daemon says
what kind each one is now, since it is the one that checks them, and the page
puts up what it is told: words, a number, a decimal, a time or a password.

3.8.0 — the gateway and its modem are words of their own, the way `shelly`
and `gateway` already were: **`zigmon sms`** and **`zigmon modem`**, each
with its own `--help` listing what can be asked for and half a dozen worked
examples. `--sms` and `--modem` still work, so nothing written down
elsewhere breaks.

The main `--help` gained the two, and a short list of the things worth asking
when something is not behaving — what would happen, why a socket is not
answering, which batteries are sinking. On a terminal the commands are picked
out in colour from the words about them, and piped anywhere else it is plain
text as before.

3.7.0 — the forecast card said one number. It says the sky now: **🌦️ light
rain**, **☀️ clear**, **🌙 clear** at night — the picture follows the hour, so
the same clear sky is a sun by day and a moon after dark — with what it feels
like, the humidity, the pressure, the cloud, the wind and where it is from,
the rain falling now and the rain expected today, the warmest and coldest of
the day, the sunrise and the sunset, and the next twenty-four hours' high and
low. Twenty-eight weather codes are given words and a picture; anything else
is honest about not knowing.

**weather_place** puts the name of the place under the card's own name — the
reading still follows `latitude` and `longitude`, so the words are only what
to call it. Every figure is a reading like any other, so History charts the
pressure falling and a rule can watch for rain.

3.6.1 — **Data received** and **Data sent** moved to the front of the
gateway's card, where the signal and the network are, since on a SIM that is
usually the number one wants. They can be started again from zero: the modem
counts from the moment it connected and cannot be told otherwise, so the
counting is done from a mark of our own — **Data counters back to zero** on
the card, or `zigmon --modem reset`. What the modem itself has carried stays
beside them as *Received since it connected*, and a modem that has restarted
moves the mark rather than showing a negative.

3.6.0 — everything the modem's own status page shows, read the same way, and
a command to read it with.

Fourteen more readings joined the gateway's card: the provider and how it is
registered, the network type as the modem words it, the bandwidth, whether
carrier aggregation is up, the signal quality as a percentage, the physical
cell and EARFCN, how many SIM slots there are and which is active, the
country and network codes taken from the IMSI — the first five digits, since
the rest identifies a subscriber and has no business in a database — the eSIM
profile, how many MIMO antennas, and whether the modem is busy. The per-band
table comes from `/modems/signal/status`, so a 4G carrier's own RSSI, RSRP,
RSRQ and SINR are read per band rather than as one figure.

**`zigmon --modem`** prints the lot, grouped as the modem's own page groups
it — SIM card, connection, signal, cell, the modem, traffic — and the band
table underneath. `--modem sim`, `signal`, `cell`, `data`, `info` and `bands`
print one part each.

3.5.0 — thirteen more facts, all about the text that arrived and whoever sent
it. A message could say what the number was but not whose it is, so
`{person}` now works in an answer wherever `{sms_from}` does, alongside
`{person_known}`, `{person_home}`, `{person_since}`, `{person_device}`,
`{person_may_command}` and `{person_gets_alerts}`. The text itself gained
`{sms_phrase}` — the words it was matched on — and **`{sms_rest}`**, which is
everything that followed them, so *heating 22* can set a temperature rather
than needing a command per number; with `{sms_first_word}`, `{sms_words}`,
`{sms_length}` and `{sms_number}` beside them. They are worked out in one
place, so an answer, an event and anything the command fires all see the
same thing. Ninety-eight facts now, and `test/facts.py` still says every one
of them is both offered and filled.

3.4.4 — say *home* and then *away* and the house sometimes let you in again a
moment later, running the arrival twice. A claim of being home was honoured
against the controller for half an hour, and a claim of being out was not
honoured at all: it was left to the ordinary rules, where the arrival's own
grace window — *seen a moment ago, so still home* — outlived it and put the
person back. The two are symmetrical now: somebody who has said they are out
stays out until the controller actually sees them again, at which point the
old word is spent and the network has the say, exactly as before. Saying
*away* while still on the Wi-Fi is still refused, as it was. `test/replay.py`
walks the whole sequence and refuses a release that arrives twice.

3.4.3 — the message lists on the command line wrote a moment as `09-10 18:01`,
which says neither the year nor the second and reads back to front for anyone
here. They write `10.09.2026 18:01:12`. `--sms raw` gained a *when* column of
its own, turning the modem's own `Wed Sep 10 18:01:12 2026` into the same
shape, and a heading over the columns.

3.4.2 — leaving was there all along, but nobody could see it. A person as a
target read *Falco being home* and offered *on*, *off* and *toggle*, so
saying "I am out" meant working out that it was *off*. The target reads
*Falco — home or away* now, and its actions are **has arrived**, **has left**
and **the other way round**. Nothing changed underneath: a rule or a text
written before still means what it meant.

3.4.1 — a notification is not switched on, so nothing pointed at one should
offer an action. Rules, bindings, schedules, scenes and presence triggers
already replaced the *Do* column with *sends the message*; the SMS commands
did not, and nor did a step in a sequence. Both do now. And the check for
"is this a notification" had never been told about the roads added in 3.0.0,
so *notify me — text only* and *text Falco* still asked for an action
everywhere; it knows them now. The bin on an SMS command sat off centre,
since a command button keeps room for a label it does not have; it is a
34-pixel square with the icon in the middle of it.

3.4.0 — send the same word twice and the second went missing. The modem
numbers messages by the slot they sit in and gives the slot back when one is
deleted; the second *On* landed in the slot the first had just left, from the
same number and with the same words, and what the daemon remembers about
messages already dealt with matched it exactly — so it was passed over as one
already seen, while the modem still held it. Two things now keep them apart:
the time the message arrived goes into what is remembered, and a message
taken off the modem is forgotten, since nothing can offer it again. Both are
in `test/replay.py`: the same text sent twice must be acted on twice.

3.3.9 — a text arrived, the events said *did "on"*, the answer went back, and
the light did not move. A target has to be worked out before it can be fired —
a name on a card becomes a socket, a group becomes its members — and the SMS
command was handing the name straight to the part that fires, which quietly
did nothing with it. It is worked out first now, and if the target turns out
to be switched off or gone, the events say so instead of claiming success.
The dashboard's own call had the same fault for a scene, a sequence or an
action group; it is fixed too, and `test/replay.py` now sends itself a text
and refuses the release unless something actually switches.

3.3.8 — the bin on an SMS command was the width of a name field. The answer
box spans the whole row, and it was being put in before the last two cells,
which pushed them onto a row of their own where the bin took a column meant
for a phrase and stretched across it. The answer goes in last, where it
belongs, and the bin keeps its own 34 pixels at the end of the row.

3.3.7 — three on the SMS card. The folds stopped opening after any change and
would not work again until the page was reloaded: the card refuses to rebuild
itself while there are unsaved changes, so as not to throw away half-typed
text, and the fold was asking for a rebuild; it opens and closes itself now,
which changes nothing but what is on show. The blue highlight over a person's
row was chopped into four because an outline was being drawn round every
cell — a leftover from when every editable row on the page was given a hover
outline; the row gets it now. And the switches lost the box 3.3.6 put round
them; the word beside them stays.

3.3.6 — the switches on the SMS card were the right size all along; what was
wrong is that they floated bare in a band while every field beside them sat
in a bordered box, so the eye read them as the wrong shape. Each now sits in
a box of the same height, edge and corner as its neighbours, with the word
*on* or *off* next to it, and the whole box is the thing you click.

3.3.5 — two more on that card. The row under the pointer was lit by giving
each of its four cells the same background, and the joins showed; a row is a
row of its own now, sharing one column template with the heading, so the
highlight is a single band the whole way across. And the two boxes for
numbers that belong to nobody sat at different heights, because their labels
are of different lengths and they were the only pair on the card not sharing
the three bands the rest do; they share them now.

3.3.4 — the SMS card's switches were the small ones, which beside a
full-height box read as a dot rather than a switch. They are the same
44 by 26 as every other switch on the page.

3.3.3 — the whole Settings card had gone wrong, not only the SMS one. The
three-band rule written for the SMS settings in 3.2.1 was applied to every
settings grid on the page, and in a grid a box keeps its own width and sits
where it likes; so every label and every box in Settings, Wi-Fi and Heating
drifted to the right of its column. The rule applies to the SMS card alone
now and says what fills its one column; everywhere else an item is a label
over a box, hard left, the box the full width of its column, the way it was.

3.3.2 — all thirty-five readings were being kept, but a card shows the four
that matter most and the modem's card was showing three of them. It shows
eight: the signal, the network and band, the operator, the SIM, whether it is
connected, how many messages are sitting in it, and how many went out today.
The other twenty-seven are where every device's are — the readings popup on
the card, the All values tab, and History.

3.3.1 — the people table's cells kept a rounded corner each, so the row under
the pointer lit up as four boxes with the blue cut between them; the cells
carry no rounding, border or background of their own now and the row is one
band. And half the settings were saying the same words twice — the grey text
in the empty box and the note under it were the same sentence, which read as
a stutter. A note that only repeats its own box is left out, though the band
it would sit in is kept, so the boxes stay level down the row.

3.3.0 — the gateway's card was showing eight of the thirty-five things the
modem says about itself. It says them all now: the four signal figures and
Ec/Io, RSCP and the quality percentage beside them; the operator, the
provider, whether it is registered and with whom; the band, the cell, the
area and tracking codes; the SIM's state, which SIM is active, the last four
of its number, whether a PIN is set and how many tries are left; VoLTE, the
external aerial, the modem's own firmware and temperature, the message
centre; the bytes each way since it connected; and what the house itself has
done — sent and received today, how many are waiting to go, how many are
sitting in the modem's inbox, and how many commands it is listening for.

Each is a reading like any other, so History charts the signal against the
day, a rule can watch the band changing or the temperature climbing, and an
alert can quote any of it.

3.2.1 — yesterday's regrouping read badly. Three things were wrong with it.
A setting with a note under it sat lower than its neighbours, because each
item was a column of its own and only its own contents decided where the box
went; the items share three bands now — label, control, note — so a two-line
label no longer drags its own box below the others, and every item keeps its
third band even when it has nothing to say. A dropdown cannot wrap, so the
long explanations that were inside the choices are under them instead, and
the choices themselves are short enough to read. And the people table drew a
box around every cell, which came out as a row of separate boxes with gaps
between them; it is one table now, with a line between rows, a heading band,
and rounded corners only where the table itself ends.

3.2.0 — the SMS gateway's settings were thirty boxes in one heap, several of
them asking to be typed a word into and answering only to three. They are
five folds now, in the order somebody setting one up meets them: **the
gateway itself** and **messages in and out** open, and **instant delivery**,
**when things go wrong** and **rarely needed** folded away, since a working
TRB140 wants nothing from the last three. Anything with a fixed set of
answers is a list rather than a box — which interface, how often to look,
what to do about a stranger's text, where to ask the modem about itself, how
to write a number — each choice saying what it means rather than naming a
value. The two boxes for numbers that belong to nobody moved down beside the
people they add to, where the confusion about how they combine was.

3.1.9 — the time sat across the message on the SMS tab. When the settings
table was given a name of its own in 2.99.4, the rename caught a line it had
no business with, and the sender's cell on this tab became a four-column
table: the name and the time were laid out side by side and the time ran into
the bubble. The name stands over the time again.

3.1.8 — a text from a number nobody knows was being forwarded to the house's
own phone, at the house's own expense. The daemon says so when a stranger
writes, which is right; what was wrong is that saying so went out by every
road including SMS, so an operator's notice or a bank's code arrived twice —
once from the operator, once from the house. It is said through ntfy and
Telegram now and not by text. `sms_stranger_alert` chooses: `event` (only
written down), `notify` (the default), or `sms` for anyone who does want it
forwarded.

An alert about a message will also never be texted to the number the message
came from, whatever the settings say — that was one wrong tick away from two
phones texting each other all night.

3.1.7 — three things about incoming messages.

**The wait.** The inbox was looked at on the heating's half-minute, so a
setting of every fifteen seconds still waited thirty, and sixty could take
ninety. It keeps its own rhythm now, on its own thread, and the default is
fifteen seconds. For a message that arrives the instant it is sent, give
`sms_push_secret` a word and paste the address into the modem's *SMS
forwarding to HTTP*.

**A message taken for an old one.** The device numbers messages by storage
slot and gives the slot back when one is deleted, so message 2 could be a new
message in an old number's clothing and be passed over. What is remembered is
the slot, the sender and the opening of the text together.

**Half a message.** The command line cut every text at sixty-odd characters,
which is a third of an SMS. `--sms inbox`, `--sms outbox` and `--sms raw`
print the whole thing, wrapped under itself to the width of the terminal.

3.1.6 — the messages still did not show. Yesterday's fix wrote down the ones
found on a first look, but by then they had already been marked as seen by
the run before, so the poll passed over them without a word — and would have
for ever. A message the device lists is written down if the log does not
already hold it, whether or not it is to be acted on; the device's own id is
kept beside it so it is written once and no more.

And the words were misleading, as you said. **`--sms inbox`** is now what
came in and **`--sms outbox`** what went out — the two halves of the
conversation. What has not managed to go yet is **`--sms waiting`**, and what
the device itself is holding is **`--sms raw`**. `--sms all` shows both
directions together.

3.1.5 — the two messages the daemon found and left alone never reached the
SMS tab: what came in was written to the log inside the part that acts on a
message, and the leave-it-alone path returned before that. They are kept and
shown now, marked *was already here*, so the tab shows the whole
conversation while still not carrying out yesterday's texts.

3.1.4 — messages went out but none ever came in. The listing was filtered to
messages the device called *unread*, and a TRB marks a message read the
moment it stores it — so the filter threw away every one. Every message the
device lists is taken now; what stops one being acted on twice is the list of
ones already seen, which outlives a restart, and taking them off the device
afterwards. Whatever was already sitting in the inbox the first time the
daemon looks is remembered and left alone, with an event saying how many, so
an upgrade does not carry out a week of old texts.

Two more: `zigmon --sms inbox` asked for a path that does not exist, and
there was no way to see what the device itself says. **`zigmon --sms raw`**
prints the device's own listing — id, sender, status, text — so *"it says it
has none"* can be told apart from *"we are throwing them away"*, and it
points at the SMS storage setting when the list really is empty.

3.1.3 — *Gets alerts* and *May command* could not be saved: the save used
`people-save`, which is the id of a button on another page, not the path the
relay serves — so it answered *unknown endpoint* and the two ticks never
went anywhere. It uses `people` now. `test/endpoints.py` gained a check that
every name the page calls is one the relay actually serves, since that is the
whole shape of this mistake; it says how many it checked (ninety-one today)
and refuses a release where one is missing.

3.1.2 — `zigmon --check-sms` walks the whole road to the gateway and says,
step by step, what is well and what is not: the settings, whether the device
answers and lets us in, the SIM, the signal, whether the modem is registered,
who would be told, who may command, whether there is anything a text may do,
whether incoming messages would be noticed at all, and whether anything is
stuck in the outbox. Whatever fails is turned into a line saying what to do
about it — a wrong password, a locked SIM, an aerial that wants moving.

It also found a fault of its own: four of the seven ways the daemon talks to
the gateway — the whole older interface and the bus — were opening plain
connections and ignoring the certificate setting, so any of them over HTTPS
(which RutOS now enforces) would have failed. Every request goes through one
door now.

3.1.1 — a walk through the SMS settings, asking of each whether it earns its
place. `sms_delete_path` was read by nothing at all, and behind it was a real
fault: a message that had been acted on was never taken off the device, and
the list of ones already seen lived only in memory — so a restart would carry
out every command still sitting in the inbox, again. They are removed now
(`/messages/actions/remove_messages`, or the cgi path for the older
interface), and the ones seen are kept in the database. `sms_clear_inbox`
turns that off for anyone who would rather keep them on the modem.

`sms_status_via: auto` used to try a bus a TRB140 does not run, costing a
timeout on every poll; auto now means *the same interface as everything
else*. And three settings the daemon reads were never shown on the page —
the modem's name among the devices, and the status and delete paths for the
older interface — while `sms_number_format` now says plainly that it applies
to that interface only, since the device's own API always wants `+420…`.
Twenty-nine settings, every one of them offered and every one of them read.

3.1.0 — the SMS gateway is rewritten against the TRB140's own API
description, because what was there could not have worked on a device in its
factory state. Five things were wrong. It defaulted to the older *Post/Get*
query interface, which is switched off until somebody turns it on under
Services — a new device answers only the REST API, so that is the default
now. Sending left out **modem**, which is required even when the device has
one, and the device answered with a bare complaint; the modem is asked for
once and remembered, or named in the settings. Numbers went out as
`00420...`, while the API insists on `+420...`. The inbox was read from
`/api/messages`, which does not exist — it is `/api/messages/status`, and
messages already marked read are passed over. And the token was kept for
twenty-five minutes when the device gives five, so everything worked once
and then quietly stopped; it is renewed a minute before it lapses and a
refusal makes it log in again. HTTPS with the device's self-signed
certificate is accepted unless `sms_verify_cert` says otherwise.

The modem's readings now come from the fields the device actually uses —
signal, operator, network, SIM state, cell, its own temperature and the bytes
each way — with RSRP, RSRQ and SINR from `/api/modems/signal/status`.

`test/mocksms.py` speaks that API too, with the same rules enforced, so the
whole path can be tried without a SIM card. Doing so turned up one more
thing: on a database that had been sitting a while, the quiet-device watchdog
sent twenty-two texts at once. More than `quiet_at_once` (three) going quiet
together is now one message that names them — a dozen at once is a radio or a
broker, not a dozen flat batteries.

3.0.3 — eighteenth pass, on the ninth of September's database. One figure
stood out: the battery health walks a month of history for every cell that
has one, 20 to 26 ms, and the page asks for it every five minutes; the answer
is kept for those five minutes now, so a second look costs nothing. Nothing
else was over eight milliseconds. Twenty-one hot paths were timed, every read
the page can make was tried (none failed, none over 60 ms), and all twelve
editors were handed four kinds of nonsense each — a string, a number, an
object and nothing at all — and refused every one of them with the rules,
bindings, scenes, rooms and messages left exactly as they were. Under a
storm of a hundred and ten messages a second with two pages polling and
searching, a report still reaches the page in 3.8 ms; quiet, it is 1.5 ms
with a worst case of 3.0.

3.0.2 — the box times were still large because the fix that was meant to cure
them had never once run. Asking a box for a reading of all its sockets can
fail, and when it did the daemon quietly asked each socket on its own
instead — which is exactly the old behaviour, and nothing said so. It says so
now, once per box, and the test gateway that was refusing those readings
(mine, not yours) is mended, so the saving can be measured: a round over four
sockets on one box went from **eleven seconds to four, and to nothing at all
once the box has been learnt** — one request where there were four.

*Where the time goes* now separates the two halves of a slow poll: the figure
is the box's own answer, and any wait in the queue is written beside it as
*(+950 ms in the queue)*. A large number there is our own pacing; a large
number in front of it is the box.

3.0.1 — the message card said nobody had a number when somebody did: under
Presence a person's number is called `number`, while `phone` there means what
their phone last said about being home, and the card was reading the wrong
one. The same slip hid the *text Falco* target. Both read the right field now.

And the chips are gone in favour of one box that takes both: start typing a
name and the people who have a number are offered with it, press Ctrl+Space
to see them all, or type a number straight in and it stands as it is. Several
are separated by commas, and a name is looked up when the message goes out —
so changing somebody's number changes it everywhere at once.

3.0.0 — a message says which way it travels. Three switches on its card —
**ntfy**, **Telegram**, **SMS** — each on by default, because switching one
off should be a deliberate act. Turn SMS on and a panel appears underneath:
**anybody with a number** in one switch, the people who have one as chips to
tick, and a box for numbers that belong to nobody. Nothing is typed twice —
the people are ticked, the free numbers are typed, and the two are kept
apart.

The automatic text gained the same choice as targets, so a rule or a button
can take one road without a written message at all: 🔔 *notify me — ntfy
only*, *— Telegram only*, *— text only*, and 🔔 *text Falco* for each person
with a number. They sit under Notifications in every target list, sorted and
grouped like the rest.

2.99.6 — the red numbers under *Where the time goes* were mostly our own
doing. Requests to one box are spaced a second apart on purpose, because a
Shelly answers 429 when it is hurried — and a box with four sockets was
asked four separate times, so the fourth socket waited three seconds and
reported that wait as its own. One `Shelly.GetStatus` carries every socket
on the box, so a box is now asked once a round and its sockets read their
part of that answer: **four requests become one**, and the whole-box section
that the slow poll wanted anyway comes with it, so that request is saved
too. The figure's explanation now says plainly that a second or two there is
the pacing rather than the box, and that a press does not wait in that queue.

2.99.5 — seventeenth latency pass, on the database of the ninth of
September (1.4 million samples, 57 devices, 22 rules). One thing found: the
day's SMS count was worked out inside every status, by walking a thousand
events — a third of the build. It is counted once and kept, and a message
going out adds one: **status 5.6 ms to 3.1 ms**. A report reaches the page in
1.6 ms median and 2.4 ms at worst when the house is quiet; 2.6 ms median
under seventy-five messages a second with a page polling and searching
beside it. Every read the page can make and every hostile save the editors
could send were tried against that database: nothing failed, nothing was
wiped. And the two switches in *Who it involves* had been reshaped by the
table cell they sat in; they sit in cells of their own now and keep their
shape.

2.99.4 — *Who it involves* was broken by a name, not by a layout: two
different things were both called `sms-people` — this table and the row of
recipient chips on the SMS tab — and the chips' `display: flex`, being later
in the stylesheet, won. Yesterday's fix made it worse rather than better,
because the grid it set was overruled a hundred lines further down. The table
has a name of its own now, and a check refuses a release where two class
names disagree about how they are laid out.

2.99.3 — a gateway's model and firmware sit on a line of their own under its
row, and the hover outline was drawn around the row alone, so it cut straight
across them. The whole card lights up now, the way a rule's does, and the
line beneath has the room it needs.

2.99.2 — three things that looked wrong. The rooms list is a grid now, so the
count and the bin line up down the column however long a room's name is. The
*Who it involves* table put its heading over one grid and its people over
another, each sized to its own contents, which is why they did not line up;
the rows take part in the table's own grid now. And a row lights up under the
pointer wherever one can be edited — bindings, rules, scenes, schedules,
groups, SMS commands, people, rooms, messages, gateways, backups — with the
same outline a device card has always had.

2.99.1 — a row's own menu, and a command line that keeps up with the
dashboard.

**Right-click a row** in any editor and, above *Move to*, it now offers
**add a new one above or below** and **copy this one above or below**. The
copy keeps everything but the identity, so it saves as a new row rather than
overwriting the one it came from, and its name gets *(copy)* so two rows are
never confused. Both work in every editor that has sections.

**New commands**, in the same colours as the rest:

    zigmon --sms                     what the modem says: signal, operator, SIM, data used
    zigmon --sms inbox               read the gateway now and print what came in
    zigmon --sms outbox              what is waiting to go, and why
    zigmon --sms flush               offer the waiting ones again
    zigmon --sms send --number +420777123456 --text hello there
    zigmon --sms test --number +420777123456
    zigmon --what-if PIR-Chodba occupancy 1     which rules would fire, and why the others would not
    zigmon --diagnose Plug-WorkshopPC           why a socket is not answering, step by step
    zigmon --battery                            which cells are sinking, and how long they have
    zigmon --weather                            what it will be outside
    zigmon --switch Light-Chodba off            switch anything the dashboard can
    zigmon --switch heat:room:r092361 set:eco
    zigmon --targets                            every name --switch will take

The ones that change something take `--pin`, or use the one in the
configuration.


2.99.0 — six at once, all of them settings in Control.

**An outbox for SMS.** A message the gateway would not take is kept and
offered again on the slow beat, so an alert is not lost while the box is
away; *Messages waiting to go* shows what is queued, with *Try them now* and
a bin. It is given up on after `sms_queue_hours`, and `sms_daily_cap` puts a
ceiling on a day's messages — a runaway rule cannot spend a tariff.

**What would happen.** Pick a device, a reading and a value, and the page
says which rules would fire and, for the ones that would not, exactly what
stands in the way — the condition, the edge, the cooldown, the must-hold, the
clock window, the presence gate or the rule being switched off. Nothing is
switched.

**Start early.** With `preheat` on, a room learns from its own history how
fast it heats (the best rise in a fortnight) and begins early enough to be at
the plan's temperature when the plan gets there, rather than an hour later. A
cold night stretches the head start, `preheat_max_min` caps it, and
`preheat_default_rate` stands in until the house has taught us better.

**The weather.** One call an hour to open-meteo, which wants no account and
no key, using the latitude and longitude already set for sunrise. It becomes
a device of its own with the temperature outside, the wind and the day's high
and low — charted like anything else, quotable in a message, and used by the
head start above.

**Why is it not working?** Right-click a socket that is misbehaving and the
daemon walks the chain in the order the answer usually lies: does the box
answer on the network, does it speak Shelly RPC, does it take the password,
does the broker carry its commands, does the ACL allow them. It names the
first thing that fails.

**Batteries.** What each cell is at, how fast it is falling per week and
roughly how many days it has left, worked out from a month of its own
history rather than from the percentage alone.


2.98.0 — everything worth having from the gateway's own documentation: it
pushes an incoming message to us instead of being asked every minute, the
modem is questioned over `ubus` (signal, operator, SIM, cell, roaming,
temperature and the SIM's data for the month and the day), numbers go out in
the 00-prefixed form Teltonika asks for, a message can go to a group the
gateway knows, and *Test* reports what it found rather than only that it
answered. The reply an SMS command sends back is now written in a proper box
of its own line — the same shape, tools and preview the alert editor has,
rather than squeezed into a table column — and a sweep of every tab found
twelve buttons still without an icon and gave them one.

2.97.2 — sixteenth latency pass, and it found a bug rather than a delay:
👤 *somebody being home* worked from a button, a rule and a text message but
not from the dashboard's own target call, which answered *unknown target* —
the right-click on a person had nothing behind it. Two milliseconds now.
Everything else measured again on the production database with the SMS
gateway running: a report reaches the page in **1.6 ms median, 2.4 ms at
worst** when the house is quiet and 2.0 ms median (12.9 ms worst) under sixty
messages a second with a page polling and searching beside it; an SMS command
end to end, reply included, 2 ms; reading the gateway's inbox 1 ms; saving
the heating 3 ms; and the whole of message_facts, now eighty-five of them,
0.66 ms.

2.97.1 — a sweep for bugs rather than for looks. A phone number that was
typed but made no sense was quietly saved as nothing at all; it is refused
now, with the words back. The page's device signature reached for a
`parents` table the daemon has never sent, so a card would not repaint when
its route through the mesh changed — it uses the device's own `via`, which
was there all along. And `sms_timeout_s` was read in six places without
being a setting anywhere; it is one now, adjustable like the rest. Nothing
else turned up: no id used before it exists, none duplicated, no icon name
without an icon, no editor saving without its guard, no meta key written and
never read, and every hostile payload the new endpoints were given came back
as a refusal rather than a wipe.

2.97.0 — the version was wrong. From 2.90 onwards the number inside the
release was never changed: the line that sets it had moved, the replacement
matched nothing, and every package since carried **2.89.8** however it was
named. The work itself all shipped — the sensor groups, action groups, the
SMS gateway and everything after — but nobody could tell one release from
the next. `test/version.py` now refuses a release whose three statements of
the version disagree, and this one is the first correct number since. If a
dashboard shows 2.89.8 in its footer, it wants this package.

Since 2.89.8, in order: a third condition in a rule, away with dates, the
month's electricity in money, watchdogs for quiet devices and an unsettled
mesh, a version kept before every Save, route history, Ctrl+K, MQTT-only
switching and a debug mode, a real search over every event, sensor groups
with filters, action groups, one summary of the day, the heating's
**by hand on the head** and its opposite, an SMS gateway that sends alerts
and takes commands, people with phone numbers, presence as a target, the
gateway as a device of its own, and eighty-five facts a message may quote.


2.89.8 — a sweep for bugs rather than for looks, on the production data.
Nothing broken was found: every endpoint the page calls is relayed and
answers, no element id is missing or repeated, every icon name resolves,
every advertised target validates and has a label, no rule, binding, scene,
schedule or room points at something that no longer exists, and bad input
(a nonsense operator, a scene running itself, a target that is gone, the
wrong PIN, a percent sign in the search) is refused with a sentence rather
than a stack trace. One piece of dead weight went: the shared-broker-password
endpoint, unused since each box got its own account in 2.87.0.

2.89.7 — the schedule's clock takes the room it needs (it grows with the
column rather than sitting at a fixed narrow width, and the sunrise offset
only appears when sunrise or sunset is chosen), the when-box says in a
tooltip what it accepts, and hovering a socket's On/Off button on the Smart
Plugs list shows what that socket is drawing.

2.89.6 — seven bits of text showed their escape codes rather than their
characters (the search dialog's hint, the away-dates tooltip, the note above
the kept versions and a few dashes and ellipses): an escape means nothing in
markup, only in a script. All seven are real characters now, and a walk over
every tab confirms nothing else is showing one.

2.89.5 — kept versions can be forgotten: a bin on each row, and *Throw them
all away* under the list. Neither touches the settings in force.

2.89.4 — a scene's action list was the short one: sockets, Zigbee switches
and heating only. It now offers everything a button does — all plugs at
once, sequences, notifications and messages, and switching a rule, schedule
or binding section on and off — everything bar running another scene.

2.89.3 — the schedule's clock is wide enough to read (118 px, and the row
gives that column the space), and the popup that says what something is
doing now follows the **Do** column as well as the target column, in
bindings, rules, scenes, sequences and schedules. Where the target is not a
device it says so in words instead: a scene lists what it switches, a room
gives its temperature and what it is holding, and a rule, a schedule or a
section of bindings says whether it is on.

2.89.2 — *What is in them* under Rooms shows each device's whole name on its
own line above its room picker, in even tiles, so a long name is neither cut
short nor squeezing anything; the energy-summary rooms are the same folds
the editors use, one per line, with the sockets inside laid out in a steady
grid rather than chips that reflow as they open; and a message starts eight
lines tall and can be dragged taller.

2.89.1 — the hover popup that says what a device last reported now follows
the target pickers too, in rules, bindings, schedules and scenes: hovering
over what a row switches shows what that thing is doing. Right-click gained
two more homes — a socket's line (its history, a rule from it, its own web
page, its name or address to copy) and a room's heating card (comfort, eco,
off, back to the plan, and the history of its thermometer).

2.89.0 — the target lists are grouped (Sockets and lights, Zigbee switches,
Heating, Scenes, Sequences, Notifications, Automation on and off) instead of
one hundred-line list, and they gained the automation itself: a rule, a
schedule or a section of bindings can be switched on, off or toggled by a
button, a rule, a scene or a schedule. A right-click on a device card offers
its history, all its values, its name or address to copy, and a new rule
from it. The message box starts six lines tall, the per-device notification
choices and the energy-summary buttons fold like the sockets do (the latter
grouped by room), a long device name no longer squeezes its room picker,
the schedule's time box fits *sunset+30*, and a scene's Run and Remove stay
clear of its actions.

2.88.5 — thirteenth pass, under a storm this time: forty-seven Zigbee
reports a second for fifteen seconds, with a dashboard polling beside it.
A report still reaches the page in **1.1 ms median, 1.4 ms at the 95th, 16
ms at worst**; the status endpoint slows from 5 ms to 13 ms while that is
going on and settles again afterwards, which is the right way round —
what a person waits for stays fast, the poll gives way. The message path
itself costs 0.09 ms end to end (one row written, one wake-up), and the
write queue never grew. One editor on the Control tab had escaped the
per-section rendering added in 2.88.4 and was still built whichever section
was open; it is gated now, so every section builds only its own.

2.88.4 — twelfth latency pass, and the first one where the browser was the
slow part rather than the daemon. Opening Control built every editor in
every section, visible or not: twenty rules, two dozen sockets, the scenes,
the settings, all of it. Only the section on screen is built now, and the
others are marked as owing a repaint and get one the moment they are shown —
Control opens in about a fifth of what it took. Two lists that every editor
row rebuilt from scratch (the sorted devices and every target in the house)
are worked out once per pass, and the option markup for a list is kept
against the list itself. On the daemon side nothing was found to be slow:
status 4.9 ms on the production database, the new watchdogs, snapshots,
money and event search all under a third of a millisecond, saves 2–4 ms,
wake-ups 1.3 ms median and 2.1 ms worst — 1.4 ms median with a busy
dashboard searching events beside it.

2.88.3 — a pass over the interface itself, tab by tab: ten buttons that had
a label and no icon now carry one (Put back, Add section, + step, Fold every
socket, Fold every group, Make a new token and the rest), nine that had
neither tooltip nor hint now say what they do, three classes used in the
page had no style rule, and two notices pointed at config.json for something
that has been in Settings for a while. Nothing behavioural: every button
was already gated correctly, no id was missing or duplicated, and no call
the page makes goes unrelayed.

2.88.2 — the search box on Events searches **every event ever recorded**,
not the five hundred on the page: the daemon does it in SQL, case does not
matter, several words all have to appear in any order, and it combines with
the kind and level pickers. The count says what it found against the whole
table — *852 of 8 981 recorded* — and new events keep the filter as they
arrive. Searching ten thousand events takes 7–40 ms.

2.88.1 — **MQTT only** in the settings stops the HTTP fallback for boxes set
up for MQTT (off by default, so nothing changes until it is asked for), every
switch now says which road it took in the event and the log, and **Debug**
writes every command and every MQTT message to the log and, if wanted, to
Events.

2.88.0 — eight things at once, all measured on the production database: a
third condition in a rule; away with dates; the month's electricity in
money on the Overview; a watchdog for devices that go quiet and for a mesh
that keeps losing them; a version kept before every Save, with *Put back*;
which router each device reaches the mesh through, over time; and Ctrl+K to
find anything. Everything they need is in Control → System.

2.87.1 — eleventh latency pass. A command over MQTT no longer waits for the
box to answer before returning: a click reaches the wire in 1.9 ms and the
API call is back in 3 ms, where waiting for the echo had put a second and a
half in between; the answer is still checked in the background and HTTP
still takes over when it never comes. Everything else measured again on the
production database — a report reaches the page in 1.6 ms median, 2.8 ms
worst, under four reports a second with rules, heating and polls live.

2.87.0 — the broker user and password on a box's MQTT strip are that box's
own, kept with it and never shared: *(kept)* now means this box has one,
the bin clears this box's, and the values in config.json are only the
fallback for a box without any.

2.86.6 — forgetting the kept broker password works: the web relay had no
entry for the call, so it came back as *unknown endpoint*. The guard that
checks every call the page makes against the relay's list now covers the
ones fetched as well as the ones posted.

2.86.5 — the kept broker password says where it is kept (config.json or this
dashboard) in the field's tooltip, and one kept here can be forgotten with
the bin beside it; the field also tells a browser's password manager to
leave it alone, which is what filled it in unasked.

2.86.4 — the broker password typed into a box's MQTT strip is kept, so the
field reads **(kept)** afterwards and the next box needs only the button;
before, *(kept)* appeared only if `plug_mqtt_password` had been put in
config.json by hand.

2.86.3 — when the ACL file cannot be read (mosquitto keeps it at 0600), the
check and the card say so as a note and print the one command that grants
the read; the installer now asks for it while it is setting the broker
account up.

2.86.2 — *Test MQTT* now says which of the three links failed: it listens to
the command topic while it asks, so a message the broker dropped is told
apart from a box that stayed quiet, and the ACL line that explains it is
named.

2.86.1 — the broker password on the MQTT strip reads **(kept)** when one is
already stored, the same as every other password field on the page.

2.86.0 — the broker's ACL is checked against what is actually set up:
Control → System → *What the broker must allow* ticks each topic in use
against `/etc/mosquitto/acl` and prints the missing lines as a block to
paste; `zigmon --check` does the same on the command line.

2.85.1 — the client id really is the box's name now: it is read from the box
itself (`Shelly.GetDeviceInfo`) when the page sends none, and since a Shelly
quietly keeps its old client id while MQTT is enabled, the value is read
back and — if it did not stick — written with MQTT off and switched on
again. The reply says so when a box refuses it anyway.

2.85.0 — a command over MQTT is only done when the box answers. A publish
the broker's ACL forbids is dropped silently and used to look like success;
now the answer on `zigmon/rpc` is waited for, HTTP takes over when it does
not come, and the log says which of the three things to check. **Test MQTT**
on the strip does the same on demand and names what is wrong.

2.84.4 — *Set the box up* also writes the box's **client id** as its name
(*Plug-TST* rather than *shellyplugsg3-…*), so the broker's log and its
connected-clients list read; and a box has one MQTT prefix, edited in the
MQTT strip — the channel row shows it read-only, since the two were the
same field shown twice.

2.84.3 — the MQTT switch on a box was not part of what Save devices sent,
so it was lost on save; it is kept now, with the prefix, and comes back
switched on after a reload.

2.84.2 — one broker account for every box: `plug_mqtt_user` /
`plug_mqtt_password` (*plug*) and `plug_mqtt_root` (*shellies*) in
config.json; the MQTT strip is pre-filled with them and suggests
`shellies/<name>` as the prefix, and *Set the box up* uses the shared
password when the field is blank. The README carries the ACL block that
covers every box at once.

2.84.1 — *Set the box up* works: it uses the box password the daemon already
holds rather than asking the page for it, and offers the box's own
connection types — TLS without validation (pre-filled when the broker is
TLS), TLS with the box's CA, or plain — with the port following the choice.

2.84.0 — commands over MQTT: an MQTT switch and broker fields on every box
under Plugs and sensors, a *Set the box up* that writes the broker into the
box itself, commands as RPC over the broker with HTTP as the fallback, and
two more actions for a box in every Do list — reboot, reset its counters.

2.83.2 — the Smart Plugs card is a list, not a scroll: one line per socket
with its name, state, current draw and small On / Pulse buttons, sorted like
everywhere else, and a fold under each (closed by default) for the box's
details and its counter resets. *Open every socket* / *Fold every socket*
at the top; what you open stays open for the session.

2.83.1 — a scene's Run and Remove are two small icon buttons on one line,
and each action's remove is a single icon at the end of its own line, so a
scene with many actions no longer carries a tall column of buttons.

2.83.0 — sections everywhere they belong, including Messages under Alerts &
energy; a ➕ on each section header adds a new row into that section; a
*Move to* menu on every row (click the handle, or right-click) moves it
between sections without dragging; and a section left empty survives a
save and a reload.

2.82.3 — sections, second round, tested on the production data: dragging a
row into another section without changing its place in the order was not
counted as a change and was thrown away on the next repaint; a managed
device's section was not sent with Save nor read back; the rename button
had no icon; the count sat against the name. All four fixed; a section now
reads *Plugs · 1 item*, and a device dragged into it is still there after
Save and a reload.

2.82.2 — the sections' stylesheet had not made it into the page, so a
section changed state on a click but never actually folded; it folds now.

2.82.1 — naming a section, renaming one, and adding a Wi-Fi device by name
ask in the dashboard's own dialog, not the browser's grey box; Enter
confirms, Escape cancels, and a blank or duplicate name is told so in
place. No browser prompt is left anywhere in the page.

2.82.0 — named sections in the Control editors: bindings, rules, scenes,
sequences, schedules, presence triggers and managed devices can be folded
under names of your own, rows drag between sections, sections drag above
each other, everything starts folded, and it all saves with the editor.

2.81.1 — measured on a production database (a million samples over eight
days, 50 devices, 23 sockets, 21 rules): the daemon builds status in 4 ms,
a chart in 4 ms, the whole Overview's charts in 40 ms, and wakes a page in
under 2 ms under a report a quarter-second - none of that is where a lag
lives. Two things in the data were. Two dozen boxes each pushing new
watts every few seconds woke every open page for each of them, so a page
was pulling a quarter-megabyte of status several times a second and
repainting each time; a number changing now wakes the pages at most twice a
second, together, while a relay, a button or a rule still wakes them at
once (2 ms, measured). And a rule saying "off" every time a sensor cleared
sent the box the same "off" every minute and logged a switch each time -
one box had five thousand of those; a rule's command that the box already
confirms is now no command at all.

2.81.0 — a lag can now be placed: Control → System → *Where the time goes*
and `zigmon --diag` show, live, the daemon's own path, the broker's round
trip, each box's answer time and the Zigbee command-to-echo time, colour
coded. Two things changed on the strength of what that showed: the
network-map scan runs every half hour instead of every five minutes (the
coordinator walks the mesh for seconds during one, and commands wait), and
a field left with the cursor in it pauses the repaint for at most fifteen
seconds instead of indefinitely.

2.80.6 — tenth latency pass, this time under load rather than idle: a scene
switching four sockets of a strip every second, a button press every
second, and four sensor reports a second, all at once. Measured with one
waiter per message so the meter itself cannot fall behind: a report reaches
the dashboard in 1.4 ms median, 2.6 ms worst, over 116 messages — the same
figures as an idle daemon. A button press becomes a switch command in
1.5 ms; a toggle is one round trip to the box (`Switch.Toggle`, no read
first) and the card shows the new state before the box confirms it. The one
change: the clock thread beats every quarter second instead of every half,
so a "must hold for N s" rule fires within 0.25 s of the stretch being long
enough; each beat costs microseconds.

2.80.5 — a scene switches the sockets of one strip in the order its actions
are written, every time, 20 ms apart, instead of in whatever order four
threads happened to run; `plug_command_gap` default is 20 ms (was 50).

2.80.4 — ninth latency pass. A button press reaches the wire as a switch
command in 1.5 ms (median of fifteen, worst 1.8 ms); the knob path is the
one deliberate exception at a quarter-second, so a burst of clicks is one
message. A two-minute soak straight at the daemon with rules, heating and
polls live: wake-ups 1.2 ms median, 2.9 ms worst, no outlier. One thing
found: a dropdown keeps the keyboard focus after a choice, and the repaint
pause introduced in 2.78.5 honoured that focus — so after picking a level on
a card the page stood still until something else was clicked. A choice now
releases the focus, and the repaint with it.

2.80.3 — the explanation under a valve card's controls is a tooltip on the
level line rather than a paragraph taking up half the card.

2.80.2 — *Off* (and an open window) now shuts a valve with the head's own
**off** mode rather than a set point of five, which a head reading the
radiator's own warmth would simply regulate against; the next preset turns
it back on.

2.80.1 — the *Right now* dropdown on a Heating card is gone: the preset
buttons on the line above are the same choice, and two copies of it could
only disagree.

2.80.0 — taking a valve over now also clears `force` (which pins the valve
open or shut regardless of the set point) and asks a TS0601 head for **auto**
rather than **heat**, since on those heads `heat` means heat without
regulating and `auto` means hold the number. A valve that is still forced
says so on its line.

2.79.6 — on a valve's own card the five levels are a dropdown rather than a
row of small buttons, which is what fits on a device card; the Heating tab
keeps them as buttons, where there is room.

2.79.5 — the heating controls carry icons like everything else (🔆 Comfort,
🌿 Eco, 🌙 Night, ⛔ Off, 📅 Plan, ⏱️ for the hold, 🌡️ Match the room), and a
button on a valve line no longer sits against the text beside it.

2.79.4 — a **Close** button beside each valve shuts the room to frost
protection; on a valve that belongs to no room it switches the head off
directly.

2.79.3 — a valve outside any room says on its card that the presets it is
showing are the head's own, and where to put it to get the room's five
instead.

2.79.2 — the Rearrange switch appears only on the tabs whose cards can be
moved, and the Heating cards can now be moved as well; their order is the
rooms' order.

2.79.1 — a valve that belongs to a room shows the room's controls on its own
card — the same slider and the same Comfort / Eco / Night / Off / Plan — in
place of the head's firmware presets, so there is one set of words for
heating everywhere.

2.79.0 — a **Rearrange** switch beside the lock decides whether cards can be
dragged. Off by default, so a slider or a dropdown on a tile can be used
without the tile moving; on, the movable cards are outlined and their
controls step aside.

2.78.5 — an open dropdown, a focused field or a held slider anywhere on the
page now pauses the card repaint until it is let go, instead of being closed
or reset by the next reading.

2.78.4 — the slider is the whole control: the − and + beside it did the
same thing in bigger steps and are gone. Holding any slider now freezes the
repaint until it is let go, so a reading arriving mid-drag no longer
rebuilds the tile under the thumb.

2.78.3 — *Match the room* works: the web relay had no entry for the
calibrate call, so the browser's request never reached the daemon and came
back as *unknown endpoint*.

2.78.2 — a remote's card leads with what was pressed or turned again (a
knob that also reports its cell voltage was showing 3000 mV instead); a
valve's card leads with what it measures, holds and how far it is open, with
its stored settings left in All values; and its target is set with the same
slider the Heating cards use.

2.78.1 — devices are categorised by what they report and carry their own
icon (valve, knob, motion, contact, thermometer); the lists group by that
and sort by name inside. A heating card shows each head's own reading,
valve position, running state, mode and battery, and can set its offset to
match the room's thermometer.

2.78.0 — a self-programmed radiator head (TuYa/Immax TS0601) is put into
manual with away mode cleared before it is driven, so its own weekly
programme stops overwriting what the room asks for; and the temperature on
a Heating card is set with a slider that speaks when it is let go.

2.77.4 — eighth latency pass, over the knob, the room holds and the
presets. Two things fixed. Every heating save — every knob click, every
preset — wiped the memory of what each valve had last been sent, so the next
round re-sent every valve in the house its current number, and sleeping
heads drained a queue of repeats; the memory is kept now and only a changed
wish goes out. And the plug poll started every box's request in the same
instant; the boxes are now asked one after another across the first half of
the round. A knob press over MQTT reaches the dashboard in 8–13 ms
including the room update; a two-minute soak straight at the daemon, with
rules, heating and plug polls live, gave wake-ups of 1.0 ms median and 6.8
ms worst, not one outlier.

2.77.3 — the room's presets are buttons on its card (Comfort, Eco, Night,
Off, Plan), and a heating level target takes **next** to cycle through them
from a single button.

2.77.2 — a room's temperature can be set by hand on its card (−, a number,
+, and for how long: until the plan's next step, or a fixed 1–24 hours);
the same length can be sent with a target as `hold_s`.

2.77.1 — the number a room is holding is labelled on its card with why
(*eco*, *comfort*, *away*), and a hand-set one is shown large in amber with
*by hand until 22:00*, so a knob's effect is seen at a glance.

2.77.0 — a room's temperature is a target: 🔥 *temperature in ⟨room⟩* takes
to / up by / down by, so a knob nudges the room and every valve in it
follows; the nudge holds until the plan's next change of level (or four
hours without a plan), the card says so, and *Back to the plan now* ends it
early.

2.76.2 — a knob on a valve feels like a dial: steps accumulate on what was
last sent, the card updates the moment the knob moves, and a burst of
clicks leaves as one message with the final number instead of a queue the
sleeping head drains one at a time.

2.76.1 — in a binding row the *set to* trio (to/up by/down by, the number,
the unit) borrows the neighbouring pulse-ms column, so the number is a
field rather than a sliver.

2.76.0 — *set to* on a number can step **up by** or **down by** an amount,
so a rotary knob drives a valve's target temperature; hovering a rule's
source, reading or threshold shows the sensor's current values with the
chosen one marked; and a valve's settables are named by what they are
(*Frost protection*, *Heating stop*) rather than a converter's generic
*State*.

2.75.2 — seventh latency pass, over the heating targets, the sequence
steps and everything else since 2.72: nothing in the daemon's hot path
changed shape. A four-minute soak (959 reports, four a second, rules and
heating live): wake-up 1.5 ms median, 2.2 ms p99, no outlier; the same
again ran without a single error. One thing tightened: the process's RSS
crept up a few MB per hour of heavy dashboard use, and tracemalloc showed
nothing held — it was glibc handing every request thread its own malloc
arena. The unit now caps arenas at two.

2.75.1 — a sequence's reset takes the same choices as a step: a scene, or
any single target with an action.

2.75.0 — a sequence step can be any single target with an action — a plug,
a light, a valve's target, a room's heating level — not only a scene. A
scene is still the way to do several things in one step.

2.74.2 — heating control per room: a switch on the room's card, and a
*heating control in ⟨room⟩* target (on / off / toggle) everywhere a target
is chosen.

2.74.1 — a room can be marked as not heated: its card folds to the title,
nothing is sent for it, and it is not offered as a heating target.

2.74.0 — heating is a target everywhere: *heating control* and *away mode*
switch on/off/toggle, a room's level is set to plan / comfort / eco /
night / off, from any binding, rule, scene, schedule or presence trigger.
And a room can be told which of its door and window sensors count as
windows.

2.73.0 — each room on the Heating tab can be told which thermometer to read,
for a room that has none of its own or has several.

2.72.0 — sixth latency pass, over everything added since the last one
(rooms, heating, the phone reports, the ntfy listener, the rule workers,
the reorderable editors, the QR encoder). Two things found. The ntfy
listener read its stream with no timeout, so a link that died quietly would
have left it waiting forever; it now reconnects after two minutes of
silence, since ntfy keeps the line alive every forty-five seconds. And every
draggable row registered its own mouse-up listener on the document each
time an editor was repainted, which grew without bound over a long session;
there is one now. Measured on the real database: status 1.9 ms, the
heating state 0.2 ms, a two-minute soak at four reports a second with
wake-ups of 1.3 ms median and 3.3 ms worst, no outlier, memory flat.

2.71.6 — on a Heating card, the *stop for an open window* switch is set off
from the plan above it by a rule and some space, and sits level with its
label instead of riding above it.

2.71.5 — every line of the energy table carries its icon: a socket or a bulb
per plug, a house for a room, the strip's own mark where the grouping is by
box, and a sigma on the total.

2.71.4 — the energy table groups by room only: the separate *Lights* section
is gone, and every group now starts folded when the page loads.

2.71.3 — the QR code on a Setup chip was being drawn behind the dialog it
belongs to (z-index 80 under a backdrop at 100), so hovering appeared to do
nothing; and a browser that refuses the clipboard call did so silently,
which made clicking look dead. The QR now sits above everything, and a copy
falls back to the old method and says so if even that fails.

2.71.2 — the *What is in them* list under Rooms is ordered like every other
device list: sockets, lights, sensors, buttons, routers, and by name inside
each.

2.71.1 — a socket marked as a light carries a bulb icon everywhere it is
listed, and the dropdowns group the lights together, by name within the
group.

2.71.0 — the editors under Control can be reordered by dragging a row by
the handle on its left: bindings, rules, scenes, rooms, sequences,
schedules, people, presence triggers, messages, devices and gateways. The
order is saved by that section's own Save button.

2.70.1 — Rooms sits under Scenes in Control → Automation.

2.70.0 — hovering a copy chip in the phone Setup dialog shows its contents
as a QR code, so a link or a token goes to the phone by pointing a camera at
the screen. The encoder is written out in the page (byte mode, level L,
versions 1-10, all eight masks scored); every code it makes was read back
with an independent decoder across 154 payloads, including Czech diacritics.

2.69.1 — picking *a light* now survives Save: the web relay copies each
device field by name onto what it forwards to the daemon, and the new one
was not on that list, so the choice was dropped on the way and came back a
socket.

2.69.0 — a plug can be marked as **a light**: identical in every other way,
but listed in a section of its own in the energy table, folded away when the
page opens.

2.68.3 — a room just added can be assigned to straight away: it used to get
its id only when saved, so until then the only choice beside every device
was a dash that did nothing. The empty choice now reads *not in a room*,
and each room says how many things are in it.

2.68.2 — Rooms moved from Control → Devices to Control → Automation, above
the bindings, since what a room is for is the automation side.

2.68.1 — the phone Setup dialog opens wide (900 px) so a link is one line
rather than four, its copy chips stand on their own, and the bold in a step’s
heading is bold rather than the letters <b>.

2.68.0 — the phone **Setup** dialog carries the step-by-step for the
handset: the Location Services setting, every screen of the iOS automation
in order, the ntfy or direct variant depending on what is configured, how
to test it, and tap-to-copy chips for the URL, topic and token.

2.67.3 — the Rooms and Heating editors behave like every other one: their
buttons carry icons, and a locked page no longer greys the controls out and
leaves them dead — you edit, and the PIN is asked for when you save.

2.67.2 — the energy table groups even before any room exists: the sockets
of one strip fold into a line of their own, with a *Fold every group*
button, and the folds are remembered across a reload.

2.67.1 — the row above the Heating rooms lines its labels and controls up
in a grid instead of leaning them against each other, and the SSH fields
read in the order they are filled in: how to get in, port, username,
password.

2.67.0 — rooms, and a Heating screen built on them: three temperatures and
a weekly plan per room, an away switch, an open window that stops the room
while it lasts, all pushed to the valves in that room and only when the
number has changed. The energy table is grouped by room and folds. A
summary of what the month cost goes out on the first, by notification.

2.66.1 — settings layout: the SSH password sits next to the username it
belongs with and the port after them, and a label too long for its column no
longer wraps and drops its own field half a row below the others.

2.66.0 — a phone can report its own arrivals and departures, from its
geofence, over mobile data, before it is on the Wi-Fi: a token per person, a
link to paste into an iOS Shortcut or Tasker, and an ntfy topic as an
alternative for anyone who would rather expose nothing. Arriving counts at
once; a reported departure is checked against the controller first.

2.65.0 — fifth latency pass, nothing found in the daemon: a two-minute soak
on the real database (4 reports/s) gave wake-ups of 1.5 ms median, 2.1 ms
p99, 2.5 ms max with no outlier at all; a full garbage collection of the
70 MB heap costs 4 ms and gen-2 collections never ran during 3,000 status
builds. The one thing tightened is the web layer: the installer (and
`--upgrade`) sets the php-fpm pool to keep 6-24 idle workers with 8 started
(the stock five made an opening page wait for forks, since every open tab
already holds one worker for its live wait) and installs php-opcache.

2.64.1 — arriving and leaving are noticed when they happen. What the access
points last reported over SSH was being folded back into every presence
round whatever its age, so a phone that had left stayed on the network - and
its owner stayed home, and "when the last person leaves" stayed unfired -
until the next point probe, up to `detail_s` (three minutes by default)
later. That snapshot now only fills in detail on clients the controller
still lists, and carries a client of its own only while it is fresh. For a
minute after anybody comes or goes the controller is also asked every five
seconds instead of every `poll_s`.

2.64.0 — thermostatic radiator valves. The keys a head reports are named
and carry their units, its card gains a target-temperature control and a
mode picker, and a new action **set to …** makes its target and its mode
usable in bindings, rules, scenes, schedules and presence triggers, with
the head's own range and list of modes offered in the editor.

2.63.2 — fixes the Wi-Fi tab, blank since 2.62.2: the *why out* line meant
for the People editor had landed in the *Other networks* renderer, where it
threw on the first row and took the client list down with it. Both draw
again; the line is where it belongs.

2.63.1 — the Wi-Fi tab never goes blank: when the controller is not
answering, the client list says so with the error and when it was last
asked; a client record that cannot be drawn gets a one-line row instead of
taking the list down; and any tab that fails to draw shows the error at
its top while the rest of the page carries on.

2.63.0 — fourth latency pass. The API listener's backlog is 64 instead of
the default 5, so a page opening with a dozen requests on top of the parked
long polls no longer has connections dropped and retried a second later. A
presence rule's quick look at the Wi-Fi never waits behind a regular poll
stuck on a slow controller (it takes the lock for its own 3 s at most, then
goes with the last answer). *Must hold for N s* rules are finished on the
presence worker rather than the clock thread, and the clock beats every
half second. After the daemon comes back, the page's live wait retries at
once instead of after its backoff. Soak on the real database unchanged:
wake-up median 1.3 ms, status 6.7 ms, 3 % of one core.

2.62.2 — the *why out* explanation sits on its own line under the person
(it was crammed into the 54 px tag column) and reads more plainly.

2.62.1 — a person's device can be matched by the name the controller shows
(`name:iPhone16`) instead of a Wi-Fi address that rotates; every *out* tag
and the At home dialog say in words why the person counts as out.

2.62.0 — presence-gated rules look at the Wi-Fi *now* before firing: an
answer older than `presence_fresh_s` (4 s) is refreshed with a 3 s timeout,
so arriving is seen before the first motion alert. Rules are evaluated on
their own ordered thread (hand-over from the broker thread in microseconds),
so that wait never touches a button, a report or a plug. The controller can
now be asked as often as every 3 s (was 10).

2.61.0 — third latency pass, with a 60-second soak on the real database
(five reports a second with a browser-style long-poll client): wake-up
median 1.0 ms, p95 1.5 ms, max 1.8 ms; `/api/status` 5.5 ms; 1.9 % of one
core; no memory growth. Two things were found and fixed. *Must hold for
N s* rules and weekly schedules were checked from the plug poll loop every
30 s, so "no motion for 10 min" fired anywhere up to half a minute late and
a slow plug round pushed a 07:00 schedule to 07:01 — they now beat on their
own one-second thread (a 3 s rule fires at 3.0 s), and that thread runs
even with no plug configured, where before a house with only Zigbee
switches got no schedules at all. Notifications that sat in the queue for
five minutes (internet down) are dropped with a log line instead of
arriving as stale news, critical ones excepted.

2.60.3 — the coordinator is no longer shown as offline while it is plainly
running. Zigbee2MQTT marks it offline because it does not answer the
availability pings an end device answers, and that word used to stand even
when the box was answering on its own network API a second earlier. A
gateway that answers now vouches for its device: the bridge's *offline* is
ignored while its own API is replying, and counts again three poll rounds
after it stops.

2.60.2 — the Overview metric cards open the same detail dialog *Needs
attention* has: **Online** lists what is and is not reporting with why and
how long ago, **At home** each watched person with how they are known and
the state of the controller, **Devices** everything grouped by kind. A name
in any of them opens that device's History, as before.

2.60.1 — *By hand* works through scenes and sequences: the hold used to be
looked for on the scene itself, where no rule ever looks, so a PIR rule
switched the lights off again a minute after the button had set the scene.
Each light the scene touches is now held (or released) on its own.

2.60.0 — a second latency pass, measured on a real 4-day database. Every
message type costs under 4 ms on the broker thread (a device list 2 ms, a
PIR event with its rule 2.9 ms, a button with its binding 3.9 ms); the
message path, the wake-up and `/api/status` (1.7 ms warm) never wait for
the store lock, so a VACUUM or a backup stalls charts only, never a press.
On the page: the Overview rebuilds only the card whose facts changed (one
report used to rebuild all of them and restart every animation); a burst
of reports — twenty in 80 ms — becomes one status fetch instead of twenty,
with the first change still fetched at once; the broker keepalive is 20 s
and reconnects start after 1 s, so a dead link is noticed in ~30 s rather
than 90 and picked up again in a second.

2.59.4 — the Emoji and Facts pop-ups are wide and low (720 / 860 px,
capped at 70 % of the window and scrolling inside) instead of a 330 px
column; Facts lays its items out in a grid with the description beside
each placeholder; both open above the button when there is no room below.

2.59.3 — Ctrl+Space (and moving through the completion list) no longer
scrolls the page: the list scrolls itself, focus is restored without
scrolling, and when there is no room under the caret the list opens above
it.

2.59.2 — the live preview under every message is back and drawn as the
phone will show it (app, title, text, picture line), refreshed a beat
after each keystroke and after a level/picture change. It used to need an
unlocked session because it went through the PIN-guarded save endpoint;
it now has its own read-only `/api/message-preview`, so it shows locked or
not. The Emoji button offers seven groups (~180 symbols) instead of four.

2.59.1 — IDE-style completion in the message editor: `{` or Ctrl+Space
lists every fact with a description and a live example, a device name and
`.` lists that device's readings with their current values; the Facts
button carries the same catalogue with examples.

2.59.0 — messages know more: `{unit}`, `{label}`, `{model}`, `{battery}`,
`{signal}`, `{temperature}`, `{humidity}` of the device that set it off;
`{weekday}`, `{sunrise}`, `{sunset}`, `{daylight}`, `{home_count}`,
`{attention}`, `{attention_list}`, `{alerts}`, `{uptime}`; and
`{Name.key}` for the current reading of any device at all (`{Name.state}`,
`{Name.age}`, `{Name.battery}` …). The Facts picker lists them.

2.58.2 — Zigbee gateways editor: the Detect/Remove buttons sat in a fixed
104 px cell and hung out past the card; the cell now takes what they need,
the other columns may shrink, and on a narrower window the buttons wrap under
the row instead of overflowing. The *config.json* tag rides with them
rather than becoming a stray seventh cell.

2.58.1 — verified against a real 4-day database (35 devices, 15 plugs, 3
gateways, 11 bindings, 6 rules): a report, a button press with its binding
and a PIR event with its rule each wake the dashboard in 2–7 ms while every
plug is unreachable; `/api/status` builds in 9 ms. Its 140 kB of JSON is now
gzip-compressed by nginx (~15 kB on the wire; `--upgrade` adds the directive
to an existing server block).

2.58.0 — the *may be unplugged* device state; and a pass over latency:
the Overview charts load in one request (`/api/history-multi`) and, on a
live update, at most once every 15 s instead of once per message from any
device — the cards themselves still repaint the instant a report lands;
history is thinned inside SQLite (a 7-day series takes ~8 ms instead of
~40 ms of lock time per device); the systemd unit no longer caps the
daemon at 15 % CPU with idle I/O, which had been stretching sub-second
work into seconds whenever the machine was busy; a plug's MQTT push of new
watts wakes the dashboard at once; the plug poll period counts from the
start of a round, so one dead box no longer delays the others or the
schedules; a multi-relay strip now records *contact restored* and wakes the
dashboard when it comes back.
