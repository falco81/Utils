const { JSDOM } = require('jsdom');
(async () => {
  const base = 'http://127.0.0.1:8099/';
  const html = await (await fetch(base + 'index.php')).text();
  const errors = [];
  const dom = new JSDOM(html, { url: base + 'index.php', runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true,
    beforeParse(window) {
      window.fetch = (url, opts) => fetch(new URL(url, base).href, opts);
      window.confirm = () => true;
      window.addEventListener('error', e => errors.push(e.message));
      window.console.error = (...a) => errors.push(a.join(' '));
      Object.defineProperty(window.HTMLElement.prototype, 'clientWidth', { get() { return 600; } });
      Object.defineProperty(window.HTMLElement.prototype, 'clientHeight', { get() { return 240; } });
      Object.defineProperty(window.HTMLElement.prototype, 'offsetParent', { get() { return this.parentNode; } });
    }});
  const w = dom.window, d = w.document;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  await wait(1500);
  const txt = id => (d.getElementById(id) || {}).textContent;
  console.log('pill:', txt('pill-text'), '| devices:', txt('m-devices'), '| cards:', d.querySelectorAll('#device-cards .dev').length);
  console.log('ov-temp svg paths:', d.querySelectorAll('#ov-temp path').length, 'legend:', txt('ov-temp-legend'));
  for (const tab of ['history','devices','events','control','all']) {
    d.querySelector('.tabs button[data-tab="'+tab+'"]').click();
    await wait(1200);
  }
  console.log('history charts:', d.querySelectorAll('#h-charts .card').length, '| note:', txt('h-note'));
  console.log('devices rows:', d.querySelectorAll('#devices-table tbody tr').length);
  console.log('events rows:', d.querySelectorAll('#events-table tbody tr').length);
  console.log('health rows:', d.querySelectorAll('#health-kv .kv').length);
  console.log('all cards:', d.querySelectorAll('#all-values .card').length);
  // control: reset events with PIN flow
  d.querySelector('.tabs button[data-tab="control"]').click(); await wait(300);
  d.querySelector('[data-reset="events"]').click(); await wait(200);
  console.log('modal shown:', !d.getElementById('pinback').hidden);
  // the PIN is one box per digit since 2.x
  Array.from(d.getElementById('pindigits').querySelectorAll('input')).forEach((i, n) => { i.value = '1234'[n] || ''; i.dispatchEvent(new w.Event('input', {bubbles: true})); });
  d.getElementById('pinok').click(); await wait(1200);
  console.log('toast:', txt('toast'));
  // hover a chart
  d.querySelector('.tabs button[data-tab="overview"]').click(); await wait(800);
  const c = d.getElementById('ov-temp');
  c.dispatchEvent(new w.MouseEvent('mousemove', {clientX: 300, clientY: 100, bubbles: true}));
  console.log('tip:', (c.querySelector('.tip')||{}).style && c.querySelector('.tip').style.display, (c.querySelector('.tip')||{}).textContent);
  // A rule dragged by its handle must survive the house reporting while the
  // pointer is down: the guard against redrawing under a drag knew only about
  // the cards, so in a busy house every drag was undone by the next report.
  try {
    const r2 = await (await fetch(base + 'index.php?api=unlock', {method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({pin: '1234', minutes: 30})})).json();
    if (r2 && r2.token) {
      w.LOCK.token = r2.token; w.LOCK.until = r2.until; w.SIGS = {}; w.tick(true);
      d.querySelector('.tabs button[data-tab="control"]').click(); await wait(400);
      w.showControlSection('automation'); await wait(2500);
      const packs = Array.from(d.querySelectorAll('#rules-list .rule-pack'));
      if (packs.length > 1) {
        const a = packs[0], b = packs[1], parent = a.parentNode;
        const dt = {effectAllowed: '', setData() {}, getData() { return 'row'; }};
        a.querySelector('.rowgrab').dispatchEvent(new w.MouseEvent('mousedown', {bubbles: true}));
        a.dispatchEvent(Object.assign(new w.Event('dragstart', {bubbles: true}), {dataTransfer: dt}));
        // exactly what a report from the house does, and what used to rebuild
        // the list out from under the pointer
        w.SIGS = {}; w.tick(true); await wait(1800);
        if (!d.body.contains(a)) errors.push('the row being dragged was rebuilt out from under the pointer');
        b.dispatchEvent(Object.assign(new w.Event('dragover', {bubbles: true, cancelable: true}), {dataTransfer: dt}));
        const moved = Array.prototype.indexOf.call(parent.children, a)
                    > Array.prototype.indexOf.call(parent.children, b);
        a.dispatchEvent(new w.Event('dragend', {bubbles: true}));
        await wait(400);
        console.log('a rule dragged through a redraw moves:', moved);
        if (!moved) errors.push('a rule could not be dragged while the house was reporting');
      }
    }
  } catch (e) { errors.push('the drag check itself failed: ' + e.message); }

  console.log('errors:', errors.length ? errors : 'none');
  w.close(); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
