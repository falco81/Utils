#!/usr/bin/env python3
"""A Teltonika-lookalike SMS gateway, for testing without a SIM card.

    python3 test/mocksms.py 18110 [user] [password]

Speaks the CGI dialect a TRB140 does: /cgi-bin/sms_send, /cgi-bin/sms_list,
/cgi-bin/sms_delete. GET / returns what it has been asked to send, so a test
can check the message actually went out; POST /inbox puts a message in the
box for the daemon to find.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

SENT, INBOX = [], []
USER = sys.argv[2] if len(sys.argv) > 2 else 'admin'
PASSWORD = sys.argv[3] if len(sys.argv) > 3 else 'secret'


SIGNAL = {'rssi': -71, 'rsrp': -101, 'rsrq': -11, 'sinr': 9, 'conn_type': 'LTE'}
INFO = {'operator': 'Vodafone CZ', 'net_mode': 'LTE', 'sim_state': 'ready',
        'imei': '350000000000001', 'cell_id': '1A2B3C', 'roaming': 'no', 'temperature': 372}
USAGE = {'month': {'total': 734003200}, 'today': {'total': 41943040}}


class Handler(BaseHTTPRequestHandler):
    def _ubus(self, body):
        """Just enough of RutOS's JSON-RPC to be worth testing against."""
        params = body.get('params') or []
        session, obj, method = (params + ['', '', ''])[:3]
        def out(result):
            self._text(json.dumps({'jsonrpc': '2.0', 'id': body.get('id'), 'result': [0, result]}))
        if obj == 'session' and method == 'login':
            given = params[3] if len(params) > 3 else {}
            if given.get('username') != USER or given.get('password') != PASSWORD:
                return self._text(json.dumps({'jsonrpc': '2.0', 'id': body.get('id'), 'error': 'wrong password'}), 200)
            return out({'ubus_rpc_session': 'abcdef0123456789'})
        if session != 'abcdef0123456789':
            return self._text(json.dumps({'jsonrpc': '2.0', 'id': body.get('id'), 'result': [6]}))
        if obj == 'gsm.modem0' and method == 'get_signal_query':
            return out(dict(SIGNAL))
        if obj == 'gsm.modem0' and method == 'info':
            return out(dict(INFO))
        if obj == 'gsm.modem0' and method == 'get_data_usage':
            return out(dict(USAGE))
        return self._text(json.dumps({'jsonrpc': '2.0', 'id': body.get('id'), 'result': [4]}))

    def log_message(self, *a):
        pass

    def _text(self, body, code=200):
        raw = body.encode()
        self.send_response(code)
        self.send_header('Content-Type', 'text/plain')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self, q):
        return (q.get('username', [''])[0] == USER and q.get('password', [''])[0] == PASSWORD)

    def do_GET(self):
        url = urlparse(self.path)
        q = parse_qs(url.query)
        if url.path == '/':
            return self._text(json.dumps({'sent': SENT, 'inbox': INBOX}))
        if not self._auth(q):
            return self._text('ERROR: wrong username or password', 403)
        if url.path == '/cgi-bin/sms_send':
            SENT.append({'number': q.get('number', [''])[0], 'text': q.get('text', [''])[0]})
            return self._text('OK')
        if url.path == '/cgi-bin/sms_list':
            if not INBOX:
                return self._text('No messages')
            out = []
            for i, m in enumerate(INBOX):
                out.append('Index: %d\nSender: %s\nText: %s\n' % (i, m['from'], m['text']))
            return self._text('\n'.join(out))
        if url.path == '/cgi-bin/status':
            return self._text('Operator: Vodafone CZ\nConnection type: LTE\nSignal strength: -71 dBm\n'
                              'RSRP: -101\nRSRQ: -11\nSINR: 9\nSIM state: ready\nIMEI: 350000000000001\n')
        if url.path == '/cgi-bin/sms_delete':
            INBOX.clear()
            return self._text('OK')
        return self._text('ERROR: no such path', 404)

    def do_POST(self):
        length = int(self.headers.get('Content-Length') or 0)
        body = json.loads(self.rfile.read(length) or b'{}')
        if urlparse(self.path).path == '/ubus':
            return self._ubus(body)
        if urlparse(self.path).path == '/inbox':
            INBOX.append({'from': body.get('from', '+420777123456'), 'text': body.get('text', '')})
            return self._text('OK')
        if urlparse(self.path).path == '/reset':
            SENT.clear(); INBOX.clear()
            return self._text('OK')
        return self._text('ERROR', 404)


if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', int(sys.argv[1])), Handler).serve_forever()
