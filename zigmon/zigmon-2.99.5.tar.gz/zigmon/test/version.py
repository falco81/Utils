#!/usr/bin/env python3
"""The version must be the same in every place that states it.

They drifted apart once: a release script replaced a version string that was
no longer there, said nothing, and several releases went out carrying an old
number inside a differently named file. Nobody could tell what they were
running. Run this before packaging.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
found = {}

m = re.search(r"__version__ = '([^']+)'", (here / 'zigmon.py').read_text())
found['zigmon.py'] = m.group(1) if m else None

m = re.search(r'^VERSION="([^"]+)"', (here / 'install.sh').read_text(), re.M)
found['install.sh'] = m.group(1) if m else None

m = re.search(r'Current version: \*\*([^*]+)\*\*', (here / 'README.md').read_text())
found['README.md'] = m.group(1) if m else None

for where, value in found.items():
    print('%-12s %s' % (where, value or '(not stated)'))
if len(set(found.values())) != 1 or None in found.values():
    print('\nthese do not agree')
    sys.exit(1)
print('\nall three agree')
