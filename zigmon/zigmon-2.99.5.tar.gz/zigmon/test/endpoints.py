#!/usr/bin/env python3
"""Every path the web relay forwards must be one the daemon actually serves.

Run before a release. It reads both files rather than the running daemon, so
it needs nothing set up, and it catches the mistake that shipped in 2.90.0:
an endpoint written into the daemon's read branch while the page posts to it.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
php = (here / 'web' / 'index.php').read_text()
py = (here / 'zigmon.py').read_text()

relayed = set(re.findall(r"zigmon_relay\('(/api/[a-z0-9/_-]+)", php))
relayed |= set(re.findall(r"=> '(/api/[a-z0-9/_-]+)'", php))

served = set(re.findall(r"path == '(/api/[a-z0-9/_-]+)'", py))
for group in re.findall(r"path in \(([^)]+)\)", py):
    served |= set(re.findall(r"'(/api/[a-z0-9/_-]+)'", group))

missing = sorted(relayed - served)
if missing:
    print('the relay forwards paths the daemon does not serve:')
    for p in missing:
        print('   ', p)
    sys.exit(1)
print('%d relayed path(s), all served' % len(relayed))
