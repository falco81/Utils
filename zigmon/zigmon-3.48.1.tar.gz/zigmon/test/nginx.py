#!/usr/bin/env python3
"""The nginx file, read for the things nginx itself would refuse.

There is no nginx here to ask, and the file is shipped to machines where a
mistake in it stops the web server rather than the dashboard - which is worse
than any fault inside the dashboard, because it takes everything else on that
machine with it.
"""
import re
import sys
from pathlib import Path

CONF = Path(__file__).resolve().parent.parent / 'deploy' / 'nginx-zigmon.conf'
text = CONF.read_text()
bad = []

# A location's regex may hold { or }, but only in quotes: nginx reads a brace
# as the start or end of a block and cuts the expression off there, then
# refuses to start with "missing ) in ...". This is how /tap/([A-Za-z0-9_-]
# was all nginx ever saw of a perfectly good pattern.
for match in re.finditer(r'location\s+(~\*?|=)?\s*([^\s{][^\n]*?)\s*\{', text):
    expr = match.group(2).strip()
    if ('{' in expr or '}' in expr) and not (expr.startswith('"') and expr.endswith('"')):
        bad.append('location %s needs quoting: a brace in it ends the expression' % expr)

# gzip always compresses text/html, and naming it warns at every start
for line in text.split('\n'):
    if line.strip().startswith('gzip_types') and 'text/html' in line:
        bad.append('gzip_types names text/html, which nginx compresses anyway - a warning at start')

# every brace balanced, or nginx says something far less helpful than this
depth = 0
for n, line in enumerate(text.split('\n'), 1):
    without = re.sub(r'"[^"]*"|#.*$', '', line)
    depth += without.count('{') - without.count('}')
    if depth < 0:
        bad.append('a } too many at line %d' % n)
        break
if depth > 0:
    bad.append('%d block(s) left open at the end' % depth)

# Every regex must compile. A quoted pattern is taken whole - reading up to
# the first brace is the very mistake being looked for, and doing it here
# would report a sound pattern as broken.
for match in re.finditer(r'location\s+~\*?\s*(?:"([^"]*)"|([^\s{]+))\s*\{', text):
    expr = match.group(1) if match.group(1) is not None else match.group(2)
    try:
        re.compile(expr)
    except re.error as e:
        bad.append('location %s is not a regular expression: %s' % (expr, e))

# A rewrite resets $1..$9 to its own captures, so "rewrite ^ /x?t=$1" hands
# on an empty token however well the location captured it. If a rewrite uses
# a capture, its own expression has to make one.
for match in re.finditer(r'\n\s*rewrite\s+("[^"]*"|\S+)\s+(\S+)', text):
    pattern, target = match.group(1).strip('"'), match.group(2)
    if re.search(r'\$[1-9]', target) and '(' not in pattern:
        bad.append('rewrite %s uses $1 but captures nothing itself - the token arrives empty'
                   % pattern)

if bad:
    print('the nginx file would not start:')
    for line in bad:
        print('   ' + line)
    sys.exit(1)
print('nginx file: %d location(s), braces balanced, every pattern sound'
      % len(re.findall(r'\n\s*location\s', text)))
