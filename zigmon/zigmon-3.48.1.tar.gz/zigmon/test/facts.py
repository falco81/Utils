#!/usr/bin/env python3
"""Every fact the daemon fills must be offered in the page's picker, and every
fact the picker offers must exist.

The two lists drifted apart once: the picker advertised sunrise, sunset and
daylight for weeks while the daemon filled none of them, so a message quoting
them arrived with the words missing. Run this before a release.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(here))
import zigmon                                    # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-facts-check.db'
zigmon.CONFIG['api_port'] = 19700
zigmon.CONFIG['token_file'] = '/tmp/zigmon-facts-token'
daemon = zigmon.Daemon()
have = set(daemon.message_facts('a check'))

page = (here / 'web' / 'index.php').read_text()
start = page.index('function factCatalogue')
block = page[start:page.index('\n}', start)]
offered = set(re.findall(r"\['([a-z_0-9]+)',", block))

missing = sorted(have - offered)
extra = sorted(offered - have)
if missing:
    print('filled by the daemon but not offered in the picker:')
    for k in missing:
        print('   {%s}' % k)
if extra:
    print('offered in the picker but never filled:')
    for k in extra:
        print('   {%s}' % k)
if missing or extra:
    sys.exit(1)
print('%d facts, all of them offered and all of them filled' % len(have))

# Turns of phrase: a fact may be followed by one, or several, and they have to
# work anywhere a fact does. An empty list is a word in this house - "nothing",
# "nobody" - so counting one of those as an item would have a message saying
# one socket is on when none is.
_list = 'Plug-UPS, Workshop-PC, Workshop-TV, Balcony'
_turns = {
    'nl': 'Plug-UPS\nWorkshop-PC\nWorkshop-TV\nBalcony',
    'count': '4',
    'first': 'Plug-UPS',
    'last': 'Balcony',
    'and': 'Plug-UPS, Workshop-PC, Workshop-TV and Balcony',
    'three': 'Plug-UPS, Workshop-PC, Workshop-TV and 1 more',
    'upper': _list.upper(),
}
for _name, _want in _turns.items():
    _got = zigmon.FACT_TURNS[_name](_list)
    assert _got == _want, '.%s gave %r, wanted %r' % (_name, _got, _want)
for _empty in ('nothing', 'nobody', 'none', ''):
    assert zigmon.FACT_TURNS['count'](_empty) == '0', '.count called %r one thing' % _empty
    assert zigmon.FACT_TURNS['nl'](_empty) == '', '.nl made a line out of %r' % _empty
assert zigmon.FACT_TURNS['round']('21.73') == '22'
assert zigmon.FACT_TURNS['round1']('21.73') == '21.7'
assert zigmon.FACT_TURNS['round']('not a number') == 'not a number'

# every turn the page offers must be one the daemon knows, and the other way
_php = (Path(__file__).resolve().parent.parent / 'web' / 'index.php').read_text()
_offered = set(re.findall(r"\n  \['([a-z0-9]+)', '[^']*', '[^']*'\]", _php[_php.index('var FACT_TURN_LIST'):
                                                                      _php.index('function completerItems')]))
_known = set(zigmon.FACT_TURNS)
assert not (_offered - _known), 'the page offers turns the daemon does not know: %s' % (_offered - _known)
assert not (_known - _offered), 'the daemon knows turns the page never offers: %s' % (_known - _offered)
# a turn must never leave a message half-written, whatever it is given
for _name, _fn in sorted(zigmon.FACT_TURNS.items()):
    for _given in ('', 'nothing', 'one', 'a, b, c', '-4.25', 'not a number', 'P\u0159\u00edzem\u00ed'):
        try:
            _out = _fn(_given)
        except Exception as _e:
            raise AssertionError('.%s fell over on %r: %s' % (_name, _given, _e))
        assert isinstance(_out, str), '.%s gave back a %s' % (_name, type(_out).__name__)

# the one that pays for itself: a diacritic doubles what a text message costs
_cz = 'Venku je zima a pr\u0161\u00ed, m\u011b\u0159\u00edm teplotu v ob\u00fdvac\u00edm pokoji a v lo\u017enici. Z\u00e1suvky: Plug-UPS, Workshop-PC.'
assert zigmon.Daemon.sms_parts(_cz) == 2
assert zigmon.Daemon.sms_parts(zigmon.FACT_TURNS['ascii'](_cz)) == 1, \
    'stripping the diacritics did not bring it down to one message'

print('%d turn(s) of phrase, each working and each offered' % len(_known))
