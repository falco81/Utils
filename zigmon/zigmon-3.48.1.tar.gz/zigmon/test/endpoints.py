#!/usr/bin/env python3
"""Every path the web relay forwards must be one the daemon actually serves.

Run before a release. It reads both files rather than the running daemon, so
it needs nothing set up, and it catches the mistake that shipped in 2.90.0:
an endpoint written into the daemon's read branch while the page posts to it.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
php = (here / 'web' / 'index.php').read_text()
py = (here / 'zigmon.py').read_text()

relayed = set(re.findall(r"zigmon_relay\('(/api/[a-z0-9/_-]+)", php))
relayed |= set(re.findall(r"=> '(/api/[a-z0-9/_-]+)'", php))

served = set(re.findall(r"path == '(/api/[a-z0-9/_-]+)'", py))
for group in re.findall(r"path in \(([^)]+)\)", py):
    served |= set(re.findall(r"'(/api/[a-z0-9/_-]+)'", group))

# a path the daemon answers by its opening rather than in full, such as a
# one-tap link, where the rest of the path is the link's own secret
starts = re.findall(r"path\.startswith\('(/api/[a-z0-9/_-]+)'\)", py)
missing = sorted(p for p in relayed - served
                 if not any(p.startswith(x) for x in starts))
if missing:
    print('the relay forwards paths the daemon does not serve:')
    for p in missing:
        print('   ', p)
    sys.exit(1)
print('%d relayed path(s), all served' % len(relayed))


# Every name the page calls must be one the relay serves. It caught a save
# that used a button's id as a path and answered "unknown endpoint".
import re as _re
_src = (here / 'web' / 'index.php').read_text() if 'here' in dir() else open(str(__file__).rsplit('/', 2)[0] + '/web/index.php').read()
_js = _re.search(r'<script>(.*?)</script>', _src, _re.S).group(1)
_called = set(_re.findall(r"post\('([a-z0-9-]+)'", _js)) | set(_re.findall(r"api\('([a-z0-9-]+)", _js))
_allow = set(_re.findall(r"'([a-z0-9-]+)'", _re.search(r"if \(in_array\(\$what, \[(.*?)\], true\)", _src, _re.S).group(1)))
_gets = set(_re.findall(r"\$what === '([a-z0-9-]+)'", _src))
_paths = set(_re.findall(r"'([a-z0-9-]+)' => '/api", _src))
_missing = sorted(_called - _allow - _gets - _paths)
if _missing:
    print('the page calls names the relay does not serve:')
    for _name in _missing:
        print('   %s' % _name)
    raise SystemExit(1)
print('%d name(s) the page calls, all of them served' % len(_called))

# ?ask has to survive every hop. It is dropped in two ways that look like
# nothing at all: an nginx rewrite whose replacement holds a ? throws the
# original query away, and a relay that rebuilds the path leaves it behind.
# Either way, asking how things stand quietly becomes switching them.
php = (Path(__file__).resolve().parent.parent / 'web' / 'index.php').read_text()
conf = (Path(__file__).resolve().parent.parent / 'deploy' / 'nginx-zigmon.conf').read_text()
lost = []
for line in php.split('\n'):
    if "'/api/tap/'" in line and 'relay' in line and 'ask' not in line:
        lost.append('the relay drops ?ask: %s' % line.strip()[:70])
for line in conf.split('\n'):
    if line.strip().startswith('rewrite') and '?' in line and '$args' not in line:
        lost.append('this rewrite throws the query away: %s' % line.strip()[:70])
if lost:
    print('?ask would not arrive:')
    for line in lost:
        print('   ' + line)
    sys.exit(1)
print('?ask survives the relay and the rewrite')
