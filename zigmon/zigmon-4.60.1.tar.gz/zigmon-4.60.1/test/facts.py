#!/usr/bin/env python3
"""Every fact the daemon fills must be offered in the page's picker, and every
fact the picker offers must exist.

The two lists drifted apart once: the picker advertised sunrise, sunset and
daylight for weeks while the daemon filled none of them, so a message quoting
them arrived with the words missing. Run this before a release.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(here))
import zigmon                                    # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-facts-check.db'
zigmon.CONFIG['api_port'] = 19700
zigmon.CONFIG['token_file'] = '/tmp/zigmon-facts-token'
daemon = zigmon.Daemon()
have = set(daemon.message_facts('a check'))

page = (here / 'web' / 'index.php').read_text()
start = page.index('function factCatalogue')
block = page[start:page.index('\n}', start)]
offered = set(re.findall(r"\['([a-z_0-9]+)',", block))

missing = sorted(have - offered)
extra = sorted(offered - have)
if missing:
    print('filled by the daemon but not offered in the picker:')
    for k in missing:
        print('   {%s}' % k)
if extra:
    print('offered in the picker but never filled:')
    for k in extra:
        print('   {%s}' % k)
if missing or extra:
    sys.exit(1)
print('%d facts, all of them offered and all of them filled' % len(have))

# Turns of phrase: a fact may be followed by one, or several, and they have to
# work anywhere a fact does. An empty list is a word in this house - "nothing",
# "nobody" - so counting one of those as an item would have a message saying
# one socket is on when none is.
_list = 'Plug-UPS, Workshop-PC, Workshop-TV, Balcony'
_turns = {
    'nl': 'Plug-UPS\nWorkshop-PC\nWorkshop-TV\nBalcony',
    'count': '4',
    'first': 'Plug-UPS',
    'last': 'Balcony',
    'and': 'Plug-UPS, Workshop-PC, Workshop-TV and Balcony',
    'three': 'Plug-UPS, Workshop-PC, Workshop-TV and 1 more',
    'upper': _list.upper(),
}
for _name, _want in _turns.items():
    _got = zigmon.FACT_TURNS[_name](_list)
    assert _got == _want, '.%s gave %r, wanted %r' % (_name, _got, _want)
for _empty in ('nothing', 'nobody', 'none', ''):
    assert zigmon.FACT_TURNS['count'](_empty) == '0', '.count called %r one thing' % _empty
    assert zigmon.FACT_TURNS['nl'](_empty) == '', '.nl made a line out of %r' % _empty
assert zigmon.FACT_TURNS['round']('21.73') == '22'
assert zigmon.FACT_TURNS['round1']('21.73') == '21.7'
assert zigmon.FACT_TURNS['round']('not a number') == 'not a number'

# every turn the page offers must be one the daemon knows, and the other way
_php = (Path(__file__).resolve().parent.parent / 'web' / 'index.php').read_text()
_offered = set(re.findall(r"\n  \['([a-z0-9]+)', '[^']*', '[^']*'\]", _php[_php.index('var FACT_TURN_LIST'):
                                                                      _php.index('function completerItems')]))
_known = set(zigmon.FACT_TURNS)
assert not (_offered - _known), 'the page offers turns the daemon does not know: %s' % (_offered - _known)
assert not (_known - _offered), 'the daemon knows turns the page never offers: %s' % (_known - _offered)
# a turn must never leave a message half-written, whatever it is given
for _name, _fn in sorted(zigmon.FACT_TURNS.items()):
    for _given in ('', 'nothing', 'one', 'a, b, c', '-4.25', 'not a number', 'P\u0159\u00edzem\u00ed'):
        try:
            _out = _fn(_given)
        except Exception as _e:
            raise AssertionError('.%s fell over on %r: %s' % (_name, _given, _e))
        assert isinstance(_out, str), '.%s gave back a %s' % (_name, type(_out).__name__)

# the one that pays for itself: a diacritic doubles what a text message costs
_cz = 'Venku je zima a pr\u0161\u00ed, m\u011b\u0159\u00edm teplotu v ob\u00fdvac\u00edm pokoji a v lo\u017enici. Z\u00e1suvky: Plug-UPS, Workshop-PC.'
assert zigmon.Daemon.sms_parts(_cz) == 2
assert zigmon.Daemon.sms_parts(zigmon.FACT_TURNS['ascii'](_cz)) == 1, \
    'stripping the diacritics did not bring it down to one message'

print('%d turn(s) of phrase, each working and each offered' % len(_known))

# A turn after a reading of a NAMED device, which is the case that was broken:
# {PIR-Chodba.model.nl} left the whole placeholder standing on the page. The
# daemon takes the turns off the end while it knows them and asks for the rest
# as a device fact, so every turn must survive a device name in front of it -
# including a key that holds a dot of its own (switch.apower).
import json as _json                                                    # noqa: E402
_B = 'zigbee2mqtt/'


def _send(_t, _p):
    daemon.handle(_t, _json.dumps(_p).encode())


_send(_B + 'bridge/state', {'state': 'online'})
_send(_B + 'bridge/devices', [
    {'ieee_address': '0x0000', 'type': 'Coordinator', 'friendly_name': 'Coordinator'},
    {'ieee_address': '0xc02cedfffe2c7248', 'type': 'EndDevice', 'friendly_name': 'PIR-Chodba',
     'definition': {'model': 'SBMO-003Z', 'vendor': 'Shelly', 'description': 'Motion sensor', 'exposes': [
         {'access': 5, 'label': 'Battery', 'name': 'battery', 'property': 'battery', 'type': 'numeric', 'unit': '%'},
         {'access': 5, 'label': 'Occupancy', 'name': 'occupancy', 'property': 'occupancy', 'type': 'binary'}]}}])
_send(_B + 'PIR-Chodba', {'occupancy': True, 'battery': 88, 'linkquality': 90})
_facts = daemon.message_facts('a check')

assert daemon.fill_message('{PIR-Chodba.model}', _facts) == 'SBMO-003Z'
_pairs = [('{PIR-Chodba.model.lower}', 'sbmo-003z'),
          ('{PIR-Chodba.model.nl}', 'SBMO-003Z'),
          ('{PIR-Chodba.name.upper}', 'PIR-CHODBA'),
          ('{PIR-Chodba.battery.percent}', '88%'),
          ('{PIR-Chodba.occupancy.yesno}', 'yes'),
          ('{PIR-Chodba.model.lower.upper}', 'SBMO-003Z')]
for _wrote, _want in _pairs:
    _got = daemon.fill_message(_wrote, _facts)
    assert _got == _want, '%s gave %r, wanted %r' % (_wrote, _got, _want)
# and none of them may leave the placeholder itself standing
for _name in sorted(_known):
    _out = daemon.fill_message('{PIR-Chodba.model.%s}' % _name, _facts)
    assert '{' not in _out, '{PIR-Chodba.model.%s} came back as %r' % (_name, _out)
print('%d turn(s) work after a named device\'s reading too' % len(_known))


# Every kind of message the card offers a road for must be a kind something
# actually sends, and every kind something sends must be on the card. Five of
# them - a one-tap link, the router, heating, Wi-Fi, the text gateway - were
# offered for months with nothing ever sending them: anybody who routed one
# somewhere heard nothing for ever and had no way to tell.
import re as _re9
_src = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
_sent = set(_re9.findall(r"about='([a-z_]+)'", _src)) - {''}
_offered = {_k for _k, _n, _w in zigmon.Daemon.SYSTEM_ALERTS}
# these two mean "this one carries its own roads" and are not categories
_own_roads = {'device', 'message'}
_silent = sorted(_offered - _sent)
if _silent:
    print('kind(s) of message the card offers a road for that nothing ever sends:')
    for _k in _silent:
        print('   %s' % _k)
    raise SystemExit(1)
_unlisted = sorted(_sent - _offered - _own_roads)
if _unlisted:
    print('kind(s) of message sent that the card offers no road for:')
    for _k in _unlisted:
        print('   %s' % _k)
    raise SystemExit(1)
print('%d kinds of message, every one of them both sent and routable' % len(_offered))


# A road set for one kind of message has to actually take that road. The list
# of kinds being right is half of it; the other half is that choosing one
# changes where a message goes, and nothing checked that at all.
import json as _json9
_d9 = zigmon.Daemon()
_d9.store.set_meta('notify', _json9.dumps({
    'systems': {'taps': {'roads': 'telegram'}, 'router': {'off': True}}}))
zigmon.CONFIG.update({'notify_ntfy': 'https://ntfy.sh/x', 'notify_telegram_token': 't',
                      'notify_telegram_chat': '1', 'sms_enabled': 1})
_queue = _d9.notify_queue


def _roads_for(about):
    del _queue[:]
    _d9.notify('x', 'warn', about=about)
    return [{_k: _item[_k] for _k in ('ntfy', 'telegram', 'sms') if _k in _item}
            for _item in _queue]


_took = _roads_for('taps')
assert _took and _took[0] == {'ntfy': False, 'telegram': True, 'sms': False}, \
    'a kind sent down one road alone went %r instead' % _took
assert not _roads_for('router'), 'a kind switched off was still sent'
_other = _roads_for('wifi')
assert _other and _other[0]['ntfy'] and _other[0]['telegram'], \
    'a kind nobody has touched stopped taking the ordinary roads: %r' % _other
_d9.store.set_meta('notify', '{}')
print('a road set for one kind of message is the road that kind takes')

