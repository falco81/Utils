#!/usr/bin/env python3
"""Every setting drawn on the page must be the kind of box the daemon says it
is. The page used to keep its own idea of which settings were yes-or-no
questions, and it fell behind: two settings were drawn as number boxes asking
for a 1 or a 0, and a place could not be typed into the box asking for one.

This checks the two sides agree without a browser: the daemon's kinds against
the kinds the page's own code will draw.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(here))
import zigmon                                        # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-inputs-check.db'
zigmon.CONFIG['api_port'] = 19599
zigmon.CONFIG['token_file'] = '/tmp/zigmon-inputs-token'
daemon = zigmon.Daemon()
kinds = {k: v['kind'] for k, v in daemon.runtime_config().items()}

page = (here / 'web' / 'index.php').read_text()
drawn = {}
block = re.search(r'var SMS_GROUPS = \[(.*?)\n\];', page, re.S)
if block:
    for key, kind in re.findall(r"\['(sms_[a-z_0-9]+)', '(?:[^']|\\')*', '(\w+)'", block.group(1)):
        drawn[key] = {'switch': 'switch', 'select': 'choice', 'password': 'secret',
                      'number': 'number', 'text': 'text'}.get(kind, kind)

wrong = []
for key, kind in sorted(drawn.items()):
    if key not in kinds:
        wrong.append('%s is drawn but the daemon has no such setting' % key)
        continue
    want = kinds[key]
    if want == 'phone' and kind == 'text':
        continue                                     # a number box for a phone is still words
    if want == 'decimal' and kind == 'number':
        continue
    if want != kind:
        wrong.append('%s: the daemon says %s, the page draws %s' % (key, want, kind))

if wrong:
    print('the page and the daemon disagree about:')
    for line in wrong:
        print('   %s' % line)
    raise SystemExit(1)
print('%d settings the SMS card draws, all of the kind the daemon says' % len(drawn))
print('%d settings in all, each with a kind' % len(kinds))
