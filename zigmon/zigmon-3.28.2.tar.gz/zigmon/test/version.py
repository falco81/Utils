#!/usr/bin/env python3
"""The version must be the same in every place that states it.

They drifted apart once: a release script replaced a version string that was
no longer there, said nothing, and several releases went out carrying an old
number inside a differently named file. Nobody could tell what they were
running. Run this before packaging.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
found = {}

m = re.search(r"__version__ = '([^']+)'", (here / 'zigmon.py').read_text())
found['zigmon.py'] = m.group(1) if m else None

m = re.search(r'^VERSION="([^"]+)"', (here / 'install.sh').read_text(), re.M)
found['install.sh'] = m.group(1) if m else None

m = re.search(r'Current version: \*\*([^*]+)\*\*', (here / 'README.md').read_text())
found['README.md'] = m.group(1) if m else None

for where, value in found.items():
    print('%-12s %s' % (where, value or '(not stated)'))
if len(set(found.values())) != 1 or None in found.values():
    print('\nthese do not agree')
    sys.exit(1)
print('\nall three agree')


# The help is built from a table of (command, words) pairs, so that a column
# cannot drift. Every command must have words beside it, and every word must
# fit the page.
import re as _re
_src = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
_rows = _re.search(r'\nHELP_LINES = \[(.*?)\n\]', _src, _re.S).group(1)
_pairs = _re.findall(r"^\s*\('(.*?)', '(.*?)'\),$", _rows, _re.M)
_bare = [c for c, w in _pairs if not w.strip()]
if _bare:
    print('examples with nothing said about them:')
    for _c in _bare:
        print('   ' + _c)
    raise SystemExit(1)
print('%d example(s) in the help, every one of them worded' % len(_pairs))


# An upgrade must do everything a fresh install does that is not about first
# setup. The sudoers line that lets the daemon reload the broker was written
# only on a fresh install, so nobody who upgraded ever got it - the same shape
# of fault as a switch that is saved and never read.
_sh = (Path(__file__).resolve().parent.parent / 'install.sh').read_text()
_fresh = _re.search(r'\nmain\(\) \{(.*?)\n\}', _sh, _re.S).group(1)
_upgrade = _re.search(r'\ndo_upgrade\(\) \{(.*?)\n\}', _sh, _re.S).group(1)
_first_time_only = {'gather_answers', 'install_packages', 'create_user', 'write_config',
                    'create_mqtt_user', 'check_certificate', 'configure_nginx', 'configure_selinux',
                    'configure_firewall', 'summary', 'preflight', 'install_web', 'start_service',
                    'verify'}
_want = [c for c in _re.findall(r'^\s+([a-z_]+)$', _fresh, _re.M) if c not in _first_time_only]
_missing = [c for c in _want if c not in _upgrade]
if _missing:
    print('a fresh install does these and an upgrade does not:')
    for _c in _missing:
        print('   ' + _c)
    raise SystemExit(1)
print('%d step(s) an upgrade must repeat, all of them repeated' % len(_want))
