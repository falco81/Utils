#!/usr/bin/env python3
"""Every fact the daemon fills must be offered in the page's picker, and every
fact the picker offers must exist.

The two lists drifted apart once: the picker advertised sunrise, sunset and
daylight for weeks while the daemon filled none of them, so a message quoting
them arrived with the words missing. Run this before a release.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(here))
import zigmon                                    # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-facts-check.db'
zigmon.CONFIG['api_port'] = 19700
zigmon.CONFIG['token_file'] = '/tmp/zigmon-facts-token'
daemon = zigmon.Daemon()
have = set(daemon.message_facts('a check'))

page = (here / 'web' / 'index.php').read_text()
start = page.index('function factCatalogue')
block = page[start:page.index('\n}', start)]
offered = set(re.findall(r"\['([a-z_0-9]+)',", block))

missing = sorted(have - offered)
extra = sorted(offered - have)
if missing:
    print('filled by the daemon but not offered in the picker:')
    for k in missing:
        print('   {%s}' % k)
if extra:
    print('offered in the picker but never filled:')
    for k in extra:
        print('   {%s}' % k)
if missing or extra:
    sys.exit(1)
print('%d facts, all of them offered and all of them filled' % len(have))
