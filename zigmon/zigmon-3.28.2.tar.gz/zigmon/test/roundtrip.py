#!/usr/bin/env python3
"""Change one field in each editor, save it, read it back.

A control can be wired to a record, the record can be saved, and the field
can still be dropped on the way - by a validator that does not know it, or a
reader that never looks. This writes something distinctive into each editor,
saves through the same path the page uses, and asks the daemon for it again.
"""
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

BASE = 'http://127.0.0.1:%s' % (sys.argv[1] if len(sys.argv) > 1 else '9849')
TOKEN = Path(sys.argv[2] if len(sys.argv) > 2 else '/tmp/prod4-token').read_text().strip()
PIN = sys.argv[3] if len(sys.argv) > 3 else '1234'


def get(path):
    return json.loads(urllib.request.urlopen(BASE + path, timeout=25).read())


def post(path, body):
    req = urllib.request.Request(BASE + path, data=json.dumps(dict(body, pin=PIN)).encode(),
                                 headers={'X-Zigmon-Token': TOKEN, 'Content-Type': 'application/json'},
                                 method='POST')
    try:
        return json.loads(urllib.request.urlopen(req, timeout=25).read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


status = get('/api/status')
# the overview sums some editors up - a scene there carries how many steps it
# has, not the steps - so those are read from their own endpoint, as the page
# does when it opens the editor
for extra, path, key in (('scenes', '/api/scenes', 'scenes'),
                         ('sequences', '/api/sequences', 'sequences')):
    try:
        status[key] = get(path).get(key) or status.get(key) or []
    except Exception:
        pass
bad = []
mark = 'checked %d' % int(time.time())

# a field a person actually fills in, for each editor
CASES = [
    ('rules', '/api/rules', 'rules', 'group', mark),
    ('bindings', '/api/bindings', 'bindings', 'group', mark),
    ('scenes', '/api/scenes', 'scenes', 'name', 'Lo\u017enice ve\u010der'),
    ('schedules', '/api/schedules', 'schedules', 'group', mark),
    ('messages', '/api/messages', 'messages', 'text', None),
    ('sms commands', '/api/sms/commands', 'commands', 'reply', mark),
    ('people', '/api/people', 'people', 'name', None),
    ('rooms', '/api/rooms', 'rooms', 'name', None),
    ('sensor groups', '/api/sensor-groups', 'sensor_groups', 'name', 'Teplom\u011bry'),
    ('action groups', '/api/action-groups', 'action_groups', 'name', 'Sv\u011btla dole'),
]

for label, path, key, field, value in CASES:
    rows = status.get(key) or []
    if not rows:
        print('  %-14s nothing to change' % label)
        continue
    keep = json.loads(json.dumps(rows))
    was = rows[0].get(field)
    rows[0][field] = value if value is not None else ((was or 'x') + ' \u2713')
    wanted = rows[0][field]
    answer = post(path, {key: rows})
    if not answer.get('ok'):
        bad.append('%s: the save was refused (%s)' % (label, answer.get('error')))
        continue
    back = (get('/api/status').get(key) or [{}])[0].get(field)
    if back != wanted:
        bad.append('%s: wrote %r, read back %r' % (label, wanted, back))
        print('  %-14s <-- LOST ON THE WAY' % label)
    else:
        print('  %-14s kept what was written' % label)
    post(path, {key: keep})                      # put it back as it was

print('')
if bad:
    print('fields that did not survive a save:')
    for line in bad:
        print('   ' + line)
    raise SystemExit(1)
print('every editor kept what was written into it')
