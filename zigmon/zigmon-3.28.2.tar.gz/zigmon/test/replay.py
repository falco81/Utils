import json, time, threading, sys
sys.argv=['zigmon']
import zigmon
zigmon.load_config()
d = zigmon.Daemon()
B = 'zigbee2mqtt/'
def send(t, p): d.handle(t, json.dumps(p).encode() if not isinstance(p, str) else p.encode())
send(B+'Temp-Balkon', {"battery":100,"humidity":45.48,"last_seen":"2026-09-01T11:16:21.138Z","linkquality":68,"temperature":24.77})
send(B+'bridge/state', {"state":"online"})
send(B+'bridge/info', {"version":"2.13.0","coordinator":{"type":"EmberZNet","ieee_address":"0x00","meta":{"revision":"8.0.2"}},"network":{"channel":25,"pan_id":40435},"permit_join":False})
devices = [
 {"ieee_address":"0x0000","type":"Coordinator","friendly_name":"Coordinator"},
 {"ieee_address":"0xc02cedfffe2c7248","type":"EndDevice","friendly_name":"Temp-Balkon","power_source":"Battery","model_id":"SBHT-203C","manufacturer":"Shelly",
  "definition":{"model":"SBHT-203C","vendor":"Shelly","description":"Humidity & temperature sensor","exposes":[
    {"access":5,"category":"diagnostic","label":"Battery","name":"battery","property":"battery","type":"numeric","unit":"%"},
    {"access":5,"label":"Temperature","name":"temperature","property":"temperature","type":"numeric","unit":"°C","description":"Measured temperature value"},
    {"access":5,"label":"Humidity","name":"humidity","property":"humidity","type":"numeric","unit":"%"},
    {"access":1,"label":"Linkquality","name":"linkquality","property":"linkquality","type":"numeric","unit":"lqi"}]}},
 {"ieee_address":"0xc02cedfffe4979aa","type":"EndDevice","friendly_name":"Button","definition":{"model":"SBBT-102C","vendor":"Shelly","description":"BLU Button Tough 1 ZB","exposes":[{"type":"enum","name":"action","property":"action","values":["single","double","long"]},{"property":"battery","type":"numeric","unit":"%","label":"Battery"}]}},
]
send(B+'bridge/devices', devices)
send(B+'Button', {"action":"single","battery":100,"linkquality":112})
send(B+'Button/availability', {"state":"online"})
send(B+'Temp-Balkon/availability', "offline")
send(B+'Temp-Balkon', {"temperature":25.1,"humidity":40.0,"battery":12,"linkquality":30})
send('shellies/ht-temp/status/temperature:0', {"id":0,"tC":22.4,"tF":72.3})
send('shellies/ht-temp/status/humidity:0', {"id":0,"rh":47.5})
send('shellies/ht-temp/status/devicepower:0', {"id":0,"battery":{"V":2.9,"percent":85},"external":{"present":False}})
send('shellies/plug-lednice/status/switch:0', {"id":0,"output":True,"apower":85.2,"voltage":231.1,"current":0.38,"aenergy":{"total":1234.5,"by_minute":[1,2,3],"minute_ts":1}})
send(B+'bridge/event', {"type":"device_joined","data":{"friendly_name":"X","ieee_address":"0xabc"}})
devices[1]['friendly_name']='Temp-Venek'
send(B+'bridge/devices', devices)
send(B+'Temp-Venek', {"temperature":26.0})
st = d.status()
print(json.dumps({k:v for k,v in st.items() if k!='devices'}, indent=1)[:700])
for dev in st['devices']:
    print(dev['name'], dev['id'], dev['level'], dev['reasons'], [ (h['key'], h['value'], h['unit']) for h in dev['headline']], dev['battery'], dev['availability'])
print(d.store.keys_for('0xc02cedfffe2c7248'))
print(d.store.history('0xc02cedfffe2c7248', ['temperature','humidity'], 3600))
for e in d.store.events(20): print(e)
print(d.store.stats())
print('aggregate', d.store.aggregate())
srv = zigmon.ApiServer(d); srv.start(); time.sleep(0.3)
for p in ['/api/status','/api/health','/api/devices','/api/device?name=Temp-Venek','/api/history?device=Temp-Venek&range=6h','/api/events','/api/nope','/api/history?device=zz']:
    c, r = zigmon.api_call(p); print(p, c, str(r)[:160])
c, r = zigmon.api_call('/api/reset','POST',{'scope':'events','pin':'0000'}, token=d.token); print('wrongpin', c, r)
c, r = zigmon.api_call('/api/reset','POST',{'scope':'events','pin':'1234'}, token='bad'); print('badtoken', c, r)
c, r = zigmon.api_call('/api/permit-join','POST',{'enable':True,'pin':'1234'}, token=d.token); print('pj', c, r)
c, r = zigmon.api_call('/api/reset','POST',{'scope':'device','device':'Button','pin':'1234'}, token=d.token); print('reset', c, r)
c, r = zigmon.api_call('/api/devices'); print([x['name'] for x in r['devices']])

# A save whose list is missing or is not a list must be refused, never taken
# as "save nothing": that once emptied every rule in the database.
d.save_rules([{'device': 'Temp-Venek', 'key': 'temperature', 'op': '>=', 'value': 20,
               'plug': 'notify', 'do': 'on', 'enabled': True}])
before = len(d.rules())
# A list of things that are not records is the same accident wearing a list:
# every validator skips what it does not recognise, so [1, 2, 3] cleaned
# itself down to nothing and that nothing was saved over everything.
for body in ({'pin': '1234'}, {'pin': '1234', 'rules': 'nope'}, {'pin': '1234', 'rules': None},
             {'pin': '1234', 'rules': [1, 2, 3]}, {'pin': '1234', 'rules': ['a', 'b']},
             {'pin': '1234', 'rules': [{'device': 'Temp-Venek', 'key': 'temperature', 'op': '>=',
                                        'value': 20, 'plug': 'notify', 'do': 'on'}, 7]}):
    c, r = zigmon.api_call('/api/rules', 'POST', body, token=d.token)
    assert c == 400 and not r.get('ok'), ('a bad save was taken: %r -> %s %r' % (body.get('rules'), c, r))
assert len(d.rules()) == before, 'a refused save changed the rules'
# and emptying it on purpose is still allowed
c, r = zigmon.api_call('/api/rules', 'POST', {'pin': '1234', 'rules': []}, token=d.token)
assert c == 200 and r.get('ok'), 'deleting the last rule was refused'
assert len(d.rules()) == 0
d.save_rules([{'device': 'Temp-Venek', 'key': 'temperature', 'op': '>=', 'value': 20,
               'plug': 'notify', 'do': 'on', 'enabled': True}])
print('guard: a save of anything that is not a list of records is refused, %d rule(s) untouched' % before)

# A sensor group leaves a device behind it; removing the group must remove
# that too, or the lists and every status grow for ever.
probe = d.save_sensor_groups([{'name': 'probe', 'key': 'temperature', 'mode': 'average',
                               'members': ['Temp-Venek']}])[0]
d.refresh_group(probe['members'][0], 'Temp-Venek', {'temperature': 21.0})
made = [x for x in d.store.devices() if str(x['id']).startswith('grp:')]
d.save_sensor_groups([])
left = [x for x in d.store.devices() if str(x['id']).startswith('grp:')]
assert made and not left, ('group device not swept', made, left)
print('guard: a removed sensor group takes its device with it')


# A target has to be worked out before it can be fired. Twice a caller handed
# _fire_target the name that was written down instead: the answer went out,
# the event said it had been done, and nothing moved.
if not d.plugs:                      # the replay has no sockets of its own
    d.plugs['Probe-Plug'] = zigmon.PlugState('Probe-Plug', {'name': 'Probe-Plug', 'host': '127.0.0.1:19999'})
probe_plug = next(iter(d.plugs.values()), None)
if probe_plug is not None:
    hit = []
    keep_run = d._run_binding
    d._run_binding = lambda p, do, origin, pulse_ms=None, stagger=0.0: hit.append((p.name, do))
    d.save_sms_commands([{'phrase': 'probe', 'target': '*', 'do': 'toggle'}])
    zigmon.CONFIG['sms_allow'] = '+420000000000'
    zigmon.CONFIG['sms_reply'] = False
    d.sms_handle('+420000000000', 'probe')
    time.sleep(0.6)
    d._run_binding = keep_run
    d.save_sms_commands([])
    assert hit, 'an SMS command matched but switched nothing'
    print('guard: an SMS command actually switches its target')

    # The same words from the same number twice: the second lands in the slot
    # the first has just left, and was taken for it and thrown away.
    box, seen_calls = [], []
    def fake_rest(path, method='GET', payload=None, retry=True):
        if path == '/messages/status':
            return list(box)
        if path == '/modems/status':
            return [{'id': '3-1'}]
        if path == '/messages/actions/remove_messages':
            for one in payload['data']['sms_id']:
                for m in list(box):
                    if m['id'] == one:
                        box.remove(m)
        return {}
    keep_rest, keep_ready = getattr(d, '_rest', None), d.sms_ready
    d._rest = fake_rest
    d.sms_ready = lambda: True
    zigmon.CONFIG['sms_api'] = 'rest'
    zigmon.CONFIG['sms_clear_inbox'] = True
    d._sms_first_look = False
    d._run_binding = lambda p, do, origin, pulse_ms=None, stagger=0.0: seen_calls.append(do)
    d.save_sms_commands([{'phrase': 'probe', 'target': '*', 'do': 'toggle'}])
    for _ in range(2):
        box.append({'id': '1', 'sender': '+420000000000', 'message': 'probe', 'status': 'read'})
        d.sms_poll(force=True)
        time.sleep(0.4)
    d._run_binding = keep_run
    d.sms_ready = keep_ready
    if keep_rest is not None:
        d._rest = keep_rest
    d.save_sms_commands([])
    assert len(seen_calls) == 2, 'the same text twice was acted on %d time(s)' % len(seen_calls)
    print('guard: the same text sent twice is acted on twice')

    # Saying "home" and then "away" used to leave and arrive again: the grace
    # window from the arrival outlived the departure.
    d.save_people([{'name': 'Probe-Person', 'macs': ['aa:bb:cc:dd:ee:ff'], 'enabled': True}])
    who = [p for p in d.people() if p['name'] == 'Probe-Person'][0]
    moves = []
    keep_changed = d._presence_changed
    d._presence_changed = lambda p, home, evs: moves.append('arrive' if home else 'leave')
    def round_without_them():
        with d._wifi_lock:
            moved = d._settle_presence(who, set(), {}, time.time())
        if moved:
            d._presence_changed(who, moved == 'arrive', [moved])
    round_without_them()
    moves[:] = []
    d.presence_report('', 'home', origin='a test', person=who)
    round_without_them(); round_without_them()
    d.presence_report('', 'away', origin='a test', person=who)
    round_without_them(); round_without_them(); round_without_them()
    d._presence_changed = keep_changed
    d.save_people([p for p in d.people() if p['name'] != 'Probe-Person'])
    assert moves == ['arrive', 'leave'], 'home then away gave %r' % (moves,)
    print('guard: saying home then away arrives once and leaves once')

    # Four sockets on one box used to click in a different order every time:
    # each went off on a thread of its own and a Python lock hands itself to
    # whoever happens to wake, not to whoever waited longest.
    for i in range(4):
        d.plugs['Strip-%d' % i] = zigmon.PlugState('Strip-%d' % i,
                                                   {'name': 'Strip-%d' % i, 'host': '127.0.0.1:19998', 'switch_id': i})
    seen = []
    def slow(p, do, origin, pulse_ms=None, stagger=0.0):
        # What has to be in order is the sending: the box acts on them as they
        # arrive. So this notes the moment the command is handed over, then
        # takes its time answering - the last of the strip answering fastest,
        # which is exactly what used to shuffle the order.
        seen.append(p.name)
        n = int(p.name[-1]) if p.name.startswith('Strip-') else 0
        time.sleep(0.04 * max(0, 4 - n))
    d._run_binding = slow
    keep_scenes = d.scenes
    d.scenes = lambda: [{'id': 'strip', 'name': 'Strip', 'actions':
                         [{'target': 'Strip-%d' % i, 'do': 'off', 'after_s': 0} for i in range(4)]}]
    for _ in range(3):
        seen[:] = []
        d.run_scene('strip', 'a test')
        time.sleep(1.1)
        assert seen == ['Strip-0', 'Strip-1', 'Strip-2', 'Strip-3'], 'a strip clicked in the order %r' % (seen,)
    print('guard: the sockets on one box switch in the order they are written')

    # And every other shape of scene: a lone socket beside a strip, a step
    # with a delay of its own, four steps sharing one delay. Grouping the
    # sockets by box once broke the delayed ones altogether - they were put
    # in a list nobody read again.
    d.plugs['Lone'] = zigmon.PlugState('Lone', {'name': 'Lone', 'host': '127.0.0.1:19996'})
    def shape(name, actions, want):
        seen[:] = []
        d.scenes = lambda: [{'id': 'x', 'name': name, 'actions': actions}]
        d.run_scene('x', 'a test')
        time.sleep(2.0)
        got = [n for n in seen]
        assert sorted(got) == sorted(want), '%s: switched %r, wanted %r' % (name, got, want)
        strip = [n for n in got if n.startswith('Strip-')]
        assert strip == sorted(strip), '%s: the strip went %r' % (name, strip)
    shape('a lone socket beside a strip',
          [{'target': 'Strip-%d' % i, 'do': 'on', 'after_s': 0} for i in range(4)]
          + [{'target': 'Lone', 'do': 'on', 'after_s': 0}],
          ['Strip-0', 'Strip-1', 'Strip-2', 'Strip-3', 'Lone'])
    shape('one now and one later',
          [{'target': 'Strip-0', 'do': 'on', 'after_s': 0}, {'target': 'Strip-1', 'do': 'off', 'after_s': 0.3}],
          ['Strip-0', 'Strip-1'])
    shape('four sharing one delay',
          [{'target': 'Strip-%d' % i, 'do': 'off', 'after_s': 0.3} for i in range(4)],
          ['Strip-0', 'Strip-1', 'Strip-2', 'Strip-3'])
    # Four sockets told to toggle used to flip one by one, so once they were
    # out of step they stayed out of step for ever.
    for i in range(4):
        d.plugs['Strip-%d' % i].output = (i == 0)          # one on, three off
    seen[:] = []
    told = []
    d._run_binding = lambda p, do, origin, pulse_ms=None, stagger=0.0: told.append((p.name, do))
    d.scenes = lambda: [{'id': 'flip', 'name': 'Flip',
                         'actions': [{'target': 'Strip-%d' % i, 'do': 'toggle', 'after_s': 0} for i in range(4)]}]
    d.run_scene('flip', 'a button')
    time.sleep(0.8)
    assert told and all(do == 'off' for _, do in told), 'a mixed strip toggled to %r' % (told,)
    for i in range(4):
        d.plugs['Strip-%d' % i].output = False
    told[:] = []
    d.run_scene('flip', 'a button')
    time.sleep(0.8)
    assert told and all(do == 'on' for _, do in told), 'a strip all off toggled to %r' % (told,)
    d.scenes = keep_scenes
    d._run_binding = keep_run
    print('guard: every shape of scene switches everything it names, in order')
    print('guard: toggling a strip moves all of it the same way')

    # And a scene that mixes them: sockets from one box, sockets of their own,
    # and a Zigbee light, all toggling. Whatever is on decides for the rest.
    d.plugs['Lone-B'] = zigmon.PlugState('Lone-B', {'name': 'Lone-B', 'host': '127.0.0.1:19995'})
    # a light of our own, so this does not depend on what the database holds
    d.store.upsert_device({'id': '0xfeedface', 'name': 'Probe-Light', 'source': 'zigbee', 'kind': 'Light',
                           'vendor': 'test', 'model': 'probe', 'last_seen': int(time.time()),
                           'exposes': {'state': {'access': 3, 'type': 'binary', 'values': ['ON', 'OFF'],
                                                 'label': 'State', 'unit': '', 'category': '',
                                                 'min': None, 'max': None}}})
    light = next((t['value'] for t in d.zigbee_targets() if t['value'].endswith(':state')), None)
    assert light, 'the probe light was not offered as a target'
    if light:
        head = light.split(':')[1]
        d.live.setdefault(head, {})['payload'] = {'state': 'ON'}
        for i in range(4):
            d.plugs['Strip-%d' % i].output = False
        d.plugs['Lone'].output = False
        d.plugs['Lone-B'].output = False
        told[:] = []
        d._run_binding = lambda p, do, origin, pulse_ms=None, stagger=0.0: told.append((p.name, do))
        keep_zb = d._run_zigbee_switch
        d._run_zigbee_switch = lambda dev, key, do, origin, pulse_ms=None: told.append(('light', do))
        d.scenes = lambda: [{'id': 'mix', 'name': 'Mixed', 'actions':
                             [{'target': 'Strip-%d' % i, 'do': 'toggle', 'after_s': 0} for i in (0, 1, 2)]
                             + [{'target': 'Lone', 'do': 'toggle', 'after_s': 0},
                                {'target': 'Lone-B', 'do': 'toggle', 'after_s': 0},
                                {'target': light, 'do': 'toggle', 'after_s': 0}]}]
        d.run_scene('mix', 'a button')
        time.sleep(1.0)
        d._run_zigbee_switch = keep_zb
        d.scenes = keep_scenes
        d._run_binding = keep_run
        assert len(told) == 6, 'six things were named, %d moved: %r' % (len(told), told)
        assert all(do == 'off' for _, do in told), 'a mixed scene went %r' % (told,)
        print('guard: a scene mixing boxes, lone sockets and a light moves as one')

    # A small box answers 429 when asked too often, and a command that then
    # slept two seconds - logged only at debug - was the lag nobody could see.
    # Four sockets switched together must not need more than one confirming
    # read of the box, and a command told 429 must not sleep for long.
    told = []
    class Limited(object):
        def __init__(self):
            self.hits = []
        def call(self, method, params=None):
            now = time.time()
            self.hits[:] = [h for h in self.hits if now - h < 1.0]
            self.hits.append(now)
            told.append(method)
            return {}
    box = Limited()
    reads = []
    keep_poll = d.poll_plug
    d.poll_plug = lambda p, force=False: reads.append(time.time())
    for i in range(4):
        d.plugs['Strip-%d' % i].rpc = lambda box=box: box
    d._run_binding = keep_run
    d.plugs['Strip-0'].output = True
    keep_set = d.set_plug_output
    d.set_plug_output = lambda p, on, origin='the dashboard': (d._plug_switched(p, on, origin), (True, 'ok'))[1]
    d.scenes = lambda: [{'id': 'lim', 'name': 'Limited',
                         'actions': [{'target': 'Strip-%d' % i, 'do': 'toggle', 'after_s': 0} for i in range(4)]}]
    reads[:] = []
    d.run_scene('lim', 'a button')
    time.sleep(1.2)
    d.set_plug_output = keep_set
    d.poll_plug = keep_poll
    d.scenes = keep_scenes
    assert len(reads) <= 1, 'four switches led to %d confirming reads of one box' % len(reads)
    print('guard: four sockets switched together are confirmed with one read of the box')

    # "all sockets" must not take the lights with it, nor the other way round.
    d.plugs['Lamp-1'] = zigmon.PlugState('Lamp-1', {'name': 'Lamp-1', 'host': '127.0.0.1:19994', 'role': 'light'})
    d.plugs['Lamp-2'] = zigmon.PlugState('Lamp-2', {'name': 'Lamp-2', 'host': '127.0.0.1:19993', 'role': 'light'})
    sockets = [t[1].name for t in d._binding_targets('*')]
    lamps = [t[1].name for t in d._binding_targets('*lights')]
    assert 'Lamp-1' in lamps and 'Lamp-2' in lamps, 'the lights were not found: %r' % (lamps,)
    assert not [n for n in sockets if n.startswith('Lamp-')], '"all sockets" took a light: %r' % (sockets,)
    assert not [n for n in lamps if not n.startswith('Lamp-')], '"all lights" took a socket: %r' % (lamps,)
    assert sockets, '"all sockets" found nothing'
    print('guard: all sockets and all lights keep to their own')

srv.stop()
