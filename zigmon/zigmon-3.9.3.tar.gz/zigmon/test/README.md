# Development checks

Nothing here ships to the server.

* `replay.py` — feeds the daemon real Zigbee2MQTT and Shelly messages without
  a broker, then exercises every API endpoint including wrong PIN and token.
  Run with a scratch configuration:

      cat > /tmp/zt.json <<'JSON'
      {"db_file": "/tmp/zt.db", "token_file": "/tmp/zt-token", "log_file": "/tmp/zt.log",
       "api_port": 19849, "pin": "1234", "sample_interval": 0, "log_to_journal": false}
      JSON
      ZIGMON_CONFIG=/tmp/zt.json PYTHONPATH=. python3 test/replay.py

* `render.js` — drives the dashboard in jsdom against a running daemon and
  `php -S 127.0.0.1:8099 -t web`, walks every tab, renders the charts, goes
  through the PIN dialogue and reports any JavaScript error.

      npm install jsdom && node test/render.js

* `mockplug.py PORT [PASSWORD]` — a Shelly Plug M Gen3 lookalike: `/rpc` with
  SHA-256 digest authentication, a switch, counters and resets. Point a plug
  entry at `127.0.0.1:PORT` to exercise polling, switching, resets and
  button bindings without hardware.

## endpoints.py

`python3 test/endpoints.py` — every `/api/...` path the web relay forwards
must be one the daemon serves, and in the branch that matches the method.
Needs nothing running; it reads the two files. It exists because *Put back*
once shipped answering "no such endpoint": the handler had been written into
the read branch while the page posted to it.

## mocksms.py

`python3 test/mocksms.py 18110 [user] [password]` — a Teltonika-lookalike SMS
gateway: `/cgi-bin/sms_send`, `/cgi-bin/sms_list`, `/cgi-bin/sms_delete` with
the same query parameters and the same plain-text listing. `GET /` returns
what it was asked to send, `POST /inbox {"from":…,"text":…}` puts a message
in for the daemon to find, `POST /reset` empties both. Enough to test alerts
going out and commands coming in without a SIM card.

## facts.py

`python3 test/facts.py` — every `{fact}` the daemon fills must appear in the
page's picker, and every one the picker offers must be filled. The two drifted
apart once: the picker advertised `{sunrise}`, `{sunset}` and `{daylight}`
while the daemon filled none of them, so a message quoting them arrived with
the words simply missing.

## version.py

`python3 test/version.py` — zigmon.py, install.sh and README.md must state
the same version. They drifted apart once: a release script replaced a string
that had moved, said nothing about it, and several releases went out carrying
an old number inside a differently named file.

`mocksms.py` also speaks RutOS 7's own API — `/api/login`, `/api/modems/status`,
`/api/modems/signal/status`, `/api/messages/status`,
`/api/messages/actions/send` — with the same rules the device enforces: a
Bearer token that expires, a required `modem` field, and a number that must
carry its country code behind a `+`. That is what a TRB140 offers out of the
box, so it is what the tests use.

`zigmon --check-sms` walks the whole road to the gateway — the settings, the
device, the SIM, the signal, who would be told, who may command, what a text
may do, and whether anything is stuck — and ends with a list of what to do
about whatever failed.

## inputs.py

`python3 test/inputs.py` — every setting the page draws must be the kind of
box the daemon says it is. The page used to keep its own idea of which
settings were yes-or-no questions and fell behind, so two were drawn as number
boxes asking for a 1 or a 0.
