<?php
/**
 * index.php — sensor dashboard.
 *
 * Renders from the daemon's snapshot and refreshes itself over the small JSON
 * endpoints below. It does nothing privileged: no shell, no broker
 * credentials, no direct access to MQTT.
 */
declare(strict_types=1);

// The whole dashboard - markup and JavaScript alike - is this one file. A
// browser (or an intermediate proxy/CDN) caching an old copy of it is
// exactly how a fixed bug can keep reappearing after an upgrade: the daemon
// answers with the new behaviour, but the tab is still running yesterday's
// JavaScript. Force a revalidation on every load so that never happens.
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');

require_once __DIR__ . '/zigmon-api.php';

/**
 * PHP falls back to UTC when date.timezone isn't set, which makes every
 * timestamp here disagree with the server's own clock. Follow the system zone.
 */
function use_system_timezone(): void
{
    $set = (string) ini_get('date.timezone');
    if ($set !== '' && strcasecmp($set, 'UTC') !== 0) {
        return;
    }
    $tz = '';
    if (is_readable('/etc/timezone')) {
        $tz = trim((string) @file_get_contents('/etc/timezone'));
    }
    if ($tz === '' && is_link('/etc/localtime')) {
        $target = (string) @readlink('/etc/localtime');
        if (preg_match('#zoneinfo/(.+)$#', $target, $m)) {
            $tz = $m[1];
        }
    }
    if ($tz !== '' && in_array($tz, timezone_identifiers_list(), true)) {
        date_default_timezone_set($tz);
    }
}
use_system_timezone();

// ---- JSON endpoints the page polls ---------------------------------------
// The short form of a one-tap link: ?t=TOKEN, with no api= in front of it.
// Every character in an address is one more thing that can be mistyped or
// changed by a phone's autocorrect on the way into Shortcuts, and this shape
// has one = and nothing else.
if (isset($_GET['t']) && !isset($_GET['api'])) {
    $token = (string) $_GET['t'];
    header('Content-Type: application/json; charset=utf-8');
    if (!preg_match('/^[A-Za-z0-9_-]{8,64}$/', $token)) {
        http_response_code(400);
        // saying what arrived turns "no link given" into one question rather
        // than three: an empty one means the web server dropped it on the way
        echo json_encode(['ok' => false, 'error' => $token === ''
            ? 'no link in the address. If this came through /tap/, the web server did not pass the '
              . 'token on - check the rewrite line in the nginx file.'
            : 'that is not the shape of a link']);
        exit;
    }
    // ?ask has to travel the whole way: dropped here, asking how things stand
    // becomes switching them, which is the opposite of what was asked
    zigmon_relay('/api/tap/' . rawurlencode($token) . (isset($_GET['ask']) ? '?ask' : ''));
    exit;
}

if (isset($_GET['api'])) {
    $what = (string) $_GET['api'];

    if ($what === 'status') {
        zigmon_relay('/api/status');
        exit;
    }
    if ($what === 'health') {
        zigmon_relay('/api/health');
        exit;
    }
    if ($what === 'mqtt-acl') {
        zigmon_relay('/api/mqtt/acl');
        exit;
    }
    if ($what === 'sms-log') {
        $limit = max(1, min(500, (int) ($_GET['limit'] ?? 200)));
        zigmon_relay('/api/sms/log?limit=' . $limit);
        exit;
    }
    if ($what === 'sms-incoming') {
        /* the gateway forwards a message here; its own word is the only
           credential it has, and the daemon checks it */
        $qs = $_SERVER['QUERY_STRING'] ?? '';
        zigmon_relay('/api/sms/incoming?' . $qs);
        exit;
    }
    if ($what === 'sms-commands' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        zigmon_relay('/api/sms/commands');
        exit;
    }
    if ($what === 'sensor-groups' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        zigmon_relay('/api/sensor-groups');
        exit;
    }
    if ($what === 'action-groups' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        zigmon_relay('/api/action-groups');
        exit;
    }
    if ($what === 'battery-health') {
        zigmon_relay('/api/battery-health');
        exit;
    }
    if ($what === 'weather') {
        zigmon_relay('/api/weather');
        exit;
    }
    if ($what === 'snapshots') {
        zigmon_relay('/api/snapshots');
        exit;
    }
    if ($what === 'routes') {
        zigmon_relay('/api/routes');
        exit;
    }
    if ($what === 'device') {
        $id = (string) ($_GET['id'] ?? '');
        zigmon_relay('/api/device?id=' . rawurlencode($id));
        exit;
    }
    if ($what === 'history') {
        $device = (string) ($_GET['device'] ?? '');
        $range  = preg_replace('/[^0-9smhdwy.]/', '', (string) ($_GET['range'] ?? '24h'));
        $points = max(50, min(3000, (int) ($_GET['points'] ?? 600)));
        $keys   = preg_replace('/[^A-Za-z0-9_.,:-]/', '', (string) ($_GET['keys'] ?? ''));
        zigmon_relay('/api/history?device=' . rawurlencode($device) . '&range=' . rawurlencode($range)
                     . '&points=' . $points . ($keys !== '' ? '&keys=' . rawurlencode($keys) : ''),
                     'GET', null, 30.0);
        exit;
    }
    if ($what === 'history-multi') {
        $range  = preg_replace('/[^0-9smhdwy.]/', '', (string) ($_GET['range'] ?? '24h'));
        $points = max(50, min(2000, (int) ($_GET['points'] ?? 400)));
        $items  = preg_replace('/[^A-Za-z0-9_.,:|;-]/', '', (string) ($_GET['items'] ?? ''));
        zigmon_relay('/api/history-multi?range=' . rawurlencode($range) . '&points=' . $points
                     . '&items=' . rawurlencode($items), 'GET', null, 30.0);
        exit;
    }
    if ($what === 'presence-report') {
        // What a phone's shortcut calls. The token in the request is the whole
        // credential, so no PIN and no session - GET is allowed too, because a
        // handset automation is easiest to set up as a plain URL.
        $sent = $_REQUEST;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $posted = json_decode((string) file_get_contents('php://input'), true);
            if (is_array($posted)) { $sent = $posted + $sent; }
        }
        $token = preg_replace('/[^A-Za-z0-9_-]/', '', (string) ($sent['token'] ?? ''));
        $state = preg_replace('/[^a-z]/', '', strtolower((string) ($sent['state'] ?? '')));
        zigmon_relay('/api/presence/report', 'POST', ['token' => $token, 'state' => $state], 15.0);
        exit;
    }
    if ($what === 'message-preview') {
        $title = substr((string) ($_GET['title'] ?? ''), 0, 400);
        $text  = substr((string) ($_GET['text'] ?? ''), 0, 4000);
        zigmon_relay('/api/message-preview?title=' . rawurlencode($title) . '&text=' . rawurlencode($text));
        exit;
    }
    if ($what === 'events') {
        $q     = substr((string) ($_GET['q'] ?? ''), 0, 120);
        $kind  = preg_replace('/[^a-z]/', '', (string) ($_GET['kind'] ?? ''));
        $level = preg_replace('/[^a-z]/', '', (string) ($_GET['level'] ?? ''));
        $limit = max(1, min(1000, (int) ($_GET['limit'] ?? 200)));
        $device = (string) ($_GET['device'] ?? '');
        zigmon_relay('/api/events?limit=' . $limit
                     . ($device !== '' ? '&device=' . rawurlencode($device) : '')
                     . ($q     !== '' ? '&q='      . rawurlencode($q)     : '')
                     . ($kind  !== '' ? '&kind='   . rawurlencode($kind)  : '')
                     . ($level !== '' ? '&level='  . rawurlencode($level) : ''));
        exit;
    }
    if ($what === 'plugs') {
        zigmon_relay('/api/plugs');
        exit;
    }
    if ($what === 'plug') {
        $name = (string) ($_GET['name'] ?? '');
        zigmon_relay('/api/plug?name=' . rawurlencode($name) . (!empty($_GET['refresh']) ? '&refresh=1' : ''), 'GET', null, 20.0);
        exit;
    }
    if ($what === 'bindings') {
        zigmon_relay('/api/bindings');
        exit;
    }
    if ($what === 'managed') {
        zigmon_relay('/api/managed');
        exit;
    }
    if ($what === 'rules') {
        zigmon_relay('/api/rules');
        exit;
    }
    if ($what === 'order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $list = function (string $key) use ($in): array {
            return array_values(array_map('strval', (is_array($in) && isset($in[$key]) && is_array($in[$key])) ? $in[$key] : []));
        };
        $body = [
            'plugs'   => $list('plugs'),
            'devices' => $list('devices'),
            'sensors' => $list('sensors'),
            'buttons' => $list('buttons'),
            'rooms'   => $list('rooms'),
        ];
        // per-strip channel order: {host: [names...]}
        if (is_array($in) && isset($in['groups']) && is_array($in['groups'])) {
            $groups = [];
            foreach ($in['groups'] as $host => $names) {
                if (is_array($names)) {
                    $groups[(string) $host] = array_values(array_map('strval', $names));
                }
            }
            $body['groups'] = (object) $groups;   // {} even when empty, never []
        }
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/order', 'POST', $body, 10.0);
        exit;
    }
    if ($what === 'rename' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['id' => (string) ($in['id'] ?? ''), 'name' => (string) ($in['name'] ?? '')];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/device/rename', 'POST', $body, 15.0);
        exit;
    }
    if ($what === 'scenes') {
        zigmon_relay('/api/scenes');
        exit;
    }
    if ($what === 'schedules') {
        zigmon_relay('/api/schedules');
        exit;
    }
    if ($what === 'sequences') {
        zigmon_relay('/api/sequences');
        exit;
    }
    if ($what === 'log') {
        $lines = (int) ($_GET['lines'] ?? 60);
        $since = (string) ($_GET['since'] ?? '');
        zigmon_relay('/api/log?lines=' . $lines . '&since=' . rawurlencode($since));
        exit;
    }
    if ($what === 'db-backups') {
        zigmon_relay('/api/db/backups');
        exit;
    }
    if ($what === 'wifi-sshkey-download') {
        // the private half, once, as a file; the session token proves the right to it
        $session = (string) ($_GET['session'] ?? '');
        if ($session === '') {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad request']);
            exit;
        }
        $url = 'http://' . ZIGMON_HOST . ':' . ZIGMON_PORT . '/api/wifi/sshkey/download?session=' . rawurlencode($session);
        $fh = @fopen($url, 'rb', false, stream_context_create(['http' => ['timeout' => 30, 'ignore_errors' => true]]));
        if ($fh === false) {
            http_response_code(503);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'the daemon is not responding']);
            exit;
        }
        // the same: a refusal must not arrive as a file with a key's name
        $code = 0;
        foreach (($http_response_header ?? []) as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#', $line, $m)) { $code = (int) $m[1]; }
        }
        if ($code !== 200) {
            fclose($fh);
            http_response_code($code ?: 502);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'refused']);
            exit;
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="zigmon-ap-key"');
        fpassthru($fh);
        fclose($fh);
        exit;
    }
    if ($what === 'mikrotik-key-download') {
        // the same road the access points' key takes
        $session = (string) ($_GET['session'] ?? '');
        if ($session === '') {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad request']);
            exit;
        }
        $url = 'http://' . ZIGMON_HOST . ':' . ZIGMON_PORT
             . '/api/mikrotik/key/download?session=' . rawurlencode($session);
        $fh = @fopen($url, 'rb', false, stream_context_create(['http' => ['timeout' => 30, 'ignore_errors' => true]]));
        if ($fh === false) {
            http_response_code(503);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'the daemon is not responding']);
            exit;
        }
        // What the daemon answered, not merely that it answered: a refusal
        // came through as a file called zigmon-mikrotik-key holding the words
        // "view locked", which is a download that looks like a key.
        $code = 0;
        foreach (($http_response_header ?? []) as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#', $line, $m)) { $code = (int) $m[1]; }
        }
        if ($code !== 200) {
            fclose($fh);
            http_response_code($code ?: 502);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'refused']);
            exit;
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="zigmon-mikrotik-key"');
        fpassthru($fh);
        fclose($fh);
        exit;
    }
    if ($what === 'db-backup-download') {
        // raw bytes straight through; the session token proves the right to read it
        $file = (string) ($_GET['file'] ?? '');
        $session = (string) ($_GET['session'] ?? '');
        if (!preg_match('/^zigmon-db-[0-9A-Za-z._-]+\.sqlite$/', $file) || $session === '') {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad request']);
            exit;
        }
        $url = 'http://' . ZIGMON_HOST . ':' . ZIGMON_PORT . '/api/db/backup/download?file=' . rawurlencode($file) . '&session=' . rawurlencode($session);
        $fh = @fopen($url, 'rb', false, stream_context_create(['http' => ['timeout' => 120, 'ignore_errors' => true]]));
        if ($fh === false) {
            http_response_code(503);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'the daemon is not responding']);
            exit;
        }
        $status = 0;
        foreach (($http_response_header ?? []) as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) { $status = (int) $m[1]; }
        }
        if ($status !== 200) {
            http_response_code($status ?: 502);
            header('Content-Type: application/json');
            fpassthru($fh);
            exit;
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Cache-Control: no-store');
        fpassthru($fh);
        fclose($fh);
        exit;
    }
    if ($what === 'energy') {
        zigmon_relay('/api/energy');
        exit;
    }
    // These three are read with a GET and worked with by a POST, and the
    // reading branch stood in front of the POST routing: every press went out
    // as a GET, was refused because a GET of them wants the PIN in a session
    // rather than in a body, and the page asked for the PIN again, and again.
    if ($what === 'approvals' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $ask = [];
        if (isset($_GET['q']) && $_GET['q'] !== '') {
            $ask[] = 'q=' . rawurlencode(substr((string) $_GET['q'], 0, 80));
        }
        if (isset($_GET['state']) && preg_match('/^[a-z]{1,12}$/', (string) $_GET['state'])) {
            $ask[] = 'state=' . $_GET['state'];
        }
        $ask[] = 'limit=' . max(1, min(2000, (int) ($_GET['limit'] ?? 200)));
        zigmon_relay('/api/approvals?' . implode('&', $ask));
        exit;
    }
    if ($what === 'scripts' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        zigmon_relay('/api/scripts');
        exit;
    }
    if ($what === 'mikrotik' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        zigmon_relay('/api/mikrotik');
        exit;
    }
    if ($what === 'blocked' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['format']) && $_GET['format'] === 'mikrotik') {
            zigmon_relay('/api/blocked?format=mikrotik');
            exit;
        }
        $ask = ['limit=' . max(1, min(2000, (int) ($_GET['limit'] ?? 400)))];
        if (isset($_GET['q']) && $_GET['q'] !== '') {
            $ask[] = 'q=' . rawurlencode(substr((string) $_GET['q'], 0, 80));
        }
        zigmon_relay('/api/blocked?' . implode('&', $ask));
        exit;
    }
    if ($what === 'wifi-seen') {
        zigmon_relay('/api/wifi/seen');
        exit;
    }
    // A one-tap link, as a watch or a phone shortcut opens it. No PIN and no
    // session: the link's own secret is its whole authority, and it does one
    // named thing. Kept here so the watch talks to nginx over https rather
    // than to the daemon directly.
    if ($what === 'tap') {
        // The header road: the secret travels in X-Zigmon-Tap on a POST, where
        // no access log, no link-preview fetcher and no browser history can
        // keep it. Nothing of the request is taken but those two headers.
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ask = json_decode((string) file_get_contents('php://input'), true);
            // a press that has to be approved comes back for its answer on
            // the same address, and waits there rather than asking again and
            // again, so the relay is given longer than a press needs
            $ticket = preg_replace('/[^A-Za-z0-9_-]/', '', substr((string) ($_SERVER['HTTP_X_ZIGMON_WAIT'] ?? ''), 0, 40));
            $body = [];
            if (is_array($ask) && !empty($ask['ask'])) { $body['ask'] = true; }
            if (is_array($ask) && array_key_exists('wait', $ask)) { $body['wait'] = (bool) $ask['wait']; }
            // a press that somebody has to approve is answered when they do,
            // so the relay is given longer than a press needs
            // Every one of these is written into a header line joined with
            // CRLF, and every one of them comes from the internet. A value
            // carrying a carriage return would end its line and start one of
            // its own - X-Zigmon-Client, say, which decides whose guesses are
            // being counted. Servers in front strip those, which is a reason
            // to be careful and not a reason to rely on it: each is cut down
            // to the letters it is allowed to have.
            $secret = preg_replace('/[^A-Za-z0-9_-]/', '', substr((string) ($_SERVER['HTTP_X_ZIGMON_TAP'] ?? ''), 0, 120));
            $code   = preg_replace('/\D/', '', substr((string) ($_SERVER['HTTP_X_ZIGMON_CODE'] ?? ''), 0, 16));
            zigmon_relay('/api/tap', 'POST', $body, 100.0,
                         ['X-Zigmon-Tap: ' . $secret,
                          'X-Zigmon-Code: ' . $code,
                          'X-Zigmon-Wait: ' . $ticket]);
            exit;
        }
        $token = isset($_GET['t']) ? (string) $_GET['t'] : '';
        if ($token === '' || !preg_match('/^[A-Za-z0-9_-]{8,64}$/', $token)) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'no link given']);
            exit;
        }
        // ?ask has to travel the whole way: dropped here, asking how things stand
    // becomes switching them, which is the opposite of what was asked
    zigmon_relay('/api/tap/' . rawurlencode($token) . (isset($_GET['ask']) ? '?ask' : ''));
        exit;
    }
    if ($what === 'tap-preview') {
        zigmon_relay('/api/tap-preview?target=' . rawurlencode((string) ($_GET['target'] ?? ''))
            . '&do=' . rawurlencode((string) ($_GET['do'] ?? 'toggle')));
        exit;
    }
    if ($what === 'tell') {
        zigmon_relay('/api/tell?what=' . rawurlencode((string) ($_GET['what'] ?? 'house')));
        exit;
    }
    if ($what === 'zigbee-bindings') {
        zigmon_relay('/api/zigbee/bindings');
        exit;
    }
    if ($what === 'power-series') {
        zigmon_relay('/api/power-series?range=' . rawurlencode((string) ($_GET['range'] ?? '24h')));
        exit;
    }
    if ($what === 'energy-daily') {
        zigmon_relay('/api/energy/daily?plug=' . rawurlencode((string) ($_GET['plug'] ?? '')) );
        exit;
    }
    if ($what === 'export') {
        // the secrets go only when asked for, and only as a plain yes
        zigmon_relay('/api/export' . (isset($_GET['secrets']) && $_GET['secrets'] === '1'
                                      ? '?secrets=1' : ''));
        exit;
    }
    if (in_array($what, ['scenes-save', 'scene-run', 'notify-save', 'notify-test', 'import', 'energy-reset', 'config-save', 'rule-dryrun', 'sessions', 'lock-all', 'backup-run', 'schedules-save', 'overview-layout-save', 'gateways-save', 'sequences-save', 'sequence-advance', 'sequence-reset', 'db-check', 'db-optimize', 'db-backup', 'db-restore', 'plug-detect', 'gateway-detect', 'db-backup-delete', 'db-backup-upload', 'db-prune', 'db-stale', 'db-stale-drop', 'ghosts', 'ghosts-clear',
                       'wifi-config', 'wifi-test', 'wifi-clients', 'people', 'presence-triggers', 'messages', 'alerts-clear', 'hold-release',
                       'wifi-detail', 'wifi-order', 'wifi-sshkey', 'target-set', 'person-token',
                       'rooms-save', 'wifi-forget', 'heating-save', 'monthly', 'heat-calibrate', 'groups-save', 'plug-mqtt-setup', 'plug-mqtt-test', 'snapshot-restore', 'snapshot-drop', 'sensor-groups', 'action-groups', 'sms-commands', 'sms-test', 'sms-send', 'sms-poll', 'sms-try', 'sms-forget', 'sms-raw', 'modem-status', 'modem-reset-data', 'sms-ussd', 'acl-mend', 'zigbee-configure', 'zigbee-forget', 'zigbee-reload', 'taps-save', 'taps-address', 'taps-keys', 'taps-duo-test', 'secrets', 'approvals-stop', 'blocked', 'mikrotik', 'scripts', 'zigbee-baseline', 'what-if', 'plug-diagnose', 'outbox-drop', 'outbox-flush'], true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $paths = ['target-set' => '/api/target/set', 'person-token' => '/api/people/token',   /* target-set carries hold_s for a room */
                  'rooms-save' => '/api/rooms', 'heating-save' => '/api/heating',   /* away_from / away_to ride along */ 'monthly' => '/api/energy/monthly',
                  'heat-calibrate' => '/api/heating/calibrate', 'groups-save' => '/api/groups', 'plug-mqtt-setup' => '/api/plug/mqtt-setup', 'plug-mqtt-test' => '/api/plug/mqtt-test',
                  'snapshot-restore' => '/api/snapshots/restore', 'snapshot-drop' => '/api/snapshots/drop',
                  'sensor-groups' => '/api/sensor-groups', 'action-groups' => '/api/action-groups',
                  'sms-commands' => '/api/sms/commands', 'sms-test' => '/api/sms/test',
                  'wifi-forget' => '/api/wifi/forget', 'sms-send' => '/api/sms/send', 'sms-poll' => '/api/sms/poll', 'sms-try' => '/api/sms/try', 'sms-raw' => '/api/sms/raw', 'modem-status' => '/api/modem/status', 'modem-reset-data' => '/api/modem/reset-data', 'sms-ussd' => '/api/modem/ussd', 'acl-mend' => '/api/mqtt/acl/mend',
                  'zigbee-configure' => '/api/zigbee/configure',
                  'zigbee-forget' => '/api/zigbee/bindings/forget',
                  'taps-save' => '/api/taps', 'taps-address' => '/api/taps/address',
                  'taps-keys' => '/api/taps/keys', 'taps-duo-test' => '/api/taps/duo-test',
                  'secrets' => '/api/secrets', 'approvals-stop' => '/api/approvals/stop',
                  'blocked' => '/api/blocked', 'mikrotik' => '/api/mikrotik',
                  'scripts' => '/api/scripts',
                  'zigbee-reload' => '/api/zigbee/bindings/reload',
                  'zigbee-baseline' => '/api/zigbee/baseline',
                  'what-if' => '/api/what-if', 'plug-diagnose' => '/api/plug/diagnose',
                  'outbox-drop' => '/api/sms/outbox/drop', 'outbox-flush' => '/api/sms/outbox/flush',
                  'sms-forget' => '/api/sms/forget',
                  'scenes-save' => '/api/scenes', 'scene-run' => '/api/scene/run',
                  'notify-save' => '/api/notify', 'notify-test' => '/api/notify/test', 'import' => '/api/import',
                  'energy-reset' => '/api/energy/reset', 'config-save' => '/api/config',
                  'rule-dryrun' => '/api/rule/dryrun', 'sessions' => '/api/sessions', 'lock-all' => '/api/lock-all',
                  'backup-run' => '/api/backup/run', 'schedules-save' => '/api/schedules',
                  'overview-layout-save' => '/api/overview-layout', 'gateways-save' => '/api/gateways', 'plug-detect' => '/api/plug/detect', 'gateway-detect' => '/api/gateway/detect',
                  'sequences-save' => '/api/sequences', 'sequence-advance' => '/api/sequence/advance',
                  'sequence-reset' => '/api/sequence/reset', 'db-check' => '/api/db/check',
                  'db-optimize' => '/api/db/optimize', 'db-prune' => '/api/db/prune',
                  'db-stale' => '/api/db/stale', 'db-stale-drop' => '/api/db/stale/drop',
                  'ghosts' => '/api/mqtt/ghosts', 'ghosts-clear' => '/api/mqtt/ghosts/clear',
                  'wifi-config' => '/api/wifi/config', 'wifi-test' => '/api/wifi/test',
                  'wifi-detail' => '/api/wifi/detail', 'wifi-order' => '/api/wifi/order',
                  'wifi-sshkey' => '/api/wifi/sshkey',
                  'wifi-clients' => '/api/wifi/clients', 'people' => '/api/people',
                  'presence-triggers' => '/api/presence/triggers', 'messages' => '/api/messages',
                  'alerts-clear' => '/api/alerts/clear', 'hold-release' => '/api/hold/release', 'db-backup' => '/api/db/backup', 'db-restore' => '/api/db/restore',
                  'db-backup-delete' => '/api/db/backup/delete', 'db-backup-upload' => '/api/db/backup/upload'];
        $body = is_array($in) ? $in : [];
        zigmon_relay($paths[$what], 'POST', $body, strpos($what, 'db-') === 0 ? 180.0 : 30.0);
        exit;
    }
    if ($what === 'manifest') {
        header('Content-Type: application/manifest+json');
        echo json_encode(['name' => 'zigmon', 'short_name' => 'zigmon', 'start_url' => './', 'display' => 'standalone',
            'background_color' => '#0d1117', 'theme_color' => '#0d1117',
            'icons' => [['src' => '?api=icon', 'sizes' => 'any', 'type' => 'image/svg+xml', 'purpose' => 'any']]]);
        exit;
    }
    if ($what === 'icon') {
        header('Content-Type: image/svg+xml');
        echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#0d1117"/><path d="M20 40 28 24l8 12 8-16" fill="none" stroke="#3fb950" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="46" cy="44" r="5" fill="#58a6ff"/></svg>';
        exit;
    }
    if ($what === 'wait') {
        $seq = (int) ($_GET['seq'] ?? 0);
        zigmon_relay('/api/wait?seq=' . $seq . '&timeout=25', 'GET', null, 30.0);
        exit;
    }
    if ($what === 'rules-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $clean = [];
        foreach ((is_array($in) && isset($in['rules']) && is_array($in['rules'])) ? $in['rules'] : [] as $r) {
            if (!is_array($r)) {
                continue;
            }
            $row = [
                'id'         => (string) ($r['id'] ?? ''),
                'group'      => (string) ($r['group'] ?? ''),
                'device'     => (string) ($r['device'] ?? ''),
                'key'        => (string) ($r['key'] ?? ''),
                'op'         => (string) ($r['op'] ?? '>='),
                'value'      => (float) ($r['value'] ?? 0),
                'plug'       => (string) ($r['plug'] ?? ''),
                'do'         => (string) ($r['do'] ?? 'on'),
                'cooldown_s' => (int) ($r['cooldown_s'] ?? 300),
                'from'       => (string) ($r['from'] ?? ''),
                'to'         => (string) ($r['to'] ?? ''),
                'window_end' => (string) ($r['window_end'] ?? ''),
                'for_s'      => (int) ($r['for_s'] ?? 0),
                'back'       => isset($r['back']) && $r['back'] !== '' && $r['back'] !== null ? (float) $r['back'] : null,
                'device2'    => (string) ($r['device2'] ?? ''),
                'device3'    => (string) ($r['device3'] ?? ''),
                'key3'       => (string) ($r['key3'] ?? ''),
                'op3'        => (string) ($r['op3'] ?? '>='),
                'value3'     => $r['value3'] ?? null,
                'combine3'   => (string) ($r['combine3'] ?? 'and'),
                'key2'       => (string) ($r['key2'] ?? ''),
                'op2'        => (string) ($r['op2'] ?? '>='),
                'combine'    => (string) ($r['combine'] ?? 'and'),
                'mode'       => (string) ($r['mode'] ?? 'abs'),
                'when'       => (string) ($r['when'] ?? ''),
                'max_per_hour' => (int) ($r['max_per_hour'] ?? 0),
                'value2'     => isset($r['value2']) && $r['value2'] !== '' && $r['value2'] !== null ? (float) $r['value2'] : null,
                'enabled'    => !isset($r['enabled']) || !empty($r['enabled']),
            ];
            if ($row['do'] === 'pulse') {
                $row['pulse_ms'] = (int) ($r['pulse_ms'] ?? 5000);
            }
            $clean[] = $row;
        }
        $body = ['rules' => $clean];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/rules', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'managed-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['plugs' => [], 'sensors' => []];
        foreach (['plugs', 'sensors'] as $kind) {
            foreach ((is_array($in) && isset($in[$kind]) && is_array($in[$kind])) ? $in[$kind] : [] as $e) {
                if (!is_array($e)) {
                    continue;
                }
                $row = [
                    'name'      => (string) ($e['name'] ?? ''),
                    'host'      => (string) ($e['host'] ?? ''),
                    'switch_id' => (int) ($e['switch_id'] ?? 0),
                    'mqtt_name' => (string) ($e['mqtt_name'] ?? ''),
                    'source'    => (string) ($e['source'] ?? 'ui'),
                    'role'      => (($e['role'] ?? '') === 'light') ? 'light' : 'plug',
                    'group'     => (string) ($e['group'] ?? ''),
                    'mqtt'      => !empty($e['mqtt']),
                    'mqtt_user' => (string) ($e['mqtt_user'] ?? ''),
                    'enabled'   => !isset($e['enabled']) || !empty($e['enabled']),
                'monitor_only' => !empty($e['monitor_only']),
                'host_state'   => (string) ($e['host_state'] ?? 'enabled'),
                'model'        => (string) ($e['model'] ?? ''),
                'mac'          => (string) ($e['mac'] ?? ''),
                ];
                if (isset($e['password']) && $e['password'] !== '') {
                    $row['password'] = (string) $e['password'];
                }
                if (isset($e['mqtt_password']) && $e['mqtt_password'] !== '') {
                    $row['mqtt_password'] = (string) $e['mqtt_password'];
                }
                if (!empty($e['clear_mqtt_password'])) {
                    $row['clear_mqtt_password'] = true;
                }
                if (!empty($e['clear_password'])) {
                    $row['clear_password'] = true;
                }
                $body[$kind][] = $row;
            }
        }
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/managed', 'POST', $body, 30.0);
        exit;
    }
    if ($what === 'managed-test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['host' => (string) ($in['host'] ?? ''), 'password' => (string) ($in['password'] ?? '')];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/managed/test', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'managed-discover' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = [];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/managed/discover', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'plug-switch' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['name' => (string) ($in['name'] ?? '')];
        if (!empty($in['pulse'])) {
            $body['pulse'] = true;
            $body['ms'] = max(100, min(3600000, (int) ($in['ms'] ?? 5000)));
        } elseif (!empty($in['toggle'])) {
            $body['toggle'] = true;
        } else {
            $body['on'] = !empty($in['on']);
        }
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/plug/switch', 'POST', $body, 30.0 + (!empty($body['pulse']) ? $body['ms'] / 1000.0 : 0));
        exit;
    }
    if ($what === 'plug-reset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['name' => (string) ($in['name'] ?? '')];
        $allowed = ['aenergy', 'ret_aenergy', 'on_time', 'switch_on', 'on_above_thr'];
        $body['types'] = (is_array($in) && isset($in['types']) && is_array($in['types']))
            ? array_values(array_intersect($in['types'], $allowed)) : [];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/plug/reset', 'POST', $body, 60.0);
        exit;
    }
    if ($what === 'bindings-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $clean = [];
        foreach ((is_array($in) && isset($in['bindings']) && is_array($in['bindings'])) ? $in['bindings'] : [] as $b) {
            if (!is_array($b)) {
                continue;
            }
            $row = [
                'group'   => (string) ($b['group'] ?? ''),
                'device'  => (string) ($b['device'] ?? ''),
                'action'  => (string) ($b['action'] ?? ''),
                'plug'    => (string) ($b['plug'] ?? ''),
                'do'      => (string) ($b['do'] ?? 'toggle'),
                'hold'    => !empty($b['hold']),
                'enabled' => !isset($b['enabled']) || !empty($b['enabled']),
            ];
            if ($row['do'] === 'pulse') {
                $row['pulse_ms'] = (int) ($b['pulse_ms'] ?? 5000);
            }
            $clean[] = $row;
        }
        $body = ['bindings' => $clean];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/bindings', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'unlock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['pin' => (string) ($in['pin'] ?? ''), 'minutes' => max(1, min(720, (int) ($in['minutes'] ?? 15)))];
        zigmon_relay('/api/unlock', 'POST', $body, 10.0);
        exit;
    }
    if ($what === 'lock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        zigmon_relay('/api/lock', 'POST', ['session' => (string) ($in['session'] ?? '')], 10.0);
        exit;
    }
    if ($what === 'permit-join' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['enable' => !empty($in['enable']), 'time' => 254];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/permit-join', 'POST', $body, 15.0);
        exit;
    }
    if ($what === 'reset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $scope = (string) ($in['scope'] ?? '');
        if (!in_array($scope, ['all', 'history', 'events', 'device'], true)) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad scope']);
            exit;
        }
        $body = ['scope' => $scope];
        if (isset($in['device'])) {
            $body['device'] = (string) $in['device'];
        }
        if (isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/reset', 'POST', $body, 120.0);
        exit;
    }
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'unknown endpoint']);
    exit;
}

// ---- The page ------------------------------------------------------------
$status  = zigmon_get('/api/status', 5.0);
$initial = $status ? json_encode($status, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) : 'null';
$host    = (string) ($_SERVER['HTTP_HOST'] ?? php_uname('n'));

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="manifest" href="?api=manifest">
<meta name="theme-color" content="#0d1117">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="dark">
<title>Sensors — <?= h($host) ?></title>
<link rel="icon" href="favicon.svg" type="image/svg+xml" id="favicon">
<meta name="theme-color" content="#161b22">
<style>
  :root{
    --bg:#0d1117; --panel:#161b22; --panel2:#1c222b; --line:#262c37;
    --tx:#e6e9ef; --tx-dim:#8b94a3; --tx-mut:#5b6472;
    --ok:#3fb950; --warn:#d29922; --crit:#f85149; --info:#58a6ff;
    --batt:#a371f7; --load:#f0883e; --sleep:#6e7681;
    --ok-bg:rgba(63,185,80,.12); --warn-bg:rgba(210,153,34,.12);
    --crit-bg:rgba(248,81,73,.13); --info-bg:rgba(88,166,255,.12);
    --r:14px;
  }
  *{box-sizing:border-box}
  html{-webkit-text-size-adjust:100%}
  body{margin:0;background:var(--bg);color:var(--tx);
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    -webkit-font-smoothing:antialiased;
    padding:26px max(16px,env(safe-area-inset-left)) 56px}
  .wrap{max-width:1280px;margin:0 auto}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}

  header{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:16px}
  header h1{font-size:20px;margin:0;font-weight:650;letter-spacing:.2px}
  header .host{color:var(--tx-dim);font-weight:400}
  .spacer{flex:1}
  .updated{color:var(--tx-mut);font-size:13px;text-align:right;line-height:1.35;cursor:pointer;user-select:none}
  .updated b{color:var(--tx-dim);font-weight:600}
  .updated.paused b{color:var(--warn)}

  .tabs{display:flex;gap:4px;margin-bottom:20px;border-bottom:1px solid var(--line);flex-wrap:wrap}
  .tabs button{appearance:none;background:none;border:0;border-bottom:2px solid transparent;
    color:var(--tx-dim);font:inherit;font-weight:600;font-size:14px;padding:9px 15px;
    cursor:pointer;border-radius:8px 8px 0 0;transition:color .15s,border-color .15s}
  .tabs button:hover{color:var(--tx)}
  .tabs button[aria-selected="true"]{color:var(--info);border-bottom-color:var(--info)}
  .panel[hidden]{display:none}

  .pill{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:999px;
        font-weight:600;font-size:14px;border:1px solid transparent}
  .pill .dot{width:9px;height:9px;border-radius:50%;flex:0 0 auto}
  .pill.ok{background:var(--ok-bg);color:var(--ok);border-color:rgba(63,185,80,.3)}
  .pill.warn{background:var(--warn-bg);color:var(--warn);border-color:rgba(210,153,34,.3)}
  .pill.crit{background:var(--crit-bg);color:var(--crit);border-color:rgba(248,81,73,.3)}
  .pill.unknown{background:var(--panel2);color:var(--tx-dim)}
  .pill.ok .dot{background:var(--ok)} .pill.warn .dot{background:var(--warn)}
  .pill.crit .dot{background:var(--crit);animation:pulse 1.4s infinite}
  .pill.unknown .dot{background:var(--tx-mut)}
  .lockpill{appearance:none;display:inline-flex;align-items:center;gap:7px;padding:7px 13px;border-radius:999px;
    font:inherit;font-weight:600;font-size:13px;cursor:pointer;border:1px solid var(--line);
    background:var(--panel2);color:var(--tx-dim);transition:color .15s,border-color .15s,background .15s}
  .lockpill:hover{border-color:var(--tx-dim);color:var(--tx)}
  .lockpill[hidden]{display:none}
  .lockpill.unlocked{background:var(--warn-bg);color:var(--warn);border-color:rgba(210,153,34,.4)}
  .lockpill.arrange.on{background:rgba(88,166,255,.14);color:var(--info);border-color:rgba(88,166,255,.45)}
  .lockpill.unlocked .lockpill-time{font-family:ui-monospace,Menlo,Consolas,monospace;font-variant-numeric:tabular-nums}
  body.locked .needs-unlock{opacity:.55}
  body.locked .needs-unlock:not(:disabled){cursor:pointer}
  /* Belt and suspenders: whatever else runs or fails to run on a tick,
     the Overview editing controls are gone the instant body is locked -
     enforced here, not only by the render functions that build them. */
  body.locked #ov-add-row{display:none !important}
  body.locked .ov-remove{display:none !important}
  .unlockbox{margin:12px 0 4px;display:flex;gap:10px;justify-content:center;align-items:center;font-size:13px;color:var(--tx-dim)}
  .unlockbox[hidden]{display:none}
  .unlockbox select{padding:7px 30px 7px 12px}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}

  .grid{display:grid;gap:14px}
  .top{grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}
  .devices{grid-template-columns:repeat(auto-fill,minmax(270px,1fr))}
  .charts{grid-template-columns:repeat(auto-fit,minmax(460px,1fr))}
  .full{grid-column:1/-1}
  @media (max-width:560px){.charts{grid-template-columns:1fr}}

  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:17px 19px}
  .card h2{margin:0 0 13px;font-size:12px;font-weight:700;letter-spacing:.7px;
           text-transform:uppercase;color:var(--tx-mut)}
  .card h2 .right{float:right;font-weight:600;letter-spacing:0;text-transform:none;color:var(--tx-dim)}

  .metric .label{font-size:12px;font-weight:700;letter-spacing:.7px;text-transform:uppercase;
                 color:var(--tx-mut);margin-bottom:9px}
  .metric .value{font-size:30px;font-weight:680;line-height:1.05;letter-spacing:-.5px}
  .metric .value .unit{font-size:16px;font-weight:600;color:var(--tx-dim);margin-left:3px}
  .metric .sub{color:var(--tx-dim);font-size:13px;margin-top:6px}
  .metric.ok .value{color:var(--ok)} .metric.warn .value{color:var(--warn)}
  .metric.crit .value{color:var(--crit)}

  .dev{display:flex;flex-direction:column;gap:10px;transition:border-color .15s}
  .dev-hist{appearance:none;border:1px solid var(--line);background:var(--panel2);color:var(--tx-dim);width:26px;height:26px;
    border-radius:8px;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;margin-left:8px;flex:0 0 auto;
    opacity:0;transition:opacity .15s}
  .dev:hover .dev-hist,.dev-hist:focus-visible{opacity:1}
  .dev-hist:hover{color:var(--info);border-color:var(--info)}
  @media (hover:none){.dev-hist{opacity:.7}}
  .dev:hover{border-color:var(--info)}
  .card.socket{transition:border-color .15s}
  .card.socket:hover{border-color:var(--info)}
  .stripgroup-body .card.socket.compact{transition:background .12s,box-shadow .12s}
  .stripgroup-body .card.socket.compact:hover{background:rgba(88,166,255,.07);box-shadow:inset 3px 0 0 var(--info)}
  .dev.crit{border-color:rgba(248,81,73,.45)} .dev.warn{border-color:rgba(210,153,34,.4)}
  .dev .head{display:flex;align-items:flex-start;gap:10px}
  .dev .name{font-weight:650;font-size:16px;line-height:1.25}
  .dev .model{color:var(--tx-dim);font-size:12.5px}
  .dev .readings{display:flex;flex-wrap:wrap;gap:6px 18px;align-items:baseline}
  .dev .reading .v{font-size:28px;font-weight:680;letter-spacing:-.5px;line-height:1.05}
  .dev .reading .v .unit{font-size:14px;font-weight:600;color:var(--tx-dim);margin-left:2px}
  .dev .reading .l{font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .dev .reading.small .v{font-size:19px}
  .dev .foot{display:flex;flex-wrap:wrap;gap:6px 12px;font-size:12.5px;color:var(--tx-dim);align-items:center}
  .dev .foot .reason{color:var(--warn)}
  .dev.crit .foot .reason{color:var(--crit)}
  .dev.stale .reading .v{color:var(--tx-dim)}

  .bar{height:6px;border-radius:99px;background:var(--panel2);overflow:hidden;flex:1;min-width:60px}
  .bar span{display:block;height:100%;border-radius:99px;transition:width .4s ease}
  .batt{display:flex;align-items:center;gap:8px;min-width:120px}

  .kv{display:flex;justify-content:space-between;align-items:baseline;padding:5px 0;
      font-size:14px;gap:12px;border-bottom:1px solid rgba(38,44,55,.5)}
  .kv:last-child{border-bottom:0}
  .kv .k{color:var(--tx-dim)} .kv .v{font-weight:600;text-align:right}
  .kv .d{display:block;color:var(--tx-mut);font-size:12px;font-weight:400}

  table{width:100%;border-collapse:collapse;font-size:13.5px}
  th{text-align:left;font-size:11px;letter-spacing:.7px;text-transform:uppercase;
     color:var(--tx-mut);font-weight:700;padding:6px 10px 6px 0;border-bottom:1px solid var(--line)}
  td{padding:7px 10px 7px 0;border-bottom:1px solid rgba(38,44,55,.55);vertical-align:top}
  tr:last-child td{border-bottom:0}
  td.num{text-align:right;font-family:ui-monospace,Menlo,Consolas,monospace}
  .scroll{overflow-x:auto}

  .tag{display:inline-block;padding:1px 7px;border-radius:6px;font-size:11px;font-weight:700;
       letter-spacing:.4px;text-transform:uppercase;white-space:nowrap}
  .tag.ok{background:var(--ok-bg);color:var(--ok)}
  .tag.warn{background:var(--warn-bg);color:var(--warn)}
  .tag.crit{background:var(--crit-bg);color:var(--crit)}
  .tag.info{background:var(--info-bg);color:var(--info)}
  .tag.dim{background:var(--panel2);color:var(--tx-dim)}
  .tag.zb{background:rgba(163,113,247,.14);color:var(--batt)}

  .btn{appearance:none;border:1px solid var(--line);background:var(--panel2);color:var(--tx);
       font:inherit;font-weight:600;font-size:13.5px;padding:9px 15px;border-radius:10px;
       cursor:pointer;transition:border-color .15s,background .15s,transform .05s}
  .btn:hover:not(:disabled){border-color:var(--info);color:var(--info)}
  .btn:active:not(:disabled){transform:translateY(1px)}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn.danger:hover:not(:disabled){border-color:var(--crit);color:var(--crit)}
  .btn.primary{background:var(--info-bg);border-color:rgba(88,166,255,.35);color:var(--info)}
  .btn.small{padding:5px 10px;font-size:12.5px;border-radius:8px}
  .btn.on{background:var(--info-bg);border-color:var(--info);color:var(--info)}
  .btn.busy{opacity:.6;cursor:progress}
  .btnrow{display:flex;gap:9px;flex-wrap:wrap}
  .btn.cmd{display:inline-flex;align-items:center;gap:9px;padding:10px 16px}
  #pinok,#pincancel{display:inline-flex;align-items:center;justify-content:center;gap:8px}
  #pinok svg,#pincancel svg{flex:0 0 auto;opacity:.85}
  .creset{display:inline-flex;align-items:center;gap:4px}
  .ov-remove svg{display:block}
  .btn.cmd.small{padding:6px 12px;gap:7px}
  .btn.iconbtn{padding:6px 9px;line-height:0}
  .btn.cmd svg{flex:0 0 auto;opacity:.85}
  .btn.cmd:hover:not(:disabled) svg{opacity:1}
  .btnhelp{color:var(--tx-mut);font-size:12.5px;margin:6px 0 16px}
  .hint{position:fixed;z-index:200;max-width:min(340px,88vw);
    background:linear-gradient(160deg,#1b2230 0%,#141922 100%);
    border:1px solid #2b3444;border-radius:12px;padding:11px 14px;
    font-size:12.5px;line-height:1.5;color:var(--tx-dim);
    box-shadow:0 14px 40px rgba(0,0,0,.55);
    opacity:0;transform:translateY(4px);transition:opacity .14s,transform .14s;
    pointer-events:none}
  .hint.show{opacity:1;transform:none}
  .hint b{color:var(--tx);font-weight:600;font-family:ui-monospace,Menlo,Consolas,monospace}
  .hint em{color:var(--crit);font-style:normal}
  .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
  select{appearance:none;background:var(--panel2);color:var(--tx);border:1px solid var(--line);min-width:0;max-width:100%;
         text-overflow:ellipsis;overflow:hidden;white-space:nowrap;
         font:inherit;font-size:13.5px;font-weight:600;padding:8px 32px 8px 12px;border-radius:10px;
         background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='%238b94a3' d='M4 6l4 4 4-4'/%3E%3C/svg%3E");
         background-repeat:no-repeat;background-position:right 10px center;background-size:14px}

  .chart{position:relative;width:100%;height:240px}
  .chart svg{width:100%;height:100%;display:block}
  .chart .empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
                color:var(--tx-mut);font-size:13.5px}
  .chart .tip{position:absolute;pointer-events:none;background:#0d1117ee;border:1px solid var(--line);
              border-radius:9px;padding:7px 10px;font-size:12.5px;line-height:1.4;white-space:nowrap;
              display:none;z-index:2;box-shadow:0 6px 20px rgba(0,0,0,.35)}
  .chart .tip b{font-weight:650}
  .chart .tip .sw{display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:6px;vertical-align:middle}
  .chart svg{cursor:grab;touch-action:none}
  .chart.dragging svg{cursor:grabbing}
  .chart.dragging{user-select:none}
  .chint{position:absolute;top:6px;right:8px;font-size:11.5px;color:var(--tx-mut);
    background:rgba(13,17,23,.82);padding:3px 9px;border-radius:7px;pointer-events:none;opacity:0;transition:opacity .18s}
  .chart:hover .chint{opacity:1}
  .creset{position:absolute;top:3px;left:46px;font-size:10.5px;padding:1px 6px;border-radius:6px;opacity:.72;
    border:1px solid var(--line);background:var(--panel2);color:var(--tx-dim);cursor:pointer;font-family:inherit}
  .creset:hover{color:var(--info);border-color:var(--info);opacity:1}
  .creset svg{width:10px;height:10px}
  .creset[hidden]{display:none}
  .legend{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12.5px;color:var(--tx-dim);margin-top:6px}
  .legend .sw{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}

  /* the socket panel: state on the left, live figures on the right */
  /* one full-width row per plug, stacked - the figures spread out to the right */
  .sockets{display:flex;flex-direction:column;gap:12px;margin-bottom:14px}
  .card.socket .socket-state{min-width:280px}
  /* one shared set of column widths, so every plug row lines up exactly */
  .socket-figures{display:grid !important;grid-auto-flow:column;grid-auto-columns:100px;
    justify-content:end;column-gap:10px}
  .socket-figures>div:last-child{width:126px}
  .socket-figures .v{white-space:nowrap}
  @media (max-width:900px){.socket-figures{grid-auto-flow:row;grid-template-columns:repeat(auto-fill,100px);justify-content:start}}
  @media (max-width:700px){.socket-figures{justify-content:flex-start}}
  .card.socket{display:flex;align-items:center;gap:22px;flex-wrap:wrap;padding:18px 20px}
  .socket-state{display:flex;align-items:center;gap:14px;min-width:200px}
  .socket-toggle{appearance:none;cursor:pointer;width:58px;height:58px;border-radius:50%;display:grid;place-items:center;
    flex:0 0 auto;border:2px solid var(--line);background:var(--panel2);color:var(--tx-mut);
    transition:color .2s,border-color .2s,background .2s,box-shadow .2s}
  .socket-toggle:hover:not(:disabled){border-color:var(--tx-dim)}
  .socket-toggle:disabled{cursor:progress;opacity:.6}
  .card.socket.on .socket-toggle{color:var(--ok);border-color:rgba(63,185,80,.55);background:rgba(63,185,80,.12);box-shadow:0 0 0 6px rgba(63,185,80,.07)}
  .card.socket.off .socket-toggle{color:var(--tx-mut)}
  .card.socket.stale .socket-figures{opacity:.45}
  .card.socket.stale .socket-label{color:var(--warn)}
  .card.socket.stale .socket-toggle{color:var(--warn);border-color:rgba(210,153,34,.45);background:rgba(210,153,34,.10);box-shadow:none}
  /* an optional box that is off: quiet grey, not a warning */
  .trv{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-top:8px;padding-top:8px;border-top:1px solid var(--line)}
  .trv .lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .trv .trv-value{min-width:66px;text-align:center;font-size:15px;font-weight:600;color:var(--tx)}
  .trv button{min-width:32px}
  .trv-room{flex-direction:column;align-items:stretch;gap:7px}
  .trv-room .trv-mode{flex:1 1 auto;min-width:0}
  .trv-line{display:flex;align-items:center;gap:9px;flex-wrap:wrap}
  .trv select{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:3px 6px}
  .card.socket.unplugged .socket-label{color:var(--tx-dim)}
  .card.socket.unplugged .socket-toggle{color:var(--tx-dim);border-color:var(--line);background:transparent}
  .socket-label{font-size:19px;font-weight:680;letter-spacing:-.2px}
  .card.socket{position:relative}
  .socket-hist{position:absolute;top:8px;right:8px;appearance:none;border:1px solid var(--line);background:var(--panel2);color:var(--tx-dim);
    width:26px;height:26px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;
    opacity:0;transition:opacity .15s;z-index:2}
  .card.socket:hover .socket-hist,.socket-hist:focus-visible{opacity:1}
  .socket-hist:hover{color:var(--info);border-color:var(--info)}
  .card.socket.compact .socket-hist{width:22px;height:22px;top:6px;right:6px}
  @media (hover:none){.socket-hist{opacity:.7}}
  /* The × goes directly under the chart button, lined up with it, whatever
     kind of card this is: beside it they were a thumb's width apart on a
     phone and overlapped outright where the chart button sits in the title
     row rather than pinned to the corner. */
  #overview-custom .card{position:relative}
  #overview-custom .card .ov-remove{top:40px;right:8px}
  #overview-custom .card.socket .ov-remove{top:40px;right:8px}
  #overview-custom .card.socket.compact .ov-remove{top:34px;right:6px}
  /* a device card is padded 17/19 and its chart button is 26 tall at the end
     of the title row, so its right edge is 19 in and its bottom edge 43 down:
     the × lines up at 19 and clears it at 49 */
  #overview-custom .card.dev .ov-remove{top:49px;right:20px}
  .card.socket.on .socket-label{color:var(--ok)} .card.socket.off .socket-label{color:var(--tx-dim)}
  .card.socket.pending .socket-label{opacity:.62}
  .card.socket.pending .socket-toggle{animation:pendpulse 1s ease-in-out infinite}
  @keyframes pendpulse{0%,100%{opacity:1}50%{opacity:.45}}
  .socket-sub{font-size:12.5px;margin-top:2px;color:var(--tx-dim)}
  .socket-figures{display:flex;gap:20px;flex-wrap:wrap;flex:1}
  .socket-figures div{min-width:70px}
  .socket-figures .k{font-size:11px;letter-spacing:.7px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .socket-figures .v{font-size:18px;font-weight:650;margin-top:2px}
  /* A grid item will not shrink below its own content unless it is told to,
     so one long device name or a number box with a unit beside it widens its
     column and pushes everything after it out of line with the header. Every
     row grid in here gets the same treatment rather than one at a time. */
  .bind-row > *, .rule-row > *, .person-row > *, .ptrig-row > *, .gw-row > *,
  .msg-top > *, .sched-row > *, .dbb-row > *, .wc-row > *, .dev-row > *,
  .scene-row > *, .seq-row > *, .mdev-line > *, .mchan > *{min-width:0}
  .bind-row{display:grid;grid-template-columns:36px minmax(150px,1.7fr) minmax(90px,.9fr) minmax(150px,1.6fr) minmax(90px,.9fr) minmax(86px,.8fr) 64px 104px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .bind-do{min-width:0}
  .bind-do select{width:100%}
  .bind-row .ms{display:flex;align-items:center;gap:5px;visibility:hidden;min-width:0}
  .bind-row .ms.show{visibility:visible}
  .bind-row .ms input{width:100%;min-width:0}
  .bind-row .ms span{color:var(--tx-mut);font-size:12px;flex:0 0 auto}
  /* "set to" needs room for its how/number/unit trio: the Do cell borrows
     the pulse-ms column beside it (the two are never shown together) */
  .bind-row .bind-do:has(.ms.show){grid-column:span 2;display:flex;flex-wrap:wrap;gap:6px;align-items:center}
  .bind-row .bind-do:has(.ms.show) > select:first-child{width:auto;flex:1 1 110px}
  .bind-row .bind-do .ms.show{display:flex;flex:1 1 170px;gap:5px}
  .bind-row .bind-do .ms.show select{width:auto;flex:0 0 auto}
  .bind-row .bind-do .ms.show input{flex:1 1 64px;min-width:64px}
  .bind-row .bind-do:has(.ms.show) + .ms{display:none}
  .rule-row .ms.show input{min-width:64px;width:72px}
  .bind-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%;min-width:0}
  .bind-row input:focus,select:focus{outline:none;border-color:var(--info)}
  .bind-row select{width:100%}
  .dev-row{display:grid;grid-template-columns:.55fr minmax(120px,1.3fr) minmax(120px,1.3fr) minmax(90px,.9fr) 52px .95fr .8fr 84px 112px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  /* the last column takes what the two buttons need (they used to sit in a
     fixed 104px cell and hang out past the card edge); everything else may
     shrink, and a row that still does not fit wraps its buttons underneath.
     Every row here is a grid of its own, so "what the buttons need" was
     answered separately in each of them: the header's last cell is empty and
     needed nothing, which handed its width to the five columns above the
     boxes and walked every column name to the right - a hundred and fifty
     pixels of it by Target. A row carrying the config.json label drifted from
     its neighbours the same way. So the width is measured once, from the
     widest set of buttons on the page, and every row and the header are told
     the same number; max-content is what is used until it is measured. */
  .gw-row{display:grid;grid-template-columns:minmax(90px,1.2fr) minmax(110px,1.3fr) minmax(70px,.8fr) minmax(70px,.8fr) minmax(120px,1.5fr) var(--gw-btns,max-content);gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .gw-row > *{min-width:0}
  .gw-row .gw-btns{white-space:nowrap;justify-self:end}
  .gw-row .tag{justify-self:start}
  .gw-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%;box-sizing:border-box}
  .gw-row select{width:100%;box-sizing:border-box}
  .gw-row input:focus,.gw-row select:focus{outline:none;border-color:var(--info)}
  .gw-row input:disabled,.gw-row select:disabled{opacity:.55}
  .gw-btns{display:inline-flex;gap:6px}
  .gw-info{font-size:12.5px;color:var(--tx-dim);padding:2px 0 8px 4px;margin-top:0} .gw-info .dim{color:var(--tx-mut)}
  .gw-head{color:var(--tx-mut);font-size:11px;letter-spacing:.09em;text-transform:uppercase;border-bottom:1px solid var(--line);padding-bottom:8px}
  .dev-row .btn.cmd{width:100%;justify-content:center}
  body:not(.locked) .cangrab{cursor:grab}
  body.arranging .cangrab{outline:1px dashed rgba(88,166,255,.45);outline-offset:2px}
  body.arranging .cangrab input,body.arranging .cangrab select,body.arranging .cangrab button{pointer-events:none;opacity:.65}
  .draggingcard{opacity:.45;outline:1.5px dashed var(--info);outline-offset:2px}
  .foot .via{color:var(--info);opacity:.85}
  .stripgroup{display:flex;flex-direction:column;gap:0;padding:0;overflow:hidden}
  .stripgroup-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 18px;border-bottom:1px solid var(--line);background:rgba(255,255,255,.02)}
  .stripgroup-title{font-weight:600;font-size:14px}
  .stripgroup-body{display:flex;flex-direction:column}
  .stripgroup-body .card.socket.compact{border:none;border-radius:0;border-bottom:1px solid rgba(38,44,55,.5);padding:10px 18px 10px 30px;background:transparent}
  .stripgroup-body .card.socket.compact:last-child{border-bottom:none}
  .stripgroup-body .card.socket.compact .socket-toggle{width:58px;height:58px}
  .stripgroup-body .card.socket.compact{padding:14px 18px}
  .stripgroup-head{flex-wrap:wrap}
  .strip-shared{margin:0 auto 0 24px;grid-auto-columns:96px}
  .stripgroup-head .socket-sub{margin-top:2px}
  .stripgroup .cangrab{cursor:grab}
  .ov-remove{position:absolute;top:8px;right:8px;width:24px;height:24px;border-radius:50%;
    border:1px solid var(--line);background:var(--panel2);color:var(--tx-dim);font-size:16px;line-height:1;
    cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:2}
  .ov-remove:hover{color:var(--crit);border-color:var(--crit)}
  #overview-custom .card.socket{position:relative}
  .socket-toggle.watch{display:inline-flex;align-items:center;justify-content:center;cursor:default;color:var(--info);opacity:.8}
  .sig{display:inline-flex;align-items:flex-end;gap:2px;height:13px;margin-right:7px;vertical-align:-1px}
  .sig i{width:3.5px;border-radius:1px;background:var(--line)}
  .sig i:nth-child(1){height:4px}.sig i:nth-child(2){height:7px}.sig i:nth-child(3){height:10px}.sig i:nth-child(4){height:13px}
  .sig.q4 i,.sig.q3 i:nth-child(-n+3),.sig.q2 i:nth-child(-n+2),.sig.q1 i:nth-child(1){background:var(--sigc)}
  .sigwrap{display:inline-flex;align-items:center}
  .mdev{border:1px solid var(--line);border-radius:12px;padding:10px 12px;margin:10px 0;background:rgba(255,255,255,.015)}
  .mdev.off{opacity:.6}
  .mdev-line{display:grid;grid-template-columns:.65fr minmax(120px,1.3fr) minmax(100px,1fr) minmax(140px,1.5fr) minmax(90px,.9fr) 92px 104px;gap:8px;align-items:center}
  .mdev-line input,.mdev-line select,.mchan input,.mchan select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%;box-sizing:border-box}
  .mdev-line select,.mchan select{width:auto;min-width:0;max-width:100%}
  .mdev-what{font-size:13px;color:var(--tx)} .mdev-what .dim{color:var(--tx-mut)} .mdev-what .mono{font-size:12px;margin-left:6px}
  .mdev-chans{margin:8px 0 0 22px;padding-left:12px;border-left:2px solid var(--line)}
  .mchan{display:grid;grid-template-columns:36px minmax(110px,1.4fr) minmax(110px,1.2fr) 92px minmax(90px,.9fr) 92px 104px;gap:8px;align-items:center;padding:5px 0}
  .mchan.off>*:not(button){opacity:.55}
  .mchan-head{color:var(--tx-mut);font-size:11px;letter-spacing:.7px;text-transform:uppercase;font-weight:700;padding-bottom:4px}
  .mchan-add{padding-top:6px}
  @media (max-width:900px){.mdev-line,.mchan{grid-template-columns:1fr 1fr} .mchan-head{display:none}}
  .managed-sub{margin:16px 0 2px;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--tx-mut)}
  .managed-sub:first-child{margin-top:4px}
  .dev-row input,.dev-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%}
  .dev-row input:focus{outline:none;border-color:var(--info)}
  .dev-row input:disabled,.dev-row select:disabled{opacity:.55}
  .dev-row .state{font-size:12px;white-space:nowrap}
  @media (max-width:900px){.dev-row{grid-template-columns:1fr 1fr 1fr;} .dev-head{display:none}
    .gw-row{grid-template-columns:1fr 1fr;} .gw-head{display:none} .gw-row .gw-btns{grid-column:1 / -1;justify-self:start}}
  @media (min-width:901px) and (max-width:1280px){
    .gw-row{grid-template-columns:minmax(90px,1.2fr) minmax(110px,1.3fr) minmax(70px,.8fr) minmax(70px,.8fr) minmax(120px,1.5fr)}
    .gw-row .gw-btns{grid-column:1 / -1;justify-self:start;padding-bottom:2px}}
  .rule-row.twinned{box-shadow:inset 3px 0 0 var(--warn)}
  .rule-row{display:grid;grid-template-columns:36px minmax(130px,1.4fr) minmax(80px,.8fr) minmax(56px,.5fr) minmax(64px,.6fr) minmax(130px,1.3fr) minmax(100px,.9fr) minmax(64px,.4fr) 104px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .rule-row input,.rule-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%;min-width:0}
  .rule-row input:focus{outline:none;border-color:var(--info)}
  .now{font-size:12px;color:var(--tx-mut);white-space:nowrap}
  .rule-row .now b{color:var(--warn)}
  .scene-row{display:grid;grid-template-columns:1.2fr 2fr 76px;gap:8px;align-items:start;padding:8px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .scene-side{display:flex;gap:6px;align-items:flex-start;justify-content:flex-end;position:sticky;top:6px}
  .scene-actions .act > select,.scene-actions .act > .ms{flex:1 1 150px;min-width:0}
  .scene-actions .act .iconbtn{flex:0 0 auto}
  .scene-row input,.scene-actions select,.scene-actions input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px}
  .scene-actions{display:flex;flex-direction:column;gap:6px}
  .scene-actions .act{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
  .scene-note{align-self:center;font-style:italic}
  .seq-row{display:grid;grid-template-columns:1.1fr 2.2fr 1.2fr 116px;gap:10px;align-items:start;padding:10px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .seq-row input,.seq-steps select,.seq-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px}
  .seq-steps{display:flex;flex-direction:column;gap:6px}
  .seq-steps .step{display:flex;gap:6px;align-items:center}
  .seq-steps .step .n{width:22px;color:var(--tx-mut);font-size:12px;text-align:right}
  .seq-steps .step.next .n{color:var(--info);font-weight:700}
  .seq-status{font-size:12.5px;color:var(--tx-dim);margin-top:4px}
  .seq-status b{color:var(--info)}
  .sched-row{display:grid;grid-template-columns:36px minmax(130px,1.1fr) minmax(190px,1.5fr) minmax(230px,1.1fr) minmax(150px,1.2fr) minmax(105px,.8fr) 104px;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .sched-row input[type=text],.sched-row .whenbox input{min-width:0;width:100%}
  .sched-row select,.sched-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:7px 10px;height:34px;box-sizing:border-box;min-width:0}
  .sched-days{display:flex;gap:3px;flex-wrap:nowrap;min-width:0}
  .sched-day{display:inline-flex;align-items:center;justify-content:center;flex:1 1 26px;min-width:26px;max-width:34px;height:34px;border-radius:9px;
    border:1px solid var(--line);background:var(--panel2);color:var(--tx-dim);font-size:12px;cursor:pointer;user-select:none}
  .sched-day.on{background:var(--info);border-color:var(--info);color:#fff}
  .sched-at{display:flex;gap:6px;align-items:center;min-width:0}
  .sched-at .woff{width:62px;flex:0 0 62px}
  .sched-row .sched-at input[type=time]{flex:1 1 120px;min-width:112px;width:auto;padding:7px 6px;
    font-variant-numeric:tabular-nums;letter-spacing:.02em}
  .sched-row .sched-at select{flex:0 0 auto;min-width:88px;padding:7px 6px}
  .scene-actions .act-after{display:inline-flex;gap:5px;align-items:center;font-size:12.5px;color:var(--tx-dim)}
  .notify-opt{display:inline-flex;gap:8px;align-items:center;font-size:13.5px;color:var(--tx-dim);
    border:1px solid var(--line);border-radius:10px;padding:8px 14px;cursor:pointer;user-select:none}
  .notify-opt input{accent-color:var(--info)}
  .etotal td{border-top:2px solid var(--line);padding-top:10px;font-weight:600}
  #energy-daily{position:relative}
  .ebar.hot i{filter:brightness(1.35)}
  .etip{position:absolute;bottom:100px;transform:translateX(-50%);pointer-events:none;z-index:5;width:max-content;min-width:220px;max-width:320px;
    background:linear-gradient(160deg,#1b2230 0%,#141922 100%);border:1px solid #2b3444;border-radius:14px;padding:12px 18px 11px;
    box-shadow:0 14px 40px rgba(0,0,0,.55),0 0 0 1px rgba(255,255,255,.03) inset;text-align:center;animation:rise .12s ease-out;white-space:nowrap}
  .etip::after{content:'';position:absolute;left:50%;bottom:-7px;width:12px;height:12px;transform:translateX(-50%) rotate(45deg);background:#141922;border-right:1px solid #2b3444;border-bottom:1px solid #2b3444}
  .etip-day{font-size:11.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--tx-mut);margin-bottom:6px}
  .etip-main{display:flex;align-items:baseline;justify-content:center;gap:16px}
  .etip-kwh{font-size:24px;font-weight:760;letter-spacing:-.3px;color:var(--tx)} .etip-kwh small{font-size:12px;font-weight:600;color:var(--tx-dim);margin-left:3px}
  .etip-money{font-size:24px;font-weight:760;letter-spacing:-.3px;color:var(--ok);white-space:nowrap} .etip-money small{font-size:12px;font-weight:600;margin-left:4px;opacity:.85}
  .etip-sub{font-size:12px;color:var(--tx-dim);margin-top:6px}
  .ebars{display:flex;align-items:flex-end;gap:3px;height:96px}
  .ebar{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;min-width:8px}
  .ebar i{display:block;width:100%;max-width:20px;background:var(--info);border-radius:3px 3px 0 0;opacity:.85}
  .ebar span{font-size:9.5px;color:var(--tx-mut)}
  .ebar:nth-child(odd) span{visibility:hidden}
  .mesh-parent{font-weight:600;color:var(--tx);margin-top:10px}
  .mesh-child{padding-left:14px;color:var(--tx-dim);font-size:13.5px;line-height:1.7}
  .mesh-child .dim{color:var(--tx-mut);font-size:12px}
  @media (max-width:640px){
    .rule-row,.bind-row,.dev-row,.gw-row{grid-template-columns:1fr 1fr;grid-auto-rows:auto}
    .dev-head,.gw-head{display:none}
    .set-grid{grid-template-columns:1fr}
    .socket-figures{grid-auto-flow:row;grid-template-columns:repeat(auto-fill,100px);justify-content:start}
  }
  .evf{font:inherit;font-size:13px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:7px 10px}
  select.evf{padding-right:26px}
  .set-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px 22px;margin-top:6px;align-items:stretch}
  .set-item.set-bool{flex-direction:row;align-items:center;justify-content:space-between}
  .set-item{display:flex;flex-direction:column;gap:5px;justify-content:flex-end}
  /* Three bands down the whole row - label, control, note - so a two-line
     label does not push its own box below its neighbours'. Where subgrid is
     not to be had, the flex column above still reads correctly. */
  /* Only the SMS card's items have the three parts; elsewhere an item is a
     label over a box and the flex column above is the right shape. The bands
     are explicit about their one column and what fills it, or an <input>
     inside a grid keeps its own width and drifts. */
  @supports (grid-template-rows: subgrid) {
    #sms-grid .section-body .set-grid{grid-auto-rows:auto}
    #sms-grid .section-body .set-grid > .set-item{display:grid;grid-template-rows:subgrid;grid-row:span 3;
      grid-template-columns:minmax(0,1fr);justify-items:stretch;gap:5px;align-content:start}
    #sms-grid .section-body .set-grid > .set-item > input,
    #sms-grid .section-body .set-grid > .set-item > select{width:100%;box-sizing:border-box;justify-self:stretch;
      /* wide, never tall: a row is as high as the tallest control in it, and
         a grid item fills its row unless told not to. Three switches beside a
         dropdown made the dropdown as tall as they were. */
      align-self:start}
  }
  /* The whole label, however long. Each item is a column with the input at
     the bottom, and grid rows stretch to the tallest item, so a label that
     wraps onto three lines leaves its neighbours' inputs level with its own. */
  .set-item label{font-size:11px;letter-spacing:.07em;text-transform:uppercase;color:var(--tx-mut);
    line-height:1.35;white-space:normal;overflow-wrap:anywhere}
  .set-item input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:8px 11px;
    width:100%;box-sizing:border-box;text-align:left}
  .set-item label{text-align:left}
  .set-item select{width:100%;box-sizing:border-box}
  .set-item input:focus{border-color:var(--info);outline:none}
  /* "this one differs from what the file says" - a mark down the left edge and
     a dot beside the label, rather than a blue frame, which read as though the
     box were focused or under the pointer */
  .set-item.overridden > input,.set-item.overridden > select{border-left:3px solid var(--info)}
  .set-item.overridden > label::after{content:'\2022';color:var(--info);margin-left:6px;font-size:15px;line-height:0}
  /* One switch and four fields: the auto-filling grid above would strand the
     last one on a row by itself. This group gets a row of its own with a
     deliberate four across, so a hidden field leaves a gap at the end instead
     of shunting the rest about. */
  .set-sub{grid-column:1/-1;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px 22px}
  .set-sub > *{min-width:0}
  .set-wide{grid-column:1/-1;max-width:340px}
  @media (max-width:1100px){.set-sub{grid-template-columns:repeat(2,minmax(0,1fr))}}
  @media (max-width:640px){.set-sub{grid-template-columns:1fr}}
  .set-head{grid-column:1/-1;font-size:11.5px;letter-spacing:.13em;text-transform:uppercase;color:var(--tx-dim);margin-top:8px}
  .set-head .dim{color:var(--tx-mut)}
  .notify-grid .pc-block .pc-body{padding-left:21px}
  .nsec{margin:20px 0 4px;font-size:11px;letter-spacing:.09em;text-transform:uppercase;
    color:var(--tx-mut);border-top:1px solid var(--line);padding-top:12px}
  .nsec:first-of-type{border-top:0;margin-top:12px}
  .notify-dev{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
  .notify-devhead{display:flex;flex-direction:column;gap:1px;min-width:200px}
  .notify-devname{font-weight:620;color:var(--tx)}
  .notify-grid{display:block}
  .notify-dev{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:5px 0;font-size:13.5px;color:var(--tx-dim)}
  .notify-dev select{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:6px 26px 6px 10px;max-width:210px}
  .notify-dev.overridden select{border-color:var(--info)}
  .notify-dev{flex-wrap:wrap}
  /* one switch per road, for a kind of message that wants its own. While it
     follows the house the switches still show where it goes, dimmed, because
     "follows the house" is not an answer to "so where does it go". */
  .notify-sys{display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:2px 0 2px 2px;
    border-left:2px solid transparent;padding-left:10px}
  /* the same three switches in a settings column, which is narrow: closer
     together, and the whole width of the card rather than one column of it,
     so they stand on one line instead of three */
  .set-grid > .set-item > .roads-field{gap:14px;padding-left:0;border-left:0;align-self:start}
  .set-item.wide{grid-column:1/-1}
  .notify-sys.overridden{border-left-color:var(--info)}
  .notify-sys .swrow.dim{opacity:.45}
  .notify-sys .swrow .swlbl{font-size:12.5px}
  .notify-sys-says{white-space:nowrap}
  .notify-custom .swrow{margin-right:10px}
  .notify-custom{display:inline-flex;gap:10px;flex-wrap:wrap;width:100%;padding:6px 0 2px 2px;font-size:12.5px}
  .notify-custom label{display:inline-flex;gap:5px;align-items:center;cursor:pointer}
  .notify-custom input{accent-color:var(--info)}
  .notify-dev.overridden span:first-child{color:var(--tx)}
  .rule-sub{display:flex;flex-direction:column;gap:7px;padding:4px 0 12px 4px;margin-top:-2px;
    border-bottom:1px solid rgba(38,44,55,.5);font-size:13px;color:var(--tx-dim)}
  .rule-sub-line{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
  .rule-sub .sublbl{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--tx-mut);margin-left:2px}
  .rule-sub .wend{display:inline-flex;gap:6px;align-items:center}
  .rule-sub input,.rule-sub select{font:inherit;font-size:13px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:9px;padding:7px 10px;height:34px;box-sizing:border-box}
  .rule-sub select{padding-right:26px}
  .rule-sub input[type=time]{width:104px}
  .rule-sub .wnum{width:86px}
  .rule-sub .woff{width:72px}
  .rule-sub input:focus,.rule-sub select:focus{border-color:var(--info);outline:none}
  .rule-row{border-bottom:none}
  @media (max-width:900px){.rule-row{grid-template-columns:1fr 1fr 1fr}}
  .bind-row.off>*:not(.sw):not(button),.rule-row.off>*:not(.sw):not(button),.sched-row.off>*:not(.sw):not(button){opacity:.5}
  .bind-head{color:var(--tx-mut);font-size:11px;letter-spacing:.7px;text-transform:uppercase;font-weight:700;border-bottom:1px solid var(--line)}
  @media (max-width:700px){.bind-row{grid-template-columns:1fr 1fr;} .bind-head{display:none}}

  .actchips{display:flex;flex-wrap:wrap;gap:5px;margin-top:10px}
  .actchips .chip{font-size:10.5px;letter-spacing:.3px;padding:2.5px 9px;border-radius:999px;
    background:var(--panel2);border:1px solid var(--line);color:var(--tx-mut);white-space:nowrap}
  .actchips .chip.more{border-style:dashed;cursor:help}
  .actchips .chip.groups{color:var(--info);border-color:rgba(88,166,255,.3);background:rgba(88,166,255,.07)}
  .lastact .v{transition:color .3s}
  .reading.fresh .v{color:var(--ok);animation:pressed 1.6s ease-out}
  .reading.fresh .l{color:var(--ok)}
  @keyframes pressed{0%{text-shadow:0 0 18px rgba(63,185,80,.85);transform:scale(1.06)}
    60%{text-shadow:0 0 8px rgba(63,185,80,.35)}100%{text-shadow:none;transform:none}}
  .muted{color:var(--tx-dim)} .small{font-size:13px} .center{text-align:center;color:var(--tx-mut);padding:26px 0}
  .note{color:var(--tx-dim);font-size:13px;margin:0 0 12px}
  code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;background:var(--panel2);
       padding:1px 6px;border-radius:6px}

  .toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(20px);opacity:0;
         background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:11px 18px;
         font-size:14px;font-weight:600;transition:opacity .2s,transform .2s;z-index:10;pointer-events:none;
         box-shadow:0 8px 30px rgba(0,0,0,.4)}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .toast.ok{border-color:rgba(63,185,80,.4);color:var(--ok)} .toast.bad{border-color:rgba(248,81,73,.4);color:var(--crit)}

  /* ---- PIN dialog, as in upsmon ---- */
  .backdrop{position:fixed;inset:0;z-index:100;display:flex;align-items:center;
    justify-content:center;background:rgba(2,5,10,.72);backdrop-filter:blur(3px);
    padding:20px;animation:fade .16s ease}
  .backdrop[hidden]{display:none}
  @keyframes fade{from{opacity:0}to{opacity:1}}
  .sw{position:relative;display:inline-block;width:44px;height:26px;flex:0 0 auto;vertical-align:middle}
  .sw input{position:absolute;opacity:0;width:0;height:0}
  .sw .knob{position:absolute;inset:0;border-radius:999px;background:#3a4354;border:1px solid var(--line);cursor:pointer;transition:background .18s,border-color .18s}
  .sw .knob::after{content:'';position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:50%;background:#fff;
    box-shadow:0 1px 3px rgba(0,0,0,.45);transition:transform .18s cubic-bezier(.2,.9,.3,1)}
  .sw input:checked+.knob{background:var(--ok);border-color:var(--ok)}
  .sw input:checked+.knob::after{transform:translateX(18px)}
  .sw input:focus-visible+.knob{box-shadow:0 0 0 3px rgba(88,166,255,.35)}
  .sw input:disabled+.knob{opacity:.45;cursor:not-allowed}
  .sw.small{width:36px;height:22px} .sw.small .knob::after{width:16px;height:16px} .sw.small input:checked+.knob::after{transform:translateX(14px)}
  .swrow{display:inline-flex;align-items:center;gap:10px}
  .swrow .swlbl{font-size:13.5px}
  #db-run, #rec-run{margin-top:12px;border:1px solid var(--line);border-radius:12px;padding:10px 12px;background:var(--panel2)}
  .runbar{height:4px;border-radius:3px;background:rgba(88,166,255,.15);overflow:hidden;margin-bottom:8px}
  .runbar i{display:block;height:100%;width:38%;border-radius:3px;background:var(--info);animation:runslide 1.1s ease-in-out infinite}
  #db-run.done .runbar i, #rec-run.done .runbar i{width:100%;animation:none;background:var(--ok)}
  #db-run.failed .runbar i, #rec-run.failed .runbar i{width:100%;animation:none;background:var(--crit)}
  @keyframes runslide{0%{margin-left:-40%}100%{margin-left:100%}}
  .runhead{display:flex;justify-content:space-between;align-items:baseline;gap:10px;font-size:13.5px;font-weight:600}
  .runlog{margin:8px 0 0;max-height:190px;overflow:auto;font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;
    color:var(--tx-dim);white-space:pre-wrap;word-break:break-word}
  .runlog:empty{display:none}
  #reset-device option.gone{color:var(--warn)}
  .set-item[hidden]{display:none}
  .subpanel{margin-top:12px;padding:12px 14px;border:1px solid var(--line);border-radius:12px;background:var(--panel2)}
  .subpanel > .note:first-child{margin-top:0}
  .subpanel .btnrow{flex-wrap:wrap}
  .subpanel .spacer{flex:1 1 auto}
  .sw-cell{display:flex;align-items:center;gap:8px}
  .sw-cap{font-size:11px;color:var(--tx-mut);line-height:1.25}
  #alertband{position:sticky;top:0;z-index:60;display:none;align-items:center;gap:12px;flex-wrap:wrap;
    padding:11px 18px;background:color-mix(in srgb, var(--crit) 22%, var(--panel));
    border-bottom:1px solid var(--crit);box-shadow:0 6px 18px rgba(0,0,0,.28)}
  #alertband.show{display:flex}
  #alertband .bell{color:var(--crit);flex:0 0 auto;display:flex}
  #alertband .texts{flex:1 1 260px;min-width:0;display:flex;flex-direction:column;gap:2px}
  #alertband .one{font-size:13.5px;font-weight:600;white-space:normal;overflow-wrap:anywhere;line-height:1.35;
    display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
  #alertband .one .when{font-weight:400;color:var(--tx-mut);margin-left:8px;font-size:12px}
  #alertband .more{font-size:12px;color:var(--tx-mut)}
  #alertband .acts{flex:0 0 auto;opacity:0;transition:opacity .15s}
  #alertband:hover .acts, #alertband:focus-within .acts{opacity:1}
  @media (hover:none){#alertband .acts{opacity:1}}
  .socket-hold{margin-top:4px}
  .holdchip{display:inline-flex;align-items:center;gap:5px;padding:2px 9px;border-radius:999px;cursor:pointer;
    background:color-mix(in srgb, var(--warn) 18%, var(--panel2));border:1px solid var(--warn);
    color:var(--warn);font:inherit;font-size:11.5px;font-weight:600}
  .holdchip:hover{background:color-mix(in srgb, var(--warn) 30%, var(--panel2))}
  .who-row{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 2px}
  .whochip{display:inline-flex;align-items:center;gap:6px;padding:2px 9px;border-radius:999px;
    background:var(--panel2);border:1px solid var(--line);font-size:12.5px;color:var(--tx-mut)}
  .whochip.in{color:var(--tx);border-color:color-mix(in srgb, var(--ok) 45%, var(--line))}
  .whochip .dot{width:7px;height:7px;border-radius:50%;background:var(--tx-mut)}
  .whochip.in .dot{background:var(--ok)}
  /* A card is the size of its kind, not of the words that happen to be in it:
     every network tile matches every other, so the wall does not stagger. */
  /* A card is as tall as its kind, not as tall as whatever it happens to sit
     beside: a grid row stretches every card in it to match the tallest, which
     is why one network card next to an access point came out oversized. */
  #wifi-tiles{align-items:start}
  .wifi-tile{display:flex;flex-direction:column;min-width:0;overflow:hidden}
  /* a flex child will not shrink below its content unless told, and a long
     model line pushed the chart button out past the frame */
  .wifi-tile .head{min-width:0}
  .wifi-tile .head > div:first-child{min-width:0;flex:1 1 auto}
  /* nothing is cut short and nothing breaks mid-word: the text wraps where
     words allow, and the cards in a group are levelled to the tallest */
  .wifi-tile .name{overflow-wrap:break-word}
  .wifi-tile .muted, .wifi-tile .reason{overflow-wrap:break-word}
  .wifi-tile .readings{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));
    gap:10px 12px;align-content:start;margin-top:8px}
  .wifi-tile .reading{min-width:0}
  /* an uplink reads "down 7.7 Kbps up 29.4 Kbps"; cutting that at the frame
     tells the reader nothing, so it wraps instead */
  .wifi-tile .reading .v{overflow-wrap:break-word;line-height:1.25}
  .wifi-tile .reading .v .unit{white-space:nowrap}
  /* each direction of the uplink stays whole; the line breaks between them */
  .wifi-tile .reading .v .nowrap{white-space:nowrap;display:inline-block;margin-right:8px}
  .wifi-tile .reading .l{overflow-wrap:break-word;line-height:1.25}
  .wifi-tile .reading .sub{font-size:10.5px;color:var(--tx-mut);line-height:1.3;margin-top:1px}
  .wifi-tile .reading .sub.hint{color:var(--ok)}
  .wifi-tile .model{overflow-wrap:break-word;line-height:1.35}
  .wifi-tile .foot{margin-top:auto;padding-top:8px}
  /* A grid row is as tall as the tallest card in it, so an access point beside
     a network stretched the network to match and the next row did not. Each
     kind is laid out in a grid of its own, where every row is the same. */
  #wifi-tiles{display:block}
  /* every row in a group is as tall as that group's tallest card, so the cards
     match without any of them having to cut its text short */
  .wifi-group .grid{grid-auto-rows:1fr}
  .wifi-group .wifi-tile{height:100%}
  .wifi-group{margin-bottom:16px}
  .wifi-group > h3{margin:2px 0 8px;font-size:11.5px;letter-spacing:.13em;text-transform:uppercase;
    color:var(--tx-dim);font-weight:600}
  .wifi-tile.tile-controller{min-height:170px}
  .wifi-tile.tile-ap{min-height:210px}
  .wifi-tile.tile-ssid{min-height:130px}
  #wifi-clients{margin:12px 0;max-height:300px;overflow:auto;border:1px solid var(--line);border-radius:12px}
  #wifi-clients:empty{display:none}
  .wc-row{display:grid;grid-template-columns:minmax(120px,1.4fr) minmax(140px,1fr) minmax(100px,.8fr) minmax(90px,.7fr) minmax(150px,1fr);
    gap:8px;align-items:center;padding:5px 6px;border-radius:8px;font-size:13px}
  .wc-row:nth-child(odd){background:var(--panel2)}
  .wc-row:not(.head):hover{background:rgba(88,166,255,.07);box-shadow:inset 3px 0 0 var(--info)}
  .wc-row.head{color:var(--tx-mut);font-size:11px;text-transform:uppercase;letter-spacing:.05em;background:none}
  .wc-row .mac{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;color:var(--tx-dim)}
  .wc-row.taken{color:var(--ok)}
  .wc-row.wide{grid-template-columns:minmax(140px,1.5fr) minmax(92px,.9fr) minmax(90px,.9fr)
    minmax(88px,.9fr) minmax(92px,.9fr) minmax(84px,.85fr) minmax(104px,1fr) minmax(66px,.65fr) minmax(72px,.7fr)}
  .wc-row.wide > *{min-width:0}
  #wifi-seen .oth-row{grid-template-columns:1.6fr 1.4fr .6fr .6fr .7fr .5fr .8fr .8fr}
  .oth-row{display:grid;grid-template-columns:minmax(140px,1.6fr) minmax(140px,1.2fr) minmax(64px,.6fr)
    minmax(90px,.8fr) minmax(70px,.6fr) minmax(84px,.7fr) minmax(120px,1.1fr) minmax(80px,.8fr);
    gap:8px;align-items:center;padding:5px 6px;border-radius:8px;font-size:13px}
  .oth-row > *{min-width:0}
  .oth-row:nth-child(odd){background:var(--panel2)}
  .oth-row:not(.head):hover{background:rgba(88,166,255,.07);box-shadow:inset 3px 0 0 var(--info)}
  .oth-row.head{color:var(--tx-mut);font-size:11px;text-transform:uppercase;letter-spacing:.05em;background:none}
  .oth-row .mac{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;color:var(--tx-dim)}
  .chip-clash{margin-left:6px;padding:1px 6px;border-radius:999px;font-size:10px;text-transform:uppercase;
    letter-spacing:.05em;background:color-mix(in srgb, var(--warn) 20%, var(--panel));color:var(--warn)}
  @media (max-width:820px){.oth-row{grid-template-columns:1fr 1fr}.oth-row.head{display:none}}
  .chip-guest{margin-left:6px;padding:1px 6px;border-radius:999px;background:var(--panel);
    border:1px solid var(--line);font-size:10.5px;text-transform:uppercase;letter-spacing:.05em}
  .sig-good{color:var(--ok)} .sig-ok{color:var(--tx-dim)} .sig-poor{color:var(--warn)}
  .chip-dfs{display:inline-block;margin-left:5px;padding:0 6px;border-radius:999px;font-size:10px;
    letter-spacing:.06em;background:color-mix(in srgb, var(--warn) 22%, var(--panel));color:var(--warn)}
  /* built like the gateway rows: the header is the same grid with a modifier,
     and every control fills its cell, or the columns drift apart */
  /* A message is mostly its words, so it gets a block of its own rather than
     a column squeezed between the settings that describe it. */
  .msg-card{border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:10px;background:var(--panel2)}
  .msg-top{display:grid;grid-template-columns:minmax(130px,1.2fr) minmax(150px,1.6fr) 132px 116px 1fr 84px;
    gap:10px;align-items:end}
  .msg-field{display:flex;flex-direction:column;gap:5px;min-width:0}
  .msg-field > label{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--tx-mut)}
  /* the phones under the links are boxes of the same card and must look it:
     their row is not a .tap-row, so they were left with whatever the browser
     draws a bare input as */
  .msg-card input, .msg-card textarea, .tap-row input, .tapkey-row input{font:inherit;font-size:13.5px;background:var(--panel);
    color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%;
    box-sizing:border-box}
  .msg-card textarea{resize:vertical;min-height:66px;line-height:1.45;font-family:inherit}
  .msg-card input:focus, .msg-card textarea:focus, .tap-row input:focus,
  .tapkey-row input:focus{outline:none;border-color:var(--info)}
  .msg-body{margin-top:10px}
  .msg-tools{display:flex;gap:6px;align-items:center;margin:6px 0 0;flex-wrap:wrap}
  .msg-preview{margin-top:10px;font-size:12.5px;color:var(--tx-dim)}
  .msg-preview:empty{display:none}
  .msg-preview .lbl.warn{color:var(--warn)}
  .msg-preview .lbl{color:var(--tx-mut);font-size:11px;text-transform:uppercase;letter-spacing:.06em;display:block;margin-bottom:5px}
  /* a phone notification, roughly as ntfy / Telegram draw one */
  .ntfy{max-width:420px;background:var(--panel2);border:1px solid var(--line);border-radius:14px;padding:10px 13px;color:var(--tx);box-shadow:0 6px 18px rgba(0,0,0,.25)}
  .ntfy-head{display:flex;justify-content:space-between;font-size:11px;color:var(--tx-mut);margin-bottom:4px}
  .ntfy-app{font-weight:600;letter-spacing:.02em}
  .ntfy-title{font-weight:600;font-size:13.5px;margin-bottom:2px}
  .ntfy-text{white-space:pre-wrap;line-height:1.35}
  .ntfy-img{margin-top:6px;font-size:11.5px;color:var(--tx-mut);word-break:break-all}
  .ntfy.crit{border-color:rgba(248,81,73,.5)} .ntfy.crit .ntfy-title{color:var(--crit)}
  .ntfy.warn .ntfy-title{color:var(--warn)} .ntfy.info .ntfy-title{color:var(--info)}
  .msg-actions{display:flex;gap:6px;justify-self:end}
  /* wide and low rather than a tall column: ~180 emoji or the whole fact
     catalogue should fit on screen without scrolling the page */
  .pickbox{position:absolute;z-index:70;background:var(--panel);border:1px solid var(--line);border-radius:12px;
    padding:10px 12px;box-shadow:0 12px 32px rgba(0,0,0,.45);width:min(720px,94vw);max-height:min(70vh,520px);overflow:auto}
  .pickbox.facts{width:min(860px,94vw)}
  .pickbox.facts .row{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:2px 8px}
  .pickbox.facts button{font-size:12.5px;text-align:left;padding:3px 6px;white-space:normal;overflow-wrap:anywhere;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--info)}
  .pickbox.facts button .d{font-family:inherit;color:var(--tx-dim);font-size:11.5px;margin-left:6px;font-family:system-ui,sans-serif}
  /* a grid, so the count and the bin line up down the column however long a
     room's name is */
  .room-row{display:grid;grid-template-columns:minmax(160px,300px) 120px 36px;align-items:center;gap:10px;padding:5px 0}
  .room-row > input{width:100%;box-sizing:border-box}
  .room-row > .muted{justify-self:start;white-space:nowrap}
  .room-row > .iconbtn{justify-self:end}
  /* The phones borrowed the rooms' row, which keeps 36px at the end for one
     button. Two of them did not fit and stood on top of "last used ...".
     Their own row: the name, then whatever is left over, then as much as the
     buttons need - hard against the right edge, clear of the words. */
  .tapkey-row{display:grid;grid-template-columns:minmax(160px,300px) minmax(0,1fr) max-content;
    align-items:center;gap:12px;padding:5px 0}
  .tapkey-row > input{width:100%;box-sizing:border-box}
  .tapkey-row > .muted{justify-self:start;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .tapkey-row > .btnrow{justify-self:end;flex-wrap:nowrap;gap:6px}
  .room-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:7px 10px;min-width:180px}
  .room-assign{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px;margin-top:8px;align-items:stretch}
  .room-item{display:grid;grid-template-columns:minmax(0,1fr);gap:3px;font-size:13px;color:var(--tx-dim);min-width:0;
    padding:6px 8px;border:1px solid var(--line);border-radius:9px;background:var(--panel2)}
  .room-item .room-name{color:var(--tx);font-weight:600;word-break:break-word;line-height:1.25}
  /* Nothing has to be in a room, so a thing that is in none is a question
     left open rather than a fault - the same amber the rest of the page uses
     for that, at a fraction of its strength. A line down the edge and a tint
     barely off the card: the eye finds them when it goes looking and they do
     not shout across the card at somebody who is not. */
  .room-item.unplaced{border-color:rgba(210,153,34,.3);background:rgba(210,153,34,.05);
    box-shadow:inset 2px 0 0 rgba(210,153,34,.5)}
  .room-item.unplaced select{color:var(--tx-dim)}
  .room-item select{font:inherit;font-size:12.5px;background:var(--panel);color:var(--tx);border:1px solid var(--line);border-radius:7px;padding:4px 6px;width:100%;min-width:0}
  .eicon{display:inline-block;width:20px;text-align:center;margin-right:2px;opacity:.85}
  .tbl tr.eroom td{background:rgba(88,166,255,.06);border-top:1px solid var(--line)}
  .tbl tr.eroom .efold{display:inline-block;width:12px;color:var(--tx-mut)}
  .tbl tr.eplug td:first-child{padding-left:22px}
  /* the row above the room cards: every label on the same line, every control
     under its own, whatever kind of control it is */
  .heat-bar{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,max-content));gap:10px 26px;align-items:end;margin-top:10px}
  .heat-bar .set-item{gap:6px}
  .heat-bar .heat-sw{display:flex;align-items:center;height:34px}
  .heat-bar input{max-width:110px}
  .heat-actions{display:flex;align-items:center;gap:10px;height:34px}
  .heatcard{padding:14px 16px}
  .heatcard.warn{border-color:rgba(210,153,34,.45)}
  .heat-head{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap}
  .heat-head h3{margin:0;font-size:15px}
  .heat-title{display:flex;align-items:center;gap:10px}
  .heatcard.unheated{opacity:.6}
  .heat-now{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
  .heat-ctl{display:inline-flex;align-items:center;gap:6px;margin-left:8px}
  .heat-ctl .lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .heat-temp{font-size:21px;font-weight:650;color:var(--tx)}
  .heat-want{font-size:13px;color:var(--info);display:inline-flex;align-items:baseline;gap:7px}
  .heat-want.hand{color:var(--warn);font-size:16px;font-weight:650}
  .heat-hand{font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;padding:2px 7px;border-radius:999px;background:rgba(210,153,34,.16);color:var(--warn)}
  .heat-hand.dim{background:rgba(139,148,158,.12);color:var(--tx-mut)}
  .heat-valve{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-top:5px;font-size:12.5px;color:var(--tx-dim)}
  .heat-valve .hv-name{color:var(--tx);font-weight:600}
  .heat-valve .hv-bits{color:var(--tx-mut);margin-right:6px}
  .heat-valve button{margin-left:6px}
  .heat-handbar{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-top:8px}
  .heat-handbar .lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut);margin-right:2px}
  .heat-slider{-webkit-appearance:none;appearance:none;flex:1 1 190px;min-width:130px;max-width:340px;height:8px;border-radius:999px;
    background:linear-gradient(90deg,var(--info) var(--fill,50%),rgba(139,148,158,.22) var(--fill,50%));outline:none;cursor:pointer;padding:0;border:none}
  .heat-slider::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:var(--tx);
    border:3px solid var(--info);box-shadow:0 1px 4px rgba(0,0,0,.5);cursor:grab}
  .heat-slider::-moz-range-thumb{width:16px;height:16px;border-radius:50%;background:var(--tx);border:3px solid var(--info);cursor:grab}
  .heat-read{min-width:66px;text-align:center;font-size:14px;font-weight:650;color:var(--info);font-variant-numeric:tabular-nums}
  .heat-handbar select{font:inherit;font-size:12px;background:var(--panel2);color:var(--tx-dim);border:1px solid var(--line);border-radius:8px;padding:4px 7px}
  .heat-handbar button{min-width:30px}
  .heat-presets{display:inline-flex;gap:4px;margin-left:10px;padding-left:10px;border-left:1px solid var(--line)}
  .heat-presets .btn.on{color:var(--info);border-color:rgba(88,166,255,.5);background:rgba(88,166,255,.12)}
  .heat-temps{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:8px 12px;margin-top:10px}
  .heat-t select{min-width:0;max-width:100%}
  .heat-t{display:flex;flex-direction:column;gap:4px}
  .heat-t .lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .heat-t input,.heat-t select{font:inherit;font-size:13px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 8px}
  .heat-plan{margin-top:12px;display:flex;flex-direction:column;gap:6px}
  /* the switch line stands apart from the plan above it, and its label and
     switch sit on the same baseline instead of the switch riding high */
  .heat-window{margin-top:14px;padding-top:12px;border-top:1px solid var(--line);align-items:center;gap:12px}
  .heat-window label{margin:0}
  .heat-windows{display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center;margin-top:8px;font-size:12.5px;color:var(--tx-dim)}
  .heat-windows .lbl{flex-basis:100%;font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .heat-win{display:inline-flex;align-items:center;gap:5px;cursor:pointer}
  .heat-step{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
  .heat-step input[type=time],.heat-step select{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:4px 7px}
  .heat-days{display:flex;gap:3px}
  .daybtn{font:inherit;font-size:11px;padding:3px 6px;border-radius:7px;border:1px solid var(--line);background:transparent;color:var(--tx-mut);cursor:pointer}
  .daybtn.on{background:rgba(88,166,255,.16);color:var(--info);border-color:rgba(88,166,255,.45)}
  .acbox{position:absolute;z-index:71;background:var(--panel);border:1px solid var(--line);border-radius:10px;box-shadow:0 12px 32px rgba(0,0,0,.45);
    min-width:320px;max-width:min(560px,92vw);max-height:300px;overflow:auto;padding:4px;font-size:12.5px}
  .ac-group{padding:6px 8px 2px;font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .ac-row{display:grid;grid-template-columns:max-content 1fr;column-gap:10px;padding:5px 8px;border-radius:7px;cursor:pointer;align-items:baseline}
  .ac-row.sel{background:rgba(88,166,255,.14)}
  .ac-name{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--info);white-space:nowrap}
  .ac-desc{color:var(--tx);white-space:normal;overflow-wrap:anywhere;line-height:1.35}
  .ac-ex{grid-column:2;color:var(--tx-mut);font-size:11.5px;white-space:normal;overflow-wrap:anywhere}
  .ac-empty{padding:8px 10px;color:var(--tx-mut)}
  .pickbox h4{margin:6px 0 4px;font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut);font-weight:600}
  .pickbox .row{display:flex;flex-wrap:wrap;gap:3px}
  .pickbox button{background:none;border:0;font-size:19px;line-height:1;padding:4px 5px;border-radius:8px;cursor:pointer}
  .pickbox button:hover{background:var(--panel2)}
  @media (max-width:760px){.msg-top{grid-template-columns:1fr 1fr}}
  .person-row{display:grid;grid-template-columns:54px minmax(110px,1fr) minmax(140px,1fr) minmax(180px,2fr) 96px 150px 132px 40px;
    gap:8px;align-items:center;padding:7px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .person-why{grid-column:1 / -1;padding:0 0 8px 62px;margin-top:-4px;font-size:12.5px;color:var(--tx-dim);border-bottom:1px solid rgba(38,44,55,.5)}
  .person-why b{color:var(--tx-mut);font-weight:600}
  .person-row:has(+ .person-why){border-bottom:none}
  .person-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%;box-sizing:border-box}
  .person-row input:focus{outline:none;border-color:var(--info)}
  .person-head{color:var(--tx-mut);font-size:11px;letter-spacing:.09em;text-transform:uppercase;
    border-bottom:1px solid var(--line);padding-bottom:8px}
  .person-head .r, .person-row .r{justify-self:end}
  .ptrig-head{color:var(--tx-mut);font-size:11px;letter-spacing:.09em;text-transform:uppercase;
    border-bottom:1px solid var(--line);padding-bottom:8px}
  .person-macs{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
  .macchip{display:inline-flex;align-items:baseline;gap:7px;padding:3px 9px;border-radius:999px;background:var(--panel2);
    border:1px solid var(--line);font-size:12.5px}
  .macchip .macname{font-weight:600}
  .macchip .macaddr{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px;color:var(--tx-mut)}
  .macchip button{background:none;border:0;color:var(--tx-mut);cursor:pointer;font-size:13px;line-height:1;padding:0}
  .macchip button:hover{color:var(--crit)}
  .ptrig-row{display:grid;
    grid-template-columns:46px minmax(110px,1fr) minmax(120px,1.1fr) 20px minmax(160px,1.6fr) minmax(96px,.9fr) 40px;
    gap:8px;align-items:center;padding:7px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .ptrig-row select{width:100%;box-sizing:border-box}
  .ptrig-row .r{justify-self:end}
  .dbb-row{display:grid;grid-template-columns:minmax(130px,170px) minmax(160px,1fr) 90px 320px;gap:10px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .dbb-row .dbb-acts{display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap}
  .dbb-head{color:var(--tx-mut);font-size:11px;letter-spacing:.7px;text-transform:uppercase;font-weight:700}
  .dbb-acts{display:inline-flex;gap:6px}
  @media (max-width:640px){
    .person-row,.ptrig-row{grid-template-columns:1fr 1fr;grid-auto-rows:auto}
    .person-head,.ptrig-head{display:none}}
  @media (max-width:900px){.dbb-row{grid-template-columns:1fr 1fr}}
  .pager{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:12px}
  .pager .pg.current{border-color:var(--info);color:var(--info);opacity:1}
  .pager .pg:disabled.current{opacity:1}
  .pager .pg-dots{color:var(--tx-mut);padding:0 4px} .pager .pg-info{margin-left:8px}
  .combine-sel{font-weight:700;min-width:64px}
  .subtabs{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}
  .subtabs button{appearance:none;cursor:pointer;font:inherit;font-size:13.5px;font-weight:600;
    background:var(--panel2);color:var(--tx-dim);border:1px solid var(--line);border-radius:999px;padding:7px 15px;
    transition:color .12s,border-color .12s,background .12s}
  .subtabs button:hover{color:var(--tx);border-color:var(--tx-mut)}
  .subtabs button.on{color:var(--info);border-color:var(--info);background:rgba(88,166,255,.10)}
  #tab-control .grid.charts > .sec-off{display:none !important}
  .kv-list{display:grid;grid-template-columns:1fr;gap:0}
  .kv-list .kv{display:flex;justify-content:space-between;gap:16px;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5);font-size:13.5px}
  .kv-list .kv .k{color:var(--tx-dim)}
  .kv-list .kv .v{text-align:right;font-weight:600}
  #db-restore-select{font:inherit;font-size:13px}
  .attnbox.wide{width:min(900px,96vw)}
  .attnbox{width:min(640px,94vw);max-height:86vh;overflow:auto;border-radius:20px;padding:22px 24px 20px;
    background:linear-gradient(160deg,#1b2230 0%,#141922 60%,#11151d 100%);border:1px solid #2b3444;
    box-shadow:0 24px 70px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.03) inset;animation:rise .2s cubic-bezier(.2,.9,.3,1)}
  .attnhead{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}
  .attnhead h3{margin:0;font-size:16px}
  .attn-item{display:grid;grid-template-columns:auto 1fr;gap:6px 12px;padding:10px 0;border-bottom:1px solid rgba(38,44,55,.6);align-items:start}
  .attn-item:last-child{border-bottom:none}
  .attn-item .lvl{font-size:10.5px;letter-spacing:.1em;text-transform:uppercase;font-weight:700;padding:3px 8px;border-radius:999px;margin-top:2px;white-space:nowrap}
  .attn-item .lvl.crit{background:rgba(248,81,73,.16);color:var(--crit)}
  .attn-item .lvl.warn{background:rgba(210,153,34,.16);color:var(--warn)}
  .attn-item .lvl.info{background:rgba(88,166,255,.14);color:var(--info)}
  .attn-item .who{font-weight:600;cursor:pointer}
  .attn-item .who:hover{color:var(--info)}
  .attn-item .why{color:var(--tx-dim);font-size:13px;line-height:1.5}
  .attn-item .when{color:var(--tx-mut);font-size:12px}
  .attn-ok{color:var(--ok);font-weight:600;padding:6px 0 2px}
  .attn-item .lvl.ok{background:rgba(63,185,80,.14);color:var(--ok)}
  .attn-item .lvl.dim{background:rgba(139,148,158,.14);color:var(--tx-mut)}
  .bindtbl td,.bindtbl th{padding:6px 10px}
  /* the same grid the other editors use, so one row of labels above the
     sections does for all of them */
  /* six columns, not seven: the grip is positioned over the row rather than
     taking a cell of its own, so a column reserved for it put every heading
     one place to the left of what it named */
  .tap-row{display:grid;grid-template-columns:44px minmax(140px,1.05fr) minmax(140px,1.05fr)
    minmax(115px,.8fr) 62px minmax(80px,.55fr) var(--tap-tools,auto);gap:10px;align-items:center;
    padding:7px 6px;border-radius:10px}
  /* .hasgrab adds the room for the handle; the header has no handle, so it is
     nudged by the same amount or every column sits one notch to the left */
  /* Two faults that were in every one of these and were fixed one at a time
     until it was plain they are the same two faults:
       - a row carries .hasgrab, which indents it to make room for the drag
         handle; a header has no handle, so without the same indent every
         column name sits one notch to the left of what it names;
       - a header that inherits its row's rounded corners lifts the ends of
         its bottom border off the line.
     Said once here rather than five times apart. */
  .tap-head,.bind-head,.person-head,.ptrig-head,.smscmd-head,.gw-head,.mchan-head{border-radius:0}
  .tap-head,.bind-head,.person-head,.ptrig-head,.smscmd-head{padding-left:16px}
  /* The gateways carry no drag handle and so no indent - not at rest, not
     while arranging; measured with gateways on the page, both ways. A header
     indented to match an indent the rows never take is what put every name
     sixteen pixels right of its box. It takes none. */
  .tap-row:hover:not(.tap-head){outline:1px solid rgba(88,166,255,.35);outline-offset:2px}
  .tap-head{color:var(--tx-mut);font-size:11px;letter-spacing:.7px;text-transform:uppercase;font-weight:700;
    border-bottom:1px solid var(--line);padding-bottom:6px;margin-bottom:2px}
  .tap-row.offrow{opacity:.55}
  .tap-what{display:flex;flex-direction:column;gap:6px;min-width:0}
  /* the writing desk is a second line of the same row, so the columns above
     it stay where they are however much is written underneath */
  .tap-storybox{grid-column:1 / -1;padding:2px 0 4px 44px}
  .tap-act{min-width:0;display:flex;align-items:center}
  .tap-act select{width:100%}
  .tap-act .scene-note{line-height:1.3}
  .tap-storybox{display:flex;flex-direction:column;gap:6px;min-width:0}
  .tap-storybox[hidden],.tap-storytools[hidden],.tap-story[hidden],.tap-preview[hidden]{display:none}
  .tap-story{font:inherit;font-size:13.5px;background:var(--panel);color:var(--tx);
    border:1px solid var(--line);border-radius:10px;padding:9px 12px;width:100%;
    box-sizing:border-box;resize:vertical;min-height:92px;line-height:1.5;font-family:inherit}
  .tap-story:focus{outline:none;border-color:var(--info)}
  .tap-storytools{margin-top:0}
  .tap-preview{margin-top:2px;font-size:12px}
  .tap-what > *{min-width:0}
  .tap-tools{justify-self:end;white-space:nowrap}
  @media (max-width:700px){.tap-row{grid-template-columns:1fr 1fr} .tap-head{display:none}}
  .tap-used{padding:7px 0}
  /* how a link was opened last time: plain when it is on the road the links
     are set to, amber when it is still on the old one and there is a switch
     waiting to be thrown - a question left open, not a fault */
  /* how the links are opened, over the list of them: the switch is in
     Settings and the phones are at the foot of the card, and a person looking
     at their links is looking at neither */
  .tapmode{display:flex;flex-wrap:wrap;align-items:center;gap:10px;padding:8px 10px;margin-bottom:10px;
    border:1px solid var(--line);border-radius:10px;background:var(--panel2);font-size:12.5px}
  .tapmode-what{font-weight:600;color:var(--tx)}
  .tapmode-code{color:var(--tx-mut)}
  .tapmode-code.on{color:var(--ok)}
  .tapmode.on{border-color:rgba(63,185,80,.3)}
  .tapmode .btn{margin-left:auto}
  /* one press waiting for somebody to say yes */
  .appr-row{display:flex;align-items:center;gap:12px;padding:9px 10px;margin-bottom:8px;
    border:1px solid var(--line);border-left:3px solid var(--info);border-radius:10px;background:var(--panel2)}
  .appr-icon{font-size:15px}
  .appr-what{display:flex;flex-direction:column;gap:2px;min-width:0;flex:1}
  .appr-link{font-weight:620;color:var(--tx)}
  .appr-left{font-variant-numeric:tabular-nums;color:var(--tx-dim);white-space:nowrap}
  .appr-left.soon{color:var(--warn);font-weight:650}
  /* the same hand every other row on the page gets under the pointer */
  .appr-row:hover{background:rgba(88,166,255,.07)}
  .appr-router.off{opacity:.75}
  .appr-router.sick{filter:grayscale(1)}
  /* the boxes in the variables dialogue: the same shape every box on the page
     has, rather than whatever the browser draws a bare input as */
  .varbox{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:9px;padding:7px 10px;width:150px;box-sizing:border-box;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
  .varbox.wide{width:240px;max-width:100%}
  .varbox:focus{border-color:var(--info);outline:none}
  .varbox::placeholder{color:var(--tx-mut);font-family:inherit}
  /* a cell that must not be broken across lines. There was a rule for this,
     but only inside a wifi tile, so every table cell asking for it wrapped
     anyway - a date over two lines and "let back in" over three. */
  td.nowrap, th.nowrap, .nowrap{white-space:nowrap}
  /* on the list to be seen, and doing nothing: struck through, in the colour
     of something that is allowed, so it cannot be read as kept out */
  .appr-row.spared{border-left-color:var(--ok);background:rgba(63,185,80,.06)}
  .appr-row.spared .appr-link{text-decoration:line-through;text-decoration-color:var(--tx-mut)}
  .appr-row.spared .appr-left{color:var(--ok)}
  .appr-row .iconbtn{opacity:.55;transition:opacity .12s}
  .appr-row:hover .iconbtn,.appr-row:focus-within .iconbtn{opacity:1}
  /* the same hand a row on the network gets: a tint and a line down the
     edge, so the eye keeps its place across eight columns */
  #approvals-past td{vertical-align:top}
  #approvals-past tbody tr:nth-child(odd){background:var(--panel2)}
  #approvals-past tbody tr:hover{background:rgba(88,166,255,.07)}
  /* the line goes on the first cell, not on the row: with border-collapse a
     shadow on a row is drawn under the cells and comes out clipped */
  #approvals-past th:first-child, #approvals-past td:first-child{padding-left:7px}
  #approvals-past tbody tr:hover td:first-child{box-shadow:inset 3px 0 0 var(--info)}
  #blocked-history tbody tr:nth-child(odd){background:var(--panel2)}
  #blocked-history tbody tr:hover{background:rgba(88,166,255,.07)}
  #blocked-history th:first-child, #blocked-history td:first-child{padding-left:7px}
  #blocked-history tbody tr:hover td:first-child{box-shadow:inset 3px 0 0 var(--info)}
  /* a box standing in a row of buttons: the same shape a box in Settings has,
     rather than whatever the browser draws a bare input as */
  #blocked-ip{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:9px;padding:8px 11px;width:220px;max-width:100%;
    box-sizing:border-box;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
  #blocked-ip:focus{border-color:var(--info);outline:none}
  #blocked-ip::placeholder{color:var(--tx-mut)}
  .tap-way{font-size:11px;color:var(--tx-mut)}
  .tap-way.behind{color:var(--warn)}
  .bindrow{cursor:pointer}
  .bindrow-bad td{background:color-mix(in srgb, var(--warn) 9%, transparent)}
  .bindmark{width:20px;text-align:center;opacity:.75}
  .bindacts{white-space:nowrap;text-align:right;opacity:0;transition:opacity .12s}
  .bindrow:hover .bindacts,.bindrow:focus-within .bindacts{opacity:1}
  .bindacts .btn{margin-left:4px}
  .binddetail td{background:var(--panel2);border-top:0}
  .binddetail-in{display:flex;flex-direction:column;gap:3px;padding:4px 2px 8px 30px;font-size:12.5px}
  .bindline{display:flex;gap:10px;align-items:baseline}
  .bindlabel{min-width:110px;color:var(--tx-mut);font-size:11px;letter-spacing:.05em;text-transform:uppercase}
  .bindvalue{color:var(--tx-dim);overflow-wrap:anywhere}
  .bindbad{border:1px solid var(--warn);border-radius:10px;padding:10px 12px;margin-bottom:10px;
    background:color-mix(in srgb, var(--warn) 7%, transparent)}
  .bindname{font-weight:650;color:var(--tx)}
  .tbl tr.dim td{color:var(--tx-dim)}
  .mqtt-warn{color:var(--warn);font-size:12px;align-self:center;max-width:340px;overflow-wrap:anywhere}
  .mqtt-strip{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:8px 10px;margin-top:6px;border-top:1px dashed var(--line)}
  .mqtt-strip .lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .mqtt-strip input{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 8px;min-width:120px}
  .mqtt-strip input:disabled,.mqtt-strip select:disabled{opacity:.45}
  .mqtt-strip select{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 8px}
  .pc-block{border-bottom:1px solid rgba(38,44,55,.5)}
  .pc-line{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:7px 0;flex-wrap:wrap}
  .pc-left{display:inline-flex;align-items:center;gap:9px;cursor:pointer;user-select:none;min-width:0;flex:1 1 260px}
  .pc-left .fold{color:var(--tx-mut);width:12px}
  .pc-name{font-weight:650;color:var(--tx);white-space:normal;overflow-wrap:anywhere}
  .pc-draw{font-family:ui-monospace,Menlo,monospace;font-variant-numeric:tabular-nums;color:var(--tx-dim);font-size:12.5px}
  .pc-btns{display:inline-flex;gap:6px;flex:0 0 auto}
  .pc-body{display:none;padding:2px 0 10px 21px}
  .pc-block.open .pc-body{display:block}
  .agroup-row{grid-template-columns:44px minmax(160px,1.6fr) 64px 36px !important}
  /* One grid for the whole table: the rows take part in it rather than each
     being a grid of its own, which is why the heading used to sit over
     nothing in particular. */
  /* Each row is a row of its own, sharing one column template, so the
     highlight is a single band the whole way across rather than four
     backgrounds with the joins showing. */
  .sms-whotable{--who-cols:minmax(140px,1.6fr) minmax(150px,1fr) 110px 120px;
    margin-top:6px;border:1px solid var(--line);border-radius:10px;background:var(--panel2);overflow:hidden}
  .sms-whotable-row{display:grid;grid-template-columns:var(--who-cols);align-items:center;
    border-bottom:1px solid rgba(38,44,55,.7)}
  .sms-whotable-row:last-child{border-bottom:0}
  .sms-whotable-row:not(.head):hover{background:rgba(88,166,255,.07)}
  .sms-whotable-cell{background:none;border:0}
  .sms-whotable-cell .sw{flex:0 0 auto}
  /* One band per row: no rounding or border on the cells themselves, or the
     row reads as four boxes with the highlight cut between them. */
  .sms-whotable-row > *{padding:9px 12px;border:0;border-radius:0;background:none;
    font-size:13px;color:var(--tx-dim);min-height:42px;display:flex;align-items:center}
  .sms-whotable-row.head{background:rgba(255,255,255,.02);border-bottom:1px solid var(--line)}
  .sms-whotable-row.head > *{padding:8px 12px;font-size:10.5px;letter-spacing:.07em;
    text-transform:uppercase;color:var(--tx-mut);min-height:0}
  .sms-person-name{color:var(--tx);font-weight:600}
  .sms-person-num{font-family:ui-monospace,Menlo,monospace;font-variant-numeric:tabular-nums}
  .msg-ways{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
  .msg-way{display:flex;gap:6px;align-items:center;font-size:12.5px;color:var(--tx-dim);cursor:pointer;white-space:nowrap}
  .msg-smswho{display:flex;flex-direction:column;gap:8px;margin:8px 0 4px;padding:9px 11px;
    border:1px solid var(--line);border-left:3px solid var(--info);border-radius:10px;background:var(--panel2)}
  .msg-towrap.off{opacity:.45}
  .whopick{display:flex;flex-direction:column;gap:2px;padding:6px;max-height:260px;overflow:auto}
  .whopick button{text-align:left;font-size:13px;padding:6px 9px;border-radius:8px;white-space:nowrap}
  .whopick .dim{color:var(--tx-mut);font-family:ui-monospace,Menlo,monospace;font-size:12px}
  .msg-smswho .set-item{gap:4px}
  .smscmd-row{display:grid;grid-template-columns:44px minmax(150px,1.3fr) minmax(190px,1.5fr) minmax(130px,.9fr) 44px 44px 36px;
    gap:8px 10px;align-items:center;padding:11px 0 9px;border-bottom:1px solid rgba(38,44,55,.5)}
  /* the answer is written, not squeezed into a column: its own line, the full
     width, with its tools and its preview under it - the same shape the alert
     editor uses */
  #sms-grid > .section{margin:0 0 10px}
  #sms-grid .section-body .set-grid{padding:6px 16px 14px}
  /* a switch stands where an input's box would, so the bands read straight
     across whether the setting is a yes-or-no or something to type in */
  #sms-grid .set-item .sms-sw{display:flex;align-items:center;gap:10px;min-height:39px;cursor:pointer}
  #sms-grid .set-item .sms-sw-word{font-size:13px;color:var(--tx-dim);letter-spacing:.02em}
  #sms-grid .set-item .btnhelp{min-height:1em;line-height:1.35;overflow-wrap:anywhere}
  /* two lines of label and one of note, whether or not the browser has
     subgrid: the boxes then sit level across the row either way */
  #sms-grid .set-item label{line-height:1.3;display:flex;align-items:flex-end;min-height:2.6em}
  #sms-grid .set-item .btnhelp{min-height:1.35em}
  .sms-extras .set-item label{display:flex;align-items:flex-end;min-height:2.6em;line-height:1.3}
  .sms-extras .set-item .btnhelp{min-height:1.35em;line-height:1.35}
  @supports (grid-template-rows: subgrid) {
    .sms-extras{grid-auto-rows:auto}
    .sms-extras > .set-item{display:grid;grid-template-rows:subgrid;grid-row:span 3;
      grid-template-columns:minmax(0,1fr);gap:5px;align-content:start}
  }
  #sms-grid .section-head .muted{font-weight:400;overflow-wrap:anywhere}
  #sms-grid select{width:100%;text-overflow:ellipsis}
  .sms-push{display:flex;flex-direction:column;gap:7px;margin-top:10px;grid-column:1/-1;
    border:1px solid var(--line);border-left:3px solid var(--info);border-radius:10px;padding:10px 12px;background:var(--panel2)}
  .sms-push-head{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .sms-push-url{font-family:ui-monospace,Menlo,monospace;font-size:12.5px;color:var(--tx);overflow-wrap:anywhere}
  .sms-push .btn{align-self:flex-start}
  .smscmd-answer{display:flex;align-items:center;gap:9px;margin-bottom:2px}
  .smscmd-replycell.quiet textarea{opacity:.45}
  .smscmd-replycell{grid-column:1/-1;display:flex;flex-direction:column;gap:7px;min-width:0;padding:2px 0 2px 54px}
  .smscmd-reply{min-height:76px;max-height:240px;resize:vertical;line-height:1.45;width:100%;box-sizing:border-box;
    font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);
    border-radius:10px;padding:9px 12px}
  .smscmd-reply:focus{border-color:var(--info);outline:none;box-shadow:0 0 0 3px rgba(88,166,255,.16)}
  .smscmd-replycell .msg-tools{display:flex;gap:6px;flex-wrap:wrap;margin:0;align-items:center}
  .smscmd-replycell .lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .sms-bubble{background:var(--panel2);border:1px solid var(--line);border-radius:12px 12px 12px 4px;
    padding:8px 11px;color:var(--tx);font-size:12.5px;white-space:pre-wrap;overflow-wrap:anywhere;max-width:40em}
  .smscmd-row > .iconbtn{justify-self:end;width:34px;height:34px;flex:0 0 auto;
    display:inline-flex;align-items:center;justify-content:center;padding:0 !important;gap:0}
  .smscmd-row > .iconbtn svg{display:block}
  .smscmd-head{padding-top:0;padding-right:0;padding-bottom:4px;padding-left:16px;border:0;font-size:10.5px;letter-spacing:.07em;text-transform:uppercase;color:var(--tx-mut)}
  .smscmd-head span{padding-left:2px}
  /* A fold insets what it holds by ten and a header stands above the folds,
     so it takes the same ten or every name sits that far left of its box.
     Written after the headers' own padding so that order agrees with
     specificity rather than relying on one of them. */

  .smscmd-do{display:flex;align-items:center;min-width:0}
  .smscmd-do select{width:100%}
  .smscmd-row input,.smscmd-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:9px;padding:7px 10px;min-width:0;width:100%;box-sizing:border-box}
  .sgroup-row{display:grid;grid-template-columns:44px minmax(120px,1.1fr) minmax(110px,.9fr) minmax(140px,1fr) 74px minmax(110px,.8fr) 60px 36px;
    gap:8px;align-items:center;padding:9px 0 6px;border-bottom:1px solid rgba(38,44,55,.5);position:relative}
  .sgroup-row input,.sgroup-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:9px;padding:7px 10px;min-width:0;width:100%;box-sizing:border-box}
  .sgroup-now{font-family:ui-monospace,Menlo,monospace;font-variant-numeric:tabular-nums;color:var(--info);text-align:right;font-weight:600}
  .sgroup-members{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:5px;padding:2px 0 6px 44px}
  .sgroup-chip{display:inline-flex;align-items:center;gap:6px;font-size:12.5px;color:var(--tx-dim);cursor:pointer;
    border:1px solid var(--line);border-radius:999px;padding:4px 10px;background:var(--panel2)}
  .sgroup-chip.on{color:var(--tx);border-color:rgba(88,166,255,.5);background:rgba(88,166,255,.12)}
  .sgroup-chip input{width:auto;accent-color:var(--info)}
  .sections{display:flex;flex-direction:column;gap:6px;margin-top:6px}
  .section{border:1px solid var(--line);border-radius:10px;background:rgba(88,166,255,.03)}
  .section-head{display:flex;align-items:center;gap:9px;padding:8px 10px 8px 22px;cursor:pointer;user-select:none;position:relative}
  .section-head .fold{color:var(--tx-mut);width:12px} .section-name{font-weight:650;color:var(--tx)}
  .section-count{color:var(--tx-mut);font-size:12px;margin-left:2px}
  .section-body > .muted{padding:6px 4px}
  .section-tools{margin-left:auto;display:inline-flex;gap:4px}
  .section-body{display:none;padding:2px 10px 8px}
  .section.open .section-body{display:block}
  .section-add{margin-top:8px}
  .movemenu{position:fixed;z-index:160;min-width:190px;background:var(--panel);border:1px solid var(--line);border-radius:10px;
    box-shadow:0 12px 34px rgba(0,0,0,.55);padding:6px;display:flex;flex-direction:column;gap:2px}
  .mm-head{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut);padding:4px 8px 6px}
  .mm-item{font:inherit;font-size:13px;text-align:left;background:transparent;border:none;color:var(--tx);padding:7px 10px;border-radius:7px;cursor:pointer}
  .mm-item:hover{background:rgba(88,166,255,.14)} .mm-item.on{color:var(--info)} .mm-new{color:var(--tx-dim);border-top:1px solid var(--line);border-radius:0 0 7px 7px;margin-top:2px}
  .rule-pack{display:block}
  .person-phone{font-variant-numeric:tabular-nums}
  .sms-people{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:10px}
  .sms-free{font:inherit;font-size:13px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);
    border-radius:999px;padding:5px 12px;min-width:180px;font-variant-numeric:tabular-nums}
  .sms-compose textarea{width:100%;box-sizing:border-box;font:inherit;font-size:14px;line-height:1.45;background:var(--panel2);
    color:var(--tx);border:1px solid var(--line);border-radius:12px;padding:11px 13px;resize:vertical;min-height:110px}
  .sms-compose .btnrow{margin-top:8px;align-items:center}
  .sms-preview{margin-top:12px;display:flex;flex-direction:column;gap:5px}
  .sms-bubble{background:var(--panel2);border:1px solid var(--line);border-radius:14px;padding:9px 13px;font-size:13.5px;
    color:var(--tx);white-space:pre-wrap;overflow-wrap:anywhere;max-width:min(520px,100%)}
  .sms-bubble.out{border-color:rgba(88,166,255,.45);background:rgba(88,166,255,.10)}
  .sms-bubble.in{border-color:rgba(63,185,80,.35);background:rgba(63,185,80,.08)}
  .subtabs{display:flex;gap:6px;margin:4px 0 12px}
  .subtabs .on{background:var(--info);border-color:var(--info);color:#fff}
  .sms-line{display:grid;grid-template-columns:minmax(140px,200px) minmax(0,1fr) auto;gap:10px;align-items:start;
    padding:9px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .sms-line.in .sms-bubble{justify-self:start}
  .sms-line.out .sms-bubble{justify-self:start}
  .sms-line.bad .sms-bubble{border-color:rgba(248,81,73,.5);background:rgba(248,81,73,.08)}
  /* amber, not red: the gateway did not answer, which is a question left open
     rather than a message that failed */
  .sms-line.unsure .sms-bubble{border-color:rgba(210,153,34,.5);background:rgba(210,153,34,.07)}
  .sms-who{display:flex;flex-direction:column;gap:2px;min-width:0}
  .sms-name{font-weight:600;color:var(--tx);overflow-wrap:anywhere}
  .sms-when{color:var(--tx-mut);font-size:11.5px}
  .sms-tail{display:flex;align-items:center;gap:6px;white-space:nowrap}
  .findbox{width:min(560px,94vw);background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:14px;
    box-shadow:0 24px 60px rgba(0,0,0,.6);margin-top:8vh;align-self:flex-start}
  #findinput{width:100%;box-sizing:border-box;font:inherit;font-size:16px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:12px;padding:11px 14px;outline:none}
  #findinput:focus{border-color:var(--info);box-shadow:0 0 0 3px rgba(88,166,255,.18)}
  .findlist{max-height:46vh;overflow:auto;margin-top:8px;display:flex;flex-direction:column;gap:2px}
  .finditem{display:flex;align-items:baseline;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;font-size:13.5px}
  .finditem .what{color:var(--tx-mut);font-size:11.5px;margin-left:auto;text-transform:uppercase;letter-spacing:.06em}
  .finditem:hover,.finditem.on{background:rgba(88,166,255,.14)}
  .card.found{outline:2px solid var(--info);outline-offset:2px;transition:outline-color .4s}
  .findhint{color:var(--tx-mut);font-size:11.5px;margin:8px 2px 0}
  .energy-reset-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:6px;padding:4px 0 2px}
  .energy-reset-row .btn{justify-content:flex-start;width:100%}
  .money-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px 22px;align-items:end}
  .money-big{font-size:26px;font-weight:650;color:var(--tx);font-variant-numeric:tabular-nums}
  .money-sub{font-size:12px;color:var(--tx-mut);margin-top:2px}
  .money-lbl{font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--tx-mut)}
  .money-top{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:8px 16px;font-size:12.5px;color:var(--tx-dim);border-top:1px solid var(--line);padding-top:10px}
  .room-name{font-weight:600;color:var(--tx)}
  .ntfy-when{color:var(--tx-mut);font-size:11.5px;margin-left:auto}
  /* every pack keeps the room for a drag handle whether it has one or not, so
     a gateway from config.json, which cannot be dragged, sits in the same
     column as one made here that can - and the header can then line up with
     all of them rather than with whichever happens to come first */
  .gw-pack{display:block;padding-left:16px}
  #messages-list textarea,.msg-card textarea{min-height:170px;max-height:420px;line-height:1.45;font-size:14px}
  .msg-card input,.tap-row input{font-size:14px;padding:9px 12px}
  .msg-tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px}
  .msg-tools .btn{white-space:nowrap}
  .msg-preview .sms-bubble{margin-top:4px}
  .acl-row{display:flex;align-items:baseline;gap:9px;padding:5px 0;border-bottom:1px solid rgba(38,44,55,.5);font-size:13px;flex-wrap:wrap}
  .acl-row .mark{width:14px} .acl-row .who{color:var(--tx-dim)} .acl-row .top{font-family:ui-monospace,Menlo,monospace;color:var(--tx)}
  .acl-row .why{color:var(--tx-mut);font-size:12px;margin-left:auto}
  .acl-row.bad .top{color:var(--warn)}
  .acl-row.quiet{opacity:.72}
  /* A row lights up under the pointer, the way a device card does: the same
     outline, so the eye is told the same thing in the same way wherever it
     looks. */
  .bind-row:not(.bind-head):hover,.rule-pack:hover,.rule-row:hover,.scene-row:hover,.sched-row:hover,
  .sgroup-row:hover,.agroup-row:hover,.smscmd-row:hover,.ptrig-row:not(.head):hover,
  .person-row:not(.head):hover,.mdev:hover,.room-row:hover,.msg-card:hover,.gw-pack:hover,
  .seq-row:hover,.acl-row:hover,.dbb-row:hover,.wc-row:hover,.appr-row:hover{
    outline:1px solid rgba(88,166,255,.35);outline-offset:2px;border-radius:10px}
  /* the row, not each cell: an outline per cell is what made the highlight
     look chopped into four */
  .sms-whotable-row:not(.head):hover{outline:1px solid rgba(88,166,255,.35);outline-offset:-1px}
  /* a table row cannot take an outline offset outwards without the cells
     drifting, so it is drawn just inside the row */
  .bindrow:hover{outline:1px solid rgba(88,166,255,.35);outline-offset:-1px}
  .gw-pack{border-radius:10px}
  .gw-pack:hover{outline-offset:3px}
  .gw-pack .gw-row:hover{outline:0}       /* the pack is outlined, not the row inside it */
  #whatif-row{gap:8px;flex-wrap:wrap;align-items:center}
  #whatif-row select,#whatif-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:9px;padding:7px 10px;min-width:0}
  #whatif-out{margin-top:10px}
  .acl-fix{background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin-top:10px;
    font-family:ui-monospace,Menlo,monospace;font-size:12.5px;color:var(--tx);white-space:pre;overflow:auto}
  .lat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px 18px}
  .lat-head{margin:12px 0 4px;font-size:11px;letter-spacing:.07em;text-transform:uppercase;color:var(--tx-mut)}
  .lat-row{display:flex;justify-content:space-between;align-items:baseline;gap:10px;padding:5px 0;border-bottom:1px solid rgba(38,44,55,.5);font-size:13px}
  .lat-row .k{color:var(--tx-dim)} .lat-row .v{font-family:ui-monospace,Menlo,monospace;font-variant-numeric:tabular-nums;font-weight:600}
  .lat-row .v.ok{color:var(--ok)} .lat-row .v.warn{color:var(--warn)} .lat-row .v.crit{color:var(--crit)} .lat-row .v.dim{color:var(--tx-mut);font-weight:400}
  .rowgrab{position:absolute;left:1px;top:50%;transform:translateY(-50%);cursor:grab;color:var(--tx-mut);
    font-size:15px;line-height:1;opacity:.45;padding:2px 3px;user-select:none}
  .rowgrab:hover{opacity:1;color:var(--info)}
  .hasgrab{position:relative;padding-left:16px}
  .dragrow{opacity:.5;outline:1px dashed var(--info);border-radius:8px}
  .readpop{position:fixed;z-index:150;background:var(--panel);border:1px solid var(--line);border-radius:12px;
    box-shadow:0 12px 34px rgba(0,0,0,.55);padding:9px 11px;min-width:230px;max-width:340px;font-size:12.5px;pointer-events:none}
  .rp-head{display:flex;justify-content:space-between;gap:12px;margin-bottom:6px;padding-bottom:6px;border-bottom:1px solid var(--line)}
  .rp-name{font-weight:600;color:var(--tx)} .rp-when{color:var(--tx-mut);font-size:11.5px;white-space:nowrap}
  .rp-list{display:flex;flex-direction:column;gap:2px}
  .rp-row{display:flex;justify-content:space-between;gap:12px;padding:2px 6px;border-radius:6px;color:var(--tx-dim)}
  .rp-row.pick{background:rgba(88,166,255,.14);color:var(--tx)} .rp-row.pick .rp-v{color:var(--info);font-weight:650}
  .rp-k{white-space:normal;overflow-wrap:anywhere} .rp-v{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;white-space:nowrap}
  .rp-foot{margin-top:6px;padding-top:6px;border-top:1px solid var(--line);color:var(--tx-mut);font-size:11.5px}
  .qrpop{position:fixed;z-index:150;background:#fff;padding:8px 8px 4px;border-radius:12px;
    box-shadow:0 12px 34px rgba(0,0,0,.55);border:1px solid #2b3444;line-height:0}
  .qrpop .qrcap{font:500 10.5px system-ui,sans-serif;color:#555;text-align:center;line-height:1.6;letter-spacing:.04em}
  /* One line, whatever the value is. A long one - an otpauth:// URI is a
     hundred and thirty characters - used to break across four lines and
     become a block, which reads as a different kind of thing from the chip
     beside it. The whole of it is still what is copied, still what the QR
     code holds, and still what the tooltip says; only the drawing is cut. */
  .copyme{display:inline-block;cursor:pointer;background:rgba(88,166,255,.10);border:1px solid rgba(88,166,255,.25);
    border-radius:6px;padding:2px 7px;margin:2px 0;max-width:100%;vertical-align:bottom;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;color:var(--info)}
  .copyme:hover{background:rgba(88,166,255,.20)}
  .attn-item .why code{font-size:11.5px}
  .attn-sec{margin:14px 0 2px;font-size:10.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--tx-mut)}
  .attn-sec:first-child{margin-top:0}
  #pill,#m-attn-card,#m-online-card,#m-home-card,#m-devices-card{cursor:pointer}
  .askbox #askinput{width:100%;box-sizing:border-box;font:inherit;font-size:16px;text-align:center;background:var(--panel2);color:var(--tx);
    border:1px solid var(--line);border-radius:12px;padding:11px 14px;margin:4px 0 6px}
  .askbox #askinput:focus{outline:none;border-color:var(--info);box-shadow:0 0 0 3px rgba(88,166,255,.18)}
  .pinbox{width:min(380px,94vw);border-radius:20px;padding:28px 26px 22px;text-align:center;
    background:linear-gradient(160deg,#1b2230 0%,#141922 60%,#11151d 100%);
    border:1px solid #2b3444;
    box-shadow:0 24px 70px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.03) inset;
    animation:rise .2s cubic-bezier(.2,.9,.3,1)}
  @keyframes rise{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
  .pinicon{width:52px;height:52px;margin:0 auto 14px;border-radius:50%;
    display:flex;align-items:center;justify-content:center;color:var(--info);
    background:radial-gradient(circle at 50% 35%,rgba(88,166,255,.28),rgba(88,166,255,.07));
    border:1px solid rgba(88,166,255,.34)}
  .pinicon.danger{color:var(--crit);
    background:radial-gradient(circle at 50% 35%,rgba(248,81,73,.26),rgba(248,81,73,.07));
    border-color:rgba(248,81,73,.34)}
  .pinbox h3{margin:0 0 5px;font-size:18px;font-weight:650;letter-spacing:.2px}
  .pinwhat{margin:0 0 20px;color:var(--tx-dim);font-size:13.5px;line-height:1.45;word-break:break-word}
  .pinwhat b{color:var(--tx);font-weight:600}
  .pindigits{display:flex;gap:11px;justify-content:center;margin-bottom:6px}
  .pindigits[hidden]{display:none}
  .pindigits input{width:54px;height:64px;text-align:center;font-size:26px;font-weight:650;
    color:var(--tx);background:#0d1117;border:1.5px solid #2b3444;border-radius:13px;
    caret-color:var(--info);transition:border-color .14s,box-shadow .14s,transform .08s}
  .pindigits.wide input{width:min(260px,80vw);font-size:22px;letter-spacing:6px}
  .pindigits input:focus{outline:none;border-color:var(--info);box-shadow:0 0 0 3.5px rgba(88,166,255,.16)}
  .pindigits input.filled{border-color:#3d4a5f;background:#111823}
  .pindigits.bad input{border-color:var(--crit);box-shadow:0 0 0 3.5px rgba(248,81,73,.13)}
  .pindigits.bad{animation:shake .32s}
  @keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}
    40%{transform:translateX(7px)}60%{transform:translateX(-4px)}80%{transform:translateX(3px)}}
  .pinerr{min-height:19px;margin:8px 0 16px;font-size:13px;color:var(--crit)}
  .pinrow{display:flex;gap:10px;justify-content:center}
  .pinrow .btn{min-width:108px;justify-content:center}
  .btn.primary.danger{background:var(--crit-bg);border-color:rgba(248,81,73,.45);color:var(--crit)}
  .btn.primary.danger:hover:not(:disabled){background:rgba(248,81,73,.2);border-color:var(--crit)}
  .btn.primary:hover:not(:disabled){background:rgba(88,166,255,.2);border-color:var(--info)}
</style>
</head>
<body>
<div id="alertband" role="alert">
  <span class="bell"></span>
  <span class="texts" id="alertband-texts"></span>
  <span class="acts"><button class="btn cmd small danger" id="alertband-clear">Clear</button></span>
</div>
<div class="wrap">

<header>
  <h1>Sensors <span class="host">· <?= h($host) ?></span></h1>
  <span class="pill unknown" id="pill"><span class="dot"></span><span id="pill-text">Connecting…</span></span>
  <button class="lockpill locked" id="lockpill" type="button" title="Editing is locked. Click to unlock for a while.">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
    <span id="lockpill-text">Locked</span>
  </button>
  <button class="lockpill arrange" id="arrangepill" type="button" hidden
          title="Off: the cards stay put and their sliders and buttons work normally. On: a card can be dragged into another place.">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 9h14M5 15h14"/><path d="M9 5 12 2l3 3M9 19l3 3 3-3"/></svg>
    <span id="arrangepill-text">Rearrange off</span>
  </button>
  <span class="spacer"></span>
  <div class="updated" id="updated" title="Click to pause or resume refreshing">
    <b id="updated-label">Loading</b><br><span id="updated-time">—</span>
  </div>
</header>

<div class="tabs" role="tablist">
  <button role="tab" aria-selected="true"  data-tab="overview">Overview</button>
  <button role="tab" aria-selected="false" data-tab="plugs">Plugs</button>
  <button role="tab" aria-selected="false" data-tab="sensors">Sensors</button>
  <button role="tab" aria-selected="false" data-tab="buttons">Buttons</button>
  <button role="tab" aria-selected="false" data-tab="heating">Heating</button>
  <button role="tab" aria-selected="false" data-tab="history">History</button>
  <button role="tab" aria-selected="false" data-tab="devices">Devices</button>
  <button role="tab" aria-selected="false" data-tab="sms">SMS</button>
  <button role="tab" aria-selected="false" data-tab="wifi">WiFi</button>
  <button role="tab" aria-selected="false" data-tab="events">Events</button>
  <button role="tab" aria-selected="false" data-tab="approvals">Public API</button>
  <button role="tab" aria-selected="false" data-tab="control">Control</button>
  <button role="tab" aria-selected="false" data-tab="all">All values</button>
</div>

<section class="panel" id="tab-plugs" hidden>
  <div class="sockets" id="sockets" hidden></div>
  <p class="muted small" id="plugs-empty" hidden>No plugs configured yet. Add one under Control → Plugs and sensors.</p>
</section>

<section class="panel" id="tab-sensors" hidden>
  <div class="grid devices" id="sensor-cards" style="margin-bottom:14px"></div>
  <p class="muted small" id="sensors-empty" hidden>No sensors yet.</p>
</section>

<section class="panel" id="tab-buttons" hidden>
  <div class="grid devices" id="button-cards" style="margin-bottom:14px"></div>
  <p class="muted small" id="buttons-empty" hidden>No buttons yet.</p>
</section>

<section class="panel" id="tab-overview">
  <div class="grid top" style="margin-bottom:14px">
    <div class="card metric" id="m-devices-card"><div class="label">Devices</div><div class="value" id="m-devices">–</div><div class="sub" id="m-devices-sub">&nbsp;</div></div>
    <div class="card metric" id="m-online-card"><div class="label">Online</div><div class="value" id="m-online">–</div><div class="sub" id="m-online-sub">&nbsp;</div></div>
    <div class="card metric" id="m-attn-card"><div class="label">Needs attention</div><div class="value" id="m-attn">–</div><div class="sub" id="m-attn-sub">&nbsp;</div></div>
    <div class="card metric" id="m-bridge-card"><div class="label">Zigbee2MQTT</div><div class="value" id="m-bridge">–</div><div class="sub" id="m-bridge-sub">&nbsp;</div></div>
    <div class="card metric" id="m-join-card"><div class="label">Permit join</div><div class="value" id="m-join">–</div><div class="sub" id="m-join-sub">&nbsp;</div></div>
    <div class="card metric" id="m-home-card" hidden><div class="label">At home</div><div class="value" id="m-home">–</div><div class="who-row" id="m-home-who"></div><div class="sub" id="m-home-sub">&nbsp;</div></div>
  </div>
  <div class="btnrow" id="ov-add-row" hidden style="margin-bottom:10px;flex-wrap:wrap">
    <select id="ov-add-select"></select>
    <button class="btn cmd" id="ov-add-btn">Add to Overview</button>
    <span class="muted small">Drag any card to reorder; × removes it. This only changes Overview — the Plugs/Sensors/Buttons tabs still show everything.</span>
  </div>
  <div class="grid devices" id="overview-custom" style="margin-bottom:14px"></div>
  <p class="muted small" id="overview-custom-empty" hidden>Overview is empty. Unlock editing and add something above.</p>
  <div class="card full" id="power-card" hidden style="margin-bottom:14px">
    <h2>What it is drawing <span class="right small muted" id="power-range"></span></h2>
    <div id="power-body" class="money-grid"></div>
    <div id="power-chart-wrap" hidden style="margin-top:12px">
      <div class="chart" id="power-chart"></div>
      <div class="legend" id="power-chart-legend"></div>
    </div>
  </div>
  <div class="card full" id="money-card" hidden style="margin-bottom:14px">
    <h2>What it costs <span class="right small muted" id="money-range"></span></h2>
    <div id="money-body" class="money-grid"></div>
    <div id="money-chart-wrap" hidden style="margin-top:12px">
      <div class="chart" id="money-chart"></div>
      <div class="legend" id="money-chart-legend"></div>
    </div>
  </div>
  <div class="card full" id="energy-card" hidden style="margin-bottom:14px">
    <h2>Energy</h2>
    <div id="energy-table"></div>
  </div>
  <div class="grid charts">
    <div class="card">
      <h2>Temperature <span class="right" id="ov-temp-range">24h</span></h2>
      <div class="chart" id="ov-temp"></div><div class="legend" id="ov-temp-legend"></div>
    </div>
    <div class="card">
      <h2>Humidity <span class="right" id="ov-hum-range">24h</span></h2>
      <div class="chart" id="ov-hum"></div><div class="legend" id="ov-hum-legend"></div>
    </div>
  </div>
  <div class="row" style="margin-top:12px" id="ov-ranges"></div>
</section>

<section class="panel" id="tab-history" hidden>
  <div class="row" style="margin-bottom:14px">
    <select id="h-device"></select>
    <span id="h-ranges" class="row"></span>
    <span class="spacer"></span>
    <span class="muted small" id="h-note"></span>
  </div>
  <div class="grid charts" id="h-charts"></div>
</section>

<section class="panel" id="tab-devices" hidden>
  <div class="card scroll"><table id="devices-table"><thead><tr>
    <th>Name</th><th>Model</th><th>Source</th><th>Address</th><th>Status</th><th>Battery</th><th>Signal</th><th>Last report</th><th>First seen</th>
  </tr></thead><tbody></tbody></table></div>
  <div class="card full" id="mesh-card" hidden style="margin-top:14px">
    <h2>Who talks through whom</h2>
    <p class="note">From the Zigbee network map — each parent with the children it carries and the link quality of that hop.</p>
    <div id="mesh-tree"></div>
  </div>
</section>

<section class="panel" id="tab-heating" hidden>
  <div class="card full">
    <h2>Heating</h2>
    <p class="note">A room holds a temperature; the valves in it are told to. <b>Comfort</b>, <b>Eco</b> and <b>Night</b> are the three
      temperatures, and the plan says which one applies when — or pick one by hand and the plan waits. <b>Away</b> drops every room
      to one temperature until it is switched off again, and an open window in a room drops that room to 5&nbsp;°C while it is open.
      A valve is a sleeping device: it takes what it was told when it next talks to the mesh, seconds to a few minutes later.
      Rooms are made under Control → Automation.</p>
    <div class="heat-bar">
      <div class="set-item"><label for="heat-enabled-sw">Heating control</label><span id="heat-enabled-sw" class="heat-sw"></span></div>
      <div class="set-item"><label for="heat-away-sw">Away</label><span id="heat-away-sw" class="heat-sw"></span></div>
      <div class="set-item"><label for="heat-away-c">Away temperature</label><input id="heat-away-c" type="number" min="5" max="30" step="0.5"></div>
      <div class="set-item"><label for="heat-away-from">Away from</label><input id="heat-away-from" type="date" title="Away turns itself on for these days and off again afterwards — a weekend away, set once"></div>
      <div class="set-item"><label for="heat-away-to">Away until</label><input id="heat-away-to" type="date" title="The last day away; the plan takes over again the day after"></div>
      <div class="set-item"><label>&nbsp;</label><div class="heat-actions"><button class="btn cmd" id="heat-save">Save heating</button><span class="muted small" id="heat-note"></span></div></div>
    </div>
  </div>
  <div id="heating-rooms" class="grid" style="margin-top:14px"></div>
  <p class="muted small" id="heating-empty" hidden>No rooms yet — make one under Control → Automation, put a valve and a thermometer in it, and it appears here.</p>
</section>
<section class="panel" id="tab-sms" hidden>
  <div class="card full">
    <h2>Write a message</h2>
    <p class="note">Pick who it goes to — anybody with a number on their card, or type one — and write it.
      <b>Ctrl+Space</b> offers the same <code>{…}</code> facts an alert can quote, and the preview underneath
      shows what will actually arrive.</p>
    <div id="sms-people" class="sms-people"></div>
    <div class="sms-compose">
      <textarea id="sms-text" rows="5" placeholder="Inside {inside_c} °C, heating {heating_on}…"></textarea>
      <div class="btnrow">
        <button class="btn small" id="sms-emoji" type="button">😀 Emoji</button>
        <button class="btn small" id="sms-facts" type="button">{ } Facts</button>
        <span class="muted small" id="sms-count"></span>
        <span class="spacer"></span>
        <button class="btn cmd primary" id="sms-write-send">Send</button>
      </div>
      <div class="sms-preview">
        <div class="muted small">On the phone it will read</div>
        <div id="sms-preview-body" class="sms-bubble out"></div>
      </div>
    </div>
  </div>
  <div class="card full">
    <div class="head">
      <h2>Messages</h2>
      <span class="spacer"></span>
      <div class="btnrow" id="sms-log-tools"></div>
    </div>
    <div class="subtabs" id="sms-subtabs">
      <button class="btn small" type="button" data-box="in" id="sms-tab-in">Inbox</button>
      <button class="btn small" type="button" data-box="out" id="sms-tab-out">Outbox</button>
      <button class="btn small on" type="button" data-box="all" id="sms-tab-all">Everything</button>
    </div>
    <div id="sms-log"></div>
  </div>
</section>
<section class="panel" id="tab-wifi" hidden>
  <div class="btnrow" style="margin-bottom:12px;flex-wrap:wrap">
    <button class="btn cmd" id="wifi-refresh">Ask the controller</button>
    <span class="muted small" id="wifi-tab-note"></span>
  </div>
  <div id="wifi-tiles"></div>
  <div class="card full" id="wifi-clients-card" style="margin-top:14px">
    <h2>On the network</h2>
    <p class="note">Everything the controller can see right now. Wireless first, then anything on a cable. A device assigned to somebody under Control → Presence is marked in green.</p>
    <p class="note" id="wifi-api-note"></p>
    <div id="wifi-client-table"></div>
  </div>
  <div class="card full" id="wifi-others-card" style="margin-top:14px" hidden>
    <h2>Other networks on the air <span class="right"><button class="btn small" id="wifi-seen-btn">Everything ever heard</button></span></h2>
    <p class="note">What the access points can hear besides your own, strongest first. A network on the same channel as one of yours is sharing the airtime with it — which is what the <b>quieter going spare</b> hint on an access point tile is about. Your own networks are left out; the hidden ones your points broadcast are marked.</p>
    <div id="wifi-others"></div>
    <div id="wifi-seen-wrap" hidden style="margin-top:14px">
      <p class="note" id="wifi-seen-note"></p>
      <div id="wifi-seen"></div>
    </div>
  </div>
</section>

<section class="panel" id="tab-events" hidden>
  <div class="card scroll">
    <h2>Events</h2>
    <table id="events-table"><thead><tr><th>When</th><th></th><th>Kind</th><th>Device</th><th>Detail</th></tr></thead><tbody></tbody></table>
    <div class="center" id="events-empty" hidden>Nothing recorded yet</div>
  </div>
</section>

<section class="panel" id="tab-approvals" hidden>
  <div class="card full">
    <h2>Waiting to be approved</h2>
    <p class="note">A press on a link that asks Duo does not act on its own: it asks, and waits for
      somebody to say yes. What is waiting is here, with what it would do and how long it has left.
      Calling one off is not undoing it — nothing has happened yet; it is telling the press that
      nobody is going to answer, so an approval arriving afterwards does nothing.</p>
    <div id="approvals-live"></div>
    <div class="btnrow" style="margin-top:12px">
      <button class="btn cmd danger" id="approvals-stop-all">Call them all off</button>
      <span class="muted small" id="approvals-note" style="align-self:center"></span>
    </div>
  </div>
  <div class="card full scroll" style="margin-top:14px">
    <h2>Every press, and what came of it</h2>
    <p class="note">Every one of them, whichever road it came by and whatever it had to get past: a
      press approved through Duo, one that carried a six-digit code, one that carried neither because
      none is asked for, and one that was refused. Kept in the database, so it is still here after a
      restart; erased from Control → System → <i>Recorded data</i>.</p>
    <div class="btnrow" id="presses-filter" style="flex-wrap:wrap;margin-bottom:12px;gap:8px"></div>
    <table id="approvals-past"><thead><tr><th>When</th><th></th><th>Link</th><th>What</th>
      <th>Road</th><th>Checked by</th><th>Asked from</th><th>How it ended</th></tr></thead><tbody></tbody></table>
    <div class="center" id="approvals-empty" hidden>No link has been pressed yet</div>
    <div class="pager" id="presses-pager"></div>
  </div>
  <div class="card full" style="margin-top:14px" id="blocked-card">
    <h2>Addresses that may not talk to this</h2>
    <p class="note">An address that behaves like somebody trying things rather than like somebody
      opening a door is put on this list, and everything the API answers it with is a refusal. What
      counts as trying things is weighed rather than counted: a wrong secret weighs more than a road
      that is shut, and trying five different links weighs more than trying one five times. The house's
      own addresses are left alone unless you say otherwise, so nobody shuts the family out. How long
      a block lasts, and what earns one, are in Settings.</p>
    <div id="blocked-watch"></div>
    <div id="blocked-list"></div>
    <div id="blocked-past" style="margin-top:12px"></div>
    <div class="btnrow" style="margin-top:10px">
      <input id="blocked-ip" type="text" autocomplete="off"
             placeholder="89.24.5.7, 89.24.5.0/24 or 2a01:430::/48">
      <button class="btn cmd" id="blocked-add">Block this one</button>
      <button class="btn cmd" id="blocked-add-forever">Block it for good</button>
      <button class="btn cmd danger" id="blocked-clear">Take them all off</button>
      <button class="btn cmd" id="blocked-forget-counters">Forget what they have been doing</button>
      <span class="muted small" id="blocked-note" style="align-self:center"></span>
    </div>
  </div>
</section>

<section class="panel" id="tab-control" hidden>
  <div class="card full" id="lock-card" style="margin-bottom:14px">
    <h2>Editing</h2>
    <p class="note" id="lock-note">Everything on this tab that changes something is locked. Unlock with the PIN for a chosen time; while unlocked nothing here asks for it again. It locks itself when the time is up, or when you lock it. The socket buttons on the Overview follow it too: unlocked they switch at once, locked they ask for the PIN per click without unlocking anything.</p>
    <div class="btnrow">
      <button class="btn cmd primary" id="lock-toggle">Unlock editing</button>
      <span class="muted small" id="lock-state" style="align-self:center"></span>
    </div>
  </div>
  <nav class="subtabs" id="control-nav">
    <button type="button" data-sec="devices">Devices</button>
    <button type="button" data-sec="automation">Automation</button>
    <button type="button" data-sec="presence">Presence</button>
    <button type="button" data-sec="alerts">Alerts &amp; energy</button>
    <button type="button" data-sec="system">System</button>
  </nav>
  <div class="grid charts">
    <div class="card" data-sec="devices">
      <h2>Pairing</h2>
      <p class="note">Opening the network lets new Zigbee devices join for four minutes. On a Shelly BLU device press the button five times quickly; on most other devices hold the button until the LED blinks.</p>
      <div class="btnrow">
        <button class="btn cmd primary" id="join-toggle">Open network (254 s)</button>
        <span class="muted small" id="join-state" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="system">
      <h2>Recorded data</h2>
      <p class="note">Erasing cannot be undone. Devices stay known to Zigbee2MQTT; only what this dashboard recorded is removed.</p>
      <div class="btnrow">
        <button class="btn cmd danger" data-reset="history">Erase history</button>
        <button class="btn cmd danger" data-reset="events">Erase events</button>
        <button class="btn cmd danger" data-reset="all">Erase everything</button>
        <button class="btn cmd danger" id="approvals-forget-btn">Erase the press log</button>
        <button class="btn cmd danger" id="blocked-forget">Erase the blocked history</button>
        <button class="btn cmd danger" id="wifi-forget-btn">Forget the networks on the air</button>
      </div>
      <div class="btnrow" style="margin-top:10px">
        <select id="reset-device"></select>
        <button class="btn cmd danger" id="reset-device-btn">Forget this device</button>
      </div>
      <p class="note" style="margin-top:12px">A removed device can also come back on its own: the broker keeps its last message and hands it over again on every reconnect. <b>Look for leftovers</b> reports those topics as well, and offers to clear them — which needs the daemon's MQTT user to be allowed to write to them. A device that was renamed or removed leaves its recordings behind under the old name. <b>Look for leftovers</b> counts what is still held for devices this dashboard no longer shows, and lists them above so a single one can be picked out; removing them all is one more click and cannot be undone.</p>
      <div class="btnrow">
        <button class="btn cmd" id="stale-scan">Look for leftovers</button>
        <button class="btn cmd danger" id="stale-drop" hidden>Erase every leftover</button>
        <button class="btn cmd" id="ghost-clear" hidden>Clear what the broker keeps replaying</button>
      </div>
      <div id="rec-run" hidden>
        <div class="runbar"><i></i></div>
        <div class="runhead"><span id="rec-run-what"></span><span id="rec-run-time" class="muted small"></span></div>
        <pre id="rec-run-log" class="runlog"></pre>
      </div>
    </div>
    <div class="card full" data-sec="devices" id="managed-card">
      <h2>Plugs and sensors</h2>
      <p class="note">Shelly devices the daemon reads over local RPC: a <b>plug</b> is switched and metered, a <b>sensor</b> is only read (an H&T on USB power; on battery it sleeps and is better served by the webhook). One block per device: address, password and the <b>device state</b> once; <b>Detect</b> asks the box what it is and lays out one <b>channel</b> row per relay (a Pro 4PM gets four) with the names it uses itself. The device state wins — <b>monitor only</b> or <b>disabled</b> there applies to every channel and locks their selects; <b>enabled</b> lets each channel choose for itself. Entries from <code>config.json</code> are shown but edited there. Passwords live in the daemon's database only; leave the field blank to keep the one already set. A disabled channel is not polled and leaves the lists, but its history, bindings and rules stay.</p>
      <div id="managed-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="managed-add-plug">Add plug</button>
        <button class="btn cmd" id="managed-add-sensor">Add sensor</button>
        <button class="btn cmd" id="managed-discover">Find Shelly devices</button>
        <button class="btn cmd primary" id="managed-save">Save devices</button>
        <span class="muted small" id="managed-note" style="align-self:center"></span>
      </div>
      <div id="managed-found" class="muted small" style="margin-top:10px"></div>
    </div>
    <div class="card full" data-sec="devices" id="gateways-card">
      <h2>Zigbee gateways</h2>
      <p class="note">A gateway read over its own network API for its own health, on top of what Zigbee2MQTT already reports — either a <b>SMLIGHT SLZB-06</b>-style box (plain HTTP, <code>username</code>/<code>password</code> if its "web server authentication" is on) or a <b>Shelly</b> device with the Zigbee component acting as a router (e.g. a Power Strip 4 Gen4 — the same local JSON-RPC API and <code>password</code> as a plug). <b>Detect</b> tries both and remembers which one answered. <b>Target</b> is either the exact name an existing router already has on this dashboard (its readings <em>extend</em> that device, nothing is duplicated) or <code>coordinator</code> for the local coordinator, which gets a small device of its own. Entries from <code>config.json</code> are shown but edited there; passwords are stored in the daemon's database, readable by the daemon alone.</p>
      <div id="gateways-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="gateway-add">Add gateway</button>
        <button class="btn cmd primary" id="gateway-save">Save gateways</button>
        <span class="muted small" id="gateway-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="devices" id="binding-card" hidden>
      <h2>What each Zigbee device was told to report</h2>
      <p class="note">A sensor is configured once, when it joins: the <b>bindings</b> say which clusters report to the
        coordinator, the <b>reporting</b> says how often, and both live in the sensor’s own memory. A rejoin, a firmware
        update or a Zigbee2MQTT that was killed rather than stopped can leave that gone — and nothing says so. The device
        stays in the list and simply never speaks again.
        There is no way to ask what a device <i>ought</i> to have without repeating the converter library’s work, so this
        compares each with the others of its own model: six of seven with three bindings and a seventh with none is the
        seventh. A Tuya that sends its readings unasked and an alarm contact that enrols instead are left alone.</p>
      <div id="binding-list"></div>
      <div id="binding-trouble" style="margin-top:12px"></div>
      <div id="binding-remembered" class="muted small" style="margin-top:10px"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="binding-remember">Everything here is right — remember it</button>
        <span class="muted small" style="align-self:center">for when these devices are replaced and there is
          nothing left to compare a new one with. It is your word, not evidence, so it is refused where the
          devices of a model disagree or where none of them has anything configured.</span>
      </div>
    </div>
    <div class="card full" data-sec="devices" id="plug-control" hidden>
      <h2>Smart plugs</h2>
      <p class="note">Switching a socket cuts power to whatever is plugged into it. The counters are the plug's own running totals; resetting one starts it from zero, the history recorded here is untouched.</p>
      <div id="plug-control-list"></div>
    </div>
    <div class="card full" data-sec="presence" id="wifi-card">
      <h2>Wi-Fi presence</h2>
      <p class="note">Whether a phone is on the house Wi-Fi is a good enough answer to <i>is anyone in</i>, and it needs nothing installed on the phone. Point this at a UniFi controller, then say which device belongs to whom. Arriving is believed at once; leaving only after the grace period, because a phone that sleeps its radio drops off the controller while its owner is asleep in the next room.</p>
      <div class="set-grid">
        <div class="set-head">Controller</div>
        <div class="set-item"><label for="wifi-host">Address</label><input id="wifi-host" type="text" placeholder="wlc.example.net"></div>
        <div class="set-item"><label for="wifi-port">Port</label><input id="wifi-port" type="number" placeholder="443"></div>
        <div class="set-item"><label for="wifi-method">Access</label><select id="wifi-method"><option value="official">API key</option><option value="legacy">Username and password</option><option value="both">Both — sign in, key as fallback</option><!-- signing in is skipped while the points are read over SSH --></select></div>
        <div class="set-item" id="wifi-key-wrap"><label for="wifi-key">API key</label><input id="wifi-key" type="password" placeholder="(kept)"></div>
        <div class="set-item" id="wifi-user-wrap"><label for="wifi-user">Username</label><input id="wifi-user" type="text" autocomplete="off"></div>
        <div class="set-item" id="wifi-pass-wrap"><label for="wifi-pass">Password</label><input id="wifi-pass" type="password" placeholder="(kept)"></div>
        <div class="set-item"><label for="wifi-site">Site</label><input id="wifi-site" type="text" placeholder="default"></div>
        <div class="set-head">Timing</div>
        <div class="set-item"><label for="wifi-poll">Ask every (seconds)</label><input id="wifi-poll" type="number" min="3" max="900"></div>
        <div class="set-item"><label for="wifi-grace">Gone after (seconds)</label><input id="wifi-grace" type="number" min="0" max="86400"></div>
        <div class="set-item"><label for="wifi-ntfy" title="Optional. A phone can publish its arrivals and departures to this ntfy topic instead of calling the dashboard, so nothing here has to be reachable from the internet.">Presence topic (optional)</label><input id="wifi-ntfy" type="text" placeholder="https://ntfy.sh/a-long-random-name" autocomplete="off"></div>
        <div class="set-head">Ask the access points themselves</div>
        <div class="set-item set-bool set-wide"><label for="ssh-enabled" title="The controller's key interface will not say which network a client is on, nor its signal. The points know both. Nothing is ever written to them: the commands are a fixed list — info and mca-dump — and neither changes anything.">Read them over SSH</label><span id="ssh-enabled-sw"></span></div>
        <div class="set-sub">
        <div class="set-item"><label for="ssh-auth">How to get in</label><select id="ssh-auth"><option value="key">A private key</option><option value="password">A password</option></select></div>
        <div class="set-item"><label for="ssh-port">SSH port</label><input id="ssh-port" type="number" placeholder="22"></div>
        <div class="set-item"><label for="ssh-user">Their username</label><input id="ssh-user" type="text" autocomplete="off" placeholder="admin"></div>
        <div class="set-item" id="ssh-pass-wrap"><label for="ssh-pass">Their password</label><input id="ssh-pass" type="password" placeholder="(kept)"></div>
        </div>
        <div class="set-head">Switches</div>
        <div class="set-item set-bool"><label for="wifi-enabled" title="Off, and nothing is asked and nobody counts as home. The connection and the people stay saved.">Watch the network</label><span id="wifi-enabled-sw"></span></div>
        <div class="set-item set-bool"><label for="wifi-verify" title="A controller with its own self-signed certificate will fail this. Leave it off for one on your own network.">Check the TLS certificate</label><span id="wifi-verify-sw"></span></div>
      </div>
      <div id="ssh-key-box" class="subpanel" hidden>
        <p class="note">The key is made here and never leaves except when you download it. Put the <b>public</b> half into the controller under Settings → System → Device SSH Authentication, and the points will accept it. Keep the private half safe: anyone holding it can log in to them.</p>
        <div class="btnrow">
          <button class="btn cmd" id="ssh-generate">Make a key</button>
          <button class="btn cmd" id="ssh-upload">Use my own</button>
          <button class="btn cmd" id="ssh-download">Download it</button>
          <button class="btn cmd danger" id="ssh-forget">Forget it</button>
          <span class="spacer"></span>
          <button class="btn cmd primary" id="ssh-test">Try the access points</button>
        </div>
        <pre id="ssh-public" class="runlog" hidden></pre>
      </div>
      <div class="btnrow" style="margin-top:14px">
        <button class="btn cmd" id="wifi-test">Test</button>
        <button class="btn cmd primary" id="wifi-save">Save connection</button>
        <span class="muted small" id="wifi-state"></span>
      </div>
    </div>
    <div class="card full" data-sec="presence" id="people-card">
      <h2>People</h2>
      <p class="note">A person is in when any of their devices is on the network. Give someone a second device — a watch, a laptop — and a sleeping phone stops mattering. <b>Load clients</b> lists what the controller can see right now; pick a device and it is assigned to the person selected next to it. <b>+ by name</b> matches a device by the name the controller shows instead of its address &mdash; use it for a phone with a <em>private / rotating Wi-Fi address</em> (iPhone: Settings &rarr; Wi-Fi &rarr; your network &rarr; Private Wi-Fi Address), which otherwise turns into a new, unknown address and its owner counts as out. An <b>out</b> tag says under it why.</p>
      <p class="note"><b>Gone after</b> is how long this person may be off the network before they count as out — blank follows the shared setting above, and a number here overrides it for someone whose phone drops off more readily. <b>Notify me</b> sends a message when that person arrives or leaves; off, it is still written to Events. Neither has anything to do with alerts from sensors — those are sensor rules with an <i>only when</i>.</p>
      <div class="btnrow">
        <button class="btn cmd" id="wifi-load">Load clients</button>
        <span class="muted small" id="wifi-clients-note"></span>
      </div>
      <div id="wifi-clients"></div>
      <div id="people-list"></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd" id="person-add">Add person</button>
        <button class="btn cmd primary" id="people-save">Save people</button>
        <span class="muted small" id="people-dirty"></span>
      </div>
    </div>
    <div class="card full" data-sec="presence" id="ptrig-card">
      <h2>When someone comes or goes</h2>
      <p class="note">Switch something the moment a person arrives or leaves. <b>anyone</b> fires for each person separately; <b>the house</b> fires once, when the first person gets in or the last one leaves — that is the one for turning everything off behind you. Sensor rules can be limited the same way, under <i>only when</i>.</p>
      <div id="ptrig-list"></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd" id="ptrig-add">Add</button>
        <button class="btn cmd primary" id="ptrig-save">Save</button>
        <span class="muted small" id="ptrig-dirty"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="bindings-card" hidden>
      <h2>Button bindings</h2>
      <p class="note">When a Zigbee button reports an action, the daemon switches the plug. <code>*</code> matches any action. One button and action may appear on several rows — every matching row fires, in parallel — and the plug column offers <b>all plugs</b> as one row. The icons say what a target is — 🔌 plug · ⚡ Zigbee switch (a wall switch channel, a bulb; driven through Zigbee2MQTT) · 🎬 scene · 🔁 sequence (next step) · ↺ sequence reset — and what an action does: ⏻ on · ⭘ off · ⇄ toggle · ⏱ pulse. <b>all plugs</b> never includes Zigbee switches. <b>pulse</b> flips the socket and flips it back after the delay: off → wait → on when it is on, on → wait → off when it is off. Saved behind the PIN; takes effect immediately.</p>
      <div id="bindings-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="binding-add">Add binding</button>
        <button class="btn cmd primary" id="binding-save">Save bindings</button>
        <span class="muted small" id="binding-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="smscmd-card">
      <h2>What a text message may do</h2>
      <p class="note">A word to listen for, and what it switches. “lights off”, “heating eco”, “home”. Only the numbers
        in <code>sms_allow</code> may give commands unless a line says otherwise, and the answer that goes back can use
        the same <code>{…}</code> facts a notification does — <code>{sms_from}</code> and <code>{sms_text}</code> as
        well. A line with no target and only an answer is a question: “status” replies and switches nothing.</p>
      <div class="smscmd-row smscmd-head">
        <span></span><span>Says</span><span>Switches</span><span>To</span>
        <span title="What follows the phrase becomes the value">Takes a value</span>
        <span title="Accepted from any number, not only the allowed ones">From anyone</span><span></span>
      </div>
      <div id="smscmd-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="smscmd-add">Add command</button>
        <button class="btn cmd primary" id="smscmd-save">Save commands</button>
        <span class="muted small" id="smscmd-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="scripts-card">
      <h2>Little scripts</h2>
      <p class="note">A rule does one thing. When the thing wanted is three things — keep that
        address out, say so, and turn the porch light on — write them here as lines, give them a
        name, and pick that name as the action of a command or a link. Every line is a plain verb and
        something to act on, and the names the rule caught are filled in before anything runs:
        <code>ban {ip} 120</code>. Ctrl+Space in the box lists the verbs and every fact.</p>
      <p class="note">A name in a script — <code>{ip}</code> — is filled in by whatever runs
        it: give the command or the link a variable of that name, and what it catches is what the
        script gets. <i>Try it</i> asks for them by hand, since there is no rule to catch anything
        then.</p>
      <div id="scripts-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="script-add">Add a script</button>
        <button class="btn cmd primary" id="script-save">Save scripts</button>
        <span class="muted small" id="script-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="agroups-card">
      <h2>Action groups</h2>
      <p class="note">Several things switched under one name — “the lights downstairs”, “everything in the workshop”.
        A group is a <em>target</em>, so one button can switch it on and another off, and a rule or a schedule can use it
        as well; a scene, by contrast, is a fixed list of actions. Groups cannot contain groups.</p>
      <div id="agroups-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="agroup-add">Add group</button>
        <button class="btn cmd primary" id="agroup-save">Save groups</button>
        <span class="muted small" id="agroup-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="sgroups-card">
      <h2>Sensor groups</h2>
      <p class="note">Several sensors read as one. “Any PIR downstairs”, “how many windows are open”, “the coldest room” —
        pick the sensors, the reading to watch and how to put them together, and the group becomes a source like any other:
        a rule can watch it, a chart can draw it, an alert can quote it. It remembers which member last moved it, so a
        message can say <code>{trigger}</code> and <code>{trigger_value}</code> as well as <code>{value}</code>.</p>
      <div id="sgroups-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="sgroup-add">Add group</button>
        <button class="btn cmd primary" id="sgroup-save">Save groups</button>
        <span class="muted small" id="sgroup-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="rules-card" hidden>
      <h2>Sensor rules</h2>
      <p class="note">When a reading crosses the line, the daemon drives the plug — any device with numbers works as the source: a thermometer, a plug's own power, Wi-Fi signal. A rule fires when its condition <b>becomes</b> true, not on every report while it stays true, and then not again until the cooldown has passed. Pair the switch-on rule with a switch-off one the other way (e.g. <code>≥ 30 → on</code> and <code>≤ 27 → off</code>) to get a thermostat with a dead band. Each rule can be limited to a <b>clock window</b> (22:00–06:00 crosses midnight) and can put the plug into a safe state when the window closes — a motion-driven light goes off in the morning even if nobody walked past at the boundary. <b>=</b> and <b>≠</b> are there for readings that are a state rather than a level — a contact, a mode, a set point. Yes/no readings (occupancy, contact) count as 1 and 0, so <code>occupancy ≥ 1 → on</code> with the sensor's own clear-timeout makes a motion light — aimed at a plug or at a ⚡ <b>Zigbee switch</b> alike. The second condition can be <b>AND</b> (both must hold) or <b>OR</b> (either is enough) — two PIRs covering one room: one rule <code>OR</code> ≥ 1 → on, a second <code>AND</code> ≤ 0 → off once <em>both</em> have gone quiet.</p>
      <div id="rules-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="rule-add">Add rule</button>
        <button class="btn cmd primary" id="rule-save">Save rules</button>
        <span class="muted small" id="rule-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="system" id="sessions-card" hidden>
      <h2>Editing sessions</h2>
      <p class="note">Who holds an unlock right now (from the audit log you can see who unlocked when). Lock all throws every browser back behind the PIN, including this one.</p>
      <div id="sessions-list" class="small muted" style="margin-bottom:10px"></div>
      <div class="btnrow"><button class="btn cmd danger" id="lock-all">Lock all sessions</button></div>
    </div>
    <div class="card full" data-sec="automation" id="scenes-card">
      <h2>Scenes</h2>
      <p class="note">A named bundle of actions fired together — "Evening" switches the lamp on, the chandelier off, the TV plug on. A step can wait ("after N s" from the start); steps without a wait fire at once, together. Run one from here, or point a button binding at it (the 🎬 entries in the plug column). A rule can start a scene too; the window-close safe state leaves scenes alone.</p>
      <div id="scenes-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="scene-add">Add scene</button>
        <button class="btn cmd primary" id="scene-save">Save scenes</button>
        <span class="muted small" id="scene-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="alerts" id="energy-reset-card">
      <h2>Energy summary</h2>
      <p class="note">The Overview's Energy card (today · month · year) is computed from recorded history. These buttons restart those sums <b>from zero, now</b> — the history itself and the plug's own meters are untouched (those have their reset above, under each plug). A restarted plug shows ↺ next to its name.</p>
      <div class="btnrow" id="energy-reset-buttons" style="flex-wrap:wrap"></div>
    </div>
    <div class="card full" data-sec="automation" id="rooms-card">
      <h2>Rooms</h2>
      <p class="note">A room is a name and the things in it. It groups the energy table, gives the <b>Heating</b> tab something to hold
        a temperature for, and says which thermometer and which window sensor belong with which valve. Anything not assigned simply
        stays out of the way.</p>
      <div id="rooms-list"></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd" id="room-add">Add room</button>
        <button class="btn cmd primary" id="rooms-save">Save rooms</button>
        <span class="muted small" id="rooms-note" style="align-self:center"></span>
      </div>
      <div id="rooms-assign" style="margin-top:14px"></div>
    </div>
    <div class="card full" data-sec="automation" id="sequences-card">
      <h2>Sequences</h2>
      <p class="note">A cycle driven by one trigger: the first press runs step 1, the next press — minutes or days later — step 2, and so on, then around again. Each step is a <b>scene</b> (several targets, at once or with delays) or any single target with an action — a plug, a light, a valve, a room’s heating. The position is remembered across restarts. Point a button binding at the 🔁 entry to advance it; a second trigger on the ↺ entry runs the optional <b>reset scene</b> (all off, say) and starts the cycle over.</p>
      <div id="sequences-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="sequence-add">Add sequence</button>
        <button class="btn cmd primary" id="sequence-save">Save sequences</button>
        <span class="muted small" id="sequence-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="automation" id="schedules-card">
      <h2>Schedules</h2>
      <p class="note">A calendar rule: "every Monday and Wednesday at 07:00, switch on" — independent of any sensor. Runs once per day per entry (a missed minute, e.g. after a restart, still catches up within the same day; never twice). Times accept <code>sunset</code>/<code>sunrise</code> with an offset, same as rule windows.</p>
      <div id="schedules-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="schedule-add">Add schedule</button>
        <button class="btn cmd primary" id="schedule-save">Save schedules</button>
        <span class="muted small" id="schedule-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="alerts" id="messages-card">
      <h2>Messages</h2>
      <p class="note">What a notification should actually say. Anything that switches something can send one instead — a rule, a button, a scene, a schedule, someone arriving — by choosing it in the target column. Without one, the notification carries the automatic description, which is fine for testing and poor at three in the morning.</p>
      <p class="note">The text may run over several lines. <b>Facts</b> puts in what was going on — <code>{device}</code>, <code>{value}</code>, <code>{time}</code> and the rest — filled in when it is sent; anything not known then is left out rather than printed. <code>{Name.key}</code> reaches for the <em>current</em> reading of any device on the dashboard (its name as shown, a dot, the key from All values): <code>Outside {Temp-Venek.temperature} °C, UPS {Plug-UPS.state}</code>. <b>Emoji</b> puts in a symbol, which both ntfy and Telegram carry. A picture is fetched by the phone from the address given, so it has to be reachable from wherever the phone is — a camera snapshot on your own network will not load from a train.</p>
      <div id="messages-list"></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd" id="message-add">Add message</button>
        <button class="btn cmd primary" id="messages-save">Save messages</button>
        <span class="muted small" id="messages-dirty"></span>
      </div>
    </div>
    <div class="card full" data-sec="alerts" id="notify-card">
      <h2>Notifications</h2>
      <p class="note" id="notify-note"></p>
      <p class="nsec">1 &nbsp;Which roads everything takes</p>
      <p class="note">Which way these go. A written message under <b>Messages</b> has three
        switches of its own; these are for the ones the daemon writes itself — a battery running down, a device gone
        quiet, a rule firing. A text is off unless you ask for it, since it costs money and wakes a phone at night.</p>
      <div class="btnrow" id="notify-roads" style="flex-wrap:wrap"></div>
      <p class="nsec">2 &nbsp;What is worth saying at all</p>
      <p class="note">Each of these has to say yes before anything is sent, whatever the roads above say.</p>
      <div class="btnrow" id="notify-opts" style="flex-wrap:wrap"></div>
      <p class="nsec">3 &nbsp;A different road for one kind of message</p>
      <p class="note">For the ones that are not about a device at all
        — a backup that failed and somebody coming home are not the same sort of news and need not travel together.
        Left alone, each follows the choice above.</p>
      <div class="notify-grid" id="notify-systems"></div>
      <p class="nsec">4 &nbsp;A different choice for one device</p>
      <p class="note">When the choices above are not enough — mute a chatty one, or hear everything about the freezer plug:</p>
      <div class="notify-grid" id="notify-devices"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd primary" id="notify-save">Save</button>
        <button class="btn cmd" id="notify-test">Send a test message</button>
      </div>
    </div>
    <div class="card full" data-sec="system" id="backup-card">
      <h2>Backup</h2>
      <p class="note">A backup also runs by itself: daily at the time set under Settings (retention there too), into <code>/var/lib/zigmon/backups/</code> — the dashboard settings as JSON and, when enabled, <b>Zigbee2MQTT's coordinator backup</b> (the zip that lets a dead stick be replaced without re-pairing). One file with everything configured here: devices (passwords included — keep the file private), bindings, rules, scenes, layout, aliases, notification choices. Import replaces those wholesale; recorded history is not part of it. The Zigbee network itself lives in Zigbee2MQTT — back up <code>/opt/zigbee2mqtt/data</code> separately.</p>
      <div class="btnrow">
        <button class="btn cmd" id="backup-export">Download settings</button>
        <button class="btn cmd danger" id="backup-export-secrets">Download with secrets</button>
        <button class="btn cmd" id="backup-import">Import settings…</button>
        <button class="btn cmd" id="backup-now">Back up on the server now</button>
        <input type="file" id="backup-file" accept="application/json" hidden>
      </div>
    </div>
    <div class="card full" data-sec="system" id="settings-card">
      <h2>Settings</h2>
      <p class="note">The safe-to-change part of <code>config.json</code>. Saved values live in the daemon's database, apply <b>immediately</b> (no restart) and win over the file; a value put back to what the file says drops the override. Connection, ports, paths and the PIN stay file-only. A setting that differs from the file is marked with a blue edge down its left side.</p>
      <div id="settings-grid"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd primary" id="settings-save">Save settings</button>
        <span class="muted small" id="settings-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="system" id="battery-card">
      <h2>Batteries</h2>
      <p class="note">What each cell is at, how fast it is falling and roughly how long it has left, read from its own
        history rather than from the percentage alone. A cell that is dropping fast is worth changing before it stops
        a door sensor at three in the morning.</p>
      <div id="battery-list"></div>
    </div>
    <div class="card full" data-sec="automation" id="taps-card">
      <h2>One-tap links</h2>
      <p class="note">A watch or a phone cannot speak to this daemon, but it can open a web address, and that is
        enough. A link can <b>switch one thing</b>, or it can <b>tell you something and touch nothing</b> —
        how the house is, who is home, whether anything is wrong, what it is costing, what is open, the
        weather, or a sentence of your own written from the facts. On a watch, <i>Show Result</i> reads it
        out. Each link here does <b>one named thing and nothing else</b>, carries a secret of its own, can be
        withdrawn on its own, and is written down every time it is used — which is what makes it safe to keep on
        a wrist that may be lost: whoever finds it can switch that one lamp, and nothing more.
        On an Apple Watch: Shortcuts → new shortcut → <i>Get contents of URL</i> → paste the address.
        Set <b>Where the dashboard answers from outside</b> in Settings first, or the address will say
        <code>your-dashboard</code>.</p>
      <div id="taps-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="tap-add">Add a link</button>
        <button class="btn cmd primary" id="taps-save">Save links</button>
        <span class="muted small" id="taps-dirty"></span>
      </div>
      <div id="tapkeys" style="margin-top:18px"></div>
    </div>
    <div class="card full" data-sec="automation" id="whatif-card">
      <h2>What would happen</h2>
      <p class="note">Pretend a reading arrived and see which rules would fire and what they would do — nothing is
        switched. Useful before saving a rule, and for the ones that never seem to fire: it says which condition,
        cooldown, window or gate is standing in the way.</p>
      <div class="btnrow" id="whatif-row"></div>
      <div id="whatif-out"></div>
    </div>
    <div class="card full" data-sec="system" id="outbox-card" hidden>
      <h2>Messages waiting to go</h2>
      <p class="note">An SMS the gateway would not take is kept here and tried again, so an alert is not simply lost
        when the box is away. They are given up on after <code>sms_queue_hours</code>.</p>
      <div id="outbox-list"></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd" id="outbox-flush">Try them now</button>
        <button class="btn cmd danger" id="outbox-drop">Throw them all away</button>
      </div>
    </div>
    <div class="card full" data-sec="system" id="sms-card">
      <h2>SMS gateway</h2>
      <p class="note">A box with a SIM card — a Teltonika TRB140 and its relatives — so alerts arrive when the internet
        does not, and so a phone with no data can switch something. Fill in where it lives and how it lets you in, then
        <b>Test</b>: with a number it sends one real message, without it only asks the gateway whether it is there.
        Incoming messages are read every <code>sms_poll_s</code> seconds and matched against the commands below.</p>
      <div class="set-grid" id="sms-grid"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd primary" id="sms-save">Save gateway</button>
        <button class="btn cmd" id="sms-test">Test</button>
        <button class="btn cmd" id="sms-send">Send one now</button>
        <button class="btn cmd" id="sms-poll">Read the inbox</button>
        <button class="btn cmd" id="modem-reset">Data counters back to zero</button>
        <button class="btn cmd" id="sms-credit">Ask the network</button>
        <span class="muted small" id="sms-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" data-sec="system" id="snap-card">
      <h2>Going back a step</h2>
      <p class="note">Every Save in these editors keeps what it replaced — the last twenty, newest first.
        <b>Put back</b> restores that version and keeps the current one, so a step back can be stepped forward again.
        This is not the backup: a backup answers "how was it last week", this answers "what did I just do".</p>
      <div id="snap-list"></div>
    </div>
    <div class="card full" data-sec="system" id="routes-card">
      <h2>How devices reach the mesh</h2>
      <p class="note">Which router each battery device is going through, and how often that has changed since the dashboard
        started watching. A device that keeps swapping routers is a device whose commands sometimes take the long way round.</p>
      <div id="routes-list"></div>
    </div>
    <div class="card full" data-sec="system" id="acl-card">
      <h2>What the broker must allow</h2>
      <p class="note">Every topic this dashboard needs, against what <code id="acl-file">the ACL file</code> actually allows.
        A missing line is why a command can go out and nothing happen: the broker drops what the ACL forbids without a word.
        The block below is what to add. <b>Add them for me</b> puts exactly those lines into each user’s own
        block, keeps a copy of the file as it was next to the database, reads it back to check, and asks mosquitto
        to read it again without dropping anybody’s connection. Nothing else in the file is touched — other users, other
        topics and your own comments stay as they are. By hand, <code>kill -HUP $(pidof mosquitto)</code> reloads it.</p>
      <div id="acl-list"></div>
      <pre id="acl-fix" class="acl-fix" hidden></pre>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd primary" id="acl-mend" hidden>Add them for me</button>
      </div>
    </div>
    <div class="card full" data-sec="system" id="latency-card">
      <h2>Where the time goes</h2>
      <p class="note">Live figures for the stretch between a press and a click. Green is what the daemon itself needs; what
        follows is the broker, the boxes and the Zigbee radio, which the daemon can only wait for. A number that stands out
        here is where a lag is coming from.</p>
      <div id="latency-list" class="lat-grid"></div>
    </div>
    <div class="card full" data-sec="system" id="db-card">
      <h2>Database</h2>
      <p class="note">The history, events and every setting made here live in one SQLite file. <b>Check</b> runs SQLite's integrity check. <b>Optimise</b> refreshes the planner statistics and compacts the file (VACUUM) — it can take a while on a large file and holds the daemon's writes meanwhile. <b>Back up</b> takes a consistent copy while the daemon keeps running, into the same folder as the daily settings backups. <b>Restore</b> replaces the live contents with a chosen copy; the state right before is saved first, so a mistaken restore can itself be undone.</p>
      <div class="kv-list" id="db-info"></div>
      <div class="btnrow" style="margin-top:12px;flex-wrap:wrap">
        <button class="btn cmd" id="db-check">Check integrity</button>
        <button class="btn cmd" id="db-optimize">Optimise</button>
        <button class="btn cmd primary" id="db-backup">Back up database now</button>
        <button class="btn cmd" id="db-prune">Clear out noise</button>
        <button class="btn cmd" id="db-upload">Upload a backup</button>
        <input type="file" id="db-upload-file" accept=".sqlite,.db,application/x-sqlite3,application/octet-stream" hidden>
        <span class="muted small" id="db-upload-progress" style="align-self:center"></span>
      </div>
      <div id="db-backups" style="margin-top:12px"></div>
      <div id="db-run" hidden>
        <div class="runbar"><i></i></div>
        <div class="runhead"><span id="db-run-what"></span><span id="db-run-time" class="muted small"></span></div>
        <pre id="db-run-log" class="runlog"></pre>
      </div>
      <p class="muted small" id="db-note" style="margin-top:8px"></p>
    </div>
    <div class="card full" data-sec="system">
      <h2>Daemon</h2>
      <div id="health-kv"></div>
    </div>
  </div>
</section>

<section class="panel" id="tab-all" hidden>
  <div class="grid charts" id="all-values"></div>
</section>

</div>

<div class="toast" id="toast"></div>

<!-- PIN dialog -->
<div class="backdrop" id="attnback" hidden>
  <div class="attnbox" role="dialog" aria-modal="true" aria-labelledby="attntitle">
    <div class="attnhead">
      <h3 id="attntitle">Needs attention</h3>
      <button class="btn cmd small" id="attnclose" type="button">Close</button>
    </div>
    <div id="attnbody"></div>
  </div>
</div>
<div class="backdrop" id="pinback" hidden>
  <div class="pinbox" role="dialog" aria-modal="true" aria-labelledby="pintitle">
    <div class="pinicon" id="pinicon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor"
           stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="10.5" width="16" height="10" rx="2.5"/>
        <path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>
      </svg>
    </div>
    <h3 id="pintitle">Enter PIN</h3>
    <p class="pinwhat" id="pinwhat"></p>
    <div class="pindigits" id="pindigits"></div>
    <div class="unlockbox" id="unlockbox" hidden>
      <span>Unlock editing for</span>
      <select id="unlock-minutes">
        <option value="5">5 min</option><option value="15" selected>15 min</option>
        <option value="30">30 min</option><option value="60">1 h</option><option value="240">4 h</option>
      </select>
    </div>
    <p class="pinerr" id="pinerr"></p>
    <div class="pinrow">
      <button class="btn" id="pincancel">Cancel</button>
      <button class="btn primary" id="pinok" disabled>Confirm</button>
    </div>
  </div>
</div>

<div class="backdrop" id="tellback" hidden>
  <div class="askbox" role="dialog" aria-modal="true">
    <h3 id="telltitle"></h3>
    <div id="tellbody"></div>
    <div class="btnrow" style="justify-content:flex-end;margin-top:12px">
      <button class="btn cmd primary" id="tellok" type="button">Close</button>
    </div>
  </div>
</div>
<div class="backdrop" id="findback" hidden>
  <div class="findbox" role="dialog" aria-modal="true" aria-label="Find anything">
    <input id="findinput" type="text" placeholder="Find a device, a plug, a room, a scene, a rule…" autocomplete="off" spellcheck="false">
    <div id="findlist" class="findlist"></div>
    <p class="findhint">↑↓ to choose · Enter to go · Esc to close</p>
  </div>
</div>
<div class="backdrop" id="askback" hidden>
  <div class="pinbox askbox" role="dialog" aria-modal="true" aria-labelledby="asktitle">
    <div class="pinicon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 20h4l10-10-4-4L4 16z"/><path d="M13 7l4 4"/>
      </svg>
    </div>
    <h3 id="asktitle">Name</h3>
    <p class="pinwhat" id="askwhat"></p>
    <input id="askinput" type="text" maxlength="40" autocomplete="off" spellcheck="false">
    <p class="pinerr" id="askerr"></p>
    <div class="pinrow">
      <button class="btn" id="askcancel">Cancel</button>
      <button class="btn primary" id="askok">OK</button>
    </div>
  </div>
</div>

<script>
'use strict';
var INITIAL = <?= $initial ?>;
var REFRESH_MS = 5000;
var COLORS = ['#58a6ff','#3fb950','#f0883e','#a371f7','#d29922','#f85149','#39d2c0','#e2a9f5','#79c0ff','#ffa657'];
var STATE = { status: null, paused: false, tab: 'overview', ovRange: '24h', hRange: '24h',
              hDevice: null, timer: null, busy: false, charts: {} };

// ---- small helpers --------------------------------------------------------
function $(id) { return document.getElementById(id); }
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) {
  return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function isNum(v) { return typeof v === 'number' && isFinite(v); }
function fmt(v, digits) {
  if (v === null || v === undefined) return '–';
  if (typeof v === 'boolean') return v ? 'yes' : 'no';
  if (!isNum(v)) return String(v);
  if (digits === undefined) digits = Math.abs(v) >= 100 ? 0 : (Math.abs(v) >= 10 ? 1 : 2);
  var s = v.toFixed(digits);
  return s.indexOf('.') >= 0 ? s.replace(/\.?0+$/, '') : s;
}
function ago(ts) {
  if (!ts) return 'never';
  var s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (s < 60) return s + ' s ago';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ' + Math.floor((s % 3600) / 60) + ' min ago';
  return Math.floor(s / 86400) + ' d ' + Math.floor((s % 86400) / 3600) + ' h ago';
}
function pad(n) { return (n < 10 ? '0' : '') + n; }
function stamp(ts) {
  if (!ts) return '–';
  var d = new Date(ts * 1000);
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}
function shortStamp(ts, spanS) {
  var d = new Date(ts * 1000);
  if (spanS > 3 * 86400) return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.';
  if (spanS > 36 * 3600) return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':00';
  return pad(d.getHours()) + ':' + pad(d.getMinutes());
}
function toast(message, ok) {
  var t = $('toast');
  t.textContent = message;
  t.className = 'toast show ' + (ok ? 'ok' : 'bad');
  clearTimeout(t._h);
  t._h = setTimeout(function () { t.className = 'toast'; }, 3200);
}
var VIEWLOCK = { asking: false };
// Declared here rather than beside the card it draws: the render loop asks
// for the scripts long before that point in the file, and a var assigned
// later is undefined when it gets there - which threw, and took everything
// after it in the same loop down with it.
var SCRIPTS = {rows: [], verbs: [], dirty: false};
// While the person is inside an editor (a dropdown held open, a field focused),
// the periodic refresh must not rebuild it under their hands.
function editorBusy(id) {
  // A row being dragged is the busiest an editor gets. The guard against
  // redrawing under a drag only knew about ORDER.drag, which is the cards;
  // a rule dragged by its handle set ROWDRAG instead, so the next report
  // from the house - a second away in a busy one - rebuilt the list under
  // the pointer and the drag came to nothing. Sections moved because they
  // are redrawn by their own section code, not by this.
  if (ROWDRAG || Date.now() - ROWDROPPED < 800) return true;
  var host = document.getElementById(id), a = document.activeElement;
  if (!host || !a || a === document.body || !host.contains(a)) return false;
  // only a field someone may be typing in or a dropdown held open counts;
  // a button keeps focus after its click, and that must not freeze the editor
  var tag = (a.tagName || '').toLowerCase();
  return tag === 'input' || tag === 'select' || tag === 'textarea';
}
function api(what, options) {
  var extra = (!options && LOCK.token) ? '&session=' + encodeURIComponent(LOCK.token) : '';
  return fetch('?api=' + what + extra, options).then(function (r) {
    return r.text().then(function (text) {
      var data;
      try { data = JSON.parse(text); }
      catch (e) {
        var err = new Error(r.status === 413 ? 'the web server refused the request as too large (HTTP 413) \u2014 raise client_max_body_size in nginx to 6m'
          : 'the web server answered HTTP ' + r.status + ' instead of JSON' + (/<title>([^<]*)/.test(text) ? ' (' + RegExp.$1.trim() + ')' : ''));
        err.status = r.status; throw err;
      }
      // A view that wants the PIN offers to unlock - but only when a person
      // asked for it. The Public API tab asks for two of those once a second
      // by itself, so a reload used to throw the PIN box up again and again,
      // and again after it was dismissed. Those say so in place of their
      // lists instead, and the offer comes when something is pressed.
      var quiet = /^(approvals|blocked)(&|$)/.test(String(what));
      if (r.status === 403 && data && /view locked/.test(data.error || '')
          && !VIEWLOCK.asking && !quiet) {
        VIEWLOCK.asking = true;
        unlockFlow(function () { VIEWLOCK.asking = false; tick(true); });
      }
      if (!r.ok && data && data.error) { var e1 = new Error(data.error); e1.status = r.status; throw e1; }
      if (!r.ok) { var e2 = new Error('HTTP ' + r.status); e2.status = r.status; throw e2; }
      return data;
    });
  });
}
function post(what, body) {
  body = body || {};
  if (LOCK.token && body.session === undefined) body.session = LOCK.token;
  return api(what, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body) });
}
function levelWord(level) {
  return {ok: 'All good', warn: 'Needs attention', crit: 'Problem', unknown: 'No data'}[level] || level;
}
function deviceById(id) {
  var devs = (STATE.status && STATE.status.devices) || [];
  for (var i = 0; i < devs.length; i++) if (devs[i].id === id) return devs[i];
  // a socket is a device too, and the popup should say what it is drawing:
  // the Devices list carries it as plug:<name>, the target columns as <name>
  for (var j = 0; j < devs.length; j++) if (devs[j].name === id || devs[j].id === 'plug:' + id) return devs[j];
  return null;
}
function tempKey(d) { return d.values.temperature ? 'temperature' : (d.values.tC ? 'tC' : null); }
function humKey(d)  { return d.values.humidity ? 'humidity' : (d.values.rh ? 'rh' : null); }

// ---- favicon ---------------------------------------------------------------
function setFavicon(level) {
  var color = {ok: '#3fb950', warn: '#d29922', crit: '#f85149'}[level] || '#6e7681';
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    + '<rect x="18" y="4" width="28" height="44" rx="14" fill="none" stroke="' + color + '" stroke-width="6"/>'
    + '<circle cx="32" cy="46" r="10" fill="' + color + '"/><rect x="29" y="18" width="6" height="26" fill="' + color + '"/></svg>';
  $('favicon').href = 'data:image/svg+xml,' + encodeURIComponent(svg);
}

// ---- charts ----------------------------------------------------------------
// ---- charts: inline SVG, drag to pan, wheel to zoom, as in upsmon ------------------
// Every chart keeps its own view window over the data it was given. Dragging
// moves that window, the wheel zooms it around the pointer, a double click
// (or the reset button) puts it back. Nothing is re-fetched while panning.
// series: [{name, color, unit, points: [[ts, value], ...]}]
var CHART_STATE = {};   // container id -> {rows, series, opts, extent, from, to, zoomed}

function humanGap(seconds) {
  if (seconds < 90) return Math.round(seconds) + ' s';
  if (seconds < 5400) return Math.round(seconds / 60) + ' min';
  if (seconds < 172800) return (seconds / 3600).toFixed(1) + ' h';
  return (seconds / 86400).toFixed(1) + ' d';
}
function drawChart(container, series, opts) {
  opts = opts || {};
  var id = container.id || (container.id = 'c' + Math.random().toString(36).slice(2));
  STATE.charts[id] = {series: series, opts: opts};
  var byTs = {};
  series.forEach(function (s, i) {
    s.points.forEach(function (p) {
      if (!isNum(p[1])) return;
      (byTs[p[0]] = byTs[p[0]] || {ts: p[0]})['s' + i] = p[1];
    });
  });
  var rows = Object.keys(byTs).map(Number).sort(function (a, b) { return a - b; }).map(function (t) { return byTs[t]; });
  if (!rows.length) {
    container.innerHTML = '';
    container.appendChild(el('div', 'empty', opts.empty || 'No data for this range yet'));
    delete CHART_STATE[id];
    return;
  }
  var now = Math.floor(Date.now() / 1000);
  var extent = [rows[0].ts, rows[rows.length - 1].ts];
  if (opts.spanS) { extent = [Math.min(extent[0], now - opts.spanS), Math.max(extent[1], now)]; }
  if (extent[1] - extent[0] < 60) { extent[0] -= 30; extent[1] += 30; }
  var old = CHART_STATE[id];
  var keep = old && old.zoomed;
  CHART_STATE[id] = { rows: rows, series: series, opts: opts, extent: extent,
                      from: keep ? old.from : extent[0], to: keep ? old.to : extent[1], zoomed: !!keep };
  if (keep) applyView(id, old.from, old.to);
  renderChart(id);
}

function renderChart(id) {
  var state = CHART_STATE[id];
  if (!state) return;
  var container = $(id), all = state.rows, series = state.series, opts = state.opts;
  if (!container) return;
  var W = Math.max(280, container.clientWidth || 600), H = container.clientHeight || 240;
  var padL = 46, padR = 12, padT = 12, padB = 26;
  var plotW = W - padL - padR, plotH = H - padT - padB;
  var t0 = state.from, t1 = state.to;
  if (t1 - t0 < 60) t1 = t0 + 60;

  // one row either side of the window, so lines reach the edges
  var first = 0, last = all.length - 1, i;
  for (i = 0; i < all.length; i++) { if (all[i].ts >= t0) { first = Math.max(0, i - 1); break; } }
  for (i = all.length - 1; i >= 0; i--) { if (all[i].ts <= t1) { last = Math.min(all.length - 1, i + 1); break; } }
  var rows = all.slice(first, last + 1);
  if (!rows.length) rows = all;

  var lo = null, hi = null;
  rows.forEach(function (r) { series.forEach(function (s, n) {
    var v = r['s' + n]; if (!isNum(v)) return;
    lo = lo === null || v < lo ? v : lo; hi = hi === null || v > hi ? v : hi; }); });
  if (lo === null) { lo = 0; hi = 1; }
  if (opts.min !== undefined && opts.min < lo) lo = opts.min;
  if (opts.max !== undefined && opts.max > hi) hi = opts.max;
  if (hi - lo < 1e-9) { lo -= 1; hi += 1; }
  var padY = (hi - lo) * 0.08; lo -= padY; hi += padY;
  function px(ts) { return padL + (ts - t0) / (t1 - t0) * plotW; }
  function py(v) { return padT + plotH - (v - lo) / (hi - lo) * plotH; }

  var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none">';
  svg += '<defs><clipPath id="clip-' + id + '"><rect x="' + padL + '" y="' + padT + '" width="' + plotW + '" height="' + plotH + '"/></clipPath></defs>';
  for (var g = 0; g <= 4; g++) {
    var value = lo + (hi - lo) * g / 4, y = py(value);
    svg += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#262c37"/>';
    svg += '<text x="' + (padL - 6) + '" y="' + (y + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="#5b6472">' + fmt(value, Math.abs(hi - lo) < 5 ? 1 : 0) + '</text>';
  }
  var span = t1 - t0, xTicks = Math.max(2, Math.min(8, Math.floor(plotW / 90)));
  for (var j = 0; j <= xTicks; j++) {
    var ts = t0 + span * j / xTicks;
    svg += '<text x="' + px(ts).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="' + (j === 0 ? 'start' : (j === xTicks ? 'end' : 'middle')) + '" font-size="11" fill="#5b6472">' + shortStamp(ts, span) + '</text>';
  }
  // A line is always one continuous stroke, whatever the source's rhythm -
  // a thermometer waking every four hours and a plug answering every 15 s
  // both draw the same way, start to finish, with no breaks. Shading real
  // outages on top is optional (Settings \u2192 Charts), off by default.
  function seriesRhythm(n) {
    var steps = [], prev = null;
    all.forEach(function (r) {
      var v = r['s' + n];
      if (!isNum(v)) return;
      if (prev !== null) steps.push(r.ts - prev);
      prev = r.ts;
    });
    if (steps.length < 3) return null;
    steps.sort(function (a, b) { return a - b; });
    return steps[Math.floor(steps.length / 2)] || null;
  }
  svg += '<g clip-path="url(#clip-' + id + ')">';
  var outages = [];
  series.forEach(function (s, n) {
    var d = '', prev = null, count = 0;
    var median = opts.outages ? seriesRhythm(n) : null;
    var breakAfter = median ? Math.max(median * 4 + 60, 300) : null;
    rows.forEach(function (r) {
      var v = r['s' + n];
      if (!isNum(v)) return;
      count++;
      if (breakAfter && prev !== null && r.ts - prev > breakAfter && median <= 300) outages.push([prev, r.ts]);
      d += (prev === null ? 'M' : 'L') + px(r.ts).toFixed(1) + ' ' + py(v).toFixed(1) + ' ';
      prev = r.ts;
    });
    svg += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>';
    if (count < 60) rows.forEach(function (r) {
      var v = r['s' + n];
      if (isNum(v)) svg += '<circle cx="' + px(r.ts).toFixed(1) + '" cy="' + py(v).toFixed(1) + '" r="2.2" fill="' + s.color + '"/>';
    });
  });
  if (opts.outages && outages.length) {
    var merged = [];
    outages.sort(function (a, b) { return a[0] - b[0]; }).forEach(function (o) {
      var lastSpan = merged[merged.length - 1];
      if (lastSpan && o[0] <= lastSpan[1]) lastSpan[1] = Math.max(lastSpan[1], o[1]);
      else merged.push([o[0], o[1]]);
    });
    merged.forEach(function (o) {
      var x = px(o[0]), width = Math.max(1.5, px(o[1]) - px(o[0]));
      svg += '<rect x="' + x.toFixed(1) + '" y="' + padT + '" width="' + width.toFixed(1) + '" height="' + plotH
        + '" fill="#f8514918" stroke="#f8514940" stroke-dasharray="2 3"><title>no data for '
        + humanGap(o[1] - o[0]) + ' \u2014 the device was quiet</title></rect>';
    });
  }
  svg += '</g>';
  svg += '<line class="cross" x1="0" x2="0" y1="' + padT + '" y2="' + (padT + plotH) + '" stroke="#8b94a3" stroke-width="1" stroke-dasharray="3 3" opacity="0"/>';
  svg += '</svg>';
  var full = t0 <= state.extent[0] && t1 >= state.extent[1];
  container.innerHTML = svg
    + '<button class="creset" type="button" title="Back to the whole range"' + (full ? ' hidden' : '')
      + '>' + iconMarkup('reset', 10) + '<span>reset</span></button>'
    + '<span class="chint">drag to pan · wheel to zoom · double-click to reset</span>'
    + '<div class="tip"></div>';
  wireChart(id, { t0: t0, t1: t1, padL: padL, padR: padR, W: W, H: H, rows: rows });
}

function wireChart(id, view) {
  var container = $(id), state = CHART_STATE[id];
  var svg = container.querySelector('svg'), tip = container.querySelector('.tip');
  var cross = container.querySelector('.cross'), reset = container.querySelector('.creset');
  if (!svg || !state) return;
  var series = state.series;

  function tsAt(clientX) {
    var box = svg.getBoundingClientRect();
    var frac = box.width ? (clientX - box.left) / box.width : 0;
    var plotFrom = view.padL / view.W, plotTo = (view.W - view.padR) / view.W;
    return view.t0 + (frac - plotFrom) / (plotTo - plotFrom) * (view.t1 - view.t0);
  }

  // ---- hover readout ----
  function hover(clientX, clientY) {
    if (container.classList.contains('dragging')) return;
    var ts = tsAt(clientX);
    if (ts < view.t0 || ts > view.t1) { leave(); return; }
    var html = '<b>' + stamp(Math.round(ts)) + '</b>', any = false;
    series.forEach(function (s, n) {
      var best = null, bd = Infinity;
      view.rows.forEach(function (r) { var v = r['s' + n]; if (!isNum(v)) return; var dd = Math.abs(r.ts - ts); if (dd < bd) { bd = dd; best = r; } });
      if (best && bd < Math.max((view.t1 - view.t0) / 40, 900)) {
        any = true;
        html += '<br><span class="sw" style="background:' + s.color + '"></span>' + esc(s.name) + ': <b>' + fmt(best['s' + n]) + (s.unit ? ' ' + s.unit : '') + '</b>';
      }
    });
    if (!any) { leave(); return; }
    tip.innerHTML = html; tip.style.display = 'block';
    var rect = container.getBoundingClientRect();
    var x = clientX - rect.left, y = clientY - rect.top, tw = tip.offsetWidth, th = tip.offsetHeight;
    tip.style.left = Math.min(rect.width - tw - 4, Math.max(0, x + 14)) + 'px';
    tip.style.top = Math.max(0, Math.min(rect.height - th, y - th - 10)) + 'px';
    var box = svg.getBoundingClientRect();
    var cx = box.width ? (clientX - box.left) / box.width * view.W : 0;
    cross.setAttribute('x1', cx.toFixed(1)); cross.setAttribute('x2', cx.toFixed(1)); cross.setAttribute('opacity', '1');
  }
  function leave() { tip.style.display = 'none'; cross.setAttribute('opacity', '0'); }
  svg.addEventListener('mousemove', function (e) { hover(e.clientX, e.clientY); });
  svg.addEventListener('mouseleave', leave);

  // ---- drag to pan: followed on the window, so the redraw under the pointer cannot break the gesture ----
  var dragFrom = null, dragFrame = null;
  function onDragMove(e) {
    if (!dragFrom) return;
    e.preventDefault();
    var plotWidth = dragFrom.width * (view.W - view.padL - view.padR) / view.W;
    var perPixel = (dragFrom.t1 - dragFrom.t0) / Math.max(1, plotWidth);
    var shift = -(e.clientX - dragFrom.x) * perPixel;
    if (Math.abs(e.clientX - dragFrom.x) > 2) state.zoomed = true;
    applyView(id, dragFrom.t0 + shift, dragFrom.t1 + shift);
    if (dragFrame === null) dragFrame = requestAnimationFrame(function () { dragFrame = null; if (dragFrom) renderChart(id); });
  }
  function endDrag() {
    if (!dragFrom) return;
    dragFrom = null;
    if (dragFrame !== null) { cancelAnimationFrame(dragFrame); dragFrame = null; }
    container.classList.remove('dragging');
    window.removeEventListener('pointermove', onDragMove);
    window.removeEventListener('pointerup', endDrag);
    window.removeEventListener('pointercancel', endDrag);
    renderChart(id);
  }
  svg.addEventListener('pointerdown', function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    if (e.pointerType === 'touch' && pinch) return;
    e.preventDefault();
    dragFrom = { x: e.clientX, t0: state.from, t1: state.to, width: svg.getBoundingClientRect().width };
    container.classList.add('dragging');
    leave();
    window.addEventListener('pointermove', onDragMove);
    window.addEventListener('pointerup', endDrag);
    window.addEventListener('pointercancel', endDrag);
  });

  // ---- wheel to zoom, anchored on the pointer ----
  svg.addEventListener('wheel', function (e) {
    e.preventDefault();
    var anchor = tsAt(e.clientX);
    var factor = e.deltaY > 0 ? 1.25 : 0.8;
    state.zoomed = true;
    applyView(id, anchor - (anchor - state.from) * factor, anchor + (state.to - anchor) * factor);
    renderChart(id);
  }, { passive: false });
  svg.addEventListener('dblclick', function () { resetView(id); });
  if (reset) reset.onclick = function () { resetView(id); };

  // ---- pinch to zoom on a touch screen ----
  var pinch = null;
  svg.addEventListener('touchstart', function (e) {
    if (e.touches.length === 2) { pinch = { distance: touchGap(e), t0: state.from, t1: state.to }; endDrag(); }
  }, { passive: true });
  svg.addEventListener('touchmove', function (e) {
    if (!pinch || e.touches.length !== 2) return;
    e.preventDefault();
    var factor = pinch.distance / Math.max(1, touchGap(e));
    var middle = (pinch.t0 + pinch.t1) / 2, half = (pinch.t1 - pinch.t0) / 2 * factor;
    state.zoomed = true;
    applyView(id, middle - half, middle + half);
    renderChart(id);
  }, { passive: false });
  svg.addEventListener('touchend', function () { pinch = null; });
}
function touchGap(e) {
  var dx = e.touches[0].clientX - e.touches[1].clientX, dy = e.touches[0].clientY - e.touches[1].clientY;
  return Math.sqrt(dx * dx + dy * dy);
}
// Keep the window inside the data's extent and never narrower than a minute.
function applyView(id, from, to) {
  var state = CHART_STATE[id];
  if (!state) return;
  var firstTs = state.extent[0], lastTs = state.extent[1], full = (lastTs - firstTs) || 60;
  var width = Math.max(60, Math.min(to - from, full));
  var middle = (from + to) / 2;
  from = middle - width / 2; to = from + width;
  if (from < firstTs) { from = firstTs; to = from + width; }
  if (to > lastTs) { to = lastTs; from = Math.max(firstTs, to - width); }
  state.from = from; state.to = to;
  if (from <= firstTs && to >= lastTs) state.zoomed = false;
}
function resetView(id) {
  var state = CHART_STATE[id];
  if (!state) return;
  state.from = state.extent[0]; state.to = state.extent[1]; state.zoomed = false;
  renderChart(id);
}
function redrawCharts() {
  Object.keys(CHART_STATE).forEach(function (id) {
    var c = $(id);
    if (c && c.offsetParent !== null) renderChart(id);
  });
}
function legend(host, series) {
  host.innerHTML = '';
  series.forEach(function (s) {
    var item = el('span');
    item.innerHTML = '<span class="sw" style="background:' + s.color + '"></span>' + esc(s.name);
    host.appendChild(item);
  });
}
window.addEventListener('resize', function () {
  clearTimeout(window._rt);
  // the charts are drawn to a width, and the column headers are put over
  // their boxes by measurement - both have to be taken again when the width
  // changes, or a narrow window keeps a wide window's answer
  window._rt = setTimeout(function () { redrawCharts(); sizeGatewayButtons(); sizeTapTools(); markHeaderIndent(); }, 150);
});


// ---- what needs attention, in one place: click the pill or the metric card ---------
function attentionItems(st) {
  var items = [];
  if (!st.connected) items.push({level: 'crit', who: 'MQTT broker', why: 'The daemon is not connected to ' + esc(st.broker || 'the broker') + (st.last_error ? ' — ' + esc(st.last_error) : '') + '. Nothing from Zigbee2MQTT reaches the dashboard until it is back.'});
  var b = st.bridge || {};
  if (st.connected && b.state !== 'online') items.push({level: 'crit', who: 'Zigbee2MQTT', why: 'The bridge reports ' + esc(b.state || 'no state') + ' — the Zigbee network is not being served.'});
  (st.devices || []).forEach(function (d) {
    if (d.level !== 'warn' && d.level !== 'crit') return;
    items.push({level: d.level, who: d.name, id: d.id,
      why: (d.reasons && d.reasons.length) ? d.reasons.map(esc).join('; ') : (d.online ? 'flagged by a threshold' : 'not reporting'),
      when: d.last_seen ? 'last report ' + ago(d.last_seen) : 'never reported'});
  });
  (st.plugs || []).forEach(function (p) {
    if (p.online && !p.stale) return;
    if (p.optional) return;                 // may be unplugged: expected, not a fault
    if (items.some(function (x) { return x.id === p.id; })) return;
    items.push({level: 'crit', who: p.name, id: p.id,
      why: 'unreachable' + (p.error ? ' — ' + esc(p.error) : '') + (p.retry_in ? ', retrying in ' + p.retry_in + ' s' : ''),
      when: p.generated ? 'last answer ' + ago(p.generated) : 'never answered'});
  });
  var order = {crit: 0, warn: 1, info: 2};
  items.sort(function (a, b) { return (order[a.level] - order[b.level]) || a.who.localeCompare(b.who); });
  return items;
}
// One dialog, three lists: what needs attention, what is and is not
// reporting, and who is in. Same shape everywhere - a level chip, a name
// that opens History, a line of why, a line of when.
function showDetail(title, items, empty, wide) {
  var body = $('attnbody'); body.innerHTML = '';
  document.querySelector('.attnbox').classList.toggle('wide', !!wide);
  $('attntitle').textContent = title;
  if (!items.length && empty) {
    body.appendChild(el('div', 'attn-ok', empty[0]));
    if (empty[1]) body.appendChild(el('div', 'muted small', empty[1]));
  }
  items.forEach(function (it) {
    if (it.section) { body.appendChild(el('div', 'attn-sec', it.section)); return; }
    var row = el('div', 'attn-item');
    row.appendChild(el('span', 'lvl ' + it.level, it.tag || (it.level === 'crit' ? 'problem' : it.level)));
    var right = el('div');
    var who = el('div', 'who');
    if (it.rich) who.innerHTML = it.who; else who.textContent = it.who;
    if (it.id) {
      who.title = 'Open in History';
      who.onclick = function () { $('attnback').hidden = true; STATE.hDevice = it.id; showTab('history'); };
    }
    right.appendChild(who);
    var why = el('div', 'why'); why.innerHTML = it.why; right.appendChild(why);
    if (it.when) right.appendChild(el('div', 'when', it.when));
    row.appendChild(right);
    body.appendChild(row);
  });
  $('attnback').hidden = false;
}
// What to put in the phone. Asks for the PIN once, since it hands out the
// token that lets that handset speak for this person.
function showPhoneSetup(person) {
  withPin('Setup for ' + person.name + '\u2019s phone', 'Shows the step-by-step for the phone, with its own link and token.', function (pin) {
    return post('person-token', {id: person.id, pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not read the token');
      paintPhoneSetup(person, r.token);
      return 'Setup shown';
    });
  });
}
// The whole walkthrough, with this person's own link and token already in it,
// so nothing has to be looked up anywhere else. Two ways: straight at the
// dashboard, or through an ntfy topic when nothing here should face the
// internet - whichever is set up is shown first.
function paintPhoneSetup(person, token) {
  var base = location.origin + location.pathname;
  var arrive = base + '?api=presence-report&state=home&token=' + token;
  var leave = base + '?api=presence-report&state=away&token=' + token;
  var ntfy = (STATE.status.wifi_config || {}).presence_ntfy || '';
  var topic = ntfy ? ntfy.replace(/^https?:\/\/[^/]+\//, '') : '';
  var items = [];
  function step(n, title, html) { items.push({level: 'dim', tag: String(n), who: title, why: html || '', rich: true}); }
  function copyable(text) {
    // the whole value in the tooltip as well, since a long one is drawn cut
    return '<code class="copyme" data-copy="' + esc(text) + '" title="' + esc(text)
      + ' \u2014 click to copy \u00b7 hover for a QR code">' + esc(text) + '</code>';
  }
  items.push({section: 'First, on the phone (once)'});
  step(1, 'Let Shortcuts see where you are',
    'Settings \u2192 Privacy &amp; Security \u2192 Location Services \u2192 <b>Shortcuts</b> \u2192 <b>Always</b>. '
    + 'Without this an arrival automation will not run while the phone is locked, which is exactly when it matters.');
  if (ntfy) {
    items.push({section: 'Arriving \u2014 through ntfy, nothing here exposed'});
    step(2, 'Shortcuts \u2192 Automation \u2192 + \u2192 Create Personal Automation');
    step(3, 'Choose <b>Arrive</b>',
      'Set <b>Location</b> to your home address. Leave the time range at <i>Any time</i>. Tap <b>Next</b>.');
    step(4, 'New Blank Automation \u2192 Add Action \u2192 <b>Get Contents of URL</b>');
    step(5, 'Fill the action in',
      'URL: ' + copyable('https://ntfy.sh/') + '<br>Tap <b>Show More</b>, then set <b>Method</b> to <code>POST</code> and '
      + '<b>Request Body</b> to <code>JSON</code>. Add two text fields:<br>'
      + '&nbsp;&nbsp;key <code>topic</code> \u2192 ' + copyable(topic) + '<br>'
      + '&nbsp;&nbsp;key <code>message</code> \u2192 ' + copyable('home ' + token));
    step(6, 'Tap Next, then <b>Run Immediately</b>',
      'Turn <b>Notify When Run</b> off once you have tested it, and tap <b>Done</b>.');
    items.push({section: 'Leaving'});
    step(7, 'The same again with <b>Leave</b>',
      'Identical, except the trigger is <b>Leave</b> and the message is ' + copyable('away ' + token) + '.');
    items.push({section: 'Or straight at the dashboard'});
    items.push({level: 'dim', tag: 'url', who: 'One link per automation, no body to fill in', rich: true,
      why: 'Use <b>Get Contents of URL</b> with the method left at GET and these links instead:<br>'
        + 'arriving ' + copyable(arrive) + '<br>leaving ' + copyable(leave)
        + '<br>This needs the dashboard to be reachable from the phone\u2019s mobile data.'});
  } else {
    items.push({section: 'Arriving'});
    step(2, 'Shortcuts \u2192 Automation \u2192 + \u2192 Create Personal Automation');
    step(3, 'Choose <b>Arrive</b>',
      'Set <b>Location</b> to your home address. Leave the time range at <i>Any time</i>. Tap <b>Next</b>.');
    step(4, 'New Blank Automation \u2192 Add Action \u2192 <b>Get Contents of URL</b>');
    step(5, 'Paste this as the URL', copyable(arrive) + '<br>Nothing else to change \u2014 the method stays GET.');
    step(6, 'Tap Next, then <b>Run Immediately</b>',
      'Turn <b>Notify When Run</b> off once you have tested it, and tap <b>Done</b>.');
    items.push({section: 'Leaving'});
    step(7, 'The same again with <b>Leave</b>', 'and this URL: ' + copyable(leave));
    items.push({section: 'Or through ntfy, with nothing exposed'});
    items.push({level: 'dim', tag: 'ntfy', who: 'The phone publishes, the daemon listens', rich: true,
      why: 'Set a <b>presence topic</b> on the Wi-Fi controller card above — <code>https://ntfy.sh/</code> and a long random name — '
        + 'and this dialog will show that way instead. Nothing here has to be reachable from the internet.'});
  }
  items.push({section: 'On Android'});
  items.push({level: 'dim', tag: 'droid', who: 'Tasker or MacroDroid', rich: true,
    why: 'A location-entered profile making the same HTTP request. The link and the body above are the whole of it.'});
  items.push({section: 'Testing it'});
  items.push({level: 'ok', tag: 'test', who: 'Run the automation by hand once', rich: true,
    why: 'The \u25b6 button in its editor. Then look at <b>Events</b> here: a line reading '
      + '\u201c' + esc(person.name) + ' reported home\u201d means it arrived. The person\u2019s row will say so too.'});
  items.push({section: 'What it does, and does not, do'});
  items.push({level: 'dim', tag: 'how', who: 'Arriving counts at once, leaving is checked first', rich: true,
    why: 'The phone\u2019s geofence trips while you are still down the street, before it is on the Wi-Fi at all. A reported departure '
      + 'asks the controller once before it counts, because a phone sitting on the home network has not left. Unconfirmed, the '
      + 'phone\u2019s word stands for half an hour and then the Wi-Fi has the say again.'});
  items.push({level: 'warn', tag: 'token', who: 'The token is the whole credential', rich: true,
    why: 'Anyone holding it can flip this person\u2019s presence, and nothing else. It is never shown in the dashboard\u2019s own status. '
      + '<b>Make a new token</b> below stops the old links working at once.'});
  showDetail('Phone setup \u2014 ' + person.name, items, null, true);
  // click any of the greyed snippets to copy it
  Array.prototype.forEach.call($('attnbody').querySelectorAll('.copyme'), function (c) {
    c.onmouseenter = function () { showQr(c); };
    c.onmouseleave = hideQr;
    c.onclick = function () { copyText(c.dataset.copy); };
  });
  var again = cmdButton('Make a new token', 'reset', 'small danger'); again.classList.remove('needs-unlock');
  again.title = 'Throw the phone\u2019s token away and issue a new one \u2014 the shortcut on the phone has to be set up again';
  again.style.marginTop = '12px';
  again.onclick = function () {
    withPin('New token for ' + person.name, 'The links above stop working at once.', function (pin2) {
      return post('person-token', {id: person.id, pin: pin2, roll: true}).then(function (rr) {
        if (!rr.ok) throw new Error(rr.error || 'could not make one');
        paintPhoneSetup(person, rr.token);
        return 'A new token is ready';
      });
    }, true);
  };
  $('attnbody').appendChild(again);
}
function showAttention() {
  var st = STATE.status; if (!st) return;
  var items = attentionItems(st), c = st.counts || {};
  showDetail(items.length ? levelWord(items[0].level) + ' \u2014 ' + items.length + ' item' + (items.length === 1 ? '' : 's') : 'All good',
    items, ['\u2713 Nothing needs attention',
            (c.devices || 0) + ' device' + (c.devices === 1 ? '' : 's') + ', ' + (c.online || 0) + ' online, thresholds all within limits, broker and bridge up.']);
}
// what a device is, in a few words, for the lists below
function deviceWhat(d) {
  return [[d.vendor, d.model].filter(Boolean).join(' '), d.description,
          d.source === 'plug' ? 'Shelly' : (d.source === 'wifi' ? 'Wi-Fi' : (d.kind || ''))].filter(Boolean).join(' \u00b7 ');
}
function showOnline(scope) {
  var st = STATE.status; if (!st) return;
  var devs = (st.devices || []).slice().sort(function (a, b) { return a.name.localeCompare(b.name); });
  var plugById = {}; (st.plugs || []).forEach(function (p) { plugById[p.id] = p; });
  var on = [], off = [];
  devs.forEach(function (d) {
    var plug = plugById[d.id];
    var why = deviceWhat(d);
    var when = d.last_seen ? (d.source === 'plug' ? 'last answer ' : 'last report ') + ago(d.last_seen) : 'never reported';
    if (d.online) {
      var extra = [];
      if (isNum(d.linkquality)) extra.push('link ' + d.linkquality);
      if (isNum(d.battery)) extra.push('battery ' + d.battery + ' %');
      if (plug && plug.output !== null && plug.output !== undefined) extra.push(plug.output ? 'switched on' : 'switched off');
      on.push({level: d.level === 'ok' ? 'ok' : d.level, tag: 'online', who: d.name, id: d.id,
               why: esc([why, extra.join(' \u00b7 ')].filter(Boolean).join(' \u2014 ')), when: when});
    } else {
      off.push({level: plug && plug.optional ? 'dim' : 'crit', tag: plug && plug.optional ? 'unplugged' : 'offline',
                who: d.name, id: d.id,
                why: esc(why) + (plug && plug.error ? ' \u2014 ' + esc(plug.error) : (d.availability === 'offline' ? ' \u2014 the bridge reports it offline' : '')),
                when: when});
    }
  });
  var items = [];
  if (off.length) items = items.concat([{section: 'Not reporting \u2014 ' + off.length}], off);
  if (on.length) items = items.concat([{section: 'Reporting \u2014 ' + on.length}], on);
  var c = st.counts || {};
  showDetail('Online \u2014 ' + (c.online || 0) + ' of ' + (c.devices || 0), items, ['No devices yet', 'Nothing has been paired or added.']);
}
function showAtHome() {
  var st = STATE.status; if (!st) return;
  var pres = st.presence || {}, wifi = pres.wifi || {};
  var watched = (pres.people || []).filter(function (p) { return p.enabled !== false; });
  var inside = watched.filter(function (p) { return p.home; });
  var items = [];
  if (!wifi.enabled) items.push({level: 'dim', tag: 'off', who: 'Presence is switched off',
    why: 'Nobody is being looked for. Switch the controller on under Control \u2192 Presence.'});
  else if (wifi.ok === false) items.push({level: 'warn', tag: 'controller', who: 'The Wi-Fi controller is not answering',
    why: esc(wifi.error || 'the last question went unanswered') + ' \u2014 who is in cannot be told apart from who is out until it replies.',
    when: wifi.checked ? 'last asked ' + ago(wifi.checked) : 'never asked'});
  watched.forEach(function (p) {
    var why = [];
    if (p.reason) why.push(esc(p.reason));
    else if (p.device) why.push('seen as ' + esc(p.device));
    if ((p.macs || []).length && !p.reason) why.push((p.macs.length === 1 ? 'address ' : 'addresses ') + p.macs.map(esc).join(', '));
    if (p.leaving_in) why.push('counts as out in ' + runtimeText(p.leaving_in));
    items.push({level: p.home ? 'ok' : 'dim', tag: p.home ? 'in' : 'out', who: p.name,
      why: why.join(' \u00b7 ') || 'nothing of this person has been seen on the network',
      when: p.last_seen ? 'last on the network ' + ago(p.last_seen) + (p.since ? ' \u00b7 ' + (p.home ? 'in' : 'out') + ' since ' + ago(p.since) : '') : 'never seen'});
  });
  if (wifi.enabled && wifi.ok !== false)
    items.push({level: 'dim', tag: 'controller', who: 'The Wi-Fi controller',
      why: 'answering' + (isNum(wifi.clients) ? ' \u00b7 ' + wifi.clients + ' clients on the network'
            + (isNum(wifi.wifi_clients) ? ', ' + wifi.wifi_clients + ' of them wireless' : '') : ''),
      when: wifi.checked ? 'last asked ' + ago(wifi.checked) : ''});
  showDetail('At home \u2014 ' + (watched.length ? (inside.length ? inside.map(function (p) { return p.name; }).join(', ') : 'nobody in') : 'nobody watched'),
    items, ['Nobody is being watched', 'Add a person under Control \u2192 Presence.']);
}
function showDevices() {
  var st = STATE.status; if (!st) return;
  var by = {};
  (st.devices || []).forEach(function (d) {
    var group = d.source === 'plug' ? 'Shelly plugs and switches' : (d.source === 'wifi' ? 'On the Wi-Fi' : (d.kind === 'Coordinator' || d.kind === 'Router' ? 'Zigbee routers and coordinators' : 'Zigbee end devices'));
    (by[group] = by[group] || []).push(d);
  });
  var items = [];
  Object.keys(by).sort().forEach(function (group) {
    items.push({section: group + ' \u2014 ' + by[group].length});
    by[group].sort(function (a, b) { return a.name.localeCompare(b.name); }).forEach(function (d) {
      items.push({level: d.level === 'ok' ? 'ok' : d.level, tag: d.online ? levelWord(d.level).toLowerCase() : 'offline',
        who: d.name, id: d.id, why: esc(deviceWhat(d)) + ((d.reasons || []).length ? ' \u2014 ' + d.reasons.map(esc).join('; ') : ''),
        when: d.last_seen ? 'last report ' + ago(d.last_seen) : 'never reported'});
    });
  });
  var c = st.counts || {};
  showDetail('Devices \u2014 ' + (c.devices || 0), items, ['No devices yet', 'Nothing has been paired or added.']);
}
$('pill').onclick = showAttention;
$('m-attn-card').onclick = showAttention;
$('m-online-card').onclick = showOnline;
$('m-home-card').onclick = showAtHome;
$('m-devices-card').onclick = showDevices;
$('attnclose').onclick = function () { $('attnback').hidden = true; };
$('attnback').addEventListener('click', function (e) { if (e.target === $('attnback')) $('attnback').hidden = true; });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('attnback').hidden) $('attnback').hidden = true; });

// ---- overview ----------------------------------------------------------------
function renderOverview(st) {
  var c = st.counts || {devices: 0, online: 0, ok: 0, warn: 0, crit: 0};
  $('m-devices').textContent = c.devices;
  $('m-devices-sub').textContent = c.devices ? (c.ok + ' ok · ' + c.warn + ' warn · ' + c.crit + ' crit') : 'none paired yet';
  $('m-online').textContent = c.online;
  $('m-online-sub').textContent = c.devices ? 'of ' + c.devices : '';
  $('m-online-card').className = 'card metric ' + (c.devices && c.online < c.devices ? 'warn' : '');
  $('m-online-card').title = 'Click for what is and is not reporting';
  $('m-devices-card').title = 'Click for every device, grouped';
  $('m-home-card').title = 'Click for who is in, and how it is known';
  var attn = c.warn + c.crit;
  $('m-attn').textContent = attn;
  $('m-attn-card').className = 'card metric ' + (c.crit ? 'crit' : (c.warn ? 'warn' : 'ok'));
  $('m-attn-sub').textContent = attn ? 'click for details' : 'everything reporting';
  var b = st.bridge || {};
  var bstate = st.connected ? (b.state || 'unknown') : 'broker down';
  $('m-bridge').textContent = bstate;
  $('m-bridge-card').className = 'card metric ' + (st.connected && b.state === 'online' ? 'ok' : 'crit');
  $('m-bridge-sub').textContent = (b.version ? 'v' + b.version : '') + (b.channel ? ' · channel ' + b.channel : '') + (b.coordinator ? ' · ' + b.coordinator : '');
  $('m-join').textContent = b.permit_join ? 'OPEN' : 'closed';
  $('m-join-card').className = 'card metric ' + (b.permit_join ? 'warn' : '');
  $('m-join-sub').textContent = b.permit_join ? 'new devices may join' : 'network locked';
  $('join-state').textContent = b.permit_join ? 'The network is open for joining.' : 'The network is closed.';
  var jt = $('join-toggle');
  setButtonIcon(jt, b.permit_join ? 'lock' : 'join', b.permit_join ? 'Close network' : 'Open network (254 s)');
  jt.className = 'btn cmd needs-unlock' + (b.permit_join ? ' danger' : ' primary');
  jt.dataset.open = b.permit_join ? '1' : '';

  // presence, but only once somebody has been set up for it
  var pres = st.presence || {};
  var watched = (pres.people || []).filter(function (p) { return p.enabled !== false; });
  var card = $('m-home-card');
  card.hidden = !watched.length;
  if (watched.length) {
    var inside = watched.filter(function (p) { return p.home; });
    var wifi = pres.wifi || {};
    if (!wifi.enabled) {
      $('m-home').textContent = 'not asking';
      card.className = 'card metric';
      $('m-home-sub').textContent = 'switch the controller on under Control \u2192 Presence';
    } else if (wifi.ok === false) {
      $('m-home').textContent = 'unknown';
      card.className = 'card metric warn';
      $('m-home-sub').textContent = 'the controller is not answering';
    } else {
      $('m-home').textContent = inside.length === watched.length ? 'everyone'
        : (inside.length ? inside.length + ' of ' + watched.length : 'nobody');
      card.className = 'card metric ' + (inside.length ? 'ok' : '');
      $('m-home-sub').textContent = (inside.length ? '' : 'the house is empty')
        + (wifi.checked ? (inside.length ? '' : ' \u00b7 ') + 'asked ' + ago(wifi.checked) : '');
    }
    // one chip per person, so a glance answers "who", not just "how many"
    var who = $('m-home-who'); who.innerHTML = '';
    if (wifi.enabled && wifi.ok !== false) {
      watched.forEach(function (p) {
        var chip = el('span', 'whochip' + (p.home ? ' in' : ''));
        chip.appendChild(el('span', 'dot'));
        chip.appendChild(document.createTextNode(p.name));
        chip.title = p.name + ' is ' + (p.home ? 'in' : 'out')
          + (p.device ? ', seen as ' + p.device : '')
          + (p.last_seen ? ', last on the network ' + ago(p.last_seen) : ', never seen')
          + (p.leaving_in ? ' \u2014 counts as out in ' + runtimeText(p.leaving_in) : '');
        who.appendChild(chip);
      });
    }
  }
}
// The per-tab work: only the visible tab is painted on a tick; a tab that
// was hidden while state changed is painted the moment it is shown. With a
// few dozen devices that is the difference between a tick costing tens of
// milliseconds and a couple of hundred - and every click waits for a tick.
var TAB_STALE = {};
var SIGS = {};
function sigChanged(key, parts) {
  var sig; try { sig = JSON.stringify(parts); } catch (e) { sig = String(Math.random()); }
  if (SIGS[key] === sig) return false;
  SIGS[key] = sig; return true;
}
// editors that reset their own cache (after a save) must repaint next time
function forgetSig(key) { delete SIGS[key]; }
// While somebody is using a control - a slider held, a dropdown open, a
// cursor in a field - the cards must not be rebuilt under them: a rebuild
// closes an open <select>, throws away what was typed and moves the tile.
// Repainting waits until they let go, and catches up straight after.
var DRAGGING = false;
var FOCUS_AT = 0, FOCUS_EL = null;
document.addEventListener('focusin', function (e) { FOCUS_AT = Date.now(); FOCUS_EL = e.target; });
function interacting() {
  if (DRAGGING) return true;
  var a = document.activeElement;
  if (!a || a === document.body) return false;
  // a field left with the cursor in it must not freeze the page for good:
  // fifteen seconds is a pause for typing, not a state
  if (a === FOCUS_EL && Date.now() - FOCUS_AT > 15000) return false;
  var tag = (a.tagName || '').toLowerCase();
  if (tag === 'select' || tag === 'textarea') return true;
  if (tag === 'input') return !/^(checkbox|radio|button|submit|reset|range)$/.test(a.type || 'text');
  return !!a.isContentEditable;
}
// A dropdown keeps the focus after a choice is made, and a slider after it is
// let go - which would keep the repaint paused until something else is
// clicked. Once the choice is made there is nothing left to protect.
document.addEventListener('change', function (e) {
  var t = e.target;
  if (t && (t.tagName === 'SELECT' || (t.tagName === 'INPUT' && /^(range|checkbox|radio)$/.test(t.type)))) setTimeout(function () { if (document.activeElement === t) t.blur(); }, 50);
});
document.addEventListener('focusout', function () {
  // whatever changed while they were busy is painted a moment later
  setTimeout(function () { if (!interacting() && STATE.status) renderTab(STATE.tab, STATE.status); }, 60);
});
function holdRepaint(node) {
  node.addEventListener('pointerdown', function () { DRAGGING = true; });
  node.addEventListener('focus', function () { DRAGGING = true; });
  var release = function () { setTimeout(function () { DRAGGING = false; }, 400); };
  node.addEventListener('pointerup', release);
  node.addEventListener('pointercancel', release);
  node.addEventListener('blur', release);
}
// A Save is only ever allowed to write what the editor is actually holding.
// Before its first load the store's rows are null, and "null or empty list"
// used to become an empty list on the wire - which erased everything it was
// meant to save. One line, checked in every editor.
function rowsToSave(store, what) {
  if (!store || store.rows === null || store.rows === undefined) {
    // said out loud rather than thrown into the void: the PIN dialog closes
    // and nothing is written
    toast('The ' + what + ' have not finished loading \u2014 nothing was saved.', false);
    throw new Error('not loaded');
  }
  return store.rows;
}
// ---- what is waiting for somebody to say yes ---------------------------------
// A press that asks Duo does not act on its own, and until now the only place
// it could be seen was the log, after the fact. Here it is while it is still
// happening: what it would do, who asked, which device was rung, how long it
// has left - and a way to call it off, which is not undoing anything, since
// nothing has happened yet.
var APPROVALS = {waiting: [], recent: [], at: 0, timer: null};
function approvalIcon(state) {
  return {waiting: ICON.wait || '\u23f3', done: '\u2705', told: '\ud83d\udcac',
          asked: '\ud83d\udc41\ufe0f', refused: '\u26d4',
          stopped: '\u270b', expired: '\u231b'}[state] || '\u2022';
}
// what a press had to get past, with the mark the rest of the page uses
function factorWords(factor, device) {
  var word = String(factor || '');
  if (word === 'Duo') return '\ud83d\udee1\ufe0f Duo' + (device ? ' \u00b7 ' + device : '');
  if (word === 'a code') return '\ud83d\udd22 a code';
  return '\u2014 ' + word.replace(/^none ?/, '').replace(/[()]/g, '');
}
function approvalWords(state) {
  return {waiting: 'waiting', done: 'done', told: 'told you', asked: 'asked, changed nothing',
          refused: 'refused', stopped: 'called off here', expired: 'nobody answered'}[state] || state;
}
// Searched in the database and paged here, exactly as the events are: a house
// that has been running a year has more presses than a browser wants handed to
// it, and the answer to "when did that address last try" is in the old ones.
var PRESSES = {page: 1, perPage: 50, text: '', state: '', matched: 0, total: 0};
function paintPressesBar() {
  var bar = $('presses-filter'); if (!bar || bar.childNodes.length) return;
  var sel = el('select'); sel.className = 'evf';
  fillSelect(sel, [['', '\ud83d\udd3d every ending'],
                   ['done', '\u2705 done'], ['told', '\ud83d\udcac told you'],
                   ['asked', '\ud83d\udc41\ufe0f asked only'], ['refused', '\u26d4 refused'],
                   ['waiting', '\u23f3 waiting'], ['stopped', '\u270b called off'],
                   ['expired', '\u231b no answer']], '');
  sel.onchange = function () { PRESSES.state = sel.value; PRESSES.page = 1; loadApprovals(true); };
  bar.appendChild(sel);
  var tx = el('input'); tx.type = 'search'; tx.className = 'evf'; tx.style.minWidth = '220px';
  tx.placeholder = 'search link, address, what checked it\u2026';
  tx.title = 'Searches every press ever recorded, not just this page: case does not matter and '
    + 'several words all have to appear.';
  tx.oninput = function () {
    PRESSES.text = tx.value; PRESSES.page = 1;
    clearTimeout(PRESSES.timer);
    PRESSES.timer = setTimeout(function () { loadApprovals(true); }, 200);
  };
  bar.appendChild(tx);
  var pp = el('select'); pp.className = 'evf';
  fillSelect(pp, [25, 50, 100, 200].map(function (n) { return [String(n), '\ud83d\udcc4 ' + n + ' per page']; }),
             String(PRESSES.perPage));
  pp.onchange = function () { PRESSES.perPage = parseInt(pp.value, 10) || 50; PRESSES.page = 1; paintApprovals(); };
  bar.appendChild(pp);
  var cnt = el('span', 'muted small'); cnt.id = 'presses-count'; cnt.style.alignSelf = 'center';
  bar.appendChild(cnt);
}
function paintPressesPager(pages) {
  var pager = $('presses-pager'); if (!pager) return;
  pager.innerHTML = '';
  if (pages <= 1) return;
  var go = function (n) { PRESSES.page = Math.max(1, Math.min(pages, n)); paintApprovals(); };
  var mk = function (label, n, key) {
    var b = el('button', 'btn cmd small pg'); b.type = 'button';
    b.classList.remove('needs-unlock');
    if (key) setButtonIcon(b, key, label); else b.textContent = label;
    b.disabled = n === PRESSES.page || n < 1 || n > pages;
    b.onclick = function () { go(n); };
    return b;
  };
  pager.appendChild(mk('', 1, 'first'));
  pager.appendChild(mk('', PRESSES.page - 1, 'prev'));
  pager.appendChild(el('span', 'muted small', ' page ' + PRESSES.page + ' of ' + pages + ' '));
  pager.appendChild(mk('', PRESSES.page + 1, 'next'));
  pager.appendChild(mk('', pages, 'last'));
}
function loadApprovals(quiet) {
  api('approvals&limit=' + (PRESSES.perPage * 10)
      + (PRESSES.text ? '&q=' + encodeURIComponent(PRESSES.text) : '')
      + (PRESSES.state ? '&state=' + encodeURIComponent(PRESSES.state) : '')).then(function (r) {
    PRESSES.matched = r.matched || 0;
    PRESSES.total = r.total || 0;
    APPROVALS.waiting = r.waiting || [];
    APPROVALS.recent = r.recent || [];
    APPROVALS.at = Date.now();
    paintApprovals();
  }, function () { if (!quiet) $('approvals-note').textContent = 'could not ask the daemon'; });
  api('blocked&limit=' + (BLOCKSTORY.perPage * 8)
      + (BLOCKSTORY.text ? '&q=' + encodeURIComponent(BLOCKSTORY.text) : '')).then(function (r) {
    BLOCKSTORY.matched = r.matched || 0;
    BLOCKSTORY.total = r.total || 0;
    APPROVALS.blocked = r.blocked || [];
    APPROVALS.counters = r.counters || [];
    APPROVALS.blockedPast = r.history || [];
    APPROVALS.blocklistOn = r.on !== false;
    // a router that cannot be reached says so once, here, rather than only in
    // the tooltip of every line
    var sick = (r.blocked || []).map(function (x) { return x.router_trouble; })
      .filter(Boolean)[0];
    $('blocked-note').textContent = r.on === false ? 'the blacklist is off'
      : ('blocking is set to ' + (r.mode || '?')
         + (sick ? ' \u00b7 the router could not be read: ' + sick : ''));
    paintBlocked();
    paintWatched();
  }, function (e) {
    if (/locked/.test((e && e.message) || '')) { APPROVALS.locked = true; paintApprovalsLocked(); }
  });
}
function paintApprovalsLocked() {
  var live = $('approvals-live'), host = $('blocked-list');
  var words = 'Unlock editing to see this. Who pressed what, and who is being kept out, is the shape '
    + 'of the house\u2019s own guard \u2014 it asks for the PIN however the rest of the view is set.';
  if (live) {
    live.innerHTML = '';
    live.appendChild(el('p', 'note reason', words));
    var open = cmdButton('Unlock editing', 'unlock', 'small primary');
    open.classList.remove('needs-unlock');
    open.onclick = function () { unlockFlow(function () { APPROVALS.locked = false; loadApprovals(true); }); };
    var bar = el('div', 'btnrow');
    bar.appendChild(open);
    live.appendChild(bar);
  }
  if (host) host.innerHTML = '';
  var past = $('blocked-past'); if (past) past.innerHTML = '';
  var body = $('approvals-past') && $('approvals-past').querySelector('tbody');
  if (body) body.innerHTML = '';
  $('approvals-note').textContent = 'locked';
}
function renderApprovals() {
  paintApprovals();
  if (Date.now() - APPROVALS.at > 2000) loadApprovals(true);
  clearInterval(APPROVALS.timer);
  // the countdown has to move on its own, and a press may be approved by
  // somebody else while this is open
  APPROVALS.timer = setInterval(function () {
    if (STATE.tab !== 'approvals') { clearInterval(APPROVALS.timer); return; }
    if (userHolding()) return;          // a list is open, or text is being copied
    paintApprovals();
    if (APPROVALS.waiting.length || Date.now() - APPROVALS.at > 5000) loadApprovals(true);
  }, 1000);
}
function paintApprovals() {
  var host = $('approvals-live'); if (!host) return;
  var gone = Math.floor((Date.now() - APPROVALS.at) / 1000);
  // A dropdown held open and a run of text being copied are taken away by a
  // repaint, and this one repaints every second of its own accord - the one
  // place on the page where that was still true.
  if (userHolding()) { APPROVALS.held = true; return; }
  // The clock has to move every second; the rows themselves change only when
  // a press starts or ends. Rebuilding all of it once a second took away
  // whatever was selected in the history below, every second.
  var shape = APPROVALS.waiting.map(function (x) { return x.ticket + x.state; }).join(',')
    + '|' + APPROVALS.recent.map(function (x) { return x.ticket + x.state; }).join(',')
    + '|' + PRESSES.page + '|' + PRESSES.perPage + '|' + PRESSES.text + '|' + PRESSES.state;
  if (shape === APPROVALS.shape && !APPROVALS.held) {
    Array.prototype.forEach.call(host.querySelectorAll('.appr-left'), function (clock) {
      var one = APPROVALS.waiting.filter(function (x) { return x.ticket === clock.dataset.ticket; })[0];
      if (!one) return;
      var left = Math.max(0, (one.left || 0) - gone);
      clock.textContent = left + ' s';
      clock.classList.toggle('soon', left <= 10);
    });
    return;
  }
  APPROVALS.shape = shape;
  APPROVALS.held = false;
  host.innerHTML = '';
  if (!APPROVALS.waiting.length) {
    host.appendChild(el('p', 'btnhelp', 'Nothing is waiting.'));
  }
  APPROVALS.waiting.forEach(function (one) {
    var left = Math.max(0, (one.left || 0) - gone);
    var row = el('div', 'appr-row');
    row.appendChild(el('span', 'appr-icon', approvalIcon('waiting')));
    var what = el('div', 'appr-what');
    what.appendChild(el('span', 'appr-link', one.link || 'a link'));
    what.appendChild(el('span', 'muted small', 'would ' + (one.what || 'act')
      + ' \u00b7 asked from ' + (one.who || 'somewhere')
      + (one.device && one.device !== 'auto' ? ' \u00b7 pushed to ' + one.device : '')));
    row.appendChild(what);
    var clock = el('span', 'appr-left' + (left <= 10 ? ' soon' : ''), left + ' s');
    clock.dataset.ticket = one.ticket;
    clock.title = 'How long before the daemon gives up waiting';
    row.appendChild(clock);
    var stop = iconButton('cancel', 'Call this one off. Nothing has happened yet, and an approval '
      + 'arriving afterwards will do nothing');
    stop.setAttribute('aria-label', 'call this one off');
    stop.classList.add('danger');
    stop.onclick = function () { stopApproval(one.ticket, one.link); };
    row.appendChild(stop);
    host.appendChild(row);
  });
  paintPressesBar();
  var body = $('approvals-past') && $('approvals-past').querySelector('tbody');
  if (!body) return;
  // the values somebody would want to carry away: the address that pressed it
  // and the device that was rung
  body.innerHTML = '';
  var all = APPROVALS.recent || [];
  var pages = Math.max(1, Math.ceil(all.length / PRESSES.perPage));
  if (PRESSES.page > pages) PRESSES.page = pages;
  var from = (PRESSES.page - 1) * PRESSES.perPage;
  var shown = all.slice(from, from + PRESSES.perPage);
  var count = $('presses-count');
  if (count) {
    count.textContent = (PRESSES.text || PRESSES.state)
      ? PRESSES.matched + ' of ' + PRESSES.total + ' recorded'
        + (PRESSES.matched > all.length ? ' \u00b7 newest ' + all.length + ' shown' : '')
        + (shown.length ? ' \u00b7 ' + (from + 1) + '\u2013' + (from + shown.length) : '')
      : all.length + ' of ' + PRESSES.total + (shown.length ? ' \u00b7 ' + (from + 1) + '\u2013' + (from + shown.length) : '');
  }
  paintPressesPager(pages);
  shown.forEach(function (one) {
    var tr = el('tr');
    tr.appendChild(el('td', 'nowrap', one.ended ? stamp(one.ended) : ''));
    tr.appendChild(el('td', 'appr-icon', approvalIcon(one.state)));
    // the same refusal arriving again and again is one line saying how many:
    // a browser asked once will often ask several times by itself
    tr.appendChild(el('td', '', (one.link || '')
      + ((one.times || 1) > 1 ? ' \u00d7' + one.times : '')));
    tr.appendChild(el('td', 'muted', one.what || ''));
    tr.appendChild(el('td', 'muted nowrap', one.way || ''));
    tr.appendChild(el('td', 'nowrap', factorWords(one.factor, one.device)));
    tr.appendChild(el('td', 'muted', one.who || ''));
    tr.appendChild(el('td', '', approvalWords(one.state) + (one.message ? ' \u2014 ' + one.message : '')));
    body.appendChild(tr);
  });
  var none = $('approvals-empty');
  if (none) none.hidden = !!all.length;
}
// ---- the addresses that may not talk to this --------------------------------
// What each address has on its account. It is counted whether or not anybody
// is looking, and was nowhere to be seen: letting somebody back in while the
// weight against them still stood meant the next thing they did put them
// straight back on the list, and there was no way to tell why.
function paintWatched() {
  var host = $('blocked-watch'); if (!host) return;
  var rows = (APPROVALS.counters || []).filter(function (x) { return !x.blocked; });
  host.innerHTML = '';
  if (!rows.length) return;
  host.appendChild(el('div', 'set-head', 'On their way to being kept out'));
  rows.forEach(function (one) {
    var row = el('div', 'appr-row');
    row.appendChild(el('span', 'appr-icon', '\ud83d\udc41\ufe0f'));
    var what = el('div', 'appr-what');
    what.appendChild(el('span', 'appr-link', one.ip));
    what.appendChild(el('span', 'muted small', one.kinds.map(function (k) {
      return k.n + '\u00d7 ' + k.words;
    }).join(', ') + ' \u00b7 forgotten in ' + Math.ceil((one.runs_out || 0) / 60) + ' min'));
    row.appendChild(what);
    var weight = el('span', 'appr-left' + (one.score >= one.bar * 0.7 ? ' soon' : ''),
                    one.score + ' of ' + one.bar);
    weight.title = 'What it has on its account, and what earns a block. Nothing is kept longer than '
      + 'the span in Settings';
    row.appendChild(weight);
    var off = iconButton('cancel', 'Forget what this address has been doing');
    off.onclick = function () {
      blockedChange({clear: one.ip}, 'Forget what ' + one.ip + ' has been doing',
        'Its score goes back to nothing. Whatever it does next starts again from there.');
    };
    row.appendChild(off);
    host.appendChild(row);
  });
}
function paintBlocked(force) {
  var host = $('blocked-list'); if (!host) return;
  // While a list is open or text is being held, a repaint would take it away
  // - except when something was just asked for and answered, which is the one
  // moment the person is waiting to see happen.
  if (!force && userHolding()) return;
  var rows = APPROVALS.blocked || [];
  host.innerHTML = '';
  if (APPROVALS.blocklistOn === false) {
    host.appendChild(el('p', 'note reason', 'The blacklist is switched off. Nothing is kept out, and '
      + 'nothing of this is left on the router. The ' + rows.length + ' address(es) below are kept as '
      + 'they are, and putting it back on in Settings fills the router again from them.'));
  }
  if (!rows.length) { host.appendChild(el('p', 'btnhelp', 'Nobody is blocked.')); }
  rows.forEach(function (one) {
    var row = el('div', 'appr-row');
    if (one.spared) row.classList.add('spared');
    row.appendChild(el('span', 'appr-icon', one.spared ? '\ud83d\udd4a\ufe0f'
                                            : (one.auto ? '\ud83e\udd16' : '\u270b')));
    // whether the router is carrying it too, as the last look found it - and
    // a change here reaches the router in a millisecond, so that is very
    // nearly now
    if (one.router) {
      var mark = el('span', 'appr-icon appr-router' + (one.router === 'yes' ? ' on' : ' off'),
                    one.router === 'yes' ? '\ud83d\udee1\ufe0f' : '\u26a0\ufe0f');
      mark.title = (one.router === 'yes'
        ? 'the router is keeping this one out as well'
        : 'the router is not carrying this one')
        + (one.router_at ? ' \u2014 as it stood ' + ago(one.router_at)
           : ' \u2014 the router has not been looked at yet')
        + (one.router_trouble ? '. The last look failed: ' + one.router_trouble : '');
      if (one.router_trouble) mark.classList.add('sick');
      row.appendChild(mark);
    }
    var what = el('div', 'appr-what');
    what.appendChild(el('span', 'appr-link', one.ip));
    // an older line still carries the daemon's shorthand; the words for it
    // are the same words, so it reads the same either way
    var why = String(one.why || '').replace(/\b(bad-secret|bad-code|shut-road|too-many|locked-read|flood)\b/g,
      function (word) {
        return {'bad-secret': 'a secret that opens nothing', 'bad-code': 'a code that was not right',
                'shut-road': 'a road the links are not set to accept',
                'too-many': 'more tries than the minute allows',
                'locked-read': 'a read that asks for the PIN',
                'flood': 'more asking than a person does'}[word] || word;
      });
    what.appendChild(el('span', 'muted small', (one.spared
        ? 'let through anyway \u2014 ' + one.spared + ' is never kept out \u00b7 '
        : '') + why
      + ' \u00b7 since ' + stamp(one.since)
      + (one.hits ? ' \u00b7 turned away ' + one.hits + '\u00d7' : '')
      + (one.by ? ' \u00b7 by ' + one.by : '')));
    row.appendChild(what);
    row.appendChild(el('span', 'appr-left' + (one.forever && !one.spared ? ' soon' : ''),
      one.spared ? 'let through' : (one.forever ? 'until taken off' : Math.ceil(one.left / 60) + ' min')));
    var off = iconButton('cancel', 'Take this address off the list');
    off.onclick = function () { blockedChange({remove: one.ip}, 'Let ' + one.ip + ' back in',
      'The API answers it again from the moment this is done. It stays in the history below.'); };
    row.appendChild(off);
    host.appendChild(row);
  });
  // every address that was ever kept out, long after it was let back in
  var past = $('blocked-past'); if (!past) return;
  var old = APPROVALS.blockedPast || [];
  past.innerHTML = '';
  if (!old.length) return;
  past.appendChild(el('div', 'set-head', 'Everything that has happened to an address'));
  past.appendChild(blockedStoryBar());
  var table = el('table');
  table.innerHTML = '<thead><tr><th>When</th><th></th><th>Address</th>'
    + '<th>Why</th><th>By</th></tr></thead>';
  var body = el('tbody');
  var pages = Math.max(1, Math.ceil(old.length / BLOCKSTORY.perPage));
  if (BLOCKSTORY.page > pages) BLOCKSTORY.page = pages;
  var from = (BLOCKSTORY.page - 1) * BLOCKSTORY.perPage;
  var shown = old.slice(from, from + BLOCKSTORY.perPage);
  var count = $('blockstory-count');
  if (count) {
    count.textContent = (BLOCKSTORY.text
      ? BLOCKSTORY.matched + ' of ' + BLOCKSTORY.total + ' recorded'
      : old.length + ' of ' + BLOCKSTORY.total)
      + (shown.length ? ' \u00b7 ' + (from + 1) + '\u2013' + (from + shown.length) : '');
  }
  shown.forEach(function (one) {
    var tr = el('tr');
    tr.appendChild(el('td', 'nowrap', stamp(one.ts)));
    tr.appendChild(el('td', 'nowrap', one.what === 'blocked' ? '\u26d4 blocked' : '\u2705 let back in'));
    tr.appendChild(el('td', '', one.ip));
    tr.appendChild(el('td', 'muted', String(one.why || '').replace(
      /\b(bad-secret|bad-code|shut-road|too-many|locked-read|flood)\b/g, function (word) {
        return {'bad-secret': 'a secret that opens nothing', 'bad-code': 'a code that was not right',
                'shut-road': 'a road the links are not set to accept',
                'too-many': 'more tries than the minute allows',
                'locked-read': 'a read that asks for the PIN',
                'flood': 'more asking than a person does'}[word] || word;
      })));
    tr.appendChild(el('td', 'nowrap', (one.auto ? '\ud83e\udd16 by itself' : '\u270b by hand')
      + (one.by ? ' \u00b7 ' + one.by : '')));
    body.appendChild(tr);
  });
  table.appendChild(body);
  table.id = 'blocked-history';
  past.appendChild(table);
  var pager = el('div', 'pager'); pager.id = 'blockstory-pager';
  past.appendChild(pager);
  if (pages > 1) {
    var go = function (n) { BLOCKSTORY.page = Math.max(1, Math.min(pages, n)); paintBlocked(true); };
    var mk = function (n, key) {
      var b = el('button', 'btn cmd small pg'); b.type = 'button';
      b.classList.remove('needs-unlock');
      setButtonIcon(b, key, '');
      b.disabled = n === BLOCKSTORY.page || n < 1 || n > pages;
      b.onclick = function () { go(n); };
      return b;
    };
    pager.appendChild(mk(1, 'first'));
    pager.appendChild(mk(BLOCKSTORY.page - 1, 'prev'));
    pager.appendChild(el('span', 'muted small', ' page ' + BLOCKSTORY.page + ' of ' + pages + ' '));
    pager.appendChild(mk(BLOCKSTORY.page + 1, 'next'));
    pager.appendChild(mk(pages, 'last'));
  }
}
var BLOCKSTORY = {page: 1, perPage: 50, text: '', matched: 0, total: 0};
function blockedStoryBar() {
  var bar = el('div', 'btnrow'); bar.style.cssText = 'flex-wrap:wrap;margin:6px 0 10px;gap:8px';
  var tx = el('input'); tx.type = 'search'; tx.className = 'evf'; tx.style.minWidth = '220px';
  tx.placeholder = 'search an address, a reason, a name\u2026';
  tx.value = BLOCKSTORY.text;
  tx.title = 'Searches everything ever recorded about an address, not just this page.';
  tx.oninput = function () {
    BLOCKSTORY.text = tx.value; BLOCKSTORY.page = 1;
    clearTimeout(BLOCKSTORY.timer);
    BLOCKSTORY.timer = setTimeout(function () { loadApprovals(true); }, 200);
  };
  bar.appendChild(tx);
  var pp = el('select'); pp.className = 'evf';
  fillSelect(pp, [25, 50, 100, 200].map(function (n) { return [String(n), '\ud83d\udcc4 ' + n + ' per page']; }),
             String(BLOCKSTORY.perPage));
  pp.onchange = function () { BLOCKSTORY.perPage = parseInt(pp.value, 10) || 50; BLOCKSTORY.page = 1; paintBlocked(true); };
  bar.appendChild(pp);
  var cnt = el('span', 'muted small'); cnt.id = 'blockstory-count'; cnt.style.alignSelf = 'center';
  bar.appendChild(cnt);
  return bar;
}
function blockedChange(body, title, why) {
  withPin(title, why, function (pin) {
    return post('blocked', Object.assign({pin: pin}, body)).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not');
      // The line goes as soon as the daemon says it is off the list, rather
      // than waiting for the next fetch to bring a list without it: a fetch
      // that is slow, or refused, or lands while something is being held,
      // left the line sitting there as though nothing had happened.
      if (body.clear) {
        APPROVALS.counters = body.all ? [] : (APPROVALS.counters || []).filter(function (x) {
          return x.ip !== body.clear;
        });
        paintWatched();
      }
      if (body.remove) {
        APPROVALS.blocked = (APPROVALS.blocked || []).filter(function (x) {
          return body.all ? false : x.ip !== body.remove;
        });
        paintBlocked(true);
      }
      loadApprovals(true);
      return r.message;
    });
  }, true);
}
function stopApproval(ticket, name) {
  withPin('Call off the press on \u201c' + (name || 'this link') + '\u201d',
    'Nothing has happened yet. This tells the press that nobody is going to answer, so an approval '
    + 'arriving afterwards does nothing.',
    function (pin) {
      return post('approvals-stop', ticket ? {pin: pin, ticket: ticket} : {pin: pin, all: true})
        .then(function (r) {
          if (!r.ok) throw new Error(r.error || 'could not');
          loadApprovals(true);
          return r.message;
        });
    });
}
function renderTab(name, st) {
  if (!st) return;
  // after everything is drawn, put each column header over the boxes it names
  setTimeout(markHeaderIndent, 0);
  LIST_CACHE.stamp = null; LIST_CACHE.devices = LIST_CACHE.targets = null;   // rebuilt once per pass
  if (interacting()) { TAB_STALE[name] = true; return; }   // wait until they are done
  // cards show "x min ago" texts: repaint at least once a minute even if nothing else moved
  var minute = Math.floor(Date.now() / 60000), unlocked = isUnlocked();
  var cardsSig = [st.devices, st.plugs, st.order, st.overview_layout, minute, unlocked, REARRANGE, LINKS, st.thresholds];
  try { renderTabInner(name, st, cardsSig, minute, unlocked); }
  catch (e) {
    // a bad record on one tab must not take the whole page down; say what and where
    var panel = $('tab-' + name);
    var box = panel && panel.querySelector('.tab-error');
    if (panel && !box) { box = el('div', 'note reason tab-error'); panel.insertBefore(box, panel.firstChild); }
    if (box) box.innerHTML = '<b>This tab could not be drawn:</b> ' + esc(e.message) + ' <span class="muted">(' + esc(String(e.stack || '').split('\n')[1] || '') + ')</span>';
    if (window.console) console.error('render ' + name, e);
  }
}
function renderTabInner(name, st, cardsSig, minute, unlocked) {
  var box = $('tab-' + name) && $('tab-' + name).querySelector('.tab-error'); if (box) box.remove();
  switch (name) {
    case 'overview':
      if (sigChanged('overview-cards', [cardsSig, OVERVIEW_LAYOUT_LOCAL])) { renderOverviewCustom(st); renderOverviewAddControl(st); }
      renderPower(st);                      // it keeps its own signature
      if (sigChanged('money', [st.money])) renderMoney(st);
      renderEnergy(st); break;
    case 'plugs': if (sigChanged('plugs-cards', [st.plugs, st.order, minute, unlocked, LINKS, ORDER.local])) renderSockets(st); break;
    case 'sensors': if (sigChanged('sensor-cards', cardsSig)) renderSensorsTab(st); break;
    case 'buttons': if (sigChanged('button-cards', cardsSig)) renderButtonsTab(st); break;
    case 'history': renderHistoryControls(true); break;
    case 'devices': if (sigChanged('devices-tab', [st.devices, minute, unlocked])) { renderDevices(st); renderMeshTree(st); } break;
    case 'heating': if (!HEAT.dirty && sigChanged('heating-tab', [st.heating, st.rooms, minute, unlocked])) renderHeating(st); break;
    case 'sms':
      renderSmsTab(st); break;
    case 'wifi': if (sigChanged('wifi-tab', [st.wifi_detail, st.wifi_config, st.people, minute, unlocked])) renderWifiTab(st); break;
    case 'all': if (sigChanged('all-values', [st.devices, st.plugs, minute])) renderAll(st); break;
    case 'approvals': renderApprovals(); break;
    case 'control':
      // Only the section on screen is built. The others are marked as owing a
      // repaint, and get one the moment they are shown - opening Control with
      // twenty rules and two dozen sockets should not build the lot.
      var sec = CONTROL_SEC || 'devices';
      var showing = function (which) {
        if (which === sec) return true;
        CONTROL_STALE[which] = true;
        return false;
      };
      // each editor repaints only when the slice of state it shows has changed
      var names = (st.devices || []).map(function (d) { return d.id + ':' + d.name + ':' + (d.kind || '') + ':' + d.has_action; });
      var targets = [(st.plugs || []).map(function (p) { return p.name + (p.monitor_only ? '!' : '') + (p.online ? '' : '?'); }), st.switch_targets, st.scenes, st.sequences];
      if (showing('devices')) if (sigChanged('plugcontrols', [st.plugs, minute, unlocked])) renderPlugControls(st);
      if (showing('automation')) if (!BINDINGS.dirty && !editorBusy('bindings-list') && sigChanged('bindings', [st.bindings, names, targets, st.binding_actions, unlocked, (st.editor_groups || {}).bindings])) renderBindings(st);
      if (showing('devices')) if (!MANAGED.dirty && !editorBusy('managed-list') && sigChanged('managed', [st.managed, unlocked, (st.editor_groups || {}).managed])) renderManaged(st);
      if (showing('devices')) if (sigChanged('gateways', [st.gateways, names, GATEWAYS.dirty])) renderGateways(st);
      if (showing('automation')) if (!ROOMS.dirty && sigChanged('rooms', [st.rooms, st.room_of, names, unlocked])) renderRooms(st);
      if (showing('system')) if (sigChanged('latency', [st.latency, TICK.lastMs])) renderLatency(st);
      if (showing('system')) if (sigChanged('acl', [st.managed, st.mqtt_for_plugs, Math.floor(Date.now() / 60000)])) renderAcl();
      if (showing('system')) if (sigChanged('sms', [st.sms, st.runtime_config, unlocked])) renderSms(st);
      if (showing('system')) if (sigChanged('outbox', [st.sms_outbox, unlocked])) renderOutbox(st);
      if (showing('system')) if (sigChanged('battery', [Math.floor(Date.now() / 300000), unlocked])) renderBattery();
      if (showing('automation')) if (sigChanged('whatif', [names, unlocked])) renderWhatIf(st);
      if (showing('system')) if (sigChanged('snaps', [Math.floor(Date.now() / 20000), unlocked])) { renderSnapshots(); renderRoutes(); }
      if (showing('automation')) if (!editorBusy('smscmd-list') && sigChanged('smscmd', [(st.sms || {}).commands, targets, unlocked, (st.editor_groups || {}).smscmd])) renderSmsCmd(st);
      // The scripts come with the section rather than with one card in it:
      // the verbs they bring are what the box offers on Ctrl+Space, and the
      // names they have are what a command or a link may point at. Asked for
      // outside every other condition, since a house with no commands yet
      // draws no command rows and used to ask for nothing.
      // Asked for once, whatever is on screen: the answer is small, the verbs
      // in it are what the box offers on Ctrl+Space, and the names in it are
      // what a command or a link may point at. Gated on the section being
      // shown, it never arrived in a house that had no commands drawn yet.
      if (!SCRIPTS.verbs.length) loadScripts();
      if (showing('automation')) if (!editorBusy('agroups-list') && sigChanged('agroups', [st.action_groups, targets, unlocked, (st.editor_groups || {}).agroups])) renderAGroups(st);
      if (showing('automation')) if (!editorBusy('sgroups-list') && sigChanged('sgroups', [st.sensor_groups, names, unlocked, (st.editor_groups || {}).sgroups])) renderSGroups(st);
      if (showing('automation')) if (!RULES.dirty && !editorBusy('rules-list') && sigChanged('rules', [st.rules, names, targets, unlocked, (st.editor_groups || {}).rules])) renderRules(st);
      if (showing('automation')) if (!editorBusy('taps-list')) renderTaps(st);
      if (showing('automation')) if (!editorBusy('scenes-list') && sigChanged('scenes', [st.scenes, targets, SCENES.rows === null, unlocked, (st.editor_groups || {}).scenes])) renderScenes(st);
      if (showing('automation')) if (!editorBusy('sequences-list') && sigChanged('sequences', [st.sequences, st.scenes, SEQUENCES.rows === null, unlocked, (st.editor_groups || {}).sequences])) renderSequences(st);
      if (showing('automation')) if (!editorBusy('schedules-list') && sigChanged('schedules', [st.schedule_count, targets, SCHEDULES.rows === null, unlocked, (st.editor_groups || {}).schedules])) renderSchedules(st);
      if (showing('presence')) if (sigChanged('wifi', [st.wifi_config, (st.presence || {}).wifi])) renderWifiConfig(st);
      if (showing('presence')) if (!PEOPLE.dirty && sigChanged('people', [st.people, (st.presence || {}).people])) { PEOPLE.rows = null; renderPeople(st); renderWifiClients(); }
      if (showing('presence')) if (!PTRIG.dirty && sigChanged('ptrig', [st.presence_triggers, st.people, st.plugs && st.plugs.length, unlocked, (st.editor_groups || {}).ptrig])) { PTRIG.rows = null; renderPtrig(st); }
      if (showing('system')) if (sigChanged('forget-list', [(st.devices || []).map(function (d) { return d.id + ':' + d.name; })])) renderForgetSelect(st);
      renderSessions();
      if (showing('system')) if (sigChanged('settings', [st.runtime_config])) renderSettings(st);
      if (showing('alerts')) if (sigChanged('energyreset', [(st.plugs || []).map(function (p) { return p.name; })])) renderEnergyReset(st);
      if (showing('alerts')) if (sigChanged('notify', [st.notify, names])) renderNotify(st);
      if (showing('alerts')) if (!MESSAGES.dirty && sigChanged('messages', [st.messages, unlocked, (st.editor_groups || {}).messages])) { MESSAGES.rows = null; renderMessages(st); }
      break;
  }
  TAB_STALE[name] = false;
  // the cards are drawn now, so every column header can be put over the boxes
  // it names - done here rather than where the folds are made, because the
  // editors fold their rows by several different routes
  setTimeout(markHeaderIndent, 0);
}

// A thermostatic valve gets its target on the card: minus, the number,
// plus, and the modes it names. Each press is one publish to <name>/set and
// the valve's own report paints the answer, the same path a binding takes.
function thermostatControls(d, st) {
  var targets = (st.switch_targets || []).filter(function (t) { return t.id === d.id && t.kind !== 'switch'; });
  var point = targets.filter(function (t) { return /heating_setpoint$/.test(t.key); })[0];
  var mode = targets.filter(function (t) { return t.key === 'system_mode' || t.key === 'preset'; })[0];
  if (!point && !mode) return null;
  // A head that belongs to a room is driven by that room, and its own preset
  // list (schedule / boost / away / complex - the firmware's own words) would
  // only fight it. So the card offers the room's vocabulary instead: the same
  // slider and the same five levels as the Heating tab.
  var map = st.room_of || {}, rid = map[d.id] || map[d.name];
  var room = rid ? (((st.heating || {}).rooms || []).filter(function (r) { return r.id === rid; })[0]) : null;
  if (room && room.heated !== false) return roomThermostat(d, st, room);
  var wrap = el('div', 'trv');
  // no room behind it: the head's own words are all there is, so say why
  var hint = el('div', 'muted small');
  hint.textContent = room ? 'This room is marked as not heated, so the head is on its own.'
    : 'Not in a room \u2014 these are the head\u2019s own presets. Put it in a room under Control \u2192 Automation \u2192 Rooms and it gets Comfort / Eco / Night / Off / Plan instead.';
  hint.style.flexBasis = '100%';
  wrap.appendChild(hint);
  function send(target, value) {
    withPin('Set ' + target.name, 'Sets it to ' + value + '. It takes effect when the valve next talks to the mesh.', function (pin) {
      return post('target-set', {target: target.value, do: 'set:' + value, pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'the valve did not take it');
        return r.message || 'Set';
      });
    });
  }
  if (point) {
    var now = isNum(point.state) ? point.state : null;
    var lo = isNum(point.min) ? point.min : 5, hi = isNum(point.max) ? point.max : 35;
    // the same slider the Heating cards use: it only speaks when let go
    var slider = el('input'); slider.type = 'range'; slider.className = 'heat-slider';
    slider.min = lo; slider.max = hi; slider.step = 0.5; slider.value = now === null ? lo : now;
    var shown = el('span', 'trv-value', now === null ? '\u2013' : fmt(now, 1) + ' \u00b0C');
    shown.title = 'The target this valve is holding';
    function paint(v) {
      slider.style.setProperty('--fill', ((v - lo) / Math.max(0.5, hi - lo)) * 100 + '%');
      shown.textContent = fmt(v, 1) + ' \u00b0C';
    }
    if (now !== null) paint(now);
    slider.disabled = now === null || !d.online;
    slider.oninput = function () { paint(parseFloat(slider.value)); };
    slider.onchange = function () { send(point, parseFloat(slider.value)); };
    slider.title = 'Drag to set the target; it is sent when you let go. Arrow keys step half a degree.';
    holdRepaint(slider);
    wrap.appendChild(el('span', 'lbl', 'Target'));
    wrap.appendChild(slider); wrap.appendChild(shown);
    // shut the valve: the mode if the head has one, else its lowest number
    var off = el('button', 'btn cmd small', ICON.shut + ' Close'); off.type = 'button';
    var offMode = mode && (mode.values || []).filter(function (v) { return String(v).toLowerCase() === 'off'; })[0];
    off.title = offMode ? 'Switch the head off - the valve shuts and stays shut until it is set again.'
                        : 'Set it to ' + lo + ' \u00b0C, the lowest the head takes: the valve shuts unless the room falls below that.';
    off.disabled = !d.online;
    off.onclick = function () {
      if (offMode) send(mode, offMode);
      else { slider.value = lo; paint(lo); send(point, lo); }
    };
    wrap.appendChild(off);
  }
  if (mode) {
    var sel = el('select', 'trv-mode');
    fillSelect(sel, (mode.values || []).map(function (v) { return [v, v]; }), mode.state);
    sel.disabled = !d.online;
    sel.onchange = function () { send(mode, sel.value); };
    wrap.appendChild(el('span', 'lbl', mode.key === 'preset' ? 'Preset' : 'Mode'));
    wrap.appendChild(sel);
  }
  return wrap;
}

// The valve's card when it belongs to a room: what the room is holding, the
// room's slider, and the room's presets - one vocabulary in both places.
function roomThermostat(d, st, room) {
  var wrap = el('div', 'trv trv-room');
  var head = el('div', 'trv-line');
  head.appendChild(el('span', 'lbl', ICON.heat + ' ' + room.name));
  head.appendChild(el('span', 'muted small', room.why === 'by hand'
    ? 'set by hand' + (room.hold_until ? ' until ' + new Date(room.hold_until * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}) : '')
    : (room.wanted_c === null || room.wanted_c === undefined ? 'not controlled' : 'holding the ' + room.why + ' temperature')));
  wrap.appendChild(head);
  var line = el('div', 'trv-line');
  var lo = 5, hi = 30;
  var slider = el('input'); slider.type = 'range'; slider.className = 'heat-slider';
  slider.min = lo; slider.max = hi; slider.step = 0.5;
  slider.value = isNum(room.wanted_c) ? room.wanted_c : 21;
  var shown = el('span', 'trv-value', isNum(room.wanted_c) ? fmt(room.wanted_c, 1) + ' \u00b0C' : '\u2013');
  function paint(v) { slider.style.setProperty('--fill', ((v - lo) / (hi - lo)) * 100 + '%'); shown.textContent = fmt(v, 1) + ' \u00b0C'; }
  paint(parseFloat(slider.value));
  slider.title = 'Sets the room \u2014 every valve in it follows. Sent when you let go.';
  holdRepaint(slider);
  slider.oninput = function () { paint(parseFloat(slider.value)); };
  slider.onchange = function () {
    withPin('Set ' + room.name + ' by hand', 'The valves in the room follow at once.', function (pin) {
      return post('target-set', {target: 'heat:temp:' + room.id, do: 'set:' + slider.value, pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not'); forgetSig('heating-tab'); return room.name + ' set by hand';
      });
    });
  };
  line.appendChild(slider); line.appendChild(shown);
  wrap.appendChild(line);
  // one dropdown rather than a row of little buttons: on a device card there
  // is no room for five, and the level is a single choice anyway
  var pick = el('select', 'trv-mode');
  var opts = [['plan', ICON.plan + ' follow the plan'], ['comfort', ICON.comfort + ' Comfort'],
              ['eco', ICON.eco + ' Eco'], ['night', ICON.night + ' Night'], ['off', ICON.shut + ' Off'],
              ['manual', '\u270b by hand on the head']];
  if (room.why === 'by hand') opts = [['', '\u270b set by hand']].concat(opts);
  fillSelect(pick, opts, room.why === 'by hand' ? '' : (room.mode || 'plan'));
  pick.title = 'What the room holds: its plan, one of its three temperatures, off, or \u201cby hand on the head\u201d \u2014 which leaves the valve entirely alone, so whatever you turn it to on the wall stays.';
  pick.onchange = function () {
    if (!pick.value) return;
    var level = pick.value;
    withPin(room.name + ': ' + level, 'The valves in the room follow at once.', function (pin) {
      return post('target-set', {target: 'heat:room:' + room.id, do: 'set:' + level, pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not'); forgetSig('heating-tab'); return room.name + ' \u2192 ' + level;
      });
    });
  };
  var pickLine = el('div', 'trv-line');
  pickLine.title = 'Off shuts the valves in this room. The head is held in manual, so its own programme cannot override the room; the room\u2019s plan lives under Heating.';
  pickLine.appendChild(el('span', 'lbl', 'Level'));
  pickLine.appendChild(pick);
  wrap.appendChild(pickLine);
  return wrap;
}

// One device (sensor, button, router - anything that isn't a plug) as a card.
// Shared by the Sensors tab, the Buttons tab, and a curated Overview.
function buildDeviceCard(d, st) {
    var stale = !d.online;
    var card = el('div', 'card dev ' + d.level + (stale ? ' stale' : ''));
    var head = el('div', 'head');
    var nm = el('div');
    nm.appendChild(el('div', 'name', d.name));
    nm.appendChild(el('div', 'model', [[d.vendor, d.model].filter(Boolean).join(' '), d.description, gatewayFirmware(d)].filter(Boolean).join(' · ')));
    head.appendChild(nm);
    head.appendChild(el('span', 'spacer'));
    head.appendChild(el('span', 'tag ' + (d.availability === 'offline' ? 'crit' : (stale ? 'warn' : (d.level === 'ok' ? 'ok' : d.level))),
                        d.availability === 'offline' ? 'offline' : (stale ? 'silent' : (d.level === 'ok' ? 'online' : d.level))));
    if (linkAllowed(d)) {
      // the way to the charts: a small icon at the top right, shown on hover only - never the name, never the card
      var hist = el('button', 'dev-hist'); hist.type = 'button'; hist.innerHTML = iconMarkup('chart', 15);
      hist.title = 'History and charts of ' + d.name;
      hist.onclick = function (e) { e.stopPropagation(); if (Date.now() - ORDER.justDropped < 500) return; STATE.hDevice = d.id; showTab('history'); };
      head.appendChild(hist);
    }
    card.appendChild(head);
    var readings = el('div', 'readings');
    var addGatewayReadings = function () {
      gatewayReadings(d).forEach(function (g) {
        var r = el('div', 'reading small');
        var v = el('div', 'v');
        v.innerHTML = esc(g.text) + (g.unit ? '<span class="unit">' + esc(g.unit) + '</span>' : '');
        r.appendChild(v);
        r.appendChild(el('div', 'l', g.label));
        readings.appendChild(r);
      });
    };
    if (d.kind === 'Coordinator') {
      // The coordinator is the mesh: it has no link quality and no parent, so
      // what it can say about itself is what its gateway entry reads out.
      var run = el('div', 'reading');
      var rvc = el('div', 'v', d.online ? 'holding the network' : 'silent');
      rvc.style.color = d.online ? 'var(--ok)' : 'var(--warn)';
      run.appendChild(rvc);
      run.appendChild(el('div', 'l', 'zigbee coordinator'));
      readings.appendChild(run);
      addGatewayReadings();
      if (readings.children.length < 2) {
        readings.appendChild(el('span', 'muted small',
          'Set up a gateway entry for it on Control to read its own health'));
      }
    } else if (d.kind === 'Router') {
      // What matters on a range extender: that it routes, how good its link
      // is, and how long it has been holding the mesh together.
      var routing = el('div', 'reading');
      var rv = el('div', 'v', d.availability === 'offline' ? 'down' : 'routing');
      rv.style.color = d.availability === 'offline' ? 'var(--crit)' : 'var(--ok)';
      routing.appendChild(rv);
      routing.appendChild(el('div', 'l', 'mains-powered mesh router'));
      readings.appendChild(routing);
      var link = el('div', 'reading');
      link.appendChild(el('div', 'v', isNum(d.linkquality) ? fmt(d.linkquality, 0) : '—'));
      link.appendChild(el('div', 'l', 'link quality'));
      readings.appendChild(link);
      var since = el('div', 'reading small');
      since.appendChild(el('div', 'v', d.first_seen ? stamp(d.first_seen).slice(0, 10) : '—'));
      since.appendChild(el('div', 'l', 'in the network since'));
      readings.appendChild(since);
      // what the box itself reports over its own network API, when one is set
      // up for it: a router is a device too, not only a hop on the mesh
      addGatewayReadings();
    } else if (!d.headline.length && d.has_action) {
      readings.appendChild(lastActionReading(d));
    } else if (!d.headline.length) {
      readings.appendChild(el('span', 'muted small', d.age_s === null ? 'Waiting for the first report'
        : 'No measurements — see All values'));
    }
    if (d.kind !== 'Router' && d.kind !== 'Coordinator') d.headline.forEach(function (hd, i) {
      var r = el('div', 'reading' + (i > 1 ? ' small' : ''));
      var v = el('div', 'v');
      v.innerHTML = esc(fmt(hd.value)) + (hd.unit ? '<span class="unit">' + esc(hd.unit) + '</span>' : '');
      r.appendChild(v);
      r.appendChild(el('div', 'l', hd.label));
      readings.appendChild(r);
    });
    card.appendChild(readings);
    if (d.has_action && d.actions && d.actions.length) card.appendChild(actionChips(d));
    var trv = thermostatControls(d, st);
    if (trv) card.appendChild(trv);
    var foot = el('div', 'foot');
    if (isNum(d.battery)) {
      var bw = el('span', 'batt');
      var bar = el('span', 'bar'); var fill = el('span');
      var bl = d.battery <= st.thresholds.battery_crit ? 'var(--crit)' : (d.battery <= st.thresholds.battery_warn ? 'var(--warn)' : 'var(--ok)');
      fill.style.width = Math.max(0, Math.min(100, d.battery)) + '%'; fill.style.background = bl;
      bar.appendChild(fill);
      bw.appendChild(el('span', '', 'Battery ' + fmt(d.battery, 0) + '%'));
      bw.appendChild(bar);
      foot.appendChild(bw);
    }
    if (isNum(d.linkquality)) {
      var lw = el('span', 'sigwrap');
      lw.appendChild(signalBars('lqi', d.linkquality, st.thresholds));
      lw.appendChild(el('span', '', 'LQI ' + fmt(d.linkquality, 0)));
      foot.appendChild(lw);
    }
    if (d.via && d.via.name) {
      var neighbour = d.via.relation === 'neighbour';
      var via = el('span', 'via', (neighbour ? 'next to ' : 'via ') + d.via.name);
      via.title = (neighbour ? 'A router has no parent \u2014 this is its strongest neighbour, ' + d.via.name
                             : 'Connected through ' + d.via.name)
        + (d.via.type ? ' (' + d.via.type.toLowerCase() + ')' : '')
        + (isNum(d.via.lqi) ? ', link ' + fmt(d.via.lqi, 0) : '')
        + (d.via.ts ? ' — from the network map ' + ago(d.via.ts) : '');
      foot.appendChild(via);
    }
    foot.appendChild(el('span', '', ago(d.last_seen)));
    if (d.zigbee_ts !== undefined && d.zigbee_ts !== null && d.last_seen - d.zigbee_ts > 120) {
      // its readings are being kept fresh over the network, not over Zigbee:
      // say when the device itself last spoke on the mesh, or the age above
      // reads as health it does not have. A router with nothing to report
      // is only heard from when Zigbee2MQTT pings it, every ten minutes or
      // so - that is not worth a colour; a quarter of an hour and more is.
      var quiet = d.last_seen - d.zigbee_ts;
      var zb = el('span', quiet > 900 ? 'reason' : 'muted small', 'Zigbee ' + ago(d.zigbee_ts));
      zb.title = 'Its own Zigbee report. The figures above are refreshed over the network by its gateway entry, which says nothing about the mesh.'
        + (quiet > 900 ? '' : ' A mains-powered device with nothing to report is only heard from when the bridge pings it, so a few minutes is normal.');
      foot.appendChild(zb);
    }
    if (d.reasons.length) foot.appendChild(el('span', 'reason', d.reasons.join('; ')));
    card.appendChild(foot);
    attachCardMenu(card, {head: d.name, rows: [
      ['\ud83d\udcc8 History for this one', function () { showTab('history'); setTimeout(function () { pickHistoryDevice(d.id); }, 80); }],
      ['\ud83d\udd0d Every value it reports', function () { showTab('all'); setTimeout(function () { highlightCard(d.name); }, 200); }],
      ['\ud83d\udccb Copy its name', function () { copyToClipboard(d.name, 'Name'); }],
      d.id && d.id !== d.name ? ['\ud83d\udccb Copy its address', function () { copyToClipboard(d.id, 'Address'); }] : null,
      ['\u26a1 A rule from this device', function () { showTab('control'); setTimeout(function () { showControlSection('automation'); newRuleFor(d.id); }, 120); }]
    ]});
  return card;
}

function renderDeviceGrid(hostId, emptyId, list, kind, st) {
  var host = $(hostId);
  if (ORDER.drag || Date.now() - ORDER.justDropped < 800) return;   // never redraw under a drag
  host.innerHTML = '';
  if ($(emptyId)) $(emptyId).hidden = !!list.length;
  sortByOrder(list, kind, function (d) { return d.id; }).forEach(function (d) {
    var card = buildDeviceCard(d, st);
    makeReorderable(card, host, kind, d.id);
    host.appendChild(card);
  });
}
function renderSensorsTab(st) {
  renderDeviceGrid('sensor-cards', 'sensors-empty',
    st.devices.filter(function (d) { return d.source !== 'plug' && d.source !== 'wifi' && !d.has_action; }), 'sensors', st);
}
function renderButtonsTab(st) {
  renderDeviceGrid('button-cards', 'buttons-empty',
    st.devices.filter(function (d) { return d.source !== 'plug' && d.source !== 'wifi' && d.has_action; }), 'buttons', st);
}



// ---- one on/off control for the whole app: an iOS-style switch ---------------------
function makeSwitch(checked, onChange, opts) {
  opts = opts || {};
  var wrap = el('label', 'sw' + (opts.small ? ' small' : ''));
  var box = el('input'); box.type = 'checkbox'; box.checked = !!checked; box.disabled = !!opts.disabled;
  if (opts.title) wrap.title = opts.title;
  box.onchange = function () { if (onChange) onChange(box.checked, box); };
  wrap.appendChild(box); wrap.appendChild(el('span', 'knob'));
  wrap.input = box;
  return wrap;
}
function switchRow(label, checked, onChange, opts) {
  var row = el('div', 'swrow');
  var sw = makeSwitch(checked, onChange, opts);
  row.appendChild(sw);
  if (label) row.appendChild(el('span', 'swlbl', label));
  row.input = sw.input;
  return row;
}

// ---- one icon per kind, used in every dropdown and button that names a type --------
var ICON = { plug: '\ud83d\udd0c', light: '\ud83d\udca1', all: '\ud83d\udd0c', zb: '\u26a1', heat: '\ud83d\udd25', scene: '\ud83c\udfac', seq: '\ud83d\udd01', seqreset: '\u21ba',
             sgroup: '\ud83e\udde9', agroup: '\ud83c\udfaf', autoswitch: '\ud83e\uddf0', bell: '\ud83d\udd14',
             person: '\ud83d\udc64', modem: '\ud83d\udcf6',
             // an access point is not a Zigbee router and not the modem: the
             // dish belongs to the router and the bars to the modem, so this
             // one takes the globe
             ap: '\ud83c\udf10', wifi: '\ud83c\udf10',
             comfort: '\ud83d\udd06', eco: '\ud83c\udf3f', night: '\ud83c\udf19', plan: '\ud83d\udcc5', shut: '\u26d4',
             valve: '\u2668\ufe0f', knob: '\ud83c\udf9b\ufe0f', motion: '\ud83d\udeb6', contact: '\ud83d\udeaa', thermo: '\ud83c\udf21\ufe0f',
             button: '\ud83d\udd18', sensor: '\ud83d\udce6', router: '\ud83d\udce1', coordinator: '\ud83d\udce1', gateway: '\ud83d\udce1' };
function targetKind(spec) {
  spec = spec || '';
  if (spec === '*') return 'all';
  if (spec === '*lights') return 'light';
  if (spec.indexOf(':') < 0 && plugRoleKind(spec) === 'light') return 'light';
  if (spec.indexOf('zb:') === 0) return 'zb';
  if (spec.indexOf('scene:') === 0) return 'scene';
  if (spec.indexOf('heat:') === 0) return 'heat';
  if (spec.indexOf('seqreset:') === 0) return 'seqreset';
  if (spec.indexOf('seq:') === 0) return 'seq';
  return 'plug';
}
function withIcon(kind, text) { return (ICON[kind] || '') + ' ' + text; }
// A socket marked as a light is shown as one wherever it is listed, and the
// lights group together in the dropdowns rather than being scattered among
// the sockets by name.
function plugRoleKind(nameOrPlug) {
  var p = nameOrPlug;
  if (typeof p === 'string') p = ((STATE.status || {}).plugs || []).filter(function (x) { return x.name === nameOrPlug || x.id === nameOrPlug; })[0];
  return p && p.role === 'light' ? 'light' : 'plug';
}
// dropdown order everywhere: first by kind (the icon), then A-Z within the kind
// The order every mixed list follows: what a person reaches for first, then
// the rest by kind. Inside a kind the sort is by name.
var KIND_ORDER = ['agroup', 'sgroup', 'person', 'plug', 'all', 'light', 'valve', 'zb', 'heat', 'scene', 'seq', 'seqreset',
                  'bell', 'autoswitch', 'thermo', 'motion', 'contact', 'knob', 'button', 'sensor',
                  'modem', 'ap', 'router', 'coordinator', 'gateway'];
function kindRankOfLabel(label) {
  label = String(label || '');
  for (var i = 0; i < KIND_ORDER.length; i++) { var ic = ICON[KIND_ORDER[i]]; if (ic && label.indexOf(ic) === 0) return i; }
  return KIND_ORDER.length;
}
// Two kinds can end up under one heading (a socket and a light are both
// switched the same way, a knob and a button are both pressed). Whatever the
// kind order says, inside a heading the list reads by name.
function fillGroupedSelect(sel, options) {
  var pairs = sortWithinHeadings(options);
  var boxes = {}, box = null, last = null;
  pairs.forEach(function (o) {
    var g = optionGroup(o[0], o[1]);
    if (g !== last) {
      box = boxes[g];                       // a heading is opened once, however the kinds interleave
      if (!box) { box = el('optgroup'); box.label = g; boxes[g] = box; sel.appendChild(box); }
      last = g;
    }
    var opt = el('option', '', o[1]);
    opt.value = o[0];
    box.appendChild(opt);
  });
}
// Sections that must not land wherever they happen to be met: the first two
// belong at the top of a list, the last where the house's own doings go.
var HEADING_FIRST = ['Just an answer', 'Ask it something'];
var HEADING_LAST = ['What the house does to itself', 'Automation on and off'];
function sortWithinHeadings(options) {
  // Every option gets a heading, the placeholder included - it used to be
  // dropped in above the first one without a word, and read as though it
  // belonged to whatever came next.
  var head = options.filter(function (o) { return o[0] === '' && !o[1]; });
  var rest = options.filter(function (o) { return !(o[0] === '' && !o[1]); });
  var order = [], buckets = {};
  rest.forEach(function (o) {
    var g = optionGroup(o[0], o[1]);
    if (!buckets[g]) { buckets[g] = []; order.push(g); }
    buckets[g].push(o);
  });
  var out = [];
  order.sort(function (a, b) {
    var ra = HEADING_FIRST.indexOf(a), rb = HEADING_FIRST.indexOf(b);
    if (ra >= 0 || rb >= 0) return (ra < 0 ? 99 : ra) - (rb < 0 ? 99 : rb);
    var la = HEADING_LAST.indexOf(a), lb = HEADING_LAST.indexOf(b);
    if (la >= 0 || lb >= 0) return (la < 0 ? -1 : la + 1) - (lb < 0 ? -1 : lb + 1);
    return order.indexOf(a) - order.indexOf(b);
  });
  order.forEach(function (g) {
    buckets[g].sort(function (a, b) {
      return String(a[1]).replace(/^\S+\s*/, '').localeCompare(String(b[1]).replace(/^\S+\s*/, ''), undefined, {numeric: true, sensitivity: 'base'});
    });
    out = out.concat(buckets[g]);
  });
  return head.concat(out);
}
function sortByKind(options) {
  // options: [value, label] pairs; a leading '' value (a placeholder) stays first
  var head = options.filter(function (o) { return o[0] === ''; }), rest = options.filter(function (o) { return o[0] !== ''; });
  // "all sockets" and "all lights" sit at the head of their own group: they
  // are what somebody reaches for first, and burying them among fifty names
  // is how they go unnoticed
  var rankOf = function (o) {
    return (o[0] === '*' || o[0] === '*lights') ? kindRankOfLabel(o[1]) - 0.5 : kindRankOfLabel(o[1]);
  };
  rest.sort(function (a, b) {
    var ra = rankOf(a), rb = rankOf(b);
    if (ra !== rb) return ra - rb;
    return String(a[1]).replace(/^\S+\s*/, '').localeCompare(String(b[1]).replace(/^\S+\s*/, ''), undefined, {numeric: true, sensitivity: 'base'});
  });
  return sortWithinHeadings(head.concat(rest));
}
function devicesSorted(list) {
  // by category, then by name; the icon is not the key because two kinds may
  // share one (a plug and "all plugs", a router and a coordinator)
  var rank = {}; KIND_ORDER.forEach(function (k, i) { rank[k] = i; });
  return list.slice().sort(function (a, b) {
    var ra = rank[deviceCategory(a)], rb = rank[deviceCategory(b)];
    ra = ra === undefined ? KIND_ORDER.length : ra; rb = rb === undefined ? KIND_ORDER.length : rb;
    if (ra !== rb) return ra - rb;
    return String(a.name || '').localeCompare(String(b.name || ''), undefined, {numeric: true, sensitivity: 'base'});
  });
}
// What a device is, from what it reports rather than what it is called: a
// valve, a knob, a button, motion, a door, a thermometer. The lists group by
// this and sort by name inside the group.
function deviceCategory(d) {
  if (!d) return 'sensor';
  if (d.source === 'sms') return 'modem';
  if (d.source === 'group') return 'sgroup';
  if (d.source === 'plug') return plugRoleKind(d.name);
  var v = d.values || {};
  if ('current_heating_setpoint' in v || 'occupied_heating_setpoint' in v || 'pi_heating_demand' in v) return 'valve';
  if (d.has_action) {
    var acts = (d.actions || []).join(' ') + ' ' + (d.model || '') + ' ' + (d.description || '');
    return /rotate|brightness_step|hue_move|color_temperature_step|knob|dimmer/i.test(acts) ? 'knob' : 'button';
  }
  if (d.source === 'wifi' || /access point|\bap\b/i.test(d.kind || '')) return 'ap';
  if ((d.kind || '') === 'Router' || (d.kind || '') === 'Coordinator' || d.source === 'gateway') return 'router';
  if ('occupancy' in v || 'presence' in v || 'motion' in v) return 'motion';
  if ('contact' in v || 'window' in v || 'window_open' in v || 'open_window' in v || 'water_leak' in v || 'smoke' in v) return 'contact';
  if ('temperature' in v || 'local_temperature' in v || 'humidity' in v || 'tC' in v) return 'thermo';
  return 'sensor';
}
function deviceIcon(d) { return ICON[deviceCategory(d)] || ICON.sensor; }
ICON.enabled = '\u2705'; ICON.monitor = '\ud83d\udc41'; ICON.disabled = '\u23f8';
ICON.clock = '\ud83d\udd50'; ICON.sunrise = '\ud83c\udf05'; ICON.sunset = '\ud83c\udf07'; ICON.always = '\ud83d\udd01'; ICON.window = '\u23f2'; ICON.leave = '\u2796';
ICON.abs = '\ud83d\udcc8'; ICON.delta = '\ud83d\udcca';
ICON.crit = '\ud83d\udea8'; ICON.warn = '\u26a0\ufe0f'; ICON.offline = '\ud83d\udcf4'; ICON.rule = '\ud83d\udccf'; ICON.switch = '\u21c4';
ICON.follow = '\u21a9'; ICON.mute = '\ud83d\udd15'; ICON.everything = '\ud83d\udce2'; ICON.custom = '\ud83d\udee0';
var EVENT_KIND_ICON = { device: ICON.sensor, plug: ICON.plug, action: ICON.button, rule: ICON.rule, binding: ICON.button, scene: ICON.scene,
  sequence: ICON.seq, schedule: ICON.clock, switch: ICON.zb, control: ICON.custom, audit: '\ud83d\udd10', bridge: ICON.router, gateway: ICON.gateway };
var EVENT_LEVEL_ICON = { info: '\u2139\ufe0f', warn: ICON.warn, crit: ICON.crit };
var NOTIFY_CATEGORY_LABELS = { crit: 'critical problems (thresholds, lost devices)', warn: 'warnings too',
  offline: 'a device going quiet, unreachable or back', rule: 'every rule that fires',
  switch: 'every socket/switch change (on, off)' };
// Which of these is worth hearing about at all, and above it, by which road.
// Both have to say yes: with "a device going quiet" off, nothing is sent about
// one however many roads are open - though it is still written down in Events.
var NOTIFY_CATEGORY_HELP = {
  crit: 'A reading past a threshold, or a device that has stopped answering altogether',
  warn: 'The same, one step milder \u2014 a battery getting low rather than flat',
  offline: 'This is the one that says "Temp-Venek has gone quiet". Off, it is still written '
    + 'down in Events; nothing is sent',
  rule: 'Every time a rule fires. Chatty in a busy house',
  'switch': 'Every socket and light as it changes. Chattier still'
};
var TIME_KIND_OPTIONS = [['clock', ICON.clock + ' at'], ['sunrise', ICON.sunrise + ' sunrise'], ['sunset', ICON.sunset + ' sunset']];
var DO_LABELS = { toggle: '\u21c4 toggle', on: '\u23fb switch on', off: '\u2b58 switch off', pulse: '\u23f1 pulse',
                  'reboot': '\u21bb reboot the box', 'reset-counters': '\u2205 reset its counters' };
function doLabel(a, long) {
  if (String(a).indexOf('set:') === 0) return 'set to ' + a.slice(4);
  if (String(a).indexOf('for:') === 0) return '\u23f1\ufe0f on for ' + a.slice(4);
  if (String(a).indexOf('off-for:') === 0) return '\u23f1\ufe0f off for ' + a.slice(8);
  if (String(a).indexOf('step:') === 0) return (a[5] === '-' ? '\u2b07\ufe0f ' : '\u2b06\ufe0f ') + a.slice(5) + ' from where it is';
  return (DO_LABELS[a] || a) + (long && a === 'pulse' ? ' (flip, wait, flip back)' : '');
}
// Options for a Do select: the on/off actions the daemon allows, plus "set
// to ..." when the chosen target is something with a value rather than a
// state - a valve's target temperature, a thermostat mode.
// A scene, a sequence or a message has nothing to choose: the daemon runs the
// steps, or sends the words, and takes no notice of what a Do column asks of
// it. The bindings card has always hidden the list and put a plain line there
// instead; this is that, so every editor can do the same rather than each one
// remembering to.
function runsItsOwnSteps(doSel, target) {
  var note = doSel.nextElementSibling;
  if (!note || !note.classList.contains('scene-note')) {
    note = el('span', 'muted small scene-note');
    if (doSel.parentNode) doSel.parentNode.insertBefore(note, doSel.nextSibling);
  }
  var bundle = isBundleTarget(target), tells = isNotifyTarget(target);
  doSel.hidden = bundle || tells;
  note.hidden = !bundle && !tells;
  if (tells) {
    note.textContent = 'sends the message';
    note.title = 'Nothing is switched \u2014 what it says is written in the Messages card';
  } else if (bundle) {
    note.textContent = String(target).indexOf('sequence:') === 0
      ? 'runs the sequence\u2019s own steps' : 'runs the scene\u2019s own steps';
    note.title = 'What happens is defined step by step in the Scenes card - the Do column does not apply here';
  }
  return bundle || tells;
}

function doOptionsFor(st, target, current) {
  // Somebody being home is not switched on and off; they arrive and they
  // leave. The daemon still hears 'on' and 'off', but nobody should have to
  // work out which is which.
  if (isSystemTarget(target))
    return [['on', '\u25b6 do it']];
  // A scene or a sequence has its own steps; the daemon runs them and takes no
  // notice of what is asked of it here. Offering on, off and toggle beside one
  // is offering a choice that does not exist - two editors said so in a note
  // beside the list and the rest quietly did not.
  if (String(target || '').indexOf('scene:') === 0)
    return [['on', '\u25b6 runs the scene\u2019s own steps']];
  if (String(target || '').indexOf('sequence:') === 0)
    return [['on', '\u25b6 runs the sequence\u2019s own steps']];
  if (String(target || '').indexOf('who:') === 0)
    return [['on', ICON.person + ' has arrived \u2014 they are home'],
            ['off', '\ud83d\udeaa has left \u2014 they are out'],
            ['toggle', '\u21c4 the other way round']];
  var opts = (st.binding_actions || ['toggle', 'on', 'off', 'pulse']).map(function (a) { return [a, doLabel(a, true)]; });
  // a Shelly box takes a few more, over MQTT or HTTP alike
  if (String(target || '').indexOf('zb:') !== 0 && String(target || '').indexOf('heat:') !== 0 && String(target || '').indexOf('scene:') !== 0 && String(target || '').indexOf('seq') !== 0 && String(target || '').indexOf('msg:') !== 0)
    opts = opts.concat((st.plug_extra_actions || []).map(function (a) { return [a, doLabel(a, true)]; }));
  // on for a while, and back again after - a light in a cellar, a fan, a pump
  if (String(target || '').indexOf('notify') !== 0)
    opts = opts.concat([['for:10m', '\u23f1\ufe0f on for 10 minutes'], ['for:30m', '\u23f1\ufe0f on for half an hour'],
                        ['for:2h', '\u23f1\ufe0f on for two hours'], ['off-for:30m', '\u23f1\ufe0f off for half an hour']]);
  var t = settableTarget(st, target);
  if (t) {
    opts = [['set:', 'set to \u2026']].concat(t.kind === 'enum' ? [] : opts);
    if (t.kind !== 'enum')                        // a nudge from wherever it is now
      opts = opts.concat([['step:+1', '\u2b06\ufe0f one more than it is now'], ['step:-1', '\u2b07\ufe0f one less'],
                          ['step:+0.5', '\u2b06\ufe0f half a degree more'], ['step:-0.5', '\u2b07\ufe0f half a degree less']]);
  }
  if (current && String(current).indexOf('set:') === 0) opts = opts.filter(function (o) { return o[0] !== 'set:'; }).concat([['set:', 'set to \u2026']]);
  return opts;
}
function settableTarget(st, target) {
  if (String(target || '').indexOf('heat:room:') === 0)
    return {value: target, kind: 'enum',
            values: ['plan', 'comfort', 'eco', 'night', 'off', 'manual', 'next'], name: 'heating level'};
  var t = (st.switch_targets || []).filter(function (x) { return x.value === target; })[0];
  return t && t.kind && t.kind !== 'switch' ? t : null;
}
// The value box that belongs to "set to ...": a number with the device's own
// limits, or the list of modes it names.
function setValueBox(st, get, put) {
  var box = el('span', 'ms'), input = null;
  box.refresh = function (target, current) {
    var t = settableTarget(st, target);
    box.innerHTML = '';
    var on = t && String(current || '').indexOf('set:') === 0;
    box.classList.toggle('show', !!on);
    if (!on) { input = null; return; }
    var value = String(current).slice(4);
    if (t.kind === 'enum') {
      input = el('select');
      fillSelect(input, (t.values || []).map(function (v) { return [v, v]; }), value || (t.values || [])[0]);
      if (!value) put('set:' + input.value);
      input.onchange = function () { put('set:' + input.value); };
    } else {
      // "to 21.5" sets it; "up by 0.5" / "down by 0.5" step from where it is -
      // what a turning knob wants (the daemon keeps it inside the device's range)
      var how = el('select');
      var sign = value.charAt(0) === '+' ? 'up' : (value.charAt(0) === '-' ? 'down' : 'to');
      fillSelect(how, [['to', 'to'], ['up', 'up by'], ['down', 'down by']], sign);
      var num = value.replace(/^[+-]/, '');
      input = el('input'); input.type = 'number'; input.style.width = '72px';
      input.step = 0.5;
      function apply() {
        if (input.value === '') return;
        var v = String(input.value).replace(/^[+-]/, '');
        // a bare minus means "down by", so an outright negative needs the = form
        put('set:' + (how.value === 'up' ? '+' : (how.value === 'down' ? '-' : (parseFloat(input.value) < 0 ? '=-' : ''))) + v);
      }
      function fit() {
        if (how.value === 'to') { if (isNum(t.min)) input.min = t.min; if (isNum(t.max)) input.max = t.max; input.title = 'What to set it to' + (isNum(t.min) && isNum(t.max) ? ' (' + t.min + '\u2013' + t.max + ')' : ''); }
        else { input.removeAttribute('min'); input.removeAttribute('max'); input.title = 'How much to step it by, from where it is now'; }
      }
      input.value = num !== '' ? num : (sign === 'to' ? (isNum(t.state) ? t.state : (isNum(t.min) ? t.min : 20)) : 0.5);
      fit();
      if (value === '') apply();
      input.oninput = apply;
      how.onchange = function () { if (how.value !== 'to' && (input.value === '' || parseFloat(input.value) > 10)) input.value = 0.5; fit(); apply(); };
      box.appendChild(how);
    }
    box.appendChild(input);
    if (t.unit) box.appendChild(el('span', '', t.unit));
  };
  return box;
}

// ---- the curated Overview: any free mix of plugs, sensors, buttons ------------------
var OVERVIEW_LAYOUT_LOCAL = null;
function overviewLayoutIds(st) {
  if (OVERVIEW_LAYOUT_LOCAL !== null) return OVERVIEW_LAYOUT_LOCAL;
  var layout = st.overview_layout;
  if (Array.isArray(layout)) return layout;
  // never customized: default to everything, in the same order the old
  // combined Overview used to show it, so a fresh install looks unchanged
  var ids = (st.plugs || []).filter(function (p) { return true; }).map(function (p) { return p.id; });
  st.devices.forEach(function (d) { if (d.source !== 'plug') ids.push(d.id); });
  return ids;
}
function overviewAvailableOptions(st) {
  var out = [];
  (st.plugs || []).forEach(function (p) { out.push([p.id, withIcon(plugRoleKind(p), p.name)]); });
  st.devices.forEach(function (d) {
    if (d.source === 'plug') return;
    out.push([d.id, deviceIcon(d) + ' ' + d.name]);
  });
  return sortByKind(out);
}
function saveOverviewLayout(items) {
  OVERVIEW_LAYOUT_LOCAL = items;
  post('overview-layout-save', {items: items}).then(function () { toast('Overview saved', true); },
    function (e) { toast('Overview not saved: ' + (e.message || e), false); OVERVIEW_LAYOUT_LOCAL = null; tick(true); });
}
function makeOverviewReorderable(node, host, id) {
  node.dataset.okey = id;
  if (!isUnlocked() || !REARRANGE) return;
  node.draggable = true;
  node.classList.add('cangrab');
  node.addEventListener('dragstart', function (e) {
    ORDER.drag = { kind: 'overview_layout', key: id, node: node };
    node.classList.add('draggingcard');
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', id); } catch (err) {} }
    e.stopPropagation();
  });
  node.addEventListener('dragover', function (e) {
    if (!ORDER.drag || ORDER.drag.kind !== 'overview_layout' || ORDER.drag.key === id) return;
    e.preventDefault(); e.stopPropagation();
    var dragged = ORDER.drag.node;
    var siblings = Array.prototype.slice.call(host.children);
    if (siblings.indexOf(dragged) < siblings.indexOf(node)) host.insertBefore(dragged, node.nextSibling);
    else host.insertBefore(dragged, node);
  });
  node.addEventListener('dragend', function (e) {
    node.classList.remove('draggingcard');
    e.stopPropagation();
    if (!ORDER.drag) return;
    ORDER.drag = null;
    ORDER.justDropped = Date.now();
    var keys = Array.prototype.map.call(host.children, function (c) { return c.dataset.okey; }).filter(Boolean);
    saveOverviewLayout(keys);
  });
}
function renderOverviewCustom(st) {
  var host = $('overview-custom');
  if (ORDER.drag || Date.now() - ORDER.justDropped < 800) return;   // never redraw under a drag
  var plugById = {}; (st.plugs || []).forEach(function (p) { plugById[p.id] = p; });
  var ids = overviewLayoutIds(st);
  $('overview-custom-empty').hidden = !!ids.length;
  $('ov-add-row').hidden = !isUnlocked();
  // Only the cards whose facts changed are rebuilt; the rest are the same
  // DOM nodes moved into place. One report used to rebuild all 35 cards -
  // fine on a desktop, a visible hitch on a phone, and it restarted every
  // animation on the page.
  var minute = Math.floor(Date.now() / 60000), unlocked = isUnlocked();
  var keep = OVERVIEW_CARDS, fresh = {};
  var order = [];
  ids.forEach(function (id) {
    var card, isPlug = !!plugById[id], sig, d = null;
    // ages tick every second on every device; the card only shows them to
    // the minute, so they are left out of the signature (minute is in)
    if (isPlug) sig = JSON.stringify([1, plugById[id], minute, unlocked, REARRANGE, LINKS], function (k, v) { return k === 'age' ? undefined : (k === 'retry_in' && v ? Math.ceil(v / 10) : v); });
    else {
      d = deviceById(id);
      if (!d) return;                  // gone (removed, disabled) - skip quietly
      sig = JSON.stringify([0, d, minute, unlocked, REARRANGE, LINKS, d.via && d.via.name], function (k, v) { return k === 'age_s' ? undefined : v; });
    }
    if (keep[id] && keep[id].sig === sig) { fresh[id] = keep[id]; order.push(keep[id].node); return; }
    if (isPlug) {
      card = buildPlugCard(plugById[id], false);
      card.style.gridColumn = '1/-1';
    } else {
      card = buildDeviceCard(d, st);
    }
    if (isUnlocked()) {
      var rm = el('button', 'ov-remove'); rm.type = 'button'; rm.title = 'Remove from Overview';
      rm.innerHTML = iconMarkup('close', 13);
      rm.onclick = function (e) {
        e.stopPropagation();
        saveOverviewLayout(ids.filter(function (x) { return x !== id; }));
        renderOverviewCustom(STATE.status);
      };
      card.style.position = 'relative';
      card.appendChild(rm);
    }
    makeOverviewReorderable(card, host, id);
    fresh[id] = {sig: sig, node: card};
    order.push(card);
  });
  OVERVIEW_CARDS = fresh;
  // same node, same place -> appendChild is a no-op for the browser; the
  // ones that moved or are new get inserted; the rest of the tree is untouched
  var existing = Array.prototype.slice.call(host.children);
  var changed = existing.length !== order.length || existing.some(function (n, i) { return n !== order[i]; });
  if (changed) {
    existing.forEach(function (n) { if (order.indexOf(n) < 0) host.removeChild(n); });
    order.forEach(function (n, i) { if (host.children[i] !== n) host.insertBefore(n, host.children[i] || null); });
  }
}
var OVERVIEW_CARDS = {};
function renderOverviewAddControl(st) {
  var row = $('ov-add-row'); row.hidden = !isUnlocked();
  if (!isUnlocked() || editorBusy('ov-add-row')) return;
  var have = {}; overviewLayoutIds(st).forEach(function (id) { have[id] = true; });
  var options = overviewAvailableOptions(st).filter(function (o) { return !have[o[0]]; });
  var sel = $('ov-add-select');
  fillSelect(sel, options.length ? options : [['', '— everything is already on Overview —']], sel.value);
  $('ov-add-btn').disabled = !options.length;
}
$('ov-add-btn').onclick = function () {
  var id = $('ov-add-select').value;
  if (!id) return;
  var ids = overviewLayoutIds(STATE.status);
  if (ids.indexOf(id) >= 0) { renderOverviewAddControl(STATE.status); return; }   // already there - just resync the list
  saveOverviewLayout(ids.concat([id]));
  renderOverviewCustom(STATE.status);
  renderOverviewAddControl(STATE.status);
};
// A live update (a report landing) refreshes the cards at once; the charts
// span hours to days, where one new point is invisible for tens of seconds,
// so their reload is coalesced: at most one every OV_CHART_MIN_MS, and always
// one shortly after the last change. Before this, every message from every
// device re-fetched every chart - N requests and N canvas redraws per report.
var OV_CHART_MIN_MS = 15000;
function scheduleOverviewCharts() {
  if (STATE._ovTimer) return;
  var wait = Math.max(500, OV_CHART_MIN_MS - (Date.now() - (STATE._ovLoaded || 0)));
  STATE._ovTimer = setTimeout(function () {
    STATE._ovTimer = null;
    if (STATE.tab !== 'overview' || document.hidden) return;
    loadOverviewCharts(); STATE._ovLoaded = Date.now();
  }, wait);
}
function loadOverviewCharts() {
  var st = STATE.status;
  if (!st) return;
  var spanS = spanSeconds(STATE.ovRange);
  var wanted = [];
  st.devices.forEach(function (d) {
    var tk = tempKey(d), hk = humKey(d);
    if (!tk && !hk) return;
    wanted.push({dev: d, tk: tk, hk: hk, keys: [tk, hk].filter(Boolean)});
  });
  $('ov-temp-range').textContent = STATE.ovRange; $('ov-hum-range').textContent = STATE.ovRange;
  if (!wanted.length) { drawChart($('ov-temp'), [], {spanS: spanS}); drawChart($('ov-hum'), [], {spanS: spanS}); return; }
  if (STATE._ovBusy) { STATE._ovAgain = true; return; }      // one in flight: run once more when it lands
  STATE._ovBusy = true;
  var items = wanted.map(function (w) { return w.dev.id + '|' + w.keys.join(','); }).join(';');
  api('history-multi&items=' + encodeURIComponent(items) + '&range=' + STATE.ovRange + '&points=400').then(function (r) {
    var series = (r && r.series) || {};
    return wanted.map(function (w) { return series[w.dev.id] ? {dev: w.dev, tk: w.tk, hk: w.hk, rows: series[w.dev.id]} : null; });
  }, function () { return []; }).then(function (results) {
    STATE._ovBusy = false;
    if (STATE._ovAgain) { STATE._ovAgain = false; scheduleOverviewCharts(); }
    var temps = [], hums = [];
    results.forEach(function (r, i) {
      if (!r) return;
      var color = COLORS[i % COLORS.length];
      if (r.tk) temps.push({name: r.dev.name, color: color, unit: '°C', points: r.rows.map(function (x) { return [x.ts, x[r.tk]]; })});
      if (r.hk) hums.push({name: r.dev.name, color: color, unit: '%', points: r.rows.map(function (x) { return [x.ts, x[r.hk]]; })});
    });
    drawChart($('ov-temp'), temps, {spanS: spanS, outages: CHART_OUTAGES}); legend($('ov-temp-legend'), temps);
    drawChart($('ov-hum'), hums, {spanS: spanS, outages: CHART_OUTAGES}); legend($('ov-hum-legend'), hums);
  });
}
function spanSeconds(range) {
  var m = /^(\d+)([smhdwy])$/.exec(range); if (!m) return 86400;
  return parseInt(m[1], 10) * {s: 1, m: 60, h: 3600, d: 86400, w: 604800, y: 31557600}[m[2]];
}
function rangeButtons(host, ranges, current, onpick) {
  host.innerHTML = '';
  ranges.forEach(function (r) {
    var b = el('button', 'btn small' + (r === current ? ' on' : ''), r);
    b.onclick = function () { onpick(r); };
    host.appendChild(b);
  });
}

// ---- history ------------------------------------------------------------------
function renderHistoryControls(fromTick) {
  var st = STATE.status; if (!st) return;
  var sel = $('h-device');
  // The periodic refresh must not rebuild an open <select> out from under
  // the person; it tries again a few seconds later, once they are done.
  // A direct call - picking a range, opening the tab - always goes through,
  // since that rebuild is the point of the click.
  if (fromTick && document.activeElement === sel) return;
  var current = STATE.hDevice || (sel.value || (st.devices[0] && st.devices[0].id));
  sel.innerHTML = '';
  // grouped by kind, alphabetical inside, like every other long list
  fillGroupedSelect(sel, devicesSorted(st.devices).map(function (d) {
    return [d.id, deviceIcon(d) + ' ' + d.name + ' \u2014 ' + [d.vendor, d.model].filter(Boolean).join(' ')];
  }));
  if (current && deviceById(current)) sel.value = current;
  STATE.hDevice = sel.value || null;
  sel.onchange = function () { STATE.hDevice = sel.value; loadHistory(); };
  rangeButtons($('h-ranges'), ['6h', '24h', '7d', '30d', '1y'], STATE.hRange, function (r) { STATE.hRange = r; renderHistoryControls(); loadHistory(); });
}
function loadHistory() {
  var id = STATE.hDevice, host = $('h-charts');
  if (!id) { host.innerHTML = '<div class="card center full">No device selected</div>'; return; }
  var d = deviceById(id);
  $('h-note').textContent = 'Loading…';
  api('device&id=' + encodeURIComponent(id)).then(function (info) {
    var keys = (info.keys || []).filter(function (k) { return k !== 'linkquality'; });
    if (info.keys && info.keys.indexOf('linkquality') >= 0) keys.push('linkquality');
    if (!keys.length) { host.innerHTML = '<div class="card center full">Nothing numeric recorded for this device yet</div>'; $('h-note').textContent = ''; return; }
    return api('history&device=' + encodeURIComponent(id) + '&keys=' + keys.join(',') + '&range=' + STATE.hRange + '&points=700').then(function (r) {
      host.innerHTML = '';
      var spanS = spanSeconds(STATE.hRange);
      keys.forEach(function (k, i) {
        var meta = (info.values && info.values[k]) || {};
        var card = el('div', 'card');
        var h2 = el('h2'); h2.innerHTML = esc(meta.label || k) + (meta.unit ? ' <span class="right">' + esc(meta.unit) + '</span>' : '');
        card.appendChild(h2);
        var box = el('div', 'chart'); box.id = 'h-chart-' + i;
        card.appendChild(box);
        host.appendChild(card);
        var pts = r.rows.map(function (x) { return [x.ts, x[k]]; }).filter(function (p) { return p[1] !== undefined; });
        var opts = {spanS: spanS};
        if (k === 'battery' || k === 'humidity' || k === 'rh') { opts.min = 0; opts.max = 100; }
        opts.outages = CHART_OUTAGES;
        drawChart(box, [{name: (d ? d.name : id), color: COLORS[i % COLORS.length], unit: meta.unit || '', points: pts}], opts);
      });
      $('h-note').textContent = r.rows.length + ' points' + (spanS > 14 * 86400 ? ' · older than two weeks is hourly average' : '');
    });
  }).catch(function (e) { $('h-note').textContent = 'Error: ' + e.message; });
}

// ---- devices table --------------------------------------------------------------
var RENAME = { active: false };
function renameDevice(d) {
  var editable = d.source !== 'plug' && d.id.indexOf('sensor:') !== 0;
  if (!editable) { toast('This one is named in "Plugs and sensors" on the Control tab', false); return; }
  var cell = $('name-' + cssId(d.id));
  if (!cell || cell.querySelector('input')) return;
  RENAME.active = true;              // the table must not redraw under the typing
  var old = d.name;
  cell.innerHTML = '';
  var input = el('input'); input.value = old; input.maxLength = 41;
  input.style.cssText = 'font:inherit;font-size:14px;background:var(--panel2);color:var(--tx);border:1px solid var(--info);border-radius:8px;padding:6px 10px;width:100%;max-width:220px';
  var hint = el('div', 'muted small', d.source === 'zigbee' ? 'Renames it in Zigbee2MQTT too (Enter saves, Esc cancels)' : 'A dashboard name; the MQTT topic stays (Enter saves, Esc cancels)');
  cell.appendChild(input); cell.appendChild(hint);
  input.focus(); input.select();
  var done = false;
  function cancel() { if (done) return; done = true; RENAME.active = false; tick(true); }
  function save() {
    if (done) return;
    var name = input.value.trim();
    if (!name || name === old) { cancel(); return; }
    done = true;
    RENAME.active = false;
    withPin('Rename ' + old, 'New name: <b>' + esc(name) + '</b>' + (d.source === 'zigbee' ? '<br>Zigbee2MQTT is told as well, so the name holds everywhere.' : ''), function (pin) {
      return post('rename', {id: d.id, name: name, pin: pin}).then(function (r) { return r.message || 'renamed'; });
    });
  }
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') save();
    if (e.key === 'Escape') cancel();
  });
  input.addEventListener('blur', function () { setTimeout(cancel, 150); });
}
// Deleting is destructive enough that even an unlocked session gets the
// danger dialogue - just without the PIN boxes, one Confirm.
function withDangerConfirm(title, text, action) {
  if (isUnlocked() && pinNeeded()) {
    askPin(title, text, true, false, true).then(function (ok) {
      if (ok === null) return;
      action('').then(function (msg) { toast(msg, true); tick(true); }, function (e) { toast(e.message || String(e), false); });
    });
    return;
  }
  withPin(title, text, action, true);
}
function deleteDevice(d) {
  withDangerConfirm('Delete ' + d.name,
    'Every reading, event and snapshot recorded for it here is erased, and any binding or rule with it as the source goes too.<br>'
    + (d.source === 'zigbee' ? 'Zigbee2MQTT still knows the device: when it next reports, it appears here again, fresh.' : 'If it reports again, it appears here again, fresh.'),
    function (pin) {
      return post('reset', {scope: 'device', device: d.id, pin: pin}).then(function (r) {
        var extra = (r.removed_with_it || []).length;
        return 'Deleted ' + d.name + (extra ? ' and ' + extra + ' binding(s)/rule(s) that used it' : '');
      });
    }, true);
}
function cssId(id) { return id.replace(/[^A-Za-z0-9_-]/g, '_'); }
function renderDevices(st) {
  if (RENAME.active) return;         // an inline rename is open; leave the table alone
  var tb = $('devices-table').querySelector('tbody');
  tb.innerHTML = '';
  st.devices.forEach(function (d) {
    var tr = el('tr');
    tr.innerHTML = '<td id="name-' + cssId(d.id) + '"><b>' + esc(d.name) + '</b>'
      + (d.alias ? '<br><span class="muted small">topic: ' + esc(d.topic_name) + '</span>' : '')
      + (function () { var sub = [d.description, gatewayFirmware(d)].filter(Boolean).join(' · ');
                       return sub ? '<br><span class="muted small">' + esc(sub) + '</span>' : ''; })() + '</td>'
      + '<td>' + esc([d.vendor, d.model].filter(Boolean).join(' ') || '–') + '</td>'
      + '<td><span class="tag ' + (d.source === 'zigbee' ? 'zb' : 'info') + '">' + esc(d.source) + '</span> <span class="muted small">' + esc(d.kind || '') + '</span></td>'
      + '<td class="mono small">' + esc(d.id) + '</td>'
      + '<td><span class="tag ' + d.level + '">' + esc(d.level) + '</span>' + (d.reasons.length ? '<br><span class="muted small">' + esc(d.reasons.join('; ')) + '</span>' : '') + '</td>'
      + '<td class="num">' + (isNum(d.battery) ? fmt(d.battery, 0) + ' %' : '–') + '</td>'
      + '<td class="num">' + (isNum(d.linkquality) ? fmt(d.linkquality, 0) : '–') + '</td>'
      + '<td>' + esc(ago(d.last_seen)) + '<br><span class="muted small">' + esc(stamp(d.last_seen)) + '</span></td>'
      + '<td class="small">' + esc(stamp(d.first_seen)) + '</td>';
    var actions = el('td');
    actions.style.whiteSpace = 'nowrap';
    var ren = el('button', 'btn small iconbtn needs-unlock'); ren.innerHTML = iconMarkup('pencil', 15); ren.title = 'Rename';
    ren.onclick = function () { if (!isUnlocked()) { unlockFlow(function () { renameDevice(d); }); } else renameDevice(d); };
    var del = el('button', 'btn small iconbtn danger needs-unlock'); del.innerHTML = iconMarkup('trash', 15); del.title = 'Delete the device and everything recorded for it';
    del.onclick = function () { deleteDevice(d); };
    actions.appendChild(ren); actions.appendChild(document.createTextNode(' ')); actions.appendChild(del);
    tr.appendChild(actions);
    tb.appendChild(tr);
  });
  renderForgetSelect(st);
}
// The list this control offers lives on the Control tab, so it has to be
// filled from there too - a tab that was never opened must not leave it empty
// and the button doing nothing.
function renderForgetSelect(st) {
  var sel = $('reset-device'); if (!sel) return;
  var cur = sel.value;
  sel.innerHTML = '';
  fillGroupedSelect(sel, devicesSorted((st && st.devices) || []).map(function (d) {
    return [d.id, deviceIcon(d) + ' ' + d.name];
  }));
  // what the leftovers scan found is not in the status list at all, so offer
  // it here, marked, or there is no way to pick a single one out
  ((STALE && STALE.devices) || []).forEach(function (x) {
    var o = el('option', '', '\u26a0 ' + x.name + ' \u2014 gone, ' + x.rows.toLocaleString() + ' readings');
    o.value = x.device; o.className = 'gone';
    sel.appendChild(o);
  });
  if (cur) sel.value = cur;
}

// ---- something a person has taken over ---------------------------------------------
function holdFor(st, name) {
  return ((st && st.holds) || []).filter(function (h) { return h.target === name; })[0];
}
function holdChip(st, name) {
  var held = holdFor(st, name);
  if (!held) return null;
  var chip = el('button', 'holdchip'); chip.type = 'button';
  chip.innerHTML = iconMarkup('hand', 13) + ' by hand';
  var left = held.until ? Math.max(0, held.until - Date.now() / 1000) : 0;
  chip.title = 'Taken over from ' + (held.by || 'a button') + ' ' + ago(held.since)
    + (left ? ', given back on its own in ' + runtimeText(left) : ', until it is given back')
    + '. Rules and schedules leave it alone until then. Click to give it back now.';
  chip.onclick = function (e) {
    e.stopPropagation();
    withPin('Give ' + name + ' back', 'Its rules and schedules take over again at once.', function (pin) {
      return post('hold-release', {target: name, pin: pin}).then(function () { tick(true); return name + ' is back on its rules'; });
    });
  };
  return chip;
}

// ---- the WiFi tab: what the controller can tell us about the network ---------------
// Everything here is for looking at. The daemon asks the controller rarely and
// nothing in the house waits on any of it.
var WIFI_ORDER = {rows: null, drag: null};

function wifiTiles(st) {
  var wifi = st.wifi_detail || {};
  var counts = wifi.counts || {};
  var tiles = [];
  var cfg = st.wifi_config || {};
  var poll = (st.presence || {}).wifi || {};

  tiles.push({id: 'wifi:controller', kind: 'tile-controller', title: cfg.host || 'Controller', build: function (card) {
    card.appendChild(el('div', 'model', [(wifi.controller || {}).name, (wifi.controller || {}).version
      ? 'v' + wifi.controller.version : ''].filter(Boolean).join(' \u00b7 ') || 'UniFi controller'));
    var readings = el('div', 'readings');
    readings.appendChild(reading(counts.wifi, '', 'on Wi-Fi'));
    readings.appendChild(reading(counts.wired, '', 'on a cable'));
    if (counts.guests) readings.appendChild(reading(counts.guests, '', 'guests', true));
    if (counts.vpn) readings.appendChild(reading(counts.vpn, '', 'over VPN', true));
    readings.appendChild(reading(counts.aps, '', 'access points', true));
    readings.appendChild(reading(counts.ssids, '', 'networks', true));
    if (isNum(counts.worst_signal)) readings.appendChild(reading(counts.worst_signal, 'dBm', 'weakest client', true));
    Object.keys(counts.bands || {}).sort().forEach(function (band) {
      readings.appendChild(reading(counts.bands[band], '', 'on ' + band, true));
    });
    card.appendChild(readings);
    var foot = el('div', 'foot');
    foot.appendChild(el('span', '', poll.checked ? 'asked ' + ago(poll.checked) : 'not asked yet'));
    if (poll.ok === false) foot.appendChild(el('span', 'reason', poll.error || 'the controller did not answer'));
    card.appendChild(foot);
  }});

  (wifi.aps || []).forEach(function (ap) {
    tiles.push({id: 'wifi:' + ap.mac, kind: 'tile-ap', title: ap.name, device: 'wifi:' + ap.mac, build: function (card) {
      card.appendChild(el('div', 'model', [ap.model, ap.version ? 'v' + ap.version : '', ap.ip].filter(Boolean).join(' \u00b7 ')));
      if (ap.last_trouble || ap.ever_crashed) {
        var warn = el('div', 'muted small');
        warn.textContent = ap.last_trouble ? ('last trouble: ' + ap.last_trouble) : 'it has crashed at some point';
        warn.className = 'reason small';
        card.appendChild(warn);
      }
      var readings = el('div', 'readings');
      readings.appendChild(reading(ap.clients, '', 'clients'));
      if (ap.guests) readings.appendChild(reading(ap.guests, '', 'of them guests', true));
      if (ap.experience) readings.appendChild(reading(ap.experience, '%', 'experience', true));
      (ap.radios || []).sort(function (a, b) { return parseFloat(a.band || 0) - parseFloat(b.band || 0); })
        .forEach(function (r) {
          var label = (r.band || '?') + ' GHz';
          // the official API reports no per-radio client count, so show what it
          // does give rather than a dash
          var value = isNum(r.clients) ? r.clients : (r.standard || '\u2013');
          var box = reading(value, '', label, true);
          var bits = [];
          if (isNum(r.utilization)) {
            // How busy the air is, and whose fault that is. Eighty per cent
            // of which ten is ours is a neighbour problem; the same eighty
            // that is all ours is a busy access point doing its job.
            var who = [];
            if (isNum(r.busy_us_tx) || isNum(r.busy_us_rx))
              who.push('us ' + fmt((r.busy_us_tx || 0) + (r.busy_us_rx || 0), 0) + '%');
            if (isNum(r.busy_others)) who.push('others ' + fmt(r.busy_others, 0) + '%');
            bits.push('airtime in use ' + fmt(r.utilization, 0) + '%'
                      + (who.length ? ' (' + who.join(', ') + ')' : ''));
          }
          if (isNum(r.noise)) bits.push('noise floor ' + fmt(r.noise, 0) + ' dBm');
          if (isNum(r.given_up) && r.given_up > 0) bits.push(fmt(r.given_up, 0) + ' frames given up on');
          if (isNum(r.tx_retries)) bits.push('retries ' + fmt(r.tx_retries, 1) + '%');
          if (isNum(r.interference)) bits.push('interference ' + fmt(r.interference, 0) + ' dBm');
          if (r.standard && isNum(r.clients)) bits.push(r.standard);
          if (r.dfs) bits.push('a radar channel \u2014 the point may be told to leave it without notice');
          if ((r.quieter || []).length) {
            bits.push('quieter going spare: ' + r.quieter.map(function (q) {
              return 'ch ' + q.channel + ' (' + fmt(q.busy, 0) + '%)';
            }).join(', '));
          }
          if (bits.length) box.title = bits.join('\n');
          var where = el('div', 'sub');
          where.textContent = 'ch ' + (r.channel || '?') + (r.width ? ' \u00b7 ' + r.width + ' MHz' : '');
          if (r.dfs) where.appendChild(el('span', 'chip-dfs', 'DFS'));
          box.appendChild(where);
          if ((r.quieter || []).length) {
            box.appendChild(el('div', 'sub hint', 'ch ' + r.quieter[0].channel + ' is quieter'));
          }
          readings.appendChild(box);
        });
      if (ap.uplink) {
        // "down 17.3 Kbps  up 48.1 Kbps" was breaking after the arrow, leaving
        // a stray one at the end of the line. Each direction is one piece now,
        // and the break falls between them.
        var flow = reading('', '', 'uplink', true);
        var vv = flow.querySelector('.v');
        vv.innerHTML = '';
        String(ap.uplink).split(/\s{2,}/).forEach(function (part) {
          var piece = el('span', 'nowrap', part.trim());
          vv.appendChild(piece);
        });
        readings.appendChild(flow);
      }
      var gateway = (ap.paths || []).filter(function (p) { return p.to === 'gateway' && p.latency_ms !== null; })[0];
      if (gateway) {
        var box = reading(gateway.latency_ms, 'ms', 'to the gateway', true);
        box.title = 'jitter ' + gateway.jitter_ms + ' ms, loss ' + gateway.loss_pct + '%'
          + (gateway.reachable ? '' : ' \u2014 not answering');
        readings.appendChild(box);
      }
      if (isNum(ap.flash_wear)) {
        var wear = reading(ap.flash_wear, '%', 'flash worn', true);
        wear.title = 'how much of the storage\u2019s write life has been used'
          + (ap.boot_reason ? '. Last start: ' + String(ap.boot_reason).toLowerCase().replace(/_/g, ' ') : '');
        readings.appendChild(wear);
      }
      if (ap.ports && ap.ports.count) {
        var speed = ap.ports.speed || ap.ports.max_speed;
        var box = reading(speed || ap.ports.count, speed ? 'Mbps' : '', speed ? 'wired at' : 'ports', true);
        box.title = [ap.ports.connector, ap.ports.poe ? 'PoE' : '',
                     ap.ports.up === null || ap.ports.up === undefined ? ''
                       : ap.ports.up + ' of ' + ap.ports.count + ' up',
                     ap.ports.max_speed && ap.ports.speed && ap.ports.max_speed !== ap.ports.speed
                       ? 'the socket can do ' + ap.ports.max_speed + ' Mbps' : ''
                    ].filter(Boolean).join(' \u00b7 ');
        readings.appendChild(box);
      }
      if (ap.updatable) readings.appendChild(reading('yes', '', 'firmware update', true));
      if (isNum(ap.cpu)) {
        var cpuBox = reading(fmt(ap.cpu, 0), '%', 'processor', true);
        if (isNum(ap.load)) {
          cpuBox.title = 'load over 1, 5 and 15 minutes: ' + [ap.load, ap.load_5, ap.load_15]
            .filter(function (x) { return isNum(x); }).join('  ')
            + (isNum(ap.memory_used) && isNum(ap.memory_total)
               ? '\nmemory ' + Math.round(ap.memory_used / 1e6) + ' of ' + Math.round(ap.memory_total / 1e6) + ' MB'
               : '');
        }
        readings.appendChild(cpuBox);
      }
      if (isNum(ap.memory)) readings.appendChild(reading(fmt(ap.memory, 0), '%', 'memory', true));
      if (isNum(ap.uptime)) readings.appendChild(reading(runtimeText(ap.uptime), '', 'uptime', true));
      card.appendChild(readings);
    }, state: ap.state === 'offline' ? 'crit' : 'ok', tag: ap.state === 'offline' ? 'offline' : 'online'});
  });

  (wifi.ssids || []).forEach(function (ssid) {
    tiles.push({id: 'wifi:ssid:' + ssid.name, kind: 'tile-ssid', title: ssid.name, build: function (card) {
      var bits = [];
      if (ssid.security) bits.push(String(ssid.security).toUpperCase());
      if (ssid.band) bits.push(ssid.band + ' GHz');
      if (ssid.network) bits.push(ssid.network + (ssid.vlan ? ' (VLAN ' + ssid.vlan + ')' : ''));
      if (ssid.guest) bits.push('guest');
      if (ssid.hidden) bits.push('hidden');
      if (ssid.derived) bits.push('seen on the air');
      card.appendChild(el('div', 'model', bits.join(' \u00b7 ') || 'wireless network'));
      var readings = el('div', 'readings');
      var joined = reading(isNum(ssid.clients) ? ssid.clients : '\u2013', '',
                           isNum(ssid.clients) ? 'joined' : 'not counted');
      if (!isNum(ssid.clients)) joined.title = 'The controller does not say which network a client is on '
        + 'over the API key, so this cannot be counted. A username and password reports it.';
      readings.appendChild(joined);
      if (ssid.on_aps && ssid.on_aps !== 'all') readings.appendChild(reading(ssid.on_aps, '', 'broadcast by', true));
      card.appendChild(readings);
    }, state: ssid.enabled === false ? 'warn' : 'ok', tag: ssid.enabled === false ? 'off' : 'on'});
  });
  return tiles;
}
function reading(value, unit, label, small) {
  var box = el('div', 'reading' + (small ? ' small' : ''));
  var v = el('div', 'v');
  v.innerHTML = esc(value === null || value === undefined ? '\u2013' : String(value))
    + (unit ? '<span class="unit">' + esc(unit) + '</span>' : '');
  box.appendChild(v);
  box.appendChild(el('div', 'l', label));
  return box;
}

// A question with a text answer, in the dashboard's own dialog rather than the
// browser's: askText(title, hint, initial).then(function (value) {...}); a
// cancelled dialog resolves to null.
function askText(title, hint, initial, validate) {
  return new Promise(function (resolve) {
    var back = $('askback'), input = $('askinput'), err = $('askerr');
    $('asktitle').textContent = title; $('askwhat').textContent = hint || ''; err.textContent = '';
    input.value = initial || ''; back.hidden = false;
    setTimeout(function () { input.focus(); input.select(); }, 30);
    function done(value) { back.hidden = true; input.onkeydown = null; $('askok').onclick = $('askcancel').onclick = null; resolve(value); }
    function ok() {
      var v = input.value.trim();
      if (validate) { var why = validate(v); if (why) { err.textContent = why; input.focus(); return; } }
      done(v);
    }
    $('askok').onclick = ok;
    $('askcancel').onclick = function () { done(null); };
    input.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); ok(); } if (e.key === 'Escape') { e.preventDefault(); done(null); } };
    back.onclick = function (e) { if (e.target === back) done(null); };
  });
}

// ---- sections: named folds inside an editor ----------------------------------
// An editor lays its rows out flat; sectionise() then folds them under the
// section each row names (row._model.group), in the order the editor keeps
// (STORE.groups, then first appearance), with the rows that name none last
// under "Everything else". Sections fold (closed by default, remembered
// per session), rename, delete (rows go back to the loose pile), and both
// the rows and the sections drag: a row into another section, a section
// above another. All of it is part of that editor's unsaved changes.
var SECTION_OPEN = {};
try { SECTION_OPEN = JSON.parse(sessionStorage.getItem('zigmon-sections') || '{}') || {}; } catch (e) {}
function rememberSections() { try { sessionStorage.setItem('zigmon-sections', JSON.stringify(SECTION_OPEN)); } catch (e) {} }
// A column header stands above the folds while the boxes it names are inside
// them, and a fold insets everything it holds. So the header has to take that
// inset too, but only while there are folds - without them the rows are flush
// and an indented header is the thing that looks wrong.
function markHeaderIndent() {
  // Every column header on the page is put over the boxes it names by
  // measuring where those boxes actually start - through folds, packs and
  // drag handles alike - and giving the header the same inset. A gateway
  // from config.json takes no handle and one made here does; a row in a fold
  // is inset by the fold; deciding any of that by rule rather than by
  // measurement is how the gateways were wrong three times over.
  Array.prototype.forEach.call(document.querySelectorAll('[class$="-head"], [class*="-head "]'),
    function (head) {
      var kind = (String(head.className).match(/([a-z0-9]+)-head/) || [])[1];
      if (!kind || !head.classList.contains(kind + '-row')) return;   // a caption, not a table head
      var card = head.closest('.card') || document.body;
      var row = Array.prototype.filter.call(card.querySelectorAll('.' + kind + '-row'),
        function (x) { return !x.classList.contains(kind + '-head'); })[0];
      if (!row) return;
      var inset = 0, walk = row;
      while (walk && walk !== card) {
        inset += parseFloat(getComputedStyle(walk).paddingLeft) || 0;
        walk = walk.parentElement;
      }
      var own = 0, up = head.parentElement;
      while (up && up !== card) { own += parseFloat(getComputedStyle(up).paddingLeft) || 0; up = up.parentElement; }
      head.style.paddingLeft = Math.max(0, inset - own) + 'px';
    });
}

// Move every row of one section to another name, against the list as it
// stands now. A row holds the object it was built with, and a redraw replaces
// those objects with fresh copies read from the state - so writing through
// the row's own copy renamed something that had already been thrown away:
// the rows kept the old name and the new one appeared empty beside it.
function regroupRows(store, from, to) {
  var moved = 0;
  (store.rows || []).forEach(function (row) {
    if (String(row.group || '') === String(from)) { row.group = to; moved++; }
  });
  return moved;
}

function sectionise(host, store, editor, mark, redraw) {
  var rows = Array.prototype.filter.call(host.children, function (n) { return n._model; });
  var loose = Array.prototype.filter.call(host.children, function (n) { return !n._model && !n.classList.contains('section'); });
  var server = (((STATE.status || {}).editor_groups || {})[editor] || []).slice();
  var order = (store.dirty && store.groups) ? store.groups.slice() : server;
  store.groups = order;
  rows.forEach(function (r) { var g = groupOf(r._model); if (g && order.indexOf(g) < 0) order.push(g); });
  store.groups = order;
  function addBar() {
    var bar = el('div', 'btnrow section-add');
    var add = el('button', 'btn cmd small needs-unlock', 'Add section'); add.type = 'button';
    setButtonIcon(add, 'add');
    add.title = 'A named fold to keep these rows tidy; drag rows into it';
    add.onclick = function () {
      askText('New section', 'A fold with a name, to keep these rows tidy. Drag rows into it afterwards.', '',
              function (v) { return !v ? 'Give it a name' : (store.groups.indexOf(v.slice(0, 40)) >= 0 ? 'There is a section of that name already' : ''); })
        .then(function (name) {
          if (!name) return;
          name = name.slice(0, 40);
          store.groups.push(name); SECTION_OPEN[editor + ':' + name] = true; rememberSections(); mark(); redraw();
        });
    };
    bar.appendChild(add); return bar;
  }
  if (!order.length) {
    host.appendChild(addBar());
    setTimeout(markHeaderIndent, 0);
    return;                                       // nothing named yet: the flat list stays
  }
  host.innerHTML = '';
  loose.filter(function (n) { return n.classList.contains('bind-head') || n.classList.contains('tap-head') || n.classList.contains('person-head') || n.classList.contains('ptrig-head') || n.classList.contains('mchan-head') || n.classList.contains('gw-head') || n.classList.contains('rule-head'); })
       .forEach(function (n) { host.appendChild(n); });
  var byGroup = {}; rows.forEach(function (r) { var g = groupOf(r._model); (byGroup[g] = byGroup[g] || []).push(r); });
  var groupsHost = el('div', 'sections'); groupsHost.dataset.editor = editor;
  function section(name) {
    var key = editor + ':' + name;
    var open = SECTION_OPEN[key] === true;
    var box = el('div', 'section' + (open ? ' open' : '')); box.dataset.group = name;
    var head = el('div', 'section-head');
    var fold = el('span', 'fold', open ? '\u25be' : '\u25b8');
    var title = el('span', 'section-name', name || 'Everything else');
    var n = (byGroup[name] || []).length;
    var count = el('span', 'section-count', n + (n === 1 ? ' item' : ' items'));
    head.appendChild(fold); head.appendChild(title); head.appendChild(count);
    head.onclick = function (e) {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
      SECTION_OPEN[key] = !(SECTION_OPEN[key] === true); rememberSections(); box.classList.toggle('open', SECTION_OPEN[key]);
      fold.textContent = SECTION_OPEN[key] ? '\u25be' : '\u25b8';
    };
    var tools = el('span', 'section-tools');
    if (ADD_INTO[editor]) {
      var plus = el('button', 'btn small iconbtn needs-unlock'); plus.type = 'button'; plus.innerHTML = iconMarkup('add', 13);
      plus.title = 'Add a new one here, in ' + (name || 'Everything else');
      plus.onclick = function (e) {
        e.stopPropagation();
        var before = (store.rows || []).length;
        $(ADD_INTO[editor]).onclick();                 // the editor's own Add, with its defaults
        (store.rows || []).slice(before).forEach(function (m) { m.group = name; });
        SECTION_OPEN[key] = true; rememberSections(); mark(); redraw();
      };
      tools.appendChild(plus);
    }
    if (name) {
      var ren = el('button', 'btn small iconbtn needs-unlock'); ren.type = 'button'; ren.innerHTML = iconMarkup('pencil', 13); ren.title = 'Rename this section';
      ren.onclick = function (e) {
        e.stopPropagation();
        askText('Rename section', 'The rows stay where they are; only the name changes.', name,
                function (v) { return !v ? 'Give it a name' : (v !== name && store.groups.indexOf(v.slice(0, 40)) >= 0 ? 'There is a section of that name already' : ''); })
          .then(function (fresh) {
            if (!fresh) return;
            fresh = fresh.slice(0, 40); if (fresh === name) return;
            regroupRows(store, name, fresh);
            store.groups = store.groups.map(function (g) { return g === name ? fresh : g; });
            var was = SECTION_OPEN[key]; delete SECTION_OPEN[key]; SECTION_OPEN[editor + ':' + fresh] = was; rememberSections();
            mark(); redraw();
          });
      };
      var drop = el('button', 'btn small iconbtn danger needs-unlock'); drop.type = 'button'; drop.innerHTML = iconMarkup('trash', 13); drop.title = 'Remove this section (its rows go to Everything else)';
      drop.onclick = function (e) {
        e.stopPropagation();
        regroupRows(store, name, '');
        store.groups = store.groups.filter(function (g) { return g !== name; });
        mark(); redraw();
      };
      tools.appendChild(ren); tools.appendChild(drop);
      // the section itself drags above another section
      var grip = el('span', 'rowgrab'); grip.innerHTML = '\u2807'; grip.title = 'Drag to move this section';
      grip.addEventListener('mousedown', function () { box.draggable = true; ROWARMED = box; });
      head.insertBefore(grip, head.firstChild); head.classList.add('hasgrab');
      box.addEventListener('dragstart', function (e) {
        if (ROWDRAG) return;
        SECDRAG = {host: groupsHost, node: box}; box.classList.add('dragrow');
        if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', 'section'); } catch (err) {} }
        e.stopPropagation();
      });
      box.addEventListener('dragend', function (e) {
        box.classList.remove('dragrow'); box.draggable = false; e.stopPropagation();
        if (!SECDRAG) return;
        SECDRAG = null;
        store.groups = Array.prototype.map.call(groupsHost.children, function (b) { return b.dataset.group; }).filter(Boolean);
        var models = []; Array.prototype.forEach.call(groupsHost.querySelectorAll('.section'), function (b) {
          Array.prototype.forEach.call(b.querySelector('.section-body').children, function (n) { if (n._model) models.push(n._model); });
        });
        store.rows = flattenModels(models); mark(); redraw();
      });
    }
    head.appendChild(tools);
    box.addEventListener('dragover', function (e) {
      if (SECDRAG && SECDRAG.node !== box) {
        e.preventDefault(); e.stopPropagation();
        var sib = Array.prototype.slice.call(groupsHost.children);
        if (sib.indexOf(SECDRAG.node) < sib.indexOf(box)) groupsHost.insertBefore(SECDRAG.node, box.nextSibling); else groupsHost.insertBefore(SECDRAG.node, box);
        return;
      }
      if (ROWDRAG && ROWDRAG.set === host) {   // a row over a section: drop it in, at the end
        e.preventDefault(); e.stopPropagation();
        var bodyEl = box.querySelector('.section-body');
        if (ROWDRAG.node.parentNode !== bodyEl) { bodyEl.appendChild(ROWDRAG.node); box.classList.add('open'); }
      }
    });
    box.appendChild(head);
    var body = el('div', 'section-body'); body.dataset.group = name;
    (byGroup[name] || []).forEach(function (r) {
      body.appendChild(r);
      r.addEventListener('contextmenu', function (e) { e.preventDefault(); e.stopPropagation(); showMoveMenu(e.clientX, e.clientY, r, store, editor, mark, redraw); });
      var g = r.querySelector(':scope > .rowgrab');
      if (g) { g.title = 'Drag to reorder \u00b7 click for "move to section"'; g.addEventListener('click', function (e) { e.stopPropagation(); var b = g.getBoundingClientRect(); showMoveMenu(b.left, b.bottom + 4, r, store, editor, mark, redraw); }); }
    });
    if (!(byGroup[name] || []).length) body.appendChild(el('div', 'muted small', name ? 'empty \u2014 drag rows here' : 'nothing here'));
    box.appendChild(body);
    return box;
  }
  order.forEach(function (g) { groupsHost.appendChild(section(g)); });
  groupsHost.appendChild(section(''));
  host.appendChild(groupsHost);
  loose.filter(function (n) { return !/head/.test(n.className); }).forEach(function (n) { host.appendChild(n); });
  host.appendChild(addBar());
}
// The editors' own Add buttons, so a section can add straight into itself.
var ADD_INTO = {bindings: 'binding-add', rules: 'rule-add', scenes: 'scene-add', sequences: 'sequence-add',
                schedules: 'schedule-add', ptrig: 'ptrig-add', messages: 'message-add', managed: 'managed-add-plug',
                sgroups: 'sgroup-add', agroups: 'agroup-add', smscmd: 'smscmd-add',
                taps: 'tap-add'};
// "Move to section": a small menu by the row, from a right-click or its grip.
var MOVEMENU = null;
function hideMoveMenu() { if (MOVEMENU) { MOVEMENU.remove(); MOVEMENU = null; } }
document.addEventListener('click', function () { hideMoveMenu(); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideMoveMenu(); });
function showMoveMenu(x, y, row, store, editor, mark, redraw) {
  hideMoveMenu();
  var current = groupOf(row._model);
  var menu = el('div', 'movemenu');

  // A row's own menu: put one beside it, copy this one, or move it to another
  // section. The copy keeps everything but the identity, so it saves as a new
  // row rather than overwriting the one it came from.
  var rows = store.rows || [];
  var models = Array.isArray(row._model) ? row._model : [row._model];
  var at = rows.indexOf(models[0]);
  if (at < 0 && models[0] && models[0].id) {
    // an editor that rebuilds its rows from the state on every paint hands
    // the row a model that is no longer the one in the list, only an equal
    // copy of it - so look it up by identity as well as by reference
    for (var mi = 0; mi < rows.length; mi++) {
      if (rows[mi] && rows[mi].id === models[0].id) { at = mi; models = [rows[mi]]; break; }
    }
  }
  function blank() {
    var maker = ADD_INTO[editor] && $(ADD_INTO[editor]);
    if (!maker) return null;
    var before = rows.length;
    maker.onclick();                              // the editor's own Add, with its defaults
    var made = (store.rows || []).slice(before);
    (store.rows || []).splice((store.rows || []).length - made.length, made.length);
    return made.length ? made[0] : null;
  }
  function put(model, where) {
    if (!model || at < 0) return;
    model.group = current;
    (store.rows || []).splice(where === 'before' ? at : at + 1, 0, model);
    hideMoveMenu(); mark(); redraw();
  }
  function copyOf() {
    var copy = JSON.parse(JSON.stringify(models[0]));
    copy.id = '';                                  // a copy is a new row, not the same one twice
    if (copy.name) copy.name = copy.name + ' (copy)';
    if (copy.phrase) copy.phrase = copy.phrase + ' 2';
    return copy;
  }
  if (at >= 0 && ADD_INTO[editor]) {
    menu.appendChild(el('div', 'mm-head', 'This row'));
    [['\u2795 Add a new one above', function () { put(blank(), 'before'); }],
     ['\u2795 Add a new one below', function () { put(blank(), 'after'); }],
     ['\u29c9 Copy this one above', function () { put(copyOf(), 'before'); }],
     ['\u29c9 Copy this one below', function () { put(copyOf(), 'after'); }]].forEach(function (pair) {
      var b = el('button', 'mm-item', pair[0]); b.type = 'button';
      b.onclick = function (e) { e.stopPropagation(); pair[1](); };
      menu.appendChild(b);
    });
  }
  menu.appendChild(el('div', 'mm-head', 'Move to'));
  function setGroup(name) {
    var models = Array.isArray(row._model) ? row._model : [row._model];
    models.forEach(function (m) { m.group = name; });
    if (name && store.groups.indexOf(name) < 0) store.groups.push(name);
    SECTION_OPEN[editor + ':' + name] = true; rememberSections();
    hideMoveMenu(); mark(); redraw();
  }
  (store.groups || []).concat(['']).forEach(function (g) {
    var it = el('button', 'mm-item' + (g === current ? ' on' : ''), (g || 'Everything else') + (g === current ? ' \u2713' : '')); it.type = 'button';
    it.onclick = function (e) { e.stopPropagation(); if (g !== current) setGroup(g); else hideMoveMenu(); };
    menu.appendChild(it);
  });
  var fresh = el('button', 'mm-item mm-new', '\u2795 New section\u2026'); fresh.type = 'button';
  fresh.title = 'Make a section and move this row into it';
  fresh.onclick = function (e) {
    e.stopPropagation(); hideMoveMenu();
    askText('New section', 'The row moves into it.', '', function (v) { return v ? '' : 'Give it a name'; }).then(function (name) { if (name) setGroup(name.slice(0, 40)); });
  };
  menu.appendChild(fresh);
  document.body.appendChild(menu);
  var w = menu.offsetWidth || 200, h = menu.offsetHeight || 160;
  menu.style.left = Math.max(8, Math.min(x, window.innerWidth - w - 10)) + 'px';
  menu.style.top = Math.max(8, Math.min(y, window.innerHeight - h - 10)) + 'px';
  MOVEMENU = menu;
}
function groupOf(model) { return Array.isArray(model) ? String((model[0] || {}).group || '') : String((model || {}).group || ''); }
function flattenModels(models) { return models.reduce(function (a, m) { return a.concat(Array.isArray(m) ? m : [m]); }, []); }
var SECDRAG = null;
// the section order rides along with the editor's save (the session is
// already unlocked at that point, so no second PIN)
function saveGroups(editor, store) {
  var groups = (store.groups || []).slice();
  store.groups = null;                                   // reread from status after the save
  return post('groups-save', {editor: editor, groups: groups}).then(function () {}, function () {});
}

// ---- dragging a row to reorder a list ----------------------------------------
// The order these editors show is the order they are saved in, and for
// bindings, rules and scenes it is the order they FIRE in - so being able to
// move one up is worth having. Grab the handle on the left, drop it where it
// belongs; the section's own Save button writes it, like any other edit.
var ROWDRAG = null, ROWARMED = null, ROWDROPPED = 0;
document.addEventListener('mouseup', function () { if (!ROWDRAG && ROWARMED) { ROWARMED.draggable = false; ROWARMED = null; } });
function makeRowSortable(row, host, store, mark, redraw, model) {
  row._model = model;                 // the sections need this whether or not editing is unlocked
  if (!isUnlocked()) return;
  row.classList.add('hasgrab');
  var grip = el('span', 'rowgrab');
  grip.innerHTML = '\u2807';
  grip.title = 'Drag to reorder \u2014 the new order is kept when you save this section';
  // the row is only draggable while the handle is held, so text in the fields
  // can still be selected the ordinary way
  grip.addEventListener('mousedown', function () { row.draggable = true; ROWARMED = row; });
  grip.addEventListener('touchstart', function () { row.draggable = true; ROWARMED = row; }, {passive: true});
  row.insertBefore(grip, row.firstChild);
  row.addEventListener('dragstart', function (e) {
    ROWDRAG = {host: host, node: row, set: host};
    row.classList.add('dragrow');
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', 'row'); } catch (err) {} }
    e.stopPropagation();
  });
  row.addEventListener('dragover', function (e) {
    if (!ROWDRAG || ROWDRAG.set !== host || ROWDRAG.node === row) return;
    e.preventDefault(); e.stopPropagation();
    var parent = row.parentNode, sib = Array.prototype.slice.call(parent.children);
    if (ROWDRAG.node.parentNode === parent && sib.indexOf(ROWDRAG.node) < sib.indexOf(row)) parent.insertBefore(ROWDRAG.node, row.nextSibling);
    else parent.insertBefore(ROWDRAG.node, row);
  });
  row.addEventListener('dragend', function (e) {
    row.classList.remove('dragrow'); row.draggable = false;
    e.stopPropagation();
    if (!ROWDRAG) return;
    ROWDRAG = null;
    ROWDROPPED = Date.now();      // and a moment's grace after it, as the cards have
    var before = JSON.stringify(store.rows);   // taken before any row's section is rewritten below
    var models = [];
    // rows may now sit in section bodies; walk them in order, and a row's
    // section is the body it was dropped in
    var bodies = host.querySelectorAll('.section-body');
    var scan = bodies.length ? Array.prototype.slice.call(bodies) : [host];
    scan.forEach(function (b) {
      var g = b.dataset ? (b.dataset.group || '') : '';
      Array.prototype.forEach.call(b.children, function (n) {
        if (!n._model) return;
        // the live row, found by id: the one the node was built with may have
        // been replaced by a redraw, and writing to that is writing to nothing
        if (bodies.length) {
          var each = Array.isArray(n._model) ? n._model : [n._model];
          each.forEach(function (m) {
            var live = m && m.id ? (store.rows || []).filter(function (x) { return x.id === m.id; })[0] : null;
            (live || m).group = g;
          });
        }
        if (Array.isArray(n._model)) models = models.concat(n._model);
        else models.push(n._model);
      });
    });
    if (!models.length) return;
    var after = JSON.stringify(models);
    store.rows = models;
    if (before !== after) mark();
    if (redraw) redraw();          // the row handlers close over their index
  });
}

// Copying without a clipboard permission: the modern call needs a secure page
// and the browser's blessing, and when it refuses it does so silently - so the
// old textarea trick is the fallback, and a failure says so rather than
// looking like a dead button.
function copyText(text) {
  function fallback() {
    var t = document.createElement('textarea');
    t.value = text; t.setAttribute('readonly', '');
    t.style.position = 'fixed'; t.style.top = '-1000px';
    document.body.appendChild(t);
    t.select(); t.setSelectionRange(0, t.value.length);
    var done = false;
    try { done = document.execCommand('copy'); } catch (e) {}
    t.remove();
    toast(done ? 'Copied' : 'Could not copy \u2014 select it and copy by hand', done);
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function () { toast('Copied', true); }, fallback);
  } else fallback();
}

// ---- what a sensor reads right now, over the field that asks about it --------
// Hovering the source, the reading or the threshold of a rule shows the
// device's current values with the chosen one marked, so a threshold is set
// against what is, not from memory.
var READPOP = null;
function showReadings(anchor, getDevice, getKey) {
  hideReadings();
  var d = deviceById(getDevice()); if (!d) return;
  var key = getKey();
  var pop = el('div', 'readpop');
  var head = el('div', 'rp-head');
  head.appendChild(el('span', 'rp-name', deviceIcon(d) + ' ' + d.name));
  head.appendChild(el('span', 'rp-when', d.last_seen ? ago(d.last_seen) : 'never reported'));
  pop.appendChild(head);
  var values = d.values || {}, keys = Object.keys(values);
  var order = keys.filter(function (k) { return k === key; }).concat(keys.filter(function (k) { return k !== key; }));
  var list = el('div', 'rp-list');
  order.slice(0, 14).forEach(function (k) {
    var v = values[k] || {}, val = v.value;
    var row = el('div', 'rp-row' + (k === key ? ' pick' : ''));
    row.appendChild(el('span', 'rp-k', v.label || k));
    var shown = val === null || val === undefined ? '\u2013' : (typeof val === 'boolean' ? (val ? 'yes (1)' : 'no (0)') : (typeof val === 'number' ? fmt(val, 2) : String(val)));
    row.appendChild(el('span', 'rp-v', shown + (v.unit ? ' ' + v.unit : '')));
    list.appendChild(row);
  });
  if (order.length > 14) list.appendChild(el('div', 'muted small', '\u2026 and ' + (order.length - 14) + ' more under All values'));
  if (!keys.length) list.appendChild(el('div', 'muted small', 'nothing reported yet'));
  pop.appendChild(list);
  if (d.last_action && (d.last_action.action || d.last_action.value)) pop.appendChild(el('div', 'rp-foot', 'last press: ' + (d.last_action.action || d.last_action.value) + (d.last_action.ts ? ' \u00b7 ' + ago(d.last_action.ts) : '')));
  document.body.appendChild(pop);
  var r = anchor.getBoundingClientRect();
  var top = r.bottom + 6;
  if (top + pop.offsetHeight + 10 > window.innerHeight) top = Math.max(8, r.top - pop.offsetHeight - 6);
  pop.style.top = top + 'px';
  pop.style.left = Math.max(8, Math.min(r.left, window.innerWidth - pop.offsetWidth - 12)) + 'px';
  READPOP = pop;
}
function hideReadings() { if (READPOP) { READPOP.remove(); READPOP = null; } }
// A target is a socket, a Zigbee switch, a room's heating or a scene; hovering
// over the picker should say what that thing is doing right now, the same way
// hovering over a rule's source says what it last reported.
function attachTargetReadings(node, getTarget) {
  attachReadings(node, function () {
    var t = String(getTarget() || '');
    if (t.indexOf('zb:') === 0) return t.split(':')[1];
    if (t.indexOf(':') < 0 && t !== '*') return t;      // a plug, by name
    return '';
  }, function () {
    var t = String(getTarget() || '');
    return t.indexOf('zb:') === 0 ? t.split(':').pop() : '';
  });
  // a scene, a room, a rule: no readings to show, but the tooltip can say
  // what the thing is and what state it is in
  var refresh = function () {
    var t = String(getTarget() || ''), st = STATE.status || {}, text = '';
    if (t.indexOf('scene:') === 0) {
      var sc = (st.scenes || []).filter(function (x) { return 'scene:' + x.id === t; })[0];
      // /api/status carries a scene's action count, the editor its actions
      if (sc) {
        var acts = Array.isArray(sc.actions) ? sc.actions : [];
        // status says how many steps there are, the editor sends the steps
        // themselves - the same word for two shapes, so read the plain one
        // when it is there
        var count = sc.action_count !== undefined ? sc.action_count
          : (Array.isArray(sc.actions) ? acts.length : (sc.actions || 0));
        text = 'The scene \u201c' + sc.name + '\u201d: ' + count + ' action(s)'
          + (acts.length ? ' \u2014 ' + acts.slice(0, 4).map(function (a) { return targetLabel(st, a.target) + ' ' + a.do; }).join(', ') : '');
      }
    } else if (t.indexOf('heat:') === 0) {
      var rid = t.split(':').pop();
      var room = ((st.heating || {}).rooms || []).filter(function (r) { return r.id === rid; })[0];
      if (room) text = room.name + ': ' + (isNum(room.temperature) ? fmt(room.temperature, 1) + ' \u00b0C now, ' : '')
        + (isNum(room.wanted_c) ? 'holding ' + fmt(room.wanted_c, 1) + ' \u00b0C (' + room.why + ')' : 'not controlled');
      else if (t === 'heat:control') text = 'The heating control itself';
      else if (t === 'heat:away') text = 'Away mode';
    } else if (/^(rule:|sched:|bindgroup:)/.test(t)) {
      var sw = (st.switchable_targets || []).filter(function (x) { return x.value === t; })[0];
      if (sw) text = sw.name + ' \u2014 currently ' + (sw.on ? 'on' : 'off');
    } else if (t === '*') {
      text = 'Every switchable socket at once';
    }
    node.title = text || '';
  };
  node.addEventListener('mouseenter', refresh);
  node.addEventListener('focus', refresh);
}
function attachReadings(node, getDevice, getKey) {
  node.addEventListener('mouseenter', function () { showReadings(node, getDevice, getKey); });
  node.addEventListener('mouseleave', hideReadings);
  node.addEventListener('focus', function () { showReadings(node, getDevice, getKey); });
  node.addEventListener('blur', hideReadings);
}

// ---- a QR code, so a phone can take a link off the screen ---------------------
// A QR code, byte mode, error level L, versions 1-10 - enough for a URL with
// a token in it. Written out rather than pulled in: the dashboard has no
// build step and no libraries.
function qrMatrix(text) {
  var forceMask = null;
  var bytes = [];
  for (var i = 0; i < text.length; i++) {
    var c = text.charCodeAt(i);
    if (c < 0x80) bytes.push(c);
    else if (c < 0x800) { bytes.push(0xc0 | (c >> 6), 0x80 | (c & 63)); }
    else { bytes.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63)); }
  }
  // per version at level L: [data codewords, ec codewords per block, blocks in group 1, blocks in group 2]
  var CAP = [null,
    [19, 7, 1, 0], [34, 10, 1, 0], [55, 15, 1, 0], [80, 20, 1, 0], [108, 26, 1, 0],
    [136, 18, 2, 0], [156, 20, 2, 0], [194, 24, 2, 0], [232, 30, 2, 0], [274, 18, 2, 2]];
  var version = 0;
  for (var v = 1; v <= 10; v++) {
    var countBits = v < 10 ? 8 : 16;
    if (bytes.length <= Math.floor((CAP[v][0] * 8 - 4 - countBits) / 8)) { version = v; break; }
  }
  if (!version) return null;                       // too long for what we support
  var spec = CAP[version], countBits = version < 10 ? 8 : 16;
  // ---- the bit stream
  var bits = [];
  function put(value, len) { for (var i = len - 1; i >= 0; i--) bits.push((value >> i) & 1); }
  put(4, 4); put(bytes.length, countBits);
  bytes.forEach(function (b) { put(b, 8); });
  var total = spec[0] * 8;
  for (var i = 0; i < 4 && bits.length < total; i++) bits.push(0);
  while (bits.length % 8) bits.push(0);
  var pad = [0xec, 0x11], p = 0;
  while (bits.length < total) { put(pad[p++ % 2], 8); }
  var data = [];
  for (var i = 0; i < bits.length; i += 8) {
    var b = 0; for (var k = 0; k < 8; k++) b = (b << 1) | bits[i + k];
    data.push(b);
  }
  // ---- Reed-Solomon over GF(256)
  var EXP = new Array(512), LOG = new Array(256), x = 1;
  for (var i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
  for (var i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  function mul(a, b) { return a && b ? EXP[LOG[a] + LOG[b]] : 0; }
  function generator(n) {
    var g = [1];
    for (var i = 0; i < n; i++) {
      var next = g.concat([0]);
      for (var j = 0; j < g.length; j++) next[j + 1] ^= mul(g[j], EXP[i]);
      g = next;
    }
    return g;
  }
  var ecCount = spec[1], g = generator(ecCount);
  var blocks1 = spec[2], blocks2 = spec[3], totalBlocks = blocks1 + blocks2;
  var perBlock = Math.floor(spec[0] / totalBlocks);
  var dataBlocks = [], ecBlocks = [], at = 0;
  for (var b = 0; b < totalBlocks; b++) {
    var len = perBlock + (b >= blocks1 ? 1 : 0);
    var block = data.slice(at, at + len); at += len;
    dataBlocks.push(block);
    var rem = block.concat(new Array(ecCount).fill(0));
    for (var i = 0; i < block.length; i++) {
      var factor = rem[i];
      if (!factor) continue;
      for (var j = 0; j < g.length; j++) rem[i + j] ^= mul(g[j], factor);
    }
    ecBlocks.push(rem.slice(block.length));
  }
  var out = [];
  for (var i = 0; i < perBlock + 1; i++)
    dataBlocks.forEach(function (blk) { if (i < blk.length) out.push(blk[i]); });
  for (var i = 0; i < ecCount; i++)
    ecBlocks.forEach(function (blk) { out.push(blk[i]); });
  // ---- the grid
  var size = version * 4 + 17;
  var m = [], reserved = [];
  for (var r = 0; r < size; r++) { m.push(new Array(size).fill(0)); reserved.push(new Array(size).fill(false)); }
  function finder(row, col) {
    for (var r = -1; r <= 7; r++) for (var c = -1; c <= 7; c++) {
      var rr = row + r, cc = col + c;
      if (rr < 0 || cc < 0 || rr >= size || cc >= size) continue;
      var on = (r >= 0 && r <= 6 && (c === 0 || c === 6)) || (c >= 0 && c <= 6 && (r === 0 || r === 6))
            || (r >= 2 && r <= 4 && c >= 2 && c <= 4);
      m[rr][cc] = on ? 1 : 0; reserved[rr][cc] = true;
    }
  }
  finder(0, 0); finder(0, size - 7); finder(size - 7, 0);
  var ALIGN = [[], [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]][version];
  for (var a = 0; a < ALIGN.length; a++) for (var b2 = 0; b2 < ALIGN.length; b2++) {
    var row = ALIGN[a], col = ALIGN[b2];
    if ((row <= 8 && col <= 8) || (row <= 8 && col >= size - 9) || (row >= size - 9 && col <= 8)) continue;
    for (var r = -2; r <= 2; r++) for (var c = -2; c <= 2; c++) {
      m[row + r][col + c] = (Math.max(Math.abs(r), Math.abs(c)) !== 1) ? 1 : 0;
      reserved[row + r][col + c] = true;
    }
  }
  for (var i = 8; i < size - 8; i++) {
    m[6][i] = i % 2 === 0 ? 1 : 0; reserved[6][i] = true;
    m[i][6] = i % 2 === 0 ? 1 : 0; reserved[i][6] = true;
  }
  m[size - 8][8] = 1; reserved[size - 8][8] = true;          // the dark module
  for (var i = 0; i <= 8; i++) { if (i !== 6) { reserved[8][i] = true; reserved[i][8] = true; } }
  reserved[8][6] = true; reserved[6][8] = true;
  for (var i = 0; i < 8; i++) { reserved[8][size - 1 - i] = true; reserved[size - 1 - i][8] = true; }
  if (version >= 7) for (var i = 0; i < 18; i++) {
    var r = Math.floor(i / 3), c = i % 3;
    reserved[size - 11 + c][r] = true; reserved[r][size - 11 + c] = true;
  }
  // ---- the payload, up the right-hand side and back down
  var bitAt = 0, allBits = [];
  out.forEach(function (b) { for (var i = 7; i >= 0; i--) allBits.push((b >> i) & 1); });
  var col = size - 1, upward = true;
  while (col > 0) {
    if (col === 6) col--;
    for (var i = 0; i < size; i++) {
      var row = upward ? size - 1 - i : i;
      for (var k = 0; k < 2; k++) {
        var c = col - k;
        if (reserved[row][c]) continue;
        m[row][c] = bitAt < allBits.length ? allBits[bitAt++] : 0;
      }
    }
    col -= 2; upward = !upward;
  }
  // ---- masks, and the least ugly of them
  function maskFn(n, r, c) {
    switch (n) {
      case 0: return (r + c) % 2 === 0;
      case 1: return r % 2 === 0;
      case 2: return c % 3 === 0;
      case 3: return (r + c) % 3 === 0;
      case 4: return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
      case 5: return ((r * c) % 2) + ((r * c) % 3) === 0;
      case 6: return (((r * c) % 2) + ((r * c) % 3)) % 2 === 0;
      default: return (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
    }
  }
  var FORMAT_L = [0x77c4, 0x72f3, 0x7daa, 0x789d, 0x662f, 0x6318, 0x6c41, 0x6976];
  var VERSION_BITS = [0, 0, 0, 0, 0, 0, 0, 0x07c94, 0x085bc, 0x09a99, 0x0a4d3];
  function withMask(mask) {
    var g2 = m.map(function (row) { return row.slice(); });
    for (var r = 0; r < size; r++) for (var c = 0; c < size; c++)
      if (!reserved[r][c] && maskFn(mask, r, c)) g2[r][c] ^= 1;
    var fmt = FORMAT_L[mask];
    for (var i = 0; i < 15; i++) {
      var bit = (fmt >> i) & 1;
      // the copy down the left of the top-right, and the one along the top of
      // the bottom-left, read from the least significant bit outwards
      if (i < 6) g2[i][8] = bit;
      else if (i < 8) g2[i + 1][8] = bit;
      else g2[size - 15 + i][8] = bit;
      if (i < 8) g2[8][size - 1 - i] = bit;
      else if (i < 9) g2[8][15 - i] = bit;
      else g2[8][14 - i] = bit;
    }
    g2[size - 8][8] = 1;
    if (version >= 7) {
      var vb = VERSION_BITS[version];
      for (var i = 0; i < 18; i++) {
        var bit = (vb >> i) & 1, r = Math.floor(i / 3), c = i % 3;
        g2[size - 11 + c][r] = bit; g2[r][size - 11 + c] = bit;
      }
    }
    return g2;
  }
  function penalty(g2) {
    var score = 0, dark = 0;
    for (var r = 0; r < size; r++) {
      var run = 1;
      for (var c = 1; c < size; c++) {
        if (g2[r][c] === g2[r][c - 1]) { run++; if (run === 5) score += 3; else if (run > 5) score++; }
        else run = 1;
      }
    }
    for (var c = 0; c < size; c++) {
      var run = 1;
      for (var r = 1; r < size; r++) {
        if (g2[r][c] === g2[r - 1][c]) { run++; if (run === 5) score += 3; else if (run > 5) score++; }
        else run = 1;
      }
    }
    for (var r = 0; r < size - 1; r++) for (var c = 0; c < size - 1; c++)
      if (g2[r][c] === g2[r][c + 1] && g2[r][c] === g2[r + 1][c] && g2[r][c] === g2[r + 1][c + 1]) score += 3;
    var pat1 = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], pat2 = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    function look(get) {
      for (var i = 0; i + 11 <= size; i++) {
        var ok1 = true, ok2 = true;
        for (var k = 0; k < 11; k++) { var v2 = get(i + k); if (v2 !== pat1[k]) ok1 = false; if (v2 !== pat2[k]) ok2 = false; }
        if (ok1) score += 40;
        if (ok2) score += 40;
      }
    }
    for (var r = 0; r < size; r++) look(function (i) { return g2[r][i]; });
    for (var c = 0; c < size; c++) look(function (i) { return g2[i][c]; });
    for (var r = 0; r < size; r++) for (var c = 0; c < size; c++) if (g2[r][c]) dark++;
    score += Math.floor(Math.abs(dark * 100 / (size * size) - 50) / 5) * 10;
    return score;
  }
  if (forceMask !== undefined && forceMask !== null) return withMask(forceMask);
  var best = null, bestScore = Infinity;
  for (var mask = 0; mask < 8; mask++) {
    var candidate = withMask(mask), sc = penalty(candidate);
    if (sc < bestScore) { bestScore = sc; best = candidate; }
  }
  return best;
}

function qrSvg(text, px) {
  var m = qrMatrix(text);
  if (!m) return null;
  var n = m.length, quiet = 3, size = n + quiet * 2, parts = [];
  for (var r = 0; r < n; r++) {
    var c = 0;
    while (c < n) {
      if (!m[r][c]) { c++; continue; }
      var start = c;
      while (c < n && m[r][c]) c++;
      parts.push('M' + (start + quiet) + ' ' + (r + quiet) + 'h' + (c - start) + 'v1h-' + (c - start) + 'z');
    }
  }
  return '<svg xmlns="http://www.w3.org/2000/svg" width="' + px + '" height="' + px + '" viewBox="0 0 ' + size + ' ' + size + '" shape-rendering="crispEdges">'
    + '<rect width="' + size + '" height="' + size + '" fill="#fff"/><path d="' + parts.join('') + '" fill="#000"/></svg>';
}
// hovering a copy chip shows what the phone should scan
var QRPOP = null;
function showQr(chip) {
  var svg = qrSvg(chip.dataset.copy, 190);
  if (!svg) return;
  hideQr();
  QRPOP = el('div', 'qrpop');
  QRPOP.innerHTML = svg + '<div class="qrcap">point the phone at it</div>';
  document.body.appendChild(QRPOP);
  var r = chip.getBoundingClientRect();
  var top = r.bottom + 6;
  if (r.bottom + QRPOP.offsetHeight + 10 > window.innerHeight) top = Math.max(8, r.top - QRPOP.offsetHeight - 6);
  QRPOP.style.top = top + 'px';
  QRPOP.style.left = Math.max(8, Math.min(r.left, window.innerWidth - QRPOP.offsetWidth - 12)) + 'px';
}
function hideQr() { if (QRPOP) { QRPOP.remove(); QRPOP = null; } }

// ---- What it is drawing ------------------------------------------------------
// Click the strip and the house's own history opens under it, on the same
// chart the rest of the page uses: drag to pan, wheel to zoom, double-click
// to come back. One line for everything, one for the sockets, one for the
// lights - twenty sockets laid over each other would say nothing at all.
var POWER_OPEN = false, POWER_ROWS = null, POWER_RANGE = '24h';
function loadPowerSeries(quiet) {
  api('power-series&range=' + POWER_RANGE).then(function (r) {
    POWER_ROWS = (r && r.rows) || [];
    paintPowerChart();
  }, function (e) { if (!quiet) toast(e.message || String(e), false); });
}
function paintPowerChart() {
  var wrap = $('power-chart-wrap');
  if (!wrap) return;
  wrap.hidden = !POWER_OPEN;
  $('power-range').textContent = POWER_OPEN ? POWER_RANGE + ' \u00b7 click to close' : 'click for the history';
  if (!POWER_OPEN || !POWER_ROWS) return;
  var pick = function (key) { return POWER_ROWS.map(function (x) { return [x.ts, x[key]]; }); };
  var series = [{name: 'everything', color: COLORS[0], unit: 'W', points: pick('all')},
                {name: 'sockets', color: COLORS[1], unit: 'W', points: pick('sockets')},
                {name: 'lights', color: COLORS[2], unit: 'W', points: pick('lights')}];
  drawChart($('power-chart'), series, {spanS: spanSeconds(POWER_RANGE), outages: CHART_OUTAGES});
  legend($('power-chart-legend'), series);
}
function togglePowerChart() {
  POWER_OPEN = !POWER_OPEN;
  paintPowerChart();
  if (POWER_OPEN && !POWER_ROWS) loadPowerSeries();
}

// The metered sockets added up, this moment: the house, and what of it is
// sockets and what is lights. Beside them the most it has drawn in the last
// hour, day and week - the hour from what the daemon has watched pass, the
// other two from the hourly figures.
function renderPower(st) {
  var p = st.power || {}, card = $('power-card'), host = $('power-body');
  card.hidden = !(p.total > 0 || p.sockets > 0 || p.lights > 0);
  if (card.hidden) return;
  if (!sigChanged('power', [p])) return;
  host.innerHTML = '';
  var watts = function (w) { return w == null ? '\u2014' : (w >= 1000 ? fmt(w / 1000, 2) + ' kW' : fmt(w, 0) + ' W'); };
  function box(label, big, sub, title) {
    var b = el('div');
    b.appendChild(el('div', 'money-lbl', label));
    b.appendChild(el('div', 'money-big', big));
    if (sub) b.appendChild(el('div', 'money-sub', sub));
    if (title) b.title = title;
    return b;
  }
  host.appendChild(box('Right now', watts(p.total),
    'everything with a meter', 'Every metered socket added up, as of its last reading'));
  host.appendChild(box(withIcon('plug', 'Sockets'), watts(p.sockets),
    (p.sockets_on || 0) + ' of them on', 'The ones whose role is a socket'));
  host.appendChild(box(withIcon('light', 'Lights'), watts(p.lights),
    (p.lights_on || 0) + ' of them on', 'The ones whose role is a light'));
  var peaks = p.peaks || {};
  host.appendChild(box('Most in the last hour', watts(peaks.hour), 'the house, minute by minute',
    'The highest the whole house has drawn in any minute of the last hour'));
  host.appendChild(box('Most today', watts(peaks.day), 'the house, hour by hour',
    'The highest hour of the last twenty-four'));
  host.appendChild(box('Most this week', watts(peaks.week), 'the house, hour by hour',
    'The highest hour of the last seven days'));
  var head = card.querySelector('h2');
  head.style.cursor = 'pointer';
  head.onclick = togglePowerChart;
  host.style.cursor = 'pointer';
  host.onclick = togglePowerChart;
  paintPowerChart();
  if (POWER_OPEN) loadPowerSeries(true);
}

// ---- What it costs -----------------------------------------------------------
// The sockets' own meters, in money: what this month has come to so far, what
// it is heading for at that rate, and what last month came to for comparison.
var MONEY_OPEN = false, MONEY_DAYS = null;
function loadMoneyDays() {
  api('energy-daily&plug=' + encodeURIComponent('*')).then(function (r) {
    MONEY_DAYS = (r && r.days) || [];
    paintMoneyChart(STATE.status);
  }, function () { MONEY_DAYS = []; });
}
function paintMoneyChart(st) {
  var wrap = $('money-chart-wrap');
  if (!wrap) return;
  wrap.hidden = !MONEY_OPEN;
  $('money-range').textContent = MONEY_OPEN ? 'day by day \u00b7 click to close' : 'click for the history';
  if (!MONEY_OPEN) return;
  if (!MONEY_DAYS) { loadMoneyDays(); return; }
  var days = MONEY_DAYS;
  if (!days.length) { wrap.hidden = true; return; }
  var m = (st || STATE.status || {}).money || {};
  var price = m.price_per_kwh || 0;
  var series = [{name: price ? 'a day, in ' + (m.currency || '') : 'a day, in kWh', color: COLORS[0],
                 unit: price ? ' ' + (m.currency || '') : ' kWh',
                 points: days.map(function (x) { return [x.ts, price ? (x.wh / 1000) * price : x.wh / 1000]; })}];
  drawChart($('money-chart'), series, {spanS: spanSeconds('30d'), outages: false});
  legend($('money-chart-legend'), series);
}
function toggleMoneyChart() {
  MONEY_OPEN = !MONEY_OPEN;
  paintMoneyChart(STATE.status);
}

function renderMoney(st) {
  var m = st.money || {}, card = $('money-card'), host = $('money-body');
  card.hidden = !(m.month_kwh > 0 || m.last_kwh > 0);
  if (card.hidden) return;
  host.innerHTML = '';
  var cur = m.currency || '';
  function box(label, big, sub, title) {
    var b = el('div');
    b.appendChild(el('div', 'money-lbl', label));
    b.appendChild(el('div', 'money-big', big));
    if (sub) b.appendChild(el('div', 'money-sub', sub));
    if (title) b.title = title;
    return b;
  }
  var head = card.querySelector('h2');
  head.style.cursor = 'pointer';
  head.onclick = toggleMoneyChart;
  host.style.cursor = 'pointer';
  host.onclick = toggleMoneyChart;
  paintMoneyChart(st);                    // the hint, and the chart if it is open
  var pace = m.last_cost > 0 ? Math.round((m.forecast_cost / m.last_cost - 1) * 100) : null;
  host.appendChild(box('This month so far', m.price_per_kwh ? fmt(m.month_cost, 0) + ' ' + cur : fmt(m.month_kwh, 1) + ' kWh',
    fmt(m.month_kwh, 1) + ' kWh over ' + fmt(m.days_in, 1) + ' of ' + m.days_total + ' days',
    'What every metered socket has counted since the first of the month'));
  host.appendChild(box('By the end of the month', m.price_per_kwh ? fmt(m.forecast_cost, 0) + ' ' + cur : fmt(m.forecast_kwh, 1) + ' kWh',
    'at this rate' + (pace === null ? '' : ' \u00b7 ' + (pace > 0 ? '+' : '') + pace + ' % on last month'),
    'This month so far, carried on at the same daily rate to the end of the month'));
  host.appendChild(box('Last month', m.price_per_kwh ? fmt(m.last_cost, 0) + ' ' + cur : fmt(m.last_kwh, 1) + ' kWh',
    fmt(m.last_kwh, 1) + ' kWh', 'The whole of last month, for comparison'));
  if ((m.top || []).length) {
    var top = el('div', 'money-top');
    top.appendChild(el('span', 'money-lbl', 'Most of it'));
    m.top.forEach(function (t) {
      top.appendChild(el('span', '', t.name + ' \u00b7 ' + fmt(t.kwh, 1) + ' kWh' + (m.price_per_kwh ? ' (' + fmt(t.cost, 0) + ' ' + cur + ')' : '')));
    });
    host.appendChild(top);
  }
  if (!m.price_per_kwh) host.appendChild(el('p', 'btnhelp', 'Set the price per kWh and the currency under Control \u2192 System \u2192 Settings to see this in money.'));
}

// A right-click on a card offers what one wants of that thing: its history,
// a copy of its name or address, a look at every value it reports.
function attachCardMenu(node, items) {
  node.addEventListener('contextmenu', function (e) {
    if (e.target.closest('input, select, textarea, button')) return;
    e.preventDefault(); e.stopPropagation();
    hideMoveMenu();
    var menu = el('div', 'movemenu');
    menu.appendChild(el('div', 'mm-head', items.head || 'This one'));
    (items.rows || []).forEach(function (row) {
      if (!row) return;
      var b = el('button', 'mm-item', row[0]); b.type = 'button';
      b.onclick = function (ev) { ev.stopPropagation(); hideMoveMenu(); row[1](); };
      menu.appendChild(b);
    });
    document.body.appendChild(menu);
    var w = menu.offsetWidth || 200, h = menu.offsetHeight || 140;
    menu.style.left = Math.max(8, Math.min(e.clientX, window.innerWidth - w - 10)) + 'px';
    menu.style.top = Math.max(8, Math.min(e.clientY, window.innerHeight - h - 10)) + 'px';
    MOVEMENU = menu;
  });
}
// Two small helpers the card menu leans on.
function pickHistoryDevice(id) {
  var sel = $('h-device');
  if (!sel) return;
  if (Array.prototype.some.call(sel.options, function (o) { return o.value === id; })) {
    sel.value = id;
    if (sel.onchange) sel.onchange();
  }
}
function newRuleFor(deviceId) {
  RULES.rows = RULES.rows || [];
  RULES.rows.push({id: '', device: deviceId, key: '', op: '>=', value: null, plug: '', do: 'on', enabled: true, cooldown_s: 300});
  markRules();
  renderRules(STATE.status);
  var last = document.querySelectorAll('#rules-list .rule-pack');
  if (last.length) last[last.length - 1].scrollIntoView({block: 'center', behavior: 'smooth'});
}
function copyToClipboard(text, what) {
  var done = function () { toast((what || 'Copied') + ': ' + text, true); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, done);
  else { var t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select();
         try { document.execCommand('copy'); } catch (e) {} t.remove(); done(); }
}

// ---- Find anything (Ctrl+K) --------------------------------------------------
// Everything the dashboard knows about, in one list: a device, a socket, a
// room, a scene, a rule, a binding, even a tab. Enter goes there and, where
// there is one, opens its card.
var FIND = {items: [], at: 0};
function findEverything() {
  var st = STATE.status || {}, out = [];
  (st.devices || []).forEach(function (d) { out.push({icon: deviceIcon(d), text: d.name, what: 'device', go: function () { showTab('devices'); setTimeout(function () { highlightCard(d.name); }, 250); }}); });
  (st.plugs || []).forEach(function (p) { out.push({icon: deviceIcon(Object.assign({source: 'plug'}, p)), text: p.name, what: 'socket', go: function () { showTab('plugs'); }}); });
  ((st.heating || {}).rooms || []).forEach(function (r) { out.push({icon: ICON.heat, text: r.name, what: 'room', go: function () { showTab('heating'); }}); });
  (st.scenes || []).forEach(function (x) { out.push({icon: ICON.scene, text: x.name, what: 'scene', go: function () { showTab('control'); setTimeout(function () { showControlSection('automation'); }, 40); }}); });
  (st.sequences || []).forEach(function (x) { out.push({icon: ICON.seq, text: x.name, what: 'sequence', go: function () { showTab('control'); setTimeout(function () { showControlSection('automation'); }, 40); }}); });
  (st.rules || []).forEach(function (r) {
    out.push({icon: '\u26a1', text: (nameFor(st, r.device) || r.device) + ' ' + r.key + ' ' + r.op + ' ' + r.value + ' \u2192 ' + targetLabel(st, r.plug),
              what: 'rule', go: function () { showTab('control'); setTimeout(function () { showControlSection('automation'); }, 40); }});
  });
  (st.bindings || []).forEach(function (b) {
    out.push({icon: ICON.button, text: (nameFor(st, b.device) || b.device) + ' ' + (b.action || '*') + ' \u2192 ' + targetLabel(st, b.plug),
              what: 'binding', go: function () { showTab('control'); setTimeout(function () { showControlSection('automation'); }, 40); }});
  });
  Array.prototype.forEach.call(document.querySelectorAll('.tabs button[data-tab]'), function (b) {
    out.push({icon: '\u25b8', text: b.textContent, what: 'tab', go: function () { showTab(b.dataset.tab); }});
  });
  return out;
}
// scroll a named card into view and let it glow for a moment
function highlightCard(name) {
  var card = Array.prototype.filter.call(document.querySelectorAll('.card h3, .card h2'), function (h) { return h.textContent.trim() === name; })[0];
  card = card && card.closest('.card');
  if (!card) return;
  card.scrollIntoView({block: 'center', behavior: 'smooth'});
  card.classList.add('found');
  setTimeout(function () { card.classList.remove('found'); }, 2000);
}
function nameFor(st, id) {
  var d = (st.devices || []).filter(function (x) { return x.id === id || x.name === id; })[0];
  return d ? d.name : '';
}
function targetLabel(st, target) {
  var t = (st.switch_targets || []).filter(function (x) { return x.value === target; })[0];
  if (t) return t.name;
  // switch_targets is the Zigbee and heating half of it. A scene, a socket or
  // "all lights" lives in the full list, and printing scene:f8f2a1bb at
  // somebody is no sort of answer.
  var all = targetOptions(st) || [];
  for (var i = 0; i < all.length; i++) {
    if (all[i][0] === target) return String(all[i][1] || '').replace(/^\S+\s+/, '');
  }
  return target;
}
function openFind() {
  var back = $('findback'), input = $('findinput');
  FIND.items = findEverything(); FIND.at = 0;
  back.hidden = false; input.value = ''; paintFind('');
  setTimeout(function () { input.focus(); }, 20);
  input.oninput = function () { FIND.at = 0; paintFind(input.value); };
  input.onkeydown = function (e) {
    var rows = $('findlist').children;
    if (e.key === 'Escape') { e.preventDefault(); closeFind(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); FIND.at = Math.min(rows.length - 1, FIND.at + 1); paintFind(input.value, true); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); FIND.at = Math.max(0, FIND.at - 1); paintFind(input.value, true); }
    else if (e.key === 'Enter') { e.preventDefault(); if (rows[FIND.at]) rows[FIND.at].click(); }
  };
  back.onclick = function (e) { if (e.target === back) closeFind(); };
}
function closeFind() { $('findback').hidden = true; }
function paintFind(query, keepList) {
  var host = $('findlist');
  if (!keepList) {
    host.innerHTML = '';
    var q = (query || '').toLowerCase().trim();
    var hits = FIND.items.filter(function (it) { return !q || String(it.text).toLowerCase().indexOf(q) >= 0 || it.what.indexOf(q) === 0; }).slice(0, 40);
    hits.forEach(function (it, i) {
      var row = el('div', 'finditem' + (i === FIND.at ? ' on' : ''));
      row.appendChild(el('span', '', it.icon || ''));
      row.appendChild(el('span', '', it.text));
      row.appendChild(el('span', 'what', it.what));
      row.onclick = function () { closeFind(); it.go(); };
      host.appendChild(row);
    });
    if (!hits.length) host.appendChild(el('div', 'muted small', 'Nothing of that name.'));
  } else {
    Array.prototype.forEach.call(host.children, function (n, i) { n.classList.toggle('on', i === FIND.at); });
    if (host.children[FIND.at] && host.children[FIND.at].scrollIntoView) host.children[FIND.at].scrollIntoView({block: 'nearest'});
  }
}
document.addEventListener('keydown', function (e) {
  if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); openFind(); }
});

// Per-device notification choices, one line each with a fold - two dozen
// devices as a list rather than a wall of switches.
var NOTIFY_OPEN = {};
function notifyDeviceBlock(name, body, summary) {
  var open = !!NOTIFY_OPEN[name];
  var block = el('div', 'pc-block' + (open ? ' open' : ''));
  var line = el('div', 'pc-line');
  var left = el('span', 'pc-left');
  left.appendChild(el('span', 'fold', open ? '\u25be' : '\u25b8'));
  left.appendChild(el('span', 'pc-name', name));
  if (summary) left.appendChild(el('span', 'dim', summary));
  left.onclick = function () {
    NOTIFY_OPEN[name] = !NOTIFY_OPEN[name];
    block.classList.toggle('open', NOTIFY_OPEN[name]);
    left.firstChild.textContent = NOTIFY_OPEN[name] ? '\u25be' : '\u25b8';
  };
  line.appendChild(left);
  block.appendChild(line);
  var inner = el('div', 'pc-body');
  inner.appendChild(body);
  block.appendChild(inner);
  return block;
}

// ---- Going back a step -------------------------------------------------------
function renderSnapshots() {
  var host = $('snap-list'); if (!host) return;
  api('snapshots').then(function (r) {
    host.innerHTML = '';
    var list = r.snapshots || [];
    if (!list.length) { host.appendChild(el('p', 'btnhelp', 'Nothing kept yet \u2014 the first Save in any editor starts it off.')); return; }
    list.forEach(function (sn) {
      var row = el('div', 'acl-row');
      row.appendChild(el('span', 'who', ago(sn.at)));
      row.appendChild(el('span', 'top', sn.key));
      if (sn.size !== null && sn.size !== undefined) row.appendChild(el('span', 'who', sn.size + ' row(s)'));
      row.appendChild(el('span', 'why', sn.why || ''));
      var back = cmdButton('Put back', 'reset', 'small');
      back.title = 'Restore ' + sn.key + ' as it was ' + ago(sn.at) + '. The version in force now is kept, so this can be undone.';
      back.onclick = function () {
        withPin('Put ' + sn.key + ' back', 'As it was ' + ago(sn.at) + '. What is in force now is kept first.', function (pin) {
          return post('snapshot-restore', {id: sn.id, pin: pin}).then(function (x) {
            if (!x.ok) throw new Error(x.error || 'could not'); SIGS = {}; tick(true); return x.message;
          });
        });
      };
      row.appendChild(back);
      var drop = el('button', 'btn small iconbtn needs-unlock'); drop.type = 'button'; drop.innerHTML = iconMarkup('trash', 13);
      drop.title = 'Forget this kept version. What is in force now is untouched.';
      drop.onclick = function () {
        withPin('Forget this version', 'The ' + sn.key + ' kept from ' + ago(sn.at) + ' is thrown away. What is in force now stays.', function (pin) {
          return post('snapshot-drop', {id: sn.id, pin: pin}).then(function (x) {
            if (!x.ok) throw new Error(x.error || 'could not'); renderSnapshots(); return x.message;
          });
        });
      };
      row.appendChild(drop);
      host.appendChild(row);
    });
    var bar = el('div', 'btnrow'); bar.style.marginTop = '10px';
    var wipe = cmdButton('Throw them all away', 'trash', 'small danger');
    wipe.title = 'Forget every kept version. Nothing in force changes; the next Save starts the list again.';
    wipe.onclick = function () {
      withPin('Throw away every kept version', 'All ' + list.length + ' of them. Nothing in force changes, and the next Save starts the list again.', function (pin) {
        return post('snapshot-drop', {pin: pin}).then(function (x) {
          if (!x.ok) throw new Error(x.error || 'could not'); renderSnapshots(); return x.message;
        });
      });
    };
    bar.appendChild(wipe); host.appendChild(bar);
  }, function () {});
}
function renderRoutes() {
  var host = $('routes-list'); if (!host) return;
  api('routes').then(function (r) {
    host.innerHTML = '';
    var rows = Object.keys(r.routes || {}).map(function (k) { return r.routes[k]; });
    if (!rows.length) { host.appendChild(el('p', 'btnhelp', 'Nothing yet \u2014 the first network scan fills this in.')); return; }
    rows.sort(function (a, b) { return b.changes - a.changes || String(a.name).localeCompare(b.name); });
    rows.forEach(function (x) {
      var row = el('div', 'acl-row' + (x.changes >= 3 ? ' bad' : ''));
      row.appendChild(el('span', 'top', x.name));
      row.appendChild(el('span', 'who', 'via ' + (x.via || 'the coordinator')));
      row.appendChild(el('span', 'why', x.changes ? x.changes + ' change(s), last ' + ago((x.history[x.history.length - 1] || {}).at) : 'steady'));
      if ((x.history || []).length > 1) row.title = x.history.map(function (h) { return stamp(h.at) + ' \u2192 ' + (h.via || 'coordinator'); }).join('\n');
      host.appendChild(row);
    });
  }, function () {});
}

// ---- What the broker must allow ----------------------------------------------
// The topics in use here, against the broker's own ACL file: a line missing
// there is why a command can go out and nothing happen at all.
function renderAcl() {
  var host = $('acl-list'), fix = $('acl-fix'); if (!host) return;
  api('mqtt-acl').then(function (r) {
    host.innerHTML = '';
    $('acl-file').textContent = r.file || '';
    if (!r.readable) {
      host.appendChild(el('p', 'btnhelp', 'The file could not be read: ' + (r.error || 'no reason given')
        + '. The lines below are the ones it needs; they are not ticked because nothing could be compared.'));
      if (r.fix) { var fixNote = el('pre', 'acl-fix'); fixNote.textContent = r.fix; host.appendChild(fixNote); }
    }
    (r.wanted || []).forEach(function (w) {
      var row = el('div', 'acl-row' + (w.covered || !r.readable ? '' : ' bad'));
      row.appendChild(el('span', 'mark ' + (w.covered ? 'ok' : (r.readable ? 'warn' : 'dim')), w.covered ? '\u2714' : (r.readable ? '\u2718' : '\u2013')));
      row.appendChild(el('span', 'who', w.user));
      row.appendChild(el('span', 'who', w.access));
      row.appendChild(el('span', 'top', w.topic));
      row.appendChild(el('span', 'why', w.why));
      host.appendChild(row);
    });
    Object.keys(r.muddled_prefixes || {}).forEach(function (h) {
      var names = r.muddled_prefixes[h];
      var note = el('p', 'btnhelp');
      note.style.color = 'var(--warn)';
      note.textContent = h + ' has ' + names.length + ' MQTT prefixes for one box (' + names.join(', ')
        + '). A box publishes under one, so at most one of them can be right \u2014 give its sockets the same '
        + 'prefix and this list shrinks to one set of lines.';
      host.insertBefore(note, host.firstChild);
    });
    if (!(r.wanted || []).length) host.appendChild(el('p', 'btnhelp', 'Nothing to check yet.'));
    fix.hidden = !r.suggestion || !r.readable;
    fix.textContent = r.suggestion || '';
    var mend = $('acl-mend');
    if (mend) mend.hidden = !r.suggestion || !r.readable;
  }, function (e) { host.innerHTML = ''; host.appendChild(el('p', 'btnhelp', 'Could not ask the daemon: ' + (e.message || e))); });
}

// ---- Where the time goes -----------------------------------------------------
var TICK = {lastMs: null};
function renderLatency(st) {
  var host = $('latency-list'); if (!host) return;
  host.innerHTML = '';
  var L = st.latency || {};
  function row(label, value, unit, good, bad, note) {
    var r = el('div', 'lat-row');
    r.appendChild(el('span', 'k', label));
    var cls = 'dim', text = '\u2013';
    if (isNum(value)) {
      text = fmt(value, value < 10 ? 1 : 0) + (unit || '');
      cls = value <= good ? 'ok' : (value <= bad ? 'warn' : 'crit');
    } else if (value) { text = String(value); cls = 'dim'; }
    var v = el('span', 'v ' + cls, text); if (note) v.title = note;
    r.appendChild(v); host.appendChild(r);
  }
  row('Daemon: message \u2192 dashboard', st.wake_ms, ' ms', 5, 50, 'From a report landing on the broker to this page being woken');
  row('Daemon: status build', st.status_ms, ' ms', 10, 60, 'Building /api/status');
  row('Daemon: clock thread late by', L.timer_jitter_ms, ' ms', 20, 200, 'How late the quarter-second beat runs; the machine is busy if this grows');
  row('Daemon: writes waiting', L.write_queue, '', 20, 200, 'Rows queued for the database');
  row('Browser: last repaint', TICK.lastMs, ' ms', 30, 150, 'How long this page took to draw the last update');
  row('Broker round trip', L.broker_rtt_ms, ' ms', 5, 50, 'A message out and back through mosquitto');
  row('Zigbee command \u2192 device echo' + (L.set_rtt_what ? ' (' + L.set_rtt_what + ')' : ''), L.set_rtt_ms, ' ms', 300, 2000,
      'From publishing a set to the device reporting the new value back. Routers answer in a few hundred ms; a sleeping head answers when it wakes.');
  // what the last few switch commands actually cost, newest first: the figure
  // that says whether a slow scene is the box or us
  var switches = (L.switches || []).slice().reverse();
  if (switches.length) {
    host.appendChild(el('div', 'lat-head', 'The last switch commands'));
    switches.forEach(function (x) {
      row(x.name, x.ms, ' ms', 120, 500,
          'From asking this socket to switch until it answered. Everything above this line is the daemon; '
          + 'this is the box and the network between.');
    });
  }
  var limited = L.rate_limited || {};
  Object.keys(limited).forEach(function (host) {
    row('Box ' + host + ' said "too many requests"', limited[host].times + '\u00d7',
        '', 0, 0, 'The box asked the daemon to slow down. Each time, a command waited for it; '
        + 'the confirming reads after a switch are now one per box, which is usually what fixes this.');
  });
  var plugs = L.plugs || {};
  Object.keys(plugs).sort(function (a, b) { return plugs[b] - plugs[a]; }).forEach(function (n) {
    var waited = (L.plug_waits || {})[n];
    row('Box ' + n + (waited ? ' (+' + Math.round(waited) + ' ms in the queue)' : ''), plugs[n], ' ms', 150, 600,
        'How long this box took to answer its last poll. Requests to one box are spaced '
        + 'plug_min_request_gap apart on purpose (a Shelly answers 429 when hurried), so a socket that '
        + 'waited its turn shows that wait as well \u2014 a second or two here is the pacing, not the box being slow. '
        + 'What matters for a press is the command path, which skips the queue.');
  });
  if (!Object.keys(plugs).length) row('Boxes', 'no poll yet', '', 0, 0);
}

// One place for "put this room on comfort", used by the card's buttons and by
// its right-click menu alike.
function heatPreset(room, level) {
  withPin(room.name + ': ' + level, 'The valves in the room follow at once.', function (pin) {
    return post('target-set', {target: 'heat:room:' + room.id, do: 'set:' + level, pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not'); HEAT.dirty = false; forgetSig('heating-tab');
      return room.name + ' \u2192 ' + level;
    });
  });
}

// ---- Rooms -------------------------------------------------------------------
var ROOMS = {dirty: false, rows: null, map: null};
function markRooms() { ROOMS.dirty = true; $('rooms-note').textContent = 'Unsaved changes'; }
function renderRooms(st) {
  if (!ROOMS.dirty) { ROOMS.rows = (st.rooms || []).slice(); ROOMS.map = Object.assign({}, st.room_of || {}); }
  var host = $('rooms-list'); host.innerHTML = '';
  (ROOMS.rows || []).forEach(function (room, i) {
    var row = el('div', 'room-row');
    var name = el('input'); name.value = room.name;
    name.oninput = function () { room.name = name.value; markRooms(); };
    row.appendChild(name);
    var count = Object.keys(ROOMS.map || {}).filter(function (k) { return ROOMS.map[k] === room.id; }).length;
    row.appendChild(el('span', 'muted small', count + (count === 1 ? ' thing in it' : ' things in it')));
    var drop = el('button', 'btn small iconbtn danger needs-unlock'); drop.type = 'button';
    drop.innerHTML = iconMarkup('trash', 14); drop.title = 'Remove this room (what is in it is simply unassigned)';
    drop.onclick = function () { ROOMS.rows.splice(i, 1); markRooms(); renderRooms(STATE.status); };
    row.appendChild(drop);
    makeRowSortable(row, host, ROOMS, markRooms, function () { renderRooms(STATE.status); }, room);
    host.appendChild(row);
  });
  if (!(ROOMS.rows || []).length) host.appendChild(el('div', 'muted small', 'No rooms yet.'));
  // what goes where
  var assign = $('rooms-assign'); assign.innerHTML = '';
  if (!(ROOMS.rows || []).length) return;
  var head = el('div', 'set-head', 'What is in them');
  assign.appendChild(head);
  assign.appendChild(el('p', 'note', 'Pick a room beside a device. A thermometer and a valve in the same room is what the '
    + 'Heating tab works on; plugs decide how the energy table is grouped. Nothing has to be assigned.'));
  var opts = [['', 'not in a room']].concat((ROOMS.rows || []).filter(function (r) { return r.id; })
    .map(function (r) { return [r.id, r.name || '(unnamed)']; }));
  var list = el('div', 'room-assign');
  var loose = 0;
  // the same order as everywhere else: by kind first, by name inside it
  devicesSorted(st.devices || []).forEach(function (d) {
    var key = d.source === 'plug' ? d.name : d.id;
    var where = ROOMS.map[key] || ROOMS.map[d.name] || ROOMS.map[d.id] || '';
    if (!where) loose++;
    var line = el('label', 'room-item' + (where ? '' : ' unplaced'));
    line.appendChild(el('span', 'room-name', (deviceIcon(d) ? deviceIcon(d) + ' ' : '') + d.name));
    var sel = el('select');
    fillSelect(sel, opts, where);
    sel.onchange = function () {
      delete ROOMS.map[d.id]; delete ROOMS.map[d.name];
      if (sel.value) ROOMS.map[key] = sel.value;
      markRooms(); renderRooms(STATE.status);
    };
    line.appendChild(sel);
    list.appendChild(line);
  });
  // said once at the top as well, because the marks are only visible where
  // the list happens to be scrolled to
  if (loose) head.appendChild(el('span', 'dim', ' \u00b7 ' + loose + ' in no room'));
  assign.appendChild(list);
}
$('room-add').onclick = function () {
  var id = 'r' + Math.random().toString(16).slice(2, 8);
  ROOMS.rows = (ROOMS.rows || []).concat([{id: id, name: 'Room ' + ((ROOMS.rows || []).length + 1)}]);
  markRooms(); renderRooms(STATE.status);
};
$('rooms-save').onclick = function () {
  withPin('Save the rooms', 'Rooms group the energy table and drive the Heating screen.', function (pin) {
    return post('rooms-save', {pin: pin, rooms: rowsToSave(ROOMS, 'rooms'), room_of: ROOMS.map || {}}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not save');
      ROOMS.dirty = false; $('rooms-note').textContent = ''; forgetSig('rooms');
      return (r.rooms || []).length + ' room(s) saved';
    });
  });
};

// ---- Heating -----------------------------------------------------------------
var HEAT = {dirty: false, rows: null, away_c: null};
var HEAT_DAYS = [['1', 'Mo'], ['2', 'Tu'], ['3', 'We'], ['4', 'Th'], ['5', 'Fr'], ['6', 'Sa'], ['0', 'Su']];
var HEAT_LEVELS = [['comfort', 'Comfort'], ['eco', 'Eco'], ['night', 'Night'], ['off', 'Off']];
function markHeating() { HEAT.dirty = true; $('heat-note').textContent = 'Unsaved changes'; }
function renderHeating(st) {
  var h = st.heating || {rooms: []};
  if (!HEAT.dirty) { HEAT.rows = JSON.parse(JSON.stringify(h.rooms || [])); HEAT.enabled = h.enabled;
                     HEAT.away = h.away_switch !== undefined ? h.away_switch : h.away; HEAT.away_c = h.away_c;
                     HEAT.away_from = h.away_from || ''; HEAT.away_to = h.away_to || ''; }
  $('heat-enabled-sw').innerHTML = ''; $('heat-away-sw').innerHTML = '';
  $('heat-enabled-sw').appendChild(makeSwitch(HEAT.enabled !== false, function (on) { HEAT.enabled = on; markHeating(); },
    {small: true, title: 'With this off nothing is sent to any valve; they keep whatever they were last told.'}));
  if (h.away && !HEAT.away) $('heat-away-sw').title = 'On because today falls between the dates';
  $('heat-away-sw').appendChild(makeSwitch(!!HEAT.away || !!h.away, function (on) { HEAT.away = on; markHeating(); renderHeating(STATE.status); },
    {small: true, title: 'Every room drops to the away temperature until this is switched off.'}));
  $('heat-away-c').value = HEAT.away_c === null || HEAT.away_c === undefined ? 16 : HEAT.away_c;
  $('heat-away-c').oninput = function () { HEAT.away_c = parseFloat($('heat-away-c').value); markHeating(); };
  $('heat-away-from').value = HEAT.away_from || '';
  $('heat-away-to').value = HEAT.away_to || '';
  $('heat-away-from').onchange = function () { HEAT.away_from = $('heat-away-from').value; markHeating(); };
  $('heat-away-to').onchange = function () { HEAT.away_to = $('heat-away-to').value; markHeating(); };
  var host = $('heating-rooms'); host.innerHTML = '';
  $('heating-empty').hidden = !!(HEAT.rows || []).length;
  (HEAT.rows || []).forEach(function (room, ri) {
    var live = ((st.heating || {}).rooms || []).filter(function (x) { return x.id === room.id; })[0] || room;
    var heated = room.heated !== false;
    var card = el('div', 'card heatcard' + (live.window_open && heated ? ' warn' : '') + (heated ? '' : ' unheated'));
    var head = el('div', 'heat-head');
    var titleWrap = el('div', 'heat-title');
    titleWrap.appendChild(makeSwitch(heated, function (on) { room.heated = on; markHeating(); renderHeating(STATE.status); },
      {small: true, title: heated ? 'This room is heated. Off: no heating here \u2014 the room is listed, and left alone.' : 'No heating in this room. On: the room holds a temperature.'}));
    titleWrap.appendChild(el('h3', '', room.name));
    head.appendChild(titleWrap);
    if (!heated) {
      head.appendChild(el('span', 'muted small', 'no heating in this room'));
      card.appendChild(head);
      makeRoomCardReorderable(card, host, room.id);
      host.appendChild(card);
      return;
    }
    var now = el('div', 'heat-now');
    now.appendChild(el('span', 'heat-temp', live.temperature === null || live.temperature === undefined ? '\u2013' : fmt(live.temperature, 1) + ' \u00b0C'));
    // the number the room is holding right now; when a hand set it (a knob,
    // a card) that is the number to see, so it stands out and says until when
    var want = el('span', 'heat-want' + (live.why === 'by hand' ? ' hand' : ''));
    if (live.wanted_c === null || live.wanted_c === undefined) want.textContent = 'not controlled';
    else {
      want.appendChild(el('span', '', '\u2192 ' + fmt(live.wanted_c, 1) + ' \u00b0C'));
      if (live.why === 'by hand') want.appendChild(el('span', 'heat-hand', 'by hand' + (live.hold_until ? ' until ' + new Date(live.hold_until * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}) : '')));
      else want.appendChild(el('span', 'heat-hand dim', live.why));
    }
    want.title = 'What the room is holding, and why';
    now.appendChild(want);
    var ctl = el('span', 'heat-ctl');
    ctl.appendChild(el('span', 'lbl', 'Control'));
    ctl.appendChild(makeSwitch(room.control !== false, function (on) { room.control = on; markHeating(); renderHeating(STATE.status); },
      {small: true, title: 'Whether zigmon drives the valves in this room right now. Off: the room keeps its plan and temperatures, but nothing is sent - the heads keep whatever they were last told.'}));
    now.appendChild(ctl);
    head.appendChild(now);
    card.appendChild(head);
    var why = el('div', 'muted small');
    var thName = live.thermometer ? ((st.devices || []).filter(function (d) { return d.id === live.thermometer; })[0] || {}).name : '';
    why.textContent = (thName ? 'reading ' + thName + ' \u00b7 ' : '') + (live.window_open ? 'a window is open \u2014 held at 5 \u00b0C'
      : (HEAT.enabled === false ? 'heating control is off' : (room.control === false ? 'control is off for this room \u2014 the valves are left as they are'
        : (live.why === 'away' ? 'away' : (live.why === 'by hand' ? 'set by hand' + (live.hold_until ? ' until ' + new Date(live.hold_until * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}) : '') + ', then the plan again'
          : 'holding the ' + live.why + ' temperature'))))
        + (live.valves.length ? ' \u00b7 ' + live.valves.map(function (v) { return v.name + (isNum(v.setpoint) ? ' at ' + fmt(v.setpoint, 1) : '') + (v.online ? '' : ' (silent)'); }).join(', ')
           : ' \u00b7 no valve in this room yet'));
    attachCardMenu(card, {head: room.name, rows: [
      ['\ud83d\udd06 Comfort now', function () { heatPreset(room, 'comfort'); }],
      ['\ud83c\udf3f Eco now', function () { heatPreset(room, 'eco'); }],
      ['\u26d4 Off', function () { heatPreset(room, 'off'); }],
      ['\ud83d\udcc5 Back to the plan', function () { heatPreset(room, 'plan'); }],
      ['\ud83d\udcc8 History of this room\u2019s thermometer', function () {
        var t = (live.thermometer || (live.valves[0] || {}).target || '').replace(/^zb:/, '').split(':')[0];
        if (t) { showTab('history'); setTimeout(function () { pickHistoryDevice(t); }, 80); }
      }]
    ]});
    card.appendChild(why);
    // one line per head: what it holds, what it reads, how far it is open
    (live.valves || []).forEach(function (v) {
      var line = el('div', 'heat-valve');
      line.appendChild(el('span', 'hv-name', ICON.valve + ' ' + v.name + ' \u00b7'));
      var bits = [];
      if (isNum(v.setpoint)) bits.push('holding ' + fmt(v.setpoint, 1) + ' \u00b0C');
      if (isNum(v.local_c)) bits.push('reads ' + fmt(v.local_c, 1) + (isNum(v.calibration) && v.calibration ? ' (offset ' + (v.calibration > 0 ? '+' : '') + fmt(v.calibration, 1) + ')' : ''));
      if (isNum(v.position)) bits.push(fmt(v.position, 0) + ' % open');
      if (v.running) bits.push(v.running === 'heat' || v.running === 'heating' ? 'heating' : v.running);
      if (v.mode) bits.push(v.mode);
      if (v.force && v.force !== 'normal') bits.push('forced ' + v.force);
      if (v.battery_low) bits.push('battery low');
      else if (isNum(v.battery)) bits.push('battery ' + fmt(v.battery, 0) + ' %');
      if (!v.online) bits.push('silent');
      line.appendChild(el('span', 'hv-bits', bits.join(' \u00b7 ')));
      if (v.can_calibrate && isNum(v.local_c) && isNum(live.temperature)) {
        var cal = el('button', 'btn small needs-unlock', ICON.thermo + ' Match the room'); cal.type = 'button';
        cal.title = 'Tell the head what the room thermometer reads (' + fmt(live.temperature, 1) + ' \u00b0C): it sits on the radiator and runs warm, and it takes an offset for exactly this.';
        cal.onclick = function () {
          withPin('Calibrate ' + v.name, 'Sets the head\u2019s offset so its reading matches the room.', function (pin) {
            return post('heat-calibrate', {target: v.target, pin: pin}).then(function (r) {
              if (!r.ok) throw new Error(r.error || 'could not'); forgetSig('heating-tab'); return v.name + ': ' + r.message;
            });
          });
        };
        line.appendChild(cal);
      }
      // shutting one valve while the room keeps its number would be undone on
      // the next round, so this closes the room - the same as the Off preset
      var shut = el('button', 'btn small needs-unlock', ICON.shut + ' Close'); shut.type = 'button';
      shut.title = 'Shut the valves in ' + room.name + ' (5 \u00b0C, frost only). Same as the Off preset; Plan hands the room back.';
      shut.onclick = function () {
        withPin('Close ' + room.name, 'The valves shut and hold 5 \u00b0C until the room is set again.', function (pin) {
          return post('target-set', {target: 'heat:room:' + room.id, do: 'set:off', pin: pin}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'could not'); HEAT.dirty = false; forgetSig('heating-tab'); return room.name + ' closed';
          });
        });
      };
      line.appendChild(shut);
      card.appendChild(line);
    });
    // Set the room by hand: a slider you can throw at a number, with minus
    // and plus for half a degree, and how long it should last. The slider
    // only speaks when it is let go - dragging it does not fire a request
    // per pixel, and the reading beside it follows the thumb meanwhile.
    var hand = el('div', 'heat-handbar');
    hand.appendChild(el('span', 'lbl', 'By hand'));
    var slider = el('input'); slider.type = 'range'; slider.min = 5; slider.max = 30; slider.step = 0.5;
    var shown = isNum(live.wanted_c) ? live.wanted_c : (room.comfort_c || 21);
    slider.value = shown;
    slider.className = 'heat-slider';
    var read = el('span', 'heat-read', fmt(shown, 1) + ' \u00b0C');
    function paintSlider(v) {
      var pct = ((v - 5) / 25) * 100;
      slider.style.setProperty('--fill', pct + '%');
      read.textContent = fmt(v, 1) + ' \u00b0C';
    }
    paintSlider(shown);
    var forSel = el('select');
    fillSelect(forSel, [['', ICON.plan + ' until the plan\u2019s next step'], ['3600', '\u23f1\ufe0f for 1 h'], ['7200', '\u23f1\ufe0f for 2 h'],
                        ['14400', '\u23f1\ufe0f for 4 h'], ['28800', '\u23f1\ufe0f for 8 h'], ['86400', '\u23f1\ufe0f for 24 h']], HEAT.holdFor || '');
    forSel.title = 'How long the hand-set temperature lasts. The plan\u2019s next change of level is the natural end; a fixed time holds through it.';
    forSel.onchange = function () { HEAT.holdFor = forSel.value; };
    function sendHand(spec) {
      withPin('Set ' + room.name + ' by hand', 'The valves in the room follow at once.', function (pin) {
        return post('target-set', {target: 'heat:temp:' + room.id, do: spec, pin: pin, hold_s: forSel.value || null}).then(function (r) {
          if (!r.ok) throw new Error(r.error || 'could not'); forgetSig('heating-tab'); return room.name + ' set by hand';
        });
      });
    }
    slider.oninput = function () { paintSlider(parseFloat(slider.value)); };
    slider.onchange = function () { sendHand('set:' + slider.value); };
    slider.title = 'Drag to set the room; it is sent when you let go. Arrow keys step half a degree.';
    holdRepaint(slider);
    hand.appendChild(slider); hand.appendChild(read); hand.appendChild(forSel);
    // the presets as buttons: one tap picks a level outright (and ends a hand-set number)
    var presets = el('span', 'heat-presets');
    [['comfort', 'Comfort'], ['eco', 'Eco'], ['night', 'Night'], ['off', 'Off'], ['plan', 'Plan'], ['manual', 'By hand']].forEach(function (pr) {
      var b = el('button', 'btn small needs-unlock' + ((room.mode || 'plan') === pr[0] && live.why !== 'by hand' ? ' on' : ''),
                 (pr[0] === 'manual' ? '\u270b' : (ICON[pr[0] === 'off' ? 'shut' : pr[0]] || '')) + ' ' + pr[1]); b.type = 'button';
      b.title = pr[0] === 'plan' ? 'Follow the plan'
        : pr[0] === 'manual' ? 'Leave the valve alone entirely: whatever it is turned to on the wall stays, and nothing here writes to it'
        : 'Hold the ' + pr[1].toLowerCase() + ' temperature until changed';
      b.onclick = function () {
        withPin(room.name + ': ' + pr[1], 'The valves in the room follow at once.', function (pin) {
          return post('target-set', {target: 'heat:room:' + room.id, do: 'set:' + pr[0], pin: pin}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'could not'); HEAT.dirty = false; forgetSig('heating-tab'); return room.name + ' \u2192 ' + pr[1];
          });
        });
      };
      presets.appendChild(b);
    });
    hand.appendChild(presets);
    card.appendChild(hand);
    if (live.why === 'by hand') {
      var back = el('button', 'btn small needs-unlock', ICON.plan + ' Back to the plan now'); back.type = 'button'; back.style.marginTop = '6px';
      back.onclick = function () {
        withPin('Back to the plan', room.name + ' follows its plan again.', function (pin) {
          return post('target-set', {target: 'heat:room:' + room.id, do: 'set:' + (room.mode || 'plan'), pin: pin}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'could not'); forgetSig('heating-tab'); return room.name + ' is back on the plan';
          });
        });
      };
      card.appendChild(back);
    }
    // the three temperatures
    var temps = el('div', 'heat-temps');
    [['comfort_c', 'Comfort'], ['eco_c', 'Eco'], ['night_c', 'Night']].forEach(function (pair) {
      var item = el('label', 'heat-t');
      item.appendChild(el('span', 'lbl', pair[1]));
      var input = el('input'); input.type = 'number'; input.min = 5; input.max = 35; input.step = 0.5;
      input.value = room[pair[0]];
      input.oninput = function () { room[pair[0]] = parseFloat(input.value); markHeating(); };
      item.appendChild(input); temps.appendChild(item);
    });
    // which thermometer the room reads: the ones in it first, then any other
    var thWrap = el('label', 'heat-t');
    thWrap.appendChild(el('span', 'lbl', 'Thermometer'));
    var th = el('select');
    var inRoom = {}; Object.keys(st.room_of || {}).forEach(function (k) { if ((st.room_of || {})[k] === room.id) inRoom[k] = true; });
    var thermos = (st.devices || []).filter(function (d) { return d.values && ('temperature' in d.values || 'local_temperature' in d.values || 'tC' in d.values); });
    var here = thermos.filter(function (d) { return inRoom[d.id] || inRoom[d.name]; }), elsewhere = thermos.filter(function (d) { return !(inRoom[d.id] || inRoom[d.name]); });
    var thOpts = [['', here.length ? (here.length === 1 ? 'the one in the room' : 'average of the ' + here.length + ' in the room') : 'none in the room \u2014 pick one']]
      .concat(here.map(function (d) { return [d.id, deviceIcon(d) + ' ' + d.name]; }))
      .concat(elsewhere.map(function (d) { return [d.id, deviceIcon(d) + ' ' + d.name + ' (elsewhere)']; }));
    fillSelect(th, thOpts, room.thermometer || '');
    th.title = 'The reading this room holds its temperature against. Leave it on the room\u2019s own thermometer(s) unless it has none, or several and one of them is the one that matters.';
    th.onchange = function () { room.thermometer = th.value; markHeating(); };
    thWrap.appendChild(th); temps.appendChild(thWrap);
    // (the level lives on the preset buttons above; a second copy here only
    //  invited the two to disagree)
    card.appendChild(temps);
    // the plan
    var plan = el('div', 'heat-plan');
    (room.plan || []).forEach(function (step, si) {
      var line = el('div', 'heat-step');
      var at = el('input'); at.type = 'time'; at.value = step.at;
      at.onchange = function () { step.at = at.value; markHeating(); };
      line.appendChild(at);
      var lvl = el('select');
      fillSelect(lvl, HEAT_LEVELS.map(function (lv) { return [lv[0], (ICON[lv[0] === 'off' ? 'shut' : lv[0]] || '') + ' ' + lv[1]]; }), step.level);
      lvl.onchange = function () { step.level = lvl.value; markHeating(); };
      line.appendChild(lvl);
      var days = el('span', 'heat-days');
      HEAT_DAYS.forEach(function (d) {
        var on = (step.days || []).indexOf(parseInt(d[0], 10)) >= 0;
        var b = el('button', 'daybtn' + (on ? ' on' : ''), d[1]); b.type = 'button';
        b.onclick = function () {
          var n = parseInt(d[0], 10), list = step.days || [];
          step.days = on ? list.filter(function (x) { return x !== n; }) : list.concat([n]);
          markHeating(); renderHeating(STATE.status);
        };
        days.appendChild(b);
      });
      line.appendChild(days);
      var drop = el('button', 'btn small iconbtn danger needs-unlock'); drop.type = 'button';
      drop.innerHTML = iconMarkup('trash', 14); drop.title = 'Remove this step';
      drop.onclick = function () { room.plan.splice(si, 1); markHeating(); renderHeating(STATE.status); };
      line.appendChild(drop);
      plan.appendChild(line);
    });
    var add = cmdButton('step', 'add', 'small'); add.title = 'Add a step to the plan: a time, a level and the days it applies to';
    add.onclick = function () {
      room.plan = (room.plan || []).concat([{at: '06:30', level: 'comfort', days: [0, 1, 2, 3, 4, 5, 6]}]);
      markHeating(); renderHeating(STATE.status);
    };
    plan.appendChild(add);
    card.appendChild(plan);
    var win = el('div', 'set-item set-bool heat-window');
    win.appendChild(el('label', '', 'Stop for an open window'));
    win.appendChild(makeSwitch(room.window_stop !== false, function (on) { room.window_stop = on; markHeating(); renderHeating(STATE.status); },
      {small: true, title: 'A door or window sensor in this room drops it to 5 \u00b0C while it is open.'}));
    card.appendChild(win);
    // which sensors count as this room's windows: the contacts in the room by
    // default, or a chosen set - a room with a balcony door and a hallway
    // door may only want one of them stopping the heating
    if (room.window_stop !== false) {
      var contacts = (st.devices || []).filter(function (d) {
        var v = d.values || {}; return 'contact' in v || 'window' in v || 'window_open' in v || 'open_window' in v;
      });
      var chosen = room.windows || [];
      var here = contacts.filter(function (d) { return inRoom[d.id] || inRoom[d.name]; }), other = contacts.filter(function (d) { return !(inRoom[d.id] || inRoom[d.name]); });
      var wbox = el('div', 'heat-windows');
      wbox.appendChild(el('span', 'lbl', chosen.length ? 'Windows watched' : (here.length ? 'Windows watched \u2014 every contact in the room' : 'Windows watched \u2014 none in the room')));
      if (!contacts.length) wbox.appendChild(el('span', 'muted small', 'no door or window sensor on the dashboard'));
      here.concat(other).forEach(function (d) {
        var lab = el('label', 'heat-win');
        var cb = el('input'); cb.type = 'checkbox'; cb.checked = chosen.indexOf(d.id) >= 0;
        cb.onchange = function () {
          room.windows = (room.windows || []).filter(function (x) { return x !== d.id; }).concat(cb.checked ? [d.id] : []);
          markHeating(); renderHeating(STATE.status);
        };
        lab.appendChild(cb);
        lab.appendChild(el('span', '', deviceIcon(d) + ' ' + d.name + (inRoom[d.id] || inRoom[d.name] ? '' : ' (elsewhere)')));
        wbox.appendChild(lab);
      });
      if (here.length && !chosen.length) wbox.appendChild(el('span', 'muted small', 'tick some to watch only those'));
      card.appendChild(wbox);
    }
    makeRoomCardReorderable(card, host, room.id);
    host.appendChild(card);
  });
}
// The Heating cards move like the Overview ones, and the new order is the
// order the rooms are kept in - so the Rooms editor follows it too.
function makeRoomCardReorderable(node, host, id) {
  node.dataset.okey = id;
  if (!isUnlocked() || !REARRANGE) return;
  node.draggable = true;
  node.classList.add('cangrab');
  node.addEventListener('dragstart', function (e) {
    ORDER.drag = { kind: 'rooms', key: id, node: node };
    node.classList.add('draggingcard');
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', id); } catch (err) {} }
    e.stopPropagation();
  });
  node.addEventListener('dragover', function (e) {
    if (!ORDER.drag || ORDER.drag.kind !== 'rooms' || ORDER.drag.key === id) return;
    e.preventDefault(); e.stopPropagation();
    var dragged = ORDER.drag.node, sib = Array.prototype.slice.call(host.children);
    if (sib.indexOf(dragged) < sib.indexOf(node)) host.insertBefore(dragged, node.nextSibling);
    else host.insertBefore(dragged, node);
  });
  node.addEventListener('dragend', function (e) {
    node.classList.remove('draggingcard');
    e.stopPropagation();
    if (!ORDER.drag) return;
    ORDER.drag = null; ORDER.justDropped = Date.now();
    var keys = Array.prototype.map.call(host.children, function (c) { return c.dataset.okey; }).filter(Boolean);
    post('order', {rooms: keys}).then(function () { toast('Room order saved', true); forgetSig('heating-tab'); },
      function (e2) { toast('Order not saved: ' + (e2.message || e2), false); tick(true); });
  });
}
$('heat-save').onclick = function () {
  withPin('Save the heating settings', 'The valves are told the new temperature straight away.', function (pin) {
    var rooms = {};
    (HEAT.rows || []).forEach(function (r) {
      rooms[r.id] = {mode: r.mode, comfort_c: r.comfort_c, eco_c: r.eco_c, night_c: r.night_c,
                     plan: r.plan || [], window_stop: r.window_stop !== false, thermometer: r.thermometer || '',
                     windows: r.windows || [], heated: r.heated !== false, control: r.control !== false};
    });
    return post('heating-save', {pin: pin, enabled: HEAT.enabled !== false, away: !!HEAT.away,
                                 away_c: HEAT.away_c, away_from: HEAT.away_from || '', away_to: HEAT.away_to || '',
                                 rooms: rooms}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not save');
      HEAT.dirty = false; $('heat-note').textContent = ''; forgetSig('heating-tab');
      return 'Heating saved';
    });
  });
};
function renderWifiTab(st) {
  var wall = $('wifi-tiles'); wall.innerHTML = '';
  var cfg = st.wifi_config || {};
  var note = $('wifi-tab-note');
  if (!cfg.enabled) {
    note.textContent = 'No controller set up yet \u2014 Control \u2192 Presence.';
    wall.appendChild(el('div', 'muted small', 'Point the dashboard at a UniFi controller and this fills in.'));
    $('wifi-clients-card').hidden = true;
    return;
  }
  $('wifi-clients-card').hidden = false;
  var wifi = st.wifi_detail || {};
  note.textContent = wifi.checked ? 'last looked at ' + ago(wifi.checked)
    : 'waiting for the first look \u2014 it runs every few minutes';
  if (st.wifi_probe_note) {
    var warn = el('div', 'card dev warn');
    var wh = el('div', 'head');
    wh.appendChild(el('div', 'name', 'Nothing recognised'));
    warn.appendChild(wh);
    warn.appendChild(el('div', 'muted small', st.wifi_probe_note
      + '. Press "What does it answer?" above \u2014 it shows the shape of the reply.'));
    wall.appendChild(warn);
  }
  var apiNote = $('wifi-api-note');
  var readWith = (st.wifi_detail || {}).read_with;
  if (cfg.method === 'both') {
    if (readWith === 'signin') {
      apiNote.innerHTML = 'Read by <b>signing in</b>, which is the fuller of the two: every column below is filled in.';
    } else {
      apiNote.innerHTML = 'Set to use both, but the sign-in did not work, so this is the <b>API key</b> talking'
        + ((st.wifi_detail || {}).fell_back ? ' \u2014 ' + esc(st.wifi_detail.fell_back) : '')
        + '. Network, signal and channel stay blank until the sign-in succeeds.';
      apiNote.className = 'note reason';
    }
  } else if (cfg.method === 'official') {
    apiNote.innerHTML = 'Reading over the <b>API key</b>. On 10.6 and later that covers the access points with their '
      + 'radios, channels and widths, the networks with their security and VLANs, and each client with its address, '
      + 'which access point carries it and since when. What it does not report at all is <b>which network a '
      + 'client is joined to, its signal and its channel</b> \u2014 its access field carries only whether the client '
      + 'is a guest. Set <b>Access</b> to <i>Both</i> and give a username and password as well, and those three fill in.';
  } else {
    apiNote.innerHTML = 'Reading over a <b>username and password</b>, which is the fuller of the two interfaces: '
      + 'signal, channel, radio, throughput and the real list of networks with their security.';
  }
  if (cfg.method !== 'both' || readWith === 'signin') apiNote.className = 'note';

  var tiles = wifiTiles(st);
  var order = WIFI_ORDER.rows || (st.wifi_order || []);
  var rank = {'tile-controller': 0, 'tile-ap': 1, 'tile-ssid': 2};
  tiles.sort(function (a, b) {
    var ia = order.indexOf(a.id), ib = order.indexOf(b.id);
    if (ia >= 0 || ib >= 0) return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib);
    // note the explicit check: the first kind ranks 0, and `||` would read
    // that as "no rank" and send the controller to the end
    var ra = rank[a.kind], rb = rank[b.kind];
    return (ra === undefined ? 9 : ra) - (rb === undefined ? 9 : rb);
  });
  // one grid per kind, so every card in a row is the same height as its fellows
  var groups = {}, order2 = [];
  tiles.forEach(function (tile) {
    var kind = tile.kind || 'tile-other';
    if (!groups[kind]) { groups[kind] = []; order2.push(kind); }
    groups[kind].push(tile);
  });
  var titles = {'tile-controller': '', 'tile-ap': 'Access points', 'tile-ssid': 'Networks'};
  var hosts = {};
  order2.forEach(function (kind) {
    var group = el('div', 'wifi-group');
    if (titles[kind]) group.appendChild(el('h3', '', titles[kind]));
    var grid = el('div', 'grid devices');
    group.appendChild(grid);
    wall.appendChild(group);
    hosts[kind] = grid;
  });
  tiles.forEach(function (tile) {
    var host = hosts[tile.kind || 'tile-other'];
    var card = el('div', 'card dev wifi-tile ' + (tile.kind || '') + ' ' + (tile.state || 'ok'));
    card.dataset.tile = tile.id;
    var head = el('div', 'head');
    var nm = el('div');
    nm.appendChild(el('div', 'name', tile.title));
    head.appendChild(nm);
    head.appendChild(el('span', 'spacer'));
    if (tile.tag) head.appendChild(el('span', 'tag ' + (tile.state === 'ok' ? 'ok' : tile.state), tile.tag));
    if (tile.device) {
      var hist = el('button', 'dev-hist'); hist.type = 'button'; hist.innerHTML = iconMarkup('chart', 15);
      hist.title = 'History and charts of ' + tile.title;
      hist.onclick = function (e) { e.stopPropagation(); STATE.hDevice = tile.device; showTab('history'); };
      head.appendChild(hist);
    }
    card.appendChild(head);
    // the model line goes under the name, as on every other card
    var body = el('div');
    tile.build(body);
    Array.prototype.slice.call(body.childNodes).forEach(function (n) {
      if (n.className === 'model') nm.appendChild(n); else card.appendChild(n);
    });
    makeWifiReorderable(card, host, tile.id);
    host.appendChild(card);
  });
  renderWifiOthers(st);
  renderWifiClients_tab(st);
}

// What the air has held, not only what it holds now: one row per network,
// with when it was first and last heard and the best it ever came in.
var WIFI_SEEN_OPEN = false;
function paintWifiSeen(rows) {
  var wrap = $('wifi-seen-wrap'), host = $('wifi-seen'), note = $('wifi-seen-note');
  wrap.hidden = !WIFI_SEEN_OPEN;
  setButtonIcon($('wifi-seen-btn'), WIFI_SEEN_OPEN ? 'up' : 'search',
                WIFI_SEEN_OPEN ? 'Hide the history' : 'Everything ever heard');
  if (!WIFI_SEEN_OPEN) return;
  rows = rows || [];
  note.textContent = rows.length
    ? rows.length + ' network(s) heard since the controller started keeping them. '
      + 'The strongest reading each one ever gave, and when it was last on the air.'
    : 'Nothing written down yet \u2014 the access points are read every few minutes, and what they hear is kept from then on.';
  host.innerHTML = '';
  if (!rows.length) return;
  var head = el('div', 'oth-row head');
  ['Network', 'BSSID', 'Band', 'Channel', 'Best ever', 'Times', 'First heard', 'Last heard']
    .forEach(function (t) { head.appendChild(el('div', '', t)); });
  host.appendChild(head);
  rows.forEach(function (n) {
    var row = el('div', 'oth-row');
    var name = el('div');
    name.appendChild(el('div', '', n.ssid || '(hidden)'));
    if (n.ubiquiti) name.appendChild(el('div', 'muted small', 'a Ubiquiti point'));
    else if (n.security) name.appendChild(el('div', 'muted small', n.security));
    row.appendChild(name);
    row.appendChild(el('div', 'mac', n.bssid || ''));
    row.appendChild(el('div', 'muted small', n.band ? n.band + ' GHz' : ''));
    row.appendChild(el('div', 'muted small', String(n.channel || '')));
    row.appendChild(el('div', '', n.best != null ? n.best + ' dBm' : ''));
    row.appendChild(el('div', 'muted small', String(n.times || '')));
    row.appendChild(el('div', 'muted small', n.first ? ago(n.first) : ''));
    row.appendChild(el('div', 'muted small', n.last ? ago(n.last) : ''));
    host.appendChild(row);
  });
}
function loadWifiSeen() {
  api('wifi-seen').then(function (r) { paintWifiSeen((r && r.networks) || []); },
                        function (e) { toast(e.message || String(e), false); });
}
$('wifi-forget-btn').onclick = function () {
  withPin('Forget every network heard on the air',
          'The record of what the access points have overheard \u2014 other people\u2019s networks, when each was '
          + 'first and last on the air \u2014 is erased. Nothing else is touched, and it fills up again as they '
          + 'are read.', function (pin) {
    return post('wifi-forget', {pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not');
      WIFI_SEEN_OPEN = false;
      paintWifiSeen(null);
      return r.message;
    });
  });
};
$('wifi-seen-btn').onclick = function () {
  WIFI_SEEN_OPEN = !WIFI_SEEN_OPEN;
  paintWifiSeen(null);
  if (WIFI_SEEN_OPEN) loadWifiSeen();
};

function renderWifiOthers(st) {
  var wifi = st.wifi_detail || {};
  var rows = (wifi.neighbours || []).filter(function (n) { return !n.ours; });
  var card = $('wifi-others-card');
  card.hidden = !rows.length;
  if (!rows.length) return;
  // which channels our own radios sit on, so a neighbour sharing one shows it
  var oursOn = {};
  (wifi.aps || []).forEach(function (ap) {
    (ap.radios || []).forEach(function (r) {
      if (r.channel) oursOn[r.band + '|' + r.channel] = (oursOn[r.band + '|' + r.channel] || []).concat(ap.name);
    });
  });
  var host = $('wifi-others'); host.innerHTML = '';
  var head = el('div', 'oth-row head');
  ['Network', 'BSSID', 'Band', 'Channel', 'Width', 'Signal', 'Security', 'Heard by'].forEach(function (t) {
    head.appendChild(el('div', '', t));
  });
  host.appendChild(head);
  rows.slice(0, 40).forEach(function (n) {
    var row = el('div', 'oth-row');
    var name = el('div');
    name.appendChild(el('div', '', n.ssid || '(hidden)'));
    if (n.ubiquiti) name.appendChild(el('div', 'muted small', 'a Ubiquiti point'));
    row.appendChild(name);
    row.appendChild(el('div', 'mac', n.bssid || ''));
    row.appendChild(el('div', 'muted small', n.band ? n.band + ' GHz' : ''));
    var clash = oursOn[n.band + '|' + n.channel];
    var ch = el('div', 'muted small', String(n.channel || ''));
    if (clash) {
      ch.appendChild(el('span', 'chip-clash', 'shared'));
      ch.title = 'the same channel as ' + clash.join(', ') + ' \u2014 they divide the airtime between them';
    }
    row.appendChild(ch);
    row.appendChild(el('div', 'muted small', n.width ? n.width + ' MHz' : ''));
    var sig = el('div', 'muted small');
    if (isNum(n.signal)) sig.appendChild(el('span', signalClass(n.signal), n.signal + ' dBm'));
    row.appendChild(sig);
    row.appendChild(el('div', 'muted small', (n.security || '').replace(/-Personal| \(AES\/CCMP\)/g, '')));
    row.appendChild(el('div', 'muted small', n.seen_by || ''));
    host.appendChild(row);
  });
  if (rows.length > 40) host.appendChild(el('div', 'muted small', 'and ' + (rows.length - 40) + ' more'));
}
function saveWifiOrder(ids) {
  WIFI_ORDER.rows = ids;
  post('wifi-order', {order: ids}).then(function () { toast('Order saved', true); },
    function (e) { toast('Order not saved: ' + (e.message || e), false); });
}
// The same handling the Overview uses: the card moves under the pointer and
// the order is written when it is let go. An earlier attempt keyed off a flag
// that does not exist, so nothing was ever draggable.
function makeWifiReorderable(node, host, id) {
  node.dataset.wkey = id;
  if (!isUnlocked() || !REARRANGE) return;
  node.draggable = true;
  node.classList.add('cangrab');
  node.addEventListener('dragstart', function (e) {
    WIFI_ORDER.drag = {key: id, node: node};
    node.classList.add('draggingcard');
    if (e.dataTransfer) {
      e.dataTransfer.effectAllowed = 'move';
      try { e.dataTransfer.setData('text/plain', id); } catch (err) {}
    }
    e.stopPropagation();
  });
  node.addEventListener('dragover', function (e) {
    if (!WIFI_ORDER.drag || WIFI_ORDER.drag.key === id) return;
    var dragged = WIFI_ORDER.drag.node;
    // An access point does not belong among the networks: a card can be moved
    // within its own section and nowhere else.
    if (dragged.parentNode !== host) return;
    e.preventDefault(); e.stopPropagation();
    var siblings = Array.prototype.slice.call(host.children);
    if (siblings.indexOf(dragged) < siblings.indexOf(node)) host.insertBefore(dragged, node.nextSibling);
    else host.insertBefore(dragged, node);
  });
  node.addEventListener('dragend', function (e) {
    node.classList.remove('draggingcard');
    e.stopPropagation();
    if (!WIFI_ORDER.drag) return;
    WIFI_ORDER.drag = null;
    // the whole wall is written out, not just this section, or the sections
    // left alone would lose the order they were given earlier
    var keys = [];
    Array.prototype.forEach.call(document.querySelectorAll('#wifi-tiles .wifi-group .grid > .card'),
      function (c) { if (c.dataset.wkey) keys.push(c.dataset.wkey); });
    saveWifiOrder(keys);
  });
}

function rateText(bps) {
  if (!isNum(bps) || bps <= 0) return '0';
  if (bps < 1000) return fmt(bps, 0) + ' bps';
  if (bps < 1000000) return fmt(bps / 1000, 1) + ' Kbps';
  return fmt(bps / 1000000, 1) + ' Mbps';
}
function retryClass(pct) {
  // above a tenth of its frames repeated, a client is working hard to be heard
  return pct >= 15 ? 'sig-poor' : (pct >= 8 ? 'sig-ok' : 'sig-good');
}
function signalClass(dbm) {
  // the usual reading of Wi-Fi signal: above -60 is comfortable, below -75 hurts
  return dbm >= -60 ? 'sig-good' : (dbm >= -75 ? 'sig-ok' : 'sig-poor');
}
function renderWifiClients_tab(st) {
  var wifi = st.wifi_detail || {};
  var owner = {};
  ((st.people) || []).forEach(function (p) {
    (p.macs || []).forEach(function (m) { owner[m] = p.name; });
  });
  var host = $('wifi-client-table'); host.innerHTML = '';
  var pw = (st.presence || {}).wifi || {};
  if (pw.ok === false) {
    var bad = el('div', 'note reason');
    bad.innerHTML = '<b>The controller is not answering:</b> ' + esc(pw.error || 'no answer') + (pw.checked ? ' <span class="muted">(last asked ' + ago(pw.checked) + ')</span>' : '');
    host.appendChild(bad);
  }
  var rows = (wifi.clients || []).slice().sort(function (a, b) {
    if (!!a.wired !== !!b.wired) return a.wired ? 1 : -1;
    return String(a.name || a.mac || '').toLowerCase() < String(b.name || b.mac || '').toLowerCase() ? -1 : 1;
  });
  if (!rows.length) {
    host.appendChild(el('div', 'muted small', pw.ok === false ? 'No client list until it answers.'
      : (pw.checked ? 'The controller listed nobody ' + ago(pw.checked) + '.' : 'Nothing listed yet \u2014 the controller has not been asked since the daemon started.')));
    return;
  }
  var head = el('div', 'wc-row wide head');
  ['Device', 'Address', 'Network', 'Access point', 'Radio', 'Signal', 'Traffic', 'Connected', 'Belongs to']
    .forEach(function (t) { head.appendChild(el('div', '', t)); });
  host.appendChild(head);
  rows.forEach(function (c) {
   try {
    var row = el('div', 'wc-row wide' + (owner[c.mac] ? ' taken' : ''));
    var name = el('div');
    name.appendChild(el('div', '', c.name || c.hostname || '(no name)'));
    name.appendChild(el('div', 'mac', c.mac + (c.vendor ? ' \u00b7 ' + c.vendor : '')));
    if (c.hostname && c.hostname !== c.name) {
      var real = el('div', 'muted small', c.hostname);
      real.title = 'what the device calls itself; the name above is the one set on the controller';
      name.appendChild(real);
    }
    row.appendChild(name);
    row.appendChild(el('div', 'muted small', c.ip || ''));
    var net = el('div', 'muted small');
    if (c.wired) net.textContent = 'on a cable';
    else if (c.kind === 'VPN' || c.kind === 'TELEPORT') net.textContent = c.kind.toLowerCase();
    else if (c.ssid) net.textContent = c.ssid;
    else {
      net.textContent = 'Wi-Fi';
      net.title = 'Which network, exactly, is not something the API key reports.';
    }
    if (c.guest) net.appendChild(el('span', 'chip-guest', 'guest'));
    row.appendChild(net);
    row.appendChild(el('div', 'muted small', c.ap_name || ''));
    var radio = el('div', 'muted small');
    if (!c.wired && (c.technology || c.band)) {
      radio.appendChild(el('div', '', [c.technology, c.chains].filter(Boolean).join(' ')));
      radio.appendChild(el('div', 'muted', [c.band ? c.band + ' GHz' : '', c.channel ? 'ch ' + c.channel : '',
        c.width ? c.width + ' MHz' : ''].filter(Boolean).join(' \u00b7 ')));
    }
    row.appendChild(radio);
    var sig = el('div', 'muted small');
    if (isNum(c.signal)) {
      sig.appendChild(el('span', signalClass(c.signal), c.signal + ' dBm'));
      if (isNum(c.retry_pct)) {
        var rt = el('div', retryClass(c.retry_pct), fmt(c.retry_pct, 1) + '% retries');
        rt.title = 'how much of what it sends has to go out again. Above a tenth means a client '
          + 'struggling to be heard, whatever the signal says'
          + (isNum(c.experience) ? '. Experience ' + c.experience + '%' : '');
        sig.appendChild(rt);
      } else if (isNum(c.experience)) {
        sig.appendChild(el('div', 'muted', c.experience + '% experience'));
      }
    } else if (!c.wired) {
      sig.textContent = '\u2013';
      sig.title = 'The official controller API does not report signal strength. Signing in with a password instead does.';
    }
    row.appendChild(sig);
    var flow = el('div', 'muted small');
    if (isNum(c.down_bps) || isNum(c.up_bps)) {
      flow.appendChild(el('div', '', '\u2193 ' + rateText(c.down_bps) + '  \u2191 ' + rateText(c.up_bps)));
    }
    if (isNum(c.usage) && c.usage > 0) flow.appendChild(el('div', 'muted', sizeText(c.usage) + ' total'));
    row.appendChild(flow);
    var when = el('div', 'muted small');
    var started = c.since ? (isNum(c.since) ? c.since : Date.parse(c.since) / 1000) : null;
    if (isNum(c.uptime)) when.textContent = runtimeText(c.uptime);
    else if (started) when.textContent = ago(started).replace(' ago', '');
    row.appendChild(when);
    row.appendChild(el('div', 'muted small', owner[c.mac] || ''));
    host.appendChild(row);
   } catch (e) {
    // one odd client record must not blank the whole list
    var broken = el('div', 'wc-row wide'); broken.appendChild(el('div', 'muted small', (c && (c.name || c.mac)) || '?'));
    broken.appendChild(el('div', 'muted small', 'could not be drawn: ' + e.message)); host.appendChild(broken);
   }
  });
}

$('wifi-refresh').onclick = function () {
  withPin('Ask the controller', 'Reads the access points, the networks and everyone on them. It is only for looking at.', function (pin) {
    $('wifi-tab-note').textContent = 'asking\u2026';
    return post('wifi-detail', {pin: pin}).then(function (r) {
      if (!r.ok) { $('wifi-tab-note').textContent = r.error || 'failed'; throw new Error(r.error || 'failed'); }
      tick(true);
      return 'The controller answered';
    });
  });
};

// ---- the band of things that have not been seen yet --------------------------------
function renderAlertBand(st) {
  var band = $('alertband'), rows = (st && st.alerts) || [];
  band.classList.toggle('show', rows.length > 0);
  if (!rows.length) return;
  var texts = $('alertband-texts'); texts.innerHTML = '';
  rows.slice(-2).reverse().forEach(function (a) {
    var line = el('div', 'one');
    line.appendChild(document.createTextNode(a.text));
    line.appendChild(el('span', 'when', ago(a.ts)));
    line.title = a.text;
    texts.appendChild(line);
  });
  if (rows.length > 2) texts.appendChild(el('div', 'more', 'and ' + (rows.length - 2) + ' more \u2014 all of them are under Events'));
  var bell = band.querySelector('.bell');
  if (!bell.firstChild) bell.innerHTML = iconMarkup('bell', 20);
  $('alertband-clear').textContent = rows.length > 1 ? ('Clear all ' + rows.length) : 'Clear';
}
$('alertband-clear').onclick = function () {
  withPin('Clear the alerts', 'They stay in Events either way; this only takes the band off the page.', function (pin) {
    return post('alerts-clear', {pin: pin}).then(function (r) {
      renderAlertBand({alerts: r.alerts || []});
      tick(true);
      return 'Cleared ' + r.cleared;
    });
  });
};

// ---- messages people write themselves ----------------------------------------------
var MESSAGES = {rows: null, dirty: false};
function markMessages() { MESSAGES.dirty = true; $('messages-dirty').textContent = 'Unsaved changes'; }

function renderMessages(st) {
  if (MESSAGES.rows === null && st) MESSAGES.rows = JSON.parse(JSON.stringify(st.messages || []));
  var rows = MESSAGES.rows || [];
  var host = $('messages-list'); host.innerHTML = '';
  if (!rows.length) {
    host.appendChild(el('div', 'muted small', 'None yet. One saying what happened, in your own words, beats the automatic description.'));
  }
  rows.forEach(function (m, i) {
    var card = el('div', 'msg-card');
    var top = el('div', 'msg-top');
    var field = function (label, node) {
      var box = el('div', 'msg-field');
      box.appendChild(el('label', '', label));
      box.appendChild(node);
      return box;
    };
    var name = el('input'); name.value = m.name || ''; name.placeholder = 'Break-in';
    name.oninput = function () { m.name = name.value; markMessages(); };
    top.appendChild(field('Name', name));

    var title = el('input'); title.value = m.title || ''; title.placeholder = '(the level)';
    title.title = 'The heading the notification carries. Placeholders work here too; left blank it says PROBLEM or Warning.';
    title.oninput = function () { m.title = title.value; markMessages(); schedulePreview(); };
    attachFactCompleter(title, function (v) { m.title = v; markMessages(); schedulePreview(); });
    top.appendChild(field('Heading', title));

    var critCell = el('div', 'sw-cell');
    critCell.appendChild(makeSwitch(m.level === 'crit', function (on) { m.level = on ? 'crit' : 'warn'; markMessages(); schedulePreview(); },
      {small: true, title: 'Critical: sent at the highest priority the channel allows, written to Events as a problem, '
        + 'and left standing in a band across the top of the page until somebody clears it.'}));
    critCell.appendChild(el('span', 'sw-cap', 'stays on screen'));
    top.appendChild(field('Critical', critCell));

    var quiet = el('input'); quiet.type = 'number'; quiet.min = 0; quiet.max = 86400;
    quiet.value = (m.quiet_s === undefined || m.quiet_s === null) ? 900 : m.quiet_s;
    quiet.title = 'The same message is not sent again inside this many seconds. 0 sends every time \u2014 a tripping sensor can then fill a phone.';
    quiet.oninput = function () { m.quiet_s = quiet.value === '' ? 0 : parseInt(quiet.value, 10); markMessages(); };
    // One box for both: type a name and the people who have a number are
    // offered; type a number and it stands as it is. Ctrl+Space shows
    // everybody, the way the facts picker does.
    var smsTo = el('input'); smsTo.type = 'text'; smsTo.className = 'msg-smsto'; smsTo.autocomplete = 'off';
    smsTo.value = (m.sms_to || []).join(', ');
    smsTo.placeholder = 'Falco, +420 777 123 456 \u2014 empty sends it to the gateway\u2019s own list';
    smsTo.title = 'Who this one goes to by text. Start typing a name and the people with a number are offered; '
      + 'a number can be typed straight in. Ctrl+Space shows everybody. Several are separated by commas.';
    smsTo.oninput = function () {
      m.sms_to = smsTo.value.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
      markMessages();
    };
    attachWhoCompleter(smsTo, st, function () { m.sms_to = smsTo.value.split(',').map(function (x) { return x.trim(); }).filter(Boolean); markMessages(); });
    top.appendChild(field('Repeat after (s)', quiet));
    // which way it travels. All three by default: switching one off is a
    // deliberate act, and the row underneath only appears when SMS is on.
    var ways = el('div', 'msg-ways');
    [['ntfy', ICON.bell + ' ntfy', 'Send this one through ntfy'],
     ['telegram', '\u2708\ufe0f Telegram', 'Send this one through Telegram'],
     ['sms', '\ud83d\udcf1 SMS', 'Send this one as a text through the gateway']].forEach(function (w) {
      var cell = el('label', 'msg-way');
      cell.appendChild(makeSwitch(m[w[0]] !== false, function (on) {
        m[w[0]] = on; markMessages();
        smsWho.hidden = !(m.sms !== false);
      }, {small: true, title: w[2]}));
      cell.appendChild(el('span', '', w[1]));
      ways.appendChild(cell);
    });
    top.appendChild(field('Which way', ways));

    var smsWho = el('div', 'msg-smswho');
    smsWho.hidden = m.sms === false;
    var anyone = el('label', 'msg-way');
    anyone.appendChild(makeSwitch(!!m.sms_anyone, function (on) {
      m.sms_anyone = on; markMessages();
      smsTo.disabled = on;
      smsTo.parentNode.classList.toggle('off', on);
    }, {small: true, title: 'Send it to everybody who has a number on their card'}));
    anyone.appendChild(el('span', '', 'anybody with a number'));
    smsWho.appendChild(anyone);
    var toCell = el('div', 'msg-towrap' + (m.sms_anyone ? ' off' : ''));
    smsTo.disabled = !!m.sms_anyone;
    toCell.appendChild(field('Or these people and numbers', smsTo));
    smsWho.appendChild(toCell);

    var acts = el('div', 'msg-actions');
    var test = el('button', 'btn small iconbtn'); test.type = 'button';
    test.innerHTML = iconMarkup('bell', 15); test.title = 'Send this one now, to see how it arrives';
    test.onclick = function () {
      if (MESSAGES.dirty) { toast('Save first \u2014 the test sends what is stored', false); return; }
      withPin('Send "' + (m.name || 'this message') + '"', 'It goes to the notification channel with made-up facts.', function (pin) {
        return post('messages', {send: m.id, pin: pin}).then(function (r) { return 'Sent: ' + r.sent; });
      });
    };
    var drop = el('button', 'btn small iconbtn danger'); drop.type = 'button';
    drop.innerHTML = iconMarkup('trash', 15); drop.title = 'Remove this message';
    drop.onclick = function () { MESSAGES.rows.splice(i, 1); markMessages(); renderMessages(); };
    acts.appendChild(test); acts.appendChild(drop);
    top.appendChild(el('div'));
    top.appendChild(acts);
    card.appendChild(top);

    var body = el('div', 'msg-body');
    var text = el('textarea'); text.rows = 8; text.value = m.text || '';
    text.style.resize = 'vertical';
    text.title = 'What the notification says. Several lines are fine; {device}, {value}, {time} and {Name.key} are filled in when it is sent.';
    text.placeholder = 'Motion at {device} at {time}\nNobody has been home since {away}';
    text.oninput = function () { m.text = text.value; markMessages(); schedulePreview(); };
    attachFactCompleter(text, function (v) { m.text = v; markMessages(); schedulePreview(); });
    body.appendChild(text);

    var tools = el('div', 'msg-tools');
    var emoji = el('button', 'btn small'); emoji.type = 'button'; emoji.textContent = '\ud83d\ude00 Emoji';
    emoji.title = 'Put a symbol where the cursor is';
    emoji.onclick = function (e) { e.stopPropagation(); openEmojiPicker(emoji, text, function (v) { m.text = v; markMessages(); schedulePreview(); }); };
    var field_btn = el('button', 'btn small'); field_btn.type = 'button'; field_btn.textContent = '{ } Facts';
    field_btn.title = 'Put a fact of the moment where the cursor is';
    field_btn.title = 'Every fact with an example of what it would say right now. In the text itself: type { or press Ctrl+Space, and a device name plus . for its readings';
    field_btn.onclick = function (e) { e.stopPropagation(); openFactPicker(field_btn, text, function (v) { m.text = v; markMessages(); schedulePreview(); }); };
    tools.appendChild(emoji); tools.appendChild(field_btn);
    var pic = el('input'); pic.type = 'url'; pic.value = m.image || ''; pic.placeholder = 'https://\u2026 picture (optional)';
    pic.style.maxWidth = '320px';
    pic.title = 'A picture sent with the notification \u2014 a camera snapshot, say. The phone fetches it itself, so the address has to be reachable from where the phone is.';
    pic.oninput = function () { m.image = pic.value; markMessages(); schedulePreview(); };
    tools.appendChild(pic);
    body.appendChild(tools);
    body.appendChild(smsWho);          // who hears it by text, when text is on
    card.appendChild(body);

    var pre = el('div', 'msg-preview'); pre.dataset.for = String(i);
    card.appendChild(pre);
    makeRowSortable(card, host, MESSAGES, markMessages, function () { renderMessages(STATE.status); }, m);
    host.appendChild(card);
  });
  sectionise(host, MESSAGES, 'messages', markMessages, function () { renderMessages(STATE.status); });
  schedulePreview();
}

// Somewhere to pick from, rather than remembering what is allowed.
var PICKER = null;
function closePicker() { if (PICKER) { PICKER.remove(); PICKER = null; } }
document.addEventListener('click', function () { closePicker(); });
function insertAtCursor(box, snippet, after) {
  var start = box.selectionStart === null || box.selectionStart === undefined ? box.value.length : box.selectionStart;
  var end = box.selectionEnd === null || box.selectionEnd === undefined ? start : box.selectionEnd;
  box.value = box.value.slice(0, start) + snippet + box.value.slice(end);
  box.focus({preventScroll: true});
  box.selectionStart = box.selectionEnd = start + snippet.length;
  if (after) after(box.value);
}
function openPicker(anchor, groups, box, after, cls) {
  closePicker();
  var pop = el('div', 'pickbox' + (cls ? ' ' + cls : ''));
  groups.forEach(function (group) {
    pop.appendChild(el('h4', '', group[0]));
    var row = el('div', 'row');
    group[1].forEach(function (item) {
      var b = el('button', '', item[0]); b.type = 'button';
      if (item[1]) b.title = item[1];
      if (cls === 'facts' && item[1]) b.appendChild(el('span', 'd', item[1].split(' \u2014 e.g. ')[0]));
      b.onclick = function (e) {
        e.stopPropagation();
        if (typeof item[3] === 'function') item[3](box, after);      // an entry that knows where it belongs
        else insertAtCursor(box, item[2] === undefined ? item[0] : item[2], after);
        closePicker();
        var ctx = completerContext(box); if (ctx && box.tagName === 'TEXTAREA') openCompleter(box, after, ctx);   // "{Name.key}": continue with the device list
      };
      row.appendChild(b);
    });
    pop.appendChild(row);
  });
  pop.onclick = function (e) { e.stopPropagation(); };
  document.body.appendChild(pop);
  var r = anchor.getBoundingClientRect();
  pop.style.left = Math.max(8, Math.min(r.left + window.scrollX, window.innerWidth - pop.offsetWidth - 12)) + 'px';
  // under the button when it fits, above it when it does not
  if (window.innerHeight - r.bottom < pop.offsetHeight + 8 && r.top > pop.offsetHeight + 8) pop.style.top = (r.top + window.scrollY - pop.offsetHeight - 6) + 'px';
  else pop.style.top = (r.bottom + window.scrollY + 6) + 'px';
  PICKER = pop;
}
function openEmojiPicker(anchor, box, after) {
  var G = function (title, list) { return [title, list.map(function (e) { return [e]; })]; };
  openPicker(anchor, [
    G('Something is wrong', ['\ud83d\udea8', '\u26a0\ufe0f', '\u2757', '\u203c\ufe0f', '\ud83d\udd25', '\ud83d\udca7', '\ud83c\udf0a', '\ud83d\udca8', '\u26a1', '\ud83e\udea8', '\ud83d\udd12', '\ud83d\udd13', '\ud83d\udd11', '\ud83d\udc41\ufe0f', '\ud83c\udfc3', '\ud83d\udeb6', '\ud83d\udc64', '\ud83d\udea8', '\ud83d\udeab', '\u26d4', '\ud83d\udce2', '\ud83d\udd14', '\ud83d\udd15', '\ud83c\udd98', '\ud83e\uddef', '\ud83d\ude91', '\ud83d\ude92', '\ud83d\ude93', '\ud83d\udee1\ufe0f']),
    G('All fine', ['\u2705', '\u2714\ufe0f', '\ud83d\udc4d', '\ud83d\udc4c', '\ud83d\ude42', '\ud83d\ude0a', '\ud83d\ude34', '\ud83c\udf89', '\ud83c\udf1f', '\u2728', '\ud83d\udc9a', '\ud83d\udfe2', '\ud83d\udfe1', '\ud83d\udd34', '\u26aa', '\u2b55', '\u274c', '\u2716\ufe0f', '\u2753', '\u2139\ufe0f', '\ud83d\udcac', '\ud83d\udccc', '\ud83d\udd0e']),
    G('Around the house', ['\ud83c\udfe0', '\ud83c\udfe1', '\ud83d\udeaa', '\ud83e\ude9f', '\ud83d\udd11', '\ud83d\udca1', '\ud83d\udd26', '\ud83d\udd6f\ufe0f', '\ud83d\udd0c', '\ud83d\udd0b', '\ud83e\udeab', '\ud83d\udcfa', '\ud83d\udcbb', '\ud83d\udda5\ufe0f', '\ud83c\udfae', '\ud83d\udcf1', '\ud83d\udce1', '\ud83d\udcf6', '\ud83d\udecb\ufe0f', '\ud83d\udecf\ufe0f', '\ud83d\udebf', '\ud83d\udec1', '\ud83d\udebd', '\ud83e\uddf9', '\ud83e\uddfa', '\ud83e\uddfc', '\ud83c\udf73', '\ud83c\udf7d\ufe0f', '\u2615', '\ud83e\uddca', '\ud83c\udf3f', '\ud83e\udeb4', '\ud83d\udc36', '\ud83d\udc31', '\ud83d\udce6', '\ud83d\udce8', '\ud83d\uddd1\ufe0f', '\ud83d\ude97', '\ud83d\udeb2', '\ud83c\udfd7\ufe0f', '\ud83d\udd27', '\ud83e\ude9b', '\ud83d\udd28']),
    G('Weather and warmth', ['\ud83c\udf21\ufe0f', '\ud83d\udd25', '\u2744\ufe0f', '\ud83e\udd76', '\ud83e\udd75', '\ud83d\udca6', '\ud83d\udca7', '\ud83c\udf27\ufe0f', '\u26c8\ufe0f', '\ud83c\udf28\ufe0f', '\u2600\ufe0f', '\ud83c\udf24\ufe0f', '\u26c5', '\u2601\ufe0f', '\ud83c\udf2b\ufe0f', '\ud83c\udf19', '\ud83c\udf03', '\ud83c\udf05', '\ud83c\udf07', '\ud83c\udf08', '\ud83c\udf2c\ufe0f', '\ud83c\udf42', '\ud83c\udf31', '\ud83c\udf3b']),
    G('People and time', ['\ud83d\udc64', '\ud83d\udc65', '\ud83d\udc68', '\ud83d\udc69', '\ud83d\udc76', '\ud83d\udc75', '\ud83d\udc74', '\ud83d\udc4b', '\ud83e\udd1d', '\ud83d\udeb6\u200d\u2642\ufe0f', '\ud83c\udfc3\u200d\u2640\ufe0f', '\u23f0', '\u23f1\ufe0f', '\u23f3', '\ud83d\udd50', '\ud83d\udcc5', '\ud83d\uddd3\ufe0f', '\ud83c\udf05', '\ud83c\udf1c', '\ud83d\udecc', '\ud83d\udcaa', '\ud83d\ude4c']),
    G('Energy and numbers', ['\u26a1', '\ud83d\udd0b', '\ud83e\udeab', '\ud83d\udcb0', '\ud83d\udcb8', '\ud83d\udcb6', '\ud83d\udcc8', '\ud83d\udcc9', '\ud83d\udcca', '\ud83d\udd22', '\ud83c\udf21\ufe0f', '\ud83d\udcaf', '\u267b\ufe0f', '\ud83c\udf1e', '\ud83d\udd0c', '\u2699\ufe0f', '\ud83e\udde0', '\ud83e\udd16', '\ud83d\udef0\ufe0f', '\ud83d\udce1', '\ud83c\udf10']),
    G('Arrows and marks', ['\u27a1\ufe0f', '\u2b05\ufe0f', '\u2b06\ufe0f', '\u2b07\ufe0f', '\u2194\ufe0f', '\ud83d\udd01', '\ud83d\udd04', '\u25b6\ufe0f', '\u23f9\ufe0f', '\u23f8\ufe0f', '\u2022', '\u2013', '\u2192', '\u2190', '\u2191', '\u2193', '\u00b7', '\u2014', '\u00b0', '\u2103', '\u2105', '\u00bd'])
  ], box, after);
}
// Every fact a message can carry, in one place: the {} Facts button, the
// Ctrl+Space / "{" completer in the editor and the README all say the same.
// Examples are taken from the live status where there is one to take.
function factCatalogue() {
  var st = STATE.status || {}, now = new Date(), pad = function (n) { return (n < 10 ? '0' : '') + n; };
  var devs = st.devices || [];
  var attention = devs.filter(function (d) { return d.level === 'warn' || d.level === 'crit'; });
  var people = ((st.presence || {}).people || []);
  var inside = people.filter(function (p) { return p.home; }).map(function (p) { return p.name; });
  var outside = people.filter(function (p) { return !p.home; }).map(function (p) { return p.name; });
  var astro = st.astro || {};
  var hhmm = function (m) { return m === null || m === undefined ? '' : pad(Math.floor(m / 60)) + ':' + pad(m % 60); };
  var minute = now.getHours() * 60 + now.getMinutes();
  var pir = devs.filter(function (d) { return d.values && d.values.occupancy; })[0] || devs.filter(function (d) { return d.temperature !== null && d.temperature !== undefined; })[0] || devs[0] || {};
  return [
    ['What set it off', [
      ['device', 'the device that reported', pir.name || 'PIR-Chodba'],
      ['key', 'which reading', pir.values && pir.values.occupancy ? 'occupancy' : 'temperature'],
      ['value', 'the reading itself', pir.values && pir.values.occupancy ? '1' : '21.4'],
      ['unit', 'its unit', pir.values && pir.values.occupancy ? '' : '\u00b0C'],
      ['label', 'the reading\u2019s label', pir.values && pir.values.occupancy ? 'Occupancy' : 'Temperature'],
      ['action', 'what was done (on, off, toggle, pulse)', 'on'],
      ['rule', 'the rule\u2019s own line, when a rule set it off', 'PIR-Chodba occupancy == 1'],
      ['threshold', 'the number the rule watches', '1'],
      ['compare', 'how it compares (>=, ==, \u2026)', '=='],
      ['room', 'the room that device belongs to', 'Chodba'],
      ['target', 'what was switched', 'Light-Chodba']]],
    ['What kind of thing it was', [
      ['level', 'how serious: info, warn or crit', 'warn'],
      ['origin', 'what set it off, in the daemon\u2019s own words', 'rule: PIR-Chodba occupancy 1 == 1'],
      ['was', 'the reading before this one', '0'],
      ['since', 'how long it had been that way', '2 h 14 min']]],
    ['When a text message set it off', [
      ['sms_from', 'the number it came from', '+420777123456'],
      ['sms_number', 'the same, with the spaces taken out', '+420777123456'],
      ['sms_text', 'what it said, in full', 'heating 22'],
      ['sms_phrase', 'the words it was matched on', 'heating'],
      ['sms_rest', 'what followed those words', '22'],
      ['sms_first_word', 'its first word', 'heating'],
      ['sms_words', 'how many words', '2'],
      ['sms_length', 'how many characters', '10'],
      ['sms_to', 'who alerts go to by SMS', ((st.sms || {}).to) || '+420777123456']]],
    ['The house as a whole', [
      ['power_now', 'what everything is drawing right now', '412.5'],
      ['power_sockets', 'what the sockets are drawing', '389.0'],
      ['power_lights', 'what the lights are drawing', '23.5'],
      ['power_peak_today', 'the most it has drawn today', '1240.0'],
      ['plugs_on', 'how many sockets are on', '5'],
      ['plugs_on_list', 'and which they are', 'Plug-UPS, Light-Chodba'],
      ['coldest_room', 'the coldest room', 'Workshop'],
      ['warmest_room', 'the warmest room', 'Loznice'],
      ['rooms_heating', 'how many rooms are calling for heat', '2'],
      ['devices_quiet', 'how many have said nothing for six hours', '0'],
      ['uptime', 'how long this has been running', '3 d 4 h'],
      ['version', 'which version it is', '3.12.0'],
      ['second_factor', 'what a one-tap link asks for beyond its secret', 'Duo'],
      ['tap_mode', 'which road a one-tap link may be opened by', 'by a header only'],
      ['tap_links', 'how many one-tap links there are', '6'],
      ['tap_phones', 'how many phones carry a six-digit code', '1'],
      ['duo_user', 'the Duo account a press is sent to \u2014 empty when Duo is not set up', 'administrator'],
      ['duo_device', 'the device a press is pushed to', 'iPhone16 (+420 603 364 754)'],
      ['duo_ready', 'whether Duo is set up \u2014 yes or no', 'yes'],
      ['presses_waiting', 'presses waiting for somebody to approve them', '0'],
      ['presses_today', 'presses of a one-tap link in the last day', '14'],
      ['presses_refused_today', 'how many of those were refused', '2'],
      ['blocked_count', 'how many addresses may not talk to the API', '3'],
      ['blocked_list', 'those addresses, up to a dozen of them', '89.24.5.7, 89.24.5.9'],
      ['blocked_last', 'the one blocked most recently', '89.24.5.7'],
      ['blocked_last_why', 'and what earned it', '3 in ten minutes: bad-secret'],
      ['blocking', 'how blocking is set \u2014 off, temporary or permanent', 'temporary'],
      ['mikrotik', 'whether the router carries the list too', 'in step'],
      ['mikrotik_list', 'the address list on the router', 'zigmon'],
      ['mikrotik_synced', 'how long ago the router was last brought in step', '4 min ago'],
      ['args', 'whatever the message carried after the phrase', '1.1.1.1'],
      ['sim_plan', 'what kind of SIM the modem carries', 'prepaid'],
      ['sim_prepaid', 'whether it has credit at all \u2014 yes or no', 'yes'],
      ['credit', 'what the operator last said about the SIM \u2014 empty on a contract', 'Vas kredit je 247.50 Kc'],
      ['credit_left', 'the credit as a number', '400'],
      ['credit_total', 'the credit and any bonus together', '494.9'],
      ['credit_until', 'the day it runs out', '11.09.2027']]],
    ['What it costs', [
      ['month_kwh', 'what the month has used so far', '34.3'],
      ['month_cost', 'and what that comes to', '223'],
      ['month_forecast', 'what the month is heading for at that rate', '410'],
      ['last_month_cost', 'what last month came to', '389'],
      ['price_per_kwh', 'the price a unit is set to', '6.50'],
      ['currency', 'the currency', 'K\u010d'],
      ['costliest_socket', 'which socket has cost the most', 'Plug-UPS']]],
    ['The weather outside', [
      ['outside_c', 'the temperature outside', '13.3'],
      ['feels_c', 'what it feels like', '11.8'],
      ['weather', 'the sky, in a word', '\ud83c\udf26\ufe0f light rain'],
      ['wind', 'the wind', '6.8'],
      ['rain_mm', 'the rain so far', '0.4'],
      ['today_max', 'the warmest it will be today', '14.7'],
      ['today_min', 'and the coldest', '6.2']]],
    ['Whether the house is well', [
      ['device_count', 'how many devices there are', '63'],
      ['lowest_battery', 'the lowest battery of the lot', '34'],
      ['worst_signal', 'the weakest signal of the lot', '60'],
      ['bindings_lost', 'how many have lost their Zigbee configuration', '0'],
      ['broker', 'whether the broker is there', 'connected'],
      ['bridge', 'what Zigbee2MQTT says of itself', 'online'],
      ['database_mb', 'how big the database is', '248.4'],
      ['events_today', 'how much has happened today', '25'],
      ['last_backup', 'how long ago the last backup was', '9 h 12 min'],
      ['taps', 'how many one-tap links there are', '4'],
      ['taps_on', 'how many of them are switched on', '3'],
      ['taps_used_today', 'how many were used today', '2'],
      ['power_hour_peak', 'the most the house drew this hour', '1240'],
      ['power_week_peak', 'and this week', '2310'],
      ['sockets_on_count', 'how many sockets are on', '5'],
      ['lights_on_count', 'how many lights are on', '3'],
      ['quiet_until', 'how long the alerts stay hushed, if they are', '42 min'],
      ['wifi_clients', 'how many things are on the WiFi', '14'],
      ['wifi_points', 'how many access points', '2'],
      ['busiest_radio', 'the busiest radio, and how busy', '2.4 GHz at 51%']]],
    ['Whoever sent it', [
      ['person', 'their name, if the number is on a card', 'Falco'],
      ['sms_person', 'the same thing, said the other way', 'Falco'],
      ['person_known', 'whether the number belongs to anybody', 'yes'],
      ['person_home', 'whether they are home', 'no'],
      ['person_since', 'how long they have been that way', '2 h 14 min'],
      ['person_device', 'what the controller sees them by', 'iPhone'],
      ['person_may_command', 'whether they may switch things by text', 'yes'],
      ['person_gets_alerts', 'whether alerts go to them', 'yes']]],
    ['The SMS gateway', [
      ['sms_signal', 'its signal, in dBm', '-71'],
      ['sms_operator', 'the operator it is on', 'Vodafone CZ'],
      ['sms_network', 'the network it has', 'LTE'],
      ['sms_sent_today', 'messages sent in the last day', '3'],
      ['sms_received_today', 'messages received in the last day', '1']]],
    ['Doors, windows and batteries', [
      ['open_now', 'what is open, by name', 'Dvere-Balkon'],
      ['open_count', 'how many are open', '0'],
      ['batteries_low', 'which batteries are at 30 % or less', 'PIR-Satna 22%']]],
    ['How much of everything there is', [
      ['devices_total', 'devices known', String((st.devices || []).length)],
      ['plugs_total', 'sockets and lights', String((st.plugs || []).length)],
      ['scenes_total', 'scenes', String((st.scenes || []).length)],
      ['sequences_total', 'sequences', String((st.sequences || []).length)],
      ['schedules_total', 'schedules', '2'],
      ['bindings_total', 'button bindings', String((st.bindings || []).length)],
      ['sms_commands_total', 'things a text message may do', String((st.sms || {}).commands || 0)]]],
    ['When a sensor group set it off', [
      ['group', 'the group\u2019s name', ((st.sensor_groups || [])[0] || {}).name || 'PIR downstairs'],
      ['trigger', 'which member of it moved', (((st.sensor_groups || [])[0] || {}).trigger || {}).device || 'PIR-Kuchyne'],
      ['trigger_value', 'what that member read', (((st.sensor_groups || [])[0] || {}).trigger || {}).value !== undefined ? String((((st.sensor_groups || [])[0] || {}).trigger || {}).value) : '1'],
      ['trigger_ago', 'how long ago it moved', '2 min'],
      ['members', 'how many sensors are in the group', String((((st.sensor_groups || [])[0] || {}).members || []).length || 3)]]],
    ['The house as a whole', [
      ['plugs_on', 'how many sockets are on', String((st.plugs || []).filter(function (p) { return p.output === 1; }).length)],
      ['plugs_on_list', 'which sockets are on, by name', (st.plugs || []).filter(function (p) { return p.output === 1 && p.role !== 'light'; }).map(function (p) { return p.name; }).slice(0,2).join(', ') || 'nothing'],
      ['lights_on', 'how many lights are on', String((st.plugs || []).filter(function (p) { return p.output === 1 && p.role === 'light'; }).length)],
      ['lights_on_list', 'which lights are on, by name', (st.plugs || []).filter(function (p) { return p.output === 1 && p.role === 'light'; }).map(function (p) { return p.name; }).slice(0,2).join(', ') || 'none'],
      ['everything_on', 'every socket and light that is on', 'Plug-UPS, Light-Chodba'],
      ['people_home', 'who is in', 'Falco'],
      ['people_out', 'who is out', 'nobody'],
      ['quiet_list', 'which devices have gone quiet', 'PIR-Satna, Temp-Lednice'],
      ['devices_offline', 'how many devices are not answering', String((st.devices || []).filter(function (d) { return d.availability === 'offline'; }).length)],
      ['uptime', 'how long the daemon has been running', '3 days']]],
    ['Heating', [
      ['heating_on', 'is heating control on \u2014 yes or no', (st.heating || {}).enabled === false ? 'no' : 'yes'],
      ['heating_away', 'is away mode on', (st.heating || {}).away ? 'yes' : 'no'],
      ['rooms_heated', 'how many rooms are heated', String(((st.heating || {}).rooms || []).filter(function (r) { return r.heated !== false; }).length)],
      ['rooms_calling', 'how many are below what they hold', '1'],
      ['rooms_manual', 'how many are left to their own head', String((((st.heating || {}).rooms) || []).filter(function (r) { return r.mode === 'manual'; }).length)],
      ['warmest_room', 'the warmest room right now', (((st.heating || {}).rooms || [])[0] || {}).name || 'Loznice'],
      ['coldest_room', 'the coldest room right now', (((st.heating || {}).rooms || [])[1] || {}).name || 'Kuchyne'],
      ['inside_c', 'the average of the rooms\u2019 thermometers', '22.4']]],
    ['The automation itself', [
      ['rules_total', 'how many rules exist', String((st.rules || []).length)],
      ['rules_off', 'how many are switched off', String((st.rules || []).filter(function (r) { return r.enabled === false; }).length)],
      ['groups_total', 'how many sensor groups exist', String((st.sensor_groups || []).length)]]],
    ['The network', [
      ['wifi_clients', 'devices on the Wi-Fi', String(((st.wifi_detail || {}).counts || {}).clients || 0)],
      ['wifi_aps', 'access points the controller reports', String(((st.wifi_detail || {}).aps || []).length)],
      ['wifi_ssid', 'the networks they carry', (((st.wifi_detail || {}).ssids || [])[0] || {}).name || 'Falco']]],
    ['Electricity', [
      ['month_kwh', 'this month so far, kWh', String((st.money || {}).month_kwh || 0)],
      ['month_cost', 'this month so far, in money', String((st.money || {}).month_cost || 0)],
      ['forecast_cost', 'what the month is heading for', String((st.money || {}).forecast_cost || 0)],
      ['currency', 'the currency from the settings', (st.money || {}).currency || 'K\u010d']]],
    ['More about that device', [
      ['model', 'its model', pir.model || 'SNZB-03P'],
      ['battery', 'its battery, %', pir.battery !== null && pir.battery !== undefined ? pir.battery : '94'],
      ['signal', 'its link quality (Zigbee) or RSSI (Wi-Fi)', pir.linkquality || '104'],
      ['temperature', 'its temperature, if it reports one', '21.4'],
      ['humidity', 'its humidity, if it reports one', '48']]],
    ['What it acted on', [
      ['target', 'the plug, switch or scene', (st.plugs && st.plugs[0] && st.plugs[0].name) || 'Light-Vchod']]],
    ['Who and when', [
      ['person', 'the person who came or went', (people[0] || {}).name || 'Petr'],
      ['home', 'who is in, comma-separated', inside.join(', ') || 'Petr, Jana'],
      ['away', 'who is out', outside.join(', ') || 'Tom'],
      ['home_count', 'how many are in', inside.length],
      ['anyone_home', 'yes or no', (st.presence || {}).anyone_home === false ? 'no' : 'yes'],
      ['time', 'the clock, HH:MM', pad(now.getHours()) + ':' + pad(now.getMinutes())],
      ['date', 'today, YYYY-MM-DD', now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate())],
      ['weekday', 'Monday \u2026 Sunday', ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][now.getDay()]],
      ['sunrise', 'today\u2019s sunrise (needs latitude/longitude in the settings)', hhmm(astro.sunrise) || '06:12'],
      ['sunset', 'today\u2019s sunset', hhmm(astro.sunset) || '19:41'],
      ['daylight', 'day or night, by the sun', astro.sunrise !== undefined && astro.sunrise !== null ? (minute >= astro.sunrise && minute < astro.sunset ? 'day' : 'night') : 'night']]],
    ['The house', [
      ['attention', 'how many devices need attention', attention.length],
      ['attention_list', 'which ones, comma-separated', attention.map(function (d) { return d.name; }).slice(0, 3).join(', ') || '(none)'],
      ['alerts', 'standing critical alerts', (st.alerts || []).length],
      ['uptime', 'how long the daemon has run', '3d 4h']]],
    ['The whole thing', [
      ['origin', 'the automatic one-line description', 'rule: ' + (pir.name || 'PIR-Chodba') + ' occupancy 1 == 1']]],
    ['Turns of phrase \u2014 put one after any fact, as {plugs_on_list.nl}', [
      ['\u2026nl', 'each one on its own line', 'Plug-UPS\u23ceWorkshop-PC'],
      ['\u2026bullets', 'each on its own line with a bullet', '\u2022 Plug-UPS\u23ce\u2022 Workshop-PC'],
      ['\u2026dashes', 'the same with a dash', '- Plug-UPS\u23ce- Workshop-PC'],
      ['\u2026numbered', 'numbered, one per line', '1. Plug-UPS\u23ce2. Workshop-PC'],
      ['\u2026count', 'how many there are', '4'],
      ['\u2026first', 'only the first', 'Plug-UPS'],
      ['\u2026last', 'only the last', 'Workshop-PC'],
      ['\u2026sort', 'in alphabetical order', 'Plug-UPS, Workshop-PC'],
      ['\u2026and', 'commas, and "and" before the last', 'Plug-UPS, Workshop-PC and Workshop-TV'],
      ['\u2026or', 'the same with "or"', 'Plug-UPS, Workshop-PC or Workshop-TV'],
      ['\u2026three', 'the first three, then how many more', 'A, B, C and 4 more'],
      ['\u2026upper', 'IN CAPITALS', 'PLUG-UPS'],
      ['\u2026lower', 'in small letters', 'plug-ups'],
      ['\u2026title', 'First Letters Capital', 'Plug-Ups'],
      ['\u2026round', 'a number with no decimals', '22'],
      ['\u2026round1', 'a number to one decimal', '21.7'],
      ['\u2026trim', 'spare spaces and line breaks squeezed out', 'one two'],
      ['\u2026quiet', 'nothing at all when there is nothing to say', ''],
      ['\u2026sentence', 'a capital letter to start with', 'Plug-UPS is on'],
      ['\u2026ascii', 'without diacritics \u2014 halves what a text message costs', 'mer teplotu'],
      ['\u2026plain', 'the same thing', 'mer teplotu'],
      ['\u2026oneline', 'line breaks turned into spaces', 'one two three'],
      ['\u2026nospace', 'no spaces at all', 'PlugUPS'],
      ['\u2026slug', 'lower case, words joined by dashes', 'obyvak-tv'],
      ['\u2026short', 'cut short with an ellipsis', 'a long name\u2026'],
      ['\u2026len', 'how many characters', '42'],
      ['\u2026sms', 'how many text messages this will be', '2'],
      ['\u2026url', 'safe to put in a web address', 'Plug%2DUPS'],
      ['\u2026reverse', 'the list backwards', 'C, B, A'],
      ['\u2026unique', 'each one only once', 'A, B'],
      ['\u2026commas', 'back to commas, after nl or bullets', 'A, B, C'],
      ['\u2026spaces', 'separated by spaces', 'A B C'],
      ['\u2026quotes', 'each one in quotation marks', '\u201cA\u201d, \u201cB\u201d'],
      ['\u2026tags', 'each one as a #tag', '#PlugUPS #WorkshopPC'],
      ['\u2026round2', 'a number to two decimals', '21.73'],
      ['\u2026abs', 'a number without its minus sign', '4.2'],
      ['\u2026plus', 'a plus sign when it is above zero', '+3.5'],
      ['\u2026percent', 'a number with a per-cent sign', '87%'],
      ['\u2026thousands', 'thousands spaced apart', '1\u202f234\u202f567'],
      ['\u2026degrees', 'a number with a degree sign', '21.7\u00b0'],
      ['\u2026yesno', 'yes or no, from a reading that is really either', 'yes'],
      ['\u2026onoff', 'on or off, the same way', 'on']]]
  ];
}
// The per-device keys that work after "{Name." on top of everything in All values.
var DEVICE_FACT_KEYS = [
  ['state', 'on / off / unplugged of a plug or switch', 'on'],
  ['age', 'how long since it last reported', '4m'],
  ['battery', 'battery, %', '94'],
  ['signal', 'link quality or RSSI', '104'],
  ['model', 'its model', 'SBHT-203C'],
  ['name', 'its name as shown (alias first)', 'Temp-Venek']
];
// A turn of phrase belongs INSIDE the braces, after the fact it changes.
// Picking one from the Facts list wrote "{\u2026nl}" into the message - ellipsis
// and all - because the list showed it the way the README writes it and the
// button put down what it showed.
function insertFactTurn(box, name, after) {
  var at = box.selectionStart === null || box.selectionStart === undefined ? box.value.length : box.selectionStart;
  var text = box.value;
  var open = text.lastIndexOf('{', Math.max(0, at - 1));
  var close = text.indexOf('}', open < 0 ? 0 : open);
  var put;
  if (open >= 0 && (close < 0 || close >= at)) put = at;             // the caret is in an unclosed {
  else if (text.slice(0, at).slice(-1) === '}') put = at - 1;        // just past one: step back inside it
  else { insertAtCursor(box, '.' + name, after); return; }           // nowhere obvious: as typed
  box.value = text.slice(0, put) + '.' + name + text.slice(put);
  box.focus({preventScroll: true});
  box.selectionStart = box.selectionEnd = put + name.length + 1;
  if (after) after(box.value);
}
function openFactPicker(anchor, box, after, locals) {
  var groups = factCatalogue().map(function (g) {
    var turns = g[0].indexOf('Turns of phrase') === 0;
    return [g[0], g[1].map(function (f) {
      var what = f[1] + (f[2] !== '' && f[2] !== undefined ? ' \u2014 e.g. ' + f[2] : '');
      if (!turns) return ['{' + f[0] + '}', what];
      var name = f[0].replace(/^\u2026/, '');
      return ['.' + name, what, undefined, function (b, af) { insertFactTurn(b, name, af); }];
    })];
  });
  groups.splice(3, 0, ['Any device, right now', [['{Name.key}', 'any device\u2019s current reading: name, dot, key \u2014 pick the device from the list that opens', '{']]]);
  // The names this one rule has made up, first, because they are the ones
  // being written about. They are offered here and nowhere else: two rules
  // may each have a name called ip and neither means the other's.
  var seenName = {}, mine = [];
  (locals ? locals() : []).forEach(function (v) {
    if (!v.name || seenName[v.name.toLowerCase()]) return;
    seenName[v.name.toLowerCase()] = true;
    mine.push([v.name, v.why || 'what this rule catches']);
  });
  if (mine.length) groups.unshift(['This rule\u2019s own names', mine]);
  openPicker(anchor, groups, box, after, 'facts');
}

// ---- IDE-style completion inside the message text -------------------------------
// Typing "{" (or Ctrl+Space anywhere) lists every fact with what it means and
// an example value; typing a device name and "." lists that device's own keys
// with its current reading. Up/Down move, Enter or Tab take, Esc closes.
var COMPLETE = { box: null, pop: null, items: [], sel: 0, start: 0 };
function closeCompleter() { if (COMPLETE.pop) { COMPLETE.pop.remove(); COMPLETE.pop = null; } COMPLETE.box = null; COMPLETE.items = []; }
function completerContext(box) {
  var upto = box.value.slice(0, box.selectionStart);
  var open = upto.lastIndexOf('{');
  if (open < 0 || upto.indexOf('}', open) >= 0) {
    // A box whose lines begin with a word rather than a brace - a script -
    // asks for the list at the start of a line too. Everywhere else a name
    // only means something inside braces, and nothing is offered without
    // one, which is why the verbs never appeared here.
    if (!box.dataset || box.dataset.bareWords !== '1') return null;
    var line = upto.slice(upto.lastIndexOf('\n') + 1);
    if (/\S\s/.test(line)) return null;          // past the first word: the rest is its own
    return {start: box.selectionStart - line.length, token: line, bare: true};
  }
  return {start: open + 1, token: upto.slice(open + 1)};
}
function deviceForFacts(name) {
  var low = name.toLowerCase();
  return (STATE.status && STATE.status.devices || []).filter(function (d) {
    return (d.name || '').toLowerCase() === low || (d.alias || '').toLowerCase() === low || (d.topic_name || '').toLowerCase() === low;
  })[0] || null;
}
// The turns of phrase a fact may be followed by. Written here as well as in
// the daemon because the completer has to offer them as they are typed.
var FACT_TURN_LIST = [
  ['nl', 'each one on its own line', 'Plug-UPS / Workshop-PC'],
  ['lines', 'the same thing', 'Plug-UPS / Workshop-PC'],
  ['bullets', 'one per line with a bullet', '\u2022 Plug-UPS'],
  ['dashes', 'one per line with a dash', '- Plug-UPS'],
  ['numbered', 'numbered, one per line', '1. Plug-UPS'],
  ['count', 'how many there are', '4'],
  ['first', 'only the first', 'Plug-UPS'],
  ['last', 'only the last', 'Workshop-PC'],
  ['sort', 'in alphabetical order', 'A, B, C'],
  ['and', 'commas, and "and" before the last', 'A, B and C'],
  ['or', 'the same with "or"', 'A, B or C'],
  ['three', 'the first three, then how many more', 'A, B, C and 4 more'],
  ['upper', 'IN CAPITALS', 'PLUG-UPS'],
  ['lower', 'in small letters', 'plug-ups'],
  ['title', 'First Letters Capital', 'Plug-Ups'],
  ['round', 'a number with no decimals', '22'],
  ['round1', 'a number to one decimal', '21.7'],
  ['trim', 'spare spaces squeezed out', 'one two'],
  ['quiet', 'nothing at all when there is nothing to say', ''],
  ['sentence', 'a capital letter to start with', 'Plug-UPS is on'],
  ['ascii', 'the same words without diacritics \u2014 halves what a text message costs', 'mer teplotu'],
  ['plain', 'the same thing', 'mer teplotu'],
  ['oneline', 'line breaks turned into spaces', 'one two three'],
  ['nospace', 'no spaces at all', 'PlugUPS'],
  ['slug', 'lower case, words joined by dashes', 'obyvak-tv'],
  ['short', 'cut short with an ellipsis', 'a long name\u2026'],
  ['len', 'how many characters', '42'],
  ['sms', 'how many text messages this will be', '2'],
  ['url', 'safe to put in a web address', 'Plug%2DUPS'],
  ['reverse', 'the list backwards', 'C, B, A'],
  ['unique', 'each one only once', 'A, B'],
  ['commas', 'back to commas, after nl or bullets', 'A, B, C'],
  ['spaces', 'separated by spaces', 'A B C'],
  ['quotes', 'each one in quotation marks', '\u201cA\u201d, \u201cB\u201d'],
  ['tags', 'each one as a #tag', '#PlugUPS #WorkshopPC'],
  ['round2', 'a number to two decimals', '21.73'],
  ['abs', 'a number without its minus sign', '4.2'],
  ['plus', 'a plus sign when it is above zero', '+3.5'],
  ['percent', 'a number with a per-cent sign', '87%'],
  ['thousands', 'thousands spaced apart', '1\u202f234\u202f567'],
  ['degrees', 'a number with a degree sign', '21.7\u00b0'],
  ['yesno', 'yes or no, from a reading that is really either', 'yes'],
  ['onoff', 'on or off, the same way', 'on']
];

// Is this word one of the turns? And what is left of a key once the turns
// already written after it are taken off - the same reading the daemon does
// when it fills the message in, so the list offered matches what will happen.
function isFactTurn(word) {
  var low = String(word || '').toLowerCase();
  return FACT_TURN_LIST.some(function (t) { return t[0] === low; });
}
function factWithoutTurns(key) {
  var parts = String(key || '').split('.');
  while (parts.length > 1 && isFactTurn(parts[parts.length - 1])) parts.pop();
  return parts.join('.');
}
function deviceKeyNames(dev) {
  var names = DEVICE_FACT_KEYS.map(function (k) { return k[0]; });
  Object.keys(dev.values || {}).forEach(function (k) { if (names.indexOf(k) < 0) names.push(k); });
  return names;
}
function turnItems(want, at) {
  var items = [];
  FACT_TURN_LIST.forEach(function (t) {
    if (t[0].indexOf(want) !== 0) return;
    items.push({text: t[0] + '}', label: '.' + t[0], desc: t[1], ex: t[2], close: true, at: at});
  });
  return items;
}
// Names a record has made up for itself - "unban {ip}" makes one called ip -
// offered wherever that record can use them. They belong to the line they are
// written on and to nothing else, so they are handed in rather than kept in
// the one list of facts everything shares.
var COMPLETE_LOCAL = [];
// ---- little scripts ------------------------------------------------------
function loadScripts() {
  // A request that never comes back must not shut the door behind it: the
  // flag is there to stop a dozen of these at once, not to stop them for
  // ever, so it is let go after ten seconds whatever happened.
  if (SCRIPTS.asking && Date.now() - (SCRIPTS.askedAt || 0) < 10000) return;
  SCRIPTS.asking = true;
  SCRIPTS.askedAt = Date.now();
  api('scripts').then(function (r) {
    SCRIPTS.asking = false;
    if (SCRIPTS.dirty) return;
    SCRIPTS.rows = r.scripts || [];
    SCRIPTS.verbs = r.verbs || [];
    paintScripts();
  }, function () { SCRIPTS.asking = false; });
}
function markScripts() { SCRIPTS.dirty = true; $('script-note').textContent = 'Unsaved changes'; }
function verbNames() {
  return (SCRIPTS.verbs || []).map(function (v) {
    return {name: v.verb, why: v.what + ' \u2014 ' + v.example, verb: true};
  });
}
function paintScripts() {
  var host = $('scripts-list'); if (!host) return;
  if (userHolding()) return;
  host.innerHTML = '';
  if (!SCRIPTS.rows.length) {
    host.appendChild(el('p', 'btnhelp', 'No script yet. One name can stand for three things done in order.'));
  }
  SCRIPTS.rows.forEach(function (one, i) {
    var pack = el('div', 'rule-pack');
    var top = el('div', 'btnrow');
    var name = el('input', 'varbox wide');
    name.value = one.name || '';
    name.placeholder = 'what to call it';
    name.oninput = function () { one.name = name.value.slice(0, 40); markScripts(); };
    top.appendChild(name);
    var tryIt = cmdButton('Try it', 'play', 'small');
    tryIt.onclick = function () {
      if (SCRIPTS.dirty) { toast('save it first, then try it', false); return; }
      // A script is written to be given its names by whatever calls it.
      // Tried from here there is no rule to give them, so they are asked for.
      var wants = one.wants || [];
      var runIt = function (facts) {
        withPin('Try "' + (one.name || 'this script') + '"',
          'It runs for real: what it switches will switch, and what it keeps out will be kept out.',
          function (pin) {
            return post('scripts', {pin: pin, try: one.id, facts: facts}).then(function (r) {
              if (!r.ok) throw new Error(r.error || 'could not');
              return (r.said || (r.lines + ' line(s) done'));
            });
          });
      };
      if (!wants.length) { runIt({}); return; }
      var facts = {};
      showDetail('Try "' + (one.name || 'this script') + '"',
                 [{section: 'What to give it, this once'}], null, true);
      var host = $('attnbody');
      host.appendChild(el('p', 'note', 'This script uses ' + wants.map(function (n) {
        return '{' + n + '}';
      }).join(', ') + '. When a command or a link runs it, those come from what that rule caught; '
        + 'tried from here, they come from these boxes.'));
      wants.forEach(function (n) {
        var line = el('div', 'appr-row');
        line.appendChild(el('span', 'appr-link', '{' + n + '}'));
        var box = el('input', 'varbox wide');
        box.placeholder = n === 'ip' ? '89.24.5.7' : 'something to stand for it';
        box.oninput = function () { facts[n] = box.value; };
        line.appendChild(box);
        host.appendChild(line);
      });
      var bar = el('div', 'btnrow');
      var go = cmdButton('Run it', 'play', 'small primary');
      go.classList.remove('needs-unlock');
      go.onclick = function () { $('attnback').hidden = true; runIt(facts); };
      bar.appendChild(go);
      host.appendChild(bar);
    };
    top.appendChild(tryIt);
    var drop = iconButton('trash', 'Take this script away');
    drop.onclick = function () { SCRIPTS.rows.splice(i, 1); markScripts(); paintScripts(); };
    top.appendChild(drop);
    pack.appendChild(top);
    var body = el('textarea', 'tap-story');
    body.rows = Math.max(3, String(one.body || '').split('\n').length + 1);
    body.value = one.body || '';
    body.placeholder = 'ban {ip} 120\nsay {ip} is kept out\non Plug-PorchLight';
    body.oninput = function () { one.body = body.value; markScripts(); };
    body.dataset.bareWords = '1';       // a line begins with a verb, not a brace
    attachFactCompleter(body, function (v) { one.body = v; markScripts(); },
                        function () { return verbNames(); });
    pack.appendChild(body);
    var tools = el('div', 'msg-tools');
    var facts = el('button', 'btn small'); facts.type = 'button'; facts.textContent = '{ } Facts';
    facts.onclick = function (e) {
      e.stopPropagation();
      openFactPicker(facts, body, function (v) { one.body = v; markScripts(); }, verbNames);
    };
    tools.appendChild(facts);
    if ((one.wants || []).length) {
      var uses = el('span', 'muted small');
      uses.textContent = 'uses ' + one.wants.map(function (n) { return '{' + n + '}'; }).join(', ');
      uses.title = 'Names this script expects from whatever runs it. A text command or a link fills '
        + 'them from what it caught: give that rule a variable of the same name.';
      uses.style.marginRight = '10px';
      tools.appendChild(uses);
    }
    var help = el('span', 'muted small');
    help.textContent = (SCRIPTS.verbs || []).map(function (v) { return v.verb; }).join('  ');
    help.title = (SCRIPTS.verbs || []).map(function (v) {
      return v.verb + ' ' + v.takes + ' \u2014 ' + v.what;
    }).join('\n');
    tools.appendChild(help);
    pack.appendChild(tools);
    host.appendChild(pack);
  });
}
$('script-add').onclick = function () {
  SCRIPTS.rows = (SCRIPTS.rows || []).concat([{id: '', name: '', body: '', note: ''}]);
  markScripts(); paintScripts();
};
$('script-save').onclick = function () {
  withPin('Save the scripts', 'Every line is checked before it is kept: one that cannot work is '
    + 'refused while you are looking at it.', function (pin) {
      return post('scripts', {pin: pin, scripts: SCRIPTS.rows}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        SCRIPTS.dirty = false;
        SCRIPTS.rows = r.scripts || [];
        $('script-note').textContent = '';
        paintScripts();
        return r.message;
      });
    });
};
// The names a row has made up for itself, kept on the row and offered only
// there. A variable belongs to the line it was written on: one called ip in
// this command means nothing in the next, and a picker that offered it
// everywhere would be offering something that is empty everywhere else.
function rowVars(row) {
  return ((row && row.vars) || []).map(function (v) {
    return {name: v.name, why: v.note || (v.from === 'phrase' ? 'named in the phrase'
      : (v.from ? 'from ' + v.from : 'what the message carries'))};
  });
}
function editRowVars(row, where, after) {
  var draw = function () {
    var items = [{section: 'Names this ' + where + ' has made up'}];
    showDetail('Variables', items, null, true);
    var host = $('attnbody');
    var list = el('div');
    (row.vars || []).forEach(function (v, i) {
      var line = el('div', 'appr-row');
      var nameBox = el('input', 'varbox');
      nameBox.value = v.name;
      nameBox.placeholder = 'name';
      nameBox.title = 'The name, written {like_this} wherever this ' + where + ' uses it';
      nameBox.oninput = function () {
        v.name = nameBox.value.replace(/[^A-Za-z0-9_]/g, '').slice(0, 24);
        nameBox.value = v.name;
      };
      line.appendChild(nameBox);
      var fromBox = el('input', 'varbox wide');
      fromBox.value = v.from || '';
      fromBox.placeholder = where === 'command'
        ? 'in order  (or all, or 2)'
        : 'X-Zigmon-Arg-' + (v.name || 'name') + '  (the name is enough)';
      fromBox.title = where === 'command'
        ? 'Which part of the message it takes. Left empty it takes the next word, in the order these '
          + 'names are written. "all" takes everything after the phrase, spaces and all - for a note '
          + 'or a sentence. A number takes that word: 2 is the second word after the phrase. Writing '
          + '{' + (v.name || 'name') + '} into the phrase itself does the same as leaving this empty.'
        : 'The header the press carries it in. Left empty it is X-Zigmon-Arg-' + (v.name || 'name')
          + ', which is all most links need; fill it in only to read the value out of a header called '
          + 'something else.';
      fromBox.oninput = function () { v.from = fromBox.value.slice(0, 60); };
      line.appendChild(fromBox);
      var drop = iconButton('trash', 'Take this name away');
      drop.onclick = function () { row.vars.splice(i, 1); after(); draw(); };
      line.appendChild(drop);
      list.appendChild(line);
    });
    if (!(row.vars || []).length) {
      list.appendChild(el('p', 'btnhelp', 'No names yet. One stands for something the '
        + (where === 'command' ? 'message' : 'press') + ' carries, and can be used in what this '
        + where + ' does and in what it answers.'));
    }
    host.appendChild(list);
    var bar = el('div', 'btnrow');
    var add = cmdButton('Add a name', 'add', 'small primary');
    add.classList.remove('needs-unlock');
    add.onclick = function () {
      row.vars = (row.vars || []).concat([{name: '', from: '', note: ''}]);
      after(); draw();
    };
    bar.appendChild(add);
    var done = cmdButton('Done', 'check', 'small');
    done.classList.remove('needs-unlock');
    done.onclick = function () { after(); $('attnback').hidden = true; };
    bar.appendChild(done);
    host.appendChild(bar);
    host.appendChild(el('p', 'note', 'Wherever this ' + where + ' writes text, these are offered by '
      + 'Ctrl+Space and at the top of the { } Facts picker, and they take the same turns of phrase '
      + 'everything else does \u2014 {' + ((row.vars || [])[0] || {}).name + '.upper}, {…count}, {…nl}. '
      + (where === 'link'
         ? 'A name is the header name: one called room arrives in X-Zigmon-Arg-room, and the box beside '
           + 'it is only for reading it out of a header called something else.'
         : 'The box beside a name says which part of the message it takes \u2014 empty for the next '
           + 'word in order, all for everything after the phrase, or a number for that word.')
      + ' They belong to this ' + where + ' alone: two rules may each have a name called ip and '
      + 'neither means the other\u2019s.'));
  };
  draw();
}
// "unban {ip}" makes a name called ip, which stands for whatever the message
// carried in its place. These are the names a phrase has made up, and a short
// list of the ones worth making up, offered where one is being written.
function phraseNames(phrase) {
  var out = [];
  String(phrase || '').replace(/\{([a-zA-Z][a-zA-Z0-9_]{0,23})\}/g, function (_, name) {
    out.push({name: name, why: 'what this phrase catches'});
    return '';
  });
  out.push({name: 'args', why: 'everything the message carried'});
  return out;
}
function nameSuggestions(phrase) {
  var have = {};
  phraseNames(phrase).forEach(function (x) { have[x.name] = true; });
  return ['ip', 'room', 'name', 'value', 'number', 'text', 'who', 'temp']
    .filter(function (n) { return !have[n]; })
    .map(function (n) { return {name: n, why: 'a name for what the message carries here'}; });
}
// A press may carry named values with it - a header called X-Zigmon-Arg-Room
// arrives as {room} - and nothing has to be set up for it, so the names worth
// carrying are offered rather than configured.
var CARRIED_KNOWN = {};
function knownFactNames() {
  // worked out once, from the same catalogue the picker shows
  if (Object.keys(CARRIED_KNOWN).length) return CARRIED_KNOWN;
  try {
    factCatalogue().forEach(function (g) {
      (g[1] || []).forEach(function (f) { CARRIED_KNOWN[f[0]] = true; });
    });
  } catch (e) { /* before the first report there is nothing to ask */ }
  return CARRIED_KNOWN;
}
function carriedNames(text) {
  var out = [], have = {};
  knownFactNames();
  String(text || '').replace(/\{([a-zA-Z][a-zA-Z0-9_]{0,23})\}/g, function (_, name) {
    // Asked cheaply and never allowed to throw: this runs on every keystroke
    // in the writing desk, and a list of facts built afresh each time was
    // enough to stop the preview underneath from being drawn at all.
    if (!have[name] && !CARRIED_KNOWN[name]) {
      have[name] = true;
      out.push({name: name, why: 'carried in X-Zigmon-Arg-' + name});
    }
    return '';
  });
  ['ip', 'room', 'who', 'value', 'name'].forEach(function (n) {
    if (!have[n]) out.push({name: n, why: 'send it in X-Zigmon-Arg-' + n});
  });
  return out;
}
function completerItems(token) {
  var items = [];
  var want = String(token || '').toLowerCase();
  // asked for defensively: this function is lifted out and run on its own by
  // test/completer.js, where nothing else of the page exists
  // One name once, whoever mentioned it: a name written into the phrase is
  // also kept on the row, so both said it and the list showed it twice. And
  // the label is the bare name, as every other item's is - the braces are
  // drawn by the list, so writing them here made {{myip}}.
  var already = {};
  ((typeof COMPLETE_LOCAL !== 'undefined' && COMPLETE_LOCAL) || []).forEach(function (one) {
    var name = String(one.name || '');
    if (!name || already[name.toLowerCase()]) return;
    if (name.toLowerCase().indexOf(want.split('.')[0]) !== 0) return;
    already[name.toLowerCase()] = true;
    items.push({text: name + '}', label: name, desc: one.why || 'a name this rule made up',
                close: true, at: 0, group: 'This rule\u2019s own names'});
  });
  var dot = token.indexOf('.');
  if (dot >= 0) {
    // A dot asks for one of two things, and which one depends on what stands
    // before it: after a device name, its own readings; after anything that
    // is already whole - a fact, or a device's reading - a turn of phrase.
    // {PIR-Chodba.model.nl} is both at once, and offering only the readings
    // there left the list empty at the very place the turn belongs.
    var lastDot = token.lastIndexOf('.');
    var want = token.slice(lastDot + 1).toLowerCase();
    var dev = deviceForFacts(token.slice(0, dot));
    if (!dev) return turnItems(want, lastDot + 1);
    var keyPart = token.slice(dot + 1, lastDot);       // empty right after the name
    if (!keyPart) {
      // the device's own keys, with what each of them reads right now
      DEVICE_FACT_KEYS.forEach(function (k) {
        var ex = k[2];
        if (k[0] === 'battery' && dev.battery !== null && dev.battery !== undefined) ex = dev.battery;
        if (k[0] === 'signal' && dev.linkquality) ex = dev.linkquality;
        if (k[0] === 'model' && dev.model) ex = dev.model;
        if (k[0] === 'name') ex = dev.name;
        if (k[0] === 'age' && dev.age_s !== null && dev.age_s !== undefined) ex = ago(Date.now() / 1000 - dev.age_s).replace(' ago', '');
        if (k[0] === 'state' && dev.source === 'plug') { var p = (STATE.status.plugs || []).filter(function (x) { return x.name === dev.name; })[0]; if (p) ex = p.unplugged ? 'unplugged' : (p.output === 1 ? 'on' : 'off'); }
        if (k[0].indexOf(want) === 0) items.push({text: k[0] + '}', label: k[0], desc: k[1], ex: ex, close: true, at: dot + 1});
      });
      var special = DEVICE_FACT_KEYS.map(function (k) { return k[0]; });
      Object.keys(dev.values || {}).sort().forEach(function (key) {
        if (key.toLowerCase().indexOf(want) < 0 || special.indexOf(key) >= 0) return;
        var v = dev.values[key] || {};
        var ex = v.value === null || v.value === undefined ? '' : String(v.value) + (v.unit ? ' ' + v.unit : '');
        items.push({text: key + '}', label: key, desc: (v.label || key) + (v.description ? ' \u2014 ' + v.description : ''), ex: ex, close: true, at: dot + 1});
      });
      return items;
    }
    // something already stands after the name. A key may hold a dot of its
    // own (switch.apower), so those are still offered; and if what stands
    // there is a whole key, a turn of phrase may follow it.
    var prefix = (keyPart + '.' + want).toLowerCase();
    Object.keys(dev.values || {}).sort().forEach(function (key) {
      if (key.toLowerCase().indexOf(prefix) !== 0) return;
      var v = dev.values[key] || {};
      var ex = v.value === null || v.value === undefined ? '' : String(v.value) + (v.unit ? ' ' + v.unit : '');
      items.push({text: key + '}', label: key, desc: (v.label || key) + (v.description ? ' \u2014 ' + v.description : ''), ex: ex, close: true, at: dot + 1});
    });
    if (deviceKeyNames(dev).indexOf(factWithoutTurns(keyPart)) >= 0) {
      items = items.concat(turnItems(want, lastDot + 1));
    }
    return items;
  }
  var low = token.toLowerCase();
  factCatalogue().forEach(function (g) {
    g[1].forEach(function (f) {
      if (f[0].indexOf(low) === 0 || (low && f[1].toLowerCase().indexOf(low) >= 0)) items.push({text: f[0] + '}', label: f[0], desc: f[1], ex: f[2], close: true, at: 0, group: g[0]});
    });
  });
  (STATE.status && STATE.status.devices || []).forEach(function (d) {
    if (d.name.toLowerCase().indexOf(low) < 0 && !(d.alias && d.alias.toLowerCase().indexOf(low) >= 0)) return;
    var head = (d.headline || [])[0];
    var ex = head ? (head.label || head.key) + ' ' + (head.value === null || head.value === undefined ? '' : head.value) + (head.unit ? ' ' + head.unit : '') : '';
    items.push({text: d.name + '.', label: d.name + '.', desc: (deviceIcon(d) ? deviceIcon(d) + ' ' : '') + [d.vendor, d.model].filter(Boolean).join(' ') + ' \u2014 then a key: ' + (ex ? ex.split(' ')[0].toLowerCase() : 'state, age \u2026'), ex: ex, close: false, at: 0, group: 'Devices'});
  });
  return items.slice(0, 40);
}
function paintCompleter() {
  var pop = COMPLETE.pop; pop.innerHTML = '';
  if (!COMPLETE.items.length) { pop.appendChild(el('div', 'ac-empty', 'no match \u2014 keep typing, or Esc')); return; }
  var lastGroup = null;
  COMPLETE.items.forEach(function (it, i) {
    if (it.group && it.group !== lastGroup) { pop.appendChild(el('div', 'ac-group', it.group)); lastGroup = it.group; }
    var row = el('div', 'ac-row' + (i === COMPLETE.sel ? ' sel' : ''));
    // braces around a fact, none around a word that stands on its own line -
    // a script's verb is not written {like this} and must not be offered as
    // though it were
    row.appendChild(el('span', 'ac-name', COMPLETE.bare
      ? it.label : '{' + it.label + (it.close ? '}' : '')));
    row.appendChild(el('span', 'ac-desc', it.desc));
    if (it.ex !== '' && it.ex !== undefined && it.ex !== null) row.appendChild(el('span', 'ac-ex', '\u2192 ' + it.ex));
    row.onmousedown = function (e) { e.preventDefault(); COMPLETE.sel = i; acceptCompletion(); };
    row.onmousemove = function () { if (COMPLETE.sel !== i) { COMPLETE.sel = i; paintCompleter(); } };
    pop.appendChild(row);
  });
  // keep the chosen row in view by scrolling the LIST only; scrollIntoView
  // also scrolled the page whenever the list reached below the window edge
  var selRow = pop.querySelector('.ac-row.sel');
  if (selRow) {
    if (selRow.offsetTop < pop.scrollTop) pop.scrollTop = selRow.offsetTop;
    else if (selRow.offsetTop + selRow.offsetHeight > pop.scrollTop + pop.clientHeight) pop.scrollTop = selRow.offsetTop + selRow.offsetHeight - pop.clientHeight;
  }
}
// Where the caret is, in page coordinates: a hidden twin of the textarea is
// filled up to the caret and measured - the usual trick, nothing exotic.
function caretPosition(box) {
  var mirror = el('div'); var cs = window.getComputedStyle(box);
  ['fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'letterSpacing', 'padding', 'border', 'boxSizing', 'whiteSpace', 'wordWrap'].forEach(function (k) { mirror.style[k] = cs[k]; });
  mirror.style.position = 'absolute'; mirror.style.visibility = 'hidden'; mirror.style.whiteSpace = 'pre-wrap'; mirror.style.wordWrap = 'break-word';
  mirror.style.width = box.clientWidth + 'px'; mirror.style.top = '0'; mirror.style.left = '-9999px';
  mirror.textContent = box.value.slice(0, box.selectionStart);
  var marker = el('span', '', '\u200b'); mirror.appendChild(marker);
  document.body.appendChild(mirror);
  var r = box.getBoundingClientRect();
  var top = r.top + window.scrollY + marker.offsetTop - box.scrollTop + marker.offsetHeight + 4;
  var left = r.left + window.scrollX + marker.offsetLeft;
  mirror.remove();
  return {top: top, left: left};
}
function openCompleter(box, after, ctx) {
  if (!COMPLETE.pop) { COMPLETE.pop = el('div', 'acbox'); COMPLETE.pop.onmousedown = function (e) { e.preventDefault(); }; document.body.appendChild(COMPLETE.pop); }
  COMPLETE.box = box; COMPLETE.after = after;
  // The whole token is the ground; each item says how far into it its own
  // text starts - a reading replaces everything after the device's name, a
  // turn of phrase only what follows the last dot. Deciding that once, at the
  // moment the list opened, put {Name.model.nl} back as {Name.nl}.
  COMPLETE.start = ctx.start;
  COMPLETE.bare = !!ctx.bare;        // a word at the start of a line, not a fact in braces
  COMPLETE.items = completerItems(ctx.token); COMPLETE.sel = 0;
  paintCompleter();
  var at = caretPosition(box), pop = COMPLETE.pop;
  pop.style.left = Math.max(8, Math.min(at.left, window.innerWidth - pop.offsetWidth - 12)) + 'px';
  var below = window.innerHeight - (at.top - window.scrollY);
  if (below < pop.offsetHeight + 8 && at.top - window.scrollY > pop.offsetHeight + 30)
    pop.style.top = (at.top - pop.offsetHeight - 26) + 'px';     // no room under the caret: open above it
  else pop.style.top = at.top + 'px';
}
function acceptCompletion() {
  var it = COMPLETE.items[COMPLETE.sel], box = COMPLETE.box; if (!it || !box) return;
  var end = box.selectionStart;
  var at = COMPLETE.start + (it.at || 0);
  var text = (COMPLETE.bare && /\}$/.test(it.text)) ? it.text.slice(0, -1) + ' ' : it.text;
  box.value = box.value.slice(0, at) + text + box.value.slice(end);
  box.selectionStart = box.selectionEnd = at + it.text.length;
  if (COMPLETE.after) COMPLETE.after(box.value);
  if (it.close) closeCompleter();
  else { var ctx = completerContext(box); if (ctx) openCompleter(box, COMPLETE.after, ctx); }
  box.focus({preventScroll: true});
}
function attachFactCompleter(box, after, locals) {
  // whatever names this line has made up, worked out afresh each time the
  // list is opened, since the line is being written as we go
  box.addEventListener('focus', function () { COMPLETE_LOCAL = locals ? locals() : []; });
  box.addEventListener('keydown', function () { COMPLETE_LOCAL = locals ? locals() : []; }, true);
  box.addEventListener('keyup', function (e) { if (e.key === ' ' && e.ctrlKey) e.preventDefault(); });
  box.addEventListener('keypress', function (e) { if (e.key === ' ' && e.ctrlKey) e.preventDefault(); });
  box.addEventListener('keydown', function (e) {
    if (e.key === ' ' && e.ctrlKey) {
      e.preventDefault(); e.stopPropagation();
      var ctx = completerContext(box);
      if (!ctx) { insertAtCursor(box, '{', after); ctx = completerContext(box); }
      if (ctx) openCompleter(box, after, ctx);
      return;
    }
    if (!COMPLETE.pop || COMPLETE.box !== box) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); COMPLETE.sel = Math.min(COMPLETE.items.length - 1, COMPLETE.sel + 1); paintCompleter(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); COMPLETE.sel = Math.max(0, COMPLETE.sel - 1); paintCompleter(); }
    else if ((e.key === 'Enter' || e.key === 'Tab') && COMPLETE.items.length) { e.preventDefault(); acceptCompletion(); }
    else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeCompleter(); }
  });
  box.addEventListener('input', function () {
    var ctx = completerContext(box);
    if (!ctx) { if (COMPLETE.box === box) closeCompleter(); return; }
    openCompleter(box, after, ctx);
  });
  box.addEventListener('blur', function () { setTimeout(function () { if (COMPLETE.box === box) closeCompleter(); }, 150); });
  box.addEventListener('click', function () { var ctx = completerContext(box); if (ctx) openCompleter(box, after, ctx); else closeCompleter(); });
  // keep whatever the editor explained about this box, and add the hint
  var hint = 'Type { or press Ctrl+Space for the list of facts; a device name and . for its readings';
  box.title = box.title ? box.title + '\n' + hint : hint;
}

// what it will read like, with stand-in facts, asked of the daemon so the
// filling in is the same code that will do it for real
var PREVIEW_TIMER = null;
// Under every message: the notification as the phone will show it, filled
// with the facts of this moment, redrawn a beat after each keystroke. It
// asks nothing privileged, so it works locked or unlocked.
// What the answer would actually say, filled in with this moment's facts -
// the same service the alert preview uses.
var SMS_PREVIEW_TIMER = null;
function scheduleSmsPreview() {
  clearTimeout(SMS_PREVIEW_TIMER);
  SMS_PREVIEW_TIMER = setTimeout(function () {
    (SMSCMD.rows || []).forEach(function (c, i) {
      var box = document.querySelector('#smscmd-list .msg-preview[data-smsfor="' + i + '"]');
      if (!box) return;
      if (!c.reply) { box.innerHTML = ''; delete box.dataset.shown; return; }
      if (box.dataset.shown === c.reply) return;
      api('message-preview&title=&text=' + encodeURIComponent(c.reply)).then(function (r) {
        box.dataset.shown = c.reply;
        box.innerHTML = '';
        box.appendChild(el('span', 'lbl', 'the phone would read'));
        box.appendChild(el('div', 'sms-bubble', r.text || ''));
      }, function () { box.innerHTML = ''; });
    });
  }, 250);
}
function schedulePreview() {
  clearTimeout(PREVIEW_TIMER);
  PREVIEW_TIMER = setTimeout(function () {
    (MESSAGES.rows || []).forEach(function (m, i) {
      var box = document.querySelector('#messages-list .msg-preview[data-for="' + i + '"]');
      if (!box) return;
      if (!m.text && !m.title) { box.innerHTML = ''; delete box.dataset.shown; return; }
      var want = (m.title || '') + '\u0000' + (m.text || '') + '\u0000' + (m.level || '') + (m.image ? '\u0000img' : '');
      if (box.dataset.shown === want) return;          // nothing new to ask about
      api('message-preview&title=' + encodeURIComponent(m.title || '') + '&text=' + encodeURIComponent(m.text || '')).then(function (r) {
        box.dataset.shown = want;
        paintPreview(box, m, r);
      }, function (e) {
        box.innerHTML = '';
        box.appendChild(el('span', 'lbl', 'preview unavailable \u2014 ' + (e.message || 'the daemon did not answer')));
      });
    });
  }, 250);
}
function paintPreview(box, m, r) {
  box.innerHTML = '';
  box.appendChild(el('span', 'lbl', 'on the phone it will read'));
  var card = el('div', 'ntfy ' + (m.level || 'warn'));
  var head = el('div', 'ntfy-head');
  head.appendChild(el('span', 'ntfy-app', 'zigmon'));
  head.appendChild(el('span', 'ntfy-when', 'now'));
  card.appendChild(head);
  var title = r.title || levelWord(m.level || 'warn');
  card.appendChild(el('div', 'ntfy-title', (m.level === 'crit' ? '\ud83d\udea8 ' : '') + title));
  card.appendChild(el('div', 'ntfy-text', r.text || (m.name || '')));
  if (m.image) card.appendChild(el('div', 'ntfy-img', '\ud83d\uddbc\ufe0f picture: ' + m.image));
  box.appendChild(card);
}
$('message-add').onclick = function () {
  MESSAGES.rows = MESSAGES.rows || [];
  MESSAGES.rows.push({id: 'm' + Math.random().toString(16).slice(2, 10), name: '', text: '', level: 'warn', quiet_s: 900});
  markMessages(); renderMessages();
};
$('messages-save').onclick = function () {
  withPin('Save messages', 'They can then be picked as a target anywhere something is switched.', function (pin) {
    return post('messages', {messages: rowsToSave(MESSAGES, 'messages'), pin: pin}).then(function (r) {
      saveGroups('messages', MESSAGES);
      MESSAGES.rows = r.messages; MESSAGES.dirty = false; $('messages-dirty').textContent = '';
      renderMessages(); tick(true);
      return r.messages.length + ' message(s) saved';
    });
  });
};

// ---- Wi-Fi presence ----------------------------------------------------------------
var PEOPLE = {rows: null, dirty: false};
var PTRIG = {rows: null, dirty: false};
var WIFI_CLIENTS = [];

function markPeople() { PEOPLE.dirty = true; $('people-dirty').textContent = 'Unsaved changes'; }
function markPtrig() { PTRIG.dirty = true; $('ptrig-dirty').textContent = 'Unsaved changes'; }

var WIFI_SW = null;
function wifiSwitches() {
  if (WIFI_SW) return WIFI_SW;
  var mk = function (host, id) {
    var sw = makeSwitch(false, null);
    sw.input.id = id;
    $(host).appendChild(sw);
    return sw.input;
  };
  WIFI_SW = {enabled: mk('wifi-enabled-sw', 'wifi-enabled'), verify: mk('wifi-verify-sw', 'wifi-verify'),
             ssh: mk('ssh-enabled-sw', 'ssh-enabled')};
  return WIFI_SW;
}
function sshAuthChanged() {
  $('ssh-pass-wrap').hidden = $('ssh-auth').value !== 'password';
  $('ssh-key-box').hidden = $('ssh-auth').value !== 'key';
}
function renderWifiConfig(st) {
  var w = st.wifi_config || {};
  wifiSwitches();
  if (document.activeElement && document.activeElement.closest && document.activeElement.closest('#wifi-card')) return;
  $('wifi-host').value = w.host || '';
  $('wifi-port').value = w.port || 443;
  $('wifi-method').value = w.method || 'official';
  $('wifi-site').value = w.site || 'default';
  $('wifi-poll').value = w.poll_s || 30;
  $('wifi-ntfy').value = w.presence_ntfy || '';
  $('wifi-grace').value = (w.grace_s === undefined || w.grace_s === null) ? 600 : w.grace_s;
  $('wifi-user').value = w.username || '';
  wifiSwitches().enabled.checked = !!w.enabled;
  wifiSwitches().verify.checked = !!w.verify_ssl;
  wifiSwitches().ssh.checked = !!w.ssh_enabled;
  $('ssh-user').value = w.ssh_user || '';
  $('ssh-port').value = w.ssh_port || 22;
  $('ssh-auth').value = w.ssh_auth || 'key';
  $('ssh-pass').placeholder = w.has_ssh_password ? '(kept)' : '';
  sshAuthChanged();
  var pub = $('ssh-public');
  pub.hidden = !w.ssh_public;
  if (w.ssh_public) pub.textContent = w.ssh_public;
  $('ssh-download').disabled = !w.has_ssh_key;
  $('ssh-forget').disabled = !w.has_ssh_key;
  if (!w.ssh_ready) {
    $('ssh-generate').disabled = $('ssh-test').disabled = true;
    $('ssh-generate').title = $('ssh-test').title = 'the ssh client is not installed on this machine (dnf install openssh-clients)';
  }
  $('wifi-key').placeholder = w.has_api_key ? '(kept)' : '';
  $('wifi-pass').placeholder = w.has_password ? '(kept)' : '';
  wifiMethodChanged();
  var p = (st.presence || {}).wifi || {};
  if (Date.now() - (wifiSay.at || 0) < 6000) return;   // leave the button's own answer up
  var text = !w.enabled ? 'not asking' : (p.ok === true
    ? p.wifi_clients + ' on Wi-Fi, ' + p.clients + ' in all \u00b7 ' + (p.checked ? ago(p.checked) : '')
    : (p.ok === false ? 'last try failed: ' + (p.error || '') : 'waiting for the first answer'));
  $('wifi-state').textContent = text;
  $('wifi-state').className = 'muted small' + (p.ok === false && w.enabled ? ' reason' : '');
}
function wifiMethodChanged() {
  var how = $('wifi-method').value;
  $('wifi-key-wrap').hidden = how === 'legacy';
  $('wifi-user-wrap').hidden = how === 'official';
  $('wifi-pass-wrap').hidden = how === 'official';
}
$('wifi-method').onchange = wifiMethodChanged;
$('ssh-auth').onchange = sshAuthChanged;

function sshKeyAction(what, extra, note) {
  withPin(note, 'The access points are only ever read from \u2014 the commands are a fixed list.', function (pin) {
    return post('wifi-sshkey', Object.assign({do: what, pin: pin}, extra || {})).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'failed');
      if (r.public !== undefined) {
        $('ssh-public').hidden = !r.public;
        $('ssh-public').textContent = r.public;
      }
      if (r.points) {
        var lines = Object.keys(r.points).map(function (name) {
          var p = r.points[name];
          return name + ': ' + (p.ok ? (p.model || 'answered') + ' ' + (p.version || '') : p.error);
        });
        $('ssh-public').hidden = false;
        $('ssh-public').textContent = lines.join('\n');
        return lines.length + ' access point(s) asked';
      }
      tick(true);
      return 'Done';
    });
  });
}
$('ssh-generate').onclick = function () {
  sshKeyAction('generate', null, 'Make a key for the access points');
};
$('ssh-upload').onclick = function () {
  var box = document.createElement('input');
  box.type = 'file';
  box.onchange = function () {
    var f = box.files && box.files[0];
    if (!f) return;
    var reader = new FileReader();
    reader.onload = function () { sshKeyAction('upload', {key: String(reader.result)}, 'Use this key'); };
    reader.readAsText(f);
  };
  box.click();
};
$('ssh-forget').onclick = function () {
  sshKeyAction('forget', null, 'Forget the key');
};
$('ssh-test').onclick = function () {
  sshKeyAction('test', null, 'Try the access points');
};
$('ssh-download').onclick = function () {
  if (!isUnlocked() || !LOCK.token) { unlockFlow(function () { $('ssh-download').onclick(); }); return; }
  var a = document.createElement('a');
  a.href = 'index.php?api=wifi-sshkey-download&session=' + encodeURIComponent(LOCK.token);
  a.download = 'zigmon-ap-key';
  document.body.appendChild(a); a.click(); a.remove();
};

function wifiPayload() {
  var body = {host: $('wifi-host').value.trim(), port: parseInt($('wifi-port').value, 10) || 443,
              method: $('wifi-method').value, site: $('wifi-site').value.trim() || 'default',
              username: $('wifi-user').value.trim(), enabled: wifiSwitches().enabled.checked,
              verify_ssl: wifiSwitches().verify.checked,
              ssh_enabled: wifiSwitches().ssh.checked,
              ssh_user: $('ssh-user').value.trim(), ssh_auth: $('ssh-auth').value,
              ssh_port: parseInt($('ssh-port').value, 10) || 22,
              poll_s: parseInt($('wifi-poll').value, 10) || 30,
              presence_ntfy: $('wifi-ntfy').value.trim(),
              grace_s: parseInt($('wifi-grace').value, 10)};
  if (isNaN(body.grace_s)) body.grace_s = 600;
  if ($('wifi-key').value) body.api_key = $('wifi-key').value;
  if ($('wifi-pass').value) body.password = $('wifi-pass').value;
  if ($('ssh-pass').value) body.ssh_password = $('ssh-pass').value;
  return body;
}
function wifiSay(text, bad) {
  var line = $('wifi-state');
  line.textContent = text;
  line.className = 'muted small' + (bad ? ' reason' : '');
  wifiSay.at = Date.now();          // hold it briefly against the next repaint
}
$('wifi-test').onclick = function () {
  withPin('Test the connection', 'Asks the controller for its clients and counts them. Saves nothing.', function (pin) {
    wifiSay('asking the controller\u2026');
    return post('wifi-test', {wifi: wifiPayload(), pin: pin}).then(function (r) {
      if (!r.ok) { wifiSay(r.error || 'failed', true); throw new Error(r.error || 'failed'); }
      var text = r.wifi_clients + ' on Wi-Fi, ' + r.clients + ' in all \u2014 the controller answered';
      wifiSay(text); return text;
    }, function (e) { wifiSay((e && e.message) || 'failed', true); throw e; });
  });
};
$('wifi-save').onclick = function () {
  withPin('Save the connection', 'The key or password is stored in the daemon\'s database, readable only by it.', function (pin) {
    return post('wifi-config', {wifi: wifiPayload(), pin: pin}).then(function () {
      $('wifi-key').value = ''; $('wifi-pass').value = '';
      tick(true); return 'Saved';
    });
  });
};
$('wifi-load').onclick = function () {
  withPin('Load the clients', 'Asks the controller who is on the network right now.', function (pin) {
    $('wifi-clients-note').textContent = 'asking the controller\u2026';
    return post('wifi-clients', {refresh: true, pin: pin}).then(function (r) {
      WIFI_CLIENTS = r.clients || [];
      renderWifiClients();
      if (!r.ok) {
        $('wifi-clients-note').textContent = r.error || 'failed';
        $('wifi-clients-note').className = 'reason small';
        throw new Error(r.error || 'failed');
      }
      $('wifi-clients-note').className = 'muted small';
      return WIFI_CLIENTS.length + ' client(s) listed';
    }, function (e) {
      $('wifi-clients-note').textContent = (e && e.message) || 'failed';
      $('wifi-clients-note').className = 'reason small';
      throw e;
    });
  });
};

function macOwner(mac) {
  var rows = PEOPLE.rows || [];
  for (var i = 0; i < rows.length; i++) if ((rows[i].macs || []).indexOf(mac) >= 0) return rows[i];
  return null;
}
function renderWifiClients() {
  var host = $('wifi-clients'); host.innerHTML = '';
  if (!WIFI_CLIENTS.length) {
    $('wifi-clients-note').textContent = 'Nothing loaded yet.';
    return;
  }
  $('wifi-clients-note').textContent = WIFI_CLIENTS.length + ' client(s) on the controller';
  var head = el('div', 'wc-row head');
  ['Device', 'MAC', 'Address', 'Where', 'Belongs to'].forEach(function (t) { head.appendChild(el('div', '', t)); });
  host.appendChild(head);
  WIFI_CLIENTS.forEach(function (c) {
    var owner = macOwner(c.mac);
    var row = el('div', 'wc-row' + (owner ? ' taken' : ''));
    row.appendChild(el('div', '', c.name || '(no name)'));
    row.appendChild(el('div', 'mac', c.mac));
    row.appendChild(el('div', 'muted small', c.ip || ''));
    row.appendChild(el('div', 'muted small', c.wired ? 'wired' : (c.ssid || 'Wi-Fi')));
    var pick = el('select');
    pick.appendChild(el('option', '', owner ? '\u2014 remove \u2014' : '\u2014 nobody \u2014'));
    (PEOPLE.rows || []).forEach(function (p) {
      var o = el('option', '', p.name || '(unnamed)'); o.value = p.id; pick.appendChild(o);
    });
    pick.value = owner ? owner.id : '';
    pick.onchange = function () {
      (PEOPLE.rows || []).forEach(function (p) {
        p.macs = (p.macs || []).filter(function (m) { return m !== c.mac; });
      });
      if (pick.value) {
        var target = (PEOPLE.rows || []).filter(function (p) { return p.id === pick.value; })[0];
        if (target) target.macs = (target.macs || []).concat([c.mac]);
      }
      markPeople(); renderPeople(); renderWifiClients();
    };
    row.appendChild(pick);
    host.appendChild(row);
  });
}

function renderPeople(st) {
  if (PEOPLE.rows === null && st) PEOPLE.rows = JSON.parse(JSON.stringify(st.people || []));
  var rows = PEOPLE.rows || [];
  var live = {};
  ((STATE.status && STATE.status.presence && STATE.status.presence.people) || []).forEach(function (p) { live[p.id] = p; });
  var host = $('people-list'); host.innerHTML = '';
  if (!rows.length) {
    host.appendChild(el('div', 'muted small', 'Nobody yet. Add a person, then pick their phone from the list above.'));
  } else {
    var head = el('div', 'person-row person-head');
    [['', ''], ['Who', ''], ['Their number', ''], ['Their devices', ''], ['Gone after', ''], ['Notify me', ''], ['From their phone', ''], ['', 'r']]
      .forEach(function (pair) { head.appendChild(el('div', pair[1], pair[0])); });
    host.appendChild(head);
  }
  rows.forEach(function (person, i) {
    var row = el('div', 'person-row');
    var here = live[person.id];
    var state = el('div');
    if (here) {
      var tag = el('span', 'tag' + (here.home ? ' ok' : ''), here.home ? 'in' : 'out');
      tag.title = here.reason || ((here.device ? 'seen as ' + here.device : 'no device of theirs on the network')
        + (here.last_seen ? ', last seen ' + ago(here.last_seen) : '')
        + (here.leaving_in ? ' \u2014 counts as out in ' + runtimeText(here.leaving_in) : ''));
      tag.style.cursor = 'help';
      state.appendChild(tag);
    } else {
      state.appendChild(el('span', 'muted small', '\u2013'));
    }
    row.appendChild(state);
    var name = el('input'); name.value = person.name || ''; name.placeholder = 'Name';
    name.oninput = function () { person.name = name.value; markPeople(); };
    var phone = el('input'); phone.type = 'tel'; phone.value = person.phone || '';
    phone.placeholder = '+420 777 123 456';
    phone.className = 'person-phone'; phone.autocomplete = 'off';
    phone.title = 'Their phone number. A text from it is recognised as theirs, so \u201caway\u201d and \u201chome\u201d work '
      + 'without naming anybody; an alert can be addressed to the person rather than to a number; and a message from a number '
      + 'nobody owns is reported and does nothing.';
    phone.oninput = function () { person.phone = phone.value; markPeople(); };
    row.appendChild(name);
    row.appendChild(phone);
    var macs = el('div', 'person-macs');
    var known = (STATE.status && STATE.status.presence && STATE.status.presence.names) || {};
    (person.macs || []).forEach(function (m) {
      var chip = el('span', 'macchip');
      if (m.indexOf('name:') === 0) {
        chip.appendChild(el('span', 'macname', m.slice(5)));
        chip.appendChild(el('span', 'macaddr', 'by name'));
        chip.title = 'Matched by the name the controller shows, whatever its Wi-Fi address is today';
      } else {
      var seen = known[m] || (WIFI_CLIENTS.filter(function (c) { return c.mac === m; })[0] || {}).name;
      chip.appendChild(el('span', 'macname', seen || 'unknown device'));
      chip.appendChild(el('span', 'macaddr', m));
      // what the controller says about it right now, not only its address
      var live = WIFI_CLIENTS.filter(function (c) { return c.mac === m; })[0];
      chip.title = (seen ? seen + ' \u2014 ' : '') + m
        + (live ? '\n' + (live.online ? 'on the network now' : 'not seen now')
                  + (live.ap ? ' \u00b7 ' + live.ap : '') + (live.ssid ? ' \u00b7 ' + live.ssid : '')
                  + (isNum(live.rssi) ? ' \u00b7 ' + live.rssi + ' dBm' : '')
                  + (live.last_seen ? '\nlast seen ' + ago(live.last_seen) : '')
                : '\nthe controller has not mentioned it');
      }
      var x = el('button', '', '\u00d7'); x.type = 'button'; x.title = 'Take this device off ' + (person.name || 'them');
      x.onclick = function () {
        person.macs = person.macs.filter(function (v) { return v !== m; });
        markPeople(); renderPeople(); renderWifiClients();
      };
      chip.appendChild(x); macs.appendChild(chip);
    });
    if (!(person.macs || []).length) macs.appendChild(el('span', 'muted small', 'no device yet'));
    var byName = el('button', 'btn cmd small', '+ by name'); byName.type = 'button';
    byName.title = 'Match a device by the name the controller shows (iPhone16, Pixel-8 \u2026) instead of its address. A phone with a rotating private Wi-Fi address keeps its name.';
    byName.onclick = function () {
      askText('Device by name', 'The name as the controller shows it \u2014 case does not matter. For a phone with a private, rotating Wi-Fi address.', '',
              function (x) { return x ? '' : 'Type the name'; }).then(function (v) {
        if (!v) return;
        person.macs = (person.macs || []).filter(function (x) { return x.toLowerCase() !== ('name:' + v).toLowerCase(); }).concat(['name:' + v]);
        markPeople(); renderPeople(); renderWifiClients();
      });
    };
    macs.appendChild(byName);
    row.appendChild(macs);
    var grace = el('input'); grace.type = 'number'; grace.min = 0; grace.max = 86400;
    var shared = ((STATE.status && STATE.status.wifi_config) || {}).grace_s;
    grace.placeholder = (shared === undefined || shared === null) ? '600' : String(shared);
    grace.title = 'Seconds off the network before this person counts as out. Left blank it follows "Gone after" on the card above, which is '
      + ((shared === undefined || shared === null) ? 600 : shared) + ' s.';
    grace.value = (person.grace_s === null || person.grace_s === undefined) ? '' : person.grace_s;
    grace.oninput = function () { person.grace_s = grace.value === '' ? null : parseInt(grace.value, 10); markPeople(); };
    row.appendChild(grace);
    var noteCell = el('div', 'sw-cell');
    var note = makeSwitch(person.notify !== false, function (on) { person.notify = on; markPeople(); },
                          {small: true, title: 'A notification when ' + (person.name || 'this person')
                           + ' arrives or leaves. Off, and it is still written to Events \u2014 you just are not told.'});
    noteCell.appendChild(note);
    noteCell.appendChild(el('span', 'sw-cap', 'when they come or go'));
    row.appendChild(noteCell);
    // The phone's own word: a geofence on the handset trips while its owner
    // is still down the street, a minute before the Wi-Fi could know.
    var phoneCell = el('div', 'sw-cell');
    var phoneSw = makeSwitch(!!person.phone_report, function (on) {
      person.phone_report = on;
      if (on && !person.has_token) person.token = 'new';        // the daemon makes one on save
      markPeople(); renderPeople();
    }, {small: true, title: 'Let ' + (person.name || 'this person') + '\u2019s phone say when it arrives and leaves, '
        + 'through a shortcut on the handset. Arriving is taken at once; leaving only when the controller cannot see them either.'});
    phoneCell.appendChild(phoneSw);
    if (person.phone_report && person.id) {
      var show = cmdButton('Setup\u2026', 'link', 'small'); show.classList.remove('needs-unlock');
      show.title = 'The link to put in the phone\u2019s shortcut';
      show.onclick = function () { showPhoneSetup(person); };
      phoneCell.appendChild(show);
    } else {
      phoneCell.appendChild(el('span', 'sw-cap', person.phone_report ? 'save first' : 'shortcut on the phone'));
    }
    row.appendChild(phoneCell);
    var drop = el('button', 'btn small iconbtn danger r'); drop.type = 'button';
    drop.innerHTML = iconMarkup('trash', 15); drop.title = 'Remove this person';
    drop.onclick = function () { PEOPLE.rows.splice(i, 1); markPeople(); renderPeople(); renderWifiClients(); };
    row.appendChild(drop);
    makeRowSortable(row, host, PEOPLE, markPeople, function () { renderPeople(STATE.status); }, person);
    host.appendChild(row);
    // why they count as out, on a line of its own under the row
    if (here && here.reason && !here.home) {
      var why = el('div', 'person-why');
      why.innerHTML = '<b>Why out:</b> ' + esc(here.reason);
      host.appendChild(why);
    }
  });
}
$('person-add').onclick = function () {
  PEOPLE.rows = PEOPLE.rows || [];
  PEOPLE.rows.push({id: 'p' + Math.random().toString(16).slice(2, 10), name: '', macs: [], grace_s: null, notify: true, enabled: true});
  markPeople(); renderPeople();
};
$('people-save').onclick = function () {
  withPin('Save people', 'Presence is worked out from these devices.', function (pin) {
    return post('people', {people: rowsToSave(PEOPLE, 'people'), pin: pin}).then(function (r) {
      PEOPLE.rows = r.people; PEOPLE.dirty = false; $('people-dirty').textContent = '';
      renderPeople(); renderWifiClients(); tick(true);
      return r.people.length + ' person(s) saved';
    });
  });
};

function renderPtrig(st) {
  if (PTRIG.rows === null && st) PTRIG.rows = JSON.parse(JSON.stringify(st.presence_triggers || []));
  var rows = PTRIG.rows || [];
  var people = (PEOPLE.rows || (st && st.people) || []);
  var host = $('ptrig-list'); host.innerHTML = '';
  if (!rows.length) {
    host.appendChild(el('div', 'muted small', 'Nothing yet. For example: the house is empty \u2192 every plug off.'));
  } else {
    var head = el('div', 'ptrig-row ptrig-head');
    ['', 'Who', 'When they', '', 'Switch', 'To', ''].forEach(function (t) { head.appendChild(el('div', '', t)); });
    host.appendChild(head);
  }
  var targets = targetOptions(STATE.status || {});
  rows.forEach(function (t, i) {
    var row = el('div', 'ptrig-row');
    row.appendChild(makeSwitch(t.enabled !== false, function (on) { t.enabled = on; markPtrig(); }, {small: true}));
    var who = el('select');
    [['anyone', 'anyone'], ['everyone', 'the house']].concat(people.map(function (p) { return [p.id, p.name || '(unnamed)']; }))
      .forEach(function (pair) { var o = el('option', '', pair[1]); o.value = pair[0]; who.appendChild(o); });
    who.value = t.who || 'anyone';
    who.onchange = function () { t.who = who.value; markPtrig(); syncEvents(); };
    var syncWhoTitle = function () {
      var st2 = STATE.status || {}, all = ((st2.presence || {}).people) || [];
      if (who.value === 'anyone') { who.title = 'Any one person. In now: ' + (all.filter(function (p) { return p.home; }).map(function (p) { return p.name; }).join(', ') || 'nobody'); return; }
      if (who.value === 'everyone') { who.title = 'The house as a whole \u2014 the first one in, or the last one out. ' + (all.filter(function (p) { return p.home; }).length) + ' of ' + all.length + ' in now.'; return; }
      var who_ = all.filter(function (p) { return p.id === who.value; })[0];
      who.title = who_ ? who_.name + ' is ' + (who_.home ? 'in' : 'out')
        + (who_.since ? ', since ' + stamp(who_.since) : '')
        + (who_.device ? ' \u00b7 seen by ' + who_.device : '')
        + (who_.enabled === false ? ' (this person is switched off)' : '') : 'This person is gone from the list';
    };
    who.addEventListener('mouseenter', syncWhoTitle); who.addEventListener('focus', syncWhoTitle); syncWhoTitle();
    row.appendChild(who);
    var ev = el('select');
    function syncEvents() {
      var house = who.value === 'everyone';
      var opts = house ? [['first_home', 'gets home first'], ['last_left', 'all gone']]
                       : [['arrive', 'arrives'], ['leave', 'leaves']];
      var want = t.event;
      ev.innerHTML = '';
      opts.forEach(function (pair) { var o = el('option', '', pair[1]); o.value = pair[0]; ev.appendChild(o); });
      ev.value = opts.map(function (x) { return x[0]; }).indexOf(want) >= 0 ? want : opts[0][0];
      t.event = ev.value;
    }
    syncEvents();
    ev.onchange = function () { t.event = ev.value; markPtrig(); };
    row.appendChild(ev);
    row.appendChild(el('div', 'muted', '\u2192'));
    var target = el('select');
    fillSelect(target, targets, t.plug || '');
    attachTargetReadings(target, function () { return t.plug; });
    target.onchange = function () {
      t.plug = target.value;
      if (settableTarget(STATE.status, t.plug) && String(t.do).indexOf('set:') !== 0) t.do = 'set:';
      if (!settableTarget(STATE.status, t.plug) && String(t.do).indexOf('set:') === 0) t.do = 'off';
      refillDoP(); markPtrig(); syncDo();
    };
    row.appendChild(target);
    var doCell = el('div');
    var doSel = el('select');
    var setBoxP = setValueBox(STATE.status, null, function (v) { t.do = v; markPtrig(); });
    function refillDoP() {
      var keep = t.do || 'off';
      fillSelect(doSel, doOptionsFor(STATE.status, t.plug, keep), String(keep).indexOf('set:') === 0 ? 'set:' : keep);
      runsItsOwnSteps(doSel, t.plug);
      attachTargetReadings(doSel, function () { return t.plug; });
      t.do = String(keep).indexOf('set:') === 0 ? keep : (doSel.value || 'off');
      setBoxP.refresh(t.plug, t.do);
    }
    refillDoP();
    doSel.onchange = function () { t.do = doSel.value; setBoxP.refresh(t.plug, t.do); markPtrig(); };
    var tellNote = el('span', 'muted small', 'sends the message');
    doCell.appendChild(doSel); doCell.appendChild(setBoxP); doCell.appendChild(tellNote);
    function syncDo() {
      var tells = isNotifyTarget(t.plug);
      doSel.hidden = tells; tellNote.hidden = !tells;
      if (tells) t.do = 'on';
    }
    syncDo();
    row.appendChild(doCell);
    var drop = el('button', 'btn small iconbtn danger r'); drop.type = 'button';
    drop.innerHTML = iconMarkup('trash', 15); drop.title = 'Remove this trigger';
    drop.onclick = function () { PTRIG.rows.splice(i, 1); markPtrig(); renderPtrig(); };
    row.appendChild(drop);
    makeRowSortable(row, host, PTRIG, markPtrig, function () { renderPtrig(STATE.status); }, t);
    host.appendChild(row);
  });
  sectionise(host, PTRIG, 'ptrig', markPtrig, function () { renderPtrig(STATE.status); });
}
$('ptrig-add').onclick = function () {
  PTRIG.rows = PTRIG.rows || [];
  PTRIG.rows.push({who: 'everyone', event: 'last_left', plug: '', do: 'off', enabled: true});
  markPtrig(); renderPtrig();
};
$('ptrig-save').onclick = function () {
  withPin('Save presence triggers', 'These fire the moment someone comes or goes.', function (pin) {
    return post('presence-triggers', {triggers: rowsToSave(PTRIG, 'presence triggers'), pin: pin}).then(function (r) {
      saveGroups('ptrig', PTRIG);
      PTRIG.rows = r.triggers; PTRIG.dirty = false; $('ptrig-dirty').textContent = '';
      renderPtrig(); tick(true);
      return r.triggers.length + ' trigger(s) saved';
    });
  });
};

// ---- events ----------------------------------------------------------------------
var EVENTS = { rows: [], filter: {kind: '', level: '', text: ''}, page: 1, perPage: 50 };
function loadEvents() {
  var f = EVENTS.filter || {};
  var query = 'events&limit=500'
    + (f.text ? '&q=' + encodeURIComponent(f.text) : '')
    + (f.kind ? '&kind=' + encodeURIComponent(f.kind) : '')
    + (f.level ? '&level=' + encodeURIComponent(f.level) : '');
  api(query).then(function (r) {
    EVENTS.rows = r.events || [];
    EVENTS.matched = r.matched;          // how many rows match in the whole table, not just here
    EVENTS.total = r.total;
    paintEvents();
  }).catch(function (e) { toast('Events: ' + e.message, false); });
}
function saveEventsAsText() {
  var rows = EVENTS.shown || [];
  if (!rows.length) { toast('Nothing to save', false); return; }
  var when = function (ts) {
    var d = new Date((ts || 0) * 1000);
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return p(d.getDate()) + '.' + p(d.getMonth() + 1) + '.' + d.getFullYear()
      + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  };
  var f = EVENTS.filter || {};
  var said = [];
  if (f.kind) said.push('kind ' + f.kind);
  if (f.level) said.push('level ' + f.level);
  if (f.text) said.push('containing \u201c' + f.text + '\u201d');
  var head = ['zigmon events', 'saved ' + when(Date.now() / 1000),
              said.length ? 'showing: ' + said.join(', ') : 'showing: everything',
              rows.length + ' event(s)', ''];
  var body = rows.map(function (e) {
    return [when(e.ts), (e.level || 'info'), (e.kind || ''), (e.device_name || e.device || ''),
            (e.detail || '')].join('\t');
  });
  var blob = new Blob([head.concat(body).join('\n') + '\n'], {type: 'text/plain;charset=utf-8'});
  var url = URL.createObjectURL(blob);
  var a = el('a');
  var now = new Date();
  var p2 = function (n) { return (n < 10 ? '0' : '') + n; };
  a.href = url;
  a.download = 'zigmon-events-' + now.getFullYear() + p2(now.getMonth() + 1) + p2(now.getDate())
    + '-' + p2(now.getHours()) + p2(now.getMinutes()) + '.txt';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  toast(rows.length + ' event(s) saved', true);
}

function paintEvents() {
  var host = $('events-table').parentNode;
  var bar = $('events-filter');
  if (!bar) {
    bar = el('div', 'btnrow'); bar.id = 'events-filter'; bar.style.cssText = 'flex-wrap:wrap;margin-bottom:12px;gap:8px';
    var mk = function (id, options, label, icons) {
      var sel = el('select'); sel.id = id; sel.className = 'evf';
      fillSelect(sel, [['', '\ud83d\udd3d ' + label]].concat(options.map(function (x) { return [x, (icons[x] || '\u2022') + ' ' + x]; })), '');
      sel.onchange = function () { EVENTS.filter[id.replace('evf-', '')] = sel.value; EVENTS.page = 1; loadEvents(); };
      return sel;
    };
    bar.appendChild(mk('evf-kind', ['device', 'plug', 'action', 'rule', 'binding', 'scene', 'sequence', 'schedule', 'switch', 'control', 'audit', 'bridge', 'gateway'], 'every kind', EVENT_KIND_ICON));
    bar.appendChild(mk('evf-level', ['info', 'warn', 'crit'], 'every level', EVENT_LEVEL_ICON));
    var tx = el('input'); tx.type = 'search'; tx.placeholder = 'search device or text\u2026'; tx.className = 'evf'; tx.style.minWidth = '220px';
    tx.title = 'Search every event ever recorded, not just the page: case does not matter and several words all have to appear (in any order).';
    tx.value = EVENTS.filter.text || '';
    tx.oninput = function () {
      EVENTS.filter.text = tx.value; EVENTS.page = 1;
      clearTimeout(EVENTS.timer);
      EVENTS.timer = setTimeout(loadEvents, 200);      // one query per pause, not per keystroke
    };
    bar.appendChild(tx);
    var pp = el('select'); pp.id = 'evf-perpage'; pp.className = 'evf';
    fillSelect(pp, [25, 50, 100, 200].map(function (n) { return [String(n), '\ud83d\udcc4 ' + n + ' per page']; }), String(EVENTS.perPage));
    pp.onchange = function () { EVENTS.perPage = parseInt(pp.value, 10) || 50; EVENTS.page = 1; paintEvents(); };
    bar.appendChild(pp);
    var cnt = el('span', 'muted small'); cnt.id = 'evf-count'; cnt.style.alignSelf = 'center';
    bar.appendChild(cnt);
    // what is on screen, as a plain file: whatever the filters have left,
    // every page of it, in the order it is shown
    var save = cmdButton('Save as text', 'download', 'small');
    save.classList.remove('needs-unlock');
    save.id = 'evf-save';
    save.title = 'Everything the filters have left, all pages of it, as a plain text file';
    save.onclick = function () { saveEventsAsText(); };
    bar.appendChild(save);
    host.insertBefore(bar, $('events-table'));
    var pager = el('div', 'pager'); pager.id = 'events-pager';
    host.insertBefore(pager, $('events-table').nextSibling);
  }
  var f = EVENTS.filter;
  var rows = EVENTS.rows.filter(function (e) {
    if (f.kind && e.kind !== f.kind) return false;
    if (f.level && (e.level || 'info') !== f.level) return false;
    if (f.text) {
      var hay = ((e.device_name || e.device || '') + ' ' + (e.detail || '') + ' ' + e.kind).toLowerCase();
      if (hay.indexOf(f.text.toLowerCase()) < 0) return false;
    }
    return true;
  });
  EVENTS.shown = rows;                     // what Save as text writes out
  var pages = Math.max(1, Math.ceil(rows.length / EVENTS.perPage));
  if (EVENTS.page > pages) EVENTS.page = pages;
  var from = (EVENTS.page - 1) * EVENTS.perPage, pageRows = rows.slice(from, from + EVENTS.perPage);
  var searching = !!(EVENTS.filter.text || EVENTS.filter.kind || EVENTS.filter.level);
  $('evf-count').textContent = searching && EVENTS.matched !== null && EVENTS.matched !== undefined
    ? EVENTS.matched + ' of ' + EVENTS.total + ' recorded' + (EVENTS.matched > EVENTS.rows.length ? ' \u00b7 newest ' + EVENTS.rows.length + ' shown' : '')
      + (rows.length ? ' \u00b7 ' + (from + 1) + '\u2013' + (from + pageRows.length) : '')
    : rows.length + ' of ' + EVENTS.rows.length + (rows.length ? ' \u00b7 ' + (from + 1) + '\u2013' + (from + pageRows.length) : '');
  paintEventsPager(pages);
  (function (r) {
    var tb = $('events-table').querySelector('tbody');
    tb.innerHTML = '';
    $('events-empty').hidden = r.events.length > 0;
    r.events.forEach(function (e) {
      var tr = el('tr');
      tr.innerHTML = '<td class="small" style="white-space:nowrap">' + esc(stamp(e.ts)) + '</td>'
        + '<td><span class="tag ' + esc(e.level || 'info') + '">' + esc(e.level || 'info') + '</span></td>'
        + '<td>' + esc(e.kind) + '</td>'
        + '<td>' + esc(e.device_name || e.device || '') + '</td>'
        + '<td>' + esc(e.detail || '') + '</td>';
      tb.appendChild(tr);
    });
  })({events: pageRows});
}
function paintEventsPager(pages) {
  var pager = $('events-pager'); if (!pager) return;
  pager.innerHTML = '';
  if (pages <= 1) return;
  var go = function (n) { EVENTS.page = Math.max(1, Math.min(pages, n)); paintEvents(); var t = $('events-table'); if (t.scrollIntoView) t.scrollIntoView({block: 'start', behavior: 'smooth'}); };
  var mk = function (label, n, cls, key) { var b = el('button', 'btn cmd small pg' + (cls ? ' ' + cls : '')); b.type = 'button'; if (key) setButtonIcon(b, key, label); else b.textContent = label; b.disabled = n === EVENTS.page || n < 1 || n > pages; b.onclick = function () { go(n); }; return b; };
  pager.appendChild(mk('First', 1, '', 'first'));
  pager.appendChild(mk('Prev', EVENTS.page - 1, '', 'prev'));
  // a window of numbers around the current page
  var lo = Math.max(1, EVENTS.page - 2), hi = Math.min(pages, EVENTS.page + 2);
  if (lo > 1) pager.appendChild(el('span', 'pg-dots', '\u2026'));
  for (var n = lo; n <= hi; n++) { var b = mk(String(n), n, n === EVENTS.page ? 'current' : ''); b.disabled = n === EVENTS.page; pager.appendChild(b); }
  if (hi < pages) pager.appendChild(el('span', 'pg-dots', '\u2026'));
  pager.appendChild(mk('Next', EVENTS.page + 1, '', 'next'));
  pager.appendChild(mk('Last', pages, '', 'last'));
  pager.appendChild(el('span', 'muted small pg-info', 'page ' + EVENTS.page + ' of ' + pages));
}

// ---- all values ------------------------------------------------------------------
// ---- who talks through whom: a small tree from the network map ----------------------
function renderMeshTree(st) {
  var card = $('mesh-card');
  if (!card) return;
  var zig = (st.devices || []).filter(function (d) { return d.source === 'zigbee'; });
  var withVia = zig.filter(function (d) { return d.via && d.via.name; });
  card.hidden = !withVia.length;
  if (!withVia.length) return;
  var groups = {};
  withVia.forEach(function (d) {
    var parent = d.via.name;
    (groups[parent] = groups[parent] || []).push(d);
  });
  var html = '';
  Object.keys(groups).sort().forEach(function (parent) {
    html += '<div class="mesh-parent">' + esc(parent) + '</div>';
    groups[parent].sort(function (a, b) { return a.name.localeCompare(b.name); }).forEach(function (d) {
      html += '<div class="mesh-child">\u2514 ' + esc(d.name)
        + ' <span class="dim">LQI ' + (isNum(d.via.lqi) ? fmt(d.via.lqi, 0) : '?') + '</span></div>';
    });
  });
  $('mesh-tree').innerHTML = html;
}

function applyRuntimeFlags(st) {
  var rc = st.runtime_config || {};
  CHART_OUTAGES = !!(rc.chart_outages || {}).value;
  var flag = function (k) { return !rc[k] || rc[k].value === null || rc[k].value === undefined ? true : !!rc[k].value; };
  LINKS = { plug: flag('link_plugs'), sensor: flag('link_sensors'), button: flag('link_buttons') };
}
var CHART_OUTAGES = false;
var LINKS = { plug: true, sensor: true, button: true };   // click-through to charts, per kind (Settings -> Charts)
function linkAllowed(d) { return d.source === 'plug' ? LINKS.plug : (d.has_action ? LINKS.button : LINKS.sensor); }
function renderAll(st) {
  applyRuntimeFlags(st);
  var host = $('all-values');
  host.innerHTML = '';
  st.devices.forEach(function (d) {
    var card = el('div', 'card');
    var h2 = el('h2'); h2.innerHTML = esc(d.name) + ' <span class="right">' + esc([d.vendor, d.model].filter(Boolean).join(' ')) + '</span>';
    card.appendChild(h2);
    var keys = Object.keys(d.values).sort();
    if (!keys.length) card.appendChild(el('div', 'muted small', 'Nothing reported yet'));
    keys.forEach(function (k) {
      var v = d.values[k];
      var row = el('div', 'kv');
      var kk = el('span', 'k'); kk.innerHTML = esc(v.label || k) + '<span class="d">' + esc(k) + (v.description ? ' — ' + esc(v.description) : '') + '</span>';
      var vv = el('span', 'v', fmt(v.value) + (v.unit ? ' ' + v.unit : ''));
      if (v.options && v.options.length) { var o = el('span', 'd', 'one of: ' + v.options.join(', ')); o.style.display = 'block'; o.style.color = 'var(--tx-mut)'; o.style.fontSize = '12px'; o.style.fontWeight = '400'; vv.appendChild(o); }
      row.appendChild(kk); row.appendChild(vv);
      card.appendChild(row);
    });
    if (d.via && d.via.name) {
      var via = el('div', 'kv');
      via.innerHTML = '<span class="k">Connected through<span class="d">from the Zigbee network map' + (d.via.ts ? ', ' + esc(ago(d.via.ts)) : '') + '</span></span>'
        + '<span class="v">' + esc(d.via.name) + (d.via.type ? ' <span style="color:var(--tx-mut);font-weight:400">(' + esc(d.via.type.toLowerCase()) + ')</span>' : '') + '</span>';
      card.appendChild(via);
    }
    var meta = el('div', 'kv');
    meta.innerHTML = '<span class="k">Last report</span><span class="v">' + esc(stamp(d.last_seen)) + '</span>';
    card.appendChild(meta);
    host.appendChild(card);
  });
}

// ---- control --------------------------------------------------------------------
function loadHealth() {
  var t0 = performance.now();
  api('health').then(function (h) {
    DB.apiMs = performance.now() - t0;
    renderDbInfo(h);
    if (DB.backups === null) loadDbBackups();
    var pairs = [
      ['Version', h.version], ['Uptime', ago(Math.floor(Date.now() / 1000) - h.uptime_s).replace(' ago', '')],
      ['Broker', h.connected ? 'connected' : 'disconnected' + (h.last_error ? ' — ' + h.last_error : '')],
      ['Bridge', h.bridge_state || 'unknown'], ['Messages received', h.messages],
      ['Last message', h.last_message ? ago(h.last_message) : 'none'],
      ['Subscriptions', (h.subscriptions || []).join(', ')],
      ['Database', h.db.path + ' — ' + (h.db.bytes ? (h.db.bytes / 1048576).toFixed(1) + ' MB' : '?') + ', ' + h.db.samples + ' samples, ' + h.db.samples_hourly + ' hourly, ' + h.db.events + ' events'],
      ['Oldest data', h.db.oldest ? stamp(h.db.oldest) : '–'],
    ];
    if (h.pushes && h.pushes.listening) {
      pairs.push(['Webhook listener', h.pushes.endpoint + ' — ' + h.pushes.received + ' received, ' + h.pushes.rejected + ' rejected' + (h.pushes.last ? ', last ' + ago(h.pushes.last) : '')]);
    }
    var host = $('health-kv'); host.innerHTML = '';
    pairs.forEach(function (p) {
      var row = el('div', 'kv'); row.appendChild(el('span', 'k', p[0])); row.appendChild(el('span', 'v', String(p[1])));
      host.appendChild(row);
    });
  }).catch(function (e) { $('health-kv').textContent = 'Daemon not reachable: ' + e.message; });
}

var PIN = { resolve: null, length: 4 };
function pinInputs() { return Array.prototype.slice.call($('pindigits').querySelectorAll('input')); }
function pinNeeded() { return !!(STATE.status && STATE.status.pin_required); }

// One box per digit for a numeric PIN of 4–8, a single field for anything else.
function buildPinBoxes() {
  var st = STATE.status || {};
  var host = $('pindigits');
  var length = st.pin_length || 4, boxes = st.pin_numeric !== false && length >= 4 && length <= 8;
  var want = boxes ? 'boxes' + length : 'wide';
  if (host.getAttribute('data-kind') === want) return;
  host.setAttribute('data-kind', want);
  host.innerHTML = '';
  host.classList.toggle('wide', !boxes);
  PIN.length = boxes ? length : 0;
  var n = boxes ? length : 1;
  for (var i = 0; i < n; i++) {
    var input = el('input');
    input.type = 'password'; input.autocomplete = 'off';
    input.setAttribute('inputmode', boxes ? 'numeric' : 'text');
    if (boxes) input.maxLength = 1;
    input.setAttribute('aria-label', boxes ? 'digit ' + (i + 1) : 'PIN');
    host.appendChild(input);
  }
  wirePinInputs();
}
function pinValue() { return pinInputs().map(function (i) { return i.value; }).join(''); }
function pinComplete() { return PIN.length ? pinValue().length === PIN.length : pinValue().length > 0; }

function askPin(title, text, danger, unlock, confirmOnly) {
  // Resolves with the PIN, '' when none is configured, or null if the person backed out.
  return new Promise(function (resolve) {
    PIN.resolve = resolve;
    var needed = pinNeeded() && !confirmOnly;
    buildPinBoxes();
    $('pintitle').textContent = title;
    $('pinwhat').innerHTML = text;
    $('pinerr').textContent = '';
    $('pindigits').classList.remove('bad');
    $('pindigits').hidden = !needed;
    $('unlockbox').hidden = !unlock;
    $('pinicon').className = 'pinicon' + (danger ? ' danger' : '');
    $('pinok').className = 'btn primary' + (danger ? ' danger' : '');
    pinInputs().forEach(function (input) { input.value = ''; input.classList.remove('filled'); });
    $('pinok').disabled = needed;
    $('pinback').hidden = false;
    setTimeout(function () { (needed ? pinInputs()[0] : $('pinok')).focus(); }, 40);
  });
}
function closePin(value) {
  $('pinback').hidden = true;
  var resolve = PIN.resolve;
  PIN.resolve = null;
  if (resolve) resolve(value);
}
function pinShake(message) {
  $('pinerr').textContent = message;
  var box = $('pindigits');
  box.classList.add('bad');
  setTimeout(function () { box.classList.remove('bad'); }, 400);
  pinInputs().forEach(function (input) { input.value = ''; input.classList.remove('filled'); });
  $('pinok').disabled = true;
  pinInputs()[0].focus();
}
function wirePinInputs() {
  var inputs = pinInputs();
  inputs.forEach(function (input, index) {
    input.addEventListener('input', function () {
      if (PIN.length) {
        input.value = input.value.replace(/\D/g, '').slice(-1);
        input.classList.toggle('filled', input.value !== '');
        if (input.value && index < inputs.length - 1) inputs[index + 1].focus();
      }
      $('pinok').disabled = !pinComplete();
      if (PIN.length && pinComplete()) $('pinok').focus();
    });
    input.addEventListener('keydown', function (e) {
      if (PIN.length && e.key === 'Backspace' && !input.value && index > 0) {
        inputs[index - 1].focus(); inputs[index - 1].value = ''; inputs[index - 1].classList.remove('filled');
        e.preventDefault();
      } else if (PIN.length && e.key === 'ArrowLeft' && index > 0) {
        inputs[index - 1].focus();
      } else if (PIN.length && e.key === 'ArrowRight' && index < inputs.length - 1) {
        inputs[index + 1].focus();
      } else if (e.key === 'Enter' && pinComplete()) {
        closePin(pinValue());
      } else if (e.key === 'Escape') {
        closePin(null);
      }
    });
    input.addEventListener('paste', function (e) {
      if (!PIN.length) return;
      var text = (e.clipboardData || window.clipboardData).getData('text') || '';
      var digits = text.replace(/\D/g, '').slice(0, PIN.length);
      if (!digits) return;
      e.preventDefault();
      inputs.forEach(function (box, n) { box.value = digits[n] || ''; box.classList.toggle('filled', !!digits[n]); });
      $('pinok').disabled = digits.length !== PIN.length;
      inputs[Math.min(digits.length, PIN.length - 1)].focus();
    });
  });
}
$('pinok').onclick = function () {
  var digitsShown = !$('pindigits').hidden;
  if (!digitsShown) { closePin(''); return; }
  if (pinComplete()) closePin(pinValue());
};
$('pincancel').onclick = function () { closePin(null); };
$('pinback').addEventListener('mousedown', function (e) { if (e.target === $('pinback')) closePin(null); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('pinback').hidden) closePin(null); });

// ---- the editing lock ---------------------------------------------------------------
// Nothing that changes something works while locked. Unlocking takes the PIN
// once and lasts a chosen while; the daemon hands out a session token that
// every request carries instead of the PIN, and forgets it when time is up.
var LOCK = { token: null, until: 0 };
try { var savedLock = JSON.parse(sessionStorage.getItem('zigmon-unlock') || 'null'); if (savedLock && savedLock.until * 1000 > Date.now()) LOCK = Object.assign(LOCK, savedLock); } catch (e) {}
function isUnlocked() { return !pinNeeded() || !!(LOCK.token && LOCK.until * 1000 > Date.now()); }
function rememberLock() { try { if (LOCK.token) sessionStorage.setItem('zigmon-unlock', JSON.stringify({token: LOCK.token, until: LOCK.until})); else sessionStorage.removeItem('zigmon-unlock'); } catch (e) {} }
function setLocked(reason) {
  var was = !!LOCK.token;
  LOCK.token = null; LOCK.until = 0; rememberLock();
  renderLock();
  SIGS = {};
  if (was && STATE.status) { renderOverviewCustom(STATE.status); renderOverviewAddControl(STATE.status); }
  if (was) tick(true);                 // drop the drag affordances
  if (was && reason) toast(reason, false);
}
// Cards are only draggable when this is on. Unlocking editing used to make
// every tile draggable at once, and then a slider on a card could not be
// dragged without the card going with it.
var REARRANGE = false;
function renderLock() {
  var pinRequired = pinNeeded();
  var unlocked = isUnlocked();
  if (!unlocked && REARRANGE) { REARRANGE = false; SIGS = {}; }
  var ap = $('arrangepill');
  // only where cards can actually be moved
  ap.hidden = !unlocked || ['overview', 'plugs', 'sensors', 'buttons', 'wifi', 'heating'].indexOf(STATE.tab) < 0;
  ap.className = 'lockpill arrange' + (REARRANGE ? ' on' : '');
  $('arrangepill-text').textContent = REARRANGE ? 'Rearranging' : 'Rearrange off';
  document.body.classList.toggle('arranging', REARRANGE && unlocked);
  document.body.classList.toggle('locked', !unlocked);
  var pill = $('lockpill');
  pill.hidden = !pinRequired;
  pill.className = 'lockpill ' + (unlocked ? 'unlocked' : 'locked');
  var left = Math.max(0, Math.floor(LOCK.until - Date.now() / 1000));
  var mm = Math.floor(left / 60), ss = left % 60;
  $('lockpill-text').innerHTML = unlocked ? 'Editing <span class="lockpill-time">' + mm + ':' + (ss < 10 ? '0' : '') + ss + '</span>' : 'Locked';
  pill.title = unlocked ? 'Editing is unlocked. Click to lock it now.' : 'Editing is locked. Click to unlock for a while.';
  var lt = $('lock-toggle');
  setButtonIcon(lt, unlocked ? 'lock' : 'unlock', unlocked ? 'Lock now' : 'Unlock editing');
  lt.className = 'btn cmd' + (unlocked ? '' : ' primary');
  lt.title = unlocked ? 'Lock editing now; the session ends for this browser' : 'Unlock editing with the PIN for a chosen time';
  $('lock-card').hidden = !pinRequired;
  $('lock-state').textContent = !pinRequired ? '' : unlocked ? 'Unlocked, ' + mm + ' min ' + ss + ' s left.' : 'Locked.';
  if (LOCK.token && pinRequired && left === 0) setLocked('Editing locked: the time is up');
}
setInterval(renderLock, 1000);
function unlockFlow(then) {
  // Ask for the PIN and a duration, get a session from the daemon, then carry on.
  askPin('Unlock editing', 'While unlocked, nothing on the dashboard asks for the PIN again.', false, true).then(function go(pin) {
    if (pin === null) return;
    var minutes = parseInt($('unlock-minutes').value, 10) || 15;
    api('unlock', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({pin: pin, minutes: minutes})}).then(function (r) {
      LOCK.token = r.token; LOCK.until = r.until; rememberLock(); renderLock();
      toast('Editing unlocked for ' + minutes + ' min', true);
      SIGS = {};
      if (STATE.status) { renderOverviewCustom(STATE.status); renderOverviewAddControl(STATE.status); }
      tick(true);                      // re-render so cards become draggable at once
      if (then) then();
    }, function (e) {
      var message = e.message || String(e);
      if (/PIN/i.test(message) && !/locked|too many/i.test(message)) {
        $('pinback').hidden = false; pinShake(message); PIN.resolve = go; return;
      }
      toast(message, false);
    });
  });
}
function lockNow() {
  var token = LOCK.token;
  setLocked(null);
  if (token) post('lock', {session: token}).then(function () { toast('Editing locked', true); }, function () {});
}
$('lockpill').onclick = function () { if (LOCK.token) lockNow(); else unlockFlow(); };
$('arrangepill').onclick = function () {
  REARRANGE = !REARRANGE;
  SIGS = {}; renderLock();
  if (STATE.status) renderTab(STATE.tab, STATE.status);
  toast(REARRANGE ? 'Drag a card to move it' : 'Cards stay put', true);
};
$('lock-toggle').onclick = function () { if (isUnlocked() && LOCK.token) lockNow(); else unlockFlow(); };

// The socket buttons on the overview: while editing is unlocked they act at
// once like everything else; while locked they ask for the PIN per click,
// without unlocking anything. The wrong-PIN retry happens in the same
// dialogue; a lockout closes it with a toast.
function withPinAlways(title, text, action, danger) {
  if (isUnlocked()) {
    action('').then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/session has expired/i.test(message)) { setLocked('Editing locked: ' + message); return; }
      toast(message, false);
    });
    return;
  }
  askPin(title, text, danger).then(function run(pin) {
    if (pin === null) return;
    action(pin).then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/PIN/i.test(message) && !/locked|too many/i.test(message) && pinNeeded()) {
        $('pinback').hidden = false; pinShake(message); PIN.resolve = run; return;
      }
      toast(message, false);
    });
  });
}

// Everything on the Control tab goes through here. Locked: offer to unlock,
// then do it. Unlocked: just do it - the session token stands in for the PIN,
// and the PIN dialogue is never shown.
function withPin(title, text, action, danger) {
  function run() {
    action('').then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/session has expired|missing or wrong API token/i.test(message)) { setLocked('Editing locked: ' + message); return; }
      toast(message, false);
    });
  }
  if (isUnlocked()) { run(); return; }
  unlockFlow(run);
}
$('join-toggle').onclick = function () {
  var open = !!$('join-toggle').dataset.open;
  if (open) {
    withPin('Close the Zigbee network', 'Joining will be disabled.', function (pin) {
      return post('permit-join', {enable: false, pin: pin}).then(function () { return 'Network closed'; });
    });
  } else {
    withPin('Open the Zigbee network', 'New devices will be able to join for 254 seconds.', function (pin) {
      return post('permit-join', {enable: true, pin: pin}).then(function () { return 'Network open \u2014 pair your device now'; });
    });
  }
};
Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) {
  b.onclick = function () {
    var scope = b.getAttribute('data-reset');
    var what = {history: 'all recorded samples', events: 'the event log', all: 'everything this dashboard has recorded'}[scope];
    withPin('Erase ' + what, '<b>This cannot be undone.</b>', function (pin) {
      var finish = dbRunStart('Erase ' + what, 'rec');
      return post('reset', {scope: scope, pin: pin}).then(function (r) {
        var text = 'Erased ' + what + (r && r.after_bytes !== undefined
          ? ': ' + sizeText(r.before_bytes) + ' \u2192 ' + sizeText(r.after_bytes) : '');
        finish(true, text); tick(true);
        return text;
      }, function (e) { finish(false, (e && e.message) || 'failed'); throw e; });
    }, true);
  };
});
$('reset-device-btn').onclick = function () {
  var id = $('reset-device').value, d = deviceById(id);
  var leftover = ((STALE && STALE.devices) || []).filter(function (x) { return x.device === id; })[0];
  if (leftover) {
    withDangerConfirm('Erase ' + leftover.name,
      '<b>' + leftover.rows.toLocaleString() + '</b> readings left behind by a device that is gone. This cannot be undone.',
      function (pin) {
        var finish = dbRunStart('Erase ' + leftover.name, 'rec');
        return post('db-stale-drop', {device: id, pin: pin}).then(function (r) {
          var text = 'Erased ' + r.rows.toLocaleString() + ' readings: ' + sizeText(r.before_bytes) + ' \u2192 ' + sizeText(r.after_bytes);
          finish(true, text); STALE = null; $('stale-drop').hidden = true; renderForgetSelect(STATE.status);
          return text;
        }, function (e) { finish(false, (e && e.message) || 'failed'); throw e; });
      });
    return;
  }
  if (!d) { toast(id ? 'That device is no longer listed' : 'Pick a device first', false); return; }
  withPin('Forget ' + d.name, 'Its history is erased. It reappears when it next reports.', function (pin) {
    var finish = dbRunStart('Forget ' + d.name, 'rec');
    return post('reset', {scope: 'device', device: id, pin: pin}).then(function (r) {
      var text = 'Forgot ' + d.name + (r && r.after_bytes !== undefined
        ? ': ' + sizeText(r.before_bytes) + ' \u2192 ' + sizeText(r.after_bytes) : '');
      finish(true, text); tick(true);
      return text;
    }, function (e) { finish(false, (e && e.message) || 'failed'); throw e; });
  }, true);
};


// ---- icons and hints, as in upsmon -------------------------------------------------
var ICONS = {
  power: '<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  // a key and a going-round-again: asked for by name and drawn as nothing at
  // all until now, since an unknown name makes an empty <svg> rather than a
  // complaint
  key: '<circle cx="8" cy="12" r="3.2"/><path d="M11.2 12H21"/><path d="M17 12v3"/><path d="M20 12v2.4"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v5h-5"/>',
  reset: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
  reboot: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
  cancel: '<circle cx="12" cy="12" r="9"/><path d="M15 9l-6 6M9 9l6 6"/>',
  trash: '<path d="M4 7h16"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13"/><path d="M10 11v6M14 11v6"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  plug: '<path d="M9 3v6M15 3v6"/><path d="M6 9h12v3a6 6 0 0 1-12 0z"/><path d="M12 18v3"/>',
  join: '<path d="M12 20V10"/><path d="M8.5 13.5a5 5 0 0 1 7 0"/><path d="M5.6 10.6a9 9 0 0 1 12.8 0"/><path d="M2.8 7.8a13 13 0 0 1 18.4 0"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  add: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  link: '<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
  pencil: '<path d="M17 3a2.4 2.4 0 0 1 3.4 3.4L8 18.8 3 20l1.2-5z"/>',
  play: '<path d="M7 5v14l11-7z"/>',
  download: '<path d="M12 4v12"/><path d="M7 11l5 5 5-5"/><path d="M4 20h16"/>',
  first: '<path d="M11 18l-6-6 6-6"/><path d="M18 18l-6-6 6-6"/>',
  prev: '<path d="M15 18l-6-6 6-6"/>',
  next: '<path d="M9 18l6-6-6-6"/>',
  last: '<path d="M13 18l6-6-6-6"/><path d="M6 18l6-6-6-6"/>',
  chart: '<path d="M4 19h16"/><path d="M5 15l4-5 4 3 6-8"/>',
  unlock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  bell: '<path d="M18 16v-5a6 6 0 1 0-12 0v5l-2 3h16z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  hand: '<path d="M9 11V5.5a1.5 1.5 0 0 1 3 0V11"/><path d="M12 11V4.5a1.5 1.5 0 0 1 3 0V11"/><path d="M15 11V6.5a1.5 1.5 0 0 1 3 0V13c0 4-2.5 7-6 7s-6-2.5-6-6v-3a1.5 1.5 0 0 1 3 0"/>',
  wifi: '<path d="M2 8.5a16 16 0 0 1 20 0"/><path d="M5 12a11 11 0 0 1 14 0"/><path d="M8.5 15.5a6 6 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/>',
  person: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.6 3.1-5.5 7-5.5s7 1.9 7 5.5"/>',
  door: '<path d="M14 3H6v18h8"/><path d="M14 3l4 2v14l-4 2z"/><circle cx="15.5" cy="12" r="1"/>',
  upload: '<path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 20h16"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  up: '<path d="M12 19V5"/><path d="M5 12l7-7 7 7"/>',
  down: '<path d="M12 5v14"/><path d="M19 12l-7 7-7-7"/>',
  forget: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M9 11l6 6M15 11l-6 6"/>'
};
function iconMarkup(key, size) {
  return '<svg viewBox="0 0 24 24" width="' + (size || 17) + '" height="' + (size || 17)
    + '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
    + (ICONS[key] || '') + '</svg>';
}
function setButtonIcon(button, key, label) {
  var text = label !== undefined ? label : button.textContent;
  button.innerHTML = iconMarkup(key) + (text ? '<span>' + esc(text) + '</span>' : '');
  return button;
}
// A button that is only an icon: in a table row a word would push everything
// about, and the row has no space to spare.
function iconButton(key, title) {
  var b = el('button', 'btn iconbtn small needs-unlock');
  b.type = 'button';
  b.title = title || '';
  return setButtonIcon(b, key, '');
}


function cmdButton(label, key, cls) {
  var b = el('button', 'btn cmd needs-unlock' + (cls ? ' ' + cls : ''));
  b.type = 'button';
  return setButtonIcon(b, key, label);
}

// Resting the pointer on a button for a while reveals what it really does.
var HINT_DELAY_MS = 5000;
var HINT = { timer: null, node: null };
function attachHint(element, html) {
  element.addEventListener('mouseenter', function () {
    clearTimeout(HINT.timer);
    HINT.timer = setTimeout(function () { showHint(element, html); }, HINT_DELAY_MS);
  });
  element.addEventListener('mouseleave', hideHint);
  element.addEventListener('blur', hideHint);
  element.addEventListener('touchstart', function () {
    clearTimeout(HINT.timer);
    HINT.timer = setTimeout(function () { showHint(element, html); }, 600);
  }, { passive: true });
  element.addEventListener('touchend', hideHint);
}
function showHint(element, html) {
  hideHint();
  var tip = el('div', 'hint');
  tip.innerHTML = html;
  document.body.appendChild(tip);
  var box = element.getBoundingClientRect();
  var width = tip.offsetWidth, height = tip.offsetHeight;
  var left = box.left + box.width / 2 - width / 2;
  left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
  var top = box.top - height - 10;
  if (top < 8) top = box.bottom + 10;
  tip.style.left = Math.round(left) + 'px';
  tip.style.top = Math.round(top) + 'px';
  requestAnimationFrame(function () { tip.classList.add('show'); });
  HINT.node = tip;
}
function hideHint() {
  clearTimeout(HINT.timer);
  if (HINT.node && HINT.node.parentNode) HINT.node.parentNode.removeChild(HINT.node);
  HINT.node = null;
}
window.addEventListener('scroll', hideHint, true);

// The buttons that live in the markup get their icons and hints once.
(function decorateStaticButtons() {
  ['join-toggle', 'reset-device-btn', 'binding-save', 'managed-save', 'managed-discover', 'rule-save', 'scene-save', 'notify-save', 'notify-test', 'backup-import', 'settings-save', 'backup-now', 'schedule-save', 'gateway-save', 'sequence-save', 'sequence-add', 'db-check', 'db-optimize', 'db-backup', 'db-upload', 'db-prune', 'stale-scan', 'stale-drop', 'ghost-clear',
   'wifi-test', 'wifi-save', 'wifi-load', 'person-add', 'people-save', 'ptrig-add', 'ptrig-save',
   'message-add', 'messages-save', 'alertband-clear', 'wifi-refresh', 'room-add', 'rooms-save', 'heat-save',
   'ssh-generate', 'ssh-upload', 'ssh-download', 'ssh-forget', 'ssh-test',
   // the ones that came with the approvals tab and the blacklist: every
   // button that changes something wears the lock, so a locked dashboard
   // looks locked rather than only behaving that way when pressed
   'approvals-stop-all', 'approvals-forget-btn', 'blocked-add', 'blocked-add-forever',
   'blocked-clear', 'blocked-forget', 'blocked-forget-counters', 'script-save',
   'backup-export-secrets', 'wifi-forget-btn'].forEach(function (id) { $(id).classList.add('needs-unlock'); });
  Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) { b.classList.add('needs-unlock'); });
  setButtonIcon($('join-toggle'), 'join');
  attachHint($('join-toggle'), '<b>bridge/request/permit_join</b> {"time": 254} / {"time": 0}<br>Opens the network to new devices for four minutes, or closes it - the button follows the current state. Asks for the PIN.');
  var resetHints = {
    history: '<b>POST /api/reset</b> {"scope": "history"}<br>Every recorded sample, full and hourly. Devices and events stay.',
    events: '<b>POST /api/reset</b> {"scope": "events"}<br>The event log only.',
    all: '<b>POST /api/reset</b> {"scope": "all"}<br><em>Everything</em> this dashboard recorded. Button bindings are kept.'
  };
  Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) {
    setButtonIcon(b, 'trash');
    attachHint(b, resetHints[b.getAttribute('data-reset')] || '');
  });
  setButtonIcon($('reset-device-btn'), 'forget');
  attachHint($('reset-device-btn'), '<b>POST /api/reset</b> {"scope": "device"}<br>Removes the device and its history from here. Zigbee2MQTT still knows it; it comes back with its next report.');
  // the newer editors, so no button on the page is left bare
  setButtonIcon($('outbox-flush'), 'upload');
  setButtonIcon($('outbox-drop'), 'trash');
  setButtonIcon($('tellok'), 'check');
  setButtonIcon($('script-add'), 'add');
  setButtonIcon($('script-save'), 'save');
  setButtonIcon($('smscmd-add'), 'add');
  setButtonIcon($('smscmd-save'), 'save');
  setButtonIcon($('agroup-add'), 'add');
  setButtonIcon($('agroup-save'), 'save');
  setButtonIcon($('sgroup-add'), 'add');
  setButtonIcon($('sgroup-save'), 'save');
  setButtonIcon($('sms-save'), 'save');
  setButtonIcon($('sms-test'), 'search');
  setButtonIcon($('sms-send'), 'upload');
  setButtonIcon($('sms-poll'), 'download');
  setButtonIcon($('modem-reset'), 'reset');
  setButtonIcon($('sms-credit'), 'search');
  setButtonIcon($('acl-mend'), 'check');
  setButtonIcon($('wifi-forget-btn'), 'forget');
  setButtonIcon($('wifi-seen-btn'), 'search');
  setButtonIcon($('sms-write-send'), 'upload');
  setButtonIcon($('binding-add'), 'add');
  setButtonIcon($('binding-save'), 'save');
  setButtonIcon($('rule-add'), 'add');
  setButtonIcon($('rule-save'), 'save');
  setButtonIcon($('scene-add'), 'add');
  setButtonIcon($('scene-save'), 'save');
  setButtonIcon($('tap-add'), 'add');
  setButtonIcon($('taps-save'), 'save');
  setButtonIcon($('backup-export'), 'save');
  setButtonIcon($('settings-save'), 'save');
  setButtonIcon($('gateway-add'), 'add');
  setButtonIcon($('sequence-add'), 'add');
  setButtonIcon($('managed-add-plug'), 'add');
  setButtonIcon($('managed-add-sensor'), 'add');
  setButtonIcon($('managed-discover'), 'search');
  setButtonIcon($('managed-save'), 'save');
  setButtonIcon($('lock-all'), 'lock');
  setButtonIcon($('notify-save'), 'save');
  setButtonIcon($('notify-test'), 'bell');
  setButtonIcon($('backup-import'), 'upload');
  setButtonIcon($('backup-now'), 'save');
  setButtonIcon($('ov-add-btn'), 'add');
  setButtonIcon($('attnclose'), 'close');
  setButtonIcon($('pincancel'), 'close');
  setButtonIcon($('pinok'), 'check');
  setButtonIcon($('db-check'), 'check');
  setButtonIcon($('db-optimize'), 'reboot');
  setButtonIcon($('db-backup'), 'save');
  setButtonIcon($('db-upload'), 'upload');
  setButtonIcon($('db-prune'), 'trash');
  setButtonIcon($('stale-scan'), 'search');
  setButtonIcon($('message-add'), 'add');
  setButtonIcon($('messages-save'), 'save');
  setButtonIcon($('wifi-test'), 'search');
  setButtonIcon($('ssh-generate'), 'add');
  setButtonIcon($('ssh-upload'), 'upload');
  setButtonIcon($('ssh-download'), 'download');
  setButtonIcon($('ssh-forget'), 'trash');
  setButtonIcon($('ssh-test'), 'wifi');
  setButtonIcon($('wifi-refresh'), 'wifi');
  setButtonIcon($('wifi-save'), 'save');
  setButtonIcon($('wifi-load'), 'wifi');
  setButtonIcon($('person-add'), 'add');
  setButtonIcon($('people-save'), 'save');
  setButtonIcon($('ptrig-add'), 'add');
  setButtonIcon($('room-add'), 'add');
  setButtonIcon($('rooms-save'), 'save');
  setButtonIcon($('heat-save'), 'save');
  setButtonIcon($('ptrig-save'), 'save');
  attachHint($('wifi-test'), '<b>POST /api/wifi/test</b><br>Asks the controller for its clients with the details typed above. Saves nothing.');
  attachHint($('wifi-load'), '<b>POST /api/wifi/clients</b> {"refresh": true}<br>Who is on the network right now, straight from the controller.');
  setButtonIcon($('stale-drop'), 'trash');
  setButtonIcon($('ghost-clear'), 'reset');
  setButtonIcon($('sequence-save'), 'save');
  setButtonIcon($('gateway-save'), 'save');
  setButtonIcon($('schedule-add'), 'add');
  setButtonIcon($('schedule-save'), 'save');
  attachHint($('rule-save'), '<b>POST /api/rules</b><br>Replaces the whole list. Edge-triggered with a cooldown; the daemon evaluates every report and every plug poll.');
  attachHint($('binding-save'), '<b>POST /api/bindings</b><br>Replaces the whole list. The daemon applies it at once, no restart.');
})();

// ---- smart plugs -----------------------------------------------------------------
function powerIcon() {
  return '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/></svg>';
}
function runtimeText(seconds) {
  if (!isNum(seconds)) return '–';
  var d = Math.floor(seconds / 86400), h = Math.floor((seconds % 86400) / 3600), m = Math.floor((seconds % 3600) / 60);
  if (d) return d + 'd ' + h + 'h';
  if (h) return h + 'h ' + m + 'm';
  return m + 'm';
}
function counterSince(counter) {
  if (!counter || !counter.reset_at) return 'the plug does not say since when';
  return (counter.reset_exact ? 'since ' : 'counting since at least ') + stamp(counter.reset_at) + ' · ' + ago(counter.reset_at);
}
function counterText(type, value) {
  if (type === 'aenergy' || type === 'ret_aenergy') return value >= 1000 ? fmt(value / 1000, 2) + ' kWh' : fmt(value, 1) + ' Wh';
  if (type === 'switch_on') return fmt(value, 0) + '×';
  return runtimeText(value);
}
function plugByName(name) {
  var plugs = (STATE.status && STATE.status.plugs) || [];
  for (var i = 0; i < plugs.length; i++) if (plugs[i].name === name) return plugs[i];
  return null;
}
// ---- buttons: what was just pressed, and what the device can send -----------------
function prettyAction(action) {
  var m = /^([0-9]+)_(.+)$/.exec(action || '');
  return {
    text: (m ? m[2] : action || '').replace(/_/g, ' '),
    button: m ? m[1] : null,
  };
}
// A gateway's own readings, whichever of them this box happens to report.
// Keys differ per vendor (an SLZB names its board temperature esp32_temp, a
// Shelly reports one figure per socket), so they are matched by shape.
// The firmware a gateway entry reports for this box. The model is already in
// the row, so only add what is not there yet.
function gatewayFirmware(d) {
  var g = d.gateway;
  if (!g) return '';
  var model = String(d.model || '');
  if (g.fw && model.indexOf(g.model) >= 0) return g.fw;
  return g.text || '';
}
function gatewayReadings(d) {
  var values = d.values || {};
  var num = function (key) { var v = (values[key] || {}).value; return isNum(v) ? v : null; };
  var find = function (test) {
    for (var k in values) { if (k.indexOf('gw.') === 0 && test(k) && isNum((values[k] || {}).value)) return k; }
    return null;
  };
  var out = [];
  // every socket of a strip added up - the one figure that says what it carries
  var total = 0, sockets = 0;
  for (var k in values) {
    if (/^gw\.switch:\d+\.apower$/.test(k) && isNum((values[k] || {}).value)) { total += values[k].value; sockets++; }
  }
  if (sockets) out.push({text: fmt(total, 1), unit: 'W', label: sockets > 1 ? 'total power' : 'power'});
  var temp = find(function (k) { return /(esp32_temp|temperature(\.tC)?$)/.test(k); });
  if (temp) out.push({text: fmt(num(temp), 1), unit: '°C', label: 'board temp'});
  var rssi = find(function (k) { return /rssi/i.test(k); });
  if (rssi) out.push({text: fmt(num(rssi), 0), unit: 'dBm', label: 'Wi-Fi'});
  var up = find(function (k) { return /uptime$/.test(k); });
  if (up) out.push({text: runtimeText(num(up)), unit: '', label: 'uptime'});
  return out.slice(0, 4);
}
function lastActionReading(d) {
  var r = el('div', 'reading lastact');
  var last = d.last_action;
  if (!last) {
    r.appendChild(el('div', 'v', '—'));
    r.appendChild(el('div', 'l', 'No press seen yet'));
    return r;
  }
  var p = prettyAction(last.action);
  var fresh = STATE.status && (STATE.status.ts - last.ts) < 20;
  if (fresh) r.className += ' fresh';
  var v = el('div', 'v', p.text);
  r.appendChild(v);
  r.appendChild(el('div', 'l', (p.button ? 'button ' + p.button + ' · ' : '') + (fresh ? 'just now' : ago(last.ts))));
  r.title = 'Last action: ' + last.action + ' · ' + stamp(last.ts);
  return r;
}
function actionChips(d) {
  var box = el('div', 'actchips');
  var actions = d.actions || [];
  // A multi-button remote names everything N_action; fold the buttons away
  // and list each gesture once.
  var suffixes = [], buttons = {}, grouped = actions.length > 0;
  actions.forEach(function (a) {
    var m = /^([0-9]+)_(.+)$/.exec(a);
    if (!m) { grouped = false; return; }
    buttons[m[1]] = true;
    if (suffixes.indexOf(m[2]) < 0) suffixes.push(m[2]);
  });
  var list = actions, buttonCount = Object.keys(buttons).length;
  if (grouped && buttonCount > 1) {
    list = suffixes;
    var g = el('span', 'chip groups', buttonCount + ' buttons');
    g.title = 'Each gesture exists for every button: ' + actions.join(', ');
    box.appendChild(g);
  }
  var shown = list.slice(0, 7);
  shown.forEach(function (a) { box.appendChild(el('span', 'chip', a.replace(/_/g, ' '))); });
  if (list.length > shown.length) {
    var more = el('span', 'chip more', '+' + (list.length - shown.length));
    more.title = list.join(', ');
    box.appendChild(more);
  }
  return box;
}
// ---- the overview layout: drag to reorder while editing is unlocked ----------------
// The saved order lives in the daemon (meta), so every browser sees the same
// layout. While a card is being dragged the two lists are not re-rendered;
// the drop reads the final order straight from the DOM and saves it.
var ORDER = { drag: null, justDropped: 0, local: {} };
function savedOrder(kind) {
  if (ORDER.local[kind]) return ORDER.local[kind];
  return ((STATE.status || {}).order || {})[kind] || [];
}
function sortByOrder(items, kind, keyFn) {
  var saved = savedOrder(kind);
  if (!saved.length) return items;
  var pos = {};
  saved.forEach(function (k, i) { pos[k] = i; });
  return items.slice().sort(function (a, b) {
    var x = pos[keyFn(a)], y = pos[keyFn(b)];
    return (x === undefined ? 1e9 : x) - (y === undefined ? 1e9 : y);
  });
}
// A multi-relay strip (e.g. a Shelly PowerStrip 4) keeps its channels in
// their own little order, independent of where the whole strip sits among
// the other plugs. Saved server-side as order.groups[host] = [names...].
function savedGroupOrder(groupHost) {
  var local = ORDER.local.groups || {};
  if (local[groupHost]) return local[groupHost];
  return (((STATE.status || {}).order || {}).groups || {})[groupHost] || [];
}
function sortByGroupOrder(items, groupHost, keyFn) {
  var saved = savedGroupOrder(groupHost);
  if (!saved.length) return items;
  var pos = {};
  saved.forEach(function (k, i) { pos[k] = i; });
  return items.slice().sort(function (a, b) {
    var x = pos[keyFn(a)], y = pos[keyFn(b)];
    return (x === undefined ? 1e9 : x) - (y === undefined ? 1e9 : y);
  });
}
function savedGroupsAll() {
  var base = ((STATE.status || {}).order || {}).groups || {};
  var local = ORDER.local.groups || {};
  var out = {};
  Object.keys(base).forEach(function (k) { out[k] = base[k]; });
  Object.keys(local).forEach(function (k) { out[k] = local[k]; });
  return out;
}
// kind is 'plugs' / 'devices' for the top-level lists, or 'grp:<host>' for
// the channels inside one strip - each strip is its own little drag scope,
// nested inside the top-level one without the two ever mixing.
function makeReorderable(node, host, kind, key) {
  node.dataset.okey = key;
  if (!isUnlocked() || !REARRANGE) return;
  node.draggable = true;
  node.classList.add('cangrab');
  node.addEventListener('dragstart', function (e) {
    ORDER.drag = { kind: kind, key: key, node: node };
    node.classList.add('draggingcard');
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', key); } catch (err) {} }
    e.stopPropagation();
  });
  node.addEventListener('dragover', function (e) {
    if (!ORDER.drag || ORDER.drag.kind !== kind || ORDER.drag.key === key) return;
    e.preventDefault();
    e.stopPropagation();
    var dragged = ORDER.drag.node;
    var siblings = Array.prototype.slice.call(host.children);
    if (siblings.indexOf(dragged) < siblings.indexOf(node)) host.insertBefore(dragged, node.nextSibling);
    else host.insertBefore(dragged, node);
  });
  node.addEventListener('dragend', function (e) {
    node.classList.remove('draggingcard');
    e.stopPropagation();
    if (!ORDER.drag) return;
    ORDER.drag = null;
    ORDER.justDropped = Date.now();
    var keys = Array.prototype.map.call(host.children, function (c) { return c.dataset.okey; }).filter(Boolean);
    if (kind.indexOf('grp:') === 0) {
      ORDER.local.groups = ORDER.local.groups || {};
      ORDER.local.groups[kind.slice(4)] = keys;
    } else {
      ORDER.local[kind] = keys;
    }
    var payload = { plugs: savedOrder('plugs'), devices: savedOrder('devices'),
                    sensors: savedOrder('sensors'), buttons: savedOrder('buttons'), groups: savedGroupsAll() };
    post('order', payload).then(function () { toast('Layout saved', true); },
      function (e2) { toast('Layout not saved: ' + (e2.message || e2), false); ORDER.local = {}; tick(true); });
  });
}

// Four little bars beside every signal figure; the number stays. LQI is the
// Zigbee link (0-255, higher is better), rssi the plug's Wi-Fi in dBm.
function signalBars(kind, value, thresholds) {
  var q = 0, color;
  if (kind === 'lqi') {
    var crit = (thresholds || {}).lqi_crit || 20, warn = (thresholds || {}).lqi_warn || 40;
    q = value >= 160 ? 4 : value >= 100 ? 3 : value > warn ? 2 : value > crit ? 1 : 0;
    color = value <= crit ? 'var(--crit)' : (value <= warn ? 'var(--warn)' : 'var(--ok)');
  } else {
    q = value >= -55 ? 4 : value >= -65 ? 3 : value >= -75 ? 2 : value >= -85 ? 1 : 0;
    color = q >= 3 ? 'var(--ok)' : (q === 2 ? 'var(--warn)' : 'var(--crit)');
  }
  var box = el('span', 'sig q' + q);
  box.style.setProperty('--sigc', color);
  for (var i = 0; i < 4; i++) box.appendChild(el('i'));
  box.title = kind === 'lqi' ? 'Zigbee link quality ' + fmt(value, 0) + ' of 255' : 'Wi-Fi signal ' + fmt(value, 0) + ' dBm';
  return box;
}
function buildPlugCard(plug, compact) {
  var v = plug.values || {};
  var on = plug.output === 1;
  var card = el('div', 'card socket ' + (plug.online ? (on ? 'on' : 'off') : 'off') + (plug.stale ? (plug.optional ? ' stale unplugged' : ' stale') : '') + (compact ? ' compact' : ''));
  var state = el('div', 'socket-state');
  var btn;
  if (plug.monitor_only) {
    btn = el('span', 'socket-toggle watch');
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
    btn.title = plug.name + ' is monitor-only: watched, recorded and charted, never switched from here';
  } else {
    btn = el('button', 'socket-toggle'); btn.type = 'button'; btn.innerHTML = powerIcon();
    btn.title = 'Switch ' + plug.name + (on ? ' off' : ' on') + (isUnlocked() ? '' : ' (asks for the PIN)');
    btn.disabled = !plug.online || plug.stale;
    btn.onclick = function () { switchPlug(plug, !on, btn, 'pin'); };
  }
  state.appendChild(btn);
  var txt = el('div');
  txt.appendChild(el('div', 'socket-label', !plug.online ? plug.name + (plug.optional ? ' unplugged' : ' unreachable') : plug.name + (on ? ' on' : ' off')));
  var chip = holdChip(STATE.status, plug.name);
  if (chip) { var chipLine = el('div', 'socket-hold'); chipLine.appendChild(chip); txt.appendChild(chipLine); }
  if (LINKS.plug) {
    // the way to the charts: a small icon in the top-right corner, shown on hover only
    var hist = el('button', 'socket-hist'); hist.type = 'button'; hist.innerHTML = iconMarkup('chart', 15);
    hist.title = 'History and charts of ' + plug.name;
    hist.onclick = function (e) { e.stopPropagation(); if (Date.now() - ORDER.justDropped < 500) return; STATE.hDevice = plug.id; showTab('history'); };
    card.appendChild(hist);
  }
  var info = plug.info || {};
  var sub = plug.stale
    ? (plug.optional ? 'unplugged \u2014 last answer ' + ago(plug.generated) + ' \u00b7 picks up by itself when powered'
       : 'last answer ' + ago(plug.generated) + ' — ' + (plug.error || 'no answer') + (plug.retry_in ? ', retrying in ' + plug.retry_in + ' s' : ''))
    : compact ? '' : [info.model, info.app ? info.app + ' ' + (info.ver || '') : '', plug.host].filter(Boolean).join(' · ');
  if (sub) txt.appendChild(el('div', 'socket-sub', sub));
  state.appendChild(txt);
  card.appendChild(state);
  var figures = el('div', 'socket-figures');
  var pairs = [
    ['Power', isNum(v.power) ? fmt(v.power, 1) + ' W' : '–'],
    ['Voltage', isNum(v.voltage) ? fmt(v.voltage, 1) + ' V' : '–'],
    ['Current', isNum(v.current) ? fmt(v.current, 3) + ' A' : '–'],
    ['Frequency', isNum(v.freq) ? fmt(v.freq, 1) + ' Hz' : '–'],
    ['Energy', isNum(v.energy) ? fmt(v.energy / 1000, 3) + ' kWh' : '–'],
    ['Plug temp', isNum(v.temperature) ? fmt(v.temperature, 1) + ' °C' : '–'],
  ];
  if (isNum(v.on_time)) pairs.push(['On time', runtimeText(v.on_time)]);
  if (isNum(v.switch_on)) pairs.push(['Switched', fmt(v.switch_on, 0) + '×']);
  if (isNum(v.rssi)) pairs.push(['Wi-Fi', fmt(v.rssi, 0) + ' dBm', v.rssi]);
  if (compact) {
    // inside a strip the box-wide numbers (mains voltage and frequency,
    // Wi-Fi, the box temperature) sit in the strip header once - a channel
    // shows only what is its own
    var own = {'Power': 1, 'Current': 1, 'Energy': 1, 'On time': 1, 'Switched': 1};
    pairs = pairs.filter(function (pr) { return own[pr[0]]; });
  }
  pairs.forEach(function (pr) {
    var box = el('div'); box.appendChild(el('div', 'k', pr[0]));
    var val = el('div', 'v');
    if (pr.length > 2) val.appendChild(signalBars('rssi', pr[2]));
    val.appendChild(document.createTextNode((pr.length > 2 ? ' ' : '') + pr[1]));
    box.appendChild(val); figures.appendChild(box);
  });
  card.appendChild(figures);
  return card;
}
function renderSockets(st) {
  var host = $('sockets');
  if (ORDER.drag || Date.now() - ORDER.justDropped < 800) return;   // never redraw under a drag
  var plugs = st.plugs || [];
  $('plugs-empty').hidden = !!plugs.length;
  host.hidden = !plugs.length;
  host.innerHTML = '';
  if (!plugs.length) return;

  // Several rows sharing one address are one physical box (a multi-relay
  // strip such as a Shelly PowerStrip 4) - group them, so the dashboard
  // shows the box once with its channels inside, not four look-alike rows.
  var byHost = {};
  plugs.forEach(function (p) {
    var k = p.host || p.name;
    (byHost[k] = byHost[k] || []).push(p);
  });
  var items = [];
  Object.keys(byHost).forEach(function (h) {
    var group = byHost[h];
    if (group.length > 1) items.push({type: 'group', host: h, plugs: group});
    else items.push({type: 'single', plug: group[0]});
  });
  items = sortByOrder(items, 'plugs', function (it) { return it.type === 'group' ? 'grp:' + it.host : it.plug.name; });

  items.forEach(function (it) {
    if (it.type === 'single') {
      var card = buildPlugCard(it.plug, false);
      makeReorderable(card, host, 'plugs', it.plug.name);
      host.appendChild(card);
      return;
    }
    var group = it;
    var wrap = el('div', 'card stripgroup');
    var head = el('div', 'stripgroup-head');
    var anyOn = group.plugs.some(function (p) { return p.output === 1; });
    var allOnline = group.plugs.every(function (p) { return p.online && !p.stale; });
    var info = (group.plugs[0] || {}).info || {};
    var title = el('div');
    title.appendChild(el('div', 'stripgroup-title', (info.model || 'Multi-relay strip') + ' \u00b7 ' + group.plugs.length + ' channels'));
    title.appendChild(el('div', 'socket-sub', [info.app ? info.app + ' ' + (info.ver || '') : '', group.host].filter(Boolean).join(' \u00b7 ') + (allOnline ? '' : ' \u00b7 one or more channels unreachable')));
    head.appendChild(title);
    // the box-wide numbers, once: mains voltage and frequency, the box temperature, Wi-Fi
    var shared = el('div', 'socket-figures strip-shared');
    var first = group.plugs.filter(function (p) { return p.online && !p.stale; })[0] || group.plugs[0], sv = first.values || {};
    var sharedPairs = [];
    if (isNum(sv.voltage)) sharedPairs.push(['Voltage', fmt(sv.voltage, 1) + ' V']);
    if (isNum(sv.freq)) sharedPairs.push(['Frequency', fmt(sv.freq, 1) + ' Hz']);
    if (isNum(sv.temperature)) sharedPairs.push(['Box temp', fmt(sv.temperature, 1) + ' \u00b0C']);
    var totalW = group.plugs.reduce(function (a, p) { return a + (isNum((p.values || {}).power) ? p.values.power : 0); }, 0);
    sharedPairs.push(['Total power', fmt(totalW, 1) + ' W']);
    if (isNum(sv.rssi)) sharedPairs.push(['Wi-Fi', fmt(sv.rssi, 0) + ' dBm', sv.rssi]);
    sharedPairs.forEach(function (pr) {
      var box = el('div'); box.appendChild(el('div', 'k', pr[0]));
      var val = el('div', 'v');
      if (pr.length > 2) val.appendChild(signalBars('rssi', pr[2]));
      val.appendChild(document.createTextNode((pr.length > 2 ? ' ' : '') + pr[1]));
      box.appendChild(val); shared.appendChild(box);
    });
    head.appendChild(shared);
    head.appendChild(el('span', 'tag ' + (allOnline ? (anyOn ? 'ok' : 'dim') : 'crit'), allOnline ? (anyOn ? 'some on' : 'all off') : 'check'));
    wrap.appendChild(head);
    var body = el('div', 'stripgroup-body');
    var ordered = sortByGroupOrder(group.plugs, group.host, function (p) { return p.name; });
    ordered.forEach(function (p) {
      var sub = buildPlugCard(p, true);
      makeReorderable(sub, body, 'grp:' + group.host, p.name);
      body.appendChild(sub);
    });
    wrap.appendChild(body);
    makeReorderable(wrap, host, 'plugs', 'grp:' + group.host);
    host.appendChild(wrap);
  });
}
// Show the new state the moment it is asked for. A plug on Wi-Fi can take a
// moment to answer; the card should not sit there looking dead while it does.
// The next status tick carries the truth, so a refused or failed switch
// corrects itself within a second.
function showPlugPending(card, plug, on) {
  if (!card) return;
  card.classList.toggle('on', !!on);
  card.classList.toggle('off', !on);
  card.classList.add('pending');
  var label = card.querySelector('.socket-label');
  if (label && plug.online) label.textContent = plug.name + (on ? ' on' : ' off');
}
function switchPlug(plug, on, button, mode) {
  var card = button && button.closest ? button.closest('.card.socket') : null;
  if (button) { button.disabled = true; button.classList.add('busy'); }
  showPlugPending(card, plug, on);
  var ask = mode === 'pin' ? withPinAlways : withPin;
  ask('Switch ' + plug.name + ' ' + (on ? 'on' : 'off'), on ? 'Restores power to the socket.' : '<b>Everything plugged into it loses power.</b>', function (pin) {
    var body = {name: plug.name, on: on, pin: pin};
    if (mode === 'pin' && !isUnlocked()) body.session = '';   // locked: the PIN alone decides
    return post('plug-switch', body).then(function (r) {
      if (card) card.classList.remove('pending');
      tick(true);                                  // pull the confirmed state straight away
      return r.message || 'done';
    }, function (e) {
      if (card) card.classList.remove('pending');
      tick(true);                                  // put the real state back
      throw e;
    });
  }, !on);
  setTimeout(function () { if (button) { button.disabled = false; button.classList.remove('busy'); } if (card) card.classList.remove('pending'); }, 3000);
}
function resetPlugCounters(plug, types, what, button) {
  if (button) { button.disabled = true; button.classList.add('busy'); }
  withPin('Reset ' + what + ' on ' + plug.name, 'That running total starts again from zero. Readings already recorded here are kept.', function (pin) {
    return post('plug-reset', {name: plug.name, types: types, pin: pin}).then(function (r) { return r.message || 'done'; });
  }, true);
  setTimeout(function () { if (button) { button.disabled = false; button.classList.remove('busy'); } renderPlugControls(STATE.status); }, 3000);
}
// The Smart Plugs card: one compact line per socket - name, state, its
// current draw, and switch / pulse - and a fold under each for the counters
// and their resets, closed by default. Two dozen sockets read as a list,
// not a scroll. What is open stays open for the session.
var PLUGCTL_OPEN = {};
try { PLUGCTL_OPEN = JSON.parse(sessionStorage.getItem('zigmon-plugctl') || '{}') || {}; } catch (e) {}
function renderPlugControls(st) {
  var card = $('plug-control'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  var host = $('plug-control-list'); host.innerHTML = '';
  var bar = el('div', 'btnrow'); bar.style.marginBottom = '8px';
  var anyOpen = plugs.some(function (p) { return PLUGCTL_OPEN[p.name]; });
  var foldAll = cmdButton(anyOpen ? 'Fold every socket' : 'Open every socket', anyOpen ? 'up' : 'down', 'small');
  foldAll.classList.remove('needs-unlock');
  foldAll.title = 'Show or hide every socket\u2019s details and counters at once';
  foldAll.onclick = function () { plugs.forEach(function (p) { PLUGCTL_OPEN[p.name] = !anyOpen; }); rememberPlugCtl(); forgetSig('plugcontrols'); renderPlugControls(st); };
  bar.appendChild(foldAll); host.appendChild(bar);
  devicesSorted(plugs.map(function (p) { return Object.assign({source: 'plug'}, p); })).forEach(function (plug) {
    var on = plug.output === 1, online = plug.online && !plug.stale;
    var info = plug.info || {};
    var open = !!PLUGCTL_OPEN[plug.name];
    var block = el('div', 'pc-block' + (open ? ' open' : ''));
    attachCardMenu(block, {head: plug.name, rows: [
      ['\ud83d\udcc8 History for this socket', function () { showTab('history'); setTimeout(function () { pickHistoryDevice('plug:' + plug.name); }, 80); }],
      ['\u26a1 A rule from this socket', function () { showTab('control'); setTimeout(function () { showControlSection('automation'); newRuleFor('plug:' + plug.name); }, 120); }],
      ['\ud83d\udd0c Its own web page', function () { if (plug.host) window.open('http://' + String(plug.host).split(':')[0], '_blank'); }],
      ['\ud83e\ude7a Why is it not working?', function () {
        withPin('Look into ' + plug.name, 'Nothing is switched; it only asks.', function (pin) {
          return post('plug-diagnose', {pin: pin, name: plug.name}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'could not');
            showDiagnosis(r);
            return r.verdict;
          });
        });
      }],
      ['\ud83d\udccb Copy its name', function () { copyToClipboard(plug.name, 'Name'); }],
      plug.host ? ['\ud83d\udccb Copy its address', function () { copyToClipboard(plug.host, 'Address'); }] : null
    ]});
    var line = el('div', 'pc-line');
    var fold = el('span', 'fold', open ? '\u25be' : '\u25b8');
    var name = el('span', 'pc-name', deviceIcon(plug) + ' ' + plug.name);
    var state = el('span', 'tag ' + (online ? (on ? 'ok' : 'dim') : (plug.optional ? 'dim' : 'crit')), online ? (on ? 'on' : 'off') : (plug.optional ? 'unplugged' : 'unreachable'));
    var watts = ((plug.values || {})['switch.apower'] || {}).value;
    var draw = el('span', 'pc-draw', online && isNum(watts) ? fmt(watts, watts < 10 ? 1 : 0) + ' W' : '');
    var left = el('span', 'pc-left'); left.appendChild(fold); left.appendChild(name); left.appendChild(state); left.appendChild(draw);
    if (plug.monitor_only) { var mo = el('span', 'dim', '\ud83d\udc41 monitor-only'); mo.title = 'Watched, recorded and charted; switching from the dashboard, bindings, rules and scenes is refused. Change it under Plugs and sensors \u2192 State.'; left.appendChild(mo); }
    left.onclick = function () { PLUGCTL_OPEN[plug.name] = !PLUGCTL_OPEN[plug.name]; rememberPlugCtl(); forgetSig('plugcontrols'); renderPlugControls(st); };
    line.appendChild(left);
    var row = el('span', 'pc-btns');
    if (!plug.monitor_only) {
      var toggle = cmdButton(on ? 'Off' : 'On', 'power', 'small ' + (on ? 'danger' : 'primary'));
      toggle.disabled = !online;
      attachReadings(toggle, function () { return plug.name; }, function () { return 'switch.apower'; });
      toggle.title = on ? 'Switch the socket off \u2014 cuts power to whatever is plugged in' : 'Switch the socket on';
      attachHint(toggle, '<b>Switch.Set ' + (on ? 'off' : 'on') + '</b><br>' + (on ? 'Cuts power to everything plugged into this socket.' : 'Restores power to the socket.') + '<br>Asks for the PIN.');
      toggle.onclick = function () { switchPlug(plug, !on, toggle); };
      row.appendChild(toggle);
      var secs = ((st.pulse_ms || {}).default || 5000) / 1000;
      var pulse = cmdButton('Pulse ' + secs + ' s', 'reboot', 'small');
      pulse.disabled = !online || (st.pulsing || []).indexOf(plug.name) >= 0;
      pulse.title = on ? 'Cut power for ' + secs + ' s, then back on \u2014 a power-cycle' : 'Power the socket for ' + secs + ' s, then off again';
      attachHint(pulse, '<b>Switch.Set ' + (on ? 'off' : 'on') + '</b>, wait, <b>Switch.Set ' + (on ? 'on' : 'off') + '</b><br>' + (on ? 'Cuts power briefly - a power-cycle for whatever is plugged in.' : 'Powers the socket briefly and switches it off again.') + '<br>Asks for the PIN.');
      pulse.onclick = function () {
        pulse.disabled = true; pulse.classList.add('busy');
        withPin('Pulse ' + plug.name, (on ? '<b>Power is cut for ' : 'Power is on for ') + secs + ' s</b>, then the socket goes back to ' + (on ? 'on' : 'off') + '.', function (pin) {
          return post('plug-switch', {name: plug.name, pulse: true, ms: (st.pulse_ms || {}).default || 5000, pin: pin}).then(function (r) { return r.message || 'done'; });
        }, on);
        setTimeout(function () { pulse.disabled = false; pulse.classList.remove('busy'); }, 3000);
      };
      row.appendChild(pulse);
    }
    line.appendChild(row);
    block.appendChild(line);
    // the fold: what the box is, and its counters with their resets
    var body = el('div', 'pc-body');
    body.appendChild(el('p', 'btnhelp', plug.stale
      ? 'The plug last answered ' + ago(plug.generated) + ': ' + (plug.error || 'no answer') + '. Controls are disabled until it responds.'
      : online ? [info.model, info.app ? info.app + ' ' + (info.ver || '') : '', plug.host].filter(Boolean).join(' \u00b7 ')
              : 'The plug is not answering: ' + (plug.error || 'unknown reason')));
    var counters = (plug.counters || []).filter(function (c) { return c.value !== null && c.value !== undefined; });
    if (counters.length && online) {
      body.appendChild(el('div', 'set-head', 'Reset a counter'));
      body.appendChild(el('p', 'btnhelp', "The plug's own running totals, the same ones its web interface lists. Resetting one starts it from zero; the history recorded here is untouched."));
      var crow = el('div', 'btnrow');
      counters.forEach(function (c) {
        var b = cmdButton(c.label + ' \u00b7 ' + counterText(c.type, c.value), 'reset', 'small');
        b.disabled = c.value === 0;
        attachHint(b, '<b>Switch.ResetCounters</b> {"type": ["' + c.type + '"]}<br>' + c.help + '.<br>'
          + (c.reset_at ? counterSince(c).replace(/^./, function (x) { return x.toUpperCase(); }) : 'Never reset from here, and the plug does not say when it was.')
          + (c.value === 0 ? '<br><em>Already at zero.</em>' : ''));
        b.onclick = function () { resetPlugCounters(plug, [c.type], c.label.toLowerCase(), b); };
        crow.appendChild(b);
      });
      var all = cmdButton('All counters', 'trash', 'small danger');
      attachHint(all, '<b>Switch.ResetCounters</b><br>Every counter above, back to zero in one go.');
      all.onclick = function () { resetPlugCounters(plug, [], 'every counter', all); };
      crow.appendChild(all);
      body.appendChild(crow);
    }
    block.appendChild(body);
    host.appendChild(block);
  });
}
function rememberPlugCtl() { try { sessionStorage.setItem('zigmon-plugctl', JSON.stringify(PLUGCTL_OPEN)); } catch (e) {} }

// ---- plugs and sensors managed from here -------------------------------------------
// The daemon keeps one entry per relay channel (that is what a plug is to it:
// a name, an address, a switch id). The editor shows one DEVICE per address
// with its channels underneath: address, password and the device state are
// entered once; Detect asks the box how many relays it has and lays them out.
var MANAGED = { rows: null, dirty: false };
function managedRows(st) {
  var out = [];
  ['plugs', 'sensors'].forEach(function (kind) {
    ((st && st.managed && st.managed[kind]) || []).forEach(function (e) {
      out.push(Object.assign({kind: kind === 'plugs' ? 'plug' : 'sensor', password: ''}, e));
    });
  });
  return out;
}
function markManaged() { MANAGED.dirty = true; $('managed-note').textContent = 'Unsaved changes'; }
// group channel entries into devices: same kind + address (a fresh, address-less row stays alone)
function managedDevices(rows) {
  var devices = [], byKey = {};
  rows.forEach(function (e, i) {
    var key = e.kind + '|' + (e.host || ('#' + i)) + '|' + e.source;
    if (!byKey[key]) { byKey[key] = {kind: e.kind, host: e.host, source: e.source, channels: [], model: e.model || '', mac: e.mac || '',
      host_state: e.host_state || 'enabled', password_set: !!e.password_set, password: e.password || ''}; devices.push(byKey[key]); }
    var dev = byKey[key];
    dev.channels.push(e);
    if (e.model && !dev.model) dev.model = e.model;
    if (e.mac && !dev.mac) dev.mac = e.mac;
    if (e.password) dev.password = e.password;
    if (e.password_set) dev.password_set = true;
    if (e.host_state && e.host_state !== 'enabled') dev.host_state = e.host_state;
  });
  devices.forEach(function (dv) { dv.channels.sort(function (a, b) { return (a.switch_id || 0) - (b.switch_id || 0); }); });
  return devices;
}
function stateValue(e) { return e.enabled === false ? '0' : (e.monitor_only ? 'm' : '1'); }
function stateOptions(device) {
  var out = [['1', withIcon('enabled', 'enabled')]];
  if (device) out.push(['o', withIcon('enabled', 'enabled, may be unplugged')]);
  return out.concat([['m', withIcon('monitor', 'monitor only')], ['0', withIcon('disabled', 'disabled')]]);
}
function hostStateValue(hs) { return hs === 'monitor' ? 'm' : (hs === 'disabled' ? '0' : (hs === 'optional' ? 'o' : '1')); }
// ---- What each Zigbee device was told to report -----------------------------
// What is actually written down about one device, shown when its row is
// opened: not a summary but the thing itself, since the point of the card is
// to answer "what does it think it knows about this sensor".
function bindingDetail(r) {
  var d = r.detail || {}, box = el('div', 'binddetail-in');
  var line = function (label, value) {
    if (value === '' || value === null || value === undefined) return;
    var p = el('div', 'bindline');
    p.appendChild(el('span', 'bindlabel', label));
    p.appendChild(el('span', 'bindvalue', value));
    box.appendChild(p);
  };
  line('address', r.ieee);
  line('made by', [d.maker, d.model_id].filter(Boolean).join(' '));
  line('kind', [d.kind, d.powered].filter(Boolean).join(', '));
  if (d.firmware) line('firmware', d.firmware);
  line('bindings', (d.bind_list || []).length
    ? (d.bind_list || []).join(', ') : 'none \u2014 nothing reports to the coordinator');
  line('reporting', (d.report_list || []).length
    ? (d.report_list || []).map(function (x) {
        return x.at + (x.every ? ' every ' + (x.every >= 3600 ? Math.round(x.every / 3600) + ' h'
                                              : Math.round(x.every / 60) + ' min') : '');
      }).join('; ')
    : 'none \u2014 it was never told how often to speak');
  line('clusters', (d.clusters || []).join(', '));
  line('written down', d.written ? ago(d.written) : '\u2014');
  return box;
}

function configureOne(name, item) {
  withPin('Set up ' + name + ' again',
    (item && item.battery)
      ? 'A sleeping sensor is awake for a second or two after it reports and deaf the rest of the time, '
        + 'so press this while it is awake \u2014 or wake it first. The daemon is also waiting to do it by '
        + 'itself the moment the sensor next speaks.'
      : 'Zigbee2MQTT is asked to configure it again. Whether it takes is written in the events.',
    function (pin) {
      return post('zigbee-configure', {device: name, pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        BINDINGS.at = 0;
        return r.message;
      });
    });
}

function forgetBinding(name) {
  withPin('Forget what is written down about ' + name,
    'Only what this daemon remembers is dropped \u2014 nothing on the device or in Zigbee2MQTT is touched. '
    + 'It comes back the next time the bridge sends its list, which is the way to clear a stale row.',
    function (pin) {
      return post('zigbee-forget', {device: name, pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        BINDINGS.at = 0;
        setTimeout(function () { loadBindings(true); }, 400);
        return r.message;
      });
    });
}

var BINDINGS = {rows: null, at: 0, busy: false};
function loadBindings(force) {
  if (BINDINGS.busy) return;
  if (!force && BINDINGS.at && Date.now() - BINDINGS.at < 60000) { paintBindings(); return; }
  BINDINGS.busy = true;
  api('zigbee-bindings').then(function (r) {
    BINDINGS.busy = false; BINDINGS.at = Date.now(); BINDINGS.rows = r || {};
    paintBindings();
  }, function () { BINDINGS.busy = false; });
}
function paintBindings() {
  var card = $('binding-card'), host = $('binding-list'), trouble = $('binding-trouble');
  if (!card) return;
  var data = BINDINGS.rows || {}, rows = data.devices || [];
  card.hidden = !rows.length;
  if (!rows.length) return;
  var every = function (s) {
    if (!s) return '\u2014';
    return s >= 3600 ? Math.round(s / 3600) + ' h' : Math.round(s / 60) + ' min';
  };
  var suspectOf = {};
  (data.suspect || []).forEach(function (x) { suspectOf[x.ieee] = x; });
  host.innerHTML = '';
  var table = el('table', 'tbl bindtbl');
  table.innerHTML = '<thead><tr><th></th><th>Device</th><th>Model</th><th class="r">Bindings</th>'
    + '<th class="r">Reporting</th><th>Every</th><th>Last heard</th><th></th></tr></thead>';
  var body = el('tbody');
  rows.forEach(function (r) {
    var bad = suspectOf[r.ieee] && !suspectOf[r.ieee].excused;
    var tr = el('tr', 'bindrow' + (bad ? ' bindrow-bad' : (!r.binds && !r.reports ? ' dim' : '')));
    tr.innerHTML = '<td class="bindmark">'
      + (bad ? iconMarkup('cancel', 13) : (r.binds || r.reports ? iconMarkup('check', 13) : ''))
      + '</td><td>' + esc(r.name) + '</td><td>' + esc(r.model || '') + '</td><td class="r">' + r.binds
      + '</td><td class="r">' + r.reports + '</td><td>' + every(r.every) + '</td><td>'
      + (r.last_seen ? ago(r.last_seen) : '\u2014') + '</td>';
    // the buttons live in their own cell so a click on the row opens it and a
    // click on a button does only what the button says
    var acts = el('td', 'bindacts');
    var open = iconButton('down', 'What is written down about this one');
    var again = iconButton('upload', 'Set it up again \u2014 a sleeping sensor has to be awake for it to take');
    var drop = iconButton('trash', 'Forget what is written down about it. It comes back with the bridge\u2019s next list');
    drop.classList.add('danger');
    again.onclick = function (e) { e.stopPropagation(); configureOne(r.name, suspectOf[r.ieee]); };
    drop.onclick = function (e) { e.stopPropagation(); forgetBinding(r.name); };
    acts.appendChild(open); acts.appendChild(again); acts.appendChild(drop);
    tr.appendChild(acts);
    var detail = el('tr', 'binddetail');
    detail.hidden = true;
    var cell = el('td');
    cell.colSpan = 8;
    cell.appendChild(bindingDetail(r));
    detail.appendChild(cell);
    var toggle = function (e) {
      if (e) e.stopPropagation();
      detail.hidden = !detail.hidden;
      setButtonIcon(open, detail.hidden ? 'down' : 'up');
    };
    open.onclick = toggle;
    tr.onclick = toggle;
    body.appendChild(tr); body.appendChild(detail);
  });
  table.appendChild(body);
  host.appendChild(table);
  var bar = el('div', 'btnrow');
  bar.style.marginTop = '10px';
  var reload = cmdButton('Ask the bridge again', 'reset', 'small');
  reload.onclick = function () {
    withPin('Ask the bridge for its device list again',
      'Zigbee2MQTT keeps the list on the broker, so this brings the whole of it back at once. '
      + 'Nothing is changed on any device.', function (pin) {
        return post('zigbee-reload', {pin: pin}).then(function (r) {
          if (!r.ok) throw new Error(r.error || 'could not');
          BINDINGS.at = 0;
          setTimeout(function () { loadBindings(true); }, 1500);
          return r.message;
        });
      });
  };
  bar.appendChild(reload);
  host.appendChild(bar);
  trouble.innerHTML = '';
  var suspect = (data.suspect || []).filter(function (x) { return !x.excused; });
  var excused = (data.suspect || []).filter(function (x) { return x.excused; });
  if (!suspect.length) {
    var fine = el('p', 'muted small');
    fine.innerHTML = iconMarkup('check', 13) + ' every device still has what it was configured with';
    trouble.appendChild(fine);
  }
  suspect.forEach(function (item) {
    var box = el('div', 'bindbad');
    box.appendChild(el('div', 'bindname', item.name));
    box.appendChild(el('div', 'muted small', item.why.join('; ')));
    var row = el('div', 'btnrow');
    row.style.marginTop = '8px';
    var go = cmdButton('Set it up again', 'upload', 'small');
    go.onclick = function () {
      withPin('Set up ' + item.name + ' again',
        item.battery
          ? 'A sleeping sensor is awake for a second or two after it reports and deaf the rest of the '
            + 'time, so press this while it is awake \u2014 or wake it first: press its button, or take the '
            + 'battery out and back. The daemon is also waiting to do this by itself the moment the '
            + 'sensor next speaks.'
          : 'It is mains powered, so it can be set up again at any time.',
        function (pin) {
          return post('zigbee-configure', {device: item.name, pin: pin}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'could not');
            BINDINGS.at = 0;
            return r.message;
          });
        });
    };
    row.appendChild(go);
    if (item.battery) row.appendChild(el('span', 'muted small',
      'waiting for it to speak \u2014 it will be asked automatically'));
    box.appendChild(row);
    trouble.appendChild(box);
  });
  var mem = $('binding-remembered');
  var remembered = data.remembered || {};
  var keys = Object.keys(remembered);
  mem.innerHTML = '';
  if (keys.length) {
    mem.appendChild(el('div', '', 'Remembered shapes: ' + keys.map(function (k) {
      var r = remembered[k];
      return k + ' (' + (r.shape.binds || []).length + ' bindings, from ' + r.from + ')';
    }).join(' \u00b7 ')));
  }
  if (excused.length) {
    trouble.appendChild(el('p', 'muted small', 'nothing configured, and right to be: '
      + excused.map(function (x) { return x.name + ' (' + x.excused + ')'; }).join(', ')));
  }
}

function renderManaged(st) {
  if (MANAGED.rows === null || !MANAGED.dirty) MANAGED.rows = managedRows(st);
  var host = $('managed-list'); host.innerHTML = '';
  if (!MANAGED.rows.length) host.appendChild(el('div', 'muted small', 'No plug or sensor yet. Add one, or let the daemon look for them.'));
  var devices = managedDevices(MANAGED.rows);
  var fromCfg = devices.filter(function (d) { return d.source === 'config'; }), fromUi = devices.filter(function (d) { return d.source !== 'config'; });
  if (fromCfg.length) {
    host.appendChild(el('div', 'managed-sub', 'From config.json \u2014 read-only here'));
    fromCfg.forEach(function (dv) { host.appendChild(deviceBlock(dv)); });
  }
  if (fromUi.length || fromCfg.length) host.appendChild(el('div', 'managed-sub', 'Managed on this dashboard'));
  if (fromUi.length) fromUi.forEach(function (dv) {
    var block = deviceBlock(dv);
    // a device moves with all its channels; the config.json ones above stay put
    makeRowSortable(block, host, MANAGED, markManaged, function () { renderManaged(STATE.status); }, dv.channels);
    host.appendChild(block);
  });
  else if (fromCfg.length) host.appendChild(el('div', 'muted small', 'Nothing yet \u2014 Add plug, Add sensor, or Find Shelly devices.'));
  if (fromUi.length) sectionise(host, MANAGED, 'managed', markManaged, function () { renderManaged(STATE.status); });

  function deviceBlock(dv) {
    var fromConfig = dv.source === 'config', isPlug = dv.kind === 'plug';
    var block = el('div', 'mdev' + (dv.host_state === 'disabled' ? ' off' : ''));
    if (dv.host_state === 'optional') block.title = 'May be unplugged: silence while it is off is expected';
    // -- device line: type, address, password, what it is, state, detect, remove --
    var line = el('div', 'mdev-line');
    var kind = el('select'); fillSelect(kind, [['plug', withIcon('plug', 'plug')], ['sensor', withIcon('sensor', 'sensor')]], dv.kind); kind.disabled = fromConfig;
    kind.onchange = function () { dv.channels.forEach(function (e) { e.kind = kind.value; }); markManaged(); renderManaged(STATE.status); };
    var addr = el('input'); addr.value = dv.host || ''; addr.placeholder = '172.16.16.14'; addr.disabled = fromConfig;
    addr.oninput = function () { dv.host = addr.value; dv.channels.forEach(function (e) { e.host = addr.value; }); markManaged(); };
    var pw = el('input'); pw.type = 'password'; pw.autocomplete = 'new-password'; pw.disabled = fromConfig;
    pw.placeholder = fromConfig ? (dv.password_set ? 'set in config.json' : 'none') : (dv.password_set ? '(kept)' : 'none');
    pw.oninput = function () { dv.password = pw.value; dv.channels.forEach(function (e) { e.password = pw.value; }); markManaged(); };
    var what = el('div', 'mdev-what');
    what.innerHTML = dv.model ? esc(dv.model) + (dv.mac ? ' <span class="mono dim">' + esc(dv.mac) + '</span>' : '')
      : '<span class="dim">' + (isPlug ? 'model unknown \u2014 Detect' : 'sensor') + '</span>';
    var hs = el('select'); fillSelect(hs, stateOptions(true), hostStateValue(dv.host_state)); hs.disabled = fromConfig;
    hs.title = 'The whole device. Monitor only / disabled here overrides every channel; enabled lets each channel decide. "May be unplugged": works like enabled, but the box is expected to lose power now and then (a lamp on a switched outlet) - while it is off nothing is alerted or notified, and it picks up by itself the moment it answers again.';
    hs.onchange = function () {
      var v = hs.value === 'm' ? 'monitor' : (hs.value === '0' ? 'disabled' : (hs.value === 'o' ? 'optional' : 'enabled'));
      dv.channels.forEach(function (e) {
        e.host_state = v;
        if (v === 'enabled' || v === 'optional') {           // back to each channel's own choice
          if (e.own_enabled !== undefined) e.enabled = e.own_enabled;
          if (e.own_monitor_only !== undefined) e.monitor_only = e.own_monitor_only;
        }
      });
      markManaged(); renderManaged(STATE.status);
    };
    var detect = cmdButton('Detect', 'search', 'small'); detect.classList.remove('needs-unlock'); detect.disabled = fromConfig || !isPlug;
    attachHint(detect, '<b>Shelly.GetDeviceInfo</b> + <b>Shelly.GetStatus</b> from the server to this address.<br>Reads the model and how many relays the device has, and lays out one channel row per relay with the names the device itself uses. Asks for the PIN.');
    detect.onclick = function () {
      if (!addr.value) { toast('Address first', false); return; }
      detect.disabled = true; detect.classList.add('busy');
      detectDevice(dv, addr.value, dv.password);
      setTimeout(function () { detect.disabled = false; detect.classList.remove('busy'); }, 3000);
    };
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock'); del.disabled = fromConfig;
    del.title = fromConfig ? 'Defined in config.json' : 'Remove the device and all its channels';
    del.onclick = function () { MANAGED.rows = MANAGED.rows.filter(function (e) { return dv.channels.indexOf(e) < 0; }); markManaged(); renderManaged(STATE.status); };
    [kind, addr, pw, what, hs, detect, del].forEach(function (x) { line.appendChild(x); });
    block.appendChild(line);
    // -- channel lines --
    var chans = el('div', 'mdev-chans');
    var head = el('div', 'mchan mchan-head');
    (isPlug ? ['Relay', 'Name', 'MQTT prefix', 'What it is', 'State', '', '']
            : ['', 'Name', 'MQTT prefix', 'What it is', 'State', '', '']).forEach(function (t) { head.appendChild(el('span', '', t)); });
    chans.appendChild(head);
    dv.channels.forEach(function (e) { chans.appendChild(channelLine(dv, e, fromConfig)); });
    if (isPlug && !fromConfig) {
      var addCh = cmdButton('Add channel', 'add', 'small'); addCh.classList.remove('needs-unlock'); addCh.title = 'One more relay on this device (Detect does this for you)';
      addCh.onclick = function () {
        var next = dv.channels.length ? Math.max.apply(null, dv.channels.map(function (c) { return c.switch_id || 0; })) + 1 : 0;
        MANAGED.rows.push({kind: 'plug', name: '', host: dv.host, password: dv.password, switch_id: next, mqtt_name: dv.channels[0] ? dv.channels[0].mqtt_name : '',
          source: 'ui', host_state: dv.host_state, model: dv.model, mac: dv.mac, enabled: true, monitor_only: false,
          role: dv.channels[0] ? (dv.channels[0].role || 'plug') : 'plug'});
        markManaged(); renderManaged(STATE.status);
      };
      var addRow = el('div', 'mchan-add'); addRow.appendChild(addCh); chans.appendChild(addRow);
    }
    block.appendChild(chans);
    if (isPlug && !fromConfig) block.appendChild(mqttStrip(dv));
    return block;
  }
  // MQTT for a box: one switch for the device. On, zigmon sends its commands
  // (switch, pulse, reboot, reset) as RPC over the broker instead of HTTP -
  // one publish, no TCP connection, from anywhere the broker is reachable -
  // and still reads the box's pushes as before. "Set the box up" writes the
  // broker into the box itself (MQTT.SetConfig) so nothing has to be typed
  // into its web page.
  function mqttStrip(dv) {
    var st = STATE.status || {}, first = dv.channels[0] || {};
    var strip = el('div', 'mqtt-strip');
    var on = !!first.mqtt;
    var sw = makeSwitch(on, function (v) { dv.channels.forEach(function (e) { e.mqtt = v; }); markManaged(); renderManaged(STATE.status); },
                        {small: true, title: 'Commands over MQTT (RPC over the broker) instead of HTTP'});
    strip.appendChild(sw);
    strip.appendChild(el('span', 'lbl', 'MQTT'));
    var mfp0 = st.mqtt_for_plugs || {};
    var suggested = (mfp0.root ? mfp0.root + '/' : '') + String((first.name || dv.name || dv.host || 'box')).toLowerCase().replace(/[^a-z0-9_-]+/g, '-');
    // One box, one prefix. Where the rows disagree - four channels each given
    // a name of their own, which only one of them can be right about - the
    // longest common start is what they were reaching for, and typing here
    // settles it for all four.
    var names = dv.channels.map(function (e) { return String(e.mqtt_name || ''); }).filter(Boolean);
    var agreed = names.length ? names.reduce(function (a, b) {
      var i = 0;
      while (i < a.length && i < b.length && a[i] === b[i]) i++;
      return a.slice(0, i);
    }) : '';
    var split = names.length > 1 && names.some(function (n) { return n !== names[0]; });
    var prefix = el('input');
    prefix.value = split ? agreed.replace(/[-_/]+$/, '') : (first.mqtt_name || '');
    prefix.placeholder = suggested;
    prefix.title = 'The box\'s MQTT prefix (Settings \u2192 MQTT \u2192 MQTT prefix). Commands go to <prefix>/rpc. Under ' + (mfp0.root || 'a common root') + '/ so one ACL line covers every box; blank uses the suggestion.';
    prefix.oninput = function () { dv.channels.forEach(function (e) { e.mqtt_name = prefix.value; }); markManaged(); };
    strip.appendChild(prefix);
    if (split) {
      // say it, rather than quietly showing one of the four
      var muddle = el('span', 'mqtt-warn', '\u26a0 its sockets have ' + names.length
        + ' different prefixes; a box publishes under one. Save devices writes this one to all of them.');
      muddle.title = names.join(', ');
      strip.appendChild(muddle);
      dv.channels.forEach(function (e) { e.mqtt_name = prefix.value; });
    }
    var mfp = st.mqtt_for_plugs || {};
    // the connection type, in the words the box's own page uses
    var tls = el('select'); fillSelect(tls, [['nocheck', 'TLS, no validation'], ['ca', 'TLS, CA on the box (ca.pem)'], ['none', 'No TLS']], mfp.tls ? 'nocheck' : 'none');
    tls.title = 'How the box connects. "TLS, no validation" is what the box offers by default with a TLS broker (encrypted, the certificate not checked); "CA on the box" checks it against a ca.pem uploaded to the box; "No TLS" is the plain 1883 port.';
    var server = el('input'); server.value = mfp.server || ''; server.placeholder = 'broker:8883'; server.title = 'The broker the box should talk to: host:8883 for TLS, host:1883 plain';
    tls.onchange = function () {
      var h = (server.value || mfp.server || '').replace(/:\d+$/, '');
      server.value = h + (tls.value === 'none' ? ':1883' : ':8883');
    };
    strip.appendChild(tls);
    var user = el('input'); user.value = first.mqtt_user || ''; user.placeholder = mfp.user || 'username';
    user.title = 'The broker account this box logs in with. Blank uses ' + (mfp.user ? '\u201c' + mfp.user + '\u201d from the configuration' : 'the one in the configuration') + '.';
    user.oninput = function () { dv.channels.forEach(function (e) { e.mqtt_user = user.value; }); markManaged(); };
    var mine = !!first.mqtt_has_password;
    var pass = el('input'); pass.type = 'password'; pass.autocomplete = 'off';
    pass.name = 'zigmon-broker-pass-' + (first.name || dv.host || '');   // a browser's password manager must not fill this
    pass.placeholder = mine ? '(kept)' : (mfp.has_password ? '(from the configuration)' : 'password');
    pass.title = mine ? 'This box\'s own broker password is kept here. Leave it blank to keep it, or type another to replace it.'
      : (mfp.has_password ? 'This box has none of its own; the one in the configuration is used. Type one here to give this box its own.'
                          : 'The broker password this box logs in with. It is kept with this box, not shared.');
    pass.oninput = function () { dv.channels.forEach(function (e) { e.mqtt_password = pass.value; }); markManaged(); };
    var setup = cmdButton(on ? 'Set the box up' : 'Switch MQTT off on the box', on ? 'upload' : 'cancel', 'small');
    setup.title = on
      ? 'Write this broker, prefix and the RPC-over-MQTT switches into the box (MQTT.SetConfig), then restart it'
      : 'Tell the box itself to stop using the broker. Turning the switch off here only stops us using it; '
        + 'the box goes on logging in and publishing to nobody until it is told otherwise.';
    setup.onclick = function () {
      if (!on) {
        withPin('Switch MQTT off on ' + (dv.name || dv.host),
                'The box is told to stop using the broker (MQTT.SetConfig enable false) and restarted. '
                + 'Nothing here is changed \u2014 this is the box\u2019s own setting.', function (pin) {
          return post('plug-mqtt-setup', {host: dv.host, password: dv.password || '', off: true, pin: pin})
            .then(function (r) { if (!r.ok) throw new Error(r.error || 'could not'); return r.message; });
        });
        return;
      }
      withPin('Set ' + (dv.name || dv.host) + ' up for MQTT', 'The box gets the broker <b>' + esc(server.value) + '</b>, prefix <b>' + esc(prefix.value) + '</b>, RPC over MQTT and status notifications on, and restarts.', function (pin) {
        var pfx = prefix.value.trim() || suggested;
        if (!prefix.value.trim()) { prefix.value = pfx; dv.channels.forEach(function (e) { e.mqtt_name = pfx; }); markManaged(); }
        return post('plug-mqtt-setup', {host: dv.host, password: dv.password || '', server: server.value, user: user.value, pass: pass.value, prefix: pfx, tls: tls.value, pin: pin})
          .then(function (r) { if (!r.ok) throw new Error(r.error || 'could not'); return r.message || 'box set up'; });
      });
    };
    tls.disabled = !on;
    var probe = cmdButton('Test MQTT', 'search', 'small'); probe.classList.remove('needs-unlock');
    probe.title = 'Ask the box over the broker and wait for its answer \u2014 says whether the topic, the box\'s RPC-over-MQTT switch and the broker\'s ACL all line up';
    probe.onclick = function () {
      probe.disabled = true; probe.classList.add('busy');
      post('plug-mqtt-test', {name: (first.name || ''), prefix: prefix.value.trim() || suggested})
        .then(function (r) { toast(r.ok ? (r.message || 'the box answered') : (r.error || 'no answer'), !!r.ok); },
              function (e) { toast(String(e.message || e), false); })
        .then(function () { probe.disabled = false; probe.classList.remove('busy'); });
    };
    [server, user, pass].forEach(function (x) { x.disabled = !on; strip.appendChild(x); });
    if (mine) {
      var forget = el('button', 'btn small iconbtn needs-unlock'); forget.type = 'button'; forget.innerHTML = iconMarkup('trash', 13);
      forget.title = 'Forget this box\u2019s broker password (Save devices writes it)'; forget.disabled = !on;
      forget.onclick = function () {
        dv.channels.forEach(function (e) { e.mqtt_password = ''; e.clear_mqtt_password = true; });
        markManaged(); renderManaged(STATE.status);
        toast('Cleared \u2014 Save devices to write it', true);
      };
      strip.appendChild(forget);
    }
    // With the switch off, setting up is off too - but telling the box to
    // stop is exactly what one wants then, so that button stays alive.
    probe.disabled = !on;
    strip.appendChild(setup);
    strip.appendChild(probe);
    var only = !!((st.runtime_config || {}).mqtt_only || {}).value;
    strip.appendChild(el('span', 'muted small', on ? (only ? 'commands go over the broker only \u2014 no HTTP fallback'
                                                           : 'commands go over the broker; HTTP is the fallback')
                                                   : 'commands go over HTTP'));
    return strip;
  }
  function channelLine(dv, e, fromConfig) {
    var row = el('div', 'mchan' + (e.enabled === false || dv.host_state === 'disabled' ? ' off' : ''));
    var relay = el('span', 'mono', dv.kind === 'plug' ? '#' + (e.switch_id || 0) : '');
    var name = el('input'); name.value = e.name || ''; name.placeholder = dv.kind === 'plug' ? 'Lednice' : 'Chodba'; name.disabled = fromConfig;
    name.oninput = function () { e.name = name.value; markManaged(); };
    var mq = el('input'); mq.value = e.mqtt_name || ''; mq.placeholder = 'shellies/\u2026'; mq.disabled = fromConfig; mq.title = 'The device\'s shellies/<name> prefix if it also publishes over MQTT, so it is not recorded twice';
    mq.oninput = function () { e.mqtt_name = mq.value; markManaged(); };
    if (dv.kind === 'plug' && !fromConfig) {
      // one prefix per box, edited in the MQTT strip below; here it is read-only so the column still lines up
      mq.readOnly = true; mq.classList.add('dim'); mq.title = 'The box\'s MQTT prefix \u2014 set it in the MQTT strip below (one for the whole box)';
    }
    // A light is a plug in every way that matters; it is listed apart in the
    // energy table, where a hall light next to a workshop PC says nothing.
    var role = el('select');
    fillSelect(role, [['plug', withIcon('plug', 'a socket')], ['light', withIcon('light', 'a light')]], e.role === 'light' ? 'light' : 'plug');
    role.disabled = fromConfig || dv.kind !== 'plug';
    role.title = 'Lights are switched, bound and recorded exactly like a socket; in the energy table they get a section of their own, folded away by default.';
    role.onchange = function () { e.role = role.value; markManaged(); };
    var inherited = dv.host_state === 'monitor' || dv.host_state === 'disabled';
    var en = el('select');
    fillSelect(en, stateOptions(), inherited ? (dv.host_state === 'monitor' ? 'm' : '0') : (e.enabled === false ? '0' : (e.own_monitor_only || (e.monitor_only && !inherited) ? 'm' : '1')));
    en.disabled = fromConfig || inherited;
    en.title = inherited ? 'Set by the device state above' : 'This channel only. Disabled: not polled, not controllable, hidden from the lists - its history, bindings and rules stay.';
    en.onchange = function () { e.enabled = en.value !== '0'; e.monitor_only = en.value === 'm'; e.own_enabled = e.enabled; e.own_monitor_only = e.monitor_only; markManaged(); renderManaged(STATE.status); };
    var test = cmdButton('Test', 'check', 'small');
    attachHint(test, '<b>Switch.GetStatus</b> for this relay from the server. Asks for the PIN.');
    test.onclick = function () {
      test.disabled = true; test.classList.add('busy');
      withPin('Test ' + (e.name || e.host), 'The daemon asks the device at <b>' + esc(e.host || '?') + '</b> who it is.', function (pin) {
        return post('managed-test', {host: e.host, password: dv.password || '', pin: pin}).then(function (r) {
          return (r.model || '?') + ' \u00b7 ' + (r.app || '') + ' ' + (r.ver || '') + (r.auth && !dv.password && !dv.password_set ? ' \u00b7 needs a password' : '') + ' \u00b7 ' + (r.kind === 'plug' ? 'has a switch' : 'no switch, a sensor');
        });
      });
      setTimeout(function () { test.disabled = false; test.classList.remove('busy'); }, 3000);
    };
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock'); del.disabled = fromConfig || dv.channels.length <= 1;
    del.title = dv.channels.length <= 1 ? 'The last channel: remove the device instead' : 'Remove this channel only';
    del.onclick = function () { MANAGED.rows.splice(MANAGED.rows.indexOf(e), 1); markManaged(); renderManaged(STATE.status); };
    [relay, name, mq, role, en, test, del].forEach(function (x) { row.appendChild(x); });
    return row;
  }
  if (!MANAGED.dirty) $('managed-note').textContent = '';
}
// ask the box what it is and lay out its channels; shared by the Detect
// button and by "Find Shelly devices -> Add"
function detectDevice(dv, addr, password, done) {
  withPin('Detect ' + addr, 'The daemon asks the device at <b>' + esc(addr) + '</b> what it is and how many relays it has.', function (pin) {
    return post('plug-detect', {host: addr, password: password || '', pin: pin}).then(function (r) {
      applyDetect(dv, r); markManaged(); renderManaged(STATE.status);
      if (done) done(r);
      var n = (r.channels || []).length;
      var moved = applyDetect.renamed || [];
      return (r.model || '?') + (r.app ? ' \u00b7 ' + r.app : '') + (r.fw ? ' ' + r.fw : '') + ' \u00b7 ' + (n ? n + ' relay' + (n === 1 ? '' : 's') : (r.sensor_like ? 'a sensor' : 'no relay'))
        + (moved.length ? ' \u00b7 renamed ' + moved.join(', ') : '');
    });
  });
}
// merge what Detect found into the device's channel rows
function applyDetect(dv, r) {
  dv.model = r.model || dv.model; dv.mac = r.mac || dv.mac;
  var found = r.channels || [];
  var clean = function (x) { return String(x || '').replace(/[^A-Za-z0-9 _.-]/g, '').trim(); };
  // Detect reads the truth from the box: a relay is named after the device
  // and its own output - PlugX4-TVLoznice-AppleTV - with the MQTT prefix set
  // to the same thing in lower case. A single-relay plug is just the device
  // name; an output the device leaves unnamed falls back to its number.
  var deviceName = clean(r.device_name);
  var byId = {}; dv.channels.forEach(function (e) { byId[e.switch_id || 0] = e; });
  var renamed = [];
  found.forEach(function (ch, idx) {
    var e = byId[ch.id];
    if (!e) {
      e = {kind: 'plug', name: '', host: dv.host, password: dv.password, switch_id: ch.id, mqtt_name: '', source: 'ui', host_state: dv.host_state, enabled: true, monitor_only: false};
      MANAGED.rows.push(e); dv.channels.push(e);
    }
    var part = clean(ch.name);
    var wanted = '';
    if (found.length > 1) {
      if (deviceName || part) wanted = (deviceName || clean(r.app) || 'Plug') + '-' + (part || (idx + 1));
    } else {
      wanted = deviceName || part;
    }
    // a device that names nothing must not overwrite a name someone chose
    if (!wanted) wanted = e.name || (clean(r.app) || 'Plug') + (found.length > 1 ? '-' + (idx + 1) : '');
    if (wanted && e.name !== wanted) {
      if (e.name) renamed.push(e.name + ' \u2192 ' + wanted);
      e.name = wanted;
    }
    e.mqtt_name = wanted.toLowerCase();
    e.model = dv.model; e.mac = dv.mac;
  });
  applyDetect.renamed = renamed;
  // relays the device does not have any more
  var have = {}; found.forEach(function (ch) { have[ch.id] = true; });
  if (found.length) dv.channels.slice().forEach(function (e) { if (!have[e.switch_id || 0] && !e.name) { MANAGED.rows.splice(MANAGED.rows.indexOf(e), 1); } });
  if (r.sensor_like && !found.length) dv.channels.forEach(function (e) { e.kind = 'sensor'; });
  else if (found.length) dv.channels.forEach(function (e) { e.kind = 'plug'; });
}
$('managed-add-plug').onclick = function () {
  MANAGED.rows = MANAGED.rows || [];
  MANAGED.rows.push({kind: 'plug', name: '', host: '', password: '', switch_id: 0, mqtt_name: '', source: 'ui', host_state: 'enabled', enabled: true, monitor_only: false});
  markManaged(); renderManaged(STATE.status);
  var inputs = $('managed-list').querySelectorAll('.mdev:last-child .mdev-line input'); if (inputs[0]) inputs[0].focus();
};
$('managed-add-sensor').onclick = function () {
  MANAGED.rows = MANAGED.rows || []; MANAGED.rows.push({kind: 'sensor', name: '', host: '', password: '', switch_id: 0, mqtt_name: '', source: 'ui', host_state: 'enabled', enabled: true, monitor_only: false});
  markManaged(); renderManaged(STATE.status);
};
$('managed-discover').onclick = function () {
  var b = $('managed-discover'); b.disabled = true; b.classList.add('busy');
  $('managed-found').textContent = 'Asking the network…';
  withPin('Find Shelly devices', 'The daemon sends a multicast DNS query and lists what answers within three seconds. Only this subnet.', function (pin) {
    return post('managed-discover', {pin: pin}).then(function (r) {
      var box = $('managed-found'); box.innerHTML = '';
      if (!r.devices.length) { box.textContent = 'Nothing answered. Devices on other subnets do not; add them by address.'; return 'no answer'; }
      r.devices.forEach(function (dv) {
        var line = el('div'); line.style.margin = '4px 0';
        line.appendChild(el('span', 'mono', dv.ip + '  '));
        var known = dv.known || (MANAGED.rows || []).some(function (e) { return e.host === dv.ip; });
        line.appendChild(el('span', '', dv.names.join(', ') + (known ? ' \u2014 already listed' : '') + ' '));
        if (!known) {
          var add = cmdButton('Add', 'add', 'small');
          add.onclick = function () {
            MANAGED.rows = MANAGED.rows || [];
            var guessSensor = /ht|h&t|temp|humid|flood|door|window|motion|smoke|gas/i.test(dv.names.join()) && !/plug|plus|pro|1pm|2pm|relay|switch/i.test(dv.names.join());
            var row = {kind: guessSensor ? 'sensor' : 'plug', name: (dv.names[0] || dv.ip).replace(/\..*$/, ''), host: dv.ip, password: '', switch_id: 0, mqtt_name: '', source: 'ui', host_state: 'enabled', enabled: true, monitor_only: false};
            MANAGED.rows.push(row);
            markManaged(); renderManaged(STATE.status); line.remove();
            // and ask the box what it really is - relays, names, prefix; a password can be added afterwards
            var dev = managedDevices(MANAGED.rows).filter(function (x) { return x.channels.indexOf(row) >= 0; })[0];
            if (dev) detectDevice(dev, dv.ip, '', function (r) {
              if (r.sensor_like && r.channels && !r.channels.length) toast('Added as a sensor: ' + (r.model || dv.ip), true);
            });
          };
          line.appendChild(add);
        }
        box.appendChild(line);
      });
      return r.devices.length + ' device(s) answered';
    });
  });
  setTimeout(function () { b.disabled = false; b.classList.remove('busy'); }, 4000);
};
$('managed-save').onclick = function () {
  var plugs = [], sensors = [];
  rowsToSave(MANAGED, 'devices').forEach(function (e) {
    // the channel's OWN choice goes to the daemon; the device state is applied there
    var row = {name: e.name, host: e.host, switch_id: e.switch_id || 0, mqtt_name: e.mqtt_name || '', source: e.source || 'ui',
               enabled: e.own_enabled !== undefined ? e.own_enabled !== false : e.enabled !== false,
               monitor_only: e.own_monitor_only !== undefined ? !!e.own_monitor_only : !!e.monitor_only,
               role: e.role === 'light' ? 'light' : 'plug', group: e.group || '', mqtt: !!e.mqtt,
               mqtt_user: e.mqtt_user || '', mqtt_password: e.mqtt_password || '', clear_mqtt_password: !!e.clear_mqtt_password,
               host_state: e.host_state || 'enabled', model: e.model || '', mac: e.mac || ''};
    if (e.password) row.password = e.password;
    (e.kind === 'plug' ? plugs : sensors).push(row);
  });
  withPin('Save devices', 'The daemon starts polling new entries at once and drops removed ones.', function (pin) {
    return post('managed-save', {plugs: plugs, sensors: sensors, pin: pin}).then(function (r) {
      saveGroups('managed', MANAGED);
      MANAGED.dirty = false; MANAGED.rows = null; forgetSig('managed');
      return (r.plugs || []).length + ' plug(s), ' + (r.sensors || []).length + ' sensor(s) saved';
    });
  });
};

// ---- button bindings --------------------------------------------------------------
var BINDINGS = {rows: null, dirty: false};
function bindingDevices(st) {
  // Only devices that can send an action - a button, a remote, a contact with
  // a click - plus anything a saved binding still points at.
  var list = st.devices.filter(function (d) { return d.has_action; });
  var ids = list.map(function (d) { return d.id; });
  (BINDINGS.rows || []).forEach(function (b) {
    var d = b.device && deviceById(b.device);
    if (d && ids.indexOf(d.id) < 0) { list.push(d); ids.push(d.id); }
  });
  return list;
}
function actionOptions(device, current) {
  var opts = device && device.actions ? device.actions.slice() : [];
  if (!opts.length) opts = ['single', 'double', 'triple', 'long', 'hold', 'release'];
  if (current && current !== '*' && opts.indexOf(current) < 0) opts.push(current);
  opts.push('*');
  return opts;
}
// The Control tab fills hundreds of these, each with every device in the
// house: twenty rules times five selects times fifty options is five
// thousand elements to build one at a time. The same list of options comes
// up again and again, so its markup is built once and set in one go - the
// browser parses that far faster than it creates elements.
// Keyed on the list itself, not on a copy of its contents: the editors hand
// the same array to every row, so this is one lookup rather than another
// walk of fifty entries.
var OPTION_HTML = typeof WeakMap === 'function' ? new WeakMap() : null;
// The heading a value belongs under. A socket and a light are different
// things even though both are driven the same way, so they get their own
// headings rather than one that fits neither.
function optionGroup(value, label) {
  var v = String(value);
  if (v === '') return 'Just an answer';                       // a text that only replies
  if (v.indexOf('sys:') === 0) return 'What the house does to itself';
  if (v.indexOf('grp:') === 0) return 'Sensor groups';
  if (v.indexOf('act:') === 0) return 'Action groups';
  if (v.indexOf('zb:') === 0) return 'Zigbee switches';
  if (v.indexOf('heat:') === 0) return 'Heating';
  if (v.indexOf('scene:') === 0) return 'Scenes';
  if (v.indexOf('seq') === 0) return 'Sequences';
  if (v.indexOf('notify') === 0) return 'Notifications';
  if (v.indexOf('who:') === 0) return 'Somebody coming or going';
  if (/^(rule:|sched:|bindgroup:|sgroup:|agroup:)/.test(v)) return 'Automation on and off';
  // "all sockets" belongs among the sockets and "all lights" among the
  // lights, the way one would look for them - not in a heading of their own
  if (v.indexOf('script:') === 0) return 'Little scripts';   // its own heading, not among the sockets
  if (v === '{ip}') return 'An address the press carries';
  if (v === 'tell') return 'Ask it something';
  if (v === '*') return 'Sockets';
  if (v === '*lights') return 'Lights';
  var head = String(label || '');
  if (head.indexOf(ICON.light) === 0) return 'Lights';
  if (head.indexOf(ICON.valve) === 0) return 'Radiator valves';
  if (head.indexOf(ICON.thermo) === 0) return 'Thermometers';
  if (head.indexOf(ICON.motion) === 0) return 'Motion sensors';
  if (head.indexOf(ICON.contact) === 0) return 'Door contacts';
  if (head.indexOf(ICON.button) === 0 || head.indexOf(ICON.knob) === 0) return 'Buttons and knobs';
  if (head.indexOf(ICON.ap) === 0) return 'Wi-Fi';        // before the modem: they share a look
  if (head.indexOf(ICON.modem) === 0) return 'The SMS gateway';
  if (head.indexOf(ICON.router) === 0 || head.indexOf(ICON.coordinator) === 0 || head.indexOf(ICON.gateway) === 0) return 'Gateways';
  return 'Sockets';
}
function optionsMarkup(options) {
  if (OPTION_HTML && OPTION_HTML.has(options)) return OPTION_HTML.get(options);
  var out = '', groups = {}, order = [];
  // Grouped as soon as the list is long enough to be worth it: a device list
  // reads far better as Thermometers / Motion sensors / Buttons than as fifty
  // lines in a row.
  var grouped = options.length > 12;
  for (var i = 0; i < options.length; i++) {
    var o = options[i], value = typeof o === 'string' ? o : o[0], label = typeof o === 'string' ? o : o[1];
    var html = '<option value="' + esc(String(value)) + '">' + esc(String(label)) + '</option>';
    if (!grouped) { out += html; continue; }
    var g = optionGroup(value, label);
    if (groups[g] === undefined) { groups[g] = ''; order.push(g); }   // one heading, however the kinds interleave
    groups[g] += html;
  }
  if (grouped) {
    // a hundred entries read as five short lists rather than one long one.
    // The order is the order the options arrived in, which sortByKind has
    // already put in kind order - so the sections follow it too.
    order.forEach(function (g) { out += '<optgroup label="' + esc(g) + '">' + groups[g] + '</optgroup>'; });
  }
  if (OPTION_HTML) OPTION_HTML.set(options, out);
  return out;
}
function fillSelect(select, options, current) {
  select.innerHTML = optionsMarkup(options);
  if (current !== undefined && current !== null && Array.prototype.some.call(select.options, function (o) { return o.value === String(current); })) select.value = current;
  // A closed select can only show one line, so the tooltip carries the whole
  // of the chosen entry - and keeps whatever explanation the editor put there
  // as well, rather than replacing it.
  var sync = function () {
    if (select.title && select.title !== select._auto) select._hint = select.title;
    var o = select.options[select.selectedIndex];
    var picked = o ? o.textContent : '';
    select._auto = (select._hint ? select._hint + '\n' : '') + picked;
    select.title = select._auto;
  };
  sync();
  if (!select._titleSync) { select._titleSync = true; select.addEventListener('change', sync); }
  return select.value;
}
function renderBindings(st) {
  var card = $('bindings-card'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  if (!plugs.length) return;
  if (BINDINGS.rows === null || !BINDINGS.dirty) BINDINGS.rows = (st.bindings || []).map(function (b) { return Object.assign({}, b); });
  var host = $('bindings-list'); host.innerHTML = '';
  var head = el('div', 'bind-row bind-head');
  ['', 'Device', 'Action', 'Plug', 'Do', 'Pulse delay', 'By hand', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  var devices = bindingDevices(st);
  if (!BINDINGS.rows.length) host.appendChild(el('div', 'muted small', devices.length ? 'No bindings yet.' : 'No device that sends actions has been seen yet. Pair a button and press it once.'));
  BINDINGS.rows.forEach(function (b, i) {
    var row = el('div', 'bind-row');
    var dev = el('select'), act = el('select'), plug = el('select'), doSel = el('select');
    b.device = fillSelect(dev, sortByKind(devices.map(function (d) { return [d.id, withIcon('button', d.name + (d.actions && d.actions.length ? ' (' + d.actions.length + ' actions)' : ''))]; })), b.device);
    function refillActions() {
      b.action = fillSelect(act, actionOptions(deviceById(b.device), b.action), b.action || 'single');
    }
    refillActions();
    dev.onchange = function () { b.device = dev.value; b.action = null; refillActions(); BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    act.onchange = function () { b.action = act.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    b.plug = fillSelect(plug, cachedTargetOptions(st), b.plug);
    attachTargetReadings(plug, function () { return b.plug; });
    plug.onchange = function () {
      b.plug = plug.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes';
      if (settableTarget(st, b.plug) && String(b.do).indexOf('set:') !== 0) b.do = 'set:';
      if (!settableTarget(st, b.plug) && String(b.do).indexOf('set:') === 0) b.do = 'toggle';
      refillDo(); syncSceneTarget();
    };
    var setBox = setValueBox(st, null, function (v) { b.do = v; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; });
    function refillDo() {
      var keep = b.do;
      fillSelect(doSel, doOptionsFor(st, b.plug, keep), String(keep).indexOf('set:') === 0 ? 'set:' : keep);
      attachTargetReadings(doSel, function () { return b.plug; });
      if (doSel.value === '' || !doSel.options.length) doSel.value = 'toggle';
      b.do = String(keep).indexOf('set:') === 0 ? keep : (doSel.value || 'toggle');
      setBox.refresh(b.plug, b.do);
    }
    refillDo();
    var limits = st.pulse_ms || {default: 5000, min: 100, max: 3600000};
    var msBox = el('span', 'ms' + (b.do === 'pulse' ? ' show' : ''));
    var ms = el('input'); ms.type = 'number'; ms.min = limits.min; ms.max = limits.max; ms.step = 100;
    ms.value = b.pulse_ms || limits.default; ms.title = 'How long the plug stays flipped before it is switched back';
    if (b.do === 'pulse') b.pulse_ms = parseInt(ms.value, 10);
    ms.oninput = function () { b.pulse_ms = parseInt(ms.value, 10) || limits.default; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    msBox.appendChild(ms); msBox.appendChild(el('span', '', 'ms'));
    doSel.onchange = function () {
      b.do = doSel.value === 'set:' ? 'set:' : doSel.value;
      BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes';
      msBox.classList.toggle('show', b.do === 'pulse');
      setBox.refresh(b.plug, b.do);
      if (b.do === 'pulse') { b.pulse_ms = parseInt(ms.value, 10) || limits.default; ms.focus(); }
    };
    var sceneNote = el('span', 'muted small scene-note', 'runs the scene / sequence\u2019s own steps');
    sceneNote.title = 'What happens is defined step by step in the Scenes card - the Do column does not apply here';
    function syncSceneTarget() {
      var isScene = isBundleTarget(b.plug), tells = isNotifyTarget(b.plug);
      doSel.hidden = isScene || tells;
      sceneNote.hidden = !isScene && !tells;
      if (tells) { sceneNote.textContent = 'sends the message'; sceneNote.title = 'Nothing is switched \u2014 what it says is set under Alerts & energy \u2192 Messages'; }
      else { sceneNote.textContent = 'runs the scene\u2019s own steps'; sceneNote.title = 'What happens is defined step by step in the Scenes card'; }
      msBox.classList.toggle('show', !isScene && !tells && b.do === 'pulse');
    }
    var holdCell = el('div', 'sw-cell');
    holdCell.appendChild(makeSwitch(!!b.hold, function (on) { b.hold = on; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; },
                                    {small: true, title: 'Takes the target over: while this press leaves it on, rules and schedules leave it alone. '
                                     + 'The same button switching it off gives it back. A pulse never takes anything over.'}));
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.onclick = function () { BINDINGS.rows.splice(i, 1); BINDINGS.dirty = true; renderBindings(STATE.status); };
    var onSw = makeSwitch(b.enabled !== false, function (v) { b.enabled = v; row.classList.toggle('off', !v); BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; }, {small: true, title: 'Enabled: the binding fires. Off: kept, but ignored.'});
    row.classList.toggle('off', b.enabled === false);
    // doSel and sceneNote take turns, and a hidden element is out of the grid
    // altogether - so they share one cell and the columns stay put
    var doCell = el('div', 'bind-do');
    doCell.appendChild(doSel); doCell.appendChild(sceneNote);
    doCell.appendChild(setBox);
    attachReadings(dev, function () { return b.device; }, function () { return 'action'; });
    [onSw, dev, act, plug, doCell, msBox, holdCell, del].forEach(function (x) { row.appendChild(x); });
    syncSceneTarget();
    makeRowSortable(row, host, BINDINGS, function () { BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; },
                    function () { renderBindings(STATE.status); }, b);
    host.appendChild(row);
  });
  sectionise(host, BINDINGS, 'bindings', function () { BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; }, function () { renderBindings(STATE.status); });
  $('binding-add').disabled = !devices.length;
  $('binding-note').textContent = BINDINGS.dirty ? 'Unsaved changes' : (devices.length ? '' : 'Pair a button first');
}
$('binding-add').onclick = function () {
  BINDINGS.rows = BINDINGS.rows || [];
  BINDINGS.rows.push({device: '', action: null, plug: '', do: 'toggle', enabled: true});
  BINDINGS.dirty = true;
  renderBindings(STATE.status);
};
$('binding-save').onclick = function () {
  withPin('Save button bindings', 'Confirm with the dashboard PIN.', function (pin) {
    return post('bindings-save', {bindings: rowsToSave(BINDINGS, 'bindings'), pin: pin}).then(function (r) {
      saveGroups('bindings', BINDINGS);
      BINDINGS.dirty = false; BINDINGS.rows = null; forgetSig('bindings');
      return (r.bindings || []).length + ' binding(s) saved';
    });
  });
};

// ---- sensor rules -------------------------------------------------------------------
var RULES = { rows: null, dirty: false };
function markRules() { RULES.dirty = true; $('rule-note').textContent = 'Unsaved changes'; }
function ruleSources(st) {
  // a sensor group is a source like any other, and stands out as one

  return st.devices.filter(function (d) {
    return Object.keys(d.values || {}).some(function (k) { return isNum((d.values[k] || {}).value); });
  });
}
function ruleWorthy(v) {
  if (isNum(v)) return true;
  if (typeof v === 'boolean') return true;
  if (typeof v === 'string') return ['ON', 'OFF', 'OPEN', 'CLOSE', 'CLOSED', 'TRUE', 'FALSE', 'OCCUPIED', 'CLEAR', 'YES', 'NO'].indexOf(v.toUpperCase()) >= 0;
  return false;
}
function numericKeys(device, current) {
  var keys = device ? Object.keys(device.values || {}).filter(function (k) { return ruleWorthy((device.values[k] || {}).value); }) : [];
  if (current && keys.indexOf(current) < 0) keys.push(current);
  return keys;
}
function minhm(m) { return m === null || m === undefined ? '?' : ('0' + Math.floor(m / 60)).slice(-2) + ':' + ('0' + (m % 60)).slice(-2); }
// Two rules watching the same sensor and pointing at the same thing fire
// twice for one report. That is legal - different hours, different
// thresholds - but far more often it is a leftover, so say so.
function duplicateRuleIds(rows) {
  // Only a rule that would fire on the very same crossing counts: the same
  // reading, the same line, the same target, the same thing done. A pair that
  // switches on above and off below is the pattern this card recommends, and
  // must never be flagged.
  var seen = {}, dupes = {};
  (rows || []).forEach(function (r) {
    if (!r.device || !r.key || !r.plug) return;
    [[r.device, r.key, r.op, r.value], [r.device2, r.key2, r.op2, r.value2]].forEach(function (side) {
      if (!side[0] || !side[1] || side[3] === undefined || side[3] === null) return;
      var key = [side[0], side[1], side[2], side[3], r.plug, r.do, r.from || '', r.to || ''].join('|');
      if (seen[key] && seen[key] !== r.id) { dupes[r.id] = true; dupes[seen[key]] = true; }
      else seen[key] = r.id;
    });
  });
  return dupes;
}
// The device list and the target list are the same for every row of one
// render, and building them is most of what a big editor spends its time on.
// Worked out once per pass, keyed on what they are made of.
var LIST_CACHE = {stamp: null, devices: null, targets: null};
function listStamp(st) { return [(st.devices || []).length, (st.plugs || []).length, (st.scenes || []).length,
                                 (st.sequences || []).length, (st.messages || []).length, ((st.heating || {}).rooms || []).length].join(':'); }
function sortedDeviceOptions(st, list) {
  var stamp = listStamp(st) + '|' + list.length;
  if (LIST_CACHE.stamp === stamp && LIST_CACHE.devices) return LIST_CACHE.devices;
  var out = sortWithinHeadings(devicesSorted(list).map(function (d) { return [d.id, deviceIcon(d) + ' ' + d.name]; }));
  LIST_CACHE.stamp = stamp; LIST_CACHE.devices = out; LIST_CACHE.targets = null;
  return out;
}
function cachedTargetOptions(st) {
  if (LIST_CACHE.targets) return LIST_CACHE.targets;
  LIST_CACHE.targets = targetOptions(st, null);
  return LIST_CACHE.targets;
}
function renderRules(st) {
  var card = $('rules-card'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  if (!plugs.length) return;
  if (RULES.rows === null || !RULES.dirty) RULES.rows = (st.rules || []).map(function (r) { return Object.assign({}, r); });
  var host = $('rules-list'); host.innerHTML = '';
  var head = el('div', 'rule-row bind-head');
  ['', 'Source', 'Value', 'Is', 'Threshold', 'Plug', 'Do', 'Cooldown', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  var sources = ruleSources(st);
  if (!RULES.rows.length) host.appendChild(el('div', 'muted small', sources.length ? 'No rules yet.' : 'No device with numeric readings seen yet.'));
  var dupes = duplicateRuleIds(RULES.rows);
  RULES.rows.forEach(function (r, i) {
    var row = el('div', 'rule-row');
    if (dupes[r.id]) {
      row.classList.add('twinned');
      row.title = 'Another rule fires on exactly this crossing and does exactly this to the same target. '
        + 'One report sets both off; unless that is deliberate, one of them is a leftover.';
    }
    var dev = el('select'), key = el('select'), op = el('select'), plug = el('select'), doSel = el('select');
    var list = sources.slice();
    if (r.device && !list.some(function (d) { return d.id === r.device; })) { var known = deviceById(r.device); if (known) list.push(known); }
    r.device = fillSelect(dev, sortedDeviceOptions(st, list), r.device);
    function refillKeys() {
      var device = deviceById(r.device);
      r.key = fillSelect(key, numericKeys(device, r.key).map(function (k) {
        var label = ((device || {}).values || {})[k] || {};
        var binary = !isNum(label.value) && ruleWorthy(label.value);
        return [k, (label.label || k) + (label.unit ? ' (' + label.unit + ')' : (binary ? ' (1 = yes/on)' : ''))];
      }), r.key);
    }
    refillKeys();
    dev.onchange = function () { r.device = dev.value; r.key = null; refillKeys(); unitHint(); markRules(); };
    key.onchange = function () { r.key = key.value; unitHint(); markRules(); };
    [dev, key].forEach(function (n) { attachReadings(n, function () { return r.device; }, function () { return r.key; }); });
    r.op = fillSelect(op, (st.rule_ops || ['>=', '<=', '>', '<', '==', '!=']).map(function (o) { return [o, RULE_OP_SYMBOL[o] || o]; }), r.op || '>=');
    op.onchange = function () { r.op = op.value; markRules(); };
    var val = el('input'); val.type = 'number'; val.step = 'any'; val.value = r.value !== undefined && r.value !== null ? r.value : '';
    function unitHint() {
      var device = deviceById(r.device), info = device && device.values ? device.values[r.key] : null;
      val.placeholder = (info && info.unit) || 'value';
      val.title = info ? (info.label || r.key) + (info.unit ? ' in ' + info.unit : '') + ', now ' + fmt(info.value) : '';
    }
    unitHint();
    val.oninput = function () { r.value = parseFloat(val.value); markRules(); };
    attachReadings(val, function () { return r.device; }, function () { return r.key; });
    r.plug = fillSelect(plug, cachedTargetOptions(st), r.plug);
    attachTargetReadings(plug, function () { return r.plug; });
    plug.onchange = function () {
      r.plug = plug.value; markRules();
      if (settableTarget(st, r.plug) && String(r.do).indexOf('set:') !== 0) r.do = 'set:';
      if (!settableTarget(st, r.plug) && String(r.do).indexOf('set:') === 0) r.do = 'on';
      refillDoR(); syncSceneTargetR();
    };
    var doBox = el('span'); doBox.style.display = 'flex'; doBox.style.gap = '6px'; doBox.style.alignItems = 'center';
    var limits = st.pulse_ms || {default: 5000, min: 100, max: 3600000};
    var setBoxR = setValueBox(st, null, function (v) { r.do = v; markRules(); });
    function refillDoR() {
      var keep = r.do || 'on';
      fillSelect(doSel, doOptionsFor(st, r.plug, keep), String(keep).indexOf('set:') === 0 ? 'set:' : keep);
      attachTargetReadings(doSel, function () { return r.plug; });
      r.do = String(keep).indexOf('set:') === 0 ? keep : (doSel.value || 'on');
      setBoxR.refresh(r.plug, r.do);
    }
    refillDoR();
    doSel.onchange = function () { r.do = doSel.value; setBoxR.refresh(r.plug, r.do); syncDoExtrasR(); if (r.do === 'pulse') r.pulse_ms = parseInt(ms.value, 10) || limits.default; markRules(); };
    doBox.appendChild(doSel); doBox.appendChild(setBoxR);
    var cool = el('input'); cool.type = 'number'; cool.min = 0; cool.step = 10; cool.value = r.cooldown_s !== undefined ? r.cooldown_s : 300; cool.title = 'seconds before the same rule may fire again';
    cool.oninput = function () { r.cooldown_s = parseInt(cool.value, 10) || 0; markRules(); };
    // pulse duration and hysteresis need room to type in - they live on the
    // sub-line below with the rest of the fine-tuning, not squeezed into
    // the narrow Do cell in the main row
    var msLbl = el('span', 'sublbl', 'pulse for');
    var ms = el('input'); ms.type = 'number'; ms.min = limits.min; ms.max = limits.max; ms.step = 100; ms.value = r.pulse_ms || limits.default;
    ms.className = 'wnum'; ms.title = 'How long the relay stays flipped before it goes back, in milliseconds';
    ms.oninput = function () { r.pulse_ms = parseInt(ms.value, 10) || limits.default; markRules(); };
    var msUnit = el('span', 'muted', 'ms');
    var backLbl = el('span', 'sublbl', 'back at');
    var back = el('input'); back.type = 'number'; back.step = 'any'; back.className = 'wnum';
    back.placeholder = '\u2026'; back.value = (r.back === undefined || r.back === null) ? '' : r.back;
    back.title = 'Hysteresis in one rule: past this threshold the other way, the opposite is done (only with switch on/off)';
    back.oninput = function () { r.back = back.value === '' ? null : parseFloat(back.value); markRules(); };
    var sceneNoteR = el('span', 'muted small scene-note', 'runs the scene\u2019s own steps');
    sceneNoteR.title = 'What happens is defined step by step in the Scenes card - Do does not apply here';
    doBox.appendChild(sceneNoteR);
    function syncSceneTargetR() { syncDoExtrasR(); }
    function syncDoExtrasR() {
      var isScene = isBundleTarget(r.plug), tells = isNotifyTarget(r.plug);
      doSel.hidden = isScene || tells;
      sceneNoteR.hidden = !isScene && !tells;
      sceneNoteR.textContent = tells ? 'sends the message' : 'runs the scene\u2019s own steps';
      sceneNoteR.title = tells ? 'Nothing is switched \u2014 what it says is set under Alerts & energy \u2192 Messages'
                               : 'What happens is defined step by step in the Scenes card - Do does not apply here';
      msLbl.hidden = msUnit.hidden = ms.hidden = isScene || tells || r.do !== 'pulse';
      backLbl.hidden = back.hidden = isScene || tells || (r.do !== 'on' && r.do !== 'off');
      if (typeof syncCloseVis === 'function') try { syncCloseVis(); } catch (err) {}
    }
    syncDoExtrasR();
    var last = el('span', 'now');
    var hasReading = r.reading !== undefined && r.reading !== null;
    if (hasReading) last.innerHTML = 'now ' + fmt(r.reading) + (r.holds ? ' <b>&middot; true</b>' : '');
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.onclick = function () { RULES.rows.splice(i, 1); markRules(); renderRules(STATE.status); };
    var cell = el('span'); cell.appendChild(cool);
    var onSwR = makeSwitch(r.enabled !== false, function (v) { r.enabled = v; row.classList.toggle('off', !v); markRules(); }, {small: true, title: 'Enabled: the rule is evaluated. Off: kept, but ignored.'});
    row.classList.toggle('off', r.enabled === false);
    [onSwR, dev, key, op, val, plug, doBox, cell, del].forEach(function (x) { row.appendChild(x); });
    var pack = el('div', 'rule-pack');
    makeRowSortable(pack, host, RULES, markRules, function () { renderRules(STATE.status); }, r);
    pack.appendChild(row);
    host.appendChild(pack);

    // the clock window, on its own quiet line under the rule
    var sub = el('div', 'rule-sub');
    var line1 = el('div', 'rule-sub-line');
    var line2 = el('div', 'rule-sub-line');
    sub.appendChild(line1); sub.appendChild(line2);

    // -- the clock window: a real picker, not a bare text box -----------------
    function parseEnd(spec) {
      var m = /^(sunrise|sunset)([+-]\d{1,3})?$/.exec(spec || '');
      if (m) return { kind: m[1], offset: parseInt(m[2] || '0', 10) };
      if (/^\d{1,2}:\d{2}$/.test(spec || '')) return { kind: 'clock', time: spec };
      return { kind: 'clock', time: '' };
    }
    function endSpec(state) {
      if (state.kind === 'clock') return state.time || '';
      return state.kind + (state.offset ? (state.offset > 0 ? '+' : '') + state.offset : '');
    }
    function endControl(initial, assign) {
      var state = parseEnd(initial);
      var wrap = el('span', 'wend');
      var kind = el('select');
      fillSelect(kind, TIME_KIND_OPTIONS, state.kind);
      var clock = el('input'); clock.type = 'time'; clock.value = state.time || '';
      var off = el('input'); off.type = 'number'; off.step = 5; off.min = -180; off.max = 180; off.value = state.offset || 0;
      off.className = 'woff'; off.title = 'minutes before (−) or after (+)';
      var offLbl = el('span', 'muted', 'min');
      function sync() {
        clock.hidden = state.kind !== 'clock';
        off.hidden = offLbl.hidden = state.kind === 'clock';
        assign(endSpec(state));
      }
      kind.onchange = function () { state.kind = kind.value; sync(); markRules(); };
      clock.onchange = function () { state.time = clock.value; assign(endSpec(state)); markRules(); };
      off.onchange = function () { state.offset = parseInt(off.value, 10) || 0; assign(endSpec(state)); markRules(); };
      if (st.astro) kind.title = 'Today: sunrise ' + minhm(st.astro.sunrise) + ', sunset ' + minhm(st.astro.sunset);
      wrap.appendChild(kind); wrap.appendChild(clock); wrap.appendChild(off); wrap.appendChild(offLbl);
      sync();
      return wrap;
    }
    var winMode = el('select');
    fillSelect(winMode, [['', withIcon('always', 'around the clock')], ['set', withIcon('window', 'between')]], (r.from || r.to) ? 'set' : '');
    var winBox = el('span', 'wend');
    var dash = el('span', 'muted', '–');
    function buildWindow() {
      winBox.innerHTML = '';
      if (winMode.value !== 'set') { r.from = ''; r.to = ''; return; }
      if (!r.from) r.from = '22:00';
      if (!r.to) r.to = '06:00';
      winBox.appendChild(endControl(r.from, function (v) { r.from = v; }));
      winBox.appendChild(dash);
      winBox.appendChild(endControl(r.to, function (v) { r.to = v; }));
    }
    winMode.onchange = function () { buildWindow(); markRules(); };
    buildWindow();
    var readingLbl = el('span', 'sublbl', 'reading');
    readingLbl.hidden = last.hidden = !hasReading;
    line1.appendChild(readingLbl);
    line1.appendChild(last);
    line1.appendChild(el('span', 'sublbl', 'Active'));
    line1.appendChild(winMode);
    line1.appendChild(winBox);
    var endSel = el('select');
    fillSelect(endSel, [['', withIcon('leave', 'leave it as it is')], ['off', '\u2b58 switch it off'], ['on', '\u23fb switch it on']], r.window_end || '');
    endSel.onchange = function () { r.window_end = endSel.value; markRules(); };
    endSel.title = 'The safe state: a motion-driven light is switched off when its night window ends, whether or not anyone walked by at that moment';
    var closeLbl = el('span', 'sublbl', 'when it closes');
    line1.appendChild(closeLbl);
    line1.appendChild(endSel);
    function syncCloseVis() {
      // no window = nothing ever closes; a scene target has no off to fall back to
      var pointless = winMode.value !== 'set' || isBundleTarget(r.plug) || isNotifyTarget(r.plug);
      closeLbl.hidden = endSel.hidden = pointless;
    }
    winMode.addEventListener('change', syncCloseVis);
    syncCloseVis();
    var forIn = el('input'); forIn.type = 'number'; forIn.min = 0; forIn.step = 10; forIn.className = 'wnum';
    forIn.value = r.for_s || 0; forIn.title = 'The condition must hold this many seconds before the rule fires (0 = at once). "No motion for 600 s" or "washer under 5 W for 180 s" live here.';
    forIn.oninput = function () { r.for_s = parseInt(forIn.value, 10) || 0; markRules(); };
    line1.appendChild(el('span', 'sublbl', 'must hold'));
    line1.appendChild(forIn);
    line1.appendChild(el('span', 'muted', 's'));
    // only when somebody is in, or out: "motion while the house is empty" is
    // a different thing from "motion"
    var whenSel = el('select');
    var whenOptions = [['', withIcon('always', 'whoever is in')],
                       ['away', '\ud83d\udeaa nobody home'],
                       ['home', '\ud83c\udfe0 someone home']];
    ((st.people) || []).forEach(function (person) {
      whenOptions.push(['person:' + person.id + ':away', '\ud83d\udeaa ' + person.name + ' out']);
      whenOptions.push(['person:' + person.id + ':home', '\ud83c\udfe0 ' + person.name + ' in']);
    });
    if (r.when && !whenOptions.some(function (o) { return o[0] === r.when; })) whenOptions.push([r.when, r.when + ' (gone)']);
    r.when = fillSelect(whenSel, whenOptions, r.when || '');
    whenSel.title = 'Limit this rule to when the house is empty, occupied, or one person is in or out. With nobody set up under Presence, or the controller unreachable, a limited rule stays quiet rather than guessing.';
    whenSel.onchange = function () { r.when = whenSel.value; markRules(); };
    line1.appendChild(el('span', 'sublbl', 'only when'));
    line1.appendChild(whenSel);
    var modeSel = el('select');
    fillSelect(modeSel, [['abs', withIcon('abs', 'value as reported')], ['delta24', withIcon('delta', 'vs its 24 h average')]], r.mode || 'abs');
    modeSel.title = 'delta: the threshold compares against (value − rolling 24 h average). Humidity +15 over the day’s norm beats any fixed number.';
    modeSel.onchange = function () { r.mode = modeSel.value; markRules(); };
    line1.appendChild(el('span', 'sublbl', 'compare'));
    line1.appendChild(modeSel);
    var mph = el('input'); mph.type = 'number'; mph.min = 0; mph.max = 1000; mph.className = 'wnum';
    mph.value = r.max_per_hour || 0; mph.title = 'Safety valve: at most this many firings per hour (0 = no limit). Past it, the rule holds fire and logs a warning.';
    mph.oninput = function () { r.max_per_hour = parseInt(mph.value, 10) || 0; markRules(); };
    line1.appendChild(el('span', 'sublbl', 'max/h'));
    line1.appendChild(mph);
    line1.appendChild(msLbl); line1.appendChild(ms); line1.appendChild(msUnit);
    line1.appendChild(backLbl); line1.appendChild(back);

    // -- the optional second condition ----------------------------------------
    var combineSel = el('select'); combineSel.className = 'combine-sel';
    r.combine = fillSelect(combineSel, [['and', 'AND'], ['or', 'OR']], r.combine || 'and');
    combineSel.title = 'AND: the rule needs both conditions at once. OR: either one is enough \u2014 e.g. two PIRs covering one room, motion on either fires it.';
    combineSel.onchange = function () { r.combine = combineSel.value; markRules(); };
    line2.appendChild(combineSel);
    var dev2 = el('select'), key2 = el('select'), op2 = el('select'), val2 = el('input');
    val2.type = 'number'; val2.step = 'any';
    var srcOptions = [['', '— no second condition —']].concat(devicesSorted(sources).map(function (x) { return [x.id, deviceIcon(x) + ' ' + x.name]; }));
    r.device2 = fillSelect(dev2, srcOptions, r.device2 || '');
    function refillKeys2() {
      var device = deviceById(r.device2);
      key2.hidden = op2.hidden = val2.hidden = combineSel.hidden = !r.device2;
      if (!r.device2) { r.key2 = ''; return; }
      r.key2 = fillSelect(key2, numericKeys(device, r.key2).map(function (k) {
        var info = ((device || {}).values || {})[k] || {};
        return [k, (info.label || k)];
      }), r.key2);
    }
    dev2.onchange = function () { r.device2 = dev2.value; r.key2 = null; refillKeys2(); markRules(); };
    [dev2, key2, val2].forEach(function (n) { attachReadings(n, function () { return r.device2; }, function () { return r.key2; }); });
    key2.onchange = function () { r.key2 = key2.value; markRules(); };
    r.op2 = fillSelect(op2, (st.rule_ops || []).map(function (o) { return [o, RULE_OP_SYMBOL[o] || o]; }), r.op2 || '>=');
    op2.onchange = function () { r.op2 = op2.value; markRules(); };
    val2.type = 'number'; val2.step = 'any'; val2.className = 'wnum'; val2.placeholder = 'threshold';
    val2.value = (r.value2 === undefined || r.value2 === null) ? '' : r.value2;
    val2.oninput = function () { r.value2 = val2.value === '' ? null : parseFloat(val2.value); markRules(); };
    refillKeys2();
    [dev2, key2, op2, val2].forEach(function (x) { line2.appendChild(x); });

    // -- and a third, on the same footing: "nobody in the hall AND the door
    //    open AND nothing moving in the lavatory" needs all three
    var combine3 = el('select'); combine3.className = 'combine-sel';
    r.combine3 = fillSelect(combine3, [['and', 'AND'], ['or', 'OR']], r.combine3 || r.combine || 'and');
    combine3.title = 'How the third condition joins the first two.';
    combine3.onchange = function () { r.combine3 = combine3.value; markRules(); };
    var dev3 = el('select'), key3 = el('select'), op3 = el('select'), val3 = el('input');
    val3.type = 'number'; val3.step = 'any';
    var src3 = [['', '\u2014 no third condition \u2014']].concat(devicesSorted(sources).map(function (x) { return [x.id, deviceIcon(x) + ' ' + x.name]; }));
    r.device3 = fillSelect(dev3, src3, r.device3 || '');
    function refillKeys3() {
      var device = deviceById(r.device3);
      key3.hidden = op3.hidden = val3.hidden = combine3.hidden = !r.device3;
      dev3.hidden = !r.device2 && !r.device3;          // a third only makes sense once there is a second
      if (!r.device3) { r.key3 = ''; return; }
      r.key3 = fillSelect(key3, numericKeys(device, r.key3).map(function (k) {
        var info = ((device || {}).values || {})[k] || {};
        return [k, (info.label || k)];
      }), r.key3);
    }
    dev3.onchange = function () { r.device3 = dev3.value; r.key3 = null; refillKeys3(); markRules(); };
    [dev3, key3, val3].forEach(function (n) { attachReadings(n, function () { return r.device3; }, function () { return r.key3; }); });
    key3.onchange = function () { r.key3 = key3.value; markRules(); };
    r.op3 = fillSelect(op3, (st.rule_ops || []).map(function (o) { return [o, RULE_OP_SYMBOL[o] || o]; }), r.op3 || '>=');
    op3.onchange = function () { r.op3 = op3.value; markRules(); };
    val3.type = 'number'; val3.step = 'any'; val3.className = 'wnum'; val3.placeholder = 'threshold';
    val3.value = (r.value3 === undefined || r.value3 === null) ? '' : r.value3;
    val3.oninput = function () { r.value3 = val3.value === '' ? null : parseFloat(val3.value); markRules(); };
    var was2 = dev2.onchange;
    dev2.onchange = function () { was2(); refillKeys3(); };
    refillKeys3();
    [combine3, dev3, key3, op3, val3].forEach(function (x) { line2.appendChild(x); });
    var dry = el('button', 'btn cmd small'); dry.type = 'button'; setButtonIcon(dry, 'search', 'Dry run 7 d');
    dry.title = 'Walk the recorded week: when would this rule have fired?';
    dry.onclick = function () {
      withPin('Dry run', 'The rule as edited here is walked over the last 7 days of history. Nothing is switched.', function (pin) {
        return post('rule-dryrun', {rule: r, pin: pin}).then(function (res) {
          var last = (res.fires || []).slice(-5).map(function (t) { return stamp(t); }).join(' · ');
          return res.count + '× in ' + res.days + ' d (' + res.samples + ' samples)' + (last ? ' — last: ' + last : '');
        });
      });
    };
    line2.appendChild(dry);
    if (r.from && !STATE_RULE_WINDOW_OPEN(r)) sub.appendChild(el('span', 'tag dim', 'outside its hours now'));
    pack.appendChild(sub);
  });
  sectionise(host, RULES, 'rules', markRules, function () { renderRules(STATE.status); });
  function STATE_RULE_WINDOW_OPEN(r) {
    if (!r.from || !r.to) return true;
    if (!/^\d{1,2}:\d{2}$/.test(r.from) || !/^\d{1,2}:\d{2}$/.test(r.to)) return true;  // astro: no claim here
    var d = new Date(), m = d.getHours() * 60 + d.getMinutes();
    var f = parseInt(r.from.slice(0, 2), 10) * 60 + parseInt(r.from.slice(3), 10);
    var t = parseInt(r.to.slice(0, 2), 10) * 60 + parseInt(r.to.slice(3), 10);
    if (f === t) return true;
    return f < t ? (m >= f && m < t) : (m >= f || m < t);
  }
  if (!RULES.dirty) $('rule-note').textContent = '';
  $('rule-add').disabled = !sources.length;
}
$('rule-add').onclick = function () {
  RULES.rows = RULES.rows || [];
  RULES.rows.push({device: '', key: null, op: '>=', value: '', plug: '', do: 'on', cooldown_s: 300, enabled: true});
  markRules(); renderRules(STATE.status);
};
$('rule-save').onclick = function () {
  withPin('Save sensor rules', 'The daemon applies them at once; each fires when its condition becomes true.', function (pin) {
    return post('rules-save', {rules: rowsToSave(RULES, 'rules'), pin: pin}).then(function (r) {
      saveGroups('rules', RULES);
      RULES.dirty = false; RULES.rows = null; forgetSig('rules');
      return (r.rules || []).length + ' rule(s) saved';
    });
  });
};

// ---- live updates: a long poll rides beside the 5 s tick --------------------------
// The daemon holds /api/wait open until something visible changes (a report,
// a plug switching, a bridge event) and answers at once when it does, so a
// button press shows up here in well under a second. The 5 s tick stays as
// the safety net; if the wait endpoint fails, nothing is worse than before.
var WAIT = { running: false, failures: 0, seq: 0 };
function waitLoop() {
  if (WAIT.running) return;
  WAIT.running = true;
  (function loop() {
    if (document.hidden || !STATE.status) { WAIT.running = false; setTimeout(waitLoop, 1000); return; }
    // the newest seq we know of: the status we painted, or the one the
    // daemon just woke us with while that status is still on its way - so
    // the next wait hangs on the NEXT change instead of returning at once
    var seen = Math.max(STATE.status.seq || 0, WAIT.seq || 0);
    api('wait&seq=' + seen).then(function (r) {
      WAIT.failures = 0;
      if (r.seq > seen) { WAIT.seq = r.seq; wakeTick(); }
      setTimeout(loop, 20);
    }, function () {
      WAIT.failures++;
      setTimeout(loop, Math.min(15000, 2000 * WAIT.failures));
    });
  })();
}
// A burst - the network map landing, twenty reports in one second - must
// not turn into twenty status fetches: the first change is fetched at once,
// anything else inside the next 150 ms rides along on one trailing fetch.
function wakeTick() {
  var now = Date.now(), since = now - (WAIT.lastTick || 0);
  if (since >= 150) { WAIT.lastTick = now; tick(true); return; }
  if (WAIT.trailing) return;
  WAIT.trailing = setTimeout(function () { WAIT.trailing = null; WAIT.lastTick = Date.now(); tick(true); }, 150 - since);
}
document.addEventListener('visibilitychange', function () { if (!document.hidden) waitLoop(); });


// ---- the energy card: kWh and money per plug ---------------------------------------
var ENERGY = { at: 0, data: null, open: null, daily: null, sig: null, folded: {} };
// which groups are folded away survives a reload, like the unlock does
try { ENERGY.folded = JSON.parse(sessionStorage.getItem('zigmon-energy-folds') || '{}') || {}; } catch (e) {}
function rememberFolds() { try { sessionStorage.setItem('zigmon-energy-folds', JSON.stringify(ENERGY.folded)); } catch (e) {} }
function renderEnergy(st) {
  var card = $('energy-card');
  if (!(st.plugs || []).length) { card.hidden = true; return; }
  if (Date.now() - ENERGY.at > 60000) {
    ENERGY.at = Date.now();
    api('energy').then(function (r) { ENERGY.data = r; paintEnergy(); }, function () {});
    if (ENERGY.open) loadEnergyDaily(ENERGY.open, true);
  } else if (ENERGY.data) paintEnergy();
  function paintEnergy() {
    var data = ENERGY.data;
    card.hidden = false;
    var signature = JSON.stringify(data.plugs) + '|' + data.price_per_kwh + '|' + ENERGY.open
      + '|' + ((STATE.status || {}).plugs || []).map(function (p) { return p.name + ':' + (p.role || ''); }).join(',')
      + '|' + JSON.stringify(ENERGY.folded) + '|' + JSON.stringify((STATE.status || {}).room_of || {});
    if (signature === ENERGY.sig && $('energy-table').firstChild) {
      if (ENERGY.open && ENERGY.daily) paintEnergyDaily();
      return;                       // nothing changed: leave the DOM (and the open chart) alone
    }
    ENERGY.sig = signature;
    var price = data.price_per_kwh, cur = data.currency || '';
    ENERGY.price = price; ENERGY.cur = cur;
    function cell(wh) {
      var kwh = (wh || 0) / 1000;
      var out = kwh.toFixed(kwh < 10 ? 2 : 1) + ' kWh';
      if (isNum(price)) out += ' \u00b7 ' + (kwh * price).toFixed(1) + ' ' + cur;
      return out;
    }
    var html = '<table class="tbl"><thead><tr><th>Plug</th><th>Today</th><th>Yesterday</th><th>This month</th><th>Last month</th><th>This year</th><th>Last year</th></tr></thead><tbody>';
    var totals = {today_wh: 0, yesterday_wh: 0, month_wh: 0, last_month_wh: 0, year_wh: 0, last_year_wh: 0};
    var KEYS = Object.keys(totals);
    function plugRow(p) {
      var since = p.zero_ts ? ' <span class="dim" title="counting since ' + esc(stamp(p.zero_ts)) + '">\u21ba</span>' : '';
      var icon = ICON[plugRoleKind(p.name)] || ICON.plug;      // a socket or a light, as it is marked
      return '<tr class="eplug"><td><span class="eicon">' + icon + '</span><b class="elink" data-plug="' + esc(p.name) + '" title="Click: last 30 days as bars">' + esc(p.name) + '</b>' + since + '</td><td>'
        + cell(p.today_wh) + '</td><td>' + cell(p.yesterday_wh) + '</td><td>' + cell(p.month_wh) + '</td><td>'
        + cell(p.last_month_wh) + '</td><td>' + cell(p.year_wh) + '</td><td>' + cell(p.last_year_wh) + '</td></tr>';
    }
    // Grouped by room and folded away: two dozen plugs is a wall of numbers
    // otherwise. Without any rooms, the sockets of one physical box make a
    // line, so a four-way strip is one row. Group lines carry their own
    // totals and every plug keeps its chart drill-down.
    var st2 = STATE.status || {}, map = st2.room_of || {}, rooms = st2.rooms || [];
    var hostOf = {};
    (st2.plugs || []).forEach(function (p) { if (p.host) hostOf[p.name] = String(p.host); });
    var groups = [], byRoom = {};
    if (rooms.length) {
      rooms.forEach(function (r) { byRoom[r.id] = {name: r.name, id: 'room:' + r.id, plugs: []}; groups.push(byRoom[r.id]); });
    }
    var loose = {name: rooms.length ? 'Not in a room' : '', id: 'loose', plugs: []};
    (data.plugs || []).forEach(function (p) {
      KEYS.forEach(function (k) { totals[k] += p[k] || 0; });
      var rid = rooms.length ? map[p.name] : null;
      if (rid && byRoom[rid]) { byRoom[rid].plugs.push(p); return; }
      if (!rooms.length) {
        // one line per physical box: a strip's four sockets belong together
        var host = hostOf[p.name] || '';
        var mates = host ? (data.plugs || []).filter(function (q) { return hostOf[q.name] === host; }) : [];
        if (mates.length > 1) {
          var id = 'host:' + host;
          if (!byRoom[id]) {
            var prefix = mates.map(function (q) { return q.name; }).reduce(function (a, b) {
              var i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++;
              return a.slice(0, i);
            });
            byRoom[id] = {name: (prefix.replace(/[-_ ]+$/, '') || host) + ' \u00b7 ' + mates.length + ' sockets', id: id, plugs: []};
            groups.push(byRoom[id]);
          }
          byRoom[id].plugs.push(p);
          return;
        }
      }
      loose.plugs.push(p);
    });
    if (loose.plugs.length) { loose.name = loose.name || 'Single plugs'; groups.push(loose); }
    groups.forEach(function (g) {
      if (!g.plugs.length) return;
      if (!g.name) { g.plugs.forEach(function (p) { html += plugRow(p); }); return; }
      var sub = {}; KEYS.forEach(function (k) { sub[k] = g.plugs.reduce(function (a, p) { return a + (p[k] || 0); }, 0); });
      // everything starts folded; what you opened stays open across a reload
      var open = ENERGY.folded[g.id] === false;
      var gicon = g.id.indexOf('room:') === 0 ? '\ud83c\udfe0' : (g.id.indexOf('host:') === 0 ? '\ud83d\udd0c' : '\ud83d\udcc1');
      html += '<tr class="eroom' + (open ? ' open' : '') + '" data-room="' + esc(g.id) + '"><td><span class="efold">'
        + (open ? '\u25be' : '\u25b8') + '</span> <span class="eicon">' + gicon + '</span><b>' + esc(g.name) + '</b> <span class="dim">' + g.plugs.length + '</span></td><td>'
        + cell(sub.today_wh) + '</td><td>' + cell(sub.yesterday_wh) + '</td><td>' + cell(sub.month_wh) + '</td><td>'
        + cell(sub.last_month_wh) + '</td><td>' + cell(sub.year_wh) + '</td><td>' + cell(sub.last_year_wh) + '</td></tr>';
      if (open) g.plugs.forEach(function (p) { html += plugRow(p); });
    });
    if ((data.plugs || []).length > 1) {
      html += '<tr class="etotal"><td><span class="eicon">\u03a3</span><b class="elink" data-plug="*" title="Click: last 30 days as bars">All plugs</b></td><td>' + cell(totals.today_wh) + '</td><td>' + cell(totals.yesterday_wh) + '</td><td>'
        + cell(totals.month_wh) + '</td><td>' + cell(totals.last_month_wh) + '</td><td>' + cell(totals.year_wh) + '</td><td>' + cell(totals.last_year_wh) + '</td></tr>';
    }
    html += '</tbody></table>';
    var anyOpen = groups.some(function (g) { return g.plugs.length && ENERGY.folded[g.id] === false; });
    html += '<div class="btnrow" style="margin-top:8px"><button class="btn small" id="energy-foldall">'
      + (anyOpen ? 'Fold every group' : 'Open every group') + '</button></div>';
    html += '<div id="energy-daily" hidden style="margin-top:12px"></div>';
    if (!isNum(price)) html += '<p class="note" style="margin-top:8px">Set <code>price_per_kwh</code> (and <code>currency</code>) under Control \u2192 System \u2192 Settings to see money next to the kWh.</p>';
    $('energy-table').innerHTML = html;
    var foldAll = $('energy-foldall');
    setButtonIcon(foldAll, anyOpen ? 'up' : 'down');
    foldAll.title = 'Show or hide the sockets inside every group at once';
    if (foldAll) foldAll.onclick = function () {
      var open = groups.some(function (g) { return g.plugs.length && ENERGY.folded[g.id] === false; });
      groups.forEach(function (g) { ENERGY.folded[g.id] = open; });
      rememberFolds(); ENERGY.sig = null; paintEnergy();
    };
    Array.prototype.forEach.call($('energy-table').querySelectorAll('.eroom'), function (tr) {
      tr.style.cursor = 'pointer';
      tr.title = 'Click to fold this room away';
      tr.onclick = function () {
        var id = tr.dataset.room;
        ENERGY.folded[id] = ENERGY.folded[id] === false;   // open -> folded, folded -> open
        rememberFolds(); ENERGY.sig = null; paintEnergy();
      };
    });
    Array.prototype.forEach.call($('energy-table').querySelectorAll('.elink'), function (b) {
      b.style.cursor = 'pointer';
      b.onclick = function () {
        if (ENERGY.open === b.dataset.plug) { ENERGY.open = null; ENERGY.daily = null; $('energy-daily').hidden = true; return; }
        loadEnergyDaily(b.dataset.plug);
      };
    });
    // restore the open daily chart from cache — never fire a new API call during a repaint
    if (ENERGY.open && ENERGY.daily) paintEnergyDaily();
    else if (ENERGY.open) loadEnergyDaily(ENERGY.open, true);
  }
}
function loadEnergyDaily(name, quiet) {
  ENERGY.open = name;
  api('energy-daily&plug=' + encodeURIComponent(name)).then(function (r) {
    ENERGY.daily = r;
    paintEnergyDaily();
  }, function (e) { if (!quiet) toast(e.message || String(e), false); });
}
function paintEnergyDaily() {
  var host = $('energy-daily');
  if (!host || !ENERGY.daily || !ENERGY.open) return;
  var r = ENERGY.daily;
  host.hidden = false;
  var top = Math.max.apply(null, r.days.map(function (d) { return d.wh; }).concat([1]));
  var bars = r.days.map(function (d, i) {
    var h = Math.max(2, Math.round(d.wh / top * 72));
    return '<div class="ebar" data-i="' + i + '"><i style="height:' + h + 'px"></i><span>' + esc(d.day.slice(3)) + '</span></div>';
  }).join('');
  host.innerHTML = '<div class="muted small" style="margin-bottom:6px">' + esc(r.plug) + ' \u2014 last 30 days, tallest ' + (top / 1000).toFixed(2) + ' kWh \u00b7 <span class="elink-close" style="cursor:pointer;color:var(--info)">close</span></div><div class="ebars">' + bars + '</div><div class="etip" hidden></div>';
  host.querySelector('.elink-close').onclick = function () { ENERGY.open = null; ENERGY.daily = null; host.hidden = true; };
  // one tooltip, moved under the pointer: date, kWh and what it cost
  var tip = host.querySelector('.etip'), wrap = host.querySelector('.ebars');
  var total = r.days.reduce(function (a, d) { return a + d.wh; }, 0);
  var show = function (bar) {
    var d = r.days[+bar.dataset.i]; if (!d) return;
    var kwh = d.wh / 1000, money = isNum(ENERGY.price) ? (kwh * ENERGY.price) : null;
    var share = total ? Math.round(d.wh / total * 100) : 0;
    tip.innerHTML = '<div class="etip-day">' + esc(dayLabel(d.day)) + '</div>'
      + '<div class="etip-main"><span class="etip-kwh">' + kwh.toFixed(2) + '<small>kWh</small></span>'
      + (money !== null ? '<span class="etip-money">' + money.toFixed(money >= 100 ? 0 : 1) + '<small>' + esc(ENERGY.cur || '') + '</small></span>' : '') + '</div>'
      + '<div class="etip-sub">' + share + '% of the last 30 days' + (d.wh === top && top > 0 ? ' \u00b7 the highest' : '') + '</div>';
    tip.hidden = false;
    var bx = bar.getBoundingClientRect(), wx = wrap.getBoundingClientRect();
    var left = bx.left - wx.left + bx.width / 2, half = Math.min(160, wx.width / 2);
    tip.style.left = Math.max(half, Math.min(wx.width - half, left)) + 'px';
    Array.prototype.forEach.call(wrap.querySelectorAll('.ebar.hot'), function (b) { b.classList.remove('hot'); });
    bar.classList.add('hot');
  };
  wrap.addEventListener('mouseover', function (e) { var bar = e.target.closest('.ebar'); if (bar) show(bar); });
  wrap.addEventListener('mouseleave', function () { tip.hidden = true; Array.prototype.forEach.call(wrap.querySelectorAll('.ebar.hot'), function (b) { b.classList.remove('hot'); }); });
  wrap.addEventListener('click', function (e) { var bar = e.target.closest('.ebar'); if (bar) show(bar); });   // touch
}
function dayLabel(iso) {
  // '2026-09-04' -> 'Fri 4 Sep' in the page's locale
  var m = /^(?:(\d{4})-)?(\d{2})-(\d{2})$/.exec(iso); if (!m) return iso;
  var now = new Date(), year = m[1] ? +m[1] : now.getFullYear();
  if (!m[1] && +m[2] - 1 > now.getMonth()) year -= 1;          // 'MM-DD' from the previous year
  var dt = new Date(year, +m[2] - 1, +m[3]);
  try { return dt.toLocaleDateString(undefined, {weekday: 'short', day: 'numeric', month: 'short'}); } catch (e) { return iso; }
}

// ---- restarting the energy summary --------------------------------------------------
function renderEnergyReset(st) {
  var host = $('energy-reset-buttons'); host.innerHTML = '';
  var plugs = st.plugs || [];
  $('energy-reset-card').hidden = !plugs.length;
  // by room, folded: two dozen buttons in one row is a wall to read
  var map = st.room_of || {}, rooms = {};
  (st.rooms || []).forEach(function (r) { rooms[r.id] = r.name; });
  var byRoom = {};
  plugs.forEach(function (p) { var name = rooms[map[p.name] || map[p.id]] || 'Not in a room'; (byRoom[name] = byRoom[name] || []).push(p); });
  var list = el('div', 'sections');
  Object.keys(byRoom).sort(function (a, b) {
    if ((a === 'Not in a room') !== (b === 'Not in a room')) return a === 'Not in a room' ? 1 : -1;
    return a.localeCompare(b);
  }).forEach(function (room) {
    var open = !!NOTIFY_OPEN['energy:' + room];
    var block = el('div', 'section' + (open ? ' open' : ''));
    var head = el('div', 'section-head');
    head.appendChild(el('span', 'fold', open ? '\u25be' : '\u25b8'));
    head.appendChild(el('span', 'section-name', (room === 'Not in a room' ? '\ud83d\udcc1 ' : ICON.heat + ' ') + room));
    head.appendChild(el('span', 'section-count', byRoom[room].length + (byRoom[room].length === 1 ? ' socket' : ' sockets')));
    head.onclick = function () { NOTIFY_OPEN['energy:' + room] = !open; renderEnergyReset(st); };
    block.appendChild(head);
    var body = el('div', 'section-body'), row = el('div', 'energy-reset-row');
    byRoom[room].forEach(function (p) { row.appendChild(energyResetButton(p)); });
    body.appendChild(row); block.appendChild(body);
    list.appendChild(block);
  });
  host.appendChild(list);
  energyResetTail(st, host, plugs);
}
function energyResetButton(p) {
  {
    var b = cmdButton(deviceIcon(Object.assign({source: 'plug'}, p)) + ' ' + p.name + ' \u2192 0', 'reset', 'small');
    b.title = 'Start the recorded sums for ' + p.name + ' from zero; the history itself stays';
    b.onclick = function () {
      withPin('Restart the energy summary', 'The sums for <b>' + esc(p.name) + '</b> start from zero, now. History stays.', function (pin) {
        return post('energy-reset', {plug: p.name, pin: pin}).then(function (r) { ENERGY.at = 0; return r.message; });
      });
    };
    return b;
  }
}
function energyResetTail(st, host, plugs) {
  if (plugs.length > 1) {
    var all = cmdButton('All plugs \u2192 0', 'reset', 'danger');
    all.onclick = function () {
      withPin('Restart every energy summary', 'The sums for <b>every plug</b> start from zero, now. History stays.', function (pin) {
        return post('energy-reset', {plug: '*', pin: pin}).then(function (r) { ENERGY.at = 0; return r.message; });
      });
    };
    var bar = el('div', 'btnrow'); bar.style.marginTop = '10px'; bar.appendChild(all);
    host.appendChild(bar);
  }
}

// ---- the tunable slice of config.json ----------------------------------------------
var SETTINGS = { dirty: false };
var SETTINGS_BOOL = { chart_outages: 1, link_plugs: 1, link_sensors: 1, link_buttons: 1, backup_enabled: 1, backup_zigbee: 1, silence_alert_buttons: 1,
                      watchdog: 1, route_watch: 1, mqtt_only: 1, debug: 1, debug_events: 1 };
var SETTINGS_TIME = { backup_time: 1 };
var SETTINGS_STEP = { price_per_kwh: '0.01', standing_charge_month: '0.01', heating_enforce_delta: '0.1', latitude: '0.000001', longitude: '0.000001', plug_min_request_gap: '0.05', plug_command_gap: '0.01' };
var SETTINGS_LAYOUT = [
  ['Alert thresholds', [['battery_warn', 'Battery warn (%)'], ['battery_crit', 'Battery crit (%)'],
    ['lqi_warn', 'LQI warn'], ['lqi_crit', 'LQI crit'],
    ['stale_warn_min', 'Quiet after (min) \u2014 amber on the dashboard, and the soonest an alert about it is sent'],
    ['stale_crit_min', 'Quiet for far too long (min) \u2014 red on the dashboard'],
    ['silence_alert_buttons', 'Silence quiet-alerts for buttons'],
    ['temperature_min', 'Temperature min (°C)'], ['temperature_max', 'Temperature max (°C)'], ['humidity_max', 'Humidity max (%)']]],
  ['Polling', [['plug_poll_interval', 'Plug poll (s)'], ['plug_sample_interval', 'Plug history sample (s)'],
    ['plug_min_request_gap', 'Gap between polls of one plug (s)'], ['plug_command_gap', 'Gap before a switch command (s)'],
    ['plug_keepalive_s', 'Use a box\u2019s open connection again if it was used this recently (s; 0 never). A box drops an idle connection without saying so, and writing into that costs a whole timeout, so this is short on purpose \u2014 it is for the four commands of one scene, not for the day'],
    ['plug_commands_at_once', 'How many switch commands one box may answer at once. One is right for nearly every box: they are sent one after another as fast as the box answers, which is usually quicker than asking it to juggle. Raise it only if yours is measurably happier with company'],
    ['sample_interval', 'Zigbee sample throttle (s)'], ['networkmap_interval', 'Network map (s, 0 = off)'],
    ['presence_fresh_s', 'Presence rule re-asks Wi-Fi if older than (s, -1 = never)']]],
  ['Money and place', [['price_per_kwh', 'Price per kWh'], ['standing_charge_month', 'Standing charge a month'],
    ['currency', 'Currency'], ['latitude', 'Latitude'], ['longitude', 'Longitude']]],
  ['Talking to the boxes', [['mqtt_only', 'A box set up for MQTT is driven over MQTT alone (no HTTP fallback)'],
    ['debug', 'Trace: write down everything \u2014 every HTTP request with the address, the body and what came back, every MQTT message either way, every wait for a box, each with the time to the millisecond. It is a lot of writing; turn it on to find something, off again after'],
    ['debug_events', 'And put the same in Events']]],
  ['Heating', [['preheat', 'Start early, so a room is warm when the plan says'],
    ['preheat_max_min', 'Never start more than this long before (min)'],
    ['preheat_default_rate', 'How fast a room heats until its own history says (\u00b0C an hour)'],
    ['weather', 'Ask open-meteo what it will be outside (no account needed)'],
    ['weather_name', 'What to call the forecast among the devices'],
    ['weather_interval_s', 'Ask for the forecast this often (s)'],
  ['weather_place', 'Where that is, in words (shown under the name; the reading itself follows latitude and longitude)'],
    ['heating_enforce', 'A head turned by hand \u2014 when to put the room\u2019s setting back'],
    ['manual_hold_s', 'How long a room set by hand keeps that setting before the plan takes over again (s)'],
    ['heating_enforce_delta', 'How far it has to have drifted before that counts (\u00b0C)'],
    ['heating_enforce_gap_s', 'Never tell the same head oftener than (s)'],
    ['heating_enforce_tries', 'Give up after this many tries, rather than flattening its battery']]],
  ['Watching over things', [['quiet_at_once', 'More than this many going quiet together is one message, not one each'],
    ['digest_at', 'One summary of the day at (HH:MM, empty for none)'],
    ['watchdog', 'Notice devices that go quiet'],
    ['binding_watch', 'Notice a sensor that has lost the Zigbee configuration telling it to report. Compared with the others of its own model, since there is no other way to know what it ought to have'],
    ['binding_mend', 'And ask for it back by itself, the moment that sensor next speaks \u2014 which is the only moment a sleeping one can hear. Off: it says so and waits for you to press the button'],
    ['binding_tries', 'How many times to ask before saying it will not take it (each try is one waking)'],
    ['mesh_churn_per_hour', 'Say something after this many leave the mesh in an hour (0 = never)'],
    ['silent_after_thermo', 'A thermometer is quiet after (s)'], ['silent_after_motion', 'A motion sensor is quiet after (s)'],
    ['silent_after_contact', 'A door contact is quiet after (s)'], ['silent_after_valve', 'A radiator head is quiet after (s)'],
    ['silent_after_button', 'A button is quiet after (s)'], ['silent_after_router', 'A router is quiet after (s)'],
    ['silent_after_sensor', 'Anything else is quiet after (s)'],
    ['route_watch', 'Follow which router a device goes through'],
    ['snapshots_keep', 'Versions kept before each Save (0 = off)']]],
  ['One-tap links', [
    ['public_url', 'Where the dashboard answers from outside \u2014 used to write out the one-tap links, e.g. https://home.example.net/index.php'],
    ['tap_mode', 'How a link may be opened. Its address carries the secret in the URL, where a web server log, a link preview and a browser history all keep it; a header carries the same secret in a POST, where none of them can. Move through \u201ceither way\u201d while the shortcuts are being changed over \u2014 nothing is thrown away, and switching back brings the old addresses straight back'],
    ['tap_code', 'And a second factor as well. A secret read out of a log a week later is then worth nothing on its own. Set the factor below up first, or this is refused'],
    ['tap_factor', 'Which second factor. A code is six digits from an authenticator on the phone, which the watch cannot produce \u2014 so a press from the wrist has to be finished on the phone. Duo pushes the question to the Duo app instead, which has a watch app of its own, so the press is approved where it was made'],
    ['duo_host', 'Duo: the API hostname from the Auth API application, e.g. api-1a2b3c4d.duosecurity.com'],
    ['duo_ikey', 'Duo: the integration key'],
    ['duo_skey', 'Duo: the secret key \u2014 kept by the daemon and never sent to this page'],
    ['duo_user', 'Duo: the username the push goes to'],
    ['duo_device', 'Duo: which of that user\u2019s devices \u2014 leave it as auto and Duo picks one of its own choosing, which on an account with three of them is as likely to be the iPad on a shelf. The list under One-tap links is easier than typing an id'],
    ['duo_wait_s', 'Duo: how long to wait for an answer before giving up (s)']]],
  ['Keeping addresses out', [
    ['retain_presses_days', 'How long the press log and the story of an address are kept (days). A link open to the internet writes a line for every press and every refusal'],
    ['debug_secrets', 'Show secrets whole in the debug log \u2014 a link\u2019s secret, a six-digit code, a token, a password on the way to a plug. Worth turning on while a one-tap link is being sorted out, since the shortening is in the way of exactly the thing being looked at, and worth turning off afterwards: the log then holds a working key'],
    ['never_block', 'Addresses that are never kept out, whatever else says otherwise \u2014 one each or whole ranges, of either family, comma separated, e.g. 192.168.1.0/24, 2a01:430::/48, 89.24.9.9. It beats a block made by hand as surely as one made by itself: an address here stays on the list to be seen, does nothing at all, and is never given to the router'],
    ['blacklist', 'The blacklist, all of it. Off means nothing is kept out and nothing of this is left on the router \u2014 the addresses are kept, and putting it back on fills the router again from them'],
    ['block_window_min', 'How long a span the weight is added up over (min)'],
    ['block_sensitivity', 'How keen it is: the same behaviour, a lower or a higher bar'],
    ['block_mode', 'Blocking an address that behaves like somebody trying things rather than like somebody opening a door. Off means nobody is ever blocked by itself; the list under Public API still works by hand'],
    ['block_minutes', 'How long a temporary block lasts (min)'],
    ['block_score', 'What earns one, weighed over the span above: a wrong secret counts 5, a wrong code 3, a shut road 3. Several <i>different</i> secrets add three each on top of that, and more than four tries in ten seconds two each \u2014 one wrong secret over and over is a shortcut nobody rewrote, a dozen different ones is somebody working through a list. 15 is three wrong secrets, or five wrong codes'],
    ['block_private', 'What to do about the house\u2019s own addresses. Never: a phone on the sofa with an old shortcut can go on refusing for ever and nothing happens. Gently: three times as much has to happen, and the block always runs out, so the family is never shut out for good. Same: treated like anybody else'],
    ['trusted_proxies', 'The address of a server in front, if there is one \u2014 several separated by commas, and a range like 10.8.0.0/24 works. Only from these is X-Forwarded-For believed; from anybody else it is a claim and the address they really came from is what counts'],
  ]],
  ['The router that carries the list', [
    ['mikrotik_host', 'Mikrotik: the router\u2019s address, so the blocked ones are dropped before they arrive. Empty means the router is not used at all'],
    ['mikrotik_port', 'Mikrotik: the SSH port'],
    ['mikrotik_user', 'Mikrotik: the user it logs in as \u2014 give it write access to firewall address lists and nothing else'],
    ['mikrotik_auth', 'Mikrotik: how it logs in'],
    ['mikrotik_password', 'Mikrotik: the password, when it logs in with one'],
    ['mikrotik_list', 'Mikrotik: the address list it works with \u2014 the same name in both /ip and /ipv6, since the router keeps those apart and each address goes where it belongs. Nothing outside this one list is ever read or written, and inside it only the entries this put there \u2014 every one carries a comment starting zigmon:, and nothing without it is ever removed'],
    ['mikrotik_sync', 'Mikrotik: keep the list on the router in step by itself. A change here reaches the router at once \u2014 an address blocked is a rule on the router a moment later, without waiting for anything'],
    ['mikrotik_every', 'Mikrotik: and look again how often, for blocks that ran out and for anything somebody changed on the router itself. The looking is cheap: one read, and nothing written unless the two disagree'],
  ]],
  ['Charts', [['chart_outages', 'Shade real outages'],
    ['link_plugs', 'Chart icon on plugs'], ['link_sensors', 'Chart icon on sensors'], ['link_buttons', 'Chart icon on buttons']]],
  ['Backups', [['backup_enabled', 'Daily backup'], ['backup_time', 'Backup time'],
    ['backup_keep', 'Keep (count)'], ['backup_zigbee', 'Include Zigbee2MQTT']]],
  ['Notification channels', [['notify_ntfy', 'ntfy topic URL'],
    ['notify_telegram_token', 'Telegram bot token'], ['notify_telegram_chat', 'Telegram chat id']]]
];
function renderSettings(st) {
  if (editorBusy('settings-grid')) return;
  if (SETTINGS.dirty) return;
  var rc = st.runtime_config || {};
  var host = $('settings-grid'); host.innerHTML = '';
  SETTINGS_LAYOUT.forEach(function (group) {
    var grid = el('div', 'set-grid');
    grid.appendChild(el('div', 'set-head', group[0]));
    group[1].forEach(function (pair) {
      var key = pair[0], info = rc[key] || {};
      // Settings that belong to a choice made above them are not drawn until
      // that choice is made. What they hold is kept either way, so turning
      // the second factor off and on again finds the Duo keys where they
      // were - they are simply not asked for while nothing uses them.
      // Which factor is a choice that stands on its own, and it is what makes
      // that factor's own boxes appear - so it is always there to be made.
      // Hidden until the factor was switched on, it could not be made at all:
      // Duo's boxes waited on the choice, and the choice waited on the boxes.
      // A box that belongs to a choice made above it is drawn either way and
      // shown or hidden as the choice is made, rather than left out and put
      // back by a redraw: a redraw throws away everything else typed and not
      // yet saved, so it is refused while anything is - and the password box
      // a person had just asked for by choosing "a password" never appeared.
      var onlyWhen = SETTINGS_WHEN[key] || null;
      var item = el('div', 'set-item' + (info.overridden ? ' overridden' : ''));
      if (onlyWhen) item.dataset.when = onlyWhen[0] + '=' + onlyWhen[1];
      var lbl = el('label', '', pair[1]);
      var fileNote = 'config.json says: ' + (info.file === null || info.file === undefined ? '(not set)' : info.file)
        + (info.overridden ? ' \u2014 overridden here' : '');
      var mark = function () { SETTINGS.dirty = true; $('settings-note').textContent = 'Unsaved changes'; };
      var box;
      // the daemon's word, with the old hand-kept list only as a fallback for
      // an older daemon; the list had fallen behind, so new yes-or-no settings
      // were coming out as number boxes
      if (info.kind === 'switch' || (!info.kind && SETTINGS_BOOL[key])) {
        var sw = makeSwitch(!!(info.value === null || info.value === undefined ? 0 : +info.value), mark, {title: fileNote});
        box = sw.input; box.dataset.k = key; box.dataset.bool = '1';
        item.classList.add('set-bool');
        item.appendChild(lbl); item.appendChild(sw);
      } else {
        // The daemon says what kind of thing each setting is, since it is the
        // one that checks them: a fixed set becomes a list, a time becomes a
        // clock, a password is not shown, and only a number gets a number box.
        if (info.kind === 'choice' && (info.choices || []).length) {
          box = el('select');
          var now = info.value === null || info.value === undefined ? '' : String(info.value);
          var choices = (info.choices || []).map(function (c) { return [c[0], c[1]]; });
          if (!choices.some(function (c) { return c[0] === now; })) choices.push([now, now + ' (as it stands)']);
          fillSelect(box, choices, now);
          box.dataset.k = key;
          box.title = fileNote;
          box.onchange = function () { mark(); applySettingsWhen(); };
          item.appendChild(lbl); item.appendChild(box);
          grid.appendChild(item);
          return;
        }
        box = el('input');
        if (info.kind === 'time' || SETTINGS_TIME[key]) box.type = 'time';
        else if (info.kind === 'secret' || /token/.test(key)) { box.type = 'password'; box.autocomplete = 'off'; }
        else if (info.kind === 'phone') box.type = 'tel';
        else if (info.kind === 'text' || (!info.kind && /currency|notify|chat|name|place/.test(key))) box.type = 'text';
        else {
          box.type = 'number';
          box.step = SETTINGS_STEP[key] || (info.kind === 'decimal' ? 'any'
            : (/interval|keep|warn|crit|min$|max$/.test(key) ? '1' : 'any'));
        }
        if (/token/.test(key)) box.autocomplete = 'off';
        // A secret is never put into its own box. The daemon stops saying
        // what one is - it says only whether it is set - so writing what it
        // says into the box put the word "true" there, and saving wrote that
        // word over the secret. Empty means keep the one it has, which is how
        // the SMS card has always done it.
        if (info.kind === 'secret') {
          box.value = '';
          box.placeholder = info.value ? '(kept)' : '';
          box.dataset.secret = '1';
        } else {
          box.value = info.value === null || info.value === undefined ? '' : info.value;
        }
        box.dataset.k = key;
        box.title = fileNote;
        box.oninput = mark;
        item.appendChild(lbl); item.appendChild(box);
      }
      grid.appendChild(item);
    });
    host.appendChild(grid);
    // The key the router is reached with belongs beside the router's own
    // boxes, not on the page where addresses are kept out - the same place
    // the access points keep theirs.
    if (group[0] === 'The router that carries the list') {
      host.appendChild(mikrotikPanel());
      var keybox = mikrotikKeyPanel();       // shown while a key is what it logs in with
      keybox.dataset.when = 'mikrotik_auth=key';
      host.appendChild(keybox);
    }
  });
  applySettingsWhen();
  $('settings-note').textContent = '';
}
// Which boxes belong to which choice, in one place, so the answer is the same
// whether the page has just been built or a choice has just been made.
var SETTINGS_WHEN = {
  mikrotik_password: ['mikrotik_auth', 'password'],
  duo_host: ['tap_factor', 'duo'], duo_ikey: ['tap_factor', 'duo'],
  duo_skey: ['tap_factor', 'duo'], duo_user: ['tap_factor', 'duo'],
  duo_device: ['tap_factor', 'duo'], duo_wait_s: ['tap_factor', 'duo']
};
function applySettingsWhen() {
  var grid = $('settings-grid'); if (!grid) return;
  var now = function (key) {
    var box = grid.querySelector('[data-k="' + key + '"]');
    return box ? String(box.value) : '';
  };
  Array.prototype.forEach.call(grid.querySelectorAll('[data-when]'), function (item) {
    var parts = String(item.dataset.when).split('=');
    item.hidden = now(parts[0]) !== parts[1];
  });
}
$('settings-save').onclick = function () {
  var body = {};
  Array.prototype.forEach.call($('settings-grid').querySelectorAll('input[data-k], select[data-k]'), function (b) {
    if (b.dataset.secret && b.value === '') return;      // left alone: it keeps the one it has
    body[b.dataset.k] = b.dataset.bool ? (b.checked ? 1 : 0) : (b.value === '' ? null : b.value);
  });
  withPin('Save settings', 'They apply immediately; no restart.', function (pin) {
    body.pin = pin;
    return post('config-save', body).then(function (r) {
      SETTINGS.dirty = false; forgetSig('settings');
      STATE._ovLoaded = 0;                 // redraw charts at once if a chart setting changed
      if (STATE.tab === 'history') loadHistory();
      // the daemon sometimes has to say what it did with a setting beyond
      // saving it - a factor demanded before anything can answer it, say
      if (r.note) return r.note;
      return (r.changed || []).length ? 'Changed: ' + r.changed.join(', ') : 'Nothing changed';
    });
  });
};


// ---- database: check, optimise, back up, restore; and how fast it all is ------------
var DB = { backups: null, apiMs: null };
function sizeText(bytes) { return bytes >= 1048576 ? (bytes / 1048576).toFixed(1) + ' MB' : Math.round(bytes / 1024) + ' KB'; }
function renderDbInfo(h) {
  var host = $('db-info'); host.innerHTML = '';
  var db = h.db || {};
  var lat = function (ms) { return ms === undefined || ms === null ? '?' : (ms < 1 ? ms.toFixed(2) : ms.toFixed(1)) + ' ms'; };
  [['File', (db.path || '?') + ' — ' + (db.file_bytes !== undefined && db.file_bytes !== null ? sizeText(db.file_bytes) : (db.bytes ? sizeText(db.bytes) : '?'))
      + (db.wal_bytes ? ' + ' + sizeText(db.wal_bytes) + ' journal' : '')],
   ['Rows', db.samples + ' samples · ' + db.samples_hourly + ' hourly · ' + db.events + ' events'],
   ['Oldest data', db.oldest ? stamp(db.oldest) : '–'],
   ['Last roll-up', h.last_aggregate ? ago(parseInt(h.last_aggregate, 10)) : 'not yet'],
   ['DB latency', 'read ' + lat(db.read_ms) + ' · write ' + lat(db.write_ms)],
   ['App latency', 'browser → daemon → back ' + (DB.apiMs === null ? '?' : lat(DB.apiMs)) + (h.api_ms !== undefined ? ' · daemon internal ' + lat(h.api_ms) : '')]
  ].forEach(function (pair) {
    var row = el('div', 'kv'); row.innerHTML = '<span class="k">' + esc(pair[0]) + '</span><span class="v">' + esc(pair[1]) + '</span>'; host.appendChild(row);
  });
}
function loadDbBackups() {
  api('db-backups').then(function (r) {
    DB.backups = r.backups || [];
    paintDbBackups();
    $('db-note').textContent = r.dir ? 'Backups live in ' + r.dir : '';
  }, function () {});
}
function paintDbBackups() {
  var host = $('db-backups'); host.innerHTML = '';
  var list = DB.backups || [];
  if (!list.length) { host.appendChild(el('div', 'muted small', 'No database backup yet.')); return; }
  var head = el('div', 'dbb-row dbb-head');
  ['When', 'File', 'Size', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  list.forEach(function (b) {
    var row = el('div', 'dbb-row');
    row.appendChild(el('span', '', stamp(b.ts)));
    var f = el('span', 'mono small', b.file); f.title = b.file; row.appendChild(f);
    row.appendChild(el('span', '', sizeText(b.bytes)));
    var acts = el('span', 'dbb-acts');
    var dl = cmdButton('Download', 'download', 'small'); dl.classList.remove('needs-unlock');
    dl.title = 'Fetch this backup to the machine you are sitting at';
    dl.onclick = function () {
      if (!isUnlocked() || !LOCK.token) { unlockFlow(function () { dl.onclick(); }); return; }
      var a = document.createElement('a'); a.href = 'index.php?api=db-backup-download&file=' + encodeURIComponent(b.file) + '&session=' + encodeURIComponent(LOCK.token);
      a.download = b.file; document.body.appendChild(a); a.click(); a.remove();
    };
    var rs = cmdButton('Restore', 'reset', 'small danger');
    rs.title = 'Put the whole database back as it was in this backup \u2014 everything recorded since is lost';
    rs.onclick = function () {
      withDangerConfirm('Restore the database', 'Everything \u2014 history, events, bindings, rules, scenes, settings \u2014 is <b>replaced</b> by <b>' + esc(b.file) + '</b>. The state right before is saved as its own backup first.', function (pin) {
        return post('db-restore', {file: b.file, pin: pin}).then(function (r) { loadDbBackups(); BINDINGS.rows = RULES.rows = MANAGED.rows = SCENES.rows = SEQUENCES.rows = SCHEDULES.rows = null; SIGS = {}; return 'Restored ' + r.restored + '; the previous state is ' + r.previous_saved_as; });
      });
    };
    var del = cmdButton('Delete', 'trash', 'small danger');
    del.onclick = function () {
      withPin('Delete ' + b.file, 'The backup file is removed from the server. The live database is untouched.', function (pin) {
        return post('db-backup-delete', {file: b.file, pin: pin}).then(function (r) { DB.backups = r.backups || []; paintDbBackups(); return 'Deleted ' + r.deleted; });
      });
    };
    [dl, rs, del].forEach(function (x) { acts.appendChild(x); });
    row.appendChild(acts);
    host.appendChild(row);
  });
}
// upload: read the file in the browser, send it in pieces the web server accepts
$('db-upload').onclick = function () { $('db-upload-file').value = ''; $('db-upload-file').click(); };
$('db-upload-file').onchange = function () {
  var file = this.files && this.files[0]; if (!file) return;
  // piece sizes to try, largest first; a web server that refuses one (HTTP 413,
  // an nginx client_max_body_size still at its old value) gets the next smaller
  var LADDER = [2 * 1024 * 1024, 512 * 1024, 128 * 1024, 40 * 1024, 10 * 1024];
  var prog = $('db-upload-progress');
  withPin('Upload ' + file.name, sizeText(file.size) + ', sent in pieces. The file is checked to be a healthy zigmon database before it joins the list.', function (pin) {
    var attempt = function (level) {
      var CHUNK = LADDER[level], parts = Math.max(1, Math.ceil(file.size / CHUNK));
      if (parts > 4000) return Promise.reject(new Error('the web server only accepts ' + sizeText(CHUNK) + ' per request; that would take ' + parts + ' requests. Raise client_max_body_size in nginx to 6m and try again.'));
      var uid = Math.random().toString(36).slice(2, 14) + Date.now().toString(36), i = 0;
      var next = function () {
        var blob = file.slice(i * CHUNK, (i + 1) * CHUNK);
        return new Promise(function (resolve, reject) {
          var rd = new FileReader();
          rd.onerror = function () { reject(new Error('could not read the file')); };
          rd.onload = function () {
            var b64 = String(rd.result).split(',')[1] || '';
            post('db-backup-upload', {name: file.name, part: i + 1, of: parts, data: b64, upload_id: uid, pin: pin}).then(function (r) {
              i += 1; prog.textContent = 'uploading\u2026 ' + Math.round(i / parts * 100) + '% (' + sizeText(CHUNK) + ' pieces)';
              if (r.file) { prog.textContent = ''; DB.backups = r.backups || DB.backups; paintDbBackups(); resolve('Uploaded ' + r.file + ' (' + sizeText(r.bytes) + ')'); }
              else next().then(resolve, reject);
            }, function (e) {
              var tooBig = e.status === 413 || /too large|413/i.test(e.message || '');
              if (tooBig && level + 1 < LADDER.length && i === 0) { prog.textContent = 'server refused ' + sizeText(CHUNK) + ' pieces, trying smaller\u2026'; attempt(level + 1).then(resolve, reject); }
              else { prog.textContent = ''; reject(e); }
            });
          };
          rd.readAsDataURL(blob);
        });
      };
      return next();
    };
    return attempt(0);
  });
};
// A database job on a large file takes long enough that silence reads as a
// dead button. Show that it is running, how long for, and what the daemon
// says about it while it works.
var DBRUN = {timer: null, poll: null, since: ''};
function dbRunStart(what, prefix) {
  prefix = prefix || 'db';
  var box = $(prefix + '-run');
  box.hidden = false; box.classList.remove('done', 'failed');
  $(prefix + '-run-what').textContent = what + '\u2026';
  $(prefix + '-run-log').textContent = '';
  var began = Date.now();
  $(prefix + '-run-time').textContent = '0.0 s';
  clearInterval(DBRUN.timer);
  DBRUN.timer = setInterval(function () {
    $(prefix + '-run-time').textContent = ((Date.now() - began) / 1000).toFixed(1) + ' s';
  }, 100);
  DBRUN.since = '';
  var pull = function () {
    api('log&lines=40' + (DBRUN.since ? '&since=' + encodeURIComponent(DBRUN.since) : '')).then(function (r) {
      var lines = (r && r.lines) || [];
      if (!lines.length) return;
      DBRUN.since = lines[lines.length - 1];
      var pre = $(prefix + '-run-log');
      pre.textContent = (pre.textContent + (pre.textContent ? '\n' : '') + lines.join('\n')).split('\n').slice(-200).join('\n');
      pre.scrollTop = pre.scrollHeight;
    }, function () {});
  };
  pull();
  clearInterval(DBRUN.poll);
  DBRUN.poll = setInterval(pull, 900);
  return function finish(ok, text) {
    clearInterval(DBRUN.timer); clearInterval(DBRUN.poll);
    setTimeout(pull, 300);                       // catch the last thing it logged
    box.classList.add(ok ? 'done' : 'failed');
    $(prefix + '-run-what').textContent = text;
    $(prefix + '-run-time').textContent = 'took ' + ((Date.now() - began) / 1000).toFixed(1) + ' s';
  };
}
function dbJob(button, what, blurb, action, describe, prefix) {
  withPin(what, blurb, function (pin) {
    var finish = dbRunStart(what, prefix);
    return post(action, {pin: pin}).then(function (r) {
      var text = describe(r);
      finish(true, text);
      return text;
    }, function (e) {
      finish(false, (e && e.message) || 'failed');
      throw e;
    });
  });
}
$('db-check').onclick = function () {
  dbJob(this, 'Check the database', 'SQLite integrity check; read-only, a few seconds at most.', 'db-check',
    function (r) { return r.ok && r.lines && r.lines[0] === 'ok' ? 'Database is healthy' : 'Problems: ' + (r.lines || []).join('; '); });
};
$('db-optimize').onclick = function () {
  dbJob(this, 'Optimise the database', 'ANALYZE + VACUUM. Writes pause while it runs; a large file can take a minute.', 'db-optimize',
    function (r) { return 'Optimised: ' + sizeText(r.before_bytes) + ' \u2192 ' + sizeText(r.after_bytes) + ' in ' + r.seconds + ' s'; });
};
$('db-backup').onclick = function () {
  dbJob(this, 'Back up the database', 'A consistent copy of the whole file, taken while the daemon keeps running.', 'db-backup',
    function (r) { loadDbBackups(); return 'Backed up: ' + r.file + ' (' + sizeText(r.bytes) + ')'; });
};
// counts first, removes only when asked again: nobody should delete history
// on one click, however worthless the rows turn out to be
$('db-prune').onclick = function () {
  dbJob(this, 'Look for noise', 'Counts the readings that carry nothing \u2014 the hardware\'s own identity and counters\' reset stamps, and gateway values written again unchanged. Removes nothing yet.', 'db-prune',
    function (r) {
      var total = r.bookkeeping_rows + r.repeated_rows;
      if (!total) return 'Nothing to clear out';
      PRUNE_FOUND = r;
      setTimeout(function () {
        withDangerConfirm('Remove ' + total.toLocaleString() + ' readings',
          '<b>' + r.bookkeeping_rows.toLocaleString() + '</b> bookkeeping values and <b>' + r.repeated_rows.toLocaleString() + '</b> unchanged repeats. Measurements that ever moved are untouched, and this cannot be undone \u2014 take a backup first if in doubt.',
          function (pin) {
            var finish = dbRunStart('Clear out noise');
            return post('db-prune', {apply: true, pin: pin}).then(function (x) {
              var text = 'Removed ' + (x.bookkeeping_rows + x.repeated_rows).toLocaleString() + ' readings: '
                + sizeText(x.before_bytes) + ' \u2192 ' + sizeText(x.after_bytes);
              finish(true, text); loadDbBackups(); return text;
            }, function (e) { finish(false, (e && e.message) || 'failed'); throw e; });
          });
      }, 400);
      return 'Found ' + total.toLocaleString() + ' readings worth nothing \u2014 confirm to remove them';
    });
};
var PRUNE_FOUND = null;
var STALE = null;
$('stale-scan').onclick = function () {
  dbJob(this, 'Look for leftovers', 'Counts what is still recorded for devices this dashboard no longer shows, and which topics the broker is still replaying for them. Removes nothing.', 'db-stale',
    function (r) {
      STALE = r;
      renderForgetSelect(STATE.status);
      $('stale-drop').hidden = !(r.devices || []).length;
      var said = [];
      if ((r.devices || []).length) {
        var top = r.devices.slice(0, 3).map(function (x) { return x.name + ' (' + x.rows.toLocaleString() + ')'; });
        said.push(r.rows.toLocaleString() + ' readings from ' + r.devices.length + ' device(s) that are gone \u2014 '
          + top.join(', ') + (r.devices.length > 3 ? ', \u2026' : ''));
      }
      post('ghosts', {}).then(function (g) {
        GHOSTS = (g && g.topics) || [];
        $('ghost-clear').hidden = !GHOSTS.length;
        if (GHOSTS.length) {
          var pre = $('rec-run-log');
          pre.textContent += (pre.textContent ? '\n' : '') + 'the broker is still replaying: ' + GHOSTS.join(', ');
        }
      }, function () {});
      return said.length ? said.join(' \u00b7 ') : 'Nothing left over';
    }, 'rec');
};
var GHOSTS = [];
$('ghost-clear').onclick = function () {
  dbJob(this, 'Clear what the broker keeps replaying',
    'Deletes the messages the broker holds for devices Zigbee2MQTT no longer has, so they stop coming back. Nothing recorded here is touched.', 'ghosts-clear',
    function (r) {
      if (r.refused && r.refused.length) {
        $('ghost-clear').hidden = false;
        throw new Error(r.message || 'the broker refused');
      }
      GHOSTS = []; $('ghost-clear').hidden = true;
      return r.message || 'cleared';
    }, 'rec');
};
$('stale-drop').onclick = function () {
  if (!STALE || !(STALE.devices || []).length) { toast('Look for leftovers first', false); return; }
  withDangerConfirm('Erase every leftover',
    '<b>' + STALE.rows.toLocaleString() + '</b> readings from <b>' + STALE.devices.length + '</b> device(s) the dashboard no longer shows. Nothing that belongs to a device still in use is touched. This cannot be undone.',
    function (pin) {
      var finish = dbRunStart('Erase every leftover', 'rec');
      return post('db-stale-drop', {pin: pin}).then(function (r) {
        var text = 'Erased ' + r.rows.toLocaleString() + ' readings from ' + r.devices + ' device(s): '
          + sizeText(r.before_bytes) + ' \u2192 ' + sizeText(r.after_bytes);
        finish(true, text); STALE = null; $('stale-drop').hidden = true;
        tick(true); loadDbBackups();
        return text;
      }, function (e) { finish(false, (e && e.message) || 'failed'); throw e; });
    });
};

// ---- editing sessions ---------------------------------------------------------------
function renderSessions() {
  var card = $('sessions-card');
  if (!isUnlocked()) { card.hidden = true; return; }
  if (Date.now() - (renderSessions.at || 0) < 5000) return;   // an admin list, not worth a request every tick
  renderSessions.at = Date.now();
  post('sessions', {}).then(function (r) {
    var list = r.sessions || [];
    card.hidden = false;
    $('sessions-list').innerHTML = list.length
      ? list.map(function (x) { return esc(x.client || '?') + ' — until ' + esc(stamp(x.until)); }).join('<br>')
      : 'No active session.';
  }, function () { card.hidden = true; });
}
$('lock-all').onclick = function () {
  withDangerConfirm('Lock all sessions', 'Every unlocked browser, this one included, goes back behind the PIN.', function (pin) {
    return post('lock-all', {pin: pin}).then(function (r) { setLocked(''); return r.message; });
  });
};


// ---- Zigbee gateways (SLZB-06 etc): read over the network for their own health -----
var GATEWAYS = { rows: null, dirty: false };
function markGateways() { GATEWAYS.dirty = true; $('gateway-note').textContent = 'Unsaved changes'; }
function renderGateways(st) {
  if (GATEWAYS.dirty) return;                    // unsaved edits anywhere in the table: leave it alone
  if (editorBusy('gateways-list')) return;
  GATEWAYS.rows = (st.gateways || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
  paintGateways(st);
  setTimeout(markHeaderIndent, 0);       // the packs and their handles exist now
}
// Everything a binding, a rule or a presence trigger can point at. One list,
// so a target added in one place shows up in all of them.
function targetOptions(st, current) {
  var plugs = st.plugs || [];
  var out = plugs.filter(function (p) { return !p.monitor_only; })
    .map(function (p) { return [p.name, withIcon(plugRoleKind(p), p.name + (p.online ? '' : ' (unreachable)'))]; });
  (st.switch_targets || []).forEach(function (t) { if (t.value.indexOf('heat:') === 0) return; out.push([t.value, withIcon('zb', t.name + (t.online ? '' : ' (offline)'))]); });
  (st.scenes || []).forEach(function (sc) { out.push(['scene:' + sc.id, withIcon('scene', sc.name)]); });
  heatingTargetOptions(st).forEach(function (o) { out.push(o); });
  sequenceTargetOptions(st).forEach(function (o) { out.push(o); });
  // sockets and lights are both relays, but "everything off" at bedtime
  // should not take the fridge with it
  var sockets = plugs.filter(function (p) { return (p.role || 'plug') !== 'light'; });
  var lamps = plugs.filter(function (p) { return (p.role || 'plug') === 'light'; });
  if (sockets.length > 1) out.push(['*', withIcon('all', 'all sockets')]);
  if (lamps.length > 1) out.push(['*lights', withIcon('light', 'all lights')]);
  out.push(['notify', ICON.bell + ' notify me (automatic text)']);
  // the same automatic text, but down one road only
  out.push(['notify@ntfy', ICON.bell + ' notify me \u2014 ntfy only']);
  out.push(['notify@telegram', ICON.bell + ' notify me \u2014 Telegram only']);
  out.push(['notify@sms', ICON.bell + ' notify me \u2014 text only']);
  // things the house does to itself: a button by the door can hush the alerts
  // for an hour, take a backup, or make everything say where it stands
  out.push(['sys:quiet:1h', '\ud83d\udd15 hush the alerts for an hour']);
  out.push(['sys:quiet:8h', '\ud83d\udd15 hush the alerts overnight']);
  out.push(['sys:clear', '\u2713 clear the standing alerts']);
  out.push(['sys:refresh', '\u21bb ask everything where it stands']);
  out.push(['sys:backup', '\ud83d\udcbe take a backup now']);
  out.push(['sys:digest', '\ud83d\udcc4 send the daily summary now']);
  (((st.presence || {}).people) || []).forEach(function (p) {
    // presence calls the number "number"; "phone" there means what their
    // phone last said about being home
    if (p.number) out.push(['notify@sms:' + p.id, ICON.bell + ' text ' + p.name]);
  });
  (st.messages || []).forEach(function (m) { out.push(['notify:' + m.id, ICON.bell + ' ' + m.name]); });
  // the automation itself can be switched, which is how "the bedroom buttons
  // do nothing while we are away" is said without editing anything
  // being at home is a target too: a button by the door, a rule, or a text
  ((st.presence || {}).people || []).forEach(function (p) {
    out.push(['who:' + p.id, ICON.person + ' ' + p.name + ' \u2014 home or away']);
  });
  out.push(['who:me', ICON.person + ' whoever sent the message \u2014 home or away']);
  (st.action_groups || []).forEach(function (g) {
    out.push(['act:' + g.id, ICON.agroup + ' ' + g.name + ' (' + (g.members || []).length + ')' + (g.enabled === false ? ' (off)' : '')]);
  });
  (st.switchable_targets || []).forEach(function (t) { out.push([t.value, ICON.autoswitch + ' ' + t.name + (t.on ? '' : ' (off)')]); });
  if (current && current !== '*' && !out.some(function (o) { return o[0] === current; })) {
    out.push([current, withIcon(targetKind(current), current + ' (disabled)')]);
  }
  return sortByKind(out);
}
// Heating as something to switch: the control itself, the away mode, and
// each room's level.
function heatingTargetOptions(st) {
  var out = [['heat:control', withIcon('heat', 'heating control')], ['heat:away', withIcon('heat', 'heating away mode')]];
  var heat = (st.heating || {}).rooms || [];
  (st.rooms || []).forEach(function (r) {
    var h = heat.filter(function (x) { return x.id === r.id; })[0];
    if (h && h.heated === false) return;
    out.push(['heat:temp:' + r.id, withIcon('heat', 'temperature in ' + r.name)]);
    out.push(['heat:room:' + r.id, withIcon('heat', 'heating in ' + r.name)]);
    out.push(['heat:control:' + r.id, withIcon('heat', 'heating control in ' + r.name)]);
  });
  return out;
}
function targetOptionsForGateway(st) {
  // 'coordinator' is its own entry; the coordinator's device record must not
  // appear a second time under its name, or the two look like a choice when
  // they are the same thing
  var out = [];
  (st.devices || []).forEach(function (d) {
    if (d.source === 'plug' || d.id === 'gw:coordinator' || d.kind === 'Coordinator') return;
    out.push([d.name, deviceIcon(d) + ' ' + d.name]);
  });
  return [['coordinator', withIcon('coordinator', 'the coordinator')]].concat(sortByKind(out));
}
function paintGateways(st) {
  var host = $('gateways-list'); host.innerHTML = '';
  var rows = GATEWAYS.rows || [];
  if (!rows.length) host.appendChild(el('div', 'muted small', 'No gateway yet — most setups don\u2019t need one; add it only if you want a router or coordinator\u2019s own network health on the dashboard.'));
  else {
    var head = el('div', 'gw-row gw-head');
    ['Name', 'Address', 'Username', 'Password', 'Target', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
    host.appendChild(head);
  }
  var targetOptions = targetOptionsForGateway(st);
  rows.forEach(function (g, i) {
    var fromConfig = g.source === 'config';
    var row = el('div', 'gw-row');
    var name = el('input'); name.value = g.name || ''; name.placeholder = 'Router'; name.disabled = fromConfig;
    name.oninput = function () { g.name = name.value; markGateways(); };
    var host2 = el('input'); host2.value = g.host || ''; host2.placeholder = '192.168.1.51'; host2.disabled = fromConfig;
    host2.oninput = function () { g.host = host2.value; markGateways(); };
    var user = el('input'); user.value = g.username || ''; user.placeholder = '(none)'; user.disabled = fromConfig;
    user.oninput = function () { g.username = user.value; markGateways(); };
    var pw = el('input'); pw.type = 'password'; pw.placeholder = g.password_set ? '(kept)' : '(none)'; pw.disabled = fromConfig;
    pw.oninput = function () { g.password = pw.value; markGateways(); };
    var target = el('select'); target.disabled = fromConfig;
    var opts = targetOptions.slice();
    if (g.target && !opts.some(function (o) { return o[0] === g.target; })) opts.push([g.target, g.target + ' (not seen yet)']);
    g.target = fillSelect(target, opts, g.target || 'coordinator');
    target.onchange = function () { g.target = target.value; markGateways(); };
    if (fromConfig) [name, host2, user, pw].forEach(function (x) { x.style.opacity = '.55'; });
    var detect = cmdButton('Detect', 'search', 'small'); detect.classList.remove('needs-unlock');
    attachHint(detect, '<b>/ha_info</b> and <b>/ha_sensors</b> from the server to this address.<br>Reads the model, firmware, Zigbee radio and mode (coordinator / router), fills the name if empty and suggests the target. Asks for the PIN.');
    detect.onclick = function () {
      if (!host2.value) { toast('Address first', false); return; }
      detect.disabled = true; detect.classList.add('busy');
      withPin('Detect ' + host2.value, 'The daemon asks the gateway at <b>' + esc(host2.value) + '</b> what it is.', function (pin) {
        return post('gateway-detect', {host: host2.value, username: user.value, password: pw.value, pin: pin}).then(function (r) {
          g.model = r.model || g.model; g.fw = r.fw || g.fw; g.kind = r.kind || g.kind;
          if (!g.name && (r.hostname || r.model)) g.name = (r.hostname || r.model).replace(/[^A-Za-z0-9 _.-]/g, '').slice(0, 40);
          if (r.mode === 'coordinator') g.target = 'coordinator';
          else if (r.mode === 'router' && (!g.target || g.target === 'coordinator')) {
            // a router shows on the mesh as a device: prefer one with a matching MAC/model, else the only Router
            var routers = (STATE.status.devices || []).filter(function (d) { return d.kind === 'Router' && d.source !== 'plug'; });
            var byModel = r.model ? routers.filter(function (d) { return d.model && r.model && d.model.indexOf(r.model) >= 0; }) : [];
            if (byModel.length === 1) g.target = byModel[0].name;
            else if (routers.length === 1) g.target = routers[0].name;
          }
          markGateways(); paintGateways(STATE.status);
          var proto = r.kind === 'shelly' ? 'Shelly RPC' : 'SLZB-style HTTP';
          return (r.model || '?') + (r.fw ? ' \u00b7 ' + r.fw : '') + ' \u00b7 ' + proto + (r.mode ? ' \u00b7 ' + r.mode : '') + (r.zb_hw ? ' \u00b7 ' + r.zb_hw : '') + (r.zb_channel !== null && r.zb_channel !== undefined ? ' \u00b7 ch ' + r.zb_channel : '') + ' \u00b7 ' + r.fields + ' fields';
        });
      });
      setTimeout(function () { detect.disabled = false; detect.classList.remove('busy'); }, 3000);
    };
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    if (fromConfig) { del.disabled = true; del.title = 'Remove it from config.json instead'; }
    else del.onclick = function () { GATEWAYS.rows.splice(i, 1); markGateways(); paintGateways(STATE.status); };
    var btns = el('span', 'gw-btns'); btns.appendChild(detect); btns.appendChild(del);
    if (fromConfig) { var tag = el('span', 'tag dim', 'config.json'); tag.style.marginLeft = '4px'; btns.appendChild(tag); }
    [name, host2, user, pw, target, btns].forEach(function (x) { row.appendChild(x); });
    var gwPack = el('div', 'gw-pack');
    if (!fromConfig) makeRowSortable(gwPack, host, GATEWAYS, markGateways, function () { paintGateways(STATE.status); }, g);
    gwPack.appendChild(row);
    host.appendChild(gwPack);
    if (g.model || g.fw) {
      var info = el('div', 'gw-info');
      var protoLabel = g.kind === 'shelly' ? 'Shelly RPC' : 'SLZB-style HTTP';
      info.innerHTML = withIcon('gateway', esc(g.model || '?')) + (g.fw ? ' <span class="dim">\u00b7 ' + esc(g.fw) + '</span>' : '') + ' <span class="dim">\u00b7 ' + esc(protoLabel) + '</span>';
      gwPack.appendChild(info);
    }
  });
  if (!GATEWAYS.dirty) $('gateway-note').textContent = '';
  setTimeout(function () { sizeGatewayButtons(); markHeaderIndent(); }, 0);
}
// A column left to size itself by what it holds is answered once per row,
// because every row on this page is a grid of its own: the header's last cell
// is empty and asks for nothing, so the columns above the boxes take the room
// the buttons need in the rows and every name walks right. Measured here from
// the widest one on the page and handed to the header and to all of them, so
// they stand in one line. Measured and not stated: the words on a button are
// as wide as the font and the language make them, and a stated width is what
// hung the gateway buttons out past the card edge before.
function shareColumn(host, cell, name) {
  if (!host) return;
  host.style.removeProperty(name);               // back to its content, then read it
  var want = 0;
  Array.prototype.forEach.call(host.querySelectorAll(cell), function (c) {
    want = Math.max(want, Math.ceil(c.getBoundingClientRect().width));
  });
  if (want > 0) host.style.setProperty(name, want + 'px');
}
function sizeGatewayButtons() { shareColumn($('gateways-list'), '.gw-btns', '--gw-btns'); }
function sizeTapTools() { shareColumn($('taps-list'), '.tap-tools', '--tap-tools'); }
$('gateway-add').onclick = function () {
  GATEWAYS.rows = GATEWAYS.rows || [];
  GATEWAYS.rows.push({name: '', host: '', username: '', password: '', target: 'coordinator', source: 'ui'});
  markGateways(); paintGateways(STATE.status);
};
$('gateway-save').onclick = function () {
  var editable = (GATEWAYS.rows || []).filter(function (g) { return g.source !== 'config'; }).map(function (g) {
    return {name: g.name, host: g.host, username: g.username || '', password: g.password || '', target: g.target || 'coordinator', model: g.model || '', fw: g.fw || '', kind: g.kind || 'slzb'};
  });
  withPin('Save gateways', 'Takes effect at once; the next poll uses the new settings.', function (pin) {
    return post('gateways-save', {gateways: editable, pin: pin}).then(function (r) {
      GATEWAYS.dirty = false; GATEWAYS.rows = null; forgetSig('gateways');
      return (r.gateways || []).length + ' gateway(s) saved';
    });
  });
};

// ---- sequences: one trigger, a different scene every press, around and around ------
var SEQUENCES = { rows: null, dirty: false };
function markSequences() { SEQUENCES.dirty = true; $('sequence-note').textContent = 'Unsaved changes'; }
function renderSequences(st) {
  if (SEQUENCES.dirty) return;                    // unsaved edits anywhere in the table: leave it alone
  if (editorBusy('sequences-list')) return;
  if (SEQUENCES.rows === null) {
    api('sequences').then(function (r) {
      if (SEQUENCES.dirty) return;
      SEQUENCES.rows = (r.sequences || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
      SEQUENCES.positions = r.positions || {};
      paintSequences(st);
    }, function () {});
    return;
  }
  paintSequences(st);
}
function paintSequences(st) {
  var host = $('sequences-list'); host.innerHTML = '';
  var rows = SEQUENCES.rows || [];
  var scenes = (SCENES.rows && !SCENES.dirty ? SCENES.rows : null) || [];
  var sceneOptions = sortByKind((st.scenes || []).map(function (sc) { return [sc.id, withIcon('scene', sc.name)]; }));
  if (!rows.length) host.appendChild(el('div', 'muted small', 'No sequence yet.'));
  var live = {}; (st.sequences || []).forEach(function (x) { live[x.id] = x; });
  rows.forEach(function (sq, i) {
    var row = el('div', 'seq-row');
    var name = el('input'); name.value = sq.name || ''; name.placeholder = 'Lamp';
    name.oninput = function () { sq.name = name.value; markSequences(); };
    var steps = el('div', 'seq-steps');
    sq.steps = sq.steps || [];
    var pos = live[sq.id] ? live[sq.id].pos : 0;
    // a step is a scene, or any single target with an action ("<target>|<do>")
    var targetOpts = targetOptions(st, null).filter(function (o) { return o[0] !== '*' && o[0].indexOf('scene:') !== 0 && o[0].indexOf('seq') !== 0; });
    var stepOpts = sceneOptions.slice().concat(targetOpts);
    sq.steps.forEach(function (sid, j) {
      var line = el('div', 'step' + (j === pos && !SEQUENCES.dirty ? ' next' : ''));
      line.appendChild(el('span', 'n', (j + 1) + '.'));
      var sel = el('select');
      var isScene = sceneOptions.some(function (o) { return o[0] === sid; });
      var stepTarget = isScene ? sid : String(sid || '').split('|')[0];
      var stepDo = isScene ? '' : (String(sid || '').split('|')[1] || 'on');
      var opts = stepOpts.slice();
      if (stepTarget && !opts.some(function (o) { return o[0] === stepTarget; })) opts.push([stepTarget, '(gone)']);
      fillSelect(sel, opts, stepTarget);
      var doSel = el('select'), setBox = setValueBox(st, null, function (v) { stepDo = v; sq.steps[j] = stepTarget + '|' + v; markSequences(); });
      var stepNote = el('span', 'muted small', 'sends the message');
      stepNote.title = 'Nothing is switched \u2014 what it says is set under Alerts';
      function refillStepDo() {
        var scene = sceneOptions.some(function (o) { return o[0] === stepTarget; });
        var tells = isNotifyTarget(stepTarget);
        stepNote.hidden = !tells;
        doSel.hidden = scene || tells; setBox.classList.toggle('show', false);
        if (tells) { sq.steps[j] = stepTarget; return; }
        if (scene) { sq.steps[j] = stepTarget; return; }
        fillSelect(doSel, doOptionsFor(st, stepTarget, stepDo), String(stepDo).indexOf('set:') === 0 ? 'set:' : stepDo);
        runsItsOwnSteps(doSel, stepTarget);
        attachTargetReadings(doSel, function () { return stepTarget; });
        if (String(stepDo).indexOf('set:') !== 0) stepDo = doSel.value || 'on';
        sq.steps[j] = stepTarget + '|' + stepDo;
        setBox.refresh(stepTarget, stepDo);
      }
      sel.onchange = function () {
        stepTarget = sel.value;
        var scene = sceneOptions.some(function (o) { return o[0] === stepTarget; });
        if (!scene) stepDo = settableTarget(st, stepTarget) ? 'set:' : 'on';
        refillStepDo(); markSequences();
      };
      doSel.onchange = function () { stepDo = doSel.value === 'set:' ? 'set:' : doSel.value; refillStepDo(); markSequences(); };
      refillStepDo();
      var swap = function (a, b) {
        var t = sq.steps[a]; sq.steps[a] = sq.steps[b]; sq.steps[b] = t;
        markSequences(); paintSequences(STATE.status);
      };
      var up = cmdButton('Up', 'up', 'small'); up.classList.remove('needs-unlock'); up.title = 'Move this step earlier'; up.disabled = j === 0;
      up.onclick = function () { swap(j - 1, j); };
      var down = cmdButton('Down', 'down', 'small'); down.classList.remove('needs-unlock'); down.title = 'Move this step later'; down.disabled = j === sq.steps.length - 1;
      down.onclick = function () { swap(j, j + 1); };
      var drop = cmdButton('\u00d7', 'cancel', 'small danger'); drop.classList.remove('needs-unlock'); drop.title = 'Remove this step';
      drop.onclick = function () { sq.steps.splice(j, 1); markSequences(); paintSequences(STATE.status); };
      [sel, doSel, stepNote, setBox, up, down, drop].forEach(function (x) { line.appendChild(x); });
      steps.appendChild(line);
    });
    var addStep = cmdButton('Add step', 'add', 'small'); addStep.classList.remove('needs-unlock'); addStep.disabled = !stepOpts.length;
    addStep.title = 'One more step in the cycle; the button moves to the next one each time it is pressed';
    addStep.onclick = function () {
      var first = stepOpts[0][0];
      sq.steps.push(sceneOptions.some(function (o) { return o[0] === first; }) ? first : first + '|on');
      markSequences(); paintSequences(STATE.status);
    };
    steps.appendChild(addStep);
    var resetBox = el('div');
    resetBox.appendChild(el('div', 'sublbl', 'on reset, run'));
    // the same choice a step has: nothing, a scene, or a target with an action
    var resetSel = el('select'), resetDo = el('select');
    var rTarget = (sq.reset_scene || '').split('|')[0], rDo = (sq.reset_scene || '').split('|')[1] || 'on';
    var rOpts = [['', '\u21ba just start over']].concat(stepOpts);
    if (rTarget && !rOpts.some(function (o) { return o[0] === rTarget; })) rOpts.push([rTarget, '(gone)']);
    fillSelect(resetSel, rOpts, rTarget);
    var rSetBox = setValueBox(st, null, function (v) { rDo = v; sq.reset_scene = rTarget + '|' + v; markSequences(); });
    function refillResetDo() {
      var plain = !rTarget || sceneOptions.some(function (o) { return o[0] === rTarget; });
      resetDo.hidden = plain; rSetBox.classList.toggle('show', false);
      if (plain) { sq.reset_scene = rTarget; return; }
      fillSelect(resetDo, doOptionsFor(st, rTarget, rDo), String(rDo).indexOf('set:') === 0 ? 'set:' : rDo);
      runsItsOwnSteps(resetDo, rTarget);
      if (String(rDo).indexOf('set:') !== 0) rDo = resetDo.value || 'on';
      sq.reset_scene = rTarget + '|' + rDo;
      rSetBox.refresh(rTarget, rDo);
    }
    resetSel.onchange = function () {
      rTarget = resetSel.value;
      if (rTarget && !sceneOptions.some(function (o) { return o[0] === rTarget; })) rDo = settableTarget(st, rTarget) ? 'set:' : 'off';
      refillResetDo(); markSequences();
    };
    resetDo.onchange = function () { rDo = resetDo.value === 'set:' ? 'set:' : resetDo.value; refillResetDo(); markSequences(); };
    refillResetDo();
    var resetLine = el('div', 'step');
    resetLine.appendChild(resetSel); resetLine.appendChild(resetDo); resetLine.appendChild(rSetBox);
    resetBox.appendChild(resetLine);
    if (sq.id && live[sq.id]) {
      var nextScene = (st.scenes || []).filter(function (x) { return x.id === sq.steps[pos]; })[0];
      var status = el('div', 'seq-status');
      status.innerHTML = 'next press: <b>step ' + (pos + 1) + '/' + sq.steps.length + '</b>' + (nextScene ? ' \u2014 ' + esc(nextScene.name) : '');
      resetBox.appendChild(status);
    }
    var side = el('div'); side.style.display = 'flex'; side.style.flexDirection = 'column'; side.style.gap = '6px';
    var adv = cmdButton('Advance', 'play', 'small'); adv.disabled = !sq.id || SEQUENCES.dirty; if (SEQUENCES.dirty) adv.title = 'Save first';
    adv.onclick = function () { withPin('Advance ' + sq.name, 'Runs the next step, as a press would.', function (pin) { return post('sequence-advance', {id: sq.id, pin: pin}).then(function (r) { SEQUENCES.rows = null; forgetSig('sequences'); return r.message; }); }); };
    var rst = cmdButton('Reset', 'reset', 'small'); rst.disabled = !sq.id || SEQUENCES.dirty;
    rst.title = 'Put the sequence back to its first step (and run the reset step, if it has one)';
    rst.onclick = function () { withPin('Reset ' + sq.name, 'Back to step 1' + (sq.reset_scene ? ', running the reset scene.' : '.'), function (pin) { return post('sequence-reset', {id: sq.id, pin: pin}).then(function (r) { SEQUENCES.rows = null; forgetSig('sequences'); return r.message; }); }); };
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.onclick = function () { SEQUENCES.rows.splice(i, 1); markSequences(); paintSequences(STATE.status); };
    [adv, rst, del].forEach(function (x) { side.appendChild(x); });
    [name, steps, resetBox, side].forEach(function (x) { row.appendChild(x); });
    makeRowSortable(row, host, SEQUENCES, markSequences, function () { paintSequences(STATE.status); }, sq);
    host.appendChild(row);
  });
  sectionise(host, SEQUENCES, 'sequences', markSequences, function () { paintSequences(STATE.status); });
  if (!SEQUENCES.dirty) $('sequence-note').textContent = '';
}
$('sequence-add').onclick = function () {
  SEQUENCES.rows = SEQUENCES.rows || [];
  var first = ((STATE.status || {}).scenes || [])[0];
  SEQUENCES.rows.push({name: '', steps: first ? [first.id] : [], reset_scene: ''});
  markSequences(); paintSequences(STATE.status);
};
$('sequence-save').onclick = function () {
  withPin('Save sequences', 'They become available as \ud83d\udd01 / \u21ba targets for buttons at once.', function (pin) {
    return post('sequences-save', {sequences: rowsToSave(SEQUENCES, 'sequences'), pin: pin}).then(function (r) {
      saveGroups('sequences', SEQUENCES);
      SEQUENCES.dirty = false; SEQUENCES.rows = null; forgetSig('sequences');
      return (r.sequences || []).length + ' sequence(s) saved';
    });
  });
};
// a target that is a bundle (scene / sequence) has no Do of its own
function isBundleTarget(v) { v = v || ''; return v.indexOf('scene:') === 0 || v.indexOf('seq:') === 0 || v.indexOf('seqreset:') === 0; }
// A notification is not switched on or off, and cannot be pulsed: the Do
// column, the pulse delay and the way-back threshold all mean nothing for it.
// 'notify', 'notify:<message>' and 'notify@ntfy' and its kin: none of them
// switch anything, so none of them takes an action
function isNotifyTarget(v) {
  v = v || '';
  return v === 'notify' || v.indexOf('notify:') === 0 || v.indexOf('notify@') === 0;
}
// something the house does to itself: it has no on and off either
function isSystemTarget(v) { return String(v || '').indexOf('sys:') === 0; }
function sequenceTargetOptions(st) {
  var out = [];
  (st.sequences || []).forEach(function (sq) { out.push(['seq:' + sq.id, withIcon('seq', sq.name + ' (next step)')]); out.push(['seqreset:' + sq.id, withIcon('seqreset', 'reset ' + sq.name)]); });
  return out;
}
// ---- sensor groups: several sensors read as one ------------------------------
var SGROUPS = { rows: null, dirty: false, groups: null };
var GROUP_MODES = [['any', 'any of them is on'], ['all', 'all of them are on'], ['count', 'how many are on'],
                   ['sum', 'the sum'], ['average', 'the average'], ['highest', 'the highest'],
                   ['lowest', 'the lowest'], ['spread', 'the gap between highest and lowest']];
function markSGroups() { SGROUPS.dirty = true; $('sgroup-note').textContent = 'Unsaved changes'; }
function renderSGroups(st) {
  if (SGROUPS.dirty) return;
  if (SGROUPS.rows === null) {
    api('sensor-groups').then(function (r) {
      if (SGROUPS.dirty) return;
      SGROUPS.rows = (r.groups || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
      paintSGroups(st);
    }, function () { SGROUPS.rows = []; paintSGroups(st); });
    return;
  }
  paintSGroups(st);
}
function paintSGroups(st) {
  if (editorBusy('sgroups-list')) return;
  var host = $('sgroups-list'); host.innerHTML = '';
  var rows = SGROUPS.rows || [];
  if (!rows.length) host.appendChild(el('div', 'muted small', 'No group yet. One group can stand for a whole floor of sensors.'));
  var sources = ruleSources(st).filter(function (d) { return d.source !== 'group'; });
  var live = {};
  (st.sensor_groups || []).forEach(function (g) { live[g.id] = g; });
  rows.forEach(function (g, i) {
    var row = el('div', 'sgroup-row');
    var name = el('input'); name.value = g.name || ''; name.placeholder = 'PIR downstairs';
    name.title = 'What to call this group. It appears as a source wherever a device does.';
    name.oninput = function () { g.name = name.value; markSGroups(); };

    var keySel = el('select');
    var keys = {};
    (g.members || []).forEach(function (m) {
      var d = deviceById(m); if (!d) return;
      numericKeys(d, null).forEach(function (k) { keys[k] = ((d.values || {})[k] || {}).label || k; });
    });
    var keyOpts = Object.keys(keys).sort().map(function (k) { return [k, keys[k]]; });
    if (g.key && !keyOpts.some(function (o) { return o[0] === g.key; })) keyOpts.unshift([g.key, g.key]);
    if (!keyOpts.length) keyOpts = [['', 'pick sensors first']];
    g.key = fillSelect(keySel, keyOpts, g.key);
    keySel.title = 'The reading to take from every sensor in the group.';
    keySel.onchange = function () { g.key = keySel.value; markSGroups(); };

    var modeSel = el('select');
    g.mode = fillSelect(modeSel, GROUP_MODES, g.mode || 'any');
    modeSel.title = 'How the readings are put together into one number. "Any"/"all" treat 1 as on; the rest are arithmetic.';
    modeSel.onchange = function () { g.mode = modeSel.value; markSGroups(); };

    var pick = el('div', 'sgroup-members');
    devicesSorted(sources).forEach(function (d) {
      var on = (g.members || []).indexOf(d.id) >= 0 || (g.members || []).indexOf(d.name) >= 0;
      var chip = el('label', 'sgroup-chip' + (on ? ' on' : ''));
      var box = el('input'); box.type = 'checkbox'; box.checked = on;
      box.onchange = function () {
        g.members = (g.members || []).filter(function (m) { return m !== d.id && m !== d.name; });
        if (box.checked) g.members.push(d.id);
        markSGroups(); paintSGroups(STATE.status);
      };
      chip.appendChild(box);
      chip.appendChild(el('span', '', deviceIcon(d) + ' ' + d.name));
      attachReadings(chip, function () { return d.id; }, function () { return g.key; });
      pick.appendChild(chip);
    });

    var now = live[g.id] || {};
    var reading = el('span', 'sgroup-now');
    reading.textContent = isNum(now.value) ? fmt(now.value, 2) : '\u2013';
    reading.title = isNum(now.value)
      ? 'What the group reads now' + ((now.trigger || {}).device ? ', last moved by ' + now.trigger.device : '')
      : 'Nothing read yet \u2014 it fills in when a member reports';

    var enabled = makeSwitch(g.enabled !== false, function (on) { g.enabled = on; markSGroups(); }, {small: true, title: 'A group switched off is not worked out at all'});
    var del = cmdButton('', 'trash', 'small iconbtn danger'); del.classList.remove('needs-unlock');
    del.title = 'Remove this group';
    del.onclick = function () { SGROUPS.rows.splice(i, 1); markSGroups(); paintSGroups(STATE.status); };

    var fresh = el('input'); fresh.type = 'number'; fresh.min = 0; fresh.step = 5; fresh.className = 'wnum';
    fresh.value = g.fresh_minutes || 0; fresh.placeholder = '0';
    fresh.title = 'Leave out members that have said nothing for this many minutes, so a sensor that has gone quiet does not drag an average with a reading from last week. 0 counts them all.';
    fresh.oninput = function () { g.fresh_minutes = parseInt(fresh.value, 10) || 0; markSGroups(); };
    var roomSel = el('select');
    var roomOpts = [['', 'any room']].concat(((st.rooms) || []).map(function (r) { return [r.name, r.name]; }));
    g.room = fillSelect(roomSel, roomOpts, g.room || '');
    roomSel.title = 'Only count the members that are in this room. Useful when one group is kept for a whole floor.';
    roomSel.onchange = function () { g.room = roomSel.value; markSGroups(); };
    if (((now.skipped) || []).length) reading.title += ' \u00b7 left out: ' + now.skipped.join(', ');
    [enabled, name, keySel, modeSel, fresh, roomSel, reading, del].forEach(function (x) { row.appendChild(x); });
    row.appendChild(pick);
    attachCardMenu(row, {head: g.name || 'group', rows: [
      ['\ud83d\udcc8 History of this group', function () { showTab('history'); setTimeout(function () { pickHistoryDevice('grp:' + g.id); }, 80); }],
      ['\u26a1 A rule from this group', function () { showControlSection('automation'); newRuleFor('grp:' + g.id); }],
      ['\ud83d\udccb Copy its name', function () { copyToClipboard(g.name || '', 'Name'); }]
    ]});
    makeRowSortable(row, host, SGROUPS, markSGroups, function () { paintSGroups(STATE.status); }, g);
    host.appendChild(row);
  });
  sectionise(host, SGROUPS, 'sgroups', markSGroups, function () { paintSGroups(STATE.status); });
}
$('sgroup-add').onclick = function () {
  SGROUPS.rows = SGROUPS.rows || [];
  SGROUPS.rows.push({id: '', name: '', key: '', mode: 'any', members: [], enabled: true});
  markSGroups(); paintSGroups(STATE.status);
};
$('sgroup-save').onclick = function () {
  withPin('Save sensor groups', 'They become sources at once; rules and charts can use them.', function (pin) {
    return post('sensor-groups', {groups: rowsToSave(SGROUPS, 'sensor groups'), pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not save');
      saveGroups('sgroups', SGROUPS);
      SGROUPS.dirty = false; SGROUPS.rows = null; $('sgroup-note').textContent = ''; forgetSig('sgroups'); tick(true);
      return (r.groups || []).length + ' group(s) saved';
    });
  });
};

// ---- the SMS tab: what has been said, and saying something -------------------
var SMSBOX = { which: 'all', to: [], loaded: 0 };   // Everything, not the inbox alone
function renderSmsTab(st) {
  var people = ((st.presence || {}).people || []).filter(function (p) { return p.number; });
  var host = $('sms-people'); host.innerHTML = '';
  people.forEach(function (p) {
    var on = SMSBOX.to.indexOf(p.id) >= 0;
    var chip = el('label', 'sgroup-chip' + (on ? ' on' : ''));
    var box = el('input'); box.type = 'checkbox'; box.checked = on;
    box.onchange = function () {
      SMSBOX.to = SMSBOX.to.filter(function (x) { return x !== p.id; });
      if (box.checked) SMSBOX.to.push(p.id);
      renderSmsTab(STATE.status);
    };
    chip.appendChild(box);
    chip.appendChild(el('span', '', ICON.person + ' ' + p.name));
    chip.title = p.name + ' \u2014 ' + p.number + (p.home ? ' \u00b7 at home' : ' \u00b7 out');
    host.appendChild(chip);
  });
  var free = el('input'); free.type = 'tel'; free.className = 'sms-free'; free.placeholder = '+420 777 123 456';
  free.title = 'Or a number that belongs to nobody on the list. Several, separated by commas, are fine.';
  free.value = SMSBOX.free || '';
  free.oninput = function () { SMSBOX.free = free.value; };
  host.appendChild(free);
  if (!people.length) host.appendChild(el('span', 'muted small', 'Nobody has a number on their card yet \u2014 Control \u2192 Presence.'));
  smsPreview();
  renderSmsLog(st);
}
function smsRecipients() {
  return SMSBOX.to.concat(String(SMSBOX.free || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean));
}
// What the text would really say, asked of the daemon - the same service the
// alert, the SMS command and the one-tap previews use. It used to be filled
// in here instead, against the examples the Facts picker shows, and that copy
// knew neither the turns of phrase nor a reading of a named device: it left
// {home.nl} and {PIR-Chodba.model.nl} standing on the page exactly as typed.
// One filler, in the daemon, is the only way the preview cannot lie.
var SMSBOX_PREVIEW_TIMER = null;
function smsPreview() {
  var text = ($('sms-text') || {}).value || '';
  var body = $('sms-preview-body'), count = $('sms-count');
  if (!body) return;
  if (!text) {
    body.textContent = '\u2014'; if (count) count.textContent = '';
    delete body.dataset.shown;
    return;
  }
  if (body.dataset.shown === text) return;
  clearTimeout(SMSBOX_PREVIEW_TIMER);
  SMSBOX_PREVIEW_TIMER = setTimeout(function () {
    var asked = ($('sms-text') || {}).value || '';
    if (!asked) return;
    api('message-preview&title=&text=' + encodeURIComponent(asked)).then(function (r) {
      if ((($('sms-text') || {}).value || '') !== asked) return;   // typed on: a later answer is on its way
      showSmsPreview(asked, r.text || '', r.chars, r.parts);
    }, function () {
      // the daemon did not answer: show it as written rather than nothing,
      // and do not remember it, so the next keystroke asks again
      body.textContent = asked;
      if (count) count.textContent = asked.length + ' character(s)';
    });
  }, 250);
}
function showSmsPreview(asked, filled, chars, parts) {
  var body = $('sms-preview-body'), count = $('sms-count');
  body.dataset.shown = asked;
  body.textContent = filled || '\u2014';
  if (!count) return;
  var n = chars === undefined || chars === null ? filled.length : chars;
  count.textContent = n ? n + ' character(s)' + (parts > 1 ? ' \u00b7 ' + parts + ' parts' : '') : '';
}
function renderSmsLog(st) {
  var host = $('sms-log'); if (!host) return;
  api('sms-log&limit=300').then(function (r) {
    host.innerHTML = '';
    var rows = (r.messages || []).filter(function (m) { return SMSBOX.which === 'all' || m.dir === SMSBOX.which; });
    if (!rows.length) { host.appendChild(el('p', 'btnhelp', 'Nothing here yet.')); return; }
    rows.forEach(function (m) {
      // three states, not two: it went, it did not, or the gateway never said
      var unsure = m.ok === null || m.ok === undefined;
      var line = el('div', 'sms-line ' + m.dir + (m.ok ? '' : (unsure ? ' unsure' : ' bad')));
      var who = el('div', 'sms-who');            // the name over the time, not a table
      who.appendChild(el('span', 'sms-name', (m.person ? ICON.person + ' ' + m.person : m.number || '?')));
      who.appendChild(el('span', 'sms-when', ago(m.at)));
      if (m.person && m.number) who.title = m.number;
      line.appendChild(who);
      var bubble = el('div', 'sms-bubble ' + m.dir, m.text);
      if (unsure) bubble.title = 'The gateway did not answer in time. It usually means the message '
        + 'went out anyway and the gateway was busy sending an earlier one \u2014 it is not a failure, '
        + 'only an unanswered question.';
      else if (!m.ok) bubble.title = 'This one did not get through';
      line.appendChild(bubble);
      var tail = el('div', 'sms-tail');
      tail.appendChild(el('span', 'muted small', (m.dir === 'in' ? 'received' : (m.why || 'sent'))
        + (m.ok ? '' : (unsure ? ' \u00b7 no answer from the gateway' : ' \u00b7 failed'))));
      var again = cmdButton('', 'reset', 'small iconbtn'); again.classList.remove('needs-unlock');
      again.title = m.dir === 'in' ? 'Answer this one' : 'Send it again';
      again.onclick = function () {
        SMSBOX.free = m.number; SMSBOX.to = [];
        if (m.dir === 'out') $('sms-text').value = m.text;
        renderSmsTab(STATE.status);
        $('sms-text').focus();
      };
      var drop = cmdButton('', 'trash', 'small iconbtn danger needs-unlock');
      drop.title = 'Forget this message';
      drop.onclick = function () {
        withPin('Forget this message', 'Only the record here; nothing is unsent.', function (pin) {
          return post('sms-forget', {pin: pin, id: m.id}).then(function (x) {
            if (!x.ok) throw new Error(x.error || 'could not'); renderSmsLog(STATE.status); return x.message;
          });
        });
      };
      tail.appendChild(again); tail.appendChild(drop);
      line.appendChild(tail);
      host.appendChild(line);
    });
  }, function () {});
  var tools = $('sms-log-tools');
  if (tools && !tools.children.length) {
    var wipe = cmdButton('Forget them all', 'trash', 'small danger');
    wipe.title = 'Empty the record of messages. Nothing is unsent, and the gateway keeps its own.';
    wipe.onclick = function () {
      withPin('Forget every message', 'The whole record here goes. Nothing is unsent.', function (pin) {
        return post('sms-forget', {pin: pin}).then(function (x) {
          if (!x.ok) throw new Error(x.error || 'could not'); renderSmsLog(STATE.status); return x.message;
        });
      });
    };
    tools.appendChild(wipe);
  }
}
document.addEventListener('DOMContentLoaded', function () {
  var box = $('sms-text');
  if (!box) return;
  setButtonIcon($('sms-tab-in'), 'down');      // what came in, what went out, and the lot
  setButtonIcon($('sms-tab-out'), 'up');
  setButtonIcon($('sms-tab-all'), 'chart');
  $('sms-tab-in').title = 'Messages that came in';
  $('sms-tab-out').title = 'Messages this dashboard sent';
  $('sms-tab-all').title = 'Both, newest first';
  box.oninput = smsPreview;
  attachFactCompleter(box, smsPreview);      // { or Ctrl+Space, the same as in an alert
  $('sms-emoji').onclick = function (e) { e.stopPropagation(); openEmojiPicker($('sms-emoji'), box, smsPreview); };
  $('sms-facts').onclick = function (e) { e.stopPropagation(); openFactPicker($('sms-facts'), box, smsPreview); };
  Array.prototype.forEach.call(document.querySelectorAll('#sms-subtabs button'), function (b) {
    b.onclick = function () {
      SMSBOX.which = b.dataset.box;
      Array.prototype.forEach.call(document.querySelectorAll('#sms-subtabs button'), function (x) { x.classList.toggle('on', x === b); });
      renderSmsLog(STATE.status);
    };
  });
  $('sms-write-send').onclick = function () {
    var to = smsRecipients();
    if (!to.length) { toast('Nobody to send it to yet.', false); return; }
    if (!box.value.trim()) { toast('Nothing to say yet.', false); return; }
    withPin('Send this message', 'To ' + esc(to.join(', ')) + '.', function (pin) {
      return post('sms-send', {pin: pin, to: to, text: box.value}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not send');
        box.value = ''; smsPreview(); renderSmsLog(STATE.status);
        return r.message;
      });
    });
  };
});

// what the diagnosis found, in the app's own dialog
function showDialog(title, body) {
  var back = $('tellback');
  $('telltitle').textContent = title;
  $('tellbody').innerHTML = '';
  $('tellbody').appendChild(body);
  back.hidden = false;
  var close = function () {
    back.hidden = true;
    document.removeEventListener('keydown', esc);
  };
  // named, so it can be taken off again: closing with OK or with a click
  // outside used to leave it attached, and every dialog after that left one
  // more listening behind it
  function esc(e) { if (e.key === 'Escape') close(); }
  $('tellok').onclick = close;
  back.onclick = function (e) { if (e.target === back) close(); };
  document.addEventListener('keydown', esc);
  setTimeout(function () { $('tellok').focus(); }, 30);
}
function showDiagnosis(r) {
  var body = el('div');
  body.appendChild(el('p', 'btnhelp', r.plug + ' at ' + (r.host || 'an unknown address')));
  (r.steps || []).forEach(function (s) {
    var row = el('div', 'acl-row' + (s.ok ? '' : ' bad'));
    row.appendChild(el('span', 'mark ' + (s.ok ? 'ok' : 'warn'), s.ok ? '\u2714' : '\u2718'));
    row.appendChild(el('span', 'top', s.what));
    row.appendChild(el('span', 'why', s.detail));
    body.appendChild(row);
  });
  body.appendChild(el('p', 'note', r.verdict));
  showDialog(r.plug, body);
}

// ---- batteries: what is falling, and how fast --------------------------------
function renderBattery() {
  var host = $('battery-list'); if (!host) return;
  api('battery-health').then(function (r) {
    host.innerHTML = '';
    var rows = r.batteries || [];
    if (!rows.length) { host.appendChild(el('p', 'btnhelp', 'Nothing with a battery has reported yet.')); return; }
    rows.forEach(function (b) {
      var row = el('div', 'acl-row' + (b.level === 'crit' ? ' bad' : ''));
      row.appendChild(el('span', 'mark ' + (b.level === 'ok' ? 'ok' : b.level), b.level === 'ok' ? '\u2714' : '\u26a0'));
      row.appendChild(el('span', 'top', b.name));
      row.appendChild(el('span', 'who', fmt(b.percent, 0) + ' %'));
      row.appendChild(el('span', 'who', b.per_week ? '\u2212' + b.per_week + ' %/week' : 'steady'));
      row.appendChild(el('span', 'why', b.days_left === null || b.days_left === undefined
        ? 'not falling yet' : 'about ' + b.days_left + ' day(s) left'));
      row.title = b.days_left !== null && b.days_left !== undefined
        ? 'At the rate of the last month it reaches 5 % in about ' + b.days_left + ' days'
        : 'It has not fallen enough for a guess';
      attachReadings(row, function () { return b.id; }, function () { return 'battery'; });
      host.appendChild(row);
    });
  }, function () {});
}

// ---- what would happen -------------------------------------------------------
var WHATIF = {device: '', key: '', value: ''};
function renderWhatIf(st) {
  var row = $('whatif-row'); if (!row) return;
  row.innerHTML = '';
  var dev = el('select');
  var sources = ruleSources(st);
  WHATIF.device = fillSelect(dev, sortedDeviceOptions(st, sources), WHATIF.device);
  dev.title = 'The device whose reading we are pretending about';
  var key = el('select');
  function refillKeys() {
    var d = deviceById(WHATIF.device);
    WHATIF.key = fillSelect(key, numericKeys(d, WHATIF.key).map(function (k) {
      var info = ((d || {}).values || {})[k] || {};
      return [k, info.label || k];
    }), WHATIF.key);
    var now = ((d || {}).values || {})[WHATIF.key];
    if (now && (WHATIF.value === '' || WHATIF.value === undefined)) { value.value = now.value; WHATIF.value = now.value; }
  }
  dev.onchange = function () { WHATIF.device = dev.value; WHATIF.key = null; refillKeys(); };
  key.onchange = function () { WHATIF.key = key.value; refillKeys(); };
  var value = el('input'); value.type = 'number'; value.step = 'any'; value.className = 'wnum';
  value.placeholder = 'value'; value.value = WHATIF.value;
  value.title = 'The reading to pretend arrived';
  value.oninput = function () { WHATIF.value = value.value; };
  [dev, key].forEach(function (n) { attachReadings(n, function () { return WHATIF.device; }, function () { return WHATIF.key; }); });
  refillKeys();
  var go = cmdButton('See what would happen', 'search', 'small');
  go.classList.remove('needs-unlock');
  go.title = 'Nothing is switched \u2014 it only says what the rules would make of that reading';
  go.onclick = function () {
    withPin('Try a reading', 'Nothing is switched; it only says what would follow.', function (pin) {
      return post('what-if', {pin: pin, device: WHATIF.device, key: WHATIF.key, value: WHATIF.value}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        paintWhatIf(r);
        return r.would_fire + ' rule(s) would fire';
      });
    });
  };
  [dev, key, value, go].forEach(function (x) { row.appendChild(x); });
}
function paintWhatIf(r) {
  var host = $('whatif-out'); host.innerHTML = '';
  var head = el('p', 'btnhelp', 'If ' + r.device + ' reported ' + r.key + ' = ' + r.value
    + (r.was === null || r.was === undefined ? '' : ' (it says ' + r.was + ' now) ') + ':');
  host.appendChild(head);
  if (!(r.rules || []).length) { host.appendChild(el('div', 'muted small', 'No rule watches that reading.')); return; }
  r.rules.forEach(function (x) {
    var row = el('div', 'acl-row' + (x.would_fire ? '' : ' quiet'));
    row.appendChild(el('span', 'mark ' + (x.would_fire ? 'ok' : 'dim'), x.would_fire ? '\u2714' : '\u2013'));
    row.appendChild(el('span', 'top', x.rule));
    row.appendChild(el('span', 'who', x.do + ' \u2192 ' + x.target));
    row.appendChild(el('span', 'why', x.would_fire ? 'it would fire' : x.why));
    host.appendChild(row);
  });
}

// ---- messages waiting to go --------------------------------------------------
function renderOutbox(st) {
  var card = $('outbox-card'), host = $('outbox-list'); if (!card) return;
  var rows = st.sms_outbox || [];
  card.hidden = !rows.length;
  if (!rows.length) return;
  host.innerHTML = '';
  rows.forEach(function (m) {
    var row = el('div', 'acl-row');
    row.appendChild(el('span', 'who', ago(m.first)));
    row.appendChild(el('span', 'top', m.number));
    row.appendChild(el('span', 'why', m.text));
    row.appendChild(el('span', 'who', m.tries + ' try(s)' + (m.last_error ? ' \u00b7 ' + m.last_error : '')));
    var drop = el('button', 'btn small iconbtn needs-unlock'); drop.type = 'button';
    drop.innerHTML = iconMarkup('trash', 13); drop.title = 'Throw this one away';
    drop.onclick = function () {
      withPin('Throw it away', 'It will not be sent.', function (pin) {
        return post('outbox-drop', {pin: pin, id: m.id}).then(function (r) { tick(true); return r.message; });
      });
    };
    row.appendChild(drop);
    host.appendChild(row);
  });
}
$('outbox-flush').onclick = function () {
  withPin('Try them now', 'Every message waiting is offered to the gateway again.', function (pin) {
    return post('outbox-flush', {pin: pin}).then(function (r) { tick(true); return r.message; });
  });
};
$('outbox-drop').onclick = function () {
  withPin('Throw them all away', 'None of them will be sent.', function (pin) {
    return post('outbox-drop', {pin: pin}).then(function (r) { tick(true); return r.message; });
  });
};

// A box that takes people and phone numbers side by side: while a name is
// being typed, the people who have a number are offered; Ctrl+Space offers
// them all. What is typed stays what is typed - a number needs no lookup.
function whoCandidates(st) {
  return (((st.presence || {}).people) || []).filter(function (p) { return p.number; })
    .map(function (p) { return {name: p.name, number: p.number}; });
}
function attachWhoCompleter(box, st, after) {
  var pop = null;
  function close() { if (pop) { pop.remove(); pop = null; } }
  function partAt() {
    var upto = box.value.slice(0, box.selectionStart === null ? box.value.length : box.selectionStart);
    var start = upto.lastIndexOf(',') + 1;
    return {start: start, word: upto.slice(start).trim()};
  }
  function put(name) {
    var here = partAt();
    var before = box.value.slice(0, here.start);
    var rest = box.value.slice(here.start + box.value.slice(here.start).split(',')[0].length);
    box.value = (before + (before && !/[,\s]$/.test(before) ? ' ' : '') + name + rest).replace(/\s+,/g, ',');
    box.focus();
    close();
    if (after) after();
  }
  function open(all) {
    close();
    var word = partAt().word.toLowerCase();
    var rows = whoCandidates(st).filter(function (p) {
      return all || !word || p.name.toLowerCase().indexOf(word) === 0 || p.number.indexOf(word) === 0;
    });
    if (!rows.length) return;
    pop = el('div', 'pickbox whopick');
    rows.slice(0, 8).forEach(function (p) {
      var b = el('button', '', ICON.person + ' ' + p.name); b.type = 'button';
      b.appendChild(el('span', 'dim', ' ' + p.number));
      b.title = 'Its number is looked up when the message goes out';
      b.onclick = function (e) { e.stopPropagation(); put(p.name); };
      pop.appendChild(b);
    });
    document.body.appendChild(pop);
    var r = box.getBoundingClientRect();
    pop.style.left = Math.max(8, r.left + window.scrollX) + 'px';
    pop.style.top = (r.bottom + window.scrollY + 4) + 'px';
    pop.style.minWidth = Math.min(320, r.width) + 'px';
  }
  box.addEventListener('input', function () { if (partAt().word.length >= 1) open(false); else close(); });
  box.addEventListener('keydown', function (e) {
    if (e.key === ' ' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); open(true); return; }
    if (e.key === 'Escape') close();
    if (e.key === 'Enter' && pop) { e.preventDefault(); pop.querySelector('button').click(); }
  });
  box.addEventListener('blur', function () { setTimeout(close, 150); });
}

// ---- the SMS gateway ---------------------------------------------------------
// The gateway's settings, in the order somebody setting one up meets them:
// what it is and how to reach it, then what it should do with messages, then
// who it involves - and the rest folded away, because a working TRB140 needs
// none of it. A field with a fixed set of answers is a list, not a box to
// mistype a word into.
// The two words that came before the switches and are not roads themselves,
// so a value written by an older dashboard still reads as what it asked for.
// 'sms' was a word too - "and by text as well" - but it is the name of a road
// now, and means that one alone; what was stored before is put right once by
// the daemon at startup, so it never arrives here meaning the old thing.
var ROADS_OF = {'': [], 'event': [], 'notify': ['ntfy', 'telegram']};
var SMS_GROUPS = [
  ['The gateway itself', 'Where the modem is and how to get in. Everything else waits on these.', true, [
    ['sms_enabled', 'Use an SMS gateway', 'switch'],
    ['sms_host', 'Address', 'text', '192.168.2.1'],
    ['sms_port', 'Port', 'number', '0 uses 443 for HTTPS, 80 otherwise'],
    ['sms_https', 'Reach it over HTTPS', 'switch'],
    ['sms_user', 'Username', 'text', 'an account that may use the API'],
    ['sms_password', 'Password', 'password'],
    ['sms_api', 'Which interface', 'select', [
      ['rest', 'the device\u2019s own API'],
      ['cgi', 'the older Post/Get service']],
     'a TRB140 answers its own API out of the box; the other must be switched on by hand'],
    ['sms_verify_cert', 'Insist on a valid certificate', 'switch', 'a TRB signs its own, so usually off']
  ]],
  ['Messages in and out', 'What to do with what arrives, and how loudly to say it.', true, [
    ['sms_poll_s', 'Look for incoming messages', 'select', [
      ['0', 'never \u2014 only when the modem forwards them'],
      ['10', 'every 10 seconds'],
      ['15', 'every 15 seconds'],
      ['30', 'every 30 seconds'],
      ['60', 'every minute'],
      ['300', 'every five minutes']]],
    ['sms_reply', 'Answer a command with what was done', 'switch'],
    ['sms_stranger_alert', 'A text from a number nobody knows', 'roads', '',
     'the message itself is always written down; these say who else hears about it. '
     + 'By text means it is forwarded to your phone, at your cost'],
    ['sms_clear_inbox', 'Take a message off the modem once it has been acted on', 'switch',
     'its inbox is small, and a full one stops new ones arriving'],
    ['sms_daily_cap', 'Never send more than this many in a day', 'number', '0 for no cap'],
    ['sms_sim', 'What kind of SIM this is', 'select', [
      ['prepaid', 'prepaid \u2014 it has credit that runs out'],
      ['contract', 'a contract \u2014 there is no credit to ask about']],
     'on a contract the asking is put away altogether: no code, no beat, and no figure on '
     + 'the modem\u2019s card. One that was true of the SIM before is taken off when you switch'],
    ['sms_credit_code', 'What to ask the network for what is left on the SIM', 'text',
     'e.g. *101# \u2014 the operator says which one'],
    ['sms_credit_pattern', 'How to find the money in the answer', 'text',
     'only if the usual shapes miss it \u2014 a pattern, e.g. kredit\\s*([0-9.,]+)'],
    ['sms_credit_every_h', 'Ask that often', 'select', [
      ['0', 'never \u2014 only when I press the button'],
      ['1', 'every hour'], ['2', 'every two hours'], ['3', 'every three hours'],
      ['4', 'every four hours'], ['6', 'every six hours'],
      ['12', 'twice a day'], ['24', 'once a day'], ['168', 'once a week']]]
  ]],
  ['Instant delivery', 'Without this the inbox is looked at on the beat above. With it, the modem '
   + 'pushes a message here the moment it arrives.', false, [
    ['sms_push_secret', 'Word the modem must send with a forwarded message', 'password', 'empty = no push'],
    ['sms_push_number_field', 'What it calls the sender\u2019s number', 'text'],
    ['sms_push_text_field', 'What it calls the message text', 'text'],
    ['sms_push_base64', 'It encodes the text as Base64', 'switch', 'keeps accents intact']
  ]],
  ['When things go wrong', 'Waiting, retrying, and giving up.', false, [
    ['sms_timeout_s', 'Give up on the modem after (s)', 'number'],
    ['sms_queue', 'Keep a message the modem would not take, and try again', 'switch'],
    ['sms_queue_hours', 'Give up on a kept message after (h)', 'number']
  ]],
  ['Rarely needed', 'A TRB140 in its factory state needs none of these.', false, [
    ['sms_modem', 'Which modem to send from', 'text', 'empty asks the device'],
    ['sms_name', 'What to call the modem among the devices', 'text'],
    ['sms_status_via', 'Where to ask the modem about itself', 'select', [
      ['auto', 'the same interface'],
      ['ubus', 'the device\u2019s own bus'],
      ['cgi', 'the older status page']]],
    ['sms_number_format', 'How to write a number', 'select', [
      ['intl00', '00420\u2026'],
      ['plus', '+420\u2026']],
     'for the older interface only \u2014 the device\u2019s own API always wants +420\u2026'],
    ['sms_ubus_user', 'Login for the bus', 'text', 'only for "ubus" above'],
    ['sms_ubus_password', 'That login\u2019s password', 'password'],
    ['sms_send_path', 'Path that sends', 'text', 'the older interface only'],
    ['sms_read_path', 'Path that lists', 'text', 'the older interface only'],
    ['sms_status_path', 'Path that gives the modem\u2019s status', 'text', 'the older interface only'],
    ['sms_delete_path', 'Path that deletes a message', 'text', 'the older interface only']
  ]]
];

function renderSms(st) {
  var host = $('sms-grid'); if (!host) return;
  var cfg = st.runtime_config || {};
  // there is nothing to ask a contract SIM, so the button that asks is not
  // there to be pressed
  var askBtn = $('sms-credit');
  if (askBtn) askBtn.hidden = String((cfg.sms_sim || {}).value || 'prepaid') === 'contract';
  if (SMS_DIRTY) return;
  host.innerHTML = '';
  SMS_GROUPS.forEach(function (group) {
    var name = group[0], why = group[1], open = group[2], fields = group[3];
    var key = 'sms-group-' + name.replace(/\W+/g, '-').toLowerCase();
    if (SMS_OPEN[key] === undefined) SMS_OPEN[key] = open;
    var box = el('div', 'section' + (SMS_OPEN[key] ? ' open' : '')); box.style.gridColumn = '1/-1';
    var head = el('div', 'section-head');
    head.appendChild(el('span', 'fold', SMS_OPEN[key] ? '\u25be' : '\u25b8'));
    head.appendChild(el('span', 'section-name', name));
    head.appendChild(el('span', 'muted small', why));
    head.onclick = function () {
      SMS_OPEN[key] = !SMS_OPEN[key];
      box.classList.toggle('open', SMS_OPEN[key]);
      head.querySelector('.fold').textContent = SMS_OPEN[key] ? '\u25be' : '\u25b8';
    };
    box.appendChild(head);
    var body = el('div', 'section-body');
    var grid = el('div', 'set-grid');
    var prepaid = String((cfg.sms_sim || {}).value || 'prepaid') !== 'contract';
    fields.forEach(function (f) {
      var name_ = f[0], label = f[1], kind = f[2], extra = f[3], note = f[4];
      // nothing about credit on a contract SIM: the boxes would ask for a
      // code that answers nothing and a beat that would never be kept
      if (!prepaid && name_.indexOf('sms_credit') === 0) return;
      var meta = cfg[name_] || {}, wrap = el('div', 'set-item'), id = 'sms-f-' + name_;
      var lab = el('label', '', label); lab.htmlFor = id;
      wrap.appendChild(lab);
      var input;
      if (kind === 'switch') {
        input = el('label', 'sms-sw');
        var word = el('span', 'sms-sw-word', meta.value ? 'on' : 'off');
        // the same size as every other switch on the page; the small one
        // beside a full-height box reads as a dot rather than a switch
        input.appendChild(makeSwitch(!!meta.value, function (on) {
          SMS_EDIT[name_] = on ? 1 : 0; word.textContent = on ? 'on' : 'off'; markSms();
        }, {title: typeof extra === 'string' ? extra : ''}));
        input.appendChild(word);
      } else if (kind === 'roads') {
        // The same three switches the alert card has, for a setting whose
        // value is which roads a message takes. A list of the combinations
        // somebody thought of cannot say all eight of them; three switches
        // can, and none of them on is the eighth - written down and no more.
        input = el('div', 'notify-sys roads-field');
        input.id = id;
        var was = String(meta.value === undefined || meta.value === null ? '' : meta.value);
        var picked = ROADS_OF[was] || was.split(',').filter(Boolean);
        var says = el('span', 'muted small notify-sys-says');
        var boxes = [];
        var tellRoads = function (save) {
          var on = boxes.filter(function (b) { return b.checked; }).map(function (b) { return b.dataset.road; });
          says.textContent = on.length ? '' : '\u26d4 written down and no more';
          input.classList.toggle('overridden', !!on.length);
          if (save) { SMS_EDIT[name_] = on.join(','); markSms(); }
        };
        [['ntfy', ICON.bell + ' ntfy'], ['telegram', '\u2708\ufe0f Telegram'], ['sms', '\ud83d\udcf1 SMS']]
          .forEach(function (pair) {
            var sw = switchRow(pair[1], picked.indexOf(pair[0]) >= 0, function () { tellRoads(true); });
            sw.input.dataset.road = pair[0];
            boxes.push(sw.input);
            input.appendChild(sw);
          });
        input.appendChild(says);
        tellRoads(false);
        wrap.classList.add('wide');      // three switches want a line, not a column
      } else if (kind === 'select') {
        input = el('select'); input.id = id;
        var now = meta.value === undefined || meta.value === null ? '' : String(meta.value);
        var options = extra.slice();
        if (!options.some(function (o) { return o[0] === now; })) options.push([now, now + ' (as it stands)']);
        fillSelect(input, options.map(function (o) { return [o[0], o[1]]; }), now);
        input.onchange = function () { SMS_EDIT[name_] = input.value; markSms(); };
      } else {
        input = el('input'); input.id = id; input.autocomplete = 'off';
        input.type = kind === 'password' ? 'password' : (kind === 'number' ? 'number' : 'text');
        if (kind === 'password') { input.placeholder = meta.value ? '(kept)' : 'password'; input.value = ''; }
        else {
          input.value = meta.value === undefined || meta.value === null ? '' : meta.value;
          if (kind === 'text' && typeof extra === 'string') input.placeholder = extra;
        }
        input.oninput = function () { SMS_EDIT[name_] = input.value; markSms(); };
      }
      wrap.appendChild(input);
      // A note under the control - but never the same words the box is
      // already showing as a placeholder, which read as an echo.
      var hint = note || (typeof extra === 'string' ? extra : '');
      if (kind === 'text' && hint === extra) hint = '';
      wrap.appendChild(el('span', 'btnhelp', hint || ''));   // the band is kept even when empty
      grid.appendChild(wrap);
    });
    body.appendChild(grid);
    box.appendChild(body);
    host.appendChild(box);
  });
  // Who gets what, on one grid rather than as numbers typed in two places
  var who = el('div'); who.style.gridColumn = '1/-1';
  who.appendChild(el('div', 'set-head', 'Who it involves'));
  who.appendChild(el('p', 'btnhelp', 'A number belongs to a person, on their card under Presence. '
    + 'These two ticks say what that number is for: an alert goes to everybody ticked on the left, '
    + 'and only the numbers ticked on the right may ask for anything. The two boxes are for numbers that '
    + 'belong to nobody; they are added to whoever is ticked, never instead of them.'));
  // numbers that belong to nobody, beside the people they sit alongside
  var extras = el('div', 'set-grid sms-extras'); extras.style.margin = '4px 0 14px';
  [['sms_to', 'Extra numbers for alerts', 'a number nobody owns \u2014 a second SIM, a neighbour'],
   ['sms_allow', 'Extra numbers allowed to give commands', 'full run of the house, and no name in the log']
  ].forEach(function (f) {
    var meta = cfg[f[0]] || {}, wrap = el('div', 'set-item');
    var lab = el('label', '', f[1]); lab.htmlFor = 'sms-f-' + f[0];
    wrap.appendChild(lab);
    var box = el('input'); box.id = 'sms-f-' + f[0]; box.type = 'tel'; box.autocomplete = 'off';
    box.value = meta.value === undefined || meta.value === null ? '' : meta.value;
    box.placeholder = '+420 777 123 456, +420 …';
    box.oninput = function () { SMS_EDIT[f[0]] = box.value; markSms(); };
    wrap.appendChild(box);
    wrap.appendChild(el('span', 'btnhelp', f[2]));
    extras.appendChild(wrap);
  });
  who.appendChild(extras);
  var grid = el('div', 'sms-whotable');
  var head = el('div', 'sms-whotable-row head');
  ['Who', 'Their number', 'Gets alerts', 'May command'].forEach(function (t) { head.appendChild(el('span', '', t)); });
  grid.appendChild(head);
  ((st.sms || {}).people || []).forEach(function (p) {
    var row = el('div', 'sms-whotable-row');
    row.appendChild(el('span', 'sms-person-name', ICON.person + ' ' + p.name));
    if (p.phone) {
      row.appendChild(el('span', 'sms-person-num', p.phone));
      // the switches sit inside a cell of their own, so the cell takes the
      // table's padding and border and the switch keeps its own shape
      var alerts = el('span', 'sms-whotable-cell');
      alerts.appendChild(makeSwitch(p.alerts, function (on) { SMS_PEOPLE[p.id] = Object.assign({}, SMS_PEOPLE[p.id] || p, {alerts: on}); markSms(); },
                                    {title: 'Alerts are sent to ' + p.name}));
      row.appendChild(alerts);
      var may = el('span', 'sms-whotable-cell');
      may.appendChild(makeSwitch(p.may_command, function (on) { SMS_PEOPLE[p.id] = Object.assign({}, SMS_PEOPLE[p.id] || p, {may_command: on}); markSms(); },
                                 {title: p.name + ' may switch things by text'}));
      row.appendChild(may);
    } else {
      var note = el('span', 'muted small', 'no number yet \u2014 add one on their card under Presence');
      note.style.gridColumn = '2/-1';
      row.appendChild(note);
    }
    grid.appendChild(row);
  });
  if (!((st.sms || {}).people || []).length) grid.appendChild(el('p', 'btnhelp', 'Nobody on the list yet.'));
  who.appendChild(grid);
  host.appendChild(who);
  // what to put on the gateway's own "SMS forwarding to HTTP" page, ready to copy
  if ((cfg.sms_push_secret || {}).value) {
    var push = el('div', 'sms-push');
    push.appendChild(el('span', 'sms-push-head', 'Tell the gateway to forward here'));
    // the word itself is not in the status any more - it is a secret, and the
    // status is answered before the view lock - so the address is shown with
    // its place kept, and the whole of it comes from the PIN-gated list
    var pushUrl = location.origin + location.pathname.replace(/[^/]*$/, '')
      + 'index.php?api=sms-incoming&secret=';
    push.appendChild(el('code', 'sms-push-url', pushUrl + '\u2026'));
    push.appendChild(el('span', 'btnhelp', 'On the gateway: Services \u2192 Mobile Utilities \u2192 SMS Gateway \u2192 SMS forwarding to HTTP. '
      + 'Method GET, this address, and the two value names above ('
      + ((cfg.sms_push_number_field || {}).value || 'number') + ' and '
      + ((cfg.sms_push_text_field || {}).value || 'text') + '). A message then arrives here in a second, '
      + 'rather than waiting for the next look in the inbox.'));
    var copyPush = cmdButton('Copy the address', 'save', 'small');
    copyPush.title = 'Put the whole address, the word included, on the clipboard';
    copyPush.onclick = function () {
      withPin('The forwarding address', 'It carries the word the modem must send, which is a secret: '
        + 'showing it is written down, like showing any other.', function (pin) {
          return post('secrets', {pin: pin}).then(function (r) {
            var word = '';
            (r.secrets || []).forEach(function (group) {
              (group.items || []).forEach(function (item) {
                if (item.name === 'Push secret') word = item.value;
              });
            });
            if (!word) throw new Error('the daemon did not give the word back');
            copyToClipboard(pushUrl + encodeURIComponent(word), 'Address');
            return 'the address is on the clipboard';
          });
        });
    };
    push.appendChild(copyPush);
    host.appendChild(push);
  }

  var line = el('p', 'btnhelp', (st.sms || {}).ready
    ? 'The gateway is set up' + ((st.sms || {}).commands ? ', with ' + st.sms.commands + ' command(s) it listens for' : '') + '.'
    : 'Not set up yet \u2014 alerts and commands over SMS are off.');
  host.appendChild(line);
}
var SMS_EDIT = {}, SMS_PEOPLE = {}, SMS_DIRTY = false, SMS_OPEN = {};
function markSms() { SMS_DIRTY = true; $('sms-note').textContent = 'Unsaved changes'; }
$('sms-save').onclick = function () {
  withPin('Save the SMS gateway', 'It takes effect at once; nothing is sent by saving.', function (pin) {
    var body = {pin: pin};
    Object.keys(SMS_EDIT).forEach(function (k) { if (SMS_EDIT[k] !== '') body[k] = SMS_EDIT[k]; });
    if (SMS_EDIT.sms_password === '') delete body.sms_password;      // blank keeps the one it has
    // the people come with the status, so nothing extra is fetched
    var first = Promise.resolve({ok: true});
    if (Object.keys(SMS_PEOPLE).length) {
      var rows = ((STATE.status || {}).people || []).map(function (p) {
        var edit = SMS_PEOPLE[p.id];
        return edit ? Object.assign({}, p, {sms_alerts: edit.alerts, sms_commands: edit.may_command}) : p;
      });
      first = post('people', {people: rows, pin: pin});   // 'people-save' is the button, not the path
    }
    return first.then(function (r0) {
      if (!r0.ok) throw new Error(r0.error || 'could not save the people');
      return post('config-save', body);
    }).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not save');
      SMS_EDIT = {}; SMS_PEOPLE = {}; SMS_DIRTY = false; $('sms-note').textContent = '';
      forgetSig('settings'); forgetSig('people'); PEOPLE.rows = null; tick(true);
      return 'saved';
    });
  });
};
$('sms-test').onclick = function () {
  askText('Test the gateway', 'A number to send a real message to, or leave it empty to only ask whether the gateway is there.', '', function (number) {
    withPin('Test the SMS gateway', number ? 'One message goes to ' + esc(number) + '.' : 'Nothing is sent.', function (pin) {
      return post('sms-test', {pin: pin, number: number || ''}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'no answer'); return r.message;
      });
    });
  });
};
$('sms-send').onclick = function () {
  askText('Send a message', 'Who to, then what to say \u2014 separated by a space.', '', function (line) {
    var bits = String(line || '').trim().split(/\s+/);
    var number = bits.shift(), text = bits.join(' ');
    if (!number || !text) { toast('A number and something to say, please.', false); return; }
    withPin('Send an SMS', 'To ' + esc(number) + '.', function (pin) {
      return post('sms-send', {pin: pin, number: number, text: text}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not send'); return 'sent';
      });
    });
  });
};
$('acl-mend').onclick = function () {
  withPin('Add the missing lines', 'They go into each user\u2019s own block in the broker\u2019s ACL. Nothing else in '
    + 'the file is touched, a copy of it as it stands is kept beside it, and mosquitto is asked to read it again '
    + 'without dropping anybody.', function (pin) {
    return post('acl-mend', {pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not');
      forgetSig('acl'); tick(true); renderAcl(STATE.status || {});
      return r.message;
    });
  });
};
$('sms-credit').onclick = function () {
  withPin('Ask the network', 'The code in the settings is sent as it stands; the answer comes back as a text '
    + 'from the operator, and is kept as a reading.', function (pin) {
    return post('sms-ussd', {pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'the network said nothing');
      forgetSig('sms'); tick(true);
      return r.message;
    });
  });
};
$('modem-reset').onclick = function () {
  withPin('Start the data counters again', 'The modem\u2019s own total is left alone \u2014 only what this '
    + 'dashboard counts from starts again at zero.', function (pin) {
    return post('modem-reset-data', {pin: pin, by: 'the dashboard'}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not');
      forgetSig('sms'); tick(true);
      return r.message;
    });
  });
};
$('sms-poll').onclick = function () {
  withPin('Read the inbox', 'Anything that came in is matched against the commands.', function (pin) {
    return post('sms-poll', {pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not read it');
      return (r.result || {}).read + ' message(s) read, ' + (r.result || {}).acted + ' acted on';
    });
  });
};

// ---- what a text message may do ---------------------------------------------
var SMSCMD = { rows: null, dirty: false };
function markSmsCmd() { SMSCMD.dirty = true; $('smscmd-note').textContent = 'Unsaved changes'; }
function renderSmsCmd(st) {
  if (SMSCMD.dirty) return;
  if (SMSCMD.rows === null) {
    api('sms-commands').then(function (r) {
      if (SMSCMD.dirty) return;
      SMSCMD.rows = (r.commands || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
      paintSmsCmd(st);
    }, function () { SMSCMD.rows = []; paintSmsCmd(st); });
    return;
  }
  paintSmsCmd(st);
}
function paintSmsCmd(st) {
  if (editorBusy('smscmd-list')) return;
  var host = $('smscmd-list'); host.innerHTML = '';
  var rows = SMSCMD.rows || [];
  if (!rows.length) host.appendChild(el('div', 'muted small', 'Nothing listened for yet.'));
  // a script written on this page is a target like any other, named as it was
  // named and doing whatever its lines say
  var targets = [['', '\u2014 answer only \u2014']]
    .concat((SCRIPTS.rows || []).filter(function (x) { return x.id && x.name; })
      .map(function (x) { return ['script:' + x.id, '\ud83d\udcdc ' + x.name]; }))
    .concat(cachedTargetOptions(st));
  rows.forEach(function (c, i) {
    var row = el('div', 'smscmd-row');
    row.appendChild(makeSwitch(c.enabled !== false, function (on) { c.enabled = on; markSmsCmd(); },
                               {small: true, title: 'A command switched off is not listened for'}));
    var phrase = el('input'); phrase.value = c.phrase || ''; phrase.placeholder = 'lights off';
    phrase.title = 'The word or phrase to listen for. A message that starts with it, or contains it as a '
      + 'word, counts. Write {a name} in it and whatever the message carries there stands for that name '
      + 'everywhere this command uses it \u2014 "unban {ip}" against "unban 1.1.1.1". Ctrl+Space offers names.';
    phrase.oninput = function () { c.phrase = phrase.value; markSmsCmd(); scheduleSmsPreview(); };
    attachFactCompleter(phrase, function (v) { c.phrase = v; markSmsCmd(); },
                        function () { return rowVars(c).concat(nameSuggestions(c.phrase)); });
    var target = el('select');
    c.target = fillSelect(target, targets, c.target || '');
    attachTargetReadings(target, function () { return c.target; });
    target.onchange = function () { c.target = target.value; markSmsCmd(); refreshDo(); };
    var doSel = el('select');
    var tellNote = el('span', 'muted small', 'sends the message');
    tellNote.title = 'Nothing is switched \u2014 what it says is set under Alerts';
    function refreshDo() {
      var tells = isNotifyTarget(c.target);
      doSel.hidden = !c.target || tells;
      tellNote.hidden = !tells;
      if (tells) { c.do = 'on'; return; }
      if (!c.target) return;
      if (String(c.target).indexOf('script:') === 0) {
        // a script does whatever its lines say; there is nothing else to pick
        c.do = fillSelect(doSel, [['script', '\ud83d\udcdc run it, line by line']], 'script');
        return;
      }
      c.do = fillSelect(doSel, doOptionsFor(st, c.target, c.do), c.do || 'on');
      runsItsOwnSteps(doSel, c.target);
      attachTargetReadings(doSel, function () { return c.target; });
    }
    doSel.onchange = function () { c.do = doSel.value; markSmsCmd(); };
    refreshDo();
    var reply = el('textarea'); reply.className = 'smscmd-reply'; reply.rows = 2; reply.value = c.reply || '';
    reply.placeholder = 'What to text back \u2014 e.g. On: {everything_on}. In: {people_home}.';
    reply.title = 'What goes back to the sender. Every fact a notification can quote works here, and {sms_from}, {sms_text} '
      + 'and {person} besides. Type { or press Ctrl+Space for the list.';
    reply.oninput = function () { c.reply = reply.value; markSmsCmd(); scheduleSmsPreview(); };
    attachFactCompleter(reply, function (v) { c.reply = v; markSmsCmd(); scheduleSmsPreview(); },
                        function () { return rowVars(c).concat(phraseNames(c.phrase)); });
    var takes = makeSwitch(!!c.takes_value, function (on) { c.takes_value = on; markSmsCmd(); refreshDo(); },
                           {small: true, title: 'What follows the phrase becomes the value: \u201cheating 22\u201d sets '
                            + '22, \u201cheating eco\u201d sets eco. The action below is then only what it does when '
                            + 'nothing follows.'});
    var anyone = makeSwitch(!!c.from_anyone, function (on) { c.from_anyone = on; markSmsCmd(); },
                            {small: true, title: 'Accept this one from any number, not only the allowed list. Use it for questions, not for switches.'});
    var del = cmdButton('', 'trash', 'small iconbtn danger'); del.classList.remove('needs-unlock');
    del.title = 'Remove this command';
    del.onclick = function () { SMSCMD.rows.splice(i, 1); markSmsCmd(); paintSmsCmd(STATE.status); };
    var replyCell = el('div', 'smscmd-replycell');
    // A command that raises an alarm has nothing to say back. This puts the
    // answer away rather than making somebody empty the box and remember why.
    var answerRow = el('div', 'smscmd-answer');
    var answerSw = makeSwitch(c.answer !== false, function (on) {
      c.answer = on; markSmsCmd(); showAnswer(on);
    }, {small: true, title: 'Off, and nothing is texted back \u2014 for a command that raises an alarm rather than answering a question'});
    answerRow.appendChild(answerSw);
    answerRow.appendChild(el('span', 'muted small', 'text something back'));
    replyCell.appendChild(answerRow);
    replyCell.appendChild(reply);
    var tools = el('div', 'msg-tools');
    var emoji = el('button', 'btn small'); emoji.type = 'button'; emoji.textContent = '\ud83d\ude00 Emoji';
    emoji.title = 'Put a symbol where the cursor is';
    emoji.onclick = function (e) { e.stopPropagation(); openEmojiPicker(emoji, reply, function (v) { c.reply = v; markSmsCmd(); scheduleSmsPreview(); }); };
    var facts = el('button', 'btn small'); facts.type = 'button'; facts.textContent = '{ } Facts';
    facts.title = 'Every fact with an example of what it would say right now. In the text itself: type { or press Ctrl+Space.';
    facts.onclick = function (e) {
      e.stopPropagation();
      openFactPicker(facts, reply, function (v) { c.reply = v; markSmsCmd(); scheduleSmsPreview(); },
                     function () { return rowVars(c).concat(phraseNames(c.phrase)); });
    };
    tools.appendChild(emoji); tools.appendChild(facts);
    var varsBtn = el('button', 'btn small'); varsBtn.type = 'button';
    varsBtn.textContent = '{ } Variables';
    varsBtn.title = 'Names this command makes up for what the message carries';
    // A command that lets an address back in, answering anybody who knows the
    // word, is a door with the key under the mat. Said here, where it is set.
    var warnAnyone = function () {
      var risky = (c.do === 'ban' || c.do === 'unban') && c.from_anyone;
      varsBtn.classList.toggle('danger', !!risky);
      varsBtn.title = risky
        ? 'This command works the blocked list and answers anybody who knows the word \u2014 somebody '
          + 'kept out could text it and let themselves back in. Turn "from anyone" off unless that is meant.'
        : 'Names this command makes up for what the message carries';
    };
    warnAnyone();
    varsBtn.onclick = function (e) {
      e.stopPropagation();
      editRowVars(c, 'command', function () { markSmsCmd(); scheduleSmsPreview(); });
    };
    tools.appendChild(varsBtn);
    // what the answer will cost to send, as it is written: a diacritic
    // anywhere halves what fits in a message, which is worth seeing before
    // the answer goes out rather than on the bill
    var cost = el('span', 'muted small smscmd-cost');
    var showCost = function () {
      var written = reply.value || '';
      var wide = /[^\x00-\x7F]/.test(written);
      var one = wide ? 70 : 160, more = wide ? 67 : 153;
      var parts = !written.length ? 0 : (written.length <= one ? 1 : Math.ceil(written.length / more));
      cost.textContent = !written.length ? ''
        : written.length + ' characters \u00b7 ' + parts + ' message' + (parts === 1 ? '' : 's')
          + (wide ? ' (a diacritic halves what fits \u2014 {\u2026.ascii} sends it plainly)' : '');
    };
    reply.addEventListener('input', showCost);
    showCost();
    tools.appendChild(cost);
    replyCell.appendChild(tools);
    var pre = el('div', 'msg-preview sms'); pre.dataset.smsfor = String(i);
    replyCell.appendChild(pre);
    function showAnswer(on) {
      reply.disabled = !on;
      tools.hidden = !on;
      pre.hidden = !on;
      replyCell.classList.toggle('quiet', !on);
    }
    showAnswer(c.answer !== false);
    var doCell = el('div', 'smscmd-do');
    doCell.appendChild(doSel); doCell.appendChild(tellNote);
    [phrase, target, doCell, takes, anyone, del, replyCell].forEach(function (x) { row.appendChild(x); });
    attachCardMenu(row, {head: c.phrase || 'command', rows: [
      ['\u25b6 Try it now', function () {
        withPin('Try \u201c' + (c.phrase || '') + '\u201d', 'It does exactly what an SMS would.', function (pin) {
          return post('sms-try', {pin: pin, text: c.phrase}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'nothing matched'); return r.message || 'done';
          });
        });
      }],
      ['\ud83d\udccb Copy the phrase', function () { copyToClipboard(c.phrase || '', 'Phrase'); }]
    ]});
    makeRowSortable(row, host, SMSCMD, markSmsCmd, function () { paintSmsCmd(STATE.status); }, c);
    host.appendChild(row);
  });
  sectionise(host, SMSCMD, 'smscmd', markSmsCmd, function () { paintSmsCmd(STATE.status); });
  scheduleSmsPreview();
}
$('smscmd-add').onclick = function () {
  SMSCMD.rows = SMSCMD.rows || [];
  SMSCMD.rows.push({id: '', phrase: '', target: '', do: 'on', reply: '', enabled: true});
  markSmsCmd(); paintSmsCmd(STATE.status);
};
$('smscmd-save').onclick = function () {
  withPin('Save the SMS commands', 'The gateway is listened to at once.', function (pin) {
    return post('sms-commands', {commands: rowsToSave(SMSCMD, 'SMS commands'), pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not save');
      saveGroups('smscmd', SMSCMD);
      SMSCMD.dirty = false; SMSCMD.rows = null; $('smscmd-note').textContent = ''; forgetSig('smscmd'); tick(true);
      return (r.commands || []).length + ' command(s) saved';
    });
  });
};

// ---- action groups: several things switched under one name -------------------
var AGROUPS = { rows: null, dirty: false };
function markAGroups() { AGROUPS.dirty = true; $('agroup-note').textContent = 'Unsaved changes'; }
function renderAGroups(st) {
  if (AGROUPS.dirty) return;
  if (AGROUPS.rows === null) {
    api('action-groups').then(function (r) {
      if (AGROUPS.dirty) return;
      AGROUPS.rows = (r.groups || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
      paintAGroups(st);
    }, function () { AGROUPS.rows = []; paintAGroups(st); });
    return;
  }
  paintAGroups(st);
}
function paintAGroups(st) {
  if (editorBusy('agroups-list')) return;
  var host = $('agroups-list'); host.innerHTML = '';
  var rows = AGROUPS.rows || [];
  if (!rows.length) host.appendChild(el('div', 'muted small', 'No group yet. One name can stand for every light on a floor.'));
  // everything switchable except the groups themselves
  var choices = cachedTargetOptions(st).filter(function (o) { return String(o[0]).indexOf('act:') !== 0 && o[0] !== '*'; });
  rows.forEach(function (g, i) {
    var row = el('div', 'sgroup-row agroup-row');
    var name = el('input'); name.value = g.name || ''; name.placeholder = 'Lights downstairs';
    name.title = 'What to call this group. It appears wherever a target can be picked.';
    name.oninput = function () { g.name = name.value; markAGroups(); };
    var count = el('span', 'sgroup-now', String((g.members || []).length));
    count.title = 'How many things this group switches';
    var enabled = makeSwitch(g.enabled !== false, function (on) { g.enabled = on; markAGroups(); },
                             {small: true, title: 'A group switched off does nothing when it is used'});
    var del = cmdButton('', 'trash', 'small iconbtn danger'); del.classList.remove('needs-unlock');
    del.title = 'Remove this group';
    del.onclick = function () { AGROUPS.rows.splice(i, 1); markAGroups(); paintAGroups(STATE.status); };
    var pick = el('div', 'sgroup-members');
    choices.forEach(function (o) {
      var on = (g.members || []).indexOf(o[0]) >= 0;
      var chip = el('label', 'sgroup-chip' + (on ? ' on' : ''));
      var box = el('input'); box.type = 'checkbox'; box.checked = on;
      box.onchange = function () {
        g.members = (g.members || []).filter(function (m) { return m !== o[0]; });
        if (box.checked) g.members.push(o[0]);
        markAGroups(); paintAGroups(STATE.status);
      };
      chip.appendChild(box);
      chip.appendChild(el('span', '', o[1]));
      attachTargetReadings(chip, function () { return o[0]; });
      pick.appendChild(chip);
    });
    [enabled, name, count, del].forEach(function (x) { row.appendChild(x); });
    row.appendChild(pick);
    attachCardMenu(row, {head: g.name || 'group', rows: [
      ['\ud83d\udd0c Switch it off now', function () { runTarget('act:' + g.id, 'off', g.name); }],
      ['\ud83d\udca1 Switch it on now', function () { runTarget('act:' + g.id, 'on', g.name); }],
      ['\ud83d\udccb Copy its name', function () { copyToClipboard(g.name || '', 'Name'); }]
    ]});
    makeRowSortable(row, host, AGROUPS, markAGroups, function () { paintAGroups(STATE.status); }, g);
    host.appendChild(row);
  });
  sectionise(host, AGROUPS, 'agroups', markAGroups, function () { paintAGroups(STATE.status); });
}
function runTarget(target, action, label) {
  withPin((label || target) + ': ' + action, 'It happens at once.', function (pin) {
    return post('target-set', {target: target, do: action, pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not'); return r.message || (label + ' \u2192 ' + action);
    });
  });
}
$('agroup-add').onclick = function () {
  AGROUPS.rows = AGROUPS.rows || [];
  AGROUPS.rows.push({id: '', name: '', members: [], enabled: true});
  markAGroups(); paintAGroups(STATE.status);
};
$('agroup-save').onclick = function () {
  withPin('Save action groups', 'They can be used as targets at once.', function (pin) {
    return post('action-groups', {groups: rowsToSave(AGROUPS, 'action groups'), pin: pin}).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not save');
      saveGroups('agroups', AGROUPS);
      AGROUPS.dirty = false; AGROUPS.rows = null; $('agroup-note').textContent = ''; forgetSig('agroups'); tick(true);
      return (r.groups || []).length + ' group(s) saved';
    });
  });
};

// ---- schedules: every <day(s)> at <time>, switch <target> ---------------------------
var SCHEDULES = { rows: null, dirty: false };
function markSchedules() { SCHEDULES.dirty = true; $('schedule-note').textContent = 'Unsaved changes'; }
var SCHED_DAYS = [['mon', 'Mo'], ['tue', 'Tu'], ['wed', 'We'], ['thu', 'Th'], ['fri', 'Fr'], ['sat', 'Sa'], ['sun', 'Su']];
function renderSchedules(st) {
  if (SCHEDULES.dirty) return;                    // unsaved edits anywhere in the table: leave it alone
  if (editorBusy('schedules-list')) return;
  if (SCHEDULES.rows === null) {
    api('schedules').then(function (r) {
      if (SCHEDULES.dirty) return;                 // became dirty while this request was in flight
      SCHEDULES.rows = (r.schedules || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
      paintSchedules(st);
    }, function () {});
    return;
  }
  paintSchedules(st);
}
function schedTargetOptions(st) {
  // the same list a rule or a binding offers, minus "all plugs": a schedule
  // that switches everything is a scene, and reads better as one
  return targetOptions(st).filter(function (o) { return o[0] !== '*'; });
}
function paintSchedules(st) {
  var host = $('schedules-list'); host.innerHTML = '';
  var rows = SCHEDULES.rows || [];
  if (!rows.length) host.appendChild(el('div', 'muted small', 'No schedule yet.'));
  var options = schedTargetOptions(st);
  rows.forEach(function (sch, i) {
    var row = el('div', 'sched-row');
    var target = el('select');
    var opts = options.slice();
    if (sch.target && !opts.some(function (o) { return o[0] === sch.target; })) opts.push([sch.target, sch.target + ' (gone)']);
    sch.target = fillSelect(target, opts, sch.target);
    attachTargetReadings(target, function () { return sch.target; });
    target.onchange = function () {
      sch.target = target.value;
      if (settableTarget(st, sch.target) && String(sch.do).indexOf('set:') !== 0) sch.do = 'set:';
      if (!settableTarget(st, sch.target) && String(sch.do).indexOf('set:') === 0) sch.do = 'on';
      refillDoS(); syncSchedDo(); markSchedules();
    };

    var days = el('div', 'sched-days');
    (sch.days = sch.days && sch.days.length ? sch.days.slice() : [0, 1, 2, 3, 4, 5, 6]);
    SCHED_DAYS.forEach(function (d, di) {
      var chip = el('span', 'sched-day' + (sch.days.indexOf(di) >= 0 ? ' on' : ''), d[1]);
      chip.title = d[0];
      chip.onclick = function () {
        var pos = sch.days.indexOf(di);
        if (pos >= 0) sch.days.splice(pos, 1); else sch.days.push(di);
        chip.classList.toggle('on');
        markSchedules();
      };
      days.appendChild(chip);
    });

    var atBox = el('span', 'sched-at');
    var parsed = /^(sunrise|sunset)([+-]\d{1,3})?$/.exec(sch.at || '');
    var atKind = el('select');
    fillSelect(atKind, TIME_KIND_OPTIONS, parsed ? parsed[1] : 'clock');
    var atClock = el('input'); atClock.type = 'time'; atClock.value = parsed ? '' : (sch.at || '07:00');
    var atOff = el('input'); atOff.type = 'number'; atOff.className = 'woff'; atOff.step = 5; atOff.min = -180; atOff.max = 180;
    atOff.value = parsed && parsed[2] ? parseInt(parsed[2], 10) : 0;
    var atOffLbl = el('span', 'muted', 'min');
    function syncAt() {
      atClock.hidden = atKind.value !== 'clock';
      atOff.hidden = atOffLbl.hidden = atKind.value === 'clock';
      sch.at = atKind.value === 'clock' ? (atClock.value || '07:00')
        : atKind.value + (parseInt(atOff.value, 10) ? (atOff.value > 0 ? '+' : '') + atOff.value : '');
    }
    atKind.onchange = function () { syncAt(); markSchedules(); };
    atClock.onchange = function () { syncAt(); markSchedules(); };
    atOff.onchange = function () { syncAt(); markSchedules(); };
    syncAt();
    [atKind, atClock, atOff, atOffLbl].forEach(function (x) { atBox.appendChild(x); });
    atBox.title = 'When it runs. A clock time, or sunrise / sunset with an offset in minutes.';

    var doSel = el('select');
    var setBoxS = setValueBox(st, null, function (v) { sch.do = v; markSchedules(); });
    function refillDoS() {
      var keep = sch.do || 'on';
      fillSelect(doSel, doOptionsFor(st, sch.target, keep), String(keep).indexOf('set:') === 0 ? 'set:' : keep);
      runsItsOwnSteps(doSel, sch.target);
      attachTargetReadings(doSel, function () { return sch.target; });
      sch.do = String(keep).indexOf('set:') === 0 ? keep : (doSel.value || 'on');
      setBoxS.refresh(sch.target, sch.do);
    }
    refillDoS();
    var ms = el('input'); ms.type = 'number'; ms.style.width = '84px'; ms.step = 100; ms.value = sch.pulse_ms || 5000; ms.hidden = sch.do !== 'pulse'; ms.title = 'pulse hold, ms';
    ms.oninput = function () { sch.pulse_ms = parseInt(ms.value, 10) || 5000; markSchedules(); };
    doSel.onchange = function () { sch.do = doSel.value; setBoxS.refresh(sch.target, sch.do); syncSchedDo(); markSchedules(); };
    var tellNote = el('span', 'muted small', 'sends the message');
    tellNote.title = 'Nothing is switched \u2014 what it says is set under Alerts & energy \u2192 Messages';
    function syncSchedDo() {
      var tells = isNotifyTarget(sch.target);
      doSel.hidden = tells; tellNote.hidden = !tells;
      ms.hidden = tells || sch.do !== 'pulse';
      if (tells) sch.do = 'on';
    }
    var doBox = el('span'); doBox.appendChild(doSel); doBox.appendChild(setBoxS); doBox.appendChild(tellNote); doBox.appendChild(ms);
    syncSchedDo();

    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.onclick = function () { SCHEDULES.rows.splice(i, 1); markSchedules(); paintSchedules(STATE.status); };

    var onSwS = makeSwitch(sch.enabled !== false, function (v) { sch.enabled = v; row.classList.toggle('off', !v); markSchedules(); }, {small: true, title: 'Enabled: the schedule runs. Off: kept, but skipped.'});
    row.classList.toggle('off', sch.enabled === false);
    [onSwS, target, days, atBox, doBox, del].forEach(function (x) { row.appendChild(x); });
    makeRowSortable(row, host, SCHEDULES, markSchedules, function () { paintSchedules(STATE.status); }, sch);
    host.appendChild(row);
  });
  sectionise(host, SCHEDULES, 'schedules', markSchedules, function () { paintSchedules(STATE.status); });
  if (!SCHEDULES.dirty) $('schedule-note').textContent = '';
}
$('schedule-add').onclick = function () {
  SCHEDULES.rows = SCHEDULES.rows || [];
  SCHEDULES.rows.push({target: (schedTargetOptions(STATE.status)[0] || [''])[0], days: [0, 1, 2, 3, 4, 5, 6], at: '07:00', do: 'on'});
  markSchedules(); paintSchedules(STATE.status);
};
$('schedule-save').onclick = function () {
  withPin('Save schedules', 'They take effect at once; the next matching day and time will fire.', function (pin) {
    return post('schedules-save', {schedules: rowsToSave(SCHEDULES, 'schedules'), pin: pin}).then(function (r) {
      saveGroups('schedules', SCHEDULES);
      SCHEDULES.dirty = false; SCHEDULES.rows = null; forgetSig('schedules');
      return (r.schedules || []).length + ' schedule(s) saved';
    });
  });
};
// ---- scenes -------------------------------------------------------------------------
var SCENES = { rows: null, dirty: false };
function markScenes() { SCENES.dirty = true; $('scene-note').textContent = 'Unsaved changes'; }
function sceneTargetOptions(st) {
  // A scene may do anything a button can, bar starting itself: sockets, Zigbee
  // switches, heating, sequences, notifications, and switching a rule or a
  // schedule off. Only scenes are left out, since a scene running a scene is
  // a knot nobody wants to unpick at three in the morning.
  var out = (st.plugs || []).filter(function (p) { return !p.monitor_only; }).map(function (p) { return [p.name, withIcon(plugRoleKind(p), p.name)]; });
  heatingTargetOptions(st).forEach(function (o) { out.push(o); });
  (st.switch_targets || []).forEach(function (t) { if (t.value.indexOf('heat:') === 0) return; out.push([t.value, withIcon('zb', t.name)]); });
  sequenceTargetOptions(st).forEach(function (o) { out.push(o); });
  var allPlugs = st.plugs || [];
  if (allPlugs.filter(function (p) { return (p.role || 'plug') !== 'light'; }).length > 1)
    out.push(['*', withIcon('all', 'all sockets')]);
  if (allPlugs.filter(function (p) { return (p.role || 'plug') === 'light'; }).length > 1)
    out.push(['*lights', withIcon('light', 'all lights')]);
  out.push(['notify', ICON.bell + ' notify me (automatic text)']);
  // the same automatic text, but down one road only
  out.push(['notify@ntfy', ICON.bell + ' notify me \u2014 ntfy only']);
  out.push(['notify@telegram', ICON.bell + ' notify me \u2014 Telegram only']);
  out.push(['notify@sms', ICON.bell + ' notify me \u2014 text only']);
  // things the house does to itself: a button by the door can hush the alerts
  // for an hour, take a backup, or make everything say where it stands
  out.push(['sys:quiet:1h', '\ud83d\udd15 hush the alerts for an hour']);
  out.push(['sys:quiet:8h', '\ud83d\udd15 hush the alerts overnight']);
  out.push(['sys:clear', '\u2713 clear the standing alerts']);
  out.push(['sys:refresh', '\u21bb ask everything where it stands']);
  out.push(['sys:backup', '\ud83d\udcbe take a backup now']);
  out.push(['sys:digest', '\ud83d\udcc4 send the daily summary now']);
  (((st.presence || {}).people) || []).forEach(function (p) {
    // presence calls the number "number"; "phone" there means what their
    // phone last said about being home
    if (p.number) out.push(['notify@sms:' + p.id, ICON.bell + ' text ' + p.name]);
  });
  (st.messages || []).forEach(function (m) { out.push(['notify:' + m.id, ICON.bell + ' ' + m.name]); });
  (st.switchable_targets || []).forEach(function (t) { out.push([t.value, ICON.autoswitch + ' ' + t.name + (t.on ? '' : ' (off)')]); });
  return sortByKind(out);
}
// ---- One-tap links ----------------------------------------------------------
// What the watch would read out, asked for as the text is typed. Nothing is
// sent and nothing is changed, so it needs no PIN - the same endpoint an
// alert's preview uses.
var TELL_PREVIEW_TIMER = null;
function scheduleTellPreview() {
  clearTimeout(TELL_PREVIEW_TIMER);
  TELL_PREVIEW_TIMER = setTimeout(function () {
    (TAPS.rows || []).forEach(function (tap, i) {
      var box = document.querySelector('.tap-preview[data-tap="' + (tap.id || String(i)) + '"]');
      if (!box) return;
      // only a telling link has something to preview: a switch says what it
      // did, and what it did has not happened yet
      if (tap.target !== 'tell') { box.innerHTML = ''; delete box.dataset.shown; return; }
      // every report gets a preview, not only one of your own: a prepared one
      // is worth seeing before it is put on a watch as well
      var want = (tap.do || 'house') + '\u0000' + (tap.text || '');
      if (box.dataset.shown === want) return;
      var ask = (tap.do === 'own')
        ? (tap.text ? api('message-preview&title=&text=' + encodeURIComponent(tap.text))
                        .then(function (r) { return (r && (r.preview || r.text)) || ''; })
           : Promise.resolve(''))
        : api('tell&what=' + encodeURIComponent(tap.do || 'house'))
            .then(function (r) { return (r && r.said) || ''; });
      ask.then(function (said) {
        // Look the box up again rather than writing into the one this round
        // began with. A redraw between the asking and the answering throws
        // that one away, and the answer was being written into a box no
        // longer on the page - the preview simply never appeared, on that
        // link, until something else made the card redraw. Which is why it
        // was missing only sometimes and only somewhere.
        var live = document.querySelector('.tap-preview[data-tap="' + (tap.id || String(i)) + '"]');
        if (!live) return;
        live.dataset.shown = want;
        live.innerHTML = '';
        if (!said) {
          // A prepared report with nothing to say right now is an answer
          // too, and a blank line is indistinguishable from a preview that
          // failed to arrive.
          if (tap.do !== 'own') live.appendChild(el('div', 'lbl', 'nothing to report just now'));
          return;
        }
        // The preview reads the row as it stands here, and until it is saved
        // the link itself still does the old thing. Saying so is the whole
        // difference between a preview and a lie.
        live.appendChild(el('div', 'lbl' + (TAPS.dirty ? ' warn' : ''),
          TAPS.dirty ? 'once saved, the watch would say' : 'the watch would say'));
        live.appendChild(el('div', '', said));
      }, function () {
        // the daemon did not answer: do not remember this round, so the next
        // redraw asks again instead of leaving the line blank for ever
        var live = document.querySelector('.tap-preview[data-tap="' + (tap.id || String(i)) + '"]');
        if (live) delete live.dataset.shown;
      });
    });
  }, 350);
}

// The address is the whole of a link's authority, so it is not in the page's
// own data: the dialog asks for it with the PIN, the same way the phone setup
// asks for a person's token.
function showTapSetup(tap) {
  if (TAPS.dirty) {
    // the address below would do what was saved, not what is on the screen
    toast('Save the links first \u2014 this one still does what it did before', false);
    return;
  }
  withPin('How to use \u201c' + (tap.name || 'this link') + '\u201d',
    'Shows the steps for a watch or a phone, with the address itself. Anyone who reads that '
    + 'address can do this one thing, so treat the screen as you would a password.',
    function (pin) {
      return post('taps-address', {id: tap.id, pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        paintTapSetup(tap, r);
        return 'shown';
      });
    });
}

function paintTapSetup(tap, r) {
  var url = r.url, plain = r.plain_url, needsRule = r.needs_rule;
  var mode = r.mode || 'link', wantsCode = !!r.code;
  var duo = wantsCode && (r.factor || 'totp') === 'duo';
  var items = [];
  function step(n, title, html) { items.push({level: 'dim', tag: String(n), who: title, why: html || '', rich: true}); }
  // every value that can be carried away looks the same wherever it is: one
  // chip, click to copy, hover for a code. A value dressed differently from
  // the rest reads as a different kind of thing, and it is not one.
  function copyable(text) {
    // the whole value in the tooltip as well, since a long one is drawn cut
    return '<code class="copyme" data-copy="' + esc(text) + '" title="' + esc(text)
      + ' \u2014 click to copy \u00b7 hover for a QR code">' + esc(text) + '</code>';
  }
  var what = '<b>' + esc(doLabel(tap.do || 'toggle')) + ' '
    + esc(targetLabel(STATE.status, tap.target || '')) + '</b>, and nothing else';
  if (mode !== 'link') {
    // the header road: one address for every link, the secret beside it
    items.push({section: 'By a header' + (mode === 'header' ? '' : ' \u2014 the way to move to')});
    items.push({level: 'ok', tag: 'post', who: 'POST to this address', rich: true,
      why: copyable(r.post_url) + '<br>The same for every link here. Opening it does nothing on its own: '
        + 'what it does is decided by the secret below.'});
    items.push({level: 'ok', tag: 'hdr', who: 'with this header', rich: true,
      why: copyable('X-Zigmon-Tap') + ' ' + copyable(r.token) + '<br>That does ' + what + '. '
        + 'Hover it, or the address above, for a QR code to carry to the phone \u2014 neither has to '
        + 'be typed.'});
    if (duo) {
      items.push({level: 'ok', tag: 'duo', who: 'and Duo approves it', rich: true,
        why: 'The press does not act on its own: it asks Duo, and Duo asks '
          + '<b>' + esc(r.duo_user || 'you') + '</b>. Approve it and the thing happens. Duo has a watch app, '
          + 'so a press made on the wrist is approved on the wrist \u2014 there is no second header to fill '
          + 'in and nothing to fetch from another app.'
          + (r.duo_ready ? '' : ' <b>Duo is not set up yet</b> \u2014 Settings \u2192 One-tap links.')});
    } else if (wantsCode) {
      items.push({level: 'ok', tag: 'code', who: 'and a code from the phone', rich: true,
        why: copyable('X-Zigmon-Code') + ' \u2014 six digits from 2FAS, OTP Auth or Raivo. The authenticator has a '
          + 'Shortcuts action that hands the current one back \u2014 put it before the request and give it '
          + 'to the header.' + ((r.keys || []).length ? ' Set up: <b>'
          + esc((r.keys || []).map(function (k) { return k.name; }).join(', ')) + '</b>.'
          : ' <b>No phone is set up yet</b> \u2014 add one under One-tap links.')});
    }
    items.push({level: 'dim', tag: 'why', who: 'Why this is better than the address', rich: true,
      why: 'A URL is written down everywhere it goes: the web server\u2019s log, any proxy on the way, the '
        + 'browser\u2019s history, and the robot that fetches a link preview when the address is pasted '
        + 'into a message \u2014 which physically presses it. A header is in none of those.'});
    items.push({level: 'warn', tag: 'cost', who: 'What it costs', rich: true,
      why: 'There is no address left that can simply be opened, so a bookmark or a watch-face complication '
        + 'that only opens a URL will not do \u2014 it has to be a shortcut. '
        + (mode === 'both' ? 'The old address still works for now.'
           : 'The old addresses are refused; every use of one is written in <b>Events</b>.')});
  }
  if (mode !== 'header') {
    items.push({section: 'The address'});
    items.push({level: mode === 'link' ? 'ok' : 'dim', tag: 'url', who: 'This is the link', rich: true,
      why: copyable(url) + '<br>Opening it does one thing: ' + what + '.'});
    items.push({level: 'warn', tag: 'how', who: 'Scan it, do not type it', rich: true,
      why: 'Hover the address for a QR code and scan that with the phone\u2019s camera. Typed by hand or '
        + 'dictated, a phone will helpfully change a full stop or an equals sign into a hyphen, and the '
        + 'address then goes nowhere \u2014 <code>index-php?api-tap</code> in the web server\u2019s log is '
        + 'exactly that. <b>zigmon --taps-test</b> from the machine says whether an address works.'});
  }
  if (mode !== 'header' && needsRule && plain) {
    items.push({level: 'dim', tag: 'rule', who: 'That short shape needs one line in nginx', rich: true,
      why: 'The installer\u2019s configuration has it; an older one may not. Without it use '
        + copyable(plain) + ' instead, or add this and reload nginx:<br>'
        + '<code>location ~ ^/tap/([A-Za-z0-9_-]{8,64})$ { rewrite ^ /index.php?t=$1 last; }</code>'});
  }
  items.push({section: 'On an Apple Watch or iPhone'});
  var n = 0;
  var next = function (title, why) { n++; step(n, title, why); };
  next('Open <b>Shortcuts</b> on the phone', 'The watch takes its shortcuts from the phone.');
  if (mode === 'header' && duo) {
    next('Add Action \u2192 <b>Get Contents of URL</b>');
  } else if (mode === 'header' && wantsCode) {
    // numbered in the order the actions stand in the shortcut: the code has
    // to be fetched before the request that carries it, and "add this before
    // the last one" is a step nobody follows without going back
    next('New shortcut \u2192 Add Action \u2192 your authenticator\u2019s <b>current code</b>',
      '2FAS calls it <i>Get Token</i>, OTP Auth <i>Get Code</i>, Raivo <i>Get OTP</i> \u2014 whichever '
      + 'yours is, it hands back the six digits showing right now. It goes <b>first</b>, so the request '
      + 'underneath can use what it returns.');
    next('Add Action \u2192 <b>Get Contents of URL</b>');
  } else {
    next('New shortcut \u2192 Add Action \u2192 <b>Get Contents of URL</b>');
  }
  if (mode === 'header') {
    next('Paste the address above', 'The one that is the same for every link.');
    next('Open <b>Show More</b> \u2192 Method: <b>POST</b>');
    next('Headers \u2192 add ' + copyable('X-Zigmon-Tap'),
      'and paste the secret above as its value \u2014 or hover it here for a QR code and take it off '
      + 'the screen with the phone\u2019s camera.'
      + (duo ? ' That is the only header: Duo is asked by the daemon, not by the shortcut.'
         : (wantsCode ? ' Then a second header ' + copyable('X-Zigmon-Code') + ': put the cursor in its value box '
            + 'and pick the <b>Code</b> the first action handed back from the variables above the keyboard, '
            + 'rather than typing anything into it.' : '')));
    next('Request Body: leave it empty',
      'Or <i>JSON</i> with <code>ask</code> set to true, for a shortcut that only tells you how things '
      + 'stand and touches nothing.');
    if (duo) {
      next('Add <b>Get Dictionary Value</b> \u2192 <code>message</code>, then <b>Show Result</b>',
        'That is the whole shortcut. The request waits where it is until you approve the push \u2014 '
        + 'the answer only comes when there is something to say, and it says what was done: '
        + '<i>Light-Chodba is on</i>. Refused says so, and nothing happening in time says that.');
      next('Nothing else is needed',
        'No second request, no ticket, no code. If you would rather not have the shortcut wait, put '
        + '<code>{"wait": false}</code> in the body: it comes back at once with a <code>ticket</code>, '
        + 'and a second request with a ' + copyable('X-Zigmon-Wait') + ' header carrying that ticket '
        + 'fetches the outcome later.');
    }
  } else {
    next('Paste the address above', 'Nothing else to change \u2014 the method stays GET.');
  }
  next('To send something with the press, add ' + copyable('X-Zigmon-Arg-ip'),
    'Any header whose name begins <code>X-Zigmon-Arg-</code> arrives as a fact of that name: '
    + '<code>X-Zigmon-Arg-Room: Loznice</code> is <code>{room}</code> in whatever this link says '
    + 'or does. Nothing is set up for it \u2014 the name of the header is the name of the fact \u2014 '
    + 'and a link whose action is <i>let that address back in</i> takes its address the same way.');
  next('Name it and give it an icon',
    'The name is what you will tap, so make it short: <i>' + esc(tap.name || 'Lamp') + '</i>.');
  next('Shortcut Details \u2192 <b>Show on Apple Watch</b>',
    'Then on the watch: the Shortcuts app, or add it to the Control Center, or put it on a watch face '
    + 'as a complication for one tap from the wrist.');
  items.push({section: 'Seeing what happened'});
  items.push({level: 'dim', tag: 'state', who: 'The link answers with the state', rich: true,
    why: 'It comes back as <code>{"ok":true,"state":"on","message":"Lampa is now on"}</code>. In the '
      + 'shortcut, add <b>Show Result</b> after <i>Get Contents of URL</i> and the watch will say '
      + '<i>Lampa is now on</i> when you tap it. For several things at once it says <i>3 of 8 on</i>.'});
  items.push({level: 'dim', tag: 'ask', who: 'Or ask without switching anything', rich: true,
    why: mode === 'header'
      ? 'Give the request a JSON body of <code>{"ask": true}</code> and it reports how things stand and '
        + 'touches nothing. Useful as a second shortcut that only tells you.'
      : 'Put <code>?ask</code> on the end and it reports how things stand and touches nothing:<br>'
        + copyable(url + '?ask') + '<br>Useful as a second shortcut that only tells you.'});
  items.push({level: 'warn', tag: 'icon', who: 'The icon itself cannot change colour', rich: true,
    why: 'A shortcut\u2019s icon and colour are fixed when it is made; watchOS gives no way to paint '
      + 'them from an answer. For a tile that shows on and off in colour the way the Home app does, '
      + 'the devices have to be in HomeKit \u2014 through Homebridge or a Matter bridge \u2014 which is a '
      + 'different road from this one.'});
  items.push({section: 'On Android'});
  items.push({level: 'dim', tag: 'droid', who: 'A browser bookmark, or HTTP Shortcuts', rich: true,
    why: 'Any app that can fetch a URL will do. <b>HTTP Shortcuts</b> puts one on the home screen '
      + 'and on a Wear OS tile.'});
  items.push({section: 'Away from home'});
  items.push({level: 'dim', tag: 'out', who: 'It works wherever the dashboard is reachable', rich: true,
    why: 'On the home Wi-Fi it always works. From outside, the dashboard has to answer from the internet, '
      + 'and the address has to say so \u2014 set <b>Where the dashboard answers from outside</b> in Settings. '
      + 'On a watch with its own SIM that is the difference between working in the garden and working anywhere.'});
  items.push({section: 'What it can and cannot do'});
  items.push({level: 'warn', tag: 'safe',
    who: mode === 'header' ? (wantsCode ? 'The header and the code are the whole credential'
                                        : 'The header is the whole credential')
                           : 'The address is the whole credential', rich: true,
    why: 'Whoever holds it can ' + esc(doLabel(tap.do || 'toggle')) + ' '
      + esc(targetLabel(STATE.status, tap.target || '')) + ' \u2014 and nothing else. No PIN, no settings, '
      + 'no other device. Every use is written in <b>Events</b>. Withdrawing the link with the bin stops '
      + 'it working at once.'});
  showDetail('One-tap link \u2014 ' + (tap.name || ''), items, null, true);
  Array.prototype.forEach.call($('attnbody').querySelectorAll('.copyme'), function (c) {
    c.onmouseenter = function () { showQr(c); };
    c.onmouseleave = hideQr;
    c.onclick = function () { copyText(c.dataset.copy); };
  });
  // a link that has been seen by the wrong person is replaced, not withdrawn:
  // the same one thing, a new address, and the old one dead at once
  var again = cmdButton('Make a new address', 'reset', 'small danger');
  again.classList.remove('needs-unlock');
  again.title = 'Throw this address away and issue another \u2014 whatever is holding the old one stops working';
  again.style.marginTop = '12px';
  again.onclick = function () {
    withPin('New address for \u201c' + (tap.name || 'this link') + '\u201d',
      'The address above stops working at once, and the shortcut on the watch has to be given the new one.',
      function (pin2) {
        return post('taps-address', {id: tap.id, pin: pin2, roll: true}).then(function (rr) {
          if (!rr.ok) throw new Error(rr.error || 'could not make one');
          paintTapSetup(tap, rr);
          return 'a new address is ready';
        });
      }, true);
  };
  $('attnbody').appendChild(again);
}

var TAPS = {rows: null, dirty: false, groups: null};
function renderTaps(st) {
  var host = $('taps-list');
  if (!host) return;
  if (!TAPS.dirty) TAPS.rows = JSON.parse(JSON.stringify(st.taps || []));
  // the phones and the two settings ride in the same signature: they are
  // drawn by this card and would otherwise sit there stale until something
  // about a link happened to change
  var rc = st.runtime_config || {};
  if (!sigChanged('taps', [TAPS.rows, isUnlocked(), st.tap_keys, st.duo_ready,
                           (rc.tap_mode || {}).value, (rc.tap_code || {}).value,
                           (rc.tap_factor || {}).value])) return;
  host.innerHTML = '';
  $('taps-dirty').textContent = TAPS.dirty ? 'not saved yet' : '';
  host.appendChild(tapModeStrip(st));
  var head = el('div', 'tap-row tap-head');
  ['On', 'What it is for', 'What it acts on', 'What it does', 'By hand', 'Used', '']
    .forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  (TAPS.rows || []).forEach(function (row_model, index) {
    // A redraw replaces TAPS.rows with fresh copies read from the state, so a
    // handler that holds on to the object it was built with writes into one
    // that has already been thrown away - which is why editing a link that
    // was there before worked on a new one and not on an old one. Look the
    // live row up by its id at the moment of the event instead.
    var tapId = row_model.id;
    var tap = row_model;
    var live = function () {
      var now = (TAPS.rows || []).filter(function (x) { return x.id && x.id === tapId; })[0];
      return now || (TAPS.rows || [])[index] || tap;
    };
    var row = el('div', 'tap-row');
    // switched off keeps the link and its address, and refuses to act on it:
    // the way to take a thing off a watch for a while without unpicking it
    var on = switchRow('', tap.enabled !== false, function () {
      live().enabled = !!on.input.checked; touched(); row.classList.toggle('offrow', !on.input.checked);
    }, {small: true});
    on.title = 'Switched off, the address answers but does nothing';
    row.classList.toggle('offrow', tap.enabled === false);
    var touched = function () { TAPS.dirty = true; $('taps-dirty').textContent = 'not saved yet'; };
    var name = el('input');
    name.value = tap.name || '';
    name.placeholder = 'Lamp by the bed';
    name.oninput = function () { live().name = name.value; touched(); };
    var target = el('select');
    // Telling is offered here and nowhere else, at the head of the list: a
    // rule or a scene cannot ask the house a question.
    var targetChoices = [['tell', '\ud83d\udcac tell me something'],
                         ['{ip}', '\u26d4 an address the press carries']]
      .concat((SCRIPTS.rows || []).filter(function (x) { return x.id && x.name; })
        .map(function (x) { return ['script:' + x.id, '\ud83d\udcdc ' + x.name]; }))
      .concat(sortWithinHeadings(targetOptions(st)));
    fillSelect(target, targetChoices, tap.target || 'tell');
    var act = el('select');
    var actsFor = function (targetValue) {
      // asked to tell, the actions are the reports; otherwise they are the
      // ways of switching whatever it points at. The two lists always agree,
      // which is the whole point of one deciding the other.
      if ((targetValue || 'tell') === 'tell') {
        return (st.tells || []).map(function (x) { return [x.key, x.title]; });
      }
      // a link may work on the blocked list rather than on a thing in the
      // house; what it works on comes with the press
      if (String(targetValue).indexOf('{') === 0) {
        return [['unban', '\u2705 let that address back in'],
                ['ban', '\u26d4 keep that address out']];
      }
      if (String(targetValue).indexOf('script:') === 0) {
        return [['script', '\ud83d\udcdc run it, line by line']];
      }
      return doOptionsFor(st, targetValue, tap.do || 'toggle');
    };
    // the list and the line that replaces it share one cell of the grid, so
    // the row keeps its shape whichever of the two is showing - as a sibling
    // the line was an extra cell, which shifted every column after it
    var actCell = el('div', 'tap-act');
    actCell.appendChild(act);
    fillSelect(act, actsFor(tap.target || 'tell'), tap.do || '');
    runsItsOwnSteps(act, tap.target || 'tell');
    // the same writing desk an alert has: a symbol picker, a fact picker, the
    // completer on { or Ctrl+Space, and a preview underneath that says what
    // the watch would read out
    var story = el('textarea', 'tap-story');
    story.rows = 4;
    story.placeholder = 'It is {inside_c}\u00b0 inside and {outside_c}\u00b0 out. {people_home_words}.';
    story.value = tap.text || '';
    var tellPreview = function () { scheduleTellPreview(); };
    story.oninput = function () { live().text = story.value; touched(); tellPreview(); };
    attachFactCompleter(story, function (v) { live().text = v; touched(); tellPreview(); },
                        function () { return rowVars(live()).concat(carriedNames(live().text)); });
    var storyTools = el('div', 'msg-tools tap-storytools');
    var tapVars = el('button', 'btn small'); tapVars.type = 'button';
    tapVars.textContent = '{ } Variables';
    tapVars.title = 'Names this link makes up for what the press carries. The name is the header name: '
      + 'one called room arrives in X-Zigmon-Arg-room';
    tapVars.onclick = function (e) {
      e.stopPropagation();
      editRowVars(live(), 'link', function () { touched(); });
    };
    var emo = el('button', 'btn small'); emo.type = 'button'; emo.textContent = '\ud83d\ude00 Emoji';
    emo.title = 'Put a symbol where the cursor is';
    emo.onclick = function (e) {
      e.stopPropagation();
      openEmojiPicker(emo, story, function (v) { live().text = v; touched(); tellPreview(); });
    };
    var facts = el('button', 'btn small'); facts.type = 'button'; facts.textContent = '{ } Facts';
    facts.title = 'Every fact with an example of what it would say right now. In the text itself: '
      + 'type { or press Ctrl+Space';
    facts.onclick = function (e) {
      e.stopPropagation();
      openFactPicker(facts, story, function (v) { live().text = v; touched(); tellPreview(); },
                     function () { return rowVars(live()); });
    };
    storyTools.appendChild(emo);
    storyTools.appendChild(facts);
    storyTools.appendChild(tapVars);
    var storyBox = el('div', 'tap-storybox');
    storyBox.appendChild(story);
    storyBox.appendChild(storyTools);
    var storyPre = el('div', 'msg-preview tap-preview');
    storyPre.dataset.tap = tap.id || String(index);
    storyBox.appendChild(storyPre);
    var showTell = function () {
      var telling = target.value === 'tell';
      // the desk and its two buttons come and go together, as one thing
      var own = telling && act.value === 'own';
      story.hidden = !own;
      storyTools.hidden = !own;
      storyBox.hidden = !telling;                    // the desk belongs to a telling link
      storyPre.hidden = !telling;
      if (telling) tellPreview();
    };

    target.onchange = function () {
      live().target = target.value;
      // the action list follows, and takes the first of the new list rather
      // than keeping one that belonged to the old
      var keep = actsFor(target.value).some(function (o) { return o[0] === act.value; }) ? act.value : '';
      fillSelect(act, actsFor(target.value), keep);
      runsItsOwnSteps(act, target.value);
      live().do = act.value;
      touched();
      tellPreview();
    };
    act.onchange = function () { live().do = act.value; showTell(); touched(); tellPreview(); };
    // the same taking-over a button press does: while this leaves it on, rules
    // and schedules let it be, until it is switched off again
    var byHand = el('div', 'sw-cell tap-hand');
    var handSw = makeSwitch(!!tap.hold, function (on) { live().hold = on; touched(); },
      {small: true, title: 'Takes the target over: while this link leaves it on, rules and schedules '
        + 'let it be. The same link switching it off gives it back.'});
    byHand.appendChild(handSw);
    var used = el('span', 'muted small tap-used', tap.used
      ? ((tap.uses || 0) + '\u00d7, last ' + ago(tap.used)) : 'never');
    // which road it came in by last time: what is still being opened the old
    // way is what has to be changed over before the last switch is thrown
    if (tap.used && tap.way) {
      var mode = ((STATE.status || {}).runtime_config || {}).tap_mode || {};
      var behind = tap.way === 'link' && String(mode.value || 'link') === 'both';
      var wayTag = el('span', 'tap-way' + (behind ? ' behind' : ''),
        tap.way === 'header' ? 'by a header' : 'by its address');
      wayTag.title = behind ? 'This one is still opened the old way \u2014 change its shortcut over before '
        + 'the links are set to a header only' : 'How it was opened last time';
      used.appendChild(el('br'));
      used.appendChild(wayTag);
    }
    var how = iconButton('search', 'How to put this on a watch or a phone, and the address itself');
    how.onclick = function () { showTapSetup(tap); };
    var drop = iconButton('trash', 'Withdraw this link. Anything holding it stops working at once');
    drop.classList.add('danger');
    drop.onclick = function () {
      TAPS.rows.splice(index, 1); TAPS.dirty = true; forgetSig('taps'); renderTaps(st);
    };
    row.appendChild(on);
    row.appendChild(name);
    row.appendChild(target);
    row.appendChild(actCell);
    row.appendChild(byHand);
    row.appendChild(used);
    var both = el('div', 'btnrow tap-tools');
    both.appendChild(how);
    both.appendChild(drop);
    row.appendChild(both);
    row.appendChild(storyBox);          // spans the row, on a line of its own
    showTell();
    makeRowSortable(row, host, TAPS, touched, function () { forgetSig('taps'); renderTaps(STATE.status); }, tap);
    host.appendChild(row);
  });
  if (!(TAPS.rows || []).length) host.appendChild(el('p', 'btnhelp', 'No links yet.'));
  sectionise(host, TAPS, 'taps', function () { TAPS.dirty = true; $('taps-dirty').textContent = 'not saved yet'; },
             function () { forgetSig('taps'); renderTaps(STATE.status); });
  // every redraw makes fresh boxes, and an answer already on its way lands in
  // the old one; asking again here is what the messages card does and why its
  // previews never go stale
  scheduleTellPreview();
  renderTapKeys(st);
  setTimeout(function () { sizeTapTools(); markHeaderIndent(); }, 0);
}

// How the links are opened, said at the top of the card they are listed in.
// The switch itself is in Settings and the phones are at the foot of this
// card, and neither is anywhere the eye falls when it is looking at a list of
// links: the code was there for a release and looked to me as though it had
// never been built.
function tapModeStrip(st) {
  var rc = st.runtime_config || {};
  var mode = String((rc.tap_mode || {}).value || 'link');
  var code = !!(rc.tap_code || {}).value && mode !== 'link';
  var keys = (st.tap_keys || []).length;
  var strip = el('div', 'tapmode' + (mode === 'link' ? '' : ' on'));
  var words = {link: 'Opened by their address', both: 'Opened either way \u2014 address or header',
               header: 'Opened by a header only'}[mode];
  strip.appendChild(el('span', 'tapmode-what', words));
  var factor = String((rc.tap_factor || {}).value || 'totp');
  var second = factor === 'duo'
    ? ('and Duo approves it' + (st.duo_ready ? '' : ' \u2014 not set up yet'))
    : ('and a code from ' + (keys === 1 ? 'one phone' : keys + ' phones'));
  strip.appendChild(el('span', 'tapmode-code' + (code ? ' on' : ''),
    code ? second
         : (mode === 'link' ? 'the secret travels in the address'
            : 'no second factor asked for')));
  var where = el('button', 'btn small'); where.type = 'button';
  where.textContent = 'Change this';
  where.title = 'Settings \u2192 One-tap links: which way a link may be opened, and whether a code is '
    + 'wanted with it';
  where.onclick = function () {
    showControlSection('system');
    setTimeout(function () {
      var card = $('settings-card') || document.querySelector('[data-sec="system"] #settings-grid');
      if (card && card.scrollIntoView) card.scrollIntoView({block: 'start'});
    }, 60);
  };
  strip.appendChild(where);
  return strip;
}

// ---- the phones that carry the code -----------------------------------------------
// One secret to a phone, not to a link: ten links would otherwise be ten
// entries in the authenticator and ten things to redo when a phone is lost.
// Any known phone's code opens any link that asks for one; taking a phone
// away leaves every link exactly as it was.
var TAPKEYS = {rows: null, dirty: false};
function markTapKeys() { TAPKEYS.dirty = true; $('tapkeys-note').textContent = 'not saved yet'; }
function renderTapKeys(st) {
  var host = $('tapkeys'); if (!host) return;
  if (editorBusy('tapkeys')) return;
  if (!TAPKEYS.dirty) TAPKEYS.rows = JSON.parse(JSON.stringify(st.tap_keys || []));
  var rc = st.runtime_config || {};
  var mode = String((rc.tap_mode || {}).value || 'link');
  var wants = !!(rc.tap_code || {}).value && mode !== 'link';
  var factor = String((rc.tap_factor || {}).value || 'totp');
  if (factor === 'duo') { renderTapDuo(st, host, wants); return; }
  host.innerHTML = '';
  host.appendChild(el('div', 'set-head', 'Phones that carry the code'));
  host.appendChild(el('p', 'note', wants
    ? 'A link opened by a header must also carry six digits from one of these. A secret read out of '
      + 'a log a week later is then worth nothing \u2014 the code it would need has long gone.'
    : 'Not asked for at the moment. Set one up here, then Settings \u2192 One-tap links \u2192 '
      + '\u201cand a six-digit code\u201d \u2014 which is refused while there is no phone to show one.'));
  (TAPKEYS.rows || []).forEach(function (key, i) {
    var row = el('div', 'tapkey-row');
    var name = el('input'); name.value = key.name || ''; name.placeholder = 'Falco\u2019s iPhone';
    name.oninput = function () { key.name = name.value; markTapKeys(); };
    row.appendChild(name);
    row.appendChild(el('span', 'muted small', key.used ? 'last used ' + ago(key.used)
      : (key.made ? 'never used' : 'not saved yet')));
    var tools = el('span', 'btnrow');
    if (key.id && key.made) {
      var show = iconButton('search', 'Show the secret and its QR code, to put it in the phone\u2019s authenticator');
      show.onclick = function () { showTapKey(key); };
      tools.appendChild(show);
    }
    var drop = iconButton('trash', 'Take this phone away. Its codes stop working at once; every link stays as it is');
    drop.classList.add('danger');
    drop.onclick = function () { TAPKEYS.rows.splice(i, 1); markTapKeys(); renderTapKeys(STATE.status); };
    tools.appendChild(drop);
    row.appendChild(tools);
    host.appendChild(row);
  });
  if (!(TAPKEYS.rows || []).length) host.appendChild(el('p', 'btnhelp', 'No phone set up yet.'));
  var bar = el('div', 'btnrow'); bar.style.marginTop = '10px';
  var add = cmdButton('Add a phone', 'add', 'small');
  add.onclick = function () {
    TAPKEYS.rows = (TAPKEYS.rows || []).concat([{name: ''}]);
    markTapKeys(); renderTapKeys(STATE.status);
  };
  var save = cmdButton('Save phones', 'save', 'small primary');
  save.onclick = function () {
    withPin('Save the phones', 'A phone added here is given a secret of its own; the QR code to put it in '
      + 'the authenticator is behind the magnifier beside it.', function (pin) {
        return post('taps-keys', {pin: pin, keys: TAPKEYS.rows || []}).then(function (r) {
          if (!r.ok) throw new Error(r.error || 'could not save');
          TAPKEYS.dirty = false; forgetSig('taps'); tick(true);
          return (r.keys || []).length + ' phone(s) saved';
        });
      });
  };
  bar.appendChild(add); bar.appendChild(save);
  bar.appendChild(el('span', 'muted small', TAPKEYS.dirty ? 'not saved yet' : ''));
  bar.lastChild.id = 'tapkeys-note';
  host.appendChild(bar);
}
// Duo does the asking, so there is nothing here to keep: no secret, no list
// of phones. What the card shows is whether the daemon can reach Duo at all,
// and a way to find out without waiting for a garage door to not open.
function renderTapDuo(st, host, wants) {
  var rc = st.runtime_config || {};
  host.innerHTML = '';
  host.appendChild(el('div', 'set-head', 'Approved through Duo'));
  var ready = !!st.duo_ready;
  host.appendChild(el('p', 'note', ready
    ? 'A press goes to Duo, which asks ' + esc(String((rc.duo_user || {}).value || 'your account'))
      + ' to approve it. Duo has a watch app of its own, so a press made on the wrist is approved '
      + 'there too \u2014 nothing has to be typed and nothing has to be fetched from another app.'
    : 'Duo is chosen but not set up. Put the API hostname, the integration key, the secret key and '
      + 'the username into Settings \u2192 One-tap links. Until then, asking for a second factor is '
      + 'refused rather than shutting the links.'));
  // Which device the push goes to. Duo's own "auto" picks one of its own
  // choosing, which on an account with three of them is as likely to be the
  // iPad on a shelf as the phone in your pocket.
  var known = st.duo_devices || [];
  if (ready) {
    var pick = el('div', 'notify-sys');
    pick.appendChild(el('span', 'muted small', 'Push it to'));
    var sel = el('select');
    var options = [['auto', 'whichever Duo picks']].concat(known.map(function (dv) {
      return [dv.device, dv.name + ((dv.capabilities || []).indexOf('push') < 0
        ? ' \u2014 cannot take a push' : '')];
    }));
    var now = String((rc.duo_device || {}).value || 'auto');
    if (!options.some(function (o) { return o[0] === now; })) options.push([now, now + ' (as it stands)']);
    fillSelect(sel, options, now);
    sel.onchange = function () {
      var chosen = sel.value;
      withPin('Push to ' + (sel.options[sel.selectedIndex].textContent || chosen),
        'Which of the account\u2019s devices a press is sent to.', function (pin) {
          return post('config-save', {pin: pin, duo_device: chosen}).then(function (r) {
            if (!r.ok) throw new Error(r.error || 'could not save');
            forgetSig('taps'); tick(true);
            return 'a press now goes to ' + (chosen === 'auto' ? 'whichever device Duo picks' : chosen);
          });
        });
    };
    pick.appendChild(sel);
    pick.appendChild(el('span', 'muted small notify-sys-says', known.length
      ? '' : 'press Test Duo to fetch the list'));
    host.appendChild(pick);
  }
  var bar = el('div', 'btnrow'); bar.style.marginTop = '10px';
  var test = cmdButton('Test Duo', 'search', 'small');
  test.title = 'Ask Duo whether the keys are right and the user is enrolled. Nothing is pushed';
  test.onclick = function () {
    withPin('Test Duo', 'The keys are checked and the user looked up. No push is sent.', function (pin) {
      return post('taps-duo-test', {pin: pin}).then(function (r) {
        forgetSig('taps'); tick(true);          // the list of devices it just fetched
        if (!r.ok) throw new Error(r.error || 'Duo did not answer');
        return r.message;
      });
    });
  };
  bar.appendChild(test);
  bar.appendChild(el('span', 'muted small', ready
    ? (wants ? 'in use' : 'set up, but no link asks for it yet')
    : 'not set up yet'));
  host.appendChild(bar);
  host.appendChild(el('p', 'btnhelp', 'The phones that carry a six-digit code are kept as they are; '
    + 'switch the factor back to a code and they are all still there. '
    + 'If the machine has Duo\u2019s own package \u2014 <code>pip install duo-client</code> \u2014 '
    + 'the daemon talks to Duo through it; without it, it signs the requests itself.'));
}
function showTapKey(key) {
  if (TAPKEYS.dirty) { toast('Save the phones first', false); return; }
  withPin('The code secret for \u201c' + (key.name || 'this phone') + '\u201d',
    'Whoever reads it can make the codes this phone makes. It is shown behind the PIN and the '
    + 'showing is written down, like any other secret here.',
    function (pin) {
      return post('taps-keys', {pin: pin, show: key.id}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        paintTapKey(r);
        return 'shown';
      });
    });
}
function paintTapKey(r) {
  var items = [];
  // every value that can be carried away looks the same wherever it is: one
  // chip, click to copy, hover for a code. A value dressed differently from
  // the rest reads as a different kind of thing, and it is not one.
  function copyable(text) {
    // the whole value in the tooltip as well, since a long one is drawn cut
    return '<code class="copyme" data-copy="' + esc(text) + '" title="' + esc(text)
      + ' \u2014 click to copy \u00b7 hover for a QR code">' + esc(text) + '</code>';
  }
  items.push({section: 'Put it in the phone'});
  items.push({level: 'ok', tag: 'qr', who: 'Scan this in 2FAS, OTP Auth or Raivo', rich: true,
    why: 'Hover it for the QR code and scan that <b>in the authenticator app</b>, not with the camera '
      + '\u2014 the camera would only show you the text of it.<br>' + copyable(r.uri)});
  items.push({level: 'dim', tag: 'key', who: 'Or type the secret by hand', rich: true,
    why: copyable(r.secret) + '<br>Six digits, thirty seconds, SHA-1 \u2014 the ordinary kind, so any '
      + 'authenticator will take it.'});
  items.push({section: 'In the shortcut'});
  items.push({level: 'dim', tag: 'use', who: 'One action before the request', rich: true,
    why: 'The authenticator app has a Shortcuts action that hands back the current code. Put it first, '
      + 'and give what it returns to the ' + copyable('X-Zigmon-Code') + ' header of '
      + '<i>Get Contents of URL</i>.'});
  items.push({level: 'warn', tag: 'twice', who: 'A code may be pressed twice', rich: true,
    why: 'The same code is taken for as long as its own thirty seconds are open, and refused for ever '
      + 'after. So a second press in a doorway works, and a code read out of a log a week later does not.'});
  showDetail('Code secret \u2014 ' + (r.name || ''), items, null, true);
  Array.prototype.forEach.call($('attnbody').querySelectorAll('.copyme'), function (c) {
    c.onmouseenter = function () { showQr(c); };
    c.onmouseleave = hideQr;
    c.onclick = function () { copyText(c.dataset.copy); };
  });
  // A secret that has been seen by the wrong person is replaced, not the phone
  // removed: the same phone, under the same name, opening the same links, and
  // every code the old secret would show refused from the moment this is done.
  var again = cmdButton('Make a new secret', 'reset', 'small danger');
  again.classList.remove('needs-unlock');
  again.title = 'Throw this secret away and make another. The authenticator has to be given the new one, '
    + 'and until it is, this phone opens nothing';
  again.style.marginTop = '12px';
  again.onclick = function () {
    withPin('New code secret for \u201c' + (r.name || 'this phone') + '\u201d',
      'The codes this phone shows now stop working at once. Scan the new secret into the authenticator '
      + '\u2014 it replaces the entry that is there.',
      function (pin) {
        return post('taps-keys', {pin: pin, roll: r.id}).then(function (rr) {
          if (!rr.ok) throw new Error(rr.error || 'could not make one');
          paintTapKey(rr);
          forgetSig('taps'); tick(true);
          return 'a new secret is ready';
        });
      }, true);
  };
  $('attnbody').appendChild(again);
}
setButtonIcon($('approvals-stop-all'), 'cancel');
setButtonIcon($('approvals-forget-btn'), 'trash');
$('approvals-stop-all').onclick = function () { stopApproval(null, 'every link'); };
// This lost its handler when the router's buttons were moved off the blocked
// card: the button was still drawn, still wore the lock, still had its icon,
// and did nothing at all when pressed.
$('approvals-forget-btn').onclick = function () {
  withPin('Erase the press log',
    'Every press of a one-tap link and what came of it, under Public API, is thrown away. Anything '
    + 'still waiting to be approved is left alone \u2014 it has not become anything yet.',
    function (pin) {
      return post('approvals-stop', {pin: pin, forget: true}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        PRESSES.page = 1;
        loadApprovals(true);
        return r.message;
      });
    }, true);
};
setButtonIcon($('blocked-add'), 'cancel');
setButtonIcon($('blocked-add-forever'), 'cancel');
setButtonIcon($('blocked-clear'), 'trash');
setButtonIcon($('blocked-forget'), 'trash');
setButtonIcon($('blocked-forget-counters'), 'forget');
$('blocked-forget-counters').onclick = function () {
  blockedChange({clear: '*', all: true}, 'Forget what every address has been doing',
    'Every score goes back to nothing. Nobody is let off the list by this \u2014 it is what they have '
    + 'done since that is forgotten.');
};
// What belongs to the router lives with the router: trying it, bringing it in
// step, and the lines to paste by hand when it is not this daemon pasting
// them. The page where addresses are kept out keeps only the keeping out.
function mikrotikPanel() {
  var box = el('div', 'subpanel');
  box.style.gridColumn = '1/-1';
  var doing = el('div', 'btnrow');
  var test = cmdButton('Try the router', 'search', 'small');
  var sync = cmdButton('Sync it now', 'refresh', 'small primary');
  var copy = cmdButton('Copy the lines', 'save', 'small');
  copy.classList.remove('needs-unlock');
  test.title = 'Read the one address list and change nothing';
  sync.title = 'Put what this holds into that list, and take off what it no longer holds';
  copy.title = 'The same addresses as lines a Mikrotik takes, for pasting by hand';
  test.onclick = function () { mikrotikKey('test', 'Try the router',
    'It reads the one address list and changes nothing.'); };
  sync.onclick = function () { mikrotikKey('sync', 'Sync the router now',
    'Addresses this holds are added to that one list, and ones it no longer holds are taken off it. '
    + 'Entries somebody put there by hand are left exactly as they are.'); };
  copy.onclick = function () {
    api('blocked&format=mikrotik').then(function (r) {
      if (!(r.lines || []).length) { toast('nobody is blocked', false); return; }
      copyToClipboard(r.lines.join('\n'), r.lines.length + ' line(s) for the firewall');
    }, function (e) { toast(e.message || String(e), false); });
  };
  [test, sync, copy].forEach(function (b) { doing.appendChild(b); });
  box.appendChild(doing);
  return box;
}
function mikrotikKeyPanel() {
  var box = el('div', 'subpanel');
  box.style.gridColumn = '1/-1';
  box.appendChild(el('p', 'note', 'The key is made here and never leaves except when you download it. '
    + 'Put the public half on the router \u2014 /user ssh-keys import public-key-file=zigmon.pub user=\u2026 '
    + '\u2014 and it can log in without a password. Keep the private half safe: anybody holding it can '
    + 'log in to the router. It goes into a settings export only when you ask for one with the secrets '
    + 'in it.'));
  var pub = el('div', 'muted small'); pub.id = 'mikrotik-public'; pub.style.margin = '6px 0';
  box.appendChild(pub);
  var bar = el('div', 'btnrow');
  var make = cmdButton('Make a key', 'key', 'small');
  var mine = cmdButton('Use my own', 'upload', 'small');
  var down = cmdButton('Download it', 'download', 'small');
  var drop = cmdButton('Forget it', 'trash', 'small danger');
  make.onclick = function () { mikrotikKey('generate', 'Make a key',
    'A new key is made here. The old one stops working the moment the router is given the new one.'); };
  // the same two as the access points have: a file chosen from the machine,
  // and the private half saved as a file - not a box to paste into and a
  // clipboard, which is a different thing wearing the same words
  mine.onclick = function () {
    var box = document.createElement('input');
    box.type = 'file';
    box.onchange = function () {
      var f = box.files && box.files[0];
      if (!f) return;
      var reader = new FileReader();
      reader.onload = function () {
        mikrotikKey('upload', 'Use this key', 'It replaces whatever key is held now.',
                    {key: String(reader.result)});
      };
      reader.readAsText(f);
    };
    box.click();
  };
  down.onclick = function () {
    if (!isUnlocked() || !LOCK.token) { unlockFlow(function () { down.onclick(); }); return; }
    var a = document.createElement('a');
    a.href = 'index.php?api=mikrotik-key-download&session=' + encodeURIComponent(LOCK.token);
    a.download = 'zigmon-mikrotik-key';
    document.body.appendChild(a); a.click(); a.remove();
  };
  drop.onclick = function () { mikrotikKey('forget', 'Forget the router\u2019s key',
    'The daemon will have no key for the router; a password can still be used.', null, true); };
  [make, mine, down, drop].forEach(function (b) { bar.appendChild(b); });
  box.appendChild(bar);
  api('mikrotik').then(function (r) {
    // what this machine can do, said here rather than found out by pressing:
    // ssh-keygen is not on every minimal install, and without it the two
    // buttons that make a key can only fail
    if (!r.can_keygen) {
      make.disabled = true; mine.disabled = true;
      box.insertBefore(el('p', 'note reason', 'ssh-keygen is not installed on this machine, so a key '
        + 'cannot be made or read here: dnf install openssh-clients. Until then the router has to be '
        + 'logged in to with a password.'), box.firstChild);
    } else if (!r.can_ssh) {
      box.insertBefore(el('p', 'note reason', 'the ssh client is not installed on this machine, so the '
        + 'router cannot be reached at all: dnf install openssh-clients.'), box.firstChild);
    }
    down.disabled = !r.has_key;
    drop.disabled = !r.has_key;
    pub.textContent = r.has_key ? '' : 'No key yet \u2014 make one, or let it log in with a password.';
    if (r.public) {
      pub.innerHTML = 'The public half: <code class="copyme" data-copy="' + esc(r.public)
        + '" title="Click to copy">' + esc(r.public) + '</code>';
      pub.querySelector('.copyme').onclick = function () { copyText(r.public); };
    }
  }, function () { pub.textContent = ''; });
  return box;
}
function mikrotikKey(what, title, why, extra, danger) {
  withPin(title, why, function (pin) {
    return post('mikrotik', Object.assign({pin: pin, do: what}, extra || {})).then(function (r) {
      if (!r.ok) throw new Error(r.error || 'could not');
      forgetSig('settings'); tick(true);
      return r.message || 'done';
    });
  }, !!danger);
}
$('blocked-forget').onclick = function () {
  blockedChange({forget: true}, 'Erase the history of blocked addresses',
    'Every address that was ever kept out is forgotten. What is blocked right now is left alone.');
};
$('blocked-add').onclick = function () {
  blockedChange({ip: $('blocked-ip').value.trim()}, 'Block ' + $('blocked-ip').value.trim(),
    'For as long as Settings says a block lasts. The API answers it with a refusal and nothing else.');
};
$('blocked-add-forever').onclick = function () {
  blockedChange({ip: $('blocked-ip').value.trim(), forever: true},
    'Block ' + $('blocked-ip').value.trim() + ' for good',
    'Until somebody takes it off this list by hand.');
};
$('blocked-clear').onclick = function () {
  blockedChange({remove: '*', all: true}, 'Take every address off the list',
    'Everything blocked, by hand or by itself, is let back in.');
};
$('tap-add').onclick = function () {
  // a pair that makes sense from the start: asked to tell, and the first
  // report it can tell. Nobody has to click away and back to mend it.
  var firstReport = ((STATE.status && STATE.status.tells) || [{key: 'house'}])[0].key;
  TAPS.rows = (TAPS.rows || []).concat([{name: '', target: 'tell', do: firstReport}]);
  TAPS.dirty = true; forgetSig('taps'); renderTaps(STATE.status);
};
$('taps-save').onclick = function () {
  withPin('Save the one-tap links',
    'A new link is given a secret of its own. The address to put on a watch is under '
    + 'Control \u2192 System, or from a terminal: zigmon --taps --secret', function (pin) {
      return post('taps-save', {taps: TAPS.rows || [], groups: TAPS.groups || [], pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not save');
        TAPS.dirty = false; forgetSig('taps'); tick(true);
        return 'saved. The addresses are under zigmon --taps --secret';
      });
    });
};

function renderScenes(st) {
  if (SCENES.dirty) return;                       // unsaved edits anywhere in the table: leave it alone
  if (SCENES.rows === null) {
    api('scenes').then(function (r) {
      if (SCENES.dirty) return;                    // became dirty while this request was in flight
      SCENES.rows = (r.scenes || []).map(function (x) { return JSON.parse(JSON.stringify(x)); });
      paintScenes(st);
    }, function () {});
    return;
  }
  paintScenes(st);
}
function paintScenes(st) {
  if (editorBusy('scenes-list')) return;
  var host = $('scenes-list'); host.innerHTML = '';
  var rows = SCENES.rows || [];
  if (!rows.length) host.appendChild(el('div', 'muted small', 'No scene yet.'));
  var options = sceneTargetOptions(st);
  rows.forEach(function (scene, i) {
    var row = el('div', 'scene-row');
    var name = el('input'); name.value = scene.name || ''; name.placeholder = 'Vecer';
    name.oninput = function () { scene.name = name.value; markScenes(); };
    var acts = el('div', 'scene-actions');
    (scene.actions = scene.actions || []).forEach(function (a, j) {
      var line = el('span', 'act');
      var target = el('select');
      var opts = options.slice();
      if (a.target && !opts.some(function (o) { return o[0] === a.target; })) opts.push([a.target, a.target + ' (gone)']);
      a.target = fillSelect(target, opts, a.target);
      attachTargetReadings(target, function () { return a.target; });
      target.onchange = function () {
        a.target = target.value;
        if (settableTarget(st, a.target) && String(a.do).indexOf('set:') !== 0) a.do = 'set:';
        if (!settableTarget(st, a.target) && String(a.do).indexOf('set:') === 0) a.do = 'on';
        refillDoA(); syncSceneDo(); markScenes();
      };
      var doSel = el('select');
      var setBoxA = setValueBox(st, null, function (v) { a.do = v; markScenes(); });
      function refillDoA() {
        var keep = a.do || 'on';
        fillSelect(doSel, doOptionsFor(st, a.target, keep), String(keep).indexOf('set:') === 0 ? 'set:' : keep);
        runsItsOwnSteps(doSel, a.target);
        attachTargetReadings(doSel, function () { return a.target; });
        a.do = String(keep).indexOf('set:') === 0 ? keep : (doSel.value || 'on');
        setBoxA.refresh(a.target, a.do);
      }
      refillDoA();
      var ms = el('input'); ms.type = 'number'; ms.style.width = '84px'; ms.step = 100; ms.value = a.pulse_ms || 5000; ms.hidden = a.do !== 'pulse'; ms.title = 'pulse hold, ms';
      ms.oninput = function () { a.pulse_ms = parseInt(ms.value, 10) || 5000; markScenes(); };
      var tellNote = el('span', 'muted small', 'sends it');
      tellNote.title = 'Nothing is switched \u2014 what it says is set under Alerts & energy \u2192 Messages';
      function syncSceneDo() {
        var tells = isNotifyTarget(a.target);
        doSel.hidden = tells; tellNote.hidden = !tells;
        ms.hidden = tells || a.do !== 'pulse';
        if (tells) a.do = 'on';
      }
      doSel.onchange = function () { a.do = doSel.value; setBoxA.refresh(a.target, a.do); syncSceneDo(); markScenes(); };
      syncSceneDo();
      var after = el('span', 'act-after');
      after.appendChild(el('span', 'muted', 'after'));
      var afterIn = el('input'); afterIn.type = 'number'; afterIn.min = 0; afterIn.max = 3600; afterIn.step = 'any'; afterIn.style.width = '70px';
      afterIn.value = a.after_s || 0; afterIn.title = 'Seconds from the scene start before this step runs; 0 = at once. Steps fire independently — 0, 2, 5 makes a small cascade.';
      afterIn.oninput = function () { var v = parseFloat(afterIn.value); a.after_s = isFinite(v) && v > 0 ? v : 0; markScenes(); };
      after.appendChild(afterIn); after.appendChild(el('span', 'muted', 's'));
      var drop = cmdButton('', 'trash', 'small iconbtn danger'); drop.classList.remove('needs-unlock'); drop.title = 'Remove this action';
      drop.onclick = function () { scene.actions.splice(j, 1); markScenes(); paintScenes(STATE.status); };
      [target, doSel, setBoxA, tellNote, ms, after, drop].forEach(function (x) { line.appendChild(x); });
      acts.appendChild(line);
    });
    var addAct = cmdButton('Add action', 'add', 'small'); addAct.classList.remove('needs-unlock');
    addAct.title = 'One more thing this scene does \u2014 a target, what to do, and how long after the start';
    addAct.onclick = function () { scene.actions.push({target: options.length ? options[0][0] : '', do: 'on'}); markScenes(); paintScenes(STATE.status); };
    acts.appendChild(addAct);
    var side = el('span', 'scene-side');
    var run = cmdButton('', 'play', 'small iconbtn'); run.title = 'Run this scene now';
    run.onclick = function () {
      withPin('Run scene ' + (scene.name || '?'), 'Every action in it fires now.', function (pin) {
        return post('scene-run', {id: scene.id, pin: pin}).then(function (r) { return r.message; });
      });
    };
    run.disabled = !scene.id || SCENES.dirty;
    if (SCENES.dirty) run.title = 'Save first';
    var del = cmdButton('', 'trash', 'small iconbtn danger'); del.classList.remove('needs-unlock'); del.title = 'Remove this scene';
    del.onclick = function () { SCENES.rows.splice(i, 1); markScenes(); paintScenes(STATE.status); };
    side.appendChild(run); side.appendChild(del);
    row.appendChild(name); row.appendChild(acts); row.appendChild(side);
    makeRowSortable(row, host, SCENES, markScenes, function () { paintScenes(STATE.status); }, scene);
    host.appendChild(row);
  });
  sectionise(host, SCENES, 'scenes', markScenes, function () { paintScenes(STATE.status); });
  if (!SCENES.dirty) $('scene-note').textContent = '';
}
$('scene-add').onclick = function () {
  SCENES.rows = SCENES.rows || [];
  SCENES.rows.push({name: '', actions: [{target: (sceneTargetOptions(STATE.status)[0] || [''])[0], do: 'on'}]});
  markScenes(); paintScenes(STATE.status);
};
$('scene-save').onclick = function () {
  withPin('Save scenes', 'They become available as \ud83c\udfac targets for buttons and rules at once.', function (pin) {
    return post('scenes-save', {scenes: rowsToSave(SCENES, 'scenes'), pin: pin}).then(function (r) {
      saveGroups('scenes', SCENES);
      SCENES.dirty = false; SCENES.rows = null; forgetSig('scenes');
      return (r.scenes || []).length + ' scene(s) saved';
    });
  });
};

// ---- notifications ------------------------------------------------------------------
var NOTIFY = { dirty: false };
function renderNotify(st) {
  if (editorBusy('notify-card')) return;
  var info = st.notify || {channels: [], settings: {}};
  $('notify-note').innerHTML = info.channels.length
    ? 'Sending through <b>' + info.channels.join('</b> and <b>') + '</b> (set in <code>config.json</code>: <code>notify_ntfy</code>, or <code>notify_telegram_token</code> + <code>notify_telegram_chat</code>). The same story repeats at most once per 15 minutes.'
    : 'No channel configured. Put <code>notify_ntfy</code> (a topic URL like <code>https://ntfy.sh/moje-tajne-slovo</code> — install the ntfy app and subscribe to the same topic) or <code>notify_telegram_token</code> + <code>notify_telegram_chat</code> into <code>config.json</code> and restart the daemon.';
  if (NOTIFY.dirty) return;
  // Which roads an automatic alert takes. A written message has its own three
  // switches; these are for the ones the daemon writes itself - a battery
  // running down, a device gone quiet, a rule firing.
  var roads = $('notify-roads'); roads.innerHTML = '';
  var chosen = ((info.settings || {}).channels) || {};
  [['ntfy', ICON.bell + ' ntfy'], ['telegram', '\u2708\ufe0f Telegram'], ['sms', '\ud83d\udcf1 SMS']]
    .forEach(function (pair) {
      var label = el('div', 'notify-opt');
      var row = switchRow(pair[1], chosen[pair[0]] !== false && (pair[0] !== 'sms' || chosen.sms === true),
                          function () { NOTIFY.dirty = true; });
      row.input.dataset.road = pair[0];
      row.title = pair[0] === 'sms'
        ? 'A text costs money and wakes a phone at night, so this one is off unless you ask for it'
        : 'Automatic alerts go this way';
      label.appendChild(row);
      roads.appendChild(label);
    });
  var host = $('notify-opts'); host.innerHTML = '';
  ['crit', 'warn', 'offline', 'rule', 'switch'].forEach(function (k) {
    var pair = [k, withIcon(k, NOTIFY_CATEGORY_LABELS[k])];
    var label = el('div', 'notify-opt');
    var row = switchRow(pair[1], !!(info.settings || {})[pair[0]], function () { NOTIFY.dirty = true; });
    row.input.dataset.k = pair[0];
    if (NOTIFY_CATEGORY_HELP[pair[0]]) label.title = NOTIFY_CATEGORY_HELP[pair[0]];
    label.appendChild(row);
    host.appendChild(label);
  });
  // per-device overrides
  // the things that are not about one device: the same choice, per kind
  var perKind = $('notify-systems'); perKind.innerHTML = '';
  var kinds = info.systems || [];
  var kindSaved = (info.settings || {}).systems || {};
  // A road apiece rather than a list of the combinations somebody thought of.
  // Three roads make eight ways of choosing and the list offered seven of
  // them: ntfy and a text but not Telegram could not be said at all, nor
  // Telegram and a text but not ntfy. One switch per road says all eight, and
  // the eighth - none of them - is the old "say nothing", which needs no
  // entry of its own because it is what no switch on means.
  var ROADS = [['ntfy', ICON.bell + ' ntfy'], ['telegram', '\u2708\ufe0f Telegram'], ['sms', '\ud83d\udcf1 SMS']];
  var houseRoads = ((info.settings || {}).channels) || {};
  var houseWords = ROADS.filter(function (r) {
    return r[0] === 'sms' ? houseRoads.sms === true : houseRoads[r[0]] !== false;
  }).map(function (r) { return r[1]; }).join(' + ') || 'nothing';
  kinds.forEach(function (k) {
    var mine = kindSaved[k.key] || {};
    var own = !!(mine.off || mine.roads);
    var picked = String(mine.roads || '').split(',').filter(Boolean);
    var box = el('div', 'notify-dev');
    var head = el('div', 'notify-devhead');
    head.appendChild(el('span', 'notify-devname', k.title));
    if (k.what) head.appendChild(el('span', 'muted small', k.what));
    box.appendChild(head);
    var row = el('div', 'notify-sys');
    row.dataset.system = k.key;
    var says = el('span', 'muted small notify-sys-says');
    var switches = [];
    var retell = function () {
      row.classList.toggle('overridden', own);
      switches.forEach(function (sw) {
        sw.row.classList.toggle('dim', !own);
        sw.row.input.disabled = !own;
      });
      var on = switches.filter(function (sw) { return sw.row.input.checked; });
      says.textContent = own
        ? (on.length ? '' : '\u26d4 nothing \u2014 written down only')
        : 'follows the house: ' + houseWords;
    };
    var ownRow = switchRow('its own roads', own, function () {
      own = !own; NOTIFY.dirty = true; retell();
    });
    ownRow.title = 'Off: this kind goes wherever the house sends everything else. '
      + 'On: it takes the roads picked here, and none of them means it is only written down.';
    row.appendChild(ownRow);
    ROADS.forEach(function (pair) {
      var sw = switchRow(pair[1], own ? picked.indexOf(pair[0]) >= 0 : (pair[0] === 'sms' ? houseRoads.sms === true : houseRoads[pair[0]] !== false),
                         function () { NOTIFY.dirty = true; retell(); });
      sw.input.dataset.road = pair[0];
      switches.push({row: sw});
      row.appendChild(sw);
    });
    row.appendChild(says);
    retell();
    box.appendChild(row);
    perKind.appendChild(box);
  });
  var perHost = $('notify-devices'); perHost.innerHTML = '';
  var bar = el('div', 'btnrow'); bar.style.margin = '0 0 8px';
  var anyOpen = Object.keys(NOTIFY_OPEN).some(function (k) { return NOTIFY_OPEN[k]; });
  var all = cmdButton(anyOpen ? 'Fold every device' : 'Open every device', anyOpen ? 'up' : 'down', 'small');
  all.classList.remove('needs-unlock');
  all.title = 'Show or hide every device\u2019s own notification choices';
  all.onclick = function () { (st.devices || []).concat(st.plugs || []).forEach(function (d) { NOTIFY_OPEN[d.name] = !anyOpen; }); renderNotify(st); };
  bar.appendChild(all); perHost.appendChild(bar);
  var overrides = (info.settings || {}).devices || {};
  var options = [['', withIcon('follow', 'follow the choices above')],
    ['mute', withIcon('mute', 'nothing \u2014 mute it')],
    ['crit', withIcon('crit', 'critical only')],
    ['crit_offline', ICON.crit + ICON.offline + ' critical + going offline'],
    ['crit_offline_switch', ICON.crit + ICON.offline + ICON.switch + ' critical + offline + switching'],
    ['all', withIcon('everything', 'everything about it')],
    ['custom', withIcon('custom', 'custom\u2026')]];
  var everything = devicesSorted(st.devices || []).map(function (d) { return {id: d.id, name: d.name, kind: d.source === 'plug' ? 'plug' : (d.kind || '')}; });
  everything.forEach(function (dev) {
    var row = el('div', 'notify-dev');
    var nm = el('span', '', dev.name);
    nm.title = dev.id;
    // (select labels are kept short; "everything" = warnings, offline, rules and switching too)
    var saved = overrides[dev.id] || '';
    var savedRoads = saved.indexOf('@') > 0 ? saved.split('@')[1] : '';   // the roads it takes, if it says
    saved = saved.split('@')[0];
    var isCustom = saved.indexOf('custom:') === 0;
    var sel = el('select');
    fillSelect(sel, options, isCustom ? 'custom' : saved);
    sel.dataset.device = dev.id;
    var custom = el('span', 'notify-custom');
    custom.hidden = !isCustom;
    var savedCats = isCustom ? saved.slice(7).split(',') : [];
    [['crit', withIcon('crit', 'crit')], ['warn', withIcon('warn', 'warn')], ['offline', withIcon('offline', 'offline')], ['rule', withIcon('rule', 'rules')], ['switch', withIcon('switch', 'switching')]].forEach(function (c) {
      var lab = switchRow(c[1], savedCats.indexOf(c[0]) >= 0, function () { NOTIFY.dirty = true; }, {small: true});
      lab.input.dataset.cat = c[0];
      custom.appendChild(lab);
    });
    // and which roads this one's alerts take, whatever the house does
    var roadSel = el('select');
    roadSel.dataset.roads = dev.id;
    fillSelect(roadSel, [['', 'by whatever the house uses'],
                         ['ntfy,telegram', ICON.bell + ' push only \u2014 no text'],
                         ['ntfy,telegram,sms', '\ud83d\udcf1 push and a text'],
                         ['sms', '\ud83d\udcf1 a text only'],
                         ['ntfy', ICON.bell + ' ntfy only'],
                         ['telegram', '\u2708\ufe0f Telegram only']], savedRoads);
    roadSel.title = 'Which way this one\u2019s alerts travel. Left alone, it follows the choice above.';
    roadSel.onchange = function () { NOTIFY.dirty = true; };
    roadSel.hidden = !saved;
    row.dataset.custom = '1';
    sel.onchange = function () { NOTIFY.dirty = true; custom.hidden = sel.value !== 'custom'; roadSel.hidden = !sel.value; row.classList.toggle('overridden', !!sel.value); };
    row.classList.toggle('overridden', !!sel.value);
    row.appendChild(sel); row.appendChild(roadSel); row.appendChild(custom);
    var summary = saved ? (isCustom ? 'its own choice' : (sel.options[sel.selectedIndex] || {}).text || '') : '';
    if (saved) NOTIFY_OPEN[dev.name] = NOTIFY_OPEN[dev.name] !== false;   // a device that differs starts open
    perHost.appendChild(notifyDeviceBlock(dev.name, row, summary));
  });
}
$('binding-remember').onclick = function () {
  withPin('Remember how these are configured',
    'The shape of each model is written down as it is now, so a replacement can be compared with it when '
    + 'none of its fellows are left. It is refused where a model\u2019s devices disagree, or where none of them '
    + 'has anything configured \u2014 that being the very fault this looks for.',
    function (pin) {
      return post('zigbee-baseline', {pin: pin}).then(function (r) {
        if (!r.ok) throw new Error(r.error || 'could not');
        BINDINGS.at = 0;
        loadBindings(true);
        return r.message;
      });
    });
};
$('notify-save').onclick = function () {
  var body = {devices: {}, systems: {}};
  Array.prototype.forEach.call($('notify-systems').querySelectorAll('.notify-sys'), function (row) {
    var own = row.querySelector('.swrow input');       // the first switch is "its own roads"
    if (!own || !own.checked) return;                  // left alone: it follows the house
    var roads = Array.prototype.filter.call(row.querySelectorAll('input[data-road]'), function (b) { return b.checked; })
      .map(function (b) { return b.dataset.road; });
    body.systems[row.dataset.system] = roads.length ? {roads: roads.join(',')} : {off: true};
  });
  Array.prototype.forEach.call($('notify-opts').querySelectorAll('input'), function (b) { body[b.dataset.k] = b.checked; });
  body.channels = {};
  Array.prototype.forEach.call($('notify-roads').querySelectorAll('input'), function (b) {
    body.channels[b.dataset.road] = b.checked;
  });
  Array.prototype.forEach.call($('notify-devices').querySelectorAll('select[data-device]'), function (sel) {
    if (!sel.value) return;
    var roadPick = sel.parentNode.querySelector('select[data-roads]');
    var roads = roadPick && roadPick.value ? '@' + roadPick.value : '';
    if (sel.value === 'custom') {
      var cats = Array.prototype.filter.call(sel.parentNode.querySelectorAll('.notify-custom input'), function (b) { return b.checked; })
        .map(function (b) { return b.dataset.cat; });
      if (cats.length) body.devices[sel.dataset.device] = 'custom:' + cats.join(',') + roads;
    } else body.devices[sel.dataset.device] = sel.value + roads;
  });
  withPin('Save notification choices', 'What is worth a push message.', function (pin) {
    body.pin = pin;
    return post('notify-save', body).then(function () { NOTIFY.dirty = false; forgetSig('notify'); return 'Notification choices saved'; });
  });
};
$('notify-test').onclick = function () {
  withPin('Send a test message', 'One message through every configured channel.', function (pin) {
    return post('notify-test', {pin: pin}).then(function (r) { return 'Sent through ' + r.channels.join(' and '); });
  });
};

// ---- backup -------------------------------------------------------------------------
function downloadExport(withSecrets) {
  api('export' + (withSecrets ? '&secrets=1' : '')).then(function (data) {
    var blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'zigmon-settings' + (withSecrets ? '-with-secrets' : '')
      + '-' + new Date().toISOString().slice(0, 10) + '.json';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
  }, function (e) { toast(e.message || String(e), false); });
}
setButtonIcon($('backup-export-secrets'), 'save');
$('backup-export').onclick = function () { downloadExport(false); };
$('backup-export-secrets').onclick = function () {
  withPin('Export with the secrets in it',
    'The file will hold every one-tap link\u2019s own secret, every phone\u2019s authenticator secret, '
    + 'the Duo key, the gateway and router passwords. It is a file, on a laptop, for years: anybody who '
    + 'reads it can open whatever the links open. Without them the restore is complete in every other '
    + 'way \u2014 the links and phones come back and are paired again from their QR codes.',
    function () { downloadExport(true); return 'the export is downloading'; }, true);
};
$('backup-import').onclick = function () { $('backup-file').click(); };
$('backup-now').onclick = function () {
  withPin('Back up now', 'The settings JSON and, if enabled, the Zigbee2MQTT coordinator backup are written on the server.', function (pin) {
    return post('backup-run', {pin: pin}).then(function (r) { return r.message; });
  });
};
$('backup-file').onchange = function () {
  var file = $('backup-file').files[0];
  if (!file) return;
  file.text().then(function (text) {
    var data;
    try { data = JSON.parse(text); } catch (e) { toast('Not a JSON file', false); return; }
    withDangerConfirm('Import settings', 'Bindings, rules, scenes, devices, layout and aliases in the daemon are <b>replaced</b> by the file\u2019s contents.', function (pin) {
      return post('import', {data: data, pin: pin}).then(function (r) {
        BINDINGS.dirty = RULES.dirty = MANAGED.dirty = SCENES.dirty = false;
        BINDINGS.rows = RULES.rows = MANAGED.rows = SCENES.rows = null;
        return 'Imported: ' + (r.imported || []).join(', ');
      });
    });
    $('backup-file').value = '';
  });
};

// ---- refresh loop ------------------------------------------------------------------
// ---- while somebody is holding something -----------------------------------
//
// A live update rebuilds a card, and whatever was inside it goes: a dropdown
// that was open shuts, a run of text that was being copied is lost, and the
// person does the same thing again and loses it again. Editors were already
// guarded one card at a time by editorBusy; these two are not tied to a card
// at all - a selection can span several - so they are held here, at the one
// place every live repaint passes through.
//
// Nothing is thrown away by holding. The newest state is kept as it arrives,
// the long poll keeps running, and the moment the dropdown shuts or the
// selection is let go the page is drawn from the newest thing the daemon
// said. What is delayed is the drawing, never the data.
var HOLD = { select: 0, waiting: false };
function userHolding() {
  // There is no way to ask a browser whether a native dropdown is open, so it
  // is followed from the events that open and shut one; the stamp is also a
  // way out, in case an event that shuts one never arrives.
  if (HOLD.select && Date.now() - HOLD.select < 20000) return true;
  var sel = window.getSelection && window.getSelection();
  if (sel && !sel.isCollapsed && String(sel).replace(/\s+/g, '') !== '') return true;
  return false;
}
function releaseHold() {
  if (!HOLD.waiting || userHolding()) return;
  HOLD.waiting = false;
  tick(true);              // whatever happened while it was held, all at once
}
document.addEventListener('mousedown', function (e) {
  var tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'select') HOLD.select = Date.now();
  else if (HOLD.select) { HOLD.select = 0; setTimeout(releaseHold, 0); }
}, true);
document.addEventListener('keydown', function (e) {
  if ((e.target.tagName || '').toLowerCase() !== 'select') return;
  if (e.key === 'Escape' || e.key === 'Tab') { HOLD.select = 0; setTimeout(releaseHold, 0); }
  else if (e.key === ' ' || e.key === 'Enter' || String(e.key).indexOf('Arrow') === 0) HOLD.select = Date.now();
}, true);
['change', 'blur'].forEach(function (what) {
  document.addEventListener(what, function (e) {
    if ((e.target.tagName || '').toLowerCase() !== 'select') return;
    HOLD.select = 0;
    setTimeout(releaseHold, 0);
  }, true);
});
document.addEventListener('selectionchange', function () {
  if (!HOLD.waiting) return;
  // let go of the text: draw what was held back, but not in the middle of a
  // drag across the page
  clearTimeout(HOLD.timer);
  HOLD.timer = setTimeout(releaseHold, 120);
});

function applyStatus(st) {
  if (userHolding()) {
    // keep the data, keep the long poll, draw nothing
    STATE.status = st;
    HOLD.waiting = true;
    waitLoop();
    // said plainly, because a page that has stopped drawing for a reason
    // nobody can see is indistinguishable from one that has stopped working
    $('updated-label').textContent = HOLD.select ? 'Held \u2014 a list is open' : 'Held \u2014 text selected';
    return;
  }
  var tPaint = performance.now();
  if (sigChanged('alertband', [st.alerts, Math.floor(Date.now() / 30000)])) renderAlertBand(st);
  applyRuntimeFlags(st);                     // before any card is built this tick
  STATE.status = st;
  var pill = $('pill');
  pill.className = 'pill ' + st.level;
  $('pill-text').textContent = levelWord(st.level) + (st.connected ? '' : ' — broker unreachable');
  setFavicon(st.level);
  waitLoop();
  if (LOCK.token && st.pin_required && !st.unlocked_until) setLocked('Editing locked by the daemon');
  renderLock();
  document.title = (st.level === 'ok' ? '' : (st.level === 'crit' ? '⚠ ' : '● ')) + 'Sensors — ' + st.counts.devices + ' devices';
  renderOverview(st);                        // the metric cards - cheap, always
  ['overview', 'plugs', 'sensors', 'buttons', 'history', 'devices', 'sms', 'wifi', 'all', 'control', 'approvals']
    .forEach(function (t) { TAB_STALE[t] = true; });
  renderTab(STATE.tab, st);
  TICK.lastMs = Math.round(performance.now() - tPaint);
  $('updated-time').textContent = stamp(st.ts);
}
function tick(force) {
  setTimeout(markHeaderIndent, 50);       // whatever was drawn this round, put its headers over its boxes
  if ((STATE.paused || document.hidden) && !force) return;
  if (STATE.busy) { if (force) STATE.pendingForce = true; return; }   // never lose a wake-up
  STATE.busy = true;
  api('status').then(function (st) {
    applyStatus(st);
    WAIT.failures = 0;                     // the daemon is back: the next wait retries at once, not after the backoff
    if (userHolding()) return;             // the lists below replace themselves whole, exactly as the cards do
    $('updated-label').textContent = STATE.paused ? 'Paused' : 'Live';
    if (STATE.tab === 'overview') {
      if (!STATE._ovLoaded || (Date.now() - STATE._ovLoaded) > 60000) { loadOverviewCharts(); STATE._ovLoaded = Date.now(); }
      else if (force) scheduleOverviewCharts();     // a live update: the cards are already fresh; the charts follow shortly
    }
    if (STATE.tab === 'events' && force) loadEvents();
    if (STATE.tab === 'control') loadHealth();
  }).catch(function (e) {
    $('pill').className = 'pill crit'; $('pill-text').textContent = 'Dashboard offline';
    $('updated-label').textContent = 'Error';
    $('updated-time').textContent = e.message;
    setFavicon('crit');
  }).then(function () {
    STATE.busy = false;
    if (STATE.pendingForce) { STATE.pendingForce = false; tick(true); }   // the refresh that arrived mid-flight
  });
}
var RULE_OP_SYMBOL = {'>=': '\u2265', '<=': '\u2264', '>': '>', '<': '<', '==': '=', '!=': '\u2260'};
var CONTROL_SEC = 'devices';
var CONTROL_STALE = {};
function showControlSection(sec) {
  var was = CONTROL_SEC;
  CONTROL_SEC = sec;
  // the cards under this section are drawn now; put their column headers over
  // their boxes once they are
  setTimeout(markHeaderIndent, 0);
  setTimeout(markHeaderIndent, 400);
  // the bindings are asked for only when somebody looks at Devices: it is a
  // question for the bridge, not something to ask every few seconds
  if (sec === 'devices') loadBindings(sec !== was);
  if (sec !== was && CONTROL_STALE[sec] && STATE.status) {
    CONTROL_STALE[sec] = false;
    forgetSig('bindings'); forgetSig('rules'); forgetSig('scenes'); forgetSig('sequences');
    forgetSig('schedules'); forgetSig('managed'); forgetSig('ptrig'); forgetSig('messages');
    forgetSig('settings'); forgetSig('gateways'); forgetSig('rooms'); forgetSig('people');
    setTimeout(function () { renderTab('control', STATE.status); }, 0);
  }
  Array.prototype.forEach.call(document.querySelectorAll('#tab-control .grid.charts > [data-sec]'), function (card) {
    card.classList.toggle('sec-off', card.dataset.sec !== sec);
  });
  Array.prototype.forEach.call(document.querySelectorAll('#control-nav button'), function (b) {
    b.classList.toggle('on', b.dataset.sec === sec);
  });
  if (STATE.tab === 'control') {
    try { history.replaceState(null, '', '#control/' + sec); } catch (e) {}
  }
}
function showTab(name) {
  STATE.tab = name;
  renderLock();                      // the Rearrange pill belongs to some tabs only
  Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
    b.setAttribute('aria-selected', b.getAttribute('data-tab') === name ? 'true' : 'false');
  });
  Array.prototype.forEach.call(document.querySelectorAll('.panel'), function (p) { p.hidden = p.id !== 'tab-' + name; });
  if (TAB_STALE[name] !== false) renderTab(name, STATE.status);   // catch up on what changed while hidden
  if (name === 'history') { renderHistoryControls(); loadHistory(); }
  if (name === 'events') loadEvents();
  if (name === 'control') { loadHealth(); showControlSection(CONTROL_SEC); }
  if (name === 'overview') { redrawCharts(); if (!STATE._ovLoaded) { loadOverviewCharts(); STATE._ovLoaded = Date.now(); } }
  try { history.replaceState(null, '', '#' + name + (name === 'control' ? '/' + CONTROL_SEC : '')); } catch (e) {}
}
Array.prototype.forEach.call(document.querySelectorAll('#control-nav button'), function (b) {
  b.onclick = function () { showControlSection(b.dataset.sec); };
});
Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
  b.onclick = function () { showTab(b.getAttribute('data-tab')); };
});
$('updated').onclick = function () {
  STATE.paused = !STATE.paused;
  $('updated').classList.toggle('paused', STATE.paused);
  $('updated-label').textContent = STATE.paused ? 'Paused' : 'Live';
  if (!STATE.paused) tick(true);
};
document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(true); });
function pickOverviewRange(r) {
  STATE.ovRange = r; rangeButtons($('ov-ranges'), ['6h', '24h', '7d'], r, pickOverviewRange); loadOverviewCharts();
}
rangeButtons($('ov-ranges'), ['6h', '24h', '7d'], STATE.ovRange, pickOverviewRange);

if (INITIAL) applyStatus(INITIAL);
var wanted = (location.hash || '#overview').substring(1);
var wantedSec = wanted.split('/')[1] || '';
wanted = wanted.split('/')[0];
if (['devices', 'automation', 'presence', 'alerts', 'system'].indexOf(wantedSec) >= 0) CONTROL_SEC = wantedSec;
showControlSection(CONTROL_SEC);
showTab(['overview', 'plugs', 'sensors', 'buttons', 'heating', 'history', 'devices', 'wifi', 'events', 'approvals', 'control', 'all'].indexOf(wanted) >= 0 ? wanted : 'overview');
// Asked for once at the start: what it brings - the verbs the script box
// offers, and the names a command or a link may point at - is wanted by
// editors drawn before anything else would think to ask.
loadScripts();
tick(true);
STATE.timer = setInterval(function () { tick(false); }, REFRESH_MS);
</script>
</body>
</html>
