#!/usr/bin/env python3
"""The two roads a one-tap link may be opened by, and the code on the second.

A link's secret used to travel in the address, where a web server log, a
proxy, a browser history and the robot that fetches a link preview all keep a
copy - and that last one physically presses the link when the address is
pasted into a message. The header road puts the same secret in a header of a
POST, where none of them can see it, and a six-digit code from a phone can be
asked for on top.

Nothing here needs a broker or a web server.

    ZIGMON_CONFIG=/tmp/zt.json PYTHONPATH=. python3 test/taps.py
"""
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.argv = ['zigmon']
import zigmon                                            # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-taps-check.db'
zigmon.CONFIG['api_port'] = 19701
zigmon.CONFIG['token_file'] = '/tmp/zigmon-taps-token'
Path(zigmon.CONFIG['db_file']).unlink(missing_ok=True)
d = zigmon.Daemon()

# -- the maths, against the examples in RFC 6238 ------------------------------
RFC = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ'
for when, want in ((59, '287082'), (1111111109, '081804'),
                   (1234567890, '005924'), (2000000000, '279037')):
    got = zigmon.totp_at(RFC, when // zigmon.TOTP_STEP)
    assert got == want, 'RFC 6238 at %d gave %s, wanted %s' % (when, got, want)
print('TOTP: four test vectors from RFC 6238, all four right')

# -- which road is open -------------------------------------------------------
d.save_taps([{'name': 'Lamp', 'target': 'notify', 'do': 'on'}])
token = d.taps()[0]['token']


def opened(way, code='', ask=False):
    ok, answer = d.tap(token, '1.2.3.4', ask=ask, way=way, code=code)
    return ok, (answer if isinstance(answer, str) else dict(answer))


for mode, by_link, by_header in (('link', True, False), ('both', True, True), ('header', False, True)):
    zigmon.CONFIG['tap_mode'] = mode
    assert opened('link')[0] is by_link, '%s: the address should be %s' % (mode, 'open' if by_link else 'shut')
    assert opened('header')[0] is by_header, '%s: the header should be %s' % (mode, 'open' if by_header else 'shut')
    print('%-6s address %-7s header %s' % (mode, 'opens' if by_link else 'refused',
                                           'opens' if by_header else 'refused'))

def outward(answer):
    """What the phone is actually sent, whichever shape came back inside."""
    if isinstance(answer, dict):
        return int(answer.get('status') or 403), answer.get('error')
    return 404, answer


# A road that is shut must answer word for word what an address that does not
# exist answers, or an old log tells whoever reads it that its link is real.
zigmon.CONFIG['tap_mode'] = 'header'
assert outward(opened('link')[1]) == outward(d.tap('not-a-real-token', '1.2.3.4')[1]), \
    'a shut road gives itself away by answering differently from an unknown link'
print('a shut road answers exactly as an unknown link does')

# A shut road is not somebody guessing. The secret was right; this is a
# shortcut that has not been changed over. Counted as a wrong try, ten presses
# of a watch face nobody has rewritten shut the links for a minute - taking
# the new shortcut down with them - and each one cost a second of a web
# server worker.
for _ in range(20):
    ok, answer = opened('link')
    assert not ok
    assert isinstance(answer, dict) and answer['status'] == 404, \
        'an old-style press is counted as a guess: %r' % (answer,)
assert d.tap_may_try('1.2.3.4'), 'twenty presses of an old shortcut shut the links'
was = time.time()
opened('link')
assert time.time() - was < 0.2, 'an old-style press is still made to wait'
print('an old shortcut is refused the same way, and costs nothing')

# -- the code -----------------------------------------------------------------
d.save_tap_keys([{'name': 'Falco iPhone'}])
secret = d.tap_keys()[0]['secret']
zigmon.CONFIG['tap_code'] = 1
assert d.tap_code_wanted()

ok, answer = opened('header')
assert not ok and answer['status'] == 403, 'a header with no code was let through'
ok, answer = opened('header', code='000000')
assert not ok and answer['status'] == 403, 'six wrong digits were let through'

def code_from(steps_back=0):
    # read the clock for each one: a window that turns over between two lines
    # of this test would otherwise make it fail for no reason
    return zigmon.totp_at(secret, int(time.time() // zigmon.TOTP_STEP) - steps_back)


assert opened('header', code=code_from())[0], 'the code showing now was refused'
# A code is good while its own window is open - somebody in a doorway presses
# twice - and refused for ever after, which is what makes a secret read out of
# a log next week worth nothing.
assert opened('header', code=code_from())[0], 'the second press inside the same code was refused'
assert opened('header', code=code_from(1))[0], 'a clock a step slow was refused'
assert not opened('header', code=code_from(3))[0], 'a code a minute and a half old was taken'
assert not opened('header', code=code_from(20160))[0], 'a code from a week ago was taken'
print('the code: this window and one either side, and nothing older')

# asking how things stand touches nothing and needs no code
assert opened('header', ask=True)[0], 'asking was refused'

# -- a new secret for the same phone -----------------------------------------
# A secret seen by the wrong person is replaced, not the phone taken away:
# taking it away would be a second decision - about which links it may open -
# that nobody asked to make.
was = d.tap_keys()[0]['secret']
kept = d.tap_keys()[0]['id']
fresh = zigmon.totp_secret()
d.store.set_meta('tap_keys', __import__('json').dumps(
    [dict(k, secret=fresh) if k['id'] == kept else k for k in d.tap_keys()]))
assert d.tap_keys()[0]['id'] == kept, 'rolling the secret changed which phone it is'
assert d.tap_keys()[0]['name'] == 'Falco iPhone', 'rolling the secret lost the name'
assert not d.tap_key_for(zigmon.totp_at(was, int(time.time() // zigmon.TOTP_STEP))), \
    'the old secret still opens things'
assert d.tap_key_for(zigmon.totp_at(fresh, int(time.time() // zigmon.TOTP_STEP))), \
    'the new secret does not open anything'
secret = fresh
print('a phone can be given a new secret without losing its name or its links')

# -- the wait before reading a socket back ------------------------------------
# Only where there is a socket to read. A link on a notification, on heating,
# on a Zigbee switch or on a sequence has nothing to come back for, and the
# third of a second was spent on the wrist for nothing at every press.
zigmon.CONFIG['tap_code'] = 0
started = time.time()
assert opened('header')[0], 'the press was refused'
spent = time.time() - started
assert spent < 0.1, 'a link with nothing to read back still waits %.2f s' % spent
print('a press with nothing to read back answers at once (%.0f ms)' % (spent * 1000))

# and where there IS a socket, the wait is still taken and the state is read
# twice: once to see whether it is worth waiting for, once for the answer
reads = []
real_state = d.tap_state


def counted(targets):
    reads.append(time.time())
    return 'on', 'on'                 # as a socket would answer


d.tap_state = counted
started = time.time()
assert opened('header')[0]
spent = time.time() - started
d.tap_state = real_state
assert len(reads) == 2, 'the state was read %d time(s), wanted twice' % len(reads)
assert 0.3 < spent < 0.6, 'a socket was not given its moment to answer (%.2f s)' % spent
print('a press on a socket still waits for it (%.0f ms)' % (spent * 1000))
zigmon.CONFIG['tap_code'] = 1

# -- the other second factor: Duo approves it --------------------------------
# The watch cannot make a six-digit code, so the code has to be finished on
# the phone. Duo asks the person instead and has a watch app of its own, so
# the press is approved where it was made. Nothing about it is asked of the
# shortcut beyond coming back for the answer.
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'duo'
for key in ('duo_host', 'duo_ikey', 'duo_skey', 'duo_user'):
    zigmon.CONFIG[key] = ''
ok, answer = opened('header')
assert not ok and answer['status'] == 503, 'a link asked Duo while Duo was not set up'
zigmon.CONFIG.update({'duo_host': 'api-test.duosecurity.com', 'duo_ikey': 'DI', 'duo_skey': 's',
                      'duo_user': 'somebody'})

asked = []


def _yes(what, who=''):
    asked.append(what)
    time.sleep(0.3)
    return True, 'approved'


d.duo_push = _yes
ok, answer = opened('header')
assert ok and answer['state'] == 'waiting' and answer.get('ticket'), \
    'the press did not come back with a ticket: %r' % (answer,)
ticket = answer['ticket']
got, state = d.tap_waiting(ticket, 5)
assert got and state['state'] == 'done', 'an approved press did not happen: %r' % (state,)
assert asked and 'notification' in asked[0], 'Duo was not told what it was approving: %r' % (asked,)
# asking again says the same thing rather than doing it twice
again = d.tap_waiting(ticket, 1)
assert again[1]['state'] == 'done'
d.duo_push = lambda what, who='': (False, 'denied')
ok, answer = opened('header')
assert d.tap_waiting(answer['ticket'], 5)[1]['state'] == 'refused', 'a refused press was let through'
assert d.tap_waiting('not-a-ticket', 1)[1]['status'] == 404, 'a ticket nobody made was answered'
print('Duo: a press waits to be approved, and happens only if it is')

# The signature Duo checks. Two ways of writing the canonical form are in use
# - the one the Auth API documents and the one the published client defaults
# to - and an account takes one and calls the other "Invalid signature in
# request credentials", which says nothing about which. Both are written out,
# so both must keep their shape.
_when = 'Tue, 21 Aug 2012 17:25:06 -0700'
_ikey, _skey = 'DIWJ8X6AEYOR5OMC6TQ1', 'Zh5eGmUq9zpfQnyUIu5OL9iWoMMv5ZNmk3zLJ4Ep'
_params = {'factor': 'push', 'username': 'somebody'}
_shapes = set()
for _v, _d in zigmon.DUO_WAYS:
    _one = zigmon.duo_sign(_ikey, _skey, 'POST', 'api-XXXXXXXX.duosecurity.com', '/auth/v2/auth',
                           _when, _params, _v, _d)
    assert _one.startswith('Basic '), 'v%s %s is not an Authorization header' % (_v, _d)
    assert _one == zigmon.duo_sign(_ikey, _skey, 'POST', 'api-XXXXXXXX.duosecurity.com',
                                   '/auth/v2/auth', _when, _params, _v, _d), \
        'v%s %s signed the same request two ways' % (_v, _d)
    assert _one != zigmon.duo_sign(_ikey, _skey, 'POST', 'api-XXXXXXXX.duosecurity.com',
                                   '/auth/v2/auth', _when, {'factor': 'push', 'username': 'else'}, _v, _d), \
        'v%s %s does not sign the parameters' % (_v, _d)
    _shapes.add(_one)
assert len(_shapes) == len(zigmon.DUO_WAYS), 'two ways of signing give the same answer, so one is wrong'
print('Duo: all %d ways of signing keep their shape, and differ from each other' % len(zigmon.DUO_WAYS))

# And which way an account takes is found out rather than assumed: four ways
# of signing are in use between the versions of the canonical form and the two
# digests, and an account takes one and calls the other three a bad signature
# without saying which. Each is tried in turn and the one that answers is
# written down.
_tried = []


def _only_sha1(method, path, params, host, version, digest, timeout):
    _tried.append('%s:%s' % (version, digest))
    if (version, digest) != ('2', 'sha1'):
        raise ValueError('Invalid signature in request credentials')
    return {'time': 1}


zigmon.CONFIG.update({'duo_host': 'api-x.duosecurity.com', 'duo_ikey': 'DI', 'duo_skey': 'sk'})
d.duo_lib = lambda timeout=20: None        # the machine without Duo's own package
d._duo_once = _only_sha1
d.duo_call('GET', '/auth/v2/check', {})
assert _tried == ['2:sha512', '2:sha1'], 'it did not walk the ways in order: %r' % (_tried,)
_tried.clear()
d.duo_call('GET', '/auth/v2/check', {})
assert _tried == ['2:sha1'], 'it asked all over again instead of remembering: %r' % (_tried,)
assert d.store.get_meta('duo_way') == '2:sha1', 'the way that worked was not written down'
print('Duo: the way of signing is found once and then remembered')

# Duo's own package is the reference for every detail of the signing, so it is
# used wherever the machine has it, and what is written out here is only for a
# machine that has not.
_lib_tried = []
d._duo_way = None
d.store.set_meta('duo_way', '')


class _PretendLib(object):
    def json_api_call(self, method, path, params):
        _lib_tried.append(path)
        return {'time': 1}


d.duo_lib = lambda timeout=20: _PretendLib()
assert d.duo_call('GET', '/auth/v2/check', {}) == {'time': 1}
assert _lib_tried == ['/auth/v2/check'], 'the package was there and was not used'
_tried.clear()
assert not _tried, 'it signed for itself while the package was answering'
d.duo_lib = lambda timeout=20: None
d.duo_call('GET', '/auth/v2/check', {})
assert _tried, 'without the package it did not sign for itself'
print('Duo: the package is used where it is installed, and not needed where it is not')

# What the endpoint answers is a `result` - waiting, allow or deny. The
# published client's own auth_status() turns that into `waiting` and
# `success`, and this asks the endpoint directly, so it gets neither: reading
# those off the raw answer made every press refused a fifth of a second after
# it was made, before the phone had finished buzzing.
d.duo_push = zigmon.Daemon.duo_push.__get__(d)     # the real one again, not the stub above
_answers = []


def _push_then(*seq):
    _answers[:] = list(seq)

    def call(method, path, params, timeout=20):
        if path.endswith('/auth'):
            return {'txid': 't-1'}
        return _answers.pop(0) if _answers else {'result': 'waiting'}
    d.duo_call = call


_push_then({'result': 'waiting', 'status': 'pushed'}, {'result': 'allow', 'status_msg': 'Approved'})
assert d.duo_push('a lamp') == (True, 'Approved'), 'a press waiting on the phone was called refused'
_push_then({'result': 'deny', 'status_msg': 'Login request denied.'})
assert d.duo_push('a lamp')[0] is False, 'a refused press was let through'
# and the shape the package's own auth_status() hands back is read too
_push_then({'waiting': True}, {'waiting': False, 'success': True, 'status_msg': 'ok'})
assert d.duo_push('a lamp') == (True, 'ok'), 'the package\u2019s own shape was misread'
print('Duo: a press waits while Duo says it is waiting, and only then is it answered')

# An account with three devices cannot be asked to guess which one Duo's own
# "auto" will pick - it is as likely to be the iPad on a shelf as the phone in
# a pocket. What preauth says is kept, so the dashboard can offer the list,
# and the one chosen is what the press is addressed to.
_pre = {'result': 'auth', 'devices': [
    {'device': 'DP111', 'display_name': 'iPad 2019', 'capabilities': ['auto', 'push']},
    {'device': 'DP333', 'display_name': 'iPhone16', 'capabilities': ['auto', 'push', 'sms']}]}
d.duo_call = lambda m, p, params, timeout=20: {} if p.endswith('check') else _pre
assert d.duo_check()[0], 'the test refused an account that can take a push'
assert [x['device'] for x in d.duo_devices()] == ['DP111', 'DP333'], 'the devices were not kept'
assert [x['name'] for x in d.status()['duo_devices']] == ['iPad 2019', 'iPhone16'], \
    'the dashboard is not told what it may choose between'
d.save_config_overrides({'duo_device': 'DP333'})
_sent = {}


def _watch(m, p, params, timeout=20):
    if p.endswith('/auth'):
        _sent.update(params)
        return {'txid': 't'}
    return {'result': 'allow', 'status_msg': 'ok'}


d.duo_call = _watch
d.duo_push('a lamp')
assert _sent.get('device') == 'DP333', 'the press was not addressed to the chosen device: %r' % (_sent,)
zigmon.CONFIG['duo_device'] = 'auto'
d.duo_push('a lamp')
assert _sent.get('device') == 'auto', 'auto stopped meaning auto'
print('Duo: the press goes to the device that was chosen, not the one Duo would pick')

# A press that has to be approved is answered when it is approved, not with a
# ticket to come back for: coming back is three more actions in a shortcut,
# and a person standing at a door is waiting either way.
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'duo'
zigmon.CONFIG['duo_wait_s'] = 10
d.duo_push = lambda what, who='': (time.sleep(0.4) or (True, 'approved'))
_started = time.time()
_ok, _answer = d.tap(token, '1.2.3.4', way='header')
assert _ok and _answer.get('ticket'), 'the press did not start'
_ok, _answer = d.tap_waiting(_answer['ticket'], 5)
assert _ok and _answer['state'] == 'done', 'waiting on the ticket did not give the outcome'
assert time.time() - _started >= 0.4, 'it answered before the approval could arrive'
print('Duo: the outcome can be waited for on the one request that made it')

# A key pasted from a web page brings a space or a newline with it more often
# than not, and Duo refuses a key with one stuck to it in exactly the words it
# refuses a wrong key with.
d.save_config_overrides({'duo_host': ' api-x.duosecurity.com \n', 'duo_ikey': ' DI ',
                         'duo_skey': 'SK\n', 'duo_user': ' falco '})
for _k, _want in (('duo_host', 'api-x.duosecurity.com'), ('duo_ikey', 'DI'),
                  ('duo_skey', 'SK'), ('duo_user', 'falco')):
    assert zigmon.CONFIG[_k] == _want, '%s was stored as %r' % (_k, zigmon.CONFIG[_k])
print('Duo: what is pasted in is stored without the whitespace around it')

# Nothing is thrown away by choosing one factor over the other.
_before = [k['secret'] for k in d.tap_keys()]
zigmon.CONFIG['tap_factor'] = 'totp'
assert [k['secret'] for k in d.tap_keys()] == _before, 'the phones lost their secrets'
zigmon.CONFIG['tap_factor'] = 'duo'
assert str(zigmon.CONFIG['duo_ikey']), 'the Duo keys were lost'
zigmon.CONFIG['tap_factor'] = 'totp'
zigmon.CONFIG['tap_code'] = 1
assert opened('header', code=code_from())[0], 'a code stopped working after a turn through Duo'
print('both factors keep what is theirs, whichever is chosen')

# -- what the dashboard may see ----------------------------------------------
state = d.status()
assert secret not in repr(state), 'a code secret went out with the status'
assert [k.get('secret') for k in state['tap_keys']] == [None], 'the phones went out with their secrets'
assert all('secret' not in k for k in state['tap_keys'])
print('the phones go out by name; the secrets stay in the daemon')

# Choosing a factor and demanding one are two decisions. Refusing both at once
# made the choice impossible to make: Duo's boxes are not asked for until Duo
# is the factor, and Duo could not be made the factor until its boxes were
# filled in - so there was nowhere to type them. The choice stands; the demand
# is what gives way, and says so.
zigmon.CONFIG['tap_mode'] = 'header'
for _k in ('duo_host', 'duo_ikey', 'duo_skey', 'duo_user'):
    zigmon.CONFIG[_k] = ''
d.save_config_overrides({'tap_factor': 'duo', 'tap_code': 1})
assert zigmon.CONFIG['tap_factor'] == 'duo', 'Duo could not be chosen before it was set up'
assert not zigmon.CONFIG['tap_code'], 'a factor nothing can answer was left demanded'
assert 'Duo' in (d.last_config_note or ''), 'nothing was said about why it was switched off'
d.save_config_overrides({'duo_host': 'api-x.duosecurity.com', 'duo_ikey': 'DI',
                         'duo_skey': 'sk', 'duo_user': 'falco'})
d.save_config_overrides({'tap_code': 1})
assert zigmon.CONFIG['tap_code'] and not d.last_config_note, 'it could not be switched on once Duo was set up'
print('Duo can be chosen first and filled in afterwards, which is the only order there is')

# -- the switch that would lock everybody out --------------------------------
zigmon.CONFIG['tap_mode'] = 'link'
zigmon.CONFIG['tap_code'] = 0
zigmon.CONFIG['tap_factor'] = 'totp'
d.store.set_meta('tap_keys', '[]')
d.save_config_overrides({'tap_code': 1, 'tap_mode': 'header'})
assert not zigmon.CONFIG.get('tap_code'), 'a code was demanded with no phone to show one'
assert 'phone' in (d.last_config_note or ''), 'nothing was said about why'
print('a code with no phone to show one is not demanded, and it is said why')


# -- and what this daemon writes down about it --------------------------------
# A secret in an address is a secret in the log. The header road exists
# because a URL is written down everywhere it goes, and the daemon's own debug
# log was one of those places: a link opened by its address went in whole.
# Enough is left to tell two links apart and no more.
_hide = zigmon.ApiHandler.hide_secrets
_line = _hide('"GET /api/tap/%s HTTP/1.1" 200 -' % token)
assert token not in _line, 'a link secret is still written into the log: %s' % _line
assert token[-4:] in _line, 'nothing is left to tell one link from another: %s' % _line
assert 'my-push-word' not in _hide('"GET /index.php?api=sms-incoming&secret=my-push-word HTTP/1.1"'), \
    'the word a forwarded message carries is still written down'
assert token not in _hide('"GET /index.php?t=%s&ask HTTP/1.1" 200 -' % token), \
    'the older address form is still written down whole'
assert _hide('"GET /api/status HTTP/1.1" 200 -') == '"GET /api/status HTTP/1.1" 200 -', \
    'an ordinary line was changed'
assert '{plugs_on_list.nl}' in _hide('"GET /api/message-preview?text={plugs_on_list.nl}"'), \
    'something that is not a secret was blotted out'
print('a secret in an address does not reach the log')

# Behind a server of its own, every press arrives from that server. What it
# says the caller was is worth showing - the proxy's address on every line
# tells nobody anything - but it is a claim, not proof, since anyone may send
# that header. It is shown as a claim, and guesses are counted against the
# address the request really came from, or a guesser would pick a new claim
# per try and the counter would never fill.


class _Pretend(object):
    def __init__(self, headers):
        self.headers = headers
        self.client_address = ('127.0.0.1', 1)
        self.daemon = d
    _who = zigmon.ApiHandler._who
    _caller = zigmon.ApiHandler._caller


assert _Pretend({'X-Zigmon-Client': '10.8.0.1'})._who() == '10.8.0.1'
_said = _Pretend({'X-Zigmon-Client': '10.8.0.1', 'X-Zigmon-Via': '89.24.5.7, 10.8.0.1'})._who()
assert _said == '10.8.0.1 (says 89.24.5.7)', 'a claim is not shown as a claim: %r' % _said
assert _Pretend({'X-Zigmon-Client': '10.8.0.1', 'X-Zigmon-Via': '89.24.5.7'})._caller() == '10.8.0.1', \
    'the counting would be done against a claim from an unnamed proxy'
assert _Pretend({'X-Zigmon-Client': '1.2.3.4', 'X-Zigmon-Via': '1.2.3.4'})._who() == '1.2.3.4', \
    'a proxy that agrees with itself is said twice'
print('a caller a proxy claims is shown as a claim, and never counted as one')

# ...and the debug log says both, since everything arrives over the loopback
# from the relay and the line named nobody at all: an arrow where the claim is
# believed, "says" where it is not.
_lines = []
_was_log = zigmon.log
zigmon.log = lambda text, level='info', **k: _lines.append(str(text))
try:
    _pretend = _Pretend({'X-Zigmon-Client': '192.168.43.17', 'X-Zigmon-Via': '89.24.5.7'})
    _pretend.hide_secrets = lambda text: text      # its own guard is checked elsewhere
    _pretend.log_message = zigmon.ApiHandler.log_message.__get__(_pretend)
    zigmon.CONFIG['trusted_proxies'] = '192.168.43.17'
    _pretend.log_message('%s', '"POST /api/tap" 200')
    zigmon.CONFIG['trusted_proxies'] = ''
    _pretend.log_message('%s', '"POST /api/tap" 200')
finally:
    zigmon.log = _was_log
assert '192.168.43.17 \u2192 89.24.5.7' in _lines[0], 'the believed claim is not shown: %r' % _lines[0]
assert '192.168.43.17 says 89.24.5.7' in _lines[1], 'an unbelieved claim is not shown as one: %r' % _lines[1]
print('the log names the server that carried a press and the address it says pressed')

# And with debug on, every header a request carried - behind a server of its
# own, what arrived is the only way to tell a thing that was sent from a thing
# that was dropped on the way. A header whose value is the thing itself is
# shown as its last few letters, so the log can be read without being worth
# stealing.
_lines = []
_was_log = zigmon.log
zigmon.log = lambda text, level='info', **k: _lines.append(str(text))
try:
    _pretend = _Pretend({'X-Zigmon-Tap': 'a-very-long-secret-1234',
                         'X-Zigmon-Code': '123456',
                         'X-Zigmon-Arg-Ip': '1.2.3.4',
                         'User-Agent': 'BackgroundShortcutRunner/4711'})
    _pretend.SECRET_HEADERS = zigmon.ApiHandler.SECRET_HEADERS
    _pretend.log_headers = zigmon.ApiHandler.log_headers.__get__(_pretend)
    _pretend.log_headers()
finally:
    zigmon.log = _was_log
_said = _lines[0]
assert 'X-Zigmon-Arg-Ip: 1.2.3.4' in _said, 'an ordinary header is not shown: %r' % _said
assert 'BackgroundShortcutRunner' in _said, 'the agent is not shown'
assert 'a-very-long-secret-1234' not in _said, 'a link secret is written out in full: %r' % _said
assert '1234' in _said, 'a secret is not shown by its last letters at all'
assert '123456' not in _said, 'a six-digit code is written out in full'
print('the debug log shows every header, with the ones that are secrets shortened')

# and on every road, not only the API: a push arriving, a call out to a plug,
# and the answer it gives back
assert 'Authorization: \u2026cafe' in zigmon.header_line(
    {'Content-Type': 'application/json', 'Authorization': 'Digest user=admin response=deadbeefcafe'}), \
    'an outgoing Authorization is written out in full'
assert 'WWW-Authenticate: \u20265678' in zigmon.header_line(
    {'WWW-Authenticate': 'Digest realm=shelly nonce=12345678'}), \
    'what a plug answers with is written out in full'
assert 'User-Agent: ntfy' in zigmon.header_line({'User-Agent': 'ntfy'}), 'an ordinary header is hidden'
_src = open(str(__file__).rsplit('/', 2)[0] + '/zigmon.py').read()
for _road in ('api    headers', 'push    headers', 'http    headers'):
    assert _road in _src, 'the %s road shows no headers in debug' % _road.split()[0]
print('the API, a push arriving and a call out to a plug all show their headers')

# ...and whole, when the house asks for whole: debugging the very path that
# carries a secret is exactly when the shortening is in the way.
zigmon.CONFIG['debug_secrets'] = 0
assert 'a-very-long-secret-1234' not in zigmon.header_line({'X-Zigmon-Tap': 'a-very-long-secret-1234'})
zigmon.CONFIG['debug_secrets'] = 1
assert 'a-very-long-secret-1234' in zigmon.header_line({'X-Zigmon-Tap': 'a-very-long-secret-1234'}), \
    'debug_secrets does not show a secret whole'
assert '123456' in zigmon.header_line({'X-Zigmon-Code': '123456'}), 'a code is still hidden'
_path = '/api/tap/a-very-long-secret-1234'
assert zigmon.ApiHandler.hide_secrets(_path) == _path, 'a secret in the path is still blotted'
zigmon.CONFIG['debug_secrets'] = 0
assert zigmon.ApiHandler.hide_secrets(_path) != _path, \
    'with it off, a secret in the path is written out'
print('debug_secrets shows them whole, and hides them again when it is off')

# and with it off, an address carrying a session or a PIN is blotted: the page
# puts a session on every request it makes
zigmon.CONFIG['debug_secrets'] = 0
for _name, _value in (('session', 'Xq8aS69EgFMqSQby-MzmnpDJctlLrcvG'), ('pin', '4321')):
    _line = '"GET /api/status?%s=%s HTTP/1.1" 200' % (_name, _value)
    assert _value not in zigmon.ApiHandler.hide_secrets(_line), \
        'a %s in an address is written out: %r' % (_name, zigmon.ApiHandler.hide_secrets(_line))
print('a session or a PIN in an address is blotted in the log')

# With debug_secrets on, the house has asked for everything open: the headers
# whole, the addresses whole, a body not cut off where the thing being looked
# for tends to be, and what Duo answered as it answered it.
zigmon.CONFIG['debug_secrets'] = 1
assert len(zigmon.debug_cut('x' * 600)) == 600, 'a body is still cut short'
assert 'deadbeefcafe' in zigmon.header_line({'Authorization': 'Digest response=deadbeefcafe'})
assert 'SECRET' in zigmon.Daemon.duo_gist({'result': 'allow', 'signature': 'SECRET'}), \
    'what Duo answered is still summarised'
zigmon.CONFIG['debug_secrets'] = 0
assert len(zigmon.debug_cut('x' * 600)) == 400, 'with it off a body is not shortened'
assert 'SECRET' not in zigmon.Daemon.duo_gist({'result': 'allow', 'signature': 'SECRET'}), \
    'with it off a Duo answer carries a secret'
print('debug_secrets opens the headers, the addresses, the bodies and what Duo said')

# The names of stored files come from outside. None of them may name a place
# outside the folder they belong in.
_bad = ['../../../../etc/passwd', '/etc/shadow', 'a/../../../tmp/x', 'ok.db; rm -rf /',
        '..%2f..%2fetc%2fpasswd', 'x' * 300, '\x00etc/passwd', '....//....//etc/passwd',
        'zigmon-db-../../evil.sqlite', 'zigmon-db-x.sqlite/../../../evil']
for _nm in _bad:
    try:
        _p = d.db_backup_path(_nm)
        raise AssertionError('a backup name reached %s' % _p)
    except ValueError:
        pass
_made = re.sub(r'[^0-9A-Za-z._-]', '-', '../../../../etc/passwd')
assert '/' not in _made, 'a separator survived the sanitising'
print('%d hostile file names, none of them naming a place outside the folder' % len(_bad))

# A copy of the house is the same house: the same settings, the same links,
# the same phones. And a file that opens a garage is not made by somebody who
# meant to keep a copy of their layout - the secrets go in only when asked
# for, and without them the restore still works, with fresh ones.
zigmon.CONFIG['tap_mode'] = 'header'
d.save_config_overrides({'tap_mode': 'header', 'tap_factor': 'duo', 'duo_user': 'somebody',
                         'duo_skey': 'THESECRETKEY'})
_plain = json.dumps(d.export_settings())
_full = json.dumps(d.export_settings(secrets=True))
_token = d.taps()[0]['token']
_phone = d.tap_keys()[0]['secret'] if d.tap_keys() else ''
for _secret in [x for x in ('THESECRETKEY', _token, _phone) if x]:
    assert _secret not in _plain, 'a secret is in the ordinary export'
    assert _secret in _full, 'a secret is missing from the one that asked for them'
for _key in ('settings', 'taps', 'tap_keys'):
    assert _key in json.loads(_plain), 'an export without %s is not a copy of the house' % _key
assert json.loads(_plain)['settings'].get('tap_factor') == 'duo', 'Settings are not carried'
assert json.loads(_full)['holds_secrets'] and not json.loads(_plain)['holds_secrets']
print('an export is a copy of the house, and holds no secret unless it is asked for')

# ---- addresses that behave like somebody trying things ----------------------
zigmon.CONFIG.update({'block_mode': 'temporary', 'block_minutes': 30, 'block_score': 15,
                      'block_private': 'never', 'trusted_proxies': ''})
d.store.unblock()
# with "never", the house is left alone whatever it does
for _i in range(9):
    d.note_anomaly('192.168.40.170', 'bad-secret', 'link %d' % _i)
assert d.store.blocked_until('192.168.40.170') is None, 'the house blocked itself'
# three wrong secrets from outside is a block, and it runs out. They are the
# same secret here, so they are made far enough apart to be three tries rather
# than one browser asking three times.
for _i in range(3):
    zigmon.Daemon.SAME_TRY_WITHIN = 0
    d.note_anomaly('89.24.5.7', 'bad-secret', 'Garaz')
zigmon.Daemon.SAME_TRY_WITHIN = 2.0
_until = d.store.blocked_until('89.24.5.7')
assert _until and _until > time.time(), 'three wrong secrets were let by'
assert 25 * 60 < _until - time.time() <= 30 * 60, 'the block does not last what it was told to'
# looking around costs more than mistyping: different links add to the weight
d.store.unblock()
for _i in range(2):
    d.note_anomaly('89.24.5.8', 'bad-code', 'one link')
assert d.store.blocked_until('89.24.5.8') is None, 'two wrong codes on one link is a block'
for _i in range(4):
    d.note_anomaly('89.24.5.9', 'bad-secret', 'link %d' % _i)
assert d.store.blocked_until('89.24.5.9') is not None, 'somebody trying four links was let by'
# off means off, permanent means permanent
zigmon.CONFIG['block_mode'] = 'off'
for _i in range(9):
    d.note_anomaly('89.24.6.1', 'bad-secret', 'link %d' % _i)
assert d.store.blocked_until('89.24.6.1') is None, 'it blocked somebody while switched off'
zigmon.CONFIG['block_mode'] = 'permanent'
for _i in range(4):
    d.note_anomaly('89.24.6.2', 'bad-secret', 'link %d' % _i)
assert d.store.blocked_until('89.24.6.2') == 0, 'a permanent block is not permanent'
# one that has run out is not a block
d.store.block('89.24.7.1', time.time() - 1, 'old')
assert d.store.blocked_until('89.24.7.1') is None, 'an expired block still shuts somebody out'
# by hand, and off again
d.store.block('89.24.8.1', None, 'by hand', auto=False, by='me')
assert d.store.blocked_until('89.24.8.1') == 0
assert d.store.unblock('89.24.8.1') == 1 and d.store.blocked_until('89.24.8.1') is None
# and it keeps, because it is in the database rather than in memory
assert any(r['ip'] == '89.24.6.2' for r in zigmon.Daemon.blocked_list(d)), 'the list is not kept'
print('%d address(es) on the list, blocked by weight and not by counting' % len(d.blocked_list()))

# A claim is believed only from a server that was named as one; from anybody
# else the address they really came from is what counts, or a guesser picks a
# new claim per try and is never blocked at all.
assert d.caller_of('10.8.0.1', '89.24.5.7') == '10.8.0.1', 'an unnamed proxy was believed'
zigmon.CONFIG['trusted_proxies'] = '10.8.0.0/24, 172.16.0.5'
assert d.caller_of('10.8.0.1', '89.24.5.7, 10.8.0.1') == '89.24.5.7', 'a named proxy was not believed'
assert d.caller_of('172.16.0.5', '89.24.5.7') == '89.24.5.7'
assert d.caller_of('89.24.9.9', '1.2.3.4') == '89.24.9.9', 'a stranger claiming to be a proxy'
zigmon.CONFIG['trusted_proxies'] = ''
print('a forwarded address is believed only from a server that was named as one')

# the same list, as a firewall takes it
d.store.block('89.24.9.1', time.time() + 600, 'for the firewall', auto=True)
_lines = d.blocked_mikrotik()
assert any('address=89.24.9.1' in x and 'timeout=' in x for x in _lines), 'no line for the firewall'
assert any('address-list add list=zigmon' in x for x in _lines)
print('%d line(s) a Mikrotik would take, timeouts and all' % len(_lines))

# ---- and carried to the router itself --------------------------------------
# One address list, and inside it only what this put there. A list somebody
# keeps by hand under the same name keeps every entry they made.
zigmon.CONFIG.update({'mikrotik_host': '192.168.40.1', 'mikrotik_list': 'zigmon',
                      'mikrotik_user': 'zigmon', 'mikrotik_auth': 'key', 'mikrotik_sync': 0})
d.store.unblock()
d.store.block('89.24.9.1', None, 'three wrong secrets', auto=True)
_sent = []


def _pretend(cmd):
    _sent.append(cmd)
    if 'print terse' in cmd:
        return ('0 list=zigmon address=10.9.9.9 comment="a hand-made entry"\n'
                '1 list=zigmon address=89.24.5.7 timeout=30m comment="zigmon: gone from here"\n')
    return ''


d.mikrotik_run = _pretend
_out = d.mikrotik_sync('a test')
assert _out['added'] == 1 and _out['removed'] == 1 and _out['kept'] == 1, 'the sync did the wrong thing: %r' % _out
assert any('add list=zigmon address=89.24.9.1' in c for c in _sent), 'the new one was not added'
assert any('remove [find list=zigmon address=89.24.5.7 comment~"^zigmon:"]' in c for c in _sent), \
    'the one no longer blocked was not taken off'
assert not any('10.9.9.9' in c for c in _sent), 'it touched an entry somebody else made'
assert all('list=zigmon' in c for c in _sent), 'it touched something outside the one list'
assert not any('remove' in c and 'comment~' not in c for c in _sent), \
    'a removal that does not insist on the mark could take away anybody\u2019s entry'
# a list name is held to the letters a list name may have, since it ends up in
# a command line on the router
assert d.mikrotik_name('zig mon; /system reboot') == 'zigmonsystemreboot'
assert d.mikrotik_name('../x') == 'x'
for _bad in ('', '   ', ';;;'):
    try:
        d.mikrotik_name(_bad)
        raise AssertionError('an empty list name was allowed')
    except ValueError:
        pass
print('the router is told about one list only, and only about entries this one made')

# A change here reaches the router at once, not at the next sweep: an address
# blocked is a rule there a moment later.
zigmon.CONFIG['mikrotik_sync'] = 1
_sent[:] = []
_t0 = time.time()
d.store.block('89.24.7.7', None, 'by hand', auto=False)
d.mikrotik_after_change()
time.sleep(0.4)
assert _sent, 'a change here never reached the router'
assert time.time() - _t0 < 1.0, 'it took its time about it'
assert any('address=89.24.7.7' in c for c in _sent), 'the new one was not put there'
zigmon.CONFIG['mikrotik_sync'] = 0
print('a change here is on the router within the second')

# Each line says whether the router is carrying it too, as the last look found
# it - and nothing at all where no router is in use, rather than a mark that
# would mean "no" when it means "there is no router".
zigmon.CONFIG['mikrotik_host'] = ''
assert all(r['router'] == '' for r in d.blocked_list()), 'it marks a router that is not there'
zigmon.CONFIG['mikrotik_host'] = 'r'
d.store.set_meta('mikrotik_seen', '')
assert all(r['router'] == 'no' for r in d.blocked_list()), 'unlooked-at reads as carried'
d.mikrotik_run = lambda cmd: ('0 list=zigmon address=89.24.7.7 comment="zigmon: by hand"\n'
                              if 'print terse' in cmd else '')
d.mikrotik_entries()
_marks = {r['ip']: r['router'] for r in d.blocked_list()}
assert _marks.get('89.24.7.7') == 'yes', 'one the router holds is not marked: %r' % _marks
assert all(v == 'no' for k, v in _marks.items() if k != '89.24.7.7'), 'everything was marked carried'
print('each line says whether the router is carrying it, and says nothing where there is none')

# An address written under "never kept out" beats a block by hand as surely as
# one made by the detector: it stays on the list to be seen, does nothing at
# all, and is never given to the router.
zigmon.CONFIG['never_block'] = '192.168.1.0/24, 89.24.9.9'
d.store.unblock()
d.store.block('192.168.1.120', None, 'by hand', auto=False)
d.store.block('89.24.9.9', None, 'by hand', auto=False)
d.store.block('89.24.5.7', None, 'a stranger', auto=True)
_rows = {r['ip']: r for r in d.blocked_list()}
assert _rows['192.168.1.120']['spared'] == '192.168.1.0/24', 'a range does not spare its addresses'
assert _rows['89.24.9.9']['spared'] == '89.24.9.9', 'an address written out does not spare itself'
assert not _rows['89.24.5.7']['spared'], 'it spared somebody it was not asked to'
assert _rows['192.168.1.120']['router'] == '', 'a spared one is marked as the router might carry it'


class _Sparing(object):
    headers = {'X-Zigmon-Client': '192.168.1.120'}
    client_address = ('127.0.0.1', 1)
    daemon = d
    _who = zigmon.ApiHandler._who
    _caller = zigmon.ApiHandler._caller
    _shut_out = zigmon.ApiHandler._shut_out

    def _send(self, *a):
        raise AssertionError('a spared address was turned away')


assert _Sparing()._shut_out(d) is False, 'a spared address was kept out'
_sent[:] = []
d.mikrotik_run = lambda c: (_sent.append(c) or
                            ('0 list=zigmon address=192.168.1.120 comment="zigmon: old"\n'
                             if 'print terse' in c else ''))
_out = d.mikrotik_sync('a test')
assert not any('address-list add' in c and '192.168.1.120' in c for c in _sent), \
    'a spared one was given to the router'
assert any('address-list remove' in c and '192.168.1.120' in c for c in _sent), \
    'a spared one already on the router was left there'
zigmon.CONFIG['never_block'] = ''
d.store.unblock()
print('what is never kept out is shown, does nothing, and never reaches the router')

# The whole of it in both families. A Mikrotik keeps its two address lists
# apart and will not take one in the other's list, so which list an address
# belongs in is read off the address; the name is the same in both.
assert d.mikrotik_family('89.24.5.7') == '/ip'
assert d.mikrotik_family('89.24.5.0/24') == '/ip'
assert d.mikrotik_family('2a01:430:17::5') == '/ipv6'
assert d.mikrotik_family('2a01:430:17::/48') == '/ipv6'
assert d.mikrotik_family('nonsense') is None
zigmon.CONFIG['never_block'] = '2a01:430:17::/48'
d.store.unblock()
d.store.block('2a02:1:2::9', None, 'a stranger on v6')
d.store.block('2a01:430:17::5', None, 'ours')
d.store.block('89.24.5.7', None, 'a stranger on v4')
_marks = {r['ip']: r['spared'] for r in d.blocked_list()}
assert _marks['2a01:430:17::5'] == '2a01:430:17::/48', 'a v6 range does not spare its addresses'
assert not _marks['2a02:1:2::9'] and not _marks['89.24.5.7'], 'it spared somebody else'
assert d.store.blocked_until('2a01:430:17::9') is None, 'a v6 address outside every block was kept out'
d.store.block('2a03:beef::/32', None, 'a v6 street')
assert d.store.blocked_until('2a03:beef::1234') == 0, 'a v6 range keeps nobody out'
assert d.store.blocked_until('2a04:beef::1') is None, 'a v6 range keeps out more than it holds'
_sent[:] = []
d.mikrotik_run = lambda c: (_sent.append(c) or '')
d.mikrotik_sync('a test')
assert any('/ipv6 firewall address-list add' in c and '2a02:1:2::9' in c for c in _sent), \
    'a v6 address was not put in the v6 list'
assert any('/ip firewall address-list add' in c and '89.24.5.7' in c for c in _sent), \
    'a v4 address was not put in the v4 list'
assert not any('2a01:430:17::5' in c for c in _sent), 'a spared v6 address reached the router'
assert any(c.startswith('/ipv6 firewall address-list print') for c in _sent), 'the v6 list is never read'
_lines = d.blocked_mikrotik()
assert any(x.startswith('/ipv6 ') for x in _lines) and any(x.startswith('/ip ') for x in _lines), \
    'the lines to paste know only one family'
assert not any('2a01:430:17::5' in x for x in _lines), 'a spared one is in the lines to paste'
zigmon.CONFIG['never_block'] = ''
d.store.unblock()
print('both families, in their own lists, with ranges and the sparing over each')

# The mark must be right whichever way the router chose to write an address,
# and must say so when the looking itself failed rather than reading as "not
# carried" for ever.
d.store.unblock()
d.store.block('2a01:430:17::5', None, 'v6')
d.store.block('89.24.5.7', None, 'v4')
d.mikrotik_run = lambda c: ('0 list=zigmon address=2A01:0430:17:0000::0005 comment="zigmon: v6"\n'
                            '1 list=zigmon address=89.24.5.7 comment="zigmon: v4"\n'
                            if 'print terse' in c else '')
d.mikrotik_entries()
_marks = {r['ip']: r['router'] for r in d.blocked_list()}
assert _marks['2a01:430:17::5'] == 'yes', 'the same v6 address written two ways read as two'
assert _marks['89.24.5.7'] == 'yes'


def _unreachable(cmd):
    raise RuntimeError('ssh: connect to host r port 22: No route to host')


d.mikrotik_run = _unreachable
d._mikrotik_peek()
assert any(r['router_trouble'] for r in d.blocked_list()), 'a router that cannot be read says nothing'
d.store.set_meta('mikrotik_trouble', '')
d.store.unblock()
print('the mark reads an address as an address, and says when the router could not be read')

# Syncing must be the same on the second run as on the first. A router writes
# an address its own way, and comparing those as letters made every IPv6 entry
# look missing: it was added again every time, and the router answered
# "already have such entry" every time.
d.store.unblock()
d.store.block('2a01:430:17::5', None, 'already there')
d.store.block('89.24.5.7', None, 'already there')
d.store.block('2a02:9:9::1', None, 'new')
_held = {'/ipv6': {'2A01:0430:17:0000::0005'}, '/ip': {'89.24.5.7'}}
_writes = []


def _router(cmd):
    fam = '/ipv6' if cmd.startswith('/ipv6') else '/ip'
    if 'print terse' in cmd:
        return ''.join('%d list=zigmon address=%s comment="zigmon: x"\n' % (i, a)
                       for i, a in enumerate(sorted(_held[fam])))
    _writes.append(cmd)
    found = re.search(r'address=([0-9a-fA-F:.]+)', cmd)
    if 'address-list add' in cmd:
        _held[fam].add(found.group(1).upper() if ':' in found.group(1) else found.group(1))
    else:
        _held[fam] = {a for a in _held[fam] if a.lower() != found.group(1).lower()}
    return ''


d.mikrotik_run = _router
_first = d.mikrotik_sync('first')
assert _first['added'] == 1, 'it added %d, when one was new' % _first['added']
for _again in range(2):
    _writes[:] = []
    _out = d.mikrotik_sync('again')
    assert not _writes, 'a sync with nothing changed wrote %d command(s): %r' % (len(_writes), _writes)
    assert _out['added'] == 0 and _out['removed'] == 0, 'it found work to do twice over: %r' % _out
d.store.unblock()
print('a sync with nothing changed writes nothing, whichever way the router spells an address')

# A Mikrotik keeps an address-list entry as a prefix and prints it as one: an
# address given as 2a01:430:17::5 comes back as 2a01:430:17::5/128. Reading
# that as a range of its own made every IPv6 entry look missing, so it was
# added again on every sync and the router said "already have such entry"
# every time.
assert d.same_address('2a01:430:17::5/128') == '2a01:430:17::5', 'a /128 is not read as one address'
assert d.same_address('89.24.5.7/32') == '89.24.5.7', 'a /32 is not read as one address'
assert d.same_address('89.24.5.0/24') == '89.24.5.0/24', 'a real range was flattened'
assert d.same_address('2a01:430::/48') == '2a01:430::/48'
d.store.unblock()
d.store.block('2a01:430:17::5', None, 'v6')
d.store.block('89.24.5.7', None, 'v4')
_writes = []


def _prefix_router(cmd):
    fam = '/ipv6' if cmd.startswith('/ipv6') else '/ip'
    if 'print terse' in cmd:
        return ('0 list=zigmon address=2A01:430:17::5/128 comment="zigmon: v6"\n' if fam == '/ipv6'
                else '0 list=zigmon address=89.24.5.7 comment="zigmon: v4"\n')
    _writes.append(cmd)
    return ''


d.mikrotik_run = _prefix_router
_out = d.mikrotik_sync('a test')
assert not _writes, 'it wrote to a router that already held everything: %r' % _writes
d.mikrotik_entries()
assert all(r['router'] == 'yes' for r in d.blocked_list()), \
    'an address the router holds as a prefix is marked as missing'
d.store.unblock()
print('an address the router keeps as a /128 is the same address, on the list and on the mark')

# A phrase may name what it catches, and a press may carry named values, so
# one command and one link serve every address rather than one of each per
# address.
assert zigmon.Daemon.phrase_match('unban {ip}', 'unban 1.1.1.1') == {'ip': '1.1.1.1'}
assert zigmon.Daemon.phrase_match('unban {ip}', 'UNBAN 2a01:430::5') == {'ip': '2a01:430::5'}
assert zigmon.Daemon.phrase_match('unban {ip}', 'ban 1.1.1.1') is None, 'it matched another command'
assert zigmon.Daemon.phrase_match('set {room} to {temp}', 'set loznice to 21.5') == \
    {'room': 'loznice', 'temp': '21.5'}
assert zigmon.Daemon.phrase_match('lights', 'lights off') == {}, 'a plain phrase stopped matching'
d.store.set_meta('sms_commands', json.dumps([
    {'phrase': 'unban {ip}', 'do': 'unban', 'target': '{ip}', 'enabled': True,
     'from_anyone': True, 'answer': True},
    {'phrase': 'ban {ip}', 'do': 'ban', 'target': '{ip}', 'enabled': True,
     'from_anyone': True, 'answer': True}]))
zigmon.CONFIG['sms_reply'] = 0
d.store.unblock()
d.store.block('1.1.1.1', None, 'a test')
d.sms_handle('+420123', 'unban 1.1.1.1')
assert not d.blocked_list(), 'a text saying "unban 1.1.1.1" did not let it back in'
d.sms_handle('+420123', 'ban 9.9.9.9')
assert [r['ip'] for r in d.blocked_list()] == ['9.9.9.9'], 'a text saying "ban" did not keep it out'
assert 'not an address' in d.ban_by_name('ban', 'rubbish'), 'it took rubbish for an address'
d.store.unblock()
# and the same by a press carrying the address in a header of its own; the
# links the rest of this file works with are put back afterwards
_was_taps = d.taps()
d.save_taps([{'name': 'Unban', 'target': '{ip}', 'do': 'unban'}])
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 0
d.store.block('1.1.1.1', None, 'a test')
_ok, _answer = d.tap(d.taps()[0]['token'], '1.2.3.4', way='header', carried={'ip': '1.1.1.1'})
assert _ok and 'let back in' in _answer['message'], 'a press carrying an address did nothing: %r' % (_answer,)
assert not d.blocked_list(), 'the address is still kept out'
d.store.set_meta('taps', json.dumps(_was_taps))
print('a phrase catches what it names, and a press carries what it is given')

# The same refusal over and over is one thing that happened, not many. A
# browser asked once will often ask again by itself, and each of those was a
# line of its own and a weight of its own: opening one wrong address twice
# filled the log with ten lines and earned a block.
d.store.flush()                    # anything still on its way to the disk, first
d.store.forget_tap_log()
d.store.unblock()
d._anomaly.clear()
zigmon.CONFIG.update({'tap_mode': 'both', 'blacklist': 1, 'block_score': 15})
for _i in range(6):
    d.tap('one-wrong-secret', '89.24.50.1', way='link')
d.store.flush()
_rows, _m, _t = d.store.tap_log(20)
assert len(_rows) == 1, 'six of the same refusal made %d lines' % len(_rows)
assert _rows[0]['times'] == 6, 'the line does not say how many: %r' % _rows[0]['times']
assert d.store.blocked_until('89.24.50.1') is None, 'a browser retrying earned a block'
assert [c['tries'] for c in d.anomaly_state() if c['ip'] == '89.24.50.1'] == [1], \
    'a retry was weighed as a try of its own'
# six different secrets is a different thing and must stay six lines
d.store.forget_tap_log()
d._anomaly.clear()
for _i in range(6):
    d.tap('wrong-%d' % _i, '89.24.50.2', way='link')
d.store.flush()
_rows, _m, _t = d.store.tap_log(20)
assert len([r for r in _rows if r['who'] == '89.24.50.2']) == 6, \
    'six different secrets were folded into %d line(s)' % len(_rows)
# and a press that works is never folded away
d.store.unblock()
_tok = d.taps()[0]['token']
d.store.forget_tap_log()
for _i in range(3):
    d.tap(_tok, '10.0.0.50', way='link')
d.store.flush()
_rows, _m, _t = d.store.tap_log(20)
assert len([r for r in _rows if r['who'] == '10.0.0.50']) == 3, 'real presses were folded together'
d.store.forget_tap_log()
d.store.unblock()
print('the same refusal repeated is one line saying how many, and weighs once')

# A row may make up names of its own and say where each comes from. They
# belong to that row: one called ip here means nothing on the next line.
_kept = d.save_sms_commands([{'phrase': 'unban', 'do': 'unban', 'target': '{ip}',
                              'reply': 'let {ip} back in', 'from_anyone': True,
                              'vars': [{'name': 'ip', 'from': 'rest', 'note': 'the address'},
                                       {'name': '', 'from': 'x'},        # no name: dropped
                                       {'name': 'ip', 'from': 'again'}]}])  # twice: kept once
assert [v['name'] for v in _kept[0]['vars']] == ['ip'], 'the names were not tidied: %r' % _kept[0]['vars']
assert _kept[0]['do'] == 'unban' and _kept[0]['target'] == '{ip}', 'the action did not survive saving'
zigmon.CONFIG['sms_reply'] = 0
d.store.unblock()
d.store.block('1.1.1.1', None, 'a test')
d.sms_handle('+420123', 'unban 1.1.1.1')
assert not d.blocked_list(), 'a name declared on the row was not caught from the message'
# a name written into the phrase counts as one of them whether or not it was
# written down here as well
_kept = d.save_sms_commands([{'phrase': 'ban {ip}', 'do': 'ban', 'target': '{ip}',
                              'reply': 'kept {ip} out', 'from_anyone': True}])
assert [v['name'] for v in _kept[0]['vars']] == ['ip'], 'a name in the phrase is not one of them'
assert _kept[0]['vars'][0]['from'] == 'phrase'
# and a link may name the header each of its own comes in
d.save_taps([{'name': 'Unban', 'target': '{ip}', 'do': 'unban',
              'vars': [{'name': 'ip', 'from': 'X-Zigmon-Arg-Address'}]}])
d.store.unblock()
d.store.block('2.2.2.2', None, 'a test')
zigmon.CONFIG['tap_mode'] = 'header'
_ok, _answer = d.tap(d.taps()[0]['token'], '1.2.3.4', way='header', carried={'address': '2.2.2.2'})
assert _ok and 'let back in' in _answer['message'], 'a link did not read its name from the header it named'
d.store.unblock()
d.save_sms_commands([])
d.store.set_meta('taps', json.dumps(_was_taps))   # the links the rest of this file works with
zigmon.CONFIG['tap_mode'] = 'both'
print('a row may make up names of its own, and they belong to that row')

# The box beside a name says which part of the message it takes. It said
# nothing at all before, which made it a control that did nothing.
def _caught(vars_, text, phrase='set'):
    _c = {'phrase': phrase, 'vars': [dict(v) for v in vars_]}
    _f = d.sms_facts('+420', text, None, _c)
    return {v['name']: _f.get(v['name']) for v in vars_}


assert _caught([{'name': 'room', 'from': ''}, {'name': 'temp', 'from': ''}], 'set loznice 21.5') == \
    {'room': 'loznice', 'temp': '21.5'}, 'names left empty do not take the words in order'
assert _caught([{'name': 'temp', 'from': '2'}, {'name': 'room', 'from': '1'}], 'set loznice 21.5') == \
    {'temp': '21.5', 'room': 'loznice'}, 'a number does not take that word'
assert _caught([{'name': 'note', 'from': 'all'}], 'set the boiler is loud') == \
    {'note': 'the boiler is loud'}, '"all" does not take everything after the phrase'
assert _caught([{'name': 'x', 'from': '9'}], 'set one') == {'x': ''}, 'a word past the end is not empty'
print('the box beside a name says which part of the message it takes')

# The dashboard meeting its own lock is not somebody trying the handle: a
# reload asks for the views that want the PIN, several times over, and every
# one of those was counted against the address that made it.
d.store.unblock()
d.forget_anomaly()
zigmon.CONFIG.update({'blacklist': 1, 'block_score': 15, 'block_private': 'gently'})
for _i in range(30):
    d.note_anomaly('192.168.40.12', 'locked-read', '/api/blocked')
assert d.store.blocked_until('192.168.40.12') is None, 'reloading the page earned a block'
# and a right PIN forgets whatever was held
d.note_anomaly('192.168.40.12', 'bad-secret', 'x')
assert d.anomaly_state(), 'nothing was held to forget'
d.pin_was_right('192.168.40.12 (says 89.24.5.7)')
assert not [c for c in d.anomaly_state() if c['ip'] == '192.168.40.12'], \
    'the right PIN did not clear what was held against that address'
d.forget_anomaly()
print('the dashboard meeting its own lock costs nothing, and a right PIN clears the slate')

# ...and that has to be true of the road the dashboard actually takes. There
# are two places that refuse a locked read; 3.85.2 took the counting out of
# one of them, and the other is the one the Public API tab meets twice a
# second, so a reload went on filling the owner's own account.
_src = open(str(__file__).rsplit('/', 2)[0] + '/zigmon.py').read()
assert "note_anomaly(self._caller(), 'locked-read'" not in _src, \
    'a locked read is still counted against whoever asked for it'

# A rule does one thing; a script is a name for three. Every line is a plain
# verb and something to act on, checked when it is saved rather than when it
# runs, and the rule's own names are filled in before anything happens.
zigmon.CONFIG.update({'blacklist': 1, 'sms_reply': 0, 'block_mode': 'permanent'})
d.store.unblock()
_kept = d.save_scripts([{'name': 'Keep out', 'body': 'ban {ip} 120\nsay {ip} is kept out'}])
assert len(_kept) == 1 and _kept[0]['id'], 'a script was not kept'
_out = d.run_script(_kept[0], {'ip': '1.2.3.4'}, 'a test')
assert _out['lines'] == 2, 'it ran %d line(s) of two' % _out['lines']
assert '1.2.3.4' in _out['said'], 'the names were not filled in: %r' % _out['said']
_row = [r for r in d.blocked_list() if r['ip'] == '1.2.3.4'][0]
assert not _row['forever'] and 100 * 60 < _row['left'] <= 120 * 60, \
    'the number of minutes on the line was not used: %r' % _row
# a line that cannot work is refused while somebody is looking at it
for _bad in ('fly to the moon', 'set', 'on', 'ban'):
    try:
        d.save_scripts([{'name': 'X', 'body': _bad}])
        raise AssertionError('%r was accepted as a line' % _bad)
    except ValueError:
        pass
# and a command may point at one, catching what it needs from the message
d.save_scripts(_kept)
d.store.unblock()
d.save_sms_commands([{'phrase': 'block', 'target': 'script:' + _kept[0]['id'], 'do': 'script',
                      'from_anyone': True, 'vars': [{'name': 'ip', 'from': 'rest'}]}])
_saved = d.sms_commands()[0]
assert _saved['do'] == 'script' and _saved['target'].startswith('script:'), \
    'a script did not survive being saved as an action: %r' % _saved
d.sms_handle('+420123', 'block 89.24.5.7')
assert [r['ip'] for r in d.blocked_list()] == ['89.24.5.7'], 'the script did not run for the message'
d.save_sms_commands([])
d.save_scripts([])
d.store.unblock()
print('a script is a name for three things, checked when it is saved and run with the rule\'s names')

# A script says which names it expects, and a name that stands for nothing is
# said plainly rather than leaving a hole in the middle of a line: "ban {ip}
# 120" with no address would otherwise read as "ban 120".
_kept = d.save_scripts([{'name': 'Ban', 'body': 'ban {myip} 120\nsay {myip} is kept out\nsay always'}])
assert d.scripts()[0]['wants'] == ['myip'], 'it does not say what it wants: %r' % d.scripts()[0]
_said = d.run_script(d.scripts()[0], {}, 'a test')['said']
assert 'stood for nothing' in _said, 'a name standing for nothing was not said: %r' % _said
assert 'is not an address' not in _said, 'it tried to act on what was left of the line'
assert 'always' in _said, 'a line needing no name was skipped too'
_said = d.run_script(d.scripts()[0], {'myip': '9.9.9.9'}, 'a test')['said']
assert '9.9.9.9 is kept out for 120 min' in _said, 'given a value it did not use it: %r' % _said
d.save_scripts([])
d.store.unblock()
print('a script says which names it wants, and says so when one stands for nothing')

# A script says which names it wants, and a rule that declared none still
# gives them: the words after the phrase are handed over in order. Declaring
# one is a way of being particular, not a thing to remember before anything
# works at all.
zigmon.CONFIG.update({'blacklist': 1, 'sms_reply': 0})
_k = d.save_scripts([{'name': 'Ban', 'body': 'ban {myip}\nsay banned {myip}'}])
d.save_sms_commands([{'phrase': 'ban', 'target': 'script:' + _k[0]['id'], 'do': 'script',
                      'from_anyone': True}])
d.store.unblock()
d.sms_handle('+420123', 'ban 1.2.3.4')
assert [r['ip'] for r in d.blocked_list()] == ['1.2.3.4'], \
    'a script got nothing from a command that declared nothing'
d.store.unblock()
d.save_sms_commands([{'phrase': 'ban', 'target': 'script:' + _k[0]['id'], 'do': 'script',
                      'from_anyone': True, 'vars': [{'name': 'myip', 'from': ''}]}])
d.sms_handle('+420123', 'ban 5.6.7.8')
assert [r['ip'] for r in d.blocked_list()] == ['5.6.7.8'], 'a declared name was not used'
d.store.unblock()
d.save_sms_commands([{'phrase': 'ban', 'target': 'script:' + _k[0]['id'], 'do': 'script',
                      'from_anyone': True}])
d.sms_handle('+420123', 'ban')
assert not d.blocked_list(), 'a message with nothing in it kept somebody out'
# and a press does the same with what it carried
d.save_taps([{'name': 'Ban', 'target': 'script:' + _k[0]['id'], 'do': 'script'}])
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 0
_ok, _answer = d.tap(d.taps()[0]['token'], '1.2.3.4', way='header', carried={'address': '7.7.7.7'})
assert [r['ip'] for r in d.blocked_list()] == ['7.7.7.7'], \
    'a press carrying one value did not fill the name the script wanted: %r' % (_answer,)
d.store.set_meta('taps', json.dumps(_was_taps))
zigmon.CONFIG['tap_mode'] = 'both'
d.save_sms_commands([])
d.save_scripts([])
d.store.unblock()
print('a script is given the names it wants, declared or not')

# The whole matrix, both roads: a name written into the phrase, one declared
# in order, one declared as a word by number, one taking everything after the
# phrase, one declared nowhere at all, two at once - and the same by a press,
# named after the header, reading another header, or taken from whatever the
# press carried.
zigmon.CONFIG.update({'blacklist': 1, 'sms_reply': 1, 'tap_mode': 'header', 'tap_code': 0})
_sent = []
_was_send = d.sms_send
d.sms_send = lambda to, text, why='': _sent.append(text)


def _by_text(body, command, text):
    _made = d.save_scripts([{'name': 'S', 'body': body}])
    d.save_sms_commands([dict(command, target='script:' + _made[0]['id'], do='script',
                              from_anyone=True)])
    d.store.unblock()
    del _sent[:]
    d.sms_handle('+420123', text)
    return [r['ip'] for r in d.blocked_list()], (_sent[-1] if _sent else '')


assert _by_text('ban {ip}', {'phrase': 'ban {ip}'}, 'ban 1.1.1.1')[0] == ['1.1.1.1'], 'a name in the phrase'
assert _by_text('ban {ip}', {'phrase': 'ban', 'vars': [{'name': 'ip', 'from': ''}]},
                'ban 2.2.2.2')[0] == ['2.2.2.2'], 'a name declared in order'
assert _by_text('ban {ip}', {'phrase': 'ban', 'vars': [{'name': 'ip', 'from': '2'}]},
                'ban now 3.3.3.3')[0] == ['3.3.3.3'], 'a name declared as the second word'
assert 'the gate is loud' in _by_text('say note: {note}',
                                      {'phrase': 'note', 'vars': [{'name': 'note', 'from': 'all'}]},
                                      'note the gate is loud')[1], 'a name taking everything after'
assert _by_text('ban {ip}', {'phrase': 'ban'}, 'ban 4.4.4.4')[0] == ['4.4.4.4'], 'nothing declared'
assert _by_text('ban {ip} {mins}', {'phrase': 'ban'}, 'ban 5.5.5.5 15')[0] == ['5.5.5.5'], 'two names'
_kept, _said = _by_text('ban {ip}', {'phrase': 'ban', 'reply': 'Banned {ip}'}, 'ban 6.6.6.6')
assert _said == 'Banned 6.6.6.6', 'a command with its own answer did not get to say it: %r' % _said
d.sms_send = _was_send


def _by_press(body, taps_vars, carried):
    _made = d.save_scripts([{'name': 'S', 'body': body}])
    d.save_taps([dict({'name': 'L', 'target': 'script:' + _made[0]['id'], 'do': 'script'},
                      vars=taps_vars)])
    d.store.unblock()
    _ok, _answer = d.tap(d.taps()[0]['token'], '1.2.3.4', way='header', carried=carried)
    return [r['ip'] for r in d.blocked_list()], (_answer.get('message') or '')


assert _by_press('ban {ip}', [], {'ip': '8.8.8.8'})[0] == ['8.8.8.8'], 'a header named like the name'
assert _by_press('ban {ip}', [{'name': 'ip', 'from': 'X-Zigmon-Arg-Address'}],
                 {'address': '9.9.9.9'})[0] == ['9.9.9.9'], 'a name reading another header'
assert _by_press('ban {ip}', [], {'whatever': '10.10.10.10'})[0] == ['10.10.10.10'], \
    'a press carrying one value, named nothing'
assert _by_press('ban {ip} {mins}', [], {'ip': '11.11.11.11', 'mins': '5'})[0] == ['11.11.11.11'], \
    'two names carried by a press'
assert 'Loznice' in _by_press('say it is {room}', [], {'room': 'Loznice'})[1], \
    'a name in a report a press asked for'
d.store.set_meta('taps', json.dumps(_was_taps))
zigmon.CONFIG['tap_mode'] = 'both'
d.save_sms_commands([])
d.save_scripts([])
d.store.unblock()
print('every way a name can arrive, by text and by press, fills what the script asks for')

# An answer written by hand says what was meant to happen; it must not be
# allowed to say it over the top of a line that did not happen. And a line
# naming something that is not here switched nothing while saying nothing,
# which reads exactly like a script that did its work.
_sent = []
_was_send = d.sms_send
d.sms_send = lambda to, text, why='': _sent.append(text)
zigmon.CONFIG.update({'sms_reply': 1, 'blacklist': 1})
_made = d.save_scripts([{'name': 'Ban', 'body': 'ban {myip}'}])
d.save_sms_commands([{'phrase': 'ban', 'target': 'script:' + _made[0]['id'], 'do': 'script',
                      'reply': 'Banned {myip}', 'from_anyone': True}])
d.store.unblock()
del _sent[:]
d.sms_handle('+420123', 'ban')
assert 'stood for nothing' in _sent[-1], 'the answer hid a line that did not happen: %r' % _sent[-1]
del _sent[:]
d.sms_handle('+420123', 'ban 1.2.3.4')
assert _sent[-1] == 'Banned 1.2.3.4', 'a line that worked was talked over: %r' % _sent[-1]
assert [r['ip'] for r in d.blocked_list()] == ['1.2.3.4']
# something that is not here, refused while somebody is looking at it
try:
    d.save_scripts([{'name': 'X', 'body': 'on No-Such-Plug'}])
    raise AssertionError('a line naming nothing real was accepted')
except ValueError as e:
    assert 'nothing here called' in str(e), str(e)
# ...and refused at the moment it runs, when the name came from the message
_made = d.save_scripts([{'name': 'X', 'body': 'on {thing}'}])
d.save_sms_commands([{'phrase': 'go', 'target': 'script:' + _made[0]['id'], 'do': 'script',
                      'reply': 'Done', 'from_anyone': True}])
del _sent[:]
d.sms_handle('+420123', 'go No-Such-Plug')
assert 'nothing here called' in _sent[-1], 'switching nothing said nothing: %r' % _sent[-1]
d.sms_send = _was_send
d.save_sms_commands([])
d.save_scripts([])
d.store.unblock()
print('an answer cannot talk over a line that did not happen')

# A script with nothing in it did nothing and said nothing, and an answer
# written by hand went back as though it had worked. It says so now, which is
# the difference between "it did not work" and "nothing happened and nobody
# will tell you why".
_sent = []
_was_send = d.sms_send
d.sms_send = lambda to, text, why='': _sent.append(text)
zigmon.CONFIG.update({'sms_reply': 1, 'blacklist': 1})
_made = d.save_scripts([{'name': 'Ban', 'body': ''}])
d.save_sms_commands([{'phrase': 'ban', 'target': 'script:' + _made[0]['id'], 'do': 'script',
                      'reply': 'Banned {myip}', 'from_anyone': True}])
d.store.unblock()
del _sent[:]
d.sms_handle('+420123', 'ban 1.2.3.4')
assert 'no lines in it' in _sent[-1], 'an empty script said nothing about itself: %r' % _sent[-1]
assert not d.blocked_list(), 'an empty script kept somebody out'
d.sms_send = _was_send
d.save_sms_commands([])
d.save_scripts([])
print('a script with nothing in it says so instead of looking like one that worked')

# {myip) is not a name, it is a name with the wrong bracket on the end - and
# it reads as ordinary words, so the line acts on the characters themselves
# and answers "{myip) is not an address".
for _typo in ('ban {myip)', 'ban {myip', 'unban {ip]'):
    try:
        d.save_scripts([{'name': 'X', 'body': _typo}])
        raise AssertionError('%r was accepted as a line' % _typo)
    except ValueError as e:
        assert 'name ends with }' in str(e) or 'without its }' in str(e), str(e)
d.save_scripts([{'name': 'X', 'body': 'say hello (world)'}])       # ordinary brackets are fine
d.save_scripts([])
print('a name closed with the wrong bracket is refused, not acted on')

# A script runs on the thread that asked for it, so the waiting in the whole
# of it is capped rather than only the waiting on one line: five lines of
# "wait 30" held a press for two and a half minutes.
_made = d.save_scripts([{'name': 'W', 'body': '\n'.join(['wait 30'] * 5)}])
_began = time.time()
_out = d.run_script(_made[0], {}, 'a test')
assert time.time() - _began < 40, 'a script slept for %.0f s' % (time.time() - _began)
assert 'may not sleep longer' in _out['said'], 'it slept less and said nothing about it'

# And a name filled in from outside may not stand for what the house does to
# itself: "on {thing}" with a command anybody may text would otherwise let a
# stranger name sys:reboot.
_fired = []
_was_fire, _was_valid = d._fire_target, d._valid_target
d._fire_target = lambda target, do, origin, **k: _fired.append((target, do))
d._valid_target = lambda t: True
_made = d.save_scripts([{'name': 'X', 'body': 'on {thing}'}])
d.save_sms_commands([{'phrase': 'go', 'target': 'script:' + _made[0]['id'], 'do': 'script',
                      'from_anyone': True}])
for _bad in ('go sys:reboot', 'go act:1', 'go rule:2', 'go script:abc'):
    del _fired[:]
    d.sms_handle('+420999', _bad)
    assert not _fired, '%r reached %r' % (_bad, _fired)
del _fired[:]
d.sms_handle('+420999', 'go Plug-UPS')
assert _fired == [('Plug-UPS', 'on')], 'an ordinary name stopped working: %r' % _fired
# written out by the person who wrote the script, it is allowed
del _fired[:]
d.run_script(d.save_scripts([{'name': 'Y', 'body': 'on sys:reboot'}])[0], {}, 'a test')
assert _fired == [('sys:reboot', 'on')], 'a line written out by hand was refused'
d._fire_target, d._valid_target = _was_fire, _was_valid
d.save_sms_commands([])
d.save_scripts([])
print('a script cannot be made to sleep for ever, or to name the house itself from a message')

# The blocked list is drawn once a second while the tab is open, and what is
# written under "never kept out" was read afresh for every address on it: five
# hundred against thirty ranges came to three hundred thousand parses.
zigmon.CONFIG['never_block'] = ', '.join('192.168.%d.0/24' % i for i in range(30))
d.store.unblock()
for _i in range(300):
    d.store.block('10.%d.%d.%d' % (_i // 255, _i % 255, _i % 7), time.time() + 3600, 'a test')
d.store.block('192.168.5.9', None, 'in a spared street')
d.store.flush()
_began = time.time()
for _ in range(10):
    _rows = d.blocked_list()
_each = (time.time() - _began) / 10 * 1000
assert _each < 25, 'the blocked list takes %.0f ms to draw' % _each
_marks = {r['ip']: r['spared'] for r in _rows}
assert _marks['192.168.5.9'] == '192.168.5.0/24', 'and it stopped sparing the right ones'
assert not _marks['10.0.0.0'], 'it spared one it should not'
# and it follows the setting when that changes
zigmon.CONFIG['never_block'] = '10.0.0.0'
_marks = {r['ip']: r['spared'] for r in d.blocked_list()}
assert _marks['10.0.0.0'] == '10.0.0.0' and not _marks['192.168.5.9'], \
    'the list it reads is remembered past the setting being changed'
zigmon.CONFIG['never_block'] = ''
d.store.unblock()
print('the blocked list is drawn in a few milliseconds, and still spares what it should')

# A phrase is built into a pattern, so a phrase somebody writes badly must not
# be able to stop every message being read.
assert zigmon.Daemon.phrase_match('{ip}{ip}', 'unban aa') is None, 'a repeated name raised'
assert zigmon.Daemon.phrase_match('set {x} to {x}', 'set 5 to 5') == {'x': '5'}, \
    'a name mentioned twice does not match what it caught'
assert zigmon.Daemon.phrase_match('set {x} to {x}', 'set 5 to 6') is None, \
    'a name mentioned twice matched two different things'
assert zigmon.Daemon.phrase_match('[', 'x') is None, 'a phrase that is not a pattern raised'
assert zigmon.Daemon.phrase_match('(a+)+$', 'a' * 40) is None
print('a badly written phrase answers no and stops nothing')

# What a press carries is held to a size and to a name, on every road: a value
# is a room name or an address, not a book.
d.save_taps([{'name': 'Say', 'target': 'tell', 'do': 'own', 'text': '{room}'}])
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 0
_ok, _answer = d.tap(d.taps()[0]['token'], '1.2.3.4', way='header',
                     carried={'room': 'x' * 5000, 'a' * 300: 'y', '../x': 'z', '': 'w'})
assert len(_answer.get('message') or '') <= 220, \
    'a press carried %d characters into a report' % len(_answer.get('message') or '')
d.store.set_meta('taps', json.dumps(_was_taps))
zigmon.CONFIG['tap_mode'] = 'both'
print('what a press carries is held to a name and to a size')

# The whole of it can be switched off. The addresses are kept - a house that
# turns it off for an afternoon should not have to write them out again - but
# nothing is enforced, and nothing of ours may be left on the router: a rule
# there that outlives the thing that made it is a rule nobody can explain.
d.store.unblock()
zigmon.CONFIG['blacklist'] = 1
d.store.block('89.24.9.9', None, 'a test', auto=False)
assert d.blacklist_on() and d.store.blocked_until('89.24.9.9') == 0
zigmon.CONFIG['blacklist'] = 0
assert not d.blacklist_on(), 'the switch does nothing'
assert len(d.store.blocked_all()) == 1, 'switching it off threw the addresses away'
_sent[:] = []
try:
    d.mikrotik_sync('while off')
    raise AssertionError('it filled the router while switched off')
except ValueError:
    pass
zigmon.CONFIG['blacklist'] = 1
print('the blacklist can be switched off without losing what it holds')

# A range, written the usual way: one line keeping out a street rather than
# thirty keeping out its houses.
d.store.unblock()
d.store.block('89.24.5.0/24', None, 'a street')
assert d.store.blocked_until('89.24.5.77') == 0, 'an address inside a blocked range was let through'
assert d.store.blocked_until('89.24.6.77') is None, 'an address outside it was kept out'
print('a range keeps out every address in it, and nothing outside it')

# A temporary one runs out by itself and goes into the history, which keeps
# every address that was ever kept out.
d.store.unblock()
d.store.forget_blocked_history()
d.store.block('1.2.3.4', time.time() + 1, 'briefly')
assert d.store.blocked_until('1.2.3.4') is not None
time.sleep(1.2)
assert d.store.blocked_until('1.2.3.4') is None, 'a block that ran out still keeps somebody out'
_past = d.store.blocked_history()
assert [(h['ip'], h['how']) for h in _past] == [('1.2.3.4', 'ran out')], 'it is not in the history: %r' % _past
d.store.block('1.2.3.5', None, 'by hand', auto=False)
d.store.unblock('1.2.3.5')
assert any(h['ip'] == '1.2.3.5' and h['how'] == 'taken off' for h in d.store.blocked_history())
assert d.store.forget_blocked_history() >= 2 and not d.store.blocked_history(), \
    'the history could not be erased'
print('a block that runs out goes into a history that keeps all of them')

# ...whether or not anybody asks about that address again. It used to happen
# only when the address itself came back, so a line sat on the list for ever
# saying "0 min" while the router had already dropped its own rule by timeout.
d.store.unblock()
d.store.forget_blocked_history()
d.store.block('1.1.1.1', time.time() + 1, 'briefly', auto=False)
d.store.block('2.2.2.2', None, 'for good', auto=False)
time.sleep(1.3)
_left = [r['ip'] for r in d.blocked_list()]
assert _left == ['2.2.2.2'], 'one whose time ran out is still on the list: %r' % _left
assert any(h['ip'] == '1.1.1.1' and h['what'] == 'let back in' and h['why'] == 'ran out'
           for h in d.store.block_events(10)[0]), 'nothing was written down about it running out'
d.store.unblock()
print('a block whose time runs out leaves the list without being asked about')

# Nothing trimmed the press log or the story of an address: a link open to the
# internet writes a line for every press and every refusal, and a year of that
# is a table nobody asked for.
_old = time.time() - 200 * 86400
d.store.flush()
d.store.forget_tap_log()
d.store.forget_blocked_history()
with d.store.lock:
    for _i in range(20):
        d.store.db.execute(
            'INSERT INTO taps_log (ts,ticket,link,who,way,state,message,times) '
            'VALUES (?,?,?,?,?,?,?,1)', (_old, 'old%d' % _i, 'L', '1.1.1.1', 'x', 'done', 'ok'))
        d.store.db.execute('INSERT INTO block_events (ts,ip,what,why,auto,by) VALUES (?,?,?,?,1,"")',
                           (_old, '1.1.1.%d' % _i, 'blocked', 'old'))
    d.store.db.commit()
d.store.log_tap({'ts': time.time(), 'ticket': 'new', 'link': 'L', 'who': '1.1.1.1', 'way': 'x',
                 'state': 'done', 'message': 'ok'})
d.store.note_block_event('9.9.9.9', 'blocked', 'today')
d.store.flush()
assert d.store.tap_log(1)[2] == 21 and d.store.block_events(1)[2] == 21, 'the rows were not written'
zigmon.CONFIG['retain_presses_days'] = 180
d.store.aggregate()
d.store.flush()
assert d.store.tap_log(1)[2] == 1, 'old presses are kept for ever: %d left' % d.store.tap_log(1)[2]
assert d.store.block_events(1)[2] == 1, 'the story of an address is kept for ever'
d.store.forget_tap_log()
d.store.forget_blocked_history()
print('the press log and the story of an address are trimmed with everything else')

# And it is a log, not a summary: a block and the letting go of it are two
# things at two times, each on its own line, in the order they happened -
# whether the letting go was the clock or a person.
d.store.unblock()
d.store.forget_blocked_history()
d.store.block('89.24.40.1', time.time() + 1, 'three wrong secrets', auto=True)
d.store.block('10.0.0.5', None, 'by hand', auto=False, by='me')
time.sleep(1.2)
d.store.blocked_until('89.24.40.1')                 # lets it run out
d.store.unblock('10.0.0.5')
d.store.flush()
_story, _matched, _total = d.store.block_events(50)
assert _total >= 4, 'four things happened and %d were written down' % _total
assert [r['ts'] for r in _story] == sorted([r['ts'] for r in _story], reverse=True), \
    'the log is not in the order it happened'
_kinds = {(r['ip'], r['what'], r['why']) for r in _story}
assert ('89.24.40.1', 'blocked', 'three wrong secrets') in _kinds
assert ('89.24.40.1', 'let back in', 'ran out') in _kinds, 'a block running out is not a line of its own'
assert ('10.0.0.5', 'let back in', 'taken off') in _kinds, 'letting one back in is not a line of its own'
assert any(r['ip'] == '10.0.0.5' and r['what'] == 'blocked' and not r['auto'] for r in _story), \
    'it does not say a person did it'
_found, _m, _t = d.store.block_events(50, '10.0.0.5')
assert _m == 2 and all(r['ip'] == '10.0.0.5' for r in _found), 'searching the log found the wrong lines'
d.store.forget_blocked_history()
print('every block and every letting go is a line of its own, and can be searched')

# How keen it is moves the bar, and nothing else about it.
for _lean, _blocked in (('forgiving', False), ('normal', True), ('keen', True)):
    zigmon.CONFIG['block_sensitivity'] = _lean
    d.store.unblock()
    d._anomaly.clear()
    for _i in range(3):
        d.note_anomaly('77.0.0.1', 'bad-secret', 'link %d' % _i)
    assert (d.store.blocked_until('77.0.0.1') is not None) is _blocked, \
        'three wrong secrets with %s did the wrong thing' % _lean
zigmon.CONFIG['block_sensitivity'] = 'normal'
d.store.unblock()
print('forgiving asks for more than normal, and keen for less')

# What was tried, not how many times it was tried. One wrong secret over and
# over is a shortcut nobody rewrote; a dozen different ones is somebody
# working through a list, and the second must not have to wait as long.
zigmon.CONFIG.update({'block_mode': 'temporary', 'block_score': 15, 'block_sensitivity': 'normal',
                      'tap_mode': 'both', 'block_private': 'gently'})


def _tries(ip, n, same=True):
    """n tries, as a person makes them - far enough apart that they are not
    taken for one browser asking twice."""
    d._anomaly.pop(ip, None)
    d.store.unblock(ip)
    was, zigmon.Daemon.SAME_TRY_WITHIN = zigmon.Daemon.SAME_TRY_WITHIN, 0
    try:
        for _i in range(n):
            d.tap('wrong-secret' if same else 'wrong-secret-%d' % _i, ip, way='link')
    finally:
        zigmon.Daemon.SAME_TRY_WITHIN = was
    return d.store.blocked_until(ip) is not None


assert _tries('89.24.30.1', 2, same=False) is False, 'two tries from a stranger is already a block'
assert _tries('89.24.30.2', 3, same=False) is True, 'three different secrets were let by'
# the house has to try three times as hard, and is never shut out for good
assert _tries('192.168.40.12', 4) is False, 'four from the house is a block'
assert _tries('192.168.40.12', 15) is True, 'fifteen refusals from one address were let by'
assert d.store.blocked_until('192.168.40.12') > time.time(), 'the house was blocked for good'
zigmon.CONFIG['block_private'] = 'never'
assert _tries('192.168.40.12', 15) is False, '"never" still blocked the house'
zigmon.CONFIG['block_private'] = 'same'
assert _tries('192.168.40.12', 3, same=False) is True, '"same" did not treat the house as anybody'
zigmon.CONFIG['block_private'] = 'gently'
d.store.unblock()
print('a stale shortcut is told from somebody working through a list')

# And why a block was earned, said in words. "3 in 10 min: bad-secret" is what
# the daemon thinks; what somebody reading the list wants is what was done.
d.store.unblock()
d._anomaly.pop('89.24.32.1', None)
for _i in range(4):
    d.tap('nope-%d' % _i, '89.24.32.1', way='link')
_why = [r['why'] for r in d.blocked_list() if r['ip'] == '89.24.32.1'][0]
assert 'bad-secret' not in _why, 'the shorthand is still on the line: %s' % _why
assert 'a secret that opens nothing' in _why, 'it does not say what was done: %s' % _why
assert 'different ones' in _why, 'it does not say they were different: %s' % _why
d.store.unblock()
d._anomaly.pop('89.24.32.2', None)
zigmon.Daemon.SAME_TRY_WITHIN = 0          # four tries, not one browser asking four times
for _i in range(4):
    d.tap('the-same', '89.24.32.2', way='link')
zigmon.Daemon.SAME_TRY_WITHIN = 2.0
_why = [r['why'] for r in d.blocked_list() if r['ip'] == '89.24.32.2'][0]
assert 'the same one each time' in _why, 'it does not tell one secret from many: %s' % _why
d.store.unblock()
print('a block says in words what earned it')

# What an address has on its account is counted whether or not anybody is
# looking, and letting somebody back in while that weight still stood meant
# the next thing they did put them straight back on the list.
d.store.unblock()
d._anomaly.pop('89.24.33.1', None)
for _i in range(3):
    d.tap('nope-%d' % _i, '89.24.33.1', way='link')
assert d.store.blocked_until('89.24.33.1') is not None, 'three tries did not earn a block'
_watch = [c for c in d.anomaly_state() if c['ip'] == '89.24.33.1']
assert _watch and _watch[0]['score'] >= _watch[0]['bar'], 'the counter says nothing: %r' % _watch
assert _watch[0]['kinds'] and _watch[0]['kinds'][0]['words'], 'it does not say what it counted'
# taken off, and what it did taken off with it
d.ban_by_name('unban', '89.24.33.1', 'a test')
assert not [c for c in d.anomaly_state() if c['ip'] == '89.24.33.1'], \
    'letting one back in kept the weight against it'
d.tap('nope-again', '89.24.33.1', way='link')
assert d.store.blocked_until('89.24.33.1') is None, \
    'one try after being let back in put it straight back on the list'
# and the counter can be forgotten on its own, without letting anybody off
d._anomaly.pop('89.24.33.2', None)
d.tap('nope', '89.24.33.2', way='link')
assert d.forget_anomaly('89.24.33.2') == 1
assert not [c for c in d.anomaly_state() if c['ip'] == '89.24.33.2']
d.store.unblock()
print('what an address has on its account can be seen, and is forgotten when it is let back in')

# The same counting whichever way the house is set to be opened: by address,
# by a header, with a code, with Duo. A secret that opens nothing is a secret
# that opens nothing.
for _mode, _factor in (('link', 'totp'), ('header', 'totp'), ('header', 'duo')):
    zigmon.CONFIG['tap_mode'] = _mode
    zigmon.CONFIG['tap_factor'] = _factor
    d._anomaly.pop('89.24.31.1', None)
    d.store.unblock('89.24.31.1')
    for _i in range(3):
        d.tap('nothing-%d' % _i, '89.24.31.1', way='header' if _mode == 'header' else 'link')
    assert d.store.blocked_until('89.24.31.1') is not None, \
        'three wrong secrets were let by with mode=%s factor=%s' % (_mode, _factor)
d.store.unblock()
zigmon.CONFIG['tap_mode'] = 'both'
print('the same counting whichever road and whatever second factor is set')
d.store.unblock()

# One link, one question at a time. A secret that has leaked can be pressed as
# fast as the network allows, and every press would be a push at somebody's
# phone and a request held open here waiting for an answer: the phone made
# unusable and the web server's workers with it, by somebody who has to be
# right about nothing but the secret.
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'duo'
zigmon.CONFIG.update({'duo_host': 'h', 'duo_ikey': 'i', 'duo_skey': 's', 'duo_user': 'u'})
_asked = []


def _slow(what, who=''):
    _asked.append(time.time())
    time.sleep(0.8)
    return True, 'approved'


d.duo_push = _slow
_tickets = [d.tap(token, '1.2.3.4', way='header')[1]['ticket'] for _ in range(20)]
assert len(set(_tickets)) == 1, 'twenty presses started %d questions' % len(set(_tickets))
time.sleep(1.2)
assert len(_asked) == 1, 'the phone was pushed %d times for one press' % len(_asked)
assert d.tap_waiting(_tickets[0], 3)[1]['state'] == 'done', 'the one question never finished'
print('a link pressed twenty times over asks once, and holds one request open')

# Each held request is a connection here and a web server worker with it, and
# there are only so many of those. Past the ceiling a press is answered at
# once with its ticket, and whoever wants the outcome comes back for it; the
# press itself is unaffected, since it is already asked.
_was_ceiling = d.HOLD_AT_ONCE
d.HOLD_AT_ONCE = 2
assert d.may_hold() and d.may_hold(), 'the first two were not let through'
assert not d.may_hold(), 'the ceiling did not hold'
d.let_go()
assert d.may_hold(), 'letting one go did not make room'
d.let_go(); d.let_go()
d.HOLD_AT_ONCE = _was_ceiling
print('only so many requests are held at once, and the rest are answered at once')

# Calling one off is not undoing it - nothing has happened yet. It tells the
# press that nobody is going to answer, so an approval arriving half a minute
# later finds it called off and does nothing.
_acted = []
d.duo_push = lambda what, who='': (time.sleep(0.6) or (True, 'approved'))
_real_do = d.tap_do
d.tap_do = lambda found, **kw: (_acted.append(found['name']) or (True, {'message': 'done'}))
_ok, _answer = d.tap(token, '1.2.3.4', way='header')
_ticket = _answer['ticket']
_seen = [x for x in d.approvals()['waiting'] if x['ticket'] == _ticket]
assert _seen, 'a press waiting to be approved is not on the list'
assert _seen[0]['link'] and _seen[0]['what'] and _seen[0]['left'] > 0, \
    'the list does not say what it would do or how long it has: %r' % (_seen[0],)
assert d.approval_stop(_ticket, who='the dashboard') == [_seen[0]['link']], 'it was not called off'
assert d.tap_waiting(_ticket, 1)[1]['state'] == 'stopped', 'the shortcut was not told'
time.sleep(1.0)
assert not _acted, 'the approval arrived afterwards and the thing happened anyway'
assert any(x['ticket'] == _ticket and x['state'] == 'stopped' for x in d.approvals()['recent']), \
    'it is not in what became of them'
d.tap_do = _real_do
print('a press can be called off, and an approval arriving after that does nothing')

# What a link does, said the way the rest of the page says it. A link that
# tells you something does not "own tell" anything: the two halves of its
# record are a target and an action, and read straight out they make nonsense
# of the one kind of link whose target is not a thing at all.
assert d.tap_words({'target': 'tell', 'do': 'house'}).startswith('tell you '), \
    'a telling link reads as nonsense: %r' % d.tap_words({'target': 'tell', 'do': 'house'})
assert 'own tell' not in d.tap_words({'target': 'tell', 'do': 'own'})
# and the device by the name Duo shows, not by the twenty letters of its id
d.store.set_meta('duo_devices', __import__('json').dumps(
    [{'device': 'DPQDHZC82JJ1TL6F00EB', 'name': 'iPhone16', 'capabilities': ['push']}]))
assert d.duo_device_name('DPQDHZC82JJ1TL6F00EB') == 'iPhone16', 'the device is shown by its id'
assert d.duo_device_name('auto') == '' and d.duo_device_name('DPNOSUCH') == 'DPNOSUCH'
print('a waiting press says what it would do and which device was rung, in words')

# The finished ones can be thrown away like any other recorded thing; what is
# still waiting is left alone, having not become anything yet.
d.duo_push = lambda what, who='': (time.sleep(5) or (True, 'approved'))
d.tap(token, '1.2.3.4', way='header')
_before = len(d.approvals()['waiting'])
assert d.approvals_forget() >= 0
assert len(d.approvals()['waiting']) == _before, 'erasing the history took a waiting press with it'
assert not d.approvals()['recent'], 'the history was not erased'
d.approval_stop(None)
print('the record of the finished ones can be erased, and the waiting ones are left')

# Every press is written down, not only the ones that wait for somebody: the
# list is worth looking at only if what is not in it did not happen. And it is
# in the database, so a restart does not lose it.
d.store.forget_tap_log()
zigmon.CONFIG['tap_mode'] = 'both'
zigmon.CONFIG['tap_code'] = 0
d.tap(token, '192.168.40.170', way='link')
d.tap(token, '192.168.40.170', way='header')
d.tap(token, '192.168.40.170', way='link', ask=True)
d.tap('not-a-real-token', '89.24.5.7', way='header')
d.store.flush()
_rows = d.approvals()['recent']
assert len(_rows) >= 4, 'four presses were written down as %d' % len(_rows)
_roads = {r['way'] for r in _rows}
assert _roads == {'by its address', 'by a header'}, 'the road is not said: %r' % _roads
assert any(r['state'] == 'refused' for r in _rows), 'a refused press is not in the list'
assert any(r['state'] == 'asked' for r in _rows), 'a press that only asked is not in the list'
assert all('none' in r['factor'] for r in _rows[:4]), 'it claims something checked these: %r' % _rows[0]
# the same through a code, and through Duo
zigmon.CONFIG['tap_mode'] = 'header'
zigmon.CONFIG['tap_code'] = 1
zigmon.CONFIG['tap_factor'] = 'totp'
d.tap(token, '10.0.0.2', way='header', code='000000')
zigmon.CONFIG['tap_factor'] = 'duo'
d.duo_push = lambda what, who='': (time.sleep(0.3) or (True, 'approved'))
d.tap(token, '10.0.0.2', way='header')
time.sleep(0.9)
d.store.flush()
_by = {r['factor'] for r in d.approvals()['recent']}
assert 'a code' in _by and 'Duo' in _by, 'what checked a press is not said: %r' % _by
assert len([r for r in d.approvals()['recent'] if r['state'] == 'done' and r['factor'] == 'Duo']) == 1, \
    'one press approved through Duo was written down twice'
# and it survives a restart, because it is in the database and not in memory
_kept = len(d.store.tap_log(500)[0])
d._waiting.clear()
assert len(d.approvals(500)['recent']) == _kept, 'the list lives in memory and would not survive a restart'
# and it is searched in the database rather than on the page
assert d.approvals(500, 'refused')['matched'] <= d.approvals(500)['matched'], 'the search widened it'
assert all(r['state'] == 'refused' for r in d.approvals(500, '', 'refused')['recent']), \
    'filtering by how it ended let something else through'
assert d.approvals(500)['total'] >= _kept, 'it does not say how many there are in all'
assert d.approvals_forget() == _kept and not d.approvals()['recent'], 'it could not be erased'
print('every press is written down with its road and what checked it, and it keeps')

# -- what the web server does with the address --------------------------------
# The address is the same for every link and carries no secret, so opening it
# in a browser - the first thing anybody does to see whether it is there - must
# be answered rather than refused. A bare 403 from nginx says nothing about
# why, and that is what it said at first.
conf = (Path(__file__).resolve().parent.parent / 'deploy' / 'nginx-zigmon.conf').read_text()
block = conf[conf.index('location = /tap {'):]
block = block[:block.index('\n    }')]
assert '$request_method != POST' in block, 'the header address is not held to POST'
assert 'return 405' in block and 'X-Zigmon-Tap' in block, \
    'a browser opening the header address is refused without being told why'
assert 'deny all' not in block, 'a bare refusal is back'
print('the header address answers a browser instead of refusing it')

print('\nboth roads, the code, the switch and the web server behave')
