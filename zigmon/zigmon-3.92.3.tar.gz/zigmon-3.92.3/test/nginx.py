#!/usr/bin/env python3
"""The nginx file, read for the things nginx itself would refuse.

There is no nginx here to ask, and the file is shipped to machines where a
mistake in it stops the web server rather than the dashboard - which is worse
than any fault inside the dashboard, because it takes everything else on that
machine with it.
"""
import re
import sys
from pathlib import Path

# Every nginx file that ships, not only the dashboard's: the one in front of
# it is the piece that faces the internet, and a fault there is the same
# fault - the web server does not start, and takes every other site with it.
DEPLOY = Path(__file__).resolve().parent.parent / 'deploy'
CONFS = sorted(DEPLOY.glob('*.conf'))
text = '\n'.join(c.read_text() for c in CONFS)
bad = []

# The one that faces the internet must expose one address and refuse the rest,
# and must not carry the dashboard's own locations by being copied from it.
front = (DEPLOY / 'nginx-tap-front.conf')
if front.exists():
    words = front.read_text()
    if 'location = /tap' not in words:
        bad.append('the front server does not carry the one address it exists for')
    if 'location / { return 404; }' not in words:
        bad.append('the front server does not refuse everything that is not that address')
    for never in ('index.php$', 'fastcgi_pass', '/api/', 'location ~ \\.php'):
        if never in words:
            bad.append('the front server carries %s, which belongs only at home' % never)
    if 'X-Forwarded-For' not in words:
        bad.append('the front server does not pass the caller on, so guesses are counted against it')
    if 'limit_req zone' not in words:
        bad.append('the address that faces the internet has no rate limit')

# A location's regex may hold { or }, but only in quotes: nginx reads a brace
# as the start or end of a block and cuts the expression off there, then
# refuses to start with "missing ) in ...". This is how /tap/([A-Za-z0-9_-]
# was all nginx ever saw of a perfectly good pattern.
for match in re.finditer(r'location\s+(~\*?|=)?\s*([^\s{][^\n]*?)\s*\{', text):
    expr = match.group(2).strip()
    if ('{' in expr or '}' in expr) and not (expr.startswith('"') and expr.endswith('"')):
        bad.append('location %s needs quoting: a brace in it ends the expression' % expr)

# gzip always compresses text/html, and naming it warns at every start
for line in text.split('\n'):
    if line.strip().startswith('gzip_types') and 'text/html' in line:
        bad.append('gzip_types names text/html, which nginx compresses anyway - a warning at start')

# every brace balanced, or nginx says something far less helpful than this
depth = 0
for n, line in enumerate(text.split('\n'), 1):
    without = re.sub(r'"[^"]*"|#.*$', '', line)
    depth += without.count('{') - without.count('}')
    if depth < 0:
        bad.append('a } too many at line %d' % n)
        break
if depth > 0:
    bad.append('%d block(s) left open at the end' % depth)

# Every regex must compile. A quoted pattern is taken whole - reading up to
# the first brace is the very mistake being looked for, and doing it here
# would report a sound pattern as broken.
for match in re.finditer(r'location\s+~\*?\s*(?:"([^"]*)"|([^\s{]+))\s*\{', text):
    expr = match.group(1) if match.group(1) is not None else match.group(2)
    try:
        re.compile(expr)
    except re.error as e:
        bad.append('location %s is not a regular expression: %s' % (expr, e))

# A rewrite resets $1..$9 to its own captures, so "rewrite ^ /x?t=$1" hands
# on an empty token however well the location captured it. If a rewrite uses
# a capture, its own expression has to make one.
for match in re.finditer(r'\n\s*rewrite\s+("[^"]*"|\S+)\s+(\S+)', text):
    pattern, target = match.group(1).strip('"'), match.group(2)
    if re.search(r'\$[1-9]', target) and '(' not in pattern:
        bad.append('rewrite %s uses $1 but captures nothing itself - the token arrives empty'
                   % pattern)

# An if block takes almost nothing. The whole list nginx allows inside one is
# short, and everything else - default_type among them - stops the web server
# at start with "directive is not allowed here". That is exactly how a release
# meant to make a refusal friendlier took nginx down with it.
IF_ALLOWS = ('return', 'rewrite', 'set', 'break', 'proxy_pass', 'fastcgi_pass',
             'add_header', 'expires', 'limit_rate', 'access_log', 'log_not_found',
             'uwsgi_pass', 'scgi_pass', 'memcached_pass', 'gzip', 'if', '}', '{')
lines = text.split('\n')
depth_in_if = 0
for n, line in enumerate(lines, 1):
    # quotes and comments are not blocks: the refusal itself is a JSON string
    # with a brace at each end of it
    counted = re.sub(r'"[^"]*"|\'[^\']*\'|#.*$', '', line)
    opens = counted.count('{') - counted.count('}')
    word = line.strip().split()[0].rstrip(';') if line.strip() else ''
    if depth_in_if > 0:
        if word and not word.startswith('#') and word not in IF_ALLOWS:
            bad.append('line %d: %s is not allowed inside an if block' % (n, word))
        depth_in_if += opens
        continue
    if re.match(r'^\s*if\s*\(', line) and '{' in counted:
        depth_in_if = opens

# A limit that names a zone nobody declared stops nginx at start, and the
# declaration has to stand outside the server block - limit_req_zone is an
# http directive, and the file is included inside http. Easy to move one and
# not the other.
zones = set(re.findall(r'limit_req_zone[^;]*zone=(\w+):', text))
for used in set(re.findall(r'limit_req\s+zone=(\w+)', text)):
    if used not in zones:
        bad.append('limit_req names the zone %s, which nothing declares' % used)
for m in re.finditer(r'\n\s*limit_req_zone\b', text):
    depth_here = 0
    for line in text[:m.start()].split('\n'):
        counted = re.sub(r'"[^"]*"|\'[^\']*\'|#.*$', '', line)
        depth_here += counted.count('{') - counted.count('}')
    if depth_here:
        bad.append('limit_req_zone is inside a block; it belongs at the top of the file')

if bad:
    print('the nginx file would not start:')
    for line in bad:
        print('   ' + line)
    sys.exit(1)
print('%d nginx file(s): %d location(s), braces balanced, every pattern sound, '
      'nothing forbidden inside an if'
      % (len(CONFS), len(re.findall(r'\n\s*location\s', text))))


# The one-tap roads may be reached from a server in front while the dashboard
# itself is not. That only holds if each of those locations carries its own
# allow rules - the ones at the top of the server apply to everything else -
# and if it hands the request to PHP itself: a rewrite re-enters the location
# list and lands in the php block, where the server's own rules apply again,
# and the front server would be refused there.
_home = (DEPLOY / 'nginx-zigmon.conf').read_text()
for _road in ('location = /tap', 'location ~ "^/tap/'):
    _at = _home.index(_road)
    _block = _home[_at:_home.index('\n    }', _at)]
    # and the allow has to be a line, not a comment: a road that only talks
    # about letting the server in front through lets nothing through
    _live = '\n'.join(l for l in _block.splitlines() if not l.strip().startswith('#'))
    if 'deny  all' not in _live or 'allow ' not in _live:
        print('%s has no rules of its own, so it is open to whatever the server allows' % _road)
        raise SystemExit(1)
    if 'rewrite' in _block and 'fastcgi_pass' not in _block:
        print('%s sends the request round again instead of handing it to PHP' % _road)
        raise SystemExit(1)
    if 'fastcgi_pass' not in _block:
        print('%s never reaches PHP at all' % _road)
        raise SystemExit(1)
    if re.search(r'^\s*set_real_ip_from', _block, re.M):
        # real_ip rewrites the address before the access rules are read, so
        # the connection stops being the server in front and the allow rule
        # for it matches nothing at all
        print('%s uses set_real_ip_from, which undoes its own allow rule' % _road)
        raise SystemExit(1)
print('both one-tap roads carry their own allow rules and reach PHP without going round again')
if '$zigmon_presser' not in _home or 'map $http_x_forwarded_for' not in _home:
    print('the rate limit counts the connection, so one server in front shares one bucket')
    raise SystemExit(1)
print('the rate limit counts whoever pressed, not the server that passed it on')

# fastcgi_params sets QUERY_STRING to the request's own query, so a road that
# includes it after setting one of its own has its own wiped: PHP sees no
# query, answers with the whole dashboard page, and the daemon never hears
# about it. A 200 and a megabyte of HTML is a hard thing to read as a fault.
for _road in ('location = /tap', 'location ~ "^/tap/'):
    _at = _home.index(_road)
    _block = _home[_at:_home.index('\n    }', _at)]
    # read with the comments out of the way: one of them says the word
    _block = '\n'.join(l for l in _block.splitlines() if not l.strip().startswith('#'))
    if 'QUERY_STRING' in _block:
        if 'include' not in _block:
            print('%s never includes fastcgi_params' % _road)
            raise SystemExit(1)
        if _block.index('include') > _block.index('QUERY_STRING'):
            print('%s includes fastcgi_params after its own QUERY_STRING, which wipes it' % _road)
            raise SystemExit(1)
print('both roads set their query after including fastcgi_params, not before')

# The installer must not write its idea of the tap block over one that is
# already there: a config on a running house has its own addresses, its own
# allow rules and a server in front, and an installer that overwrites that
# does damage every time it runs. It may add the block where there is none,
# and it must put the file back if nginx refuses what came out.
_setup = (DEPLOY.parent / 'install.sh').read_text()
_where = _setup.index('location = /tap')
_around = _setup[max(0, _where - 3000):_where + 8000]
for _wanted, _why in (
        ("print('same'", 'it does not notice a config that already matches'),
        ("else 'theirs'", 'it does not leave a config of its own alone'),
        ('kept as it is', 'it does not say that it left one alone'),
        ('zigmon-before', 'it takes no copy before writing'),
        ('cp -a "$NGINX_CONF.zigmon-before"', 'it does not put the file back when nginx refuses')):
    if _wanted not in _around:
        print('the installer: %s' % _why)
        raise SystemExit(1)
if 'rewrite ^ /index.php?api=tap' in _around:
    print('the installer still writes the old rewrite form of the tap block')
    raise SystemExit(1)
print('the installer adds the tap block where there is none and leaves any other alone')
