#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zigmon.py - monitoring daemon for every sensor published by Zigbee2MQTT (and,
optionally, by Shelly WiFi devices) over an MQTT broker.

One file. Python standard library plus paho-mqtt, which AlmaLinux 9 ships in
EPEL as python3-paho-mqtt.

It subscribes to the broker, keeps a long-term history in SQLite, and exposes
everything on a localhost HTTP API that the PHP dashboard reads. The two
actions that change something (opening the network for joining, erasing
history) are guarded by a token, so the web user never holds broker
credentials.

Runs as a systemd service, but every function is also available from the
command line for testing:

    zigmon --status              every device with its latest readings
    zigmon --devices             the device table
    zigmon --history DEV 24h     recorded samples of one device as a table
    zigmon --events              the event log
    zigmon --watch               live feed straight from the broker
    zigmon --permit-join on      open the Zigbee network for four minutes
    zigmon --plug                the smart plugs, live from the devices
    zigmon --plug-toggle NAME    switch a plug (also --plug-on, --plug-off)
    zigmon --bindings            which button does what
    zigmon --check               health check against the running daemon
    zigmon --diag                API latency, database size, config in force
    zigmon                       run the daemon in the foreground
"""

# Bumped by hand with every change to this file.
__version__ = '2.19.9'

import argparse
import errno
import json
import math
import os
import re
import secrets
import select
import shutil
import signal
import socket
import sqlite3
import ssl
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

try:
    import paho.mqtt.client as mqtt
except ImportError:            # reported properly by preflight(), not here
    mqtt = None

# ---------------------------------------------------------------------------
# Paths and defaults
# ---------------------------------------------------------------------------
CONFIG_FILE = Path(os.environ.get('ZIGMON_CONFIG', '/etc/zigmon/config.json'))
STATE_DIR = Path('/var/lib/zigmon')
DB_FILE = STATE_DIR / 'history.db'
RUN_DIR = Path('/run/zigmon')
TOKEN_FILE = RUN_DIR / 'api-token'
SERVICE_USER = 'zigmon'

DEFAULTS = {
    # --- the broker ---------------------------------------------------------
    'mqtt_host': '127.0.0.1',
    'mqtt_port': 1883,
    'mqtt_username': '',
    'mqtt_password': '',
    'mqtt_tls': False,           # True for a TLS listener (usually port 8883)
    'mqtt_ca': '',               # CA file to verify the broker; empty = no verification
    'mqtt_client_id': 'zigmon',
    'mqtt_keepalive': 60,

    # --- what to listen to --------------------------------------------------
    'base_topic': 'zigbee2mqtt',
    # Additional topic filters. Shelly Gen2/Gen3 devices publishing their
    # status under a prefix (shellies/<name>/status/...) are understood; any
    # other topic carrying a JSON object is stored under the topic's second
    # element as the device name.
    'extra_topics': ['shellies/#'],
    'networkmap_interval': 300,   # seconds between network-map scans (who is whose parent); 0 turns it off

    # --- our own API --------------------------------------------------------
    'api_host': '127.0.0.1',
    'api_port': 9849,
    'token_file': '/run/zigmon/api-token',

    # --- timing (seconds) ---------------------------------------------------
    # A reading that arrives sooner than this after the previous stored one
    # replaces it instead of adding a row. 0 keeps every reading.
    'sample_interval': 30,
    'aggregate_interval': 3600,
    'db_file': '',               # empty = /var/lib/zigmon/history.db

    # --- retention ----------------------------------------------------------
    'retain_full_days': 14,
    'retain_hourly_days': 730,
    'retain_events_days': 730,

    # --- thresholds used for the health verdict -----------------------------
    'battery_warn': 30,
    'battery_crit': 15,
    'lqi_warn': 40,
    'lqi_crit': 20,
    # A device that has not reported for this long is flagged, whatever the
    # bridge says about its availability. 0 disables it.
    'stale_warn_min': 180,
    'stale_crit_min': 1500,
    # Temperature and humidity limits, applied to every device. null = off.
    'temperature_min': None,
    'temperature_max': None,
    'humidity_max': None,

    # --- logging ------------------------------------------------------------
    'log_file': '/var/log/zigmon/zigmon.log',
    'log_level': 'info',
    'log_to_journal': True,

    # --- Shelly smart plugs, read and controlled over local RPC -------------
    # [{"name": "Lednice", "host": "172.16.16.12", "password": "", "switch_id": 0,
    #   "mqtt_name": ""}]  - mqtt_name: the plug's shellies/<name> prefix, so the
    # same device is not also picked up from MQTT.
    'plugs': [],
    'plug_poll_interval': 15,
    'plug_sample_interval': 60,
    'plug_min_request_gap': 1.0,
    'plug_command_gap': 0.05,       # a switch command may follow the last request this soon (s)
    'plug_timeout': 5.0,
    # Shelly sensors with an address of their own (an H&T on USB power answers
    # RPC; on battery it sleeps, and the webhook below is what carries it).
    # [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}]
    'sensors': [],
    # Accept webhook pushes from battery sensors that cannot be polled:
    #   http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=HT-Sklep
    'sensor_listen': False,
    'sensor_listen_host': '0.0.0.0',
    'sensor_listen_port': 8088,

    # --- the dashboard's PIN for permit-join and erasing data ---------------
    'pin': '',                   # empty disables the PIN (the token still applies)
    'pin_attempts': 5,
    'pin_lockout_s': 300,
    'public_view': True,
    'backup_enabled': 1,          # 1 = write the daily settings backup
    'backup_time': '03:30',       # local HH:MM
    'backup_keep': 14,            # how many of each to keep
    'backup_zigbee': 1,           # 1 = also ask Zigbee2MQTT for its coordinator backup
    'chart_outages': 0,            # 1 = shade stretches where a chatty source went quiet, on every chart
    'link_plugs': 1,               # 1 = a plug's name / chart button opens its history
    'link_sensors': 1,             # 1 = clicking a sensor card opens its history
    'link_buttons': 1,             # 1 = clicking a button card opens its history
    'gateway_poll_interval': 30,    # seconds between polls of each zigbee_gateways entry
    'zigbee_gateways': [],          # [{"name": "...", "host": "ip", "target": "coordinator" or an existing device name}]          # false = even reading the dashboard asks for the PIN first
    # notifications: fill a channel in and pick what to send on the dashboard
    'notify_ntfy': '',              # full topic URL, e.g. https://ntfy.sh/moje-tajne-slovo
    'notify_telegram_token': '',    # bot token from @BotFather
    'notify_telegram_chat': '',     # chat id
    # where the house stands, for sunrise/sunset in rule windows
    'latitude': None,
    'longitude': None,
    # money: per-kWh price for the energy summary
    'price_per_kwh': None,
    'currency': 'Kč',
}

CONFIG = dict(DEFAULTS)
CONFIG_NOTES = []
CONFIG_FATAL = []
DEBUG = False
LOG_HANDLE = None
LOG_PATH = None


def token_path():
    return Path(CONFIG.get('token_file') or str(TOKEN_FILE))


def db_path():
    return Path(CONFIG.get('db_file') or str(DB_FILE))


def _whoami():
    try:
        import pwd
        return pwd.getpwuid(os.geteuid()).pw_name
    except Exception:
        return str(os.geteuid())


def _coerce(current, value):
    """Make a config value the same type as its default, where that is sane."""
    if current is None:
        if value in ('', None):
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return value
    if isinstance(current, bool):
        if isinstance(value, str):
            return value.strip().lower() in ('1', 'true', 'yes', 'on')
        return bool(value)
    if isinstance(current, int):
        try:
            return int(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, float):
        try:
            return float(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, list):
        if isinstance(value, str):
            return [v.strip() for v in value.split(',') if v.strip()]
        return list(value) if isinstance(value, (list, tuple)) else current
    return value if value is not None else current


NOTIFY_CATEGORIES = ('crit', 'warn', 'offline', 'rule', 'switch')


def notify_override_set(value):
    """A per-device override: a preset name, or custom:cat1,cat2."""
    if value in NOTIFY_PRESETS:
        return NOTIFY_PRESETS[value]
    if isinstance(value, str) and value.startswith('custom:'):
        return {c for c in value[7:].split(',') if c in NOTIFY_CATEGORIES}
    return None


NOTIFY_PRESETS = {
    'mute': set(),
    'crit': {'crit'},
    'crit_offline': {'crit', 'offline'},
    'crit_offline_switch': {'crit', 'offline', 'switch'},
    'all': {'crit', 'warn', 'offline', 'rule', 'switch'},
}

KNOWN_PLUG_KEYS = {'name', 'host', 'password', 'switch_id', 'mqtt_name', 'enabled', 'kind', 'retain_full_days', 'monitor_only'}


def warn_unknown_keys():
    for entry in (CONFIG.get('plugs') or []) + (CONFIG.get('sensors') or []):
        if isinstance(entry, dict):
            for k in entry:
                if k not in KNOWN_PLUG_KEYS:
                    log('config: unknown key %r on device %r - a typo?' % (k, entry.get('name')), 'warn')
    for entry in CONFIG.get('zigbee_gateways') or []:
        if isinstance(entry, dict):
            for k in entry:
                if k not in ('name', 'host', 'target'):
                    log('config: unknown key %r on zigbee_gateways entry %r - a typo?' % (k, entry.get('name')), 'warn')
    for k in CONFIG:
        if k not in DEFAULTS and not k.startswith('_'):
            log('config: unknown top-level key %r - a typo?' % k, 'warn')


def load_config():
    """File first, then ZIGMON_* environment variables, which win."""
    if CONFIG_FILE.is_file():
        try:
            raw = json.loads(CONFIG_FILE.read_text())
            if not isinstance(raw, dict):
                CONFIG_FATAL.append('%s is not a JSON object' % CONFIG_FILE)
            else:
                for key, value in raw.items():
                    if key not in DEFAULTS:
                        CONFIG_NOTES.append('unknown option "%s" ignored' % key)
                        continue
                    CONFIG[key] = _coerce(DEFAULTS[key], value)
        except PermissionError:
            CONFIG_FATAL.append(
                '%s exists but cannot be read as %s. Fix with:  '
                'sudo chown root:%s %s && sudo chmod 640 %s'
                % (CONFIG_FILE, _whoami(), SERVICE_USER, CONFIG_FILE, CONFIG_FILE))
        except ValueError as e:
            CONFIG_FATAL.append('%s is not valid JSON: %s' % (CONFIG_FILE, e))
        except OSError as e:
            CONFIG_FATAL.append('could not read %s: %s' % (CONFIG_FILE, e))

    for key in DEFAULTS:
        env = os.environ.get('ZIGMON_' + key.upper())
        if env is not None:
            CONFIG[key] = _coerce(DEFAULTS[key], env)
            CONFIG_NOTES.append('%s taken from the environment' % key)
    return CONFIG


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def open_log(path=None):
    """Open the log file for appending. Safe to call again to reopen it."""
    global LOG_HANDLE, LOG_PATH
    close_log()
    path = path if path is not None else CONFIG.get('log_file')
    if not path:
        return None
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        LOG_HANDLE = open(str(target), 'a', encoding='utf-8')
        LOG_PATH = target
    except OSError as e:
        LOG_HANDLE, LOG_PATH = None, None
        sys.stderr.write('cannot write the log file %s: %s\n' % (path, e))
    return LOG_HANDLE


def ensure_log_current():
    """Reopen if the file we hold is no longer the one at the configured path."""
    if not LOG_HANDLE or not LOG_PATH:
        return False
    try:
        same = os.stat(str(LOG_PATH)).st_ino == os.fstat(LOG_HANDLE.fileno()).st_ino
    except OSError:
        same = False
    if same:
        return False
    open_log()
    log('log file reopened - it was rotated without a signal reaching us')
    return True


def close_log():
    global LOG_HANDLE
    if LOG_HANDLE:
        try:
            LOG_HANDLE.close()
        except OSError:
            pass
    LOG_HANDLE = None


def log(msg, level='info'):
    if level == 'debug' and not (DEBUG or CONFIG.get('log_level') == 'debug'):
        return
    line = '%s  %-5s %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), level, msg)
    if LOG_HANDLE:
        try:
            LOG_HANDLE.write(line + '\n')
            LOG_HANDLE.flush()
        except (OSError, ValueError):
            try:
                open_log()
                if LOG_HANDLE:
                    LOG_HANDLE.write(line + '\n')
                    LOG_HANDLE.flush()
            except Exception:
                pass
    if CONFIG.get('log_to_journal', True) or not LOG_HANDLE:
        stream = sys.stderr if level in ('error', 'warn') else sys.stdout
        stream.write(line + '\n')
        stream.flush()


# ---------------------------------------------------------------------------
# Units, labels and what a payload key means
# ---------------------------------------------------------------------------
# Zigbee2MQTT tells us the unit and label of every property in the device's
# "exposes" definition; these are the fallbacks for keys that arrive without
# one, and for the Shelly devices, which describe nothing.
KEY_INFO = {
    'temperature':   ('Temperature', '°C'),
    'humidity':      ('Humidity', '%'),
    'battery':       ('Battery', '%'),
    'voltage':       ('Voltage', 'mV'),
    'linkquality':   ('Link quality', 'lqi'),
    'illuminance':   ('Illuminance', 'lx'),
    'illuminance_lux': ('Illuminance', 'lx'),
    'light_level':   ('Light level', ''),
    'pressure':      ('Pressure', 'hPa'),
    'co2':           ('CO₂', 'ppm'),
    'pm25':          ('PM2.5', 'µg/m³'),
    'voc':           ('VOC', 'ppb'),
    'power':         ('Power', 'W'),
    'energy':        ('Energy', 'kWh'),
    'current':       ('Current', 'A'),
    'contact':       ('Contact', ''),
    'occupancy':     ('Occupancy', ''),
    'water_leak':    ('Water leak', ''),
    'vibration':     ('Vibration', ''),
    'tamper':        ('Tamper', ''),
    'battery_low':   ('Battery low', ''),
    'action':        ('Action', ''),
    'state':         ('State', ''),
    'position':      ('Position', '%'),
    'brightness':    ('Brightness', ''),
    'device_temperature': ('Device temperature', '°C'),
    'soil_moisture': ('Soil moisture', '%'),
    # Shelly Gen2/3 component fields
    'tC':            ('Temperature', '°C'),
    'tF':            ('Temperature', '°F'),
    'rh':            ('Humidity', '%'),
    'apower':        ('Power', 'W'),
    'aenergy.total': ('Energy total', 'Wh'),
    'battery.V':     ('Battery voltage', 'V'),
    'battery.percent': ('Battery', '%'),
    'external.present': ('External power', ''),
    'lux':           ('Illuminance', 'lx'),
    'switch.output': ('Output', ''),
    'switch.apower': ('Power', 'W'),
    'switch.voltage': ('Voltage', 'V'),
    'switch.current': ('Current', 'A'),
    'switch.pf':     ('Power factor', ''),
    'switch.freq':   ('Frequency', 'Hz'),
    'switch.aenergy.total': ('Energy total', 'Wh'),
    'switch.temperature.tC': ('Device temperature', '°C'),
    'switch.temperature.tF': ('Device temperature', '°F'),
    'pm1.apower':    ('Power', 'W'),
    'pm1.voltage':   ('Voltage', 'V'),
    'pm1.current':   ('Current', 'A'),
    'pm1.aenergy.total': ('Energy total', 'Wh'),
    'wifi.rssi':     ('WiFi signal', 'dBm'),
    'sys.uptime':    ('Uptime', 's'),
}

# Keys that are bookkeeping rather than measurements.
IGNORE_KEYS = {'last_seen', 'elapsed', 'update', 'update_available', 'linkquality_raw',
               'id', 'ts', 'transaction', 'src', 'dst', 'method', 'params', 'result',
               'device_temperature_unit', 'ret_aenergy.total'}

# Keys that count as a "reading" for the overview cards, in display order.
HEADLINE_KEYS = ['temperature', 'tC', 'humidity', 'rh', 'illuminance', 'illuminance_lux',
                 'lux', 'light_level', 'pressure', 'co2', 'pm25', 'voc', 'apower', 'power',
                 'energy', 'aenergy.total', 'switch.output', 'voltage', 'contact', 'occupancy',
                 'water_leak', 'position', 'brightness', 'state']


def key_info(key):
    """Look the key up, then every shorter dotted suffix of it."""
    parts = key.split('.')
    for i in range(len(parts)):
        info = KEY_INFO.get('.'.join(parts[i:]))
        if info:
            return info
    return None


def key_base(key):
    parts = key.split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in KEY_INFO:
            return candidate
    return parts[-1]


def headline_rank(key):
    parts = key.split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in HEADLINE_KEYS:
            return HEADLINE_KEYS.index(candidate)
    return None


def parse_prometheus_text(raw):
    """A minimal reader for the Prometheus text exposition format that
    /metrics answers with: 'name{labels} value' or 'name value' per line,
    '#' lines are comments. Labels are folded into the key so a metric with
    several label sets doesn't overwrite itself."""
    out = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.rsplit(' ', 1)
        if len(parts) != 2:
            continue
        name, value = parts
        try:
            value = float(value)
        except ValueError:
            continue
        if '{' in name:
            base, labels = name.split('{', 1)
            labels = labels.rstrip('}')
            tag = '_'.join(v.strip('"') for _, v in
                           (kv.split('=', 1) for kv in labels.split(',') if '=' in kv))
            name = base + ('.' + tag if tag else '')
        out[name] = value
    return out


def key_label(key):
    info = key_info(key)
    if info:
        return info[0]
    return key.replace('_', ' ').replace('.', ' · ').capitalize()


def key_unit(key):
    info = key_info(key)
    return info[1] if info else ''


def flatten(obj, prefix=''):
    """{'battery': {'V': 2.9}} -> {'battery.V': 2.9}. Lists are kept as-is."""
    out = {}
    if not isinstance(obj, dict):
        return out
    for key, value in obj.items():
        name = ('%s.%s' % (prefix, key)) if prefix else str(key)
        if isinstance(value, dict):
            out.update(flatten(value, name))
        else:
            out[name] = value
    return out


SENSOR_COMPONENTS = ('temperature', 'humidity', 'devicepower', 'illuminance')


def normalise_shelly_status(flat):
    """Shelly.GetStatus flattened -> the keys the dashboard knows.

    temperature:0.tC becomes tC, devicepower:0.battery.V becomes battery.V;
    switch:0.apower becomes switch.apower; wifi.rssi and sys.uptime stay.
    """
    out = {}
    for key, value in flat.items():
        if isinstance(value, (dict, list)):
            continue
        m = re.match(r'^([a-z_]+):(\d+)\.(.+)$', key)
        if m:
            component, index, rest = m.group(1), m.group(2), m.group(3)
            if rest in ('id', 'source') or 'by_minute' in rest or 'minute_ts' in rest:
                continue
            if component in SENSOR_COMPONENTS:
                out[rest if index == '0' else '%s%s.%s' % (component, index, rest)] = value
            elif component in ('switch', 'pm1', 'cover', 'light', 'input'):
                out['%s%s.%s' % (component, '' if index == '0' else index, rest)] = value
        elif key in ('wifi.rssi', 'wifi.sta_ip', 'wifi.ssid', 'sys.uptime', 'sys.ram_free',
                     'cloud.connected', 'mqtt.connected'):
            out[key] = value
    return out


def sun_minutes(lat, lon, when=None, sunset=False):
    """Local minutes-of-day of sunrise or sunset (NOAA approximation), or None
    in polar conditions."""
    day = time.localtime(when if when is not None else time.time())
    lng_hour = lon / 15.0
    t = day.tm_yday + (((18 if sunset else 6) - lng_hour) / 24.0)
    mean = (0.9856 * t) - 3.289
    lsun = (mean + 1.916 * math.sin(math.radians(mean)) + 0.020 * math.sin(math.radians(2 * mean)) + 282.634) % 360
    ra = math.degrees(math.atan(0.91764 * math.tan(math.radians(lsun)))) % 360
    ra += (math.floor(lsun / 90) - math.floor(ra / 90)) * 90
    ra /= 15.0
    sin_dec = 0.39782 * math.sin(math.radians(lsun))
    cos_dec = math.cos(math.asin(sin_dec))
    cos_h = (math.cos(math.radians(90.833)) - sin_dec * math.sin(math.radians(lat))) / (cos_dec * math.cos(math.radians(lat)))
    if cos_h > 1 or cos_h < -1:
        return None
    hours = (math.degrees(math.acos(cos_h)) if sunset else 360 - math.degrees(math.acos(cos_h))) / 15.0
    ut = (hours + ra - 0.06571 * t - 6.622 - lng_hour) % 24
    local = (ut + (day.tm_gmtoff / 3600.0)) % 24
    return int(local * 60)


def numeric(value):
    """A float for anything worth charting, or None."""
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        v = value.strip().upper()
        if v in ('ON', 'OPEN', 'TRUE', 'OCCUPIED', 'YES'):
            return 1.0
        if v in ('OFF', 'CLOSE', 'CLOSED', 'FALSE', 'CLEAR', 'NO'):
            return 0.0
        try:
            return float(value)
        except ValueError:
            return None
    return None


def parse_span(text):
    """'6h', '24h', '7d', '30d', '1y', '90m' -> seconds."""
    m = re.match(r'^\s*(\d+(?:\.\d+)?)\s*([smhdwy])?\s*$', str(text or ''))
    if not m:
        raise ValueError('bad range %r (use e.g. 24h, 7d, 1y)' % text)
    n = float(m.group(1))
    unit = m.group(2) or 'h'
    mult = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400, 'w': 604800, 'y': 31557600}[unit]
    return int(n * mult)


def human_age(seconds):
    if seconds is None:
        return 'never'
    seconds = int(seconds)
    if seconds < 60:
        return '%ds' % seconds
    if seconds < 3600:
        return '%dm' % (seconds // 60)
    if seconds < 86400:
        return '%dh %dm' % (seconds // 3600, (seconds % 3600) // 60)
    return '%dd %dh' % (seconds // 86400, (seconds % 86400) // 3600)


def thin(rows, points):
    """Keep at most `points` rows, evenly spaced, always keeping the last one."""
    if points <= 0 or len(rows) <= points:
        return rows
    step = len(rows) / float(points)
    out = [rows[int(i * step)] for i in range(points)]
    if out[-1] is not rows[-1]:
        out.append(rows[-1])
    return out


# ---------------------------------------------------------------------------
# Shelly Gen2+ RPC (the smart plugs)
# ---------------------------------------------------------------------------
class PlugError(Exception):
    pass


class ShellyRPC(object):
    """Minimal JSON-RPC client for a Shelly Gen2+ device, standard library only.

    Shelly answers the first request with 401 and a challenge, and expects
    SHA-256 digest with qop=auth; urllib's own digest handler predates SHA-256
    on the Python AlmaLinux 9 ships, so it is done by hand. One challenge is
    reused for every later call with the nonce counter stepping on each time,
    because re-authenticating doubles the request count and a Gen3 plug
    answers 429 when that adds up.
    """
    _challenges = {}
    _last_request = {}
    _pace = threading.Lock()

    def __init__(self, host, password='', switch_id=0, label='the plug'):
        self.host = host
        self.password = password or ''
        self.switch_id = int(switch_id or 0)
        self.timeout = float(CONFIG.get('plug_timeout') or 5.0)
        self.retry_after = 0.0
        self.label = label

    @property
    def url(self):
        return 'http://%s/rpc' % self.host

    COMMANDS = ('Switch.Set', 'Switch.Toggle')

    def call(self, method, params=None):
        if not self.host:
            raise PlugError('no host configured for %s' % self.label)
        payload = {'id': 1, 'method': method}
        if params:
            payload['params'] = params
        self._priority = method in self.COMMANDS   # a person is waiting; do not queue behind the poll
        body = json.dumps(payload).encode('utf-8')
        known = self._challenges.get(self.host)
        auth = self._digest_header(known, 'POST', '/rpc') if known else None
        status, reply, headers = self._post(body, auth)
        if status == 401:
            challenge = headers.get('WWW-Authenticate', '')
            if not self.password:
                raise PlugError('%s requires a password; set it in the config' % self.label)
            self._challenges[self.host] = self._parse_challenge(challenge)
            status, reply, headers = self._post(
                body, self._digest_header(self._challenges[self.host], 'POST', '/rpc'))
            if status == 401:
                self._challenges.pop(self.host, None)
                raise PlugError('%s rejected the password' % self.label)
        if status == 429:
            retry = headers.get('Retry-After')
            self.retry_after = numeric(retry) or 0
            attempt = getattr(self, '_retries', 0)
            if attempt < 3:
                self._retries = attempt + 1
                delay = min(max(self.retry_after, 2.0) * (attempt + 1), 15.0)
                log('%s asked us to wait; retrying in %.0fs' % (self.label, delay), 'debug')
                time.sleep(delay)
                try:
                    return self.call(method, params)
                finally:
                    self._retries = attempt
            raise PlugError('%s is rate limiting us (HTTP 429)' % self.label)
        if status != 200:
            raise PlugError('%s answered HTTP %s' % (self.label, status))
        try:
            result = json.loads(reply.decode('utf-8'))
        except ValueError:
            raise PlugError('%s did not return JSON - is it a Gen2+ device?' % self.label)
        if 'error' in result:
            error = result['error']
            raise PlugError('RPC error %s: %s' % (error.get('code'), error.get('message')))
        return result.get('result')

    def _wait_turn(self):
        gap = float(CONFIG.get('plug_min_request_gap') or 0)
        if getattr(self, '_priority', False):
            gap = min(gap, float(CONFIG.get('plug_command_gap') or 0))
        if gap <= 0:
            return
        with self._pace:
            previous = self._last_request.get(self.host, 0.0)
            delay = previous + gap - time.time()
            if delay > 0:
                time.sleep(min(delay, gap))
            self._last_request[self.host] = time.time()

    def _post(self, body, auth=None):
        import urllib.request
        import urllib.error
        self._wait_turn()
        request = urllib.request.Request(self.url, data=body, method='POST')
        request.add_header('Content-Type', 'application/json')
        if auth:
            request.add_header('Authorization', auth)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return response.status, response.read(), dict(response.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)
        except OSError as e:
            raise PlugError('cannot reach %s at %s (%s)' % (self.label, self.host, e))

    @staticmethod
    def _parse_challenge(header):
        fields = dict(re.findall(r'(\w+)="?([^",]+)"?', header))
        fields['nc'] = 0
        return fields

    def _digest_header(self, fields, method, path):
        import hashlib
        algorithm = (fields.get('algorithm') or 'SHA-256').upper()
        digest = hashlib.sha256 if 'SHA-256' in algorithm else hashlib.md5

        def h(text):
            return digest(text.encode('utf-8')).hexdigest()

        realm = fields.get('realm', '')
        nonce = fields.get('nonce', '')
        fields['nc'] = int(fields.get('nc', 0)) + 1
        nc = '%08x' % fields['nc']
        cnonce = secrets.token_hex(8)
        ha1 = h('admin:%s:%s' % (realm, self.password))
        ha2 = h('%s:%s' % (method, path))
        response = h('%s:%s:%s:%s:auth:%s' % (ha1, nonce, nc, cnonce, ha2))
        return ('Digest username="admin", realm="%s", nonce="%s", uri="%s", '
                'algorithm=%s, qop=auth, nc=%s, cnonce="%s", response="%s"'
                % (realm, nonce, path, algorithm, nc, cnonce, response))

    # -- the calls this daemon makes ---------------------------------------
    def switch_status(self):
        return self.call('Switch.GetStatus', {'id': self.switch_id})

    def device_status(self):
        return self.call('Shelly.GetStatus')

    def device_info(self):
        return self.call('Shelly.GetDeviceInfo')

    def set_output(self, on):
        return self.call('Switch.Set', {'id': self.switch_id, 'on': bool(on)})

    def toggle_output(self):
        """One round trip instead of read-then-set; the answer says what it was."""
        return self.call('Switch.Toggle', {'id': self.switch_id})

    def reset_counters(self, types=None):
        params = {'id': self.switch_id}
        if types:
            params['type'] = list(types)
        try:
            return self.call('Switch.ResetCounters', params)
        except PlugError:
            accepted = []
            for one in (types or PLUG_COUNTER_TYPES):
                try:
                    self.call('Switch.ResetCounters', {'id': self.switch_id, 'type': [one]})
                    accepted.append(one)
                except PlugError:
                    continue
            if not accepted:
                raise
            return {'reset': accepted}


# What Switch.ResetCounters accepts, in the order the plug's own web UI lists
# them. Sending no type at all resets everything.
PLUG_COUNTERS = [
    {'type': 'aenergy',      'label': 'Active energy',      'field': 'aenergy.total',
     'help': 'the energy consumed since the last reset'},
    {'type': 'ret_aenergy',  'label': 'Returned energy',    'field': 'ret_aenergy.total',
     'help': 'energy fed back to the grid; always zero on a plain socket'},
    {'type': 'on_time',      'label': 'Total runtime',      'field': 'counts.on_time',
     'help': 'how long the relay has been switched on, in total'},
    {'type': 'switch_on',    'label': 'Switching cycles',   'field': 'counts.switch_on',
     'help': 'how many times the relay has been switched on'},
    {'type': 'on_above_thr', 'label': 'Active load runtime', 'field': 'counts.on_above_thr',
     'help': 'time spent above the active load threshold set on the plug'},
]
PLUG_COUNTER_TYPES = [c['type'] for c in PLUG_COUNTERS]
PLUG_RESET_FIELDS = {
    'aenergy': 'aenergy.total_rst_ts', 'ret_aenergy': 'ret_aenergy.total_rst_ts',
    'on_time': 'counts.on_time_rst_ts', 'switch_on': 'counts.switch_on_rst_ts',
    'on_above_thr': 'counts.on_above_thr_rst_ts',
}

PLUG_DESCRIPTIONS = {
    'switch.output': 'Relay output',
    'switch.apower': 'Active power (W)',
    'switch.voltage': 'Voltage (V)',
    'switch.current': 'Current (A)',
    'switch.pf': 'Power factor',
    'switch.freq': 'Line frequency (Hz)',
    'switch.aenergy.total': 'Energy consumed since the counters were reset (Wh)',
    'switch.ret_aenergy.total': 'Energy returned to the grid (Wh)',
    'switch.temperature.tC': 'Plug temperature (°C)',
    'switch.counts.on_time': 'Total runtime - time the relay has been on (s)',
    'switch.counts.switch_on': 'Switching cycles - times the relay has been switched on',
    'switch.counts.on_above_thr': 'Active load runtime - time above the plug threshold (s)',
    'sys.uptime': 'Plug uptime (s)',
    'sys.ram_free': 'Free RAM (bytes)',
    'wifi.rssi': 'Wi-Fi signal (dBm)',
    'wifi.sta_ip': 'Plug IP address',
    'wifi.ssid': 'Wi-Fi network',
    'cloud.connected': 'Shelly Cloud',
    'mqtt.connected': 'MQTT broker',
}
BINDING_ACTIONS = ['toggle', 'on', 'off', 'pulse']
RULE_OPS = ['>=', '<=', '>', '<']
RULE_COOLDOWN_DEFAULT = 300
PULSE_MS_DEFAULT = 5000
PULSE_MS_MIN, PULSE_MS_MAX = 100, 3600000
PLUG_HEADLINE = ['switch.apower', 'switch.aenergy.total', 'switch.output', 'switch.voltage']


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
# Readings are stored as (device, key, value) rows rather than in fixed
# columns, because what one sensor reports is not what the next one does.
# Full resolution is kept for a fortnight, hourly averages for two years; the
# latest complete payload of every device sits in `snapshots`.
SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    id          TEXT PRIMARY KEY,       -- IEEE address, or shelly:<name>
    name        TEXT NOT NULL,          -- friendly name (the MQTT topic)
    source      TEXT NOT NULL,          -- zigbee | shelly | mqtt
    kind        TEXT,                   -- EndDevice | Router | Coordinator | wifi
    model       TEXT,
    vendor      TEXT,
    description TEXT,
    exposes     TEXT,                   -- JSON: key -> {label, unit, description}
    first_seen  INTEGER,
    last_seen   INTEGER,
    removed     INTEGER NOT NULL DEFAULT 0,
    alias       TEXT                    -- a display name set on the dashboard
);

CREATE TABLE IF NOT EXISTS samples (
    ts      INTEGER NOT NULL,
    device  TEXT    NOT NULL,
    key     TEXT    NOT NULL,
    value   REAL,
    PRIMARY KEY (device, key, ts)
);
CREATE INDEX IF NOT EXISTS samples_ts ON samples (ts);

CREATE TABLE IF NOT EXISTS samples_hourly (
    ts      INTEGER NOT NULL,
    device  TEXT    NOT NULL,
    key     TEXT    NOT NULL,
    n       INTEGER,
    avg     REAL,
    min     REAL,
    max     REAL,
    PRIMARY KEY (device, key, ts)
);
CREATE INDEX IF NOT EXISTS samples_hourly_ts ON samples_hourly (ts);

CREATE TABLE IF NOT EXISTS snapshots (
    device  TEXT PRIMARY KEY,
    ts      INTEGER NOT NULL,
    payload TEXT NOT NULL,
    availability TEXT
);

CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      INTEGER NOT NULL,
    device  TEXT,
    kind    TEXT NOT NULL,
    level   TEXT,
    detail  TEXT
);
CREATE INDEX IF NOT EXISTS events_ts ON events (ts);
CREATE INDEX IF NOT EXISTS events_device_kind_ts ON events (device, kind, ts);

CREATE TABLE IF NOT EXISTS meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);
"""


class StorageError(Exception):
    pass


class Storage(object):
    def __init__(self, path=None):
        self.path = Path(path) if path else db_path()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        try:
            self.db = sqlite3.connect(str(self.path), check_same_thread=False,
                                      timeout=15, isolation_level=None)
        except sqlite3.OperationalError as e:
            raise StorageError('cannot open %s: %s' % (self.path, e))
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=NORMAL')
        self.db.executescript(SCHEMA)
        try:
            self.db.execute('ALTER TABLE devices ADD COLUMN alias TEXT')
        except sqlite3.OperationalError:
            pass                        # already there
        self.last_sample = {}     # (device, key) -> ts of the last row written

    # -- devices --------------------------------------------------------------
    def upsert_device(self, dev):
        now = int(time.time())
        with self.lock:
            row = self.db.execute('SELECT * FROM devices WHERE id=?', (dev['id'],)).fetchone()
            if row is None:
                self.db.execute(
                    'INSERT INTO devices (id,name,source,kind,model,vendor,description,'
                    'exposes,first_seen,last_seen,removed) VALUES (?,?,?,?,?,?,?,?,?,?,0)',
                    (dev['id'], dev['name'], dev['source'], dev.get('kind'), dev.get('model'),
                     dev.get('vendor'), dev.get('description'),
                     json.dumps(dev.get('exposes') or {}), now, dev.get('last_seen')))
                return 'new'
            changed = 'renamed' if row['name'] != dev['name'] else None
            self.db.execute(
                'UPDATE devices SET name=?,source=?,kind=COALESCE(?,kind),model=COALESCE(?,model),'
                'vendor=COALESCE(?,vendor),description=COALESCE(?,description),'
                'exposes=CASE WHEN ? THEN ? ELSE exposes END,removed=0 WHERE id=?',
                (dev['name'], dev['source'], dev.get('kind'), dev.get('model'), dev.get('vendor'),
                 dev.get('description'), 1 if dev.get('exposes') else 0,
                 json.dumps(dev.get('exposes') or {}), dev['id']))
            if changed:
                return changed
            return 'known'

    def mark_removed(self, device_id):
        with self.lock:
            self.db.execute('UPDATE devices SET removed=1 WHERE id=?', (device_id,))

    def touch_device(self, device_id, ts):
        with self.lock:
            self.db.execute('UPDATE devices SET last_seen=? WHERE id=?', (ts, device_id))

    def devices(self, include_removed=False):
        with self.lock:
            sql = 'SELECT * FROM devices' + ('' if include_removed else ' WHERE removed=0')
            rows = self.db.execute(sql + ' ORDER BY name COLLATE NOCASE').fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d['exposes'] = json.loads(d.get('exposes') or '{}')
            except ValueError:
                d['exposes'] = {}
            out.append(d)
        return out

    def device(self, device_id):
        with self.lock:
            r = self.db.execute('SELECT * FROM devices WHERE id=?', (device_id,)).fetchone()
        if r is None:
            return None
        d = dict(r)
        try:
            d['exposes'] = json.loads(d.get('exposes') or '{}')
        except ValueError:
            d['exposes'] = {}
        return d

    def resolve(self, name_or_id):
        """Accept an IEEE address, an id, a friendly name or a dashboard alias."""
        with self.lock:
            r = self.db.execute('SELECT id FROM devices WHERE id=? OR name=? COLLATE NOCASE '
                                'OR alias=? COLLATE NOCASE',
                                (name_or_id, name_or_id, name_or_id)).fetchone()
        return r['id'] if r else None

    def set_alias(self, device_id, alias):
        with self.lock:
            self.db.execute('UPDATE devices SET alias=? WHERE id=?', (alias or None, device_id))

    # -- readings -------------------------------------------------------------
    def store_sample(self, device_id, ts, values):
        """values: {key: float}. Honour sample_interval by replacing the row."""
        gap = int(CONFIG.get('sample_interval') or 0)
        with self.lock:
            for key, value in values.items():
                prev = self.last_sample.get((device_id, key))
                if prev is None:
                    r = self.db.execute('SELECT MAX(ts) AS ts FROM samples WHERE device=? AND key=?',
                                        (device_id, key)).fetchone()
                    prev = r['ts'] if r and r['ts'] is not None else 0
                if gap and prev and ts - prev < gap and prev != ts:
                    self.db.execute('UPDATE samples SET value=? WHERE device=? AND key=? AND ts=?',
                                    (value, device_id, key, prev))
                    continue
                self.db.execute('INSERT OR REPLACE INTO samples (ts,device,key,value) VALUES (?,?,?,?)',
                                (ts, device_id, key, value))
                self.last_sample[(device_id, key)] = ts

    def store_snapshot(self, device_id, ts, payload, availability=None):
        with self.lock:
            row = self.db.execute('SELECT payload, availability FROM snapshots WHERE device=?',
                                  (device_id,)).fetchone()
            merged = {}
            if row:
                try:
                    merged = json.loads(row['payload'])
                except ValueError:
                    merged = {}
                if availability is None:
                    availability = row['availability']
            merged.update(payload or {})
            self.db.execute('INSERT OR REPLACE INTO snapshots (device,ts,payload,availability) '
                            'VALUES (?,?,?,?)', (device_id, ts, json.dumps(merged), availability))
        return merged

    def snapshots(self):
        with self.lock:
            rows = self.db.execute('SELECT * FROM snapshots').fetchall()
        out = {}
        for r in rows:
            try:
                payload = json.loads(r['payload'])
            except ValueError:
                payload = {}
            out[r['device']] = {'ts': r['ts'], 'payload': payload,
                                'availability': r['availability']}
        return out

    def keys_for(self, device_id):
        with self.lock:
            a = self.db.execute('SELECT DISTINCT key FROM samples WHERE device=?', (device_id,)).fetchall()
            b = self.db.execute('SELECT DISTINCT key FROM samples_hourly WHERE device=?',
                                (device_id,)).fetchall()
        return sorted({r['key'] for r in a} | {r['key'] for r in b})

    def history(self, device_id, keys, seconds, points=600):
        """Rows of {ts, key1, key2, ...} mixing hourly data for the old part."""
        now = int(time.time())
        since = now - seconds
        full_from = now - int(CONFIG.get('retain_full_days', 14)) * 86400
        rows = {}
        with self.lock:
            for key in keys:
                if since < full_from:
                    for r in self.db.execute(
                            'SELECT ts, avg AS value, min, max FROM samples_hourly '
                            'WHERE device=? AND key=? AND ts>=? AND ts<? ORDER BY ts',
                            (device_id, key, since, full_from)):
                        rows.setdefault(r['ts'], {'ts': r['ts']})[key] = r['value']
                        rows[r['ts']][key + '_min'] = r['min']
                        rows[r['ts']][key + '_max'] = r['max']
                for r in self.db.execute(
                        'SELECT ts, value FROM samples WHERE device=? AND key=? AND ts>=? ORDER BY ts',
                        (device_id, key, max(since, full_from))):
                    rows.setdefault(r['ts'], {'ts': r['ts']})[key] = r['value']
        ordered = [rows[t] for t in sorted(rows)]
        return thin(ordered, points)

    # -- events ---------------------------------------------------------------
    on_event = None

    def add_event(self, kind, detail='', level='info', device=None, ts=None):
        if callable(self.on_event):
            try:
                self.on_event(kind, detail, level, device)
            except Exception:
                pass
        ts = ts or int(time.time())
        with self.lock:
            self.db.execute('INSERT INTO events (ts,device,kind,level,detail) VALUES (?,?,?,?,?)',
                            (ts, device, kind, level, detail))

    def events(self, limit=100, device=None):
        with self.lock:
            if device:
                rows = self.db.execute('SELECT * FROM events WHERE device=? ORDER BY ts DESC, id DESC '
                                       'LIMIT ?', (device, limit)).fetchall()
            else:
                rows = self.db.execute('SELECT * FROM events ORDER BY ts DESC, id DESC LIMIT ?',
                                       (limit,)).fetchall()
        return [dict(r) for r in rows]

    # -- maintenance: check, optimise, back up, restore -------------------------
    def latency(self):
        """Round-trip of a trivial read and a trivial write, in milliseconds."""
        with self.lock:
            t0 = time.perf_counter()
            self.db.execute('SELECT value FROM meta WHERE key=?', ('schema',)).fetchone()
            read_ms = (time.perf_counter() - t0) * 1000
            t0 = time.perf_counter()
            self.db.execute('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)', ('_latency_probe', str(int(time.time()))))
            self.db.commit()
            write_ms = (time.perf_counter() - t0) * 1000
        return {'read_ms': round(read_ms, 2), 'write_ms': round(write_ms, 2)}

    def integrity_check(self):
        with self.lock:
            rows = self.db.execute('PRAGMA integrity_check').fetchall()
            fk = self.db.execute('PRAGMA foreign_key_check').fetchall()
        lines = [r[0] for r in rows]
        ok = lines == ['ok'] and not fk
        return {'ok': ok, 'lines': lines[:20], 'foreign_key_problems': len(fk)}

    def optimize(self):
        before = db_path().stat().st_size if db_path().exists() else 0
        t0 = time.time()
        with self.lock:
            self.db.execute('PRAGMA optimize')
            self.db.execute('ANALYZE')
            self.db.commit()
            self.db.execute('VACUUM')
        after = db_path().stat().st_size if db_path().exists() else 0
        return {'before_bytes': before, 'after_bytes': after, 'seconds': round(time.time() - t0, 2)}

    def backup_to(self, target):
        """A consistent copy through SQLite's online backup API - safe while
        the daemon keeps writing."""
        import sqlite3
        with self.lock:
            dest = sqlite3.connect(str(target))
            try:
                self.db.backup(dest)
            finally:
                dest.close()
        return target.stat().st_size

    def restore_from(self, source):
        """Replace the live database's contents with a backup's, in place:
        the file stays open, callers keep their connection, the daemon's
        in-memory state re-syncs from the next poll and report."""
        import sqlite3
        src = sqlite3.connect(str(source))
        try:
            with self.lock:
                src.backup(self.db)
                self.db.commit()
        finally:
            src.close()

    def counter_delta(self, device_id, key, t0, t1):
        """How much a monotonic counter grew between two times: the sum of its
        positive steps, so a counter reset in between does not go negative."""
        with self.lock:
            rows = self.db.execute('SELECT ts, value FROM samples WHERE device=? AND key=? AND ts BETWEEN ? AND ? '
                                   'ORDER BY ts', (device_id, key, int(t0), int(t1))).fetchall()
            if len(rows) < 2:
                rows = self.db.execute('SELECT ts, avg AS value FROM samples_hourly WHERE device=? AND key=? '
                                       'AND ts BETWEEN ? AND ? ORDER BY ts',
                                       (device_id, key, int(t0), int(t1))).fetchall()
        total = 0.0
        previous = None
        for row in rows:
            value = row['value']
            if value is None:
                continue
            if previous is not None and value > previous:
                total += value - previous
            previous = value
        return round(total, 2)

    def last_action(self, device_id):
        """The most recent action this device sent, with when."""
        with self.lock:
            r = self.db.execute("SELECT detail, ts FROM events WHERE device=? AND kind='action' "
                                "ORDER BY ts DESC LIMIT 1", (device_id,)).fetchone()
        return {'action': r['detail'], 'ts': r['ts']} if r else None

    def actions_seen(self, device_id):
        """Every distinct action this device has ever reported, most recent first."""
        with self.lock:
            rows = self.db.execute("SELECT detail, MAX(ts) AS ts FROM events WHERE device=? AND kind='action' "
                                   "GROUP BY detail ORDER BY ts DESC", (device_id,)).fetchall()
        return [r['detail'] for r in rows if r['detail']]

    # -- meta -----------------------------------------------------------------
    def get_meta(self, key, default=None):
        with self.lock:
            r = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        return r['value'] if r else default

    def set_meta(self, key, value):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO meta (key,value) VALUES (?,?)', (key, str(value)))

    # -- housekeeping ---------------------------------------------------------
    def aggregate(self):
        """Roll full-resolution rows older than two hours into hourly buckets."""
        now = int(time.time())
        cutoff = (now // 3600) * 3600 - 7200
        done = 0
        with self.lock:
            r = self.db.execute("SELECT value FROM meta WHERE key='aggregated_to'").fetchone()
            start = int(r['value']) if r else 0
            if start >= cutoff:
                return 0
            self.db.execute('BEGIN')
            try:
                cur = self.db.execute(
                    'INSERT OR REPLACE INTO samples_hourly (ts,device,key,n,avg,min,max) '
                    'SELECT (ts/3600)*3600, device, key, COUNT(*), AVG(value), MIN(value), MAX(value) '
                    'FROM samples WHERE ts>=? AND ts<? GROUP BY device, key, ts/3600',
                    (start, cutoff))
                done = cur.rowcount if cur.rowcount is not None else 0
                self.db.execute("INSERT OR REPLACE INTO meta (key,value) VALUES ('aggregated_to',?)",
                                (str(cutoff),))
                full_days = int(CONFIG.get('retain_full_days', 14))
                hourly_days = int(CONFIG.get('retain_hourly_days', 730))
                event_days = int(CONFIG.get('retain_events_days', 730))
                self.db.execute('DELETE FROM samples WHERE ts<?', (now - full_days * 86400,))
                self.db.execute('DELETE FROM samples_hourly WHERE ts<?', (now - hourly_days * 86400,))
                self.db.execute('DELETE FROM events WHERE ts<?', (now - event_days * 86400,))
                self.db.execute('COMMIT')
            except Exception:
                self.db.execute('ROLLBACK')
                raise
        return done

    def reset(self, scope, device_id=None):
        """Erase recorded data. scope: all, history, events, device."""
        with self.lock:
            if scope == 'all':
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    self.db.execute('DELETE FROM %s' % table)
                self.db.execute("DELETE FROM meta WHERE key NOT IN ('bindings')")
                self.db.execute('DELETE FROM devices')
            elif scope == 'history':
                for table in ('samples', 'samples_hourly'):
                    self.db.execute('DELETE FROM %s' % table)
                self.db.execute("DELETE FROM meta WHERE key='aggregated_to'")
            elif scope == 'events':
                self.db.execute('DELETE FROM events')
            elif scope == 'device' and device_id:
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    self.db.execute('DELETE FROM %s WHERE device=?' % table, (device_id,))
                self.db.execute('DELETE FROM devices WHERE id=?', (device_id,))
            else:
                raise ValueError('unknown scope %r' % scope)
            self.last_sample.clear()
        try:
            self.db.execute('VACUUM')
        except sqlite3.OperationalError:
            pass

    def stats(self):
        with self.lock:
            out = {}
            for table in ('devices', 'samples', 'samples_hourly', 'events', 'snapshots'):
                out[table] = self.db.execute('SELECT COUNT(*) AS n FROM %s' % table).fetchone()['n']
            r = self.db.execute('SELECT MIN(ts) AS a FROM samples_hourly').fetchone()
            r2 = self.db.execute('SELECT MIN(ts) AS a FROM samples').fetchone()
            oldest = [x for x in (r['a'], r2['a']) if x]
            out['oldest'] = min(oldest) if oldest else None
        try:
            size = self.path.stat().st_size
            wal = self.path.with_name(self.path.name + '-wal')
            if wal.exists():
                size += wal.stat().st_size
            out['bytes'] = size
        except OSError:
            out['bytes'] = None
        out['path'] = str(self.path)
        return out


# ---------------------------------------------------------------------------
# MQTT
# ---------------------------------------------------------------------------
def make_mqtt_client(client_id, clean=True):
    """A paho client that works with both the 1.x and the 2.x API."""
    if mqtt is None:
        raise RuntimeError('python3-paho-mqtt is not installed')
    if hasattr(mqtt, 'CallbackAPIVersion'):
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id,
                             clean_session=clean)
    else:
        client = mqtt.Client(client_id=client_id, clean_session=clean)
    if CONFIG.get('mqtt_username'):
        client.username_pw_set(CONFIG['mqtt_username'], CONFIG.get('mqtt_password') or None)
    if CONFIG.get('mqtt_tls'):
        ca = CONFIG.get('mqtt_ca') or None
        if ca:
            client.tls_set(ca_certs=ca, cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)
        else:
            client.tls_set(cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLS_CLIENT)
            client.tls_insecure_set(True)
    client.reconnect_delay_set(min_delay=2, max_delay=60)
    return client


def reason_text(rc):
    """paho 1.x gives an int, 2.x a ReasonCode; both print sensibly."""
    try:
        if hasattr(rc, 'is_failure'):
            return str(rc)
        return mqtt.connack_string(rc) if mqtt else str(rc)
    except Exception:
        return str(rc)


def rc_failed(rc):
    if hasattr(rc, 'is_failure'):
        return rc.is_failure
    return int(rc) != 0


def exposes_map(definition):
    """Zigbee2MQTT's exposes tree -> {property: {label, unit, description, type}}."""
    out = {}

    def walk(items, prefix=''):
        for item in items or []:
            if not isinstance(item, dict):
                continue
            prop = item.get('property')
            if prop:
                name = (prefix + prop) if prefix else prop
                out[name] = {
                    'access': item.get('access'),
                    'label': item.get('label') or key_label(name),
                    'unit': item.get('unit') or key_unit(name),
                    'description': item.get('description') or '',
                    'type': item.get('type') or '',
                    'category': item.get('category') or '',
                    'values': item.get('values') or None,
                    'min': item.get('value_min'),
                    'max': item.get('value_max'),
                }
            if item.get('features'):
                sub = (prefix + prop + '.') if prop else prefix
                walk(item['features'], sub)

    if isinstance(definition, dict):
        walk(definition.get('exposes'))
    return out


class PlugState(object):
    """Everything the daemon remembers about one configured plug."""

    def __init__(self, name, cfg):
        self.name = name
        self.cfg = cfg
        self.device_id = 'plug:' + name
        self.info = None
        self.device_status = None
        self.last_device_status = 0.0
        self.last_poll = 0.0
        self.last_sample = 0.0
        self.backoff_until = 0.0
        self.failures = 0
        self.error = None
        self.output = None
        self.flat = {}
        self.generated = None
        self.pulsing = False
        self.pulse_lock = threading.Lock()

    def rpc(self):
        return ShellyRPC(self.cfg.get('host'), self.cfg.get('password') or '',
                         self.cfg.get('switch_id') or 0, label='plug %s' % self.name)


# ---------------------------------------------------------------------------
# The daemon
# ---------------------------------------------------------------------------
class Daemon(object):
    def __init__(self, storage=None):
        open_log()
        self.store = storage or Storage()
        self.lock = threading.Lock()
        self.token = self._ensure_token()
        self.started = time.time()
        self.connected = False
        self.last_connect = None
        self.last_disconnect = None
        self.connect_failures = 0
        self.last_error = None
        self.messages = 0
        self.last_message_at = None
        self.last_aggregate_at = 0.0
        self.bridge = {'state': None, 'version': None, 'coordinator': None,
                       'permit_join': None, 'permit_join_end': None, 'channel': None,
                       'pan_id': None, 'log_level': None, 'updated': None}
        self.names = {}          # friendly name -> device id (zigbee)
        self.live = {}           # device id -> {'payload', 'ts', 'availability'}
        self.pin_failures = 0
        self.pin_locked_until = 0.0
        self.sessions = {}       # unlock token -> {'until': ts, 'minutes': n}
        self.rule_runtime = {}   # rule id -> {'holds', 'fired', 'reading'}
        self.schedule_runtime = {}   # schedule id -> {'last_day'}
        self.file_config = dict(CONFIG)      # what config.json says, before overrides
        self.apply_config_overrides()
        threading.Thread(target=self.backup_loop, name='backup', daemon=True).start()
        # always on: gateway_configs() covers both config.json and dashboard
        # entries, and simply does nothing on an empty list either way
        threading.Thread(target=self.gateway_loop, name='gateway', daemon=True).start()
        warn_unknown_keys()
        self.notify_queue = []
        self.notify_sent = {}    # dedup key -> last ts
        self._notify_kick = threading.Event()
        threading.Thread(target=self.notify_loop, name='notify', daemon=True).start()
        self.store.on_event = self.consider_notifying
        try:
            self.parents = json.loads(self.store.get_meta('parents') or '{}')
        except ValueError:
            self.parents = {}
        self.seq = 0             # bumped on every visible change; /api/wait hangs on it
        self._change = threading.Condition()
        self.client = None
        self._stop = threading.Event()
        # Friendly name -> id, prefilled from the database so a report or a
        # retained availability message arriving before bridge/devices after a
        # restart does not spawn a duplicate "name:" placeholder.
        for known in self.store.devices(include_removed=True):
            if known['source'] == 'zigbee' and not known['id'].startswith('name:'):
                self.names.setdefault(known['name'], known['id'])
        self.plugs = {}          # name -> PlugState
        self.sensors = {}        # name -> PlugState, for Shelly sensors polled over RPC
        self.pushes_received = 0
        self.pushes_rejected = 0
        self.last_push_at = None
        self._plug_lock = threading.Lock()
        self.setup_plugs()
        self.setup_sensors()
        # What was recorded before the restart is the starting point, so the
        # dashboard is never blank while waiting for sleepy devices to report.
        for dev in self.store.devices():
            if dev['source'] == 'zigbee':
                self.names[dev['name']] = dev['id']
        for device_id, snap in self.store.snapshots().items():
            self.live[device_id] = snap

    # -- API token ----------------------------------------------------------
    def _ensure_token(self):
        token = None
        try:
            token = TOKEN_FILE.read_text().strip() or None
        except OSError:
            pass
        token = token or secrets.token_urlsafe(32)
        path = token_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(token)
            path.chmod(0o640)
            import grp
            import pwd
            info = path.stat()
            log('API token at %s (owner %s, group %s, mode %o)'
                % (path, pwd.getpwuid(info.st_uid).pw_name,
                   grp.getgrgid(info.st_gid).gr_name, info.st_mode & 0o777))
        except OSError as e:
            log('cannot write the API token to %s: %s - the privileged '
                'endpoints will refuse every request' % (path, e), 'error')
        return token

    # -- MQTT plumbing ------------------------------------------------------
    def connect(self):
        self.client = make_mqtt_client(CONFIG.get('mqtt_client_id') or 'zigmon')
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        if hasattr(self.client, 'on_connect_fail'):
            self.client.on_connect_fail = self._on_connect_fail
        host, port = CONFIG['mqtt_host'], int(CONFIG['mqtt_port'])
        log('connecting to mqtt://%s:%d as %s' % (host, port, CONFIG.get('mqtt_username') or 'anonymous'))
        try:
            self.client.connect_async(host, port, int(CONFIG.get('mqtt_keepalive') or 60))
        except (OSError, ValueError) as e:
            self.last_error = str(e)
            log('connect: %s' % e, 'error')
        self.client.loop_start()

    def topics(self):
        base = CONFIG['base_topic'].rstrip('/')
        wanted = [(base + '/#', 0)]
        for extra in CONFIG.get('extra_topics') or []:
            if extra and extra.rstrip('/') != base:
                wanted.append((extra, 0))
        seen = {t for t, _ in wanted}
        for prefix in self.plug_prefix_map():
            t = prefix + '/#'
            if t not in seen and not any(t.startswith(e.rstrip('#')) for e in seen):
                wanted.append((t, 0))
        return wanted

    def plug_prefix_map(self):
        """MQTT prefix -> the plug rows behind it (several for a multi-relay device)."""
        out = {}
        with self._plug_lock:
            for p in list(self.plugs.values()) + list(self.sensors.values()):
                prefix = str(p.cfg.get('mqtt_name') or '').strip().strip('/')
                if prefix:
                    out.setdefault(prefix, []).append(p)
        return out

    def _on_connect(self, client, userdata, flags, rc, *rest):
        if rc_failed(rc):
            self.connect_failures += 1
            self.last_error = 'connect refused: %s' % reason_text(rc)
            log(self.last_error, 'error')
            return
        self.connected = True
        self.last_connect = time.time()
        self.last_error = None
        client.subscribe(self.topics())
        log('connected; subscribed to %s' % ', '.join(t for t, _ in self.topics()))
        self.store.add_event('broker', 'connected to %s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port']))

    def _on_connect_fail(self, client, userdata, *rest):
        self.connect_failures += 1
        self.last_error = 'cannot reach the broker at %s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port'])
        # paho retries by itself; one line per minute is enough noise.
        if self.connect_failures in (1, 2) or self.connect_failures % 30 == 0:
            log(self.last_error + ' (attempt %d)' % self.connect_failures, 'warn')

    def _on_disconnect(self, client, userdata, *rest):
        # paho 2.x: (client, userdata, flags, reason_code, properties); 1.x: (client, userdata, rc)
        rc = rest[1] if len(rest) >= 2 else (rest[0] if rest else 0)
        was = self.connected
        self.connected = False
        self.last_disconnect = time.time()
        if was and not self._stop.is_set():
            self.last_error = 'broker connection lost (%s)' % reason_text(rc)
            log(self.last_error, 'warn')
            self.store.add_event('broker', 'connection lost', 'warn')

    def _on_message(self, client, userdata, msg):
        self.messages += 1
        self.last_message_at = time.time()
        try:
            self.handle(msg.topic, msg.payload)
        except Exception as e:      # one bad payload must never stop the feed
            log('handling %s: %s' % (msg.topic, e), 'error')

    # -- message routing ----------------------------------------------------
    def handle(self, topic, raw):
        base = CONFIG['base_topic'].rstrip('/')
        if topic == base or topic.startswith(base + '/'):
            rest = topic[len(base) + 1:] if topic != base else ''
            self.handle_zigbee(rest, raw)
            return
        parts = topic.split('/')
        prefixes = self.plug_prefix_map()
        for depth in range(min(3, len(parts) - 1), 0, -1):
            prefix = '/'.join(parts[:depth])
            if prefix in prefixes:
                self.handle_plug_push(prefixes[prefix], parts[depth:], raw)
                return
        if len(parts) >= 2:
            self.handle_generic(parts, raw)

    @staticmethod
    def decode(raw):
        text = raw.decode('utf-8', 'replace').strip() if isinstance(raw, bytes) else str(raw)
        if not text:
            return None
        if text[0] in '{[':
            try:
                return json.loads(text)
            except ValueError:
                return text
        return text

    def handle_zigbee(self, rest, raw):
        parts = rest.split('/')
        if not parts or not parts[0]:
            return
        if parts[0] == 'bridge':
            self.handle_bridge(parts[1:], raw)
            return
        name = parts[0]
        sub = parts[1] if len(parts) > 1 else ''
        if sub in ('set', 'get'):
            return
        payload = self.decode(raw)
        device_id = self.names.get(name)
        if sub == 'availability':
            state = payload.get('state') if isinstance(payload, dict) else payload
            if isinstance(state, str):
                self.set_availability(device_id or self.adopt_unknown(name), state.lower(), name)
            return
        if sub:
            return          # some other sub-topic we do not care about
        if not isinstance(payload, dict):
            return
        if device_id is None:
            device_id = self.adopt_unknown(name)
        self.record(device_id, name, payload)

    def adopt_unknown(self, name):
        """A device the bridge list has not told us about yet."""
        device_id = 'name:' + name
        self.names[name] = device_id
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'zigbee',
                                      'kind': None, 'exposes': {}})
            log('device "%s" seen before the bridge listed it' % name)
        return device_id

    def handle_bridge(self, parts, raw):
        what = parts[0] if parts else ''
        payload = self.decode(raw)
        now = int(time.time())
        if what == 'state':
            state = payload.get('state') if isinstance(payload, dict) else payload
            state = str(state).lower() if state is not None else None
            old = self.bridge['state']
            self.bridge['state'] = state
            self.bridge['updated'] = now
            if old != state:
                log('bridge is %s' % state)
                if old is not None or state != 'online':
                    self.store.add_event('bridge', 'Zigbee2MQTT is %s' % state,
                                         'info' if state == 'online' else 'crit')
        elif what == 'response' and len(parts) > 1 and parts[1] == 'networkmap':
            self.handle_networkmap(payload)
        elif what == 'response' and len(parts) > 1 and parts[1] == 'backup':
            self.handle_zigbee_backup(payload)
        elif what == 'info' and isinstance(payload, dict):
            coord = payload.get('coordinator') or {}
            meta = coord.get('meta') or {}
            net = payload.get('network') or {}
            self.bridge.update({
                'version': payload.get('version'),
                'coordinator': ('%s %s' % (coord.get('type') or '', meta.get('revision') or '')).strip() or None,
                'coordinator_ieee': coord.get('ieee_address'),
                'permit_join': payload.get('permit_join'),
                'permit_join_end': payload.get('permit_join_end'),
                'channel': net.get('channel'),
                'pan_id': net.get('pan_id'),
                'log_level': payload.get('log_level'),
                'updated': now,
            })
        elif what == 'devices' and isinstance(payload, list):
            self.sync_devices(payload)
        elif what == 'event' and isinstance(payload, dict):
            self.bridge_event(payload)
        elif what == 'logging' and isinstance(payload, dict):
            level = str(payload.get('level') or '').lower()
            if level in ('error',):
                self.store.add_event('bridge', str(payload.get('message') or '')[:300], 'warn')
        # request/response/definitions/groups/extensions: nothing to record

    def sync_devices(self, devices):
        seen = set()
        for d in devices:
            if not isinstance(d, dict):
                continue
            ieee = d.get('ieee_address')
            name = d.get('friendly_name') or ieee
            if not ieee or not name:
                continue
            if d.get('type') == 'Coordinator':
                self.bridge['coordinator_name'] = name
                continue
            definition = d.get('definition') or {}
            dev = {
                'id': ieee, 'name': name, 'source': 'zigbee',
                'kind': d.get('type'),
                'model': definition.get('model') or d.get('model_id'),
                'vendor': definition.get('vendor') or d.get('manufacturer'),
                'description': definition.get('description'),
                'exposes': exposes_map(definition),
                'power_source': d.get('power_source'),
            }
            seen.add(ieee)
            # A device that reported before the list arrived was filed under
            # its name; move that history across now that we know its address.
            placeholder = 'name:' + name
            if self.store.device(placeholder):
                self.migrate(placeholder, ieee)
            old_name = None
            for n, i in list(self.names.items()):
                if i == ieee and n != name:
                    old_name = n
                    del self.names[n]
            self.names[name] = ieee
            outcome = self.store.upsert_device(dev)
            if outcome == 'new':
                log('new device: %s (%s %s)' % (name, dev['vendor'] or '', dev['model'] or ''))
                self.store.add_event('device', 'added: %s %s' % (dev['vendor'] or '', dev['model'] or ''),
                                     'info', ieee)
            elif outcome == 'renamed':
                log('device renamed: %s -> %s' % (old_name or '?', name))
                self.store.add_event('device', 'renamed from "%s" to "%s"' % (old_name or '?', name),
                                     'info', ieee)
        for dev in self.store.devices():
            if dev['source'] != 'zigbee':
                continue
            if dev['id'].startswith('name:'):
                # A leftover placeholder from an earlier version or a race:
                # if the bridge list names that device, fold it in now.
                real = self.names.get(dev['name'])
                if real and real != dev['id'] and not real.startswith('name:'):
                    self.migrate(dev['id'], real)
                continue
            if dev['id'] not in seen:
                self.store.mark_removed(dev['id'])
                self.names.pop(dev['name'], None)
                log('device left: %s' % dev['name'])
                self.store.add_event('device', 'removed from the network', 'warn', dev['id'])

    def migrate(self, old_id, new_id):
        """Fold one device row into another: rename when the target does not
        exist yet, merge and delete the leftover when it does."""
        with self.store.lock:
            for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                self.store.db.execute('UPDATE OR REPLACE %s SET device=? WHERE device=?' % table,
                                      (new_id, old_id))
            target = self.store.db.execute('SELECT first_seen FROM devices WHERE id=?', (new_id,)).fetchone()
            if target is None:
                self.store.db.execute('UPDATE OR REPLACE devices SET id=? WHERE id=?', (new_id, old_id))
            else:
                old_row = self.store.db.execute('SELECT first_seen, alias FROM devices WHERE id=?',
                                                (old_id,)).fetchone()
                if old_row:
                    if old_row['first_seen'] and (not target['first_seen']
                                                  or old_row['first_seen'] < target['first_seen']):
                        self.store.db.execute('UPDATE devices SET first_seen=? WHERE id=?',
                                              (old_row['first_seen'], new_id))
                    if old_row['alias']:
                        self.store.db.execute('UPDATE devices SET alias=COALESCE(alias,?) WHERE id=?',
                                              (old_row['alias'], new_id))
                self.store.db.execute('DELETE FROM devices WHERE id=?', (old_id,))
            self.store.last_sample.clear()
        if old_id in self.live:
            merged = self.live.pop(old_id)
            self.live.setdefault(new_id, merged)
        log('history recorded under "%s" now belongs to %s' % (old_id[5:], new_id))
        self.bump()

    def bridge_event(self, payload):
        kind = payload.get('type') or ''
        data = payload.get('data') or {}
        name = data.get('friendly_name') or data.get('ieee_address')
        ieee = data.get('ieee_address')
        if kind == 'device_joined':
            self.store.add_event('device', 'joined the network', 'info', ieee)
            log('device joined: %s' % name)
        elif kind == 'device_leave':
            self.store.add_event('device', 'left the network', 'warn', ieee)
            log('device left: %s' % name)
        elif kind == 'device_interview':
            status = data.get('status')
            if status == 'successful':
                d = data.get('definition') or {}
                self.store.add_event('device', 'interviewed: %s %s' % (d.get('vendor') or '',
                                     d.get('model') or ''), 'info', ieee)
            elif status == 'failed':
                self.store.add_event('device', 'interview failed', 'warn', ieee)
        elif kind == 'device_announce':
            self.store.add_event('device', 'announced itself', 'info', ieee)

    def set_availability(self, device_id, state, name):
        prev = (self.live.get(device_id) or {}).get('availability')
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': None, 'availability': None})
        entry['availability'] = state
        self.store.store_snapshot(device_id, entry['ts'] or int(time.time()), {}, state)
        if prev != state and prev is not None:
            level = 'warn' if state == 'offline' else 'info'
            self.store.add_event('availability', state, level, device_id)
            log('%s is %s' % (name, state))

    def record(self, device_id, name, payload):
        now = int(time.time())
        flat = flatten(payload)
        values = {}
        for key, value in flat.items():
            if key in IGNORE_KEYS or key.startswith('update'):
                continue
            if key == 'action':
                if value not in (None, ''):
                    # the relay first, the paperwork after: a binding is the one
                    # thing here a person is physically waiting on
                    self.fire_bindings(device_id, name, str(value))
                    self.store.add_event('action', str(value), 'info', device_id, now)
                    log('%s: %s' % (name, value), 'debug')
                continue
            v = numeric(value)
            if v is not None:
                values[key] = v
        if values:
            self.fire_rules(device_id, name, values)     # motion -> light must not wait for a disk commit
            self.store.store_sample(device_id, now, values)
        clean = {k: v for k, v in flat.items() if not k.startswith('update')}
        merged = self.store.store_snapshot(device_id, now, clean)
        self.store.touch_device(device_id, now)
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': None, 'availability': None})
        entry['payload'] = merged
        entry['ts'] = now
        # A device that reports is by definition reachable.
        if entry.get('availability') == 'offline':
            self.set_availability(device_id, 'online', name)
        log('%s: %s' % (name, ', '.join('%s=%s' % kv for kv in sorted(values.items()))), 'debug')
        self.bump()

    def handle_plug_push(self, plugs, rest, raw):
        """The plug's own MQTT tells us the moment its relay changes - a wall
        button, its web page, the Shelly app - so the dashboard does not sit
        on the 15 s poll for state it can have now."""
        payload = self.decode(raw)
        if not isinstance(payload, dict):
            return
        updates = {}
        if rest == ['events', 'rpc'] and payload.get('method') == 'NotifyStatus':
            for key, value in (payload.get('params') or {}).items():
                m = re.match(r'^switch:(\d+)$', key)
                if m and isinstance(value, dict):
                    updates[int(m.group(1))] = value
        elif len(rest) == 2 and rest[0] == 'status':
            m = re.match(r'^switch:(\d+)$', rest[1])
            if m:
                updates[int(m.group(1))] = payload
        if not updates:
            return
        now = int(time.time())
        for p in plugs:
            value = updates.get(int(p.cfg.get('switch_id') or 0))
            if value is None:
                continue
            changed = False
            if 'output' in value:
                output = 1 if value.get('output') else 0
                if p.output is not None and output != p.output:
                    source = str(value.get('source') or 'outside this dashboard')
                    self.store.add_event('plug', 'switched %s (%s)' % ('on' if output else 'off', source),
                                         'info', p.device_id)
                    log('%s switched %s (%s, seen on its MQTT)' % (p.name, 'on' if output else 'off', source))
                    changed = True
                p.output = output
            if p.flat:
                for k, v in flatten(value).items():
                    if k in ('id', 'source'):
                        continue
                    p.flat['switch.' + k] = v
                p.generated = now
            entry = self.live.get(p.device_id)
            if entry:
                entry['ts'] = now
            if changed:
                self.bump()

    def handle_generic(self, parts, raw):
        """shellies/<name>/status/<component> and similar: a WiFi device."""
        payload = self.decode(raw)
        if not isinstance(payload, dict):
            return
        prefix, name = parts[0], parts[1]
        rest = parts[2:]
        if name in self.plug_mqtt_names():
            return          # polled over RPC; the MQTT copy would only duplicate it
        if rest and rest[0] == 'status' and len(rest) >= 2:
            component = rest[1]              # temperature:0, switch:0, devicepower:0
            comp_name = component.split(':')[0]
            multiple = component.split(':')[1] if ':' in component and component.split(':')[1] != '0' else ''
            keyed = {}
            for k, v in flatten(payload).items():
                if k in ('id',):
                    continue
                key = k if comp_name in ('temperature', 'humidity', 'devicepower', 'illuminance') \
                    else '%s.%s' % (comp_name, k)
                if multiple:
                    key = '%s%s.%s' % (comp_name, multiple, k)
                keyed[key] = v
            payload = keyed
        elif rest and rest[0] in ('events', 'rpc', 'online', 'command'):
            if rest[0] == 'online':
                state = 'online' if str(payload).lower() in ('true', '1', 'online') else 'offline'
                device_id = '%s:%s' % (prefix, name)
                if self.store.device(device_id):
                    self.set_availability(device_id, state, name)
            return
        elif rest:
            return
        device_id = '%s:%s' % (prefix, name)
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'shelly'
                                      if prefix == 'shellies' else 'mqtt', 'kind': 'wifi',
                                      'vendor': 'Shelly' if prefix == 'shellies' else None,
                                      'exposes': {}})
            log('new device: %s (%s)' % (name, prefix))
            self.store.add_event('device', 'first seen on %s/%s' % (prefix, name), 'info', device_id)
        self.record(device_id, name, payload)


    # -- settings tunable from the dashboard --------------------------------------
    TUNABLE = {
        'battery_warn': (0, 100), 'battery_crit': (0, 100),
        'lqi_warn': (0, 255), 'lqi_crit': (0, 255),
        'stale_warn_min': (1, 100000), 'stale_crit_min': (1, 100000),
        'temperature_min': (-100, 200, True), 'temperature_max': (-100, 200, True),
        'humidity_max': (0, 100, True),
        'plug_poll_interval': (2, 3600), 'plug_sample_interval': (10, 86400),
        'plug_min_request_gap': (0, 10), 'plug_command_gap': (0, 10),
        'sample_interval': (0, 86400), 'networkmap_interval': (0, 86400),
        'price_per_kwh': (0, 1000, True),
        'latitude': (-90, 90, True), 'longitude': (-180, 180, True),
        'backup_enabled': (0, 1), 'backup_keep': (1, 365), 'backup_zigbee': (0, 1),
        'chart_outages': (0, 1), 'link_plugs': (0, 1), 'link_sensors': (0, 1), 'link_buttons': (0, 1),
        'backup_time': 'str',
        'currency': 'str', 'notify_ntfy': 'str',
        'notify_telegram_token': 'str', 'notify_telegram_chat': 'str',
    }

    def config_overrides(self):
        try:
            return {k: v for k, v in json.loads(self.store.get_meta('config_overrides') or '{}').items()
                    if k in self.TUNABLE}
        except ValueError:
            return {}

    def apply_config_overrides(self):
        for key, value in self.config_overrides().items():
            CONFIG[key] = value

    def save_config_overrides(self, body):
        overrides = self.config_overrides()
        changed = []
        for key, spec in self.TUNABLE.items():
            if key not in body:
                continue
            raw = body.get(key)
            if spec == 'str':
                value = str(raw or '').strip()[:200]
                if key == 'notify_ntfy' and value and not value.startswith(('http://', 'https://')):
                    raise ValueError('notify_ntfy must be a full topic URL (https://ntfy.sh/...)')
                if key == 'backup_time' and not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', value or ''):
                    raise ValueError('backup_time must look like 03:30')
            else:
                low, high = spec[0], spec[1]
                allow_null = len(spec) > 2
                value = numeric(raw)
                if value is None:
                    if raw not in (None, '') or not allow_null:
                        if not allow_null:
                            raise ValueError('%s must be a number' % key)
                    value = None
                elif not low <= value <= high:
                    raise ValueError('%s must be between %g and %g' % (key, low, high))
                if value is not None and value == int(value) and key not in ('latitude', 'longitude', 'price_per_kwh', 'plug_min_request_gap', 'plug_command_gap'):
                    value = int(value)
            previous = CONFIG.get(key)
            if value == self.file_config.get(key):
                overrides.pop(key, None)     # back to what the file says
            else:
                overrides[key] = value
            CONFIG[key] = value
            if value != previous:
                changed.append(key)
        self.store.set_meta('config_overrides', json.dumps(overrides))
        if changed:
            self.store.add_event('control', 'settings changed: ' + ', '.join(sorted(changed)))
            log('settings changed: %s' % ', '.join(sorted(changed)))
        self.bump()
        return changed

    def runtime_config(self):
        overrides = self.config_overrides()
        out = {}
        for key in self.TUNABLE:
            out[key] = {'value': CONFIG.get(key), 'file': self.file_config.get(key),
                        'overridden': key in overrides}
        return out

    # -- notifications: ntfy and/or Telegram ------------------------------------
    # what a per-device preset switches on (None = follow the global choices)

    def notify_channels(self):
        out = []
        if CONFIG.get('notify_ntfy'):
            out.append('ntfy')
        if CONFIG.get('notify_telegram_token') and CONFIG.get('notify_telegram_chat'):
            out.append('telegram')
        return out

    def notify_settings(self):
        try:
            saved = json.loads(self.store.get_meta('notify') or '{}')
        except ValueError:
            saved = {}
        devices = saved.get('devices') or {}
        return {'crit': bool(saved.get('crit', True)), 'warn': bool(saved.get('warn', False)),
                'rule': bool(saved.get('rule', False)), 'offline': bool(saved.get('offline', True)),
                'switch': bool(saved.get('switch', False)),
                'devices': {str(k): v for k, v in devices.items()
                            if notify_override_set(v) is not None}}

    def consider_notifying(self, kind, detail, level, device_id):
        if not self.notify_channels():
            return
        settings = self.notify_settings()
        name = None
        if device_id:
            row = self.store.device(device_id)
            name = (row.get('alias') or row['name']) if row else device_id
        offline_ish = 'lost contact' in detail or 'offline' in detail or 'went quiet' in detail \
            or 'unreachable' in detail or 'back online' in detail or 'reporting again' in detail
        switch_ish = kind in ('plug', 'switch') and ('switched' in detail or detail.startswith('set ') or detail.startswith('pulse'))
        rule_ish = kind == 'rule' and 'window' not in detail
        override = settings['devices'].get(device_id or '')
        enabled = notify_override_set(override) if override else None
        if enabled is None:
            enabled = {k for k in ('crit', 'warn', 'offline', 'rule', 'switch') if settings.get(k)}
        wanted = (level == 'crit' and 'crit' in enabled) \
            or (level == 'warn' and 'warn' in enabled) \
            or (offline_ish and 'offline' in enabled) \
            or (rule_ish and 'rule' in enabled) \
            or (switch_ish and 'switch' in enabled)
        if not wanted:
            return
        self.notify(('%s: %s' % (name, detail)) if name else detail, level, dedup='%s|%s|%s' % (kind, device_id, detail[:40]))

    def notify(self, message, level='info', dedup=None):
        now = time.time()
        if dedup:
            if now - self.notify_sent.get(dedup, 0) < 900:
                return                       # the same story inside 15 min stays untold
            self.notify_sent[dedup] = now
        self.notify_queue.append({'message': message, 'level': level})
        self._notify_kick.set()

    def notify_loop(self):
        import urllib.request
        while True:
            self._notify_kick.wait()
            self._notify_kick.clear()
            while self.notify_queue:
                item = self.notify_queue.pop(0)
                title = {'crit': 'PROBLEM', 'warn': 'Warning'}.get(item['level'], 'zigmon')
                if CONFIG.get('notify_ntfy'):
                    try:
                        req = urllib.request.Request(CONFIG['notify_ntfy'], data=item['message'].encode(),
                                                     headers={'Title': title,
                                                              'Priority': 'high' if item['level'] == 'crit' else 'default',
                                                              'Tags': 'rotating_light' if item['level'] == 'crit' else 'house'})
                        urllib.request.urlopen(req, timeout=10).read()
                    except Exception as e:
                        log('ntfy: %s' % e, 'warn')
                token, chat = CONFIG.get('notify_telegram_token'), CONFIG.get('notify_telegram_chat')
                if token and chat:
                    try:
                        body = json.dumps({'chat_id': str(chat), 'text': '%s\n%s' % (title, item['message'])}).encode()
                        req = urllib.request.Request('https://api.telegram.org/bot%s/sendMessage' % token,
                                                     data=body, headers={'Content-Type': 'application/json'})
                        urllib.request.urlopen(req, timeout=10).read()
                    except Exception as e:
                        log('telegram: %s' % e, 'warn')

    def bump(self):
        """Something the dashboard shows has changed; wake every /api/wait."""
        with self._change:
            self.seq += 1
            self._change.notify_all()

    def wait_for_change(self, since, timeout):
        deadline = time.time() + max(0.5, min(30.0, timeout))
        with self._change:
            while self.seq <= since and not self._stop.is_set():
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                self._change.wait(min(1.0, remaining))
        return self.seq

    # -- plugs and sensors: from config.json and from the dashboard ------------
    def managed(self):
        """The UI-managed entries, kept in the database."""
        raw = self.store.get_meta('managed')
        if not raw:
            return {'plugs': [], 'sensors': []}
        try:
            data = json.loads(raw)
        except ValueError:
            return {'plugs': [], 'sensors': []}
        return {'plugs': [e for e in data.get('plugs') or [] if isinstance(e, dict)],
                'sensors': [e for e in data.get('sensors') or [] if isinstance(e, dict)]}

    def all_entries(self, kind):
        """config.json entries first (read-only in the UI), then the managed ones."""
        out = []
        seen = set()
        for entry in CONFIG.get(kind) or []:
            if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
                e = dict(entry, source='config', enabled=bool(entry.get('enabled', True)))
                out.append(e)
                seen.add(str(entry['name']))
        for entry in self.managed().get(kind) or []:
            if entry.get('name') and entry.get('host') and str(entry['name']) not in seen:
                out.append(dict(entry, source='ui', enabled=bool(entry.get('enabled', True))))
                seen.add(str(entry['name']))
        return out

    def active_entries(self, kind):
        return [e for e in self.all_entries(kind) if e.get('enabled', True)]

    def plug_names_all(self):
        """Every configured plug name, enabled or not - for validating bindings and rules."""
        return {e['name'] for e in self.all_entries('plugs')}

    def managed_for_ui(self):
        """Entries without passwords - only whether one is set."""
        def strip(e):
            return {'name': str(e['name']), 'host': str(e['host']), 'password_set': bool(e.get('password')),
                    'switch_id': int(e.get('switch_id') or 0), 'mqtt_name': str(e.get('mqtt_name') or ''),
                    'source': e.get('source', 'ui'), 'enabled': bool(e.get('enabled', True)),
                    'monitor_only': bool(e.get('monitor_only', False))}
        return {'plugs': [strip(e) for e in self.all_entries('plugs')],
                'sensors': [strip(e) for e in self.all_entries('sensors')]}

    def save_managed(self, plugs, sensors):
        """Validate, keep passwords the UI did not resend, store, rebuild the live state."""
        old = {}
        old_by_addr = {}
        for kind in ('plugs', 'sensors'):
            for e in self.managed().get(kind) or []:
                old[(kind, str(e['name']))] = e
                old_by_addr[(str(e.get('host') or ''), int(e.get('switch_id') or 0))] = e
        config_names = {str(e['name']) for kind in ('plugs', 'sensors') for e in (CONFIG.get(kind) or [])
                        if isinstance(e, dict) and e.get('name')}
        clean = {'plugs': [], 'sensors': []}
        names = set()
        for kind, items in (('plugs', plugs), ('sensors', sensors)):
            for index, e in enumerate(items or []):
                if not isinstance(e, dict):
                    continue
                if e.get('source') == 'config':
                    continue                      # those live in config.json, not here
                name = str(e.get('name') or '').strip()
                host = str(e.get('host') or '').strip()
                if not name or not host:
                    raise ValueError('%s %d needs a name and an address' % (kind[:-1], index + 1))
                if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', name):
                    raise ValueError('"%s": letters, digits, space, dot, dash and underscore only' % name)
                if name in names or name in config_names:
                    raise ValueError('the name "%s" is used twice' % name)
                if not re.match(r'^[A-Za-z0-9.:\[\]-]+$', host):
                    raise ValueError('"%s" is not an address' % host)
                names.add(name)
                entry = {'name': name, 'host': host,
                         'switch_id': max(0, min(7, int(e.get('switch_id') or 0))),
                         'mqtt_name': str(e.get('mqtt_name') or '').strip(),
                         'enabled': bool(e.get('enabled', True)),
                         'monitor_only': bool(e.get('monitor_only', False))}
                password = e.get('password')
                if password is None or password == '':
                    # a renamed row is still the same box: fall back to its address
                    previous = old.get((kind, name)) \
                        or old.get(('plugs' if kind == 'sensors' else 'sensors', name)) \
                        or old_by_addr.get((host, entry['switch_id'])) or {}
                    entry['password'] = previous.get('password') or ''
                    if e.get('clear_password'):
                        entry['password'] = ''
                else:
                    entry['password'] = str(password)
                clean[kind].append(entry)
        self.store.set_meta('managed', json.dumps(clean))
        self.reload_devices()
        self.store.add_event('control', '%d plug(s) and %d sensor(s) configured from the dashboard'
                             % (len(clean['plugs']), len(clean['sensors'])))
        log('device list saved from the dashboard: %s' % ', '.join(
            [e['name'] for e in clean['plugs']] + [e['name'] for e in clean['sensors']]) or 'nothing')
        return self.managed_for_ui()

    def reload_devices(self):
        """Rebuild self.plugs / self.sensors from config + managed, keeping live state where the entry is unchanged."""
        with self._plug_lock:
            wanted = {e['name']: e for e in self.active_entries('plugs')}
            known = {e['name'] for e in self.all_entries('plugs')}
            for name in list(self.plugs):
                if name not in wanted:
                    self.store.mark_removed('plug:' + name)
                    self.live.pop('plug:' + name, None)
                    del self.plugs[name]
                    if name in known:
                        log('plug disabled: %s (its history stays; enable it to carry on)' % name)
                        self.store.add_event('plug', 'disabled from the dashboard', 'warn', 'plug:' + name)
                    else:
                        log('plug removed: %s' % name)
            for name, entry in wanted.items():
                current = self.plugs.get(name)
                if current and current.cfg.get('host') == entry.get('host') \
                        and current.cfg.get('password', '') == entry.get('password', '') \
                        and int(current.cfg.get('switch_id') or 0) == int(entry.get('switch_id') or 0):
                    current.cfg = entry
                    continue
                self.plugs[name] = PlugState(name, entry)
                self.store.upsert_device({'id': 'plug:' + name, 'name': name, 'source': 'plug', 'kind': 'wifi',
                                          'vendor': 'Shelly', 'exposes': {}})
                remembered = self.store.get_meta('plug_info_' + name)
                if remembered and not current:
                    try:
                        self.plugs[name].info = json.loads(remembered)
                    except ValueError:
                        pass
                if not current:
                    log('plug added: %s (%s)' % (name, entry.get('host')))
            wanted = {e['name']: e for e in self.active_entries('sensors')}
            known = {e['name'] for e in self.all_entries('sensors')}
            for name in list(self.sensors):
                if name not in wanted:
                    self.store.mark_removed('sensor:' + name)
                    self.live.pop('sensor:' + name, None)
                    del self.sensors[name]
                    log('sensor %s: %s' % ('disabled' if name in known else 'removed', name))
            for name, entry in wanted.items():
                current = self.sensors.get(name)
                if current and current.cfg.get('host') == entry.get('host') \
                        and current.cfg.get('password', '') == entry.get('password', ''):
                    current.cfg = entry
                    continue
                self.sensors[name] = PlugState(name, entry)
                self.sensors[name].device_id = 'sensor:' + name
                self.store.upsert_device({'id': 'sensor:' + name, 'name': name, 'source': 'shelly',
                                          'kind': 'wifi', 'vendor': 'Shelly', 'exposes': {}})
                if not current:
                    log('sensor added: %s (%s)' % (name, entry.get('host')))
        if self.connected and self.client:
            try:
                self.client.subscribe(self.topics())
            except Exception as e:
                log('resubscribe: %s' % e, 'warn')
        # the polling thread starts lazily when the first device appears
        if (self.plugs or self.sensors) and not getattr(self, '_plug_thread', None):
            self._plug_thread = threading.Thread(target=self.plug_loop, name='plugs', daemon=True)
            if getattr(self, '_running', False):
                self._plug_thread.start()

    def test_device(self, host, password=''):
        """One Shelly.GetDeviceInfo, so the dashboard can check an address before saving it."""
        rpc = ShellyRPC(host, password or '', 0, label='the device at %s' % host)
        info = rpc.device_info()
        out = {'ok': True, 'id': info.get('id'), 'model': info.get('model'), 'app': info.get('app'),
               'ver': info.get('ver'), 'gen': info.get('gen'), 'auth': bool(info.get('auth_en')),
               'name': info.get('name')}
        try:
            status = rpc.device_status() or {}
            out['components'] = sorted(k for k in status if ':' in k)
            out['kind'] = 'plug' if any(k.startswith('switch:') for k in status) else 'sensor'
        except PlugError:
            out['components'] = []
            out['kind'] = 'plug' if (info.get('app') or '').lower().startswith('plug') else 'sensor'
        return out

    def discover_devices(self, seconds=3.0):
        found = shelly_discover(Palette(False), seconds)
        known = {e['host'].split(':')[0] for kind in ('plugs', 'sensors') for e in self.all_entries(kind)}
        return [{'ip': ip, 'names': r['names'], 'known': ip in known} for ip, r in sorted(found.items())]

    # -- smart plugs ---------------------------------------------------------
    def setup_plugs(self):
        """One PlugState per plug from config.json and the dashboard; stale rows for plugs that are gone."""
        configured = set()
        for entry in self.active_entries('plugs'):
            name = str(entry['name'])
            configured.add(name)
            self.plugs[name] = PlugState(name, entry)
            device_id = 'plug:' + name
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'plug', 'kind': 'wifi',
                                      'vendor': 'Shelly', 'exposes': {}})
            remembered = self.store.get_meta('plug_info_' + name)
            if remembered:
                try:
                    self.plugs[name].info = json.loads(remembered)
                except ValueError:
                    pass
        disabled = {e['name'] for e in self.all_entries('plugs') if not e.get('enabled', True)}
        for dev in self.store.devices():
            if dev['source'] == 'plug' and dev['name'] not in configured:
                self.store.mark_removed(dev['id'])
                if dev['name'] in disabled:
                    log('plug disabled: %s' % dev['name'])

    def plug_mqtt_names(self):
        names = set()
        for p in self.plugs.values():
            if p.cfg.get('mqtt_name'):
                names.add(p.cfg['mqtt_name'])
            if p.info and p.info.get('id'):
                names.add(p.info['id'])
        return names

    def purge_per_device(self):
        """A device row may carry its own retain_full_days (shorter than the
        global one) - chatty plugs need not fill two weeks of raw samples."""
        for p in list(self.plugs.values()) + list(self.sensors.values()):
            days = numeric(p.cfg.get('retain_full_days'))
            if not days or days <= 0:
                continue
            cutoff = int(time.time() - days * 86400)
            with self.store.lock:
                gone = self.store.db.execute('DELETE FROM samples WHERE device=? AND ts<?',
                                             (p.device_id, cutoff)).rowcount
                self.store.db.commit()
            if gone:
                log('%s: %d old sample(s) dropped (retain %g d)' % (p.name, gone, days), 'debug')

    def backup_dir(self):
        return db_path().parent / 'backups'

    def db_backups(self):
        directory = self.backup_dir()
        if not directory.exists():
            return []
        out = []
        for f in sorted(directory.glob('zigmon-db-*.sqlite'), reverse=True):
            st = f.stat()
            out.append({'file': f.name, 'bytes': st.st_size, 'ts': int(st.st_mtime)})
        return out

    def db_backup_now(self, suffix=''):
        directory = self.backup_dir()
        directory.mkdir(exist_ok=True)
        target = directory / ('zigmon-db-%s%s.sqlite' % (time.strftime('%Y-%m-%d-%H%M%S'), suffix))
        n = 1
        while target.exists():                 # two in one second: never overwrite
            n += 1
            target = directory / ('zigmon-db-%s%s-%d.sqlite' % (time.strftime('%Y-%m-%d-%H%M%S'), suffix, n))
        size = self.store.backup_to(target)
        keep = int(CONFIG.get('backup_keep') or 14)
        for f in sorted(directory.glob('zigmon-db-*.sqlite'))[:-keep]:
            f.unlink()
        self.store.add_event('control', 'database backed up: %s (%.1f MB)' % (target.name, size / 1048576.0))
        log('database backed up to %s' % target)
        return {'file': target.name, 'bytes': size}

    def db_restore(self, filename):
        if not re.match(r'^zigmon-db-[0-9A-Za-z-]+\.sqlite$', str(filename)):
            raise ValueError('not a database backup file name')
        source = self.backup_dir() / filename
        if not source.exists():
            raise ValueError('no such backup')
        pre = self.db_backup_now('-before-restore')   # the state right before, in case this was a mistake
        self.store.restore_from(source)
        self.rule_runtime.clear()
        self.parents = {}
        self.reload_devices()
        self.store.add_event('control', 'database restored from %s (previous state kept as %s)' % (filename, pre['file']), 'warn')
        log('database restored from %s' % filename, 'warn')
        self.bump()
        return {'restored': filename, 'previous_saved_as': pre['file']}

    def run_backup(self):
        """The daily backup: the dashboard settings as JSON, and (when asked)
        Zigbee2MQTT's own coordinator backup - the file that lets a dead stick
        be replaced without repairing every device."""
        directory = self.backup_dir()
        directory.mkdir(exist_ok=True)
        stamp_day = time.strftime('%Y-%m-%d')
        target = directory / ('zigmon-settings-%s.json' % stamp_day)
        made = []
        if not target.exists():
            target.write_text(json.dumps(self.export_settings(), indent=1))
            made.append(target.name)
        if int(CONFIG.get('backup_zigbee') or 0) and self.connected and self.client \
                and self.bridge.get('state') == 'online' \
                and not (directory / ('zigbee2mqtt-%s.zip' % stamp_day)).exists():
            self.client.publish(CONFIG['base_topic'].rstrip('/') + '/bridge/request/backup', '{}', qos=1)
        keep = int(CONFIG.get('backup_keep') or 14)
        for pattern in ('zigmon-settings-*.json', 'zigbee2mqtt-*.zip'):
            for f in sorted(directory.glob(pattern))[:-keep]:
                f.unlink()
        if made:
            log('backed up: %s' % ', '.join(made))
            self.store.add_event('control', 'backup written: ' + ', '.join(made))

    def handle_zigbee_backup(self, payload):
        data = (payload.get('data') or {}) if isinstance(payload, dict) else {}
        blob = data.get('zip')
        if not blob:
            return
        try:
            import base64
            directory = self.backup_dir()
            directory.mkdir(exist_ok=True)
            target = directory / ('zigbee2mqtt-%s.zip' % time.strftime('%Y-%m-%d'))
            target.write_bytes(base64.b64decode(blob))
            log('Zigbee2MQTT coordinator backup written to %s' % target)
            self.store.add_event('control', 'Zigbee2MQTT backup written: ' + target.name)
        except Exception as e:
            log('zigbee backup: %s' % e, 'warn')

    def backup_loop(self):
        while getattr(self, '_stop', None) is None:
            time.sleep(0.5)                  # the constructor is still at work
        last_day = None
        while not self._stop.wait(300):
            try:
                if not int(CONFIG.get('backup_enabled') or 0):
                    continue
                lt = time.localtime()
                when = str(CONFIG.get('backup_time') or '03:30')
                due = lt.tm_hour * 60 + lt.tm_min >= int(when[:2]) * 60 + int(when[3:])
                today = time.strftime('%Y-%m-%d')
                if due and last_day != today:
                    last_day = today
                    self.run_backup()
            except Exception as e:
                log('backup: %s' % e, 'warn')

    def request_networkmap(self):
        """Ask Zigbee2MQTT for the raw map. The answer tells us which router
        or coordinator each device is actually talking through."""
        if not self.connected or not self.client or self.bridge.get('state') != 'online':
            return
        topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/networkmap'
        try:
            self.client.publish(topic, json.dumps({'type': 'raw', 'routes': False}), qos=0)
            log('network map requested', 'debug')
        except Exception as e:
            log('network map request: %s' % e, 'warn')

    def handle_networkmap(self, payload):
        value = ((payload.get('data') or {}).get('value')) if isinstance(payload, dict) else None
        if not isinstance(value, dict):
            return
        nodes = {n.get('ieeeAddr'): n for n in value.get('nodes') or [] if isinstance(n, dict)}
        parents = {}
        for link in value.get('links') or []:
            if not isinstance(link, dict):
                continue
            source = link.get('sourceIeeeAddr') or (link.get('source') or {}).get('ieeeAddr')
            target = link.get('targetIeeeAddr') or (link.get('target') or {}).get('ieeeAddr')
            if not source or not target:
                continue
            relationship = link.get('relationship')
            lqi = link.get('linkquality') or link.get('lqi')
            # In the scanned device's neighbour table: 1 = the neighbour is its
            # child, 0 = the neighbour is its parent.
            if relationship == 1:
                parents[source] = {'parent': target, 'lqi': lqi}
            elif relationship == 0:
                parents.setdefault(target, {'parent': source, 'lqi': lqi})
        now = int(time.time())
        table = {}
        for ieee, info in parents.items():
            node = nodes.get(info['parent']) or {}
            table[ieee] = {'parent': info['parent'],
                           'parent_type': node.get('type') or '',
                           'lqi': info['lqi'], 'ts': now}
        self.parents = table
        self.store.set_meta('parents', json.dumps(table))
        log('network map: %d parent relation(s)' % len(table))
        self.bump()

    def check_rule_for(self):
        """A "must hold for N s" rule whose source went quiet still fires once
        the stretch is long enough - no motion for ten minutes IS the event."""
        now = time.time()
        for r in self.rules():
            wait_s = int(r.get('for_s') or 0)
            if not wait_s or not r.get('enabled', True) or not self.rule_window_active(r):
                continue
            rt = self.rule_runtime.get(r['id'])
            if not rt or rt.get('holds') is not True or 'since' not in rt:
                continue
            if now - rt['since'] < wait_s or rt.get('for_fired') == rt['since']:
                continue
            if now - rt['fired'] < int(r.get('cooldown_s') or 0):
                continue
            if self._rate_limited(r, rt):
                continue
            rt['fired'] = now
            rt['for_fired'] = rt['since']
            origin = '%s %s held %d s (now %s)' % (
                self.store.resolve(r['device']) and (self.store.device(r['device']) or {}).get('name', r['device']) or r['device'],
                '%s %s %g' % (r['key'], r['op'], r['value']), wait_s,
                '%g' % rt['reading'] if rt.get('reading') is not None else '?')
            for target in self._binding_targets(r['plug']):
                pretty = self.target_label(r['plug'])
                log('rule (held): %s -> %s %s' % (origin, pretty, r['do']))
                self.store.add_event('rule', '%s: %s %s' % (origin, pretty, r['do']), 'info', r['device'])
                self._fire_target(target, r['do'], 'rule: ' + origin, r.get('pulse_ms'))

    def check_rule_windows(self):
        """Once a minute: notice windows opening and closing. Closing can put
        the plug into a safe state - a motion-driven light does not stay on
        into the morning just because nobody walked past at the boundary."""
        for r in self.rules():
            if not r.get('enabled', True) or not r.get('from'):
                continue
            active = self.rule_window_active(r)
            rt = self.rule_runtime.setdefault(r['id'], {'holds': None, 'fired': 0.0, 'reading': None})
            was = rt.get('window')
            rt['window'] = active
            if was is None or was == active:
                continue
            rt['holds'] = None               # a fresh edge inside the new window fires again
            what = r.get('window_end') if not active else None
            self.store.add_event('rule', 'window %s: %s %s %g -> %s%s' % (
                'opened' if active else 'closed', r['key'], r['op'], r['value'], r['plug'],
                (' (switching %s)' % what) if what else ''), 'info')
            if active or what not in ('off', 'on'):
                continue
            for target in self._binding_targets(r['plug']):
                if target[0] in ('scene', 'seq', 'seqreset'):
                    continue                 # a scene/sequence has no "off"; leave it be
                log('rule window closed: %s -> %s' % (self.target_label(r['plug']), what))
                self._fire_target(target, what, 'the rule window closing')

    def plug_loop(self):
        last_window_check = 0.0
        last_map = time.time() - max(0, int(CONFIG.get('networkmap_interval') or 0)) + 45
        while not self._stop.is_set():
            if time.time() - last_window_check >= 30:
                last_window_check = time.time()
                try:
                    self.check_rule_windows()
                    self.check_rule_for()
                    self.check_schedules()
                except Exception as e:
                    log('rule windows: %s' % e, 'error')
                interval = int(CONFIG.get('networkmap_interval') or 0)
                if interval > 0 and time.time() - last_map >= interval:
                    last_map = time.time()
                    self.request_networkmap()
            if not self.plugs and not self.sensors:
                self._stop.wait(5)
                continue
            for p in list(self.plugs.values()):
                if self._stop.is_set():
                    break
                try:
                    self.poll_plug(p)
                except Exception as e:      # never let one plug stop the others
                    log('plug %s: %s' % (p.name, e), 'error')
            for s in list(self.sensors.values()):
                if self._stop.is_set():
                    break
                try:
                    self.poll_sensor(s)
                except Exception as e:
                    log('sensor %s: %s' % (s.name, e), 'error')
            self._stop.wait(max(2, int(CONFIG.get('plug_poll_interval') or 15)))

    def poll_plug(self, p, force=False):
        """Read one plug and record it."""
        now = time.time()
        if not force and (now - p.last_poll < int(CONFIG.get('plug_poll_interval') or 15)
                          or now < p.backoff_until):
            return p
        p.last_poll = now
        rpc = p.rpc()
        try:
            switch = rpc.switch_status()
            # System, Wi-Fi and cloud sections change slowly and cost a whole
            # extra request; a Gen3 plug answers 429 when asked too often.
            if now - p.last_device_status >= 60 or not p.device_status:
                p.device_status = rpc.device_status()
                p.last_device_status = now
            if not p.info:
                p.info = rpc.device_info()
                self.store.set_meta('plug_info_' + p.name, json.dumps(p.info))
        except PlugError as e:
            p.failures += 1
            p.error = str(e)
            if p.failures == 3:
                self.store.add_event('plug', 'lost contact: %s' % e, 'warn', p.device_id)
                self.store.store_snapshot(p.device_id, int(now), {}, 'offline')
                self.bump()
            if '429' in str(e):
                p.backoff_until = now + max(getattr(rpc, 'retry_after', 0) or 0, 60)
                log('%s is rate limiting; backing off for %ds' % (p.name, int(p.backoff_until - now)),
                    'warn' if p.failures == 3 else 'debug')
            else:
                log('plug %s poll failed: %s' % (p.name, e), 'warn' if p.failures <= 3 else 'debug')
            return p
        if p.failures >= 3:
            self.store.add_event('plug', 'contact restored', 'info', p.device_id)
            self.bump()
        p.failures = 0
        p.error = None
        p.backoff_until = 0.0

        flat = {}
        for k, v in flatten(switch).items():
            if k in ('id', 'source') or k.startswith('aenergy.by_minute') or k.startswith('ret_aenergy.by_minute'):
                continue
            flat['switch.' + k] = v
        dev = flatten(p.device_status)
        for k in ('wifi.rssi', 'wifi.sta_ip', 'wifi.ssid', 'sys.uptime', 'sys.ram_free',
                  'cloud.connected', 'mqtt.connected'):
            if k in dev:
                flat[k] = dev[k]
        output = 1 if switch.get('output') else 0
        changed = p.output is None or output != p.output
        if p.output is not None and output != p.output:
            self.store.add_event('plug', 'switched %s' % ('on' if output else 'off'),
                                 'info', p.device_id)
        p.output = output
        p.flat = flat
        p.generated = int(now)

        values = {}
        for k in ('switch.output', 'switch.apower', 'switch.voltage', 'switch.current', 'switch.pf',
                  'switch.freq', 'switch.aenergy.total', 'switch.ret_aenergy.total',
                  'switch.temperature.tC', 'switch.counts.on_time', 'switch.counts.switch_on',
                  'switch.counts.on_above_thr', 'wifi.rssi', 'sys.uptime'):
            v = numeric(flat.get(k)) if k in flat else None
            if v is not None:
                values[k] = v
        if values and now - p.last_sample >= int(CONFIG.get('plug_sample_interval') or 60):
            self.store.store_sample(p.device_id, int(now), values)
            p.last_sample = now
        if values:
            self.fire_rules(p.device_id, p.name, values)
        self.store.store_snapshot(p.device_id, int(now), flat, 'online')
        self.store.touch_device(p.device_id, int(now))
        info = p.info or {}
        self.store.upsert_device({
            'id': p.device_id, 'name': p.name, 'source': 'plug', 'kind': 'wifi', 'vendor': 'Shelly',
            'model': info.get('model'),
            'description': ' '.join(x for x in (info.get('app'), info.get('ver')) if x) or None,
            'exposes': {k: {'label': key_label(k), 'unit': key_unit(k), 'description': PLUG_DESCRIPTIONS.get(k, '')}
                        for k in flat},
        })
        self.live[p.device_id] = {'payload': flat, 'ts': int(now), 'availability': 'online'}
        if changed:
            self.bump()
        return p

    def plug_snapshot(self, p):
        """What the dashboard needs about one plug."""
        now = time.time()
        stale = p.error is not None
        flat = p.flat
        if not flat:
            snap = self.live.get(p.device_id) or {}
            flat = snap.get('payload') or {}
            generated = snap.get('ts')
        else:
            generated = p.generated
        counters = []
        for c in PLUG_COUNTERS:
            value = numeric(flat.get('switch.' + c['field'])) if ('switch.' + c['field']) in flat else None
            reset_at, exact = self._counter_reset_at(p, flat, c['type'])
            counters.append(dict(c, value=value, reset_at=reset_at, reset_exact=exact))
        return {
            'name': p.name, 'id': p.device_id, 'host': p.cfg.get('host'),
            'online': bool(flat), 'stale': stale or not p.flat,
            'error': p.error if stale else (None if p.flat else 'waiting for the first reading'),
            'generated': generated, 'age': int(now - generated) if generated else None,
            'retry_in': int(p.backoff_until - now) if p.backoff_until > now else None,
            'output': (1 if flat.get('switch.output') else 0) if 'switch.output' in flat else None,
            'monitor_only': bool(p.cfg.get('monitor_only')),
            'values': {
                'power': numeric(flat.get('switch.apower')) if 'switch.apower' in flat else None,
                'voltage': numeric(flat.get('switch.voltage')) if 'switch.voltage' in flat else None,
                'current': numeric(flat.get('switch.current')) if 'switch.current' in flat else None,
                'pf': numeric(flat.get('switch.pf')) if 'switch.pf' in flat else None,
                'freq': numeric(flat.get('switch.freq')) if 'switch.freq' in flat else None,
                'energy': numeric(flat.get('switch.aenergy.total')) if 'switch.aenergy.total' in flat else None,
                'temperature': numeric(flat.get('switch.temperature.tC')) if 'switch.temperature.tC' in flat else None,
                'on_time': numeric(flat.get('switch.counts.on_time')) if 'switch.counts.on_time' in flat else None,
                'switch_on': numeric(flat.get('switch.counts.switch_on')) if 'switch.counts.switch_on' in flat else None,
                'rssi': numeric(flat.get('wifi.rssi')) if 'wifi.rssi' in flat else None,
                'uptime': numeric(flat.get('sys.uptime')) if 'sys.uptime' in flat else None,
            },
            'info': p.info or {},
            'counters': counters,
        }

    def _counter_reset_at(self, p, flat, counter):
        reported = numeric(flat.get('switch.' + PLUG_RESET_FIELDS[counter], None)) \
            if ('switch.' + PLUG_RESET_FIELDS[counter]) in flat else None
        if reported and reported > 1000000000:
            return int(reported), True
        remembered = self.store.get_meta('plug_reset_%s_%s' % (p.name, counter))
        if remembered:
            return int(float(remembered)), True
        return None, False

    def plug_by_name(self, name):
        p = self.plugs.get(str(name or ''))
        if p is None:
            for candidate in self.plugs.values():
                if candidate.device_id == name or candidate.name.lower() == str(name or '').lower():
                    return candidate
        return p

    @staticmethod
    def _monitor_guard(p):
        if p is not None and bool(p.cfg.get('monitor_only')):
            return False, '%s is monitor-only: watched, recorded, never switched from here' % p.name
        return True, ''

    def _plug_switched(self, p, on, origin):
        """The relay just obeyed: show it at once, confirm the numbers later.
        The dashboard repaints on this bump; the power/energy figures follow
        from a background poll a moment later, without anyone waiting for it."""
        p.output = 1 if on else 0           # so the confirming poll does not log it again
        if p.flat is not None:
            p.flat['switch.output'] = bool(on)
        entry = self.live.get(p.device_id)
        if entry:
            entry['ts'] = int(time.time())
        self.store.add_event('plug', 'switched %s from %s' % ('on' if on else 'off', origin),
                             'info', p.device_id)
        log('%s switched %s (%s)' % (p.name, 'on' if on else 'off', origin))
        self.bump()
        threading.Thread(target=self._confirm_poll, args=(p,), name='confirm', daemon=True).start()

    def _confirm_poll(self, p):
        try:
            self.poll_plug(p, force=True)
        except Exception as e:
            log('%s: confirming poll failed: %s' % (p.name, e), 'debug')

    def set_plug_output(self, p, on, origin='the dashboard'):
        ok, message = self._monitor_guard(p)
        if not ok:
            log('refused (%s): %s' % (origin, message), 'debug')
            return False, message
        try:
            p.rpc().set_output(on)
        except PlugError as e:
            self.store.add_event('plug', 'switch %s failed: %s' % ('on' if on else 'off', e), 'warn', p.device_id)
            return False, str(e)
        self._plug_switched(p, on, origin)
        return True, '%s switched %s' % (p.name, 'on' if on else 'off')

    def pulse_plug(self, p, ms, origin='the dashboard'):
        ok, message = self._monitor_guard(p)
        if not ok:
            return False, message
        """Flip the relay, hold for ms, flip it back: off-wait-on when it is on, on-wait-off when off."""
        ms = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(ms or PULSE_MS_DEFAULT)))
        fresh = p.output in (0, 1) and p.flat and not p.failures and p.generated \
            and time.time() - p.generated < int(CONFIG.get('plug_poll_interval') or 15) * 2
        if fresh:
            state = bool(p.output)          # fresh from the last poll or push: no extra round trip
        else:
            try:
                state = bool(p.rpc().switch_status().get('output'))
            except PlugError as e:
                return False, str(e)
        with p.pulse_lock:
            if p.pulsing:
                return False, '%s is already in a pulse' % p.name
            p.pulsing = True
        try:
            try:
                p.rpc().set_output(not state)
            except PlugError as e:
                self.store.add_event('plug', 'pulse failed: %s' % e, 'warn', p.device_id)
                return False, str(e)
            p.output = 0 if state else 1
            self.store.add_event('plug', 'pulse: switched %s for %s from %s' % (
                'off' if state else 'on', '%.1f s' % (ms / 1000.0), origin), 'info', p.device_id)
            self.bump()
            log('%s pulse: %s for %d ms (%s)' % (p.name, 'off' if state else 'on', ms, origin))
            self.poll_plug(p, force=True)
            self._stop.wait(ms / 1000.0)
            last = None
            for attempt in range(3):          # the way back must not be lost
                try:
                    p.rpc().set_output(state)
                    last = None
                    break
                except PlugError as e:
                    last = e
                    time.sleep(1.0)
            if last is not None:
                self.store.add_event('plug', 'pulse: could not switch back %s: %s' % ('on' if state else 'off', last),
                                     'crit', p.device_id)
                log('%s pulse: switching back failed: %s' % (p.name, last), 'error')
                return False, 'pulse sent, but switching back failed: %s' % last
            p.output = 1 if state else 0
            self.store.add_event('plug', 'pulse: back %s' % ('on' if state else 'off'),
                                 'info' if state else 'warn', p.device_id)
            self.poll_plug(p, force=True)
            self.bump()
            return True, '%s pulsed %s for %.1f s and is back %s' % (
                p.name, 'off' if state else 'on', ms / 1000.0, 'on' if state else 'off')
        finally:
            p.pulsing = False

    def toggle_plug(self, p, origin='the dashboard'):
        ok, message = self._monitor_guard(p)
        if not ok:
            return False, message
        try:
            reply = p.rpc().toggle_output() or {}
        except PlugError as e:
            self.store.add_event('plug', 'toggle failed: %s' % e, 'warn', p.device_id)
            return False, str(e)
        on = not bool(reply.get('was_on'))
        self._plug_switched(p, on, origin)
        return True, '%s switched %s' % (p.name, 'on' if on else 'off')

    def read_plug_counters(self, p, attempts=2):
        last = None
        for _ in range(attempts):
            try:
                flat = flatten(p.rpc().switch_status())
                break
            except PlugError as e:
                last = e
                time.sleep(1.5)
        else:
            raise last or PlugError('could not read the counters')
        return {c['type']: numeric(flat.get(c['field'])) if c['field'] in flat else None
                for c in PLUG_COUNTERS}

    def reset_plug_counters(self, p, types=None):
        """Reset counters and check they actually moved - the plug says OK regardless."""
        wanted = [t for t in (types or []) if t in PLUG_COUNTER_TYPES]
        try:
            before = self.read_plug_counters(p)
        except PlugError as e:
            return False, 'could not read the counters first: %s' % e
        try:
            p.rpc().reset_counters(wanted or None)
        except PlugError as e:
            return False, str(e)
        time.sleep(1.0)
        try:
            after = self.read_plug_counters(p)
        except PlugError as e:
            self.store.add_event('plug', 'reset requested but the result could not be checked: %s' % e,
                                 'warn', p.device_id)
            return True, 'the reset was sent, but the plug did not answer when asked to confirm it'
        checked = wanted or PLUG_COUNTER_TYPES
        labels = {c['type']: c['label'] for c in PLUG_COUNTERS}
        cleared, unchanged, already = [], [], []
        for counter in checked:
            was, now = before.get(counter), after.get(counter)
            if was is None and now is None:
                continue
            if now is not None and now == 0:
                (already if was in (0, None) else cleared).append(labels[counter])
            elif was is not None and now is not None and now < was:
                cleared.append(labels[counter])
            else:
                unchanged.append(labels[counter])
        stamped = int(time.time())
        for counter in checked:
            if labels[counter] in cleared:
                self.store.set_meta('plug_reset_%s_%s' % (p.name, counter), stamped)
        self.poll_plug(p, force=True)
        if cleared:
            message = 'reset ' + ', '.join(c.lower() for c in cleared)
            if unchanged:
                message += '; the plug did not clear ' + ', '.join(u.lower() for u in unchanged)
            self.store.add_event('plug', message, 'info', p.device_id)
            return True, message
        if already and not unchanged:
            return True, ', '.join(a.lower() for a in already) + ' was already at zero'
        message = ('the plug accepted the request but nothing changed: '
                   + ', '.join(u.lower() for u in unchanged or checked)
                   + '. This firmware may not support resetting those.')
        self.store.add_event('plug', message, 'warn', p.device_id)
        return False, message

    def rename_device(self, device_id, new_name):
        """A Zigbee device is renamed in Zigbee2MQTT itself, so the name holds
        everywhere; anything else gets a dashboard alias. Bindings and rules
        keep working either way - they store the id, not the name."""
        dev = self.store.device(device_id)
        if dev is None:
            raise ValueError('unknown device')
        new_name = str(new_name or '').strip()
        if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', new_name):
            raise ValueError('letters, digits, space, dot, dash and underscore only')
        if dev['source'] in ('plug',) or device_id.startswith('sensor:'):
            raise ValueError('this one is named in "Plugs and sensors"; rename it there')
        old = dev.get('alias') or dev['name']
        if dev['source'] == 'zigbee':
            if not self.connected or not self.client:
                raise RuntimeError('not connected to the broker')
            topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/device/rename'
            info = self.client.publish(topic, json.dumps({'from': dev['name'], 'to': new_name}), qos=1)
            if hasattr(info, 'rc') and info.rc != 0:
                raise RuntimeError('publish failed (%s) - check the broker ACL for %s' % (info.rc, topic))
            # Zigbee2MQTT confirms via bridge/devices; the row is updated now so
            # the dashboard does not flicker with the old name meanwhile.
            self.store.upsert_device({'id': device_id, 'name': new_name, 'source': dev['source']})
            message = 'renamed to %s (in Zigbee2MQTT, so the MQTT topic follows)' % new_name
        else:
            self.store.set_alias(device_id, new_name)
            message = 'renamed to %s on this dashboard (the MQTT name stays %s)' % (new_name, dev['name'])
        self.store.add_event('device', 'renamed %s -> %s' % (old, new_name), 'info', device_id)
        log('device %s %s' % (old, message))
        self.bump()
        return message

    def forget_device_cleanup(self, device_id, name):
        """Take the deleted device out of the bindings and rules that use it as
        the source - unless it is a managed plug or sensor, which comes right
        back. Plugs used as *targets* stay: the plug itself was not deleted."""
        if any(device_id == 'plug:' + e['name'] for e in self.all_entries('plugs')) \
                or any(device_id == 'sensor:' + e['name'] for e in self.all_entries('sensors')):
            return []
        dropped = []
        keep = []
        for b in self.bindings():
            if b['device'] in (device_id, name):
                dropped.append('binding: %s %s -> %s %s' % (name, b['action'], b['plug'], b['do']))
            else:
                keep.append(b)
        if dropped:
            self.store.set_meta('bindings', json.dumps(keep))
        keep = []
        rule_dropped = 0
        for r in self.rules():
            if r['device'] in (device_id, name):
                dropped.append('rule: %s %s %s %g -> %s %s' % (name, r['key'], r['op'], r['value'], r['plug'], r['do']))
                self.rule_runtime.pop(r['id'], None)
                rule_dropped += 1
            else:
                keep.append(r)
        if rule_dropped:
            self.store.set_meta('rules', json.dumps(keep))
        for line in dropped:
            self.store.add_event('control', 'removed with the device - ' + line, 'warn')
            log('removed with %s: %s' % (name, line))
        return dropped

    def overview_order(self):
        raw = self.store.get_meta('overview_order')
        if not raw:
            return {'plugs': [], 'devices': [], 'sensors': [], 'buttons': [], 'groups': {}}
        try:
            data = json.loads(raw)
        except ValueError:
            return {'plugs': [], 'devices': [], 'sensors': [], 'buttons': [], 'groups': {}}
        groups = data.get('groups') or {}
        return {'plugs': [str(x) for x in (data.get('plugs') or [])][:200],
                'devices': [str(x) for x in (data.get('devices') or [])][:200],
                'sensors': [str(x) for x in (data.get('sensors') or [])][:200],
                'buttons': [str(x) for x in (data.get('buttons') or [])][:200],
                'groups': {str(k): [str(x) for x in (v or [])][:50] for k, v in list(groups.items())[:100]}}

    def save_overview_order(self, plugs, devices, groups=None, sensors=None, buttons=None):
        def clean(items):
            out = []
            for x in items or []:
                x = str(x)[:80]
                if x and x not in out:
                    out.append(x)
            return out[:200]
        current = self.overview_order()
        order = {'plugs': clean(plugs) if plugs is not None else current['plugs'],
                 'devices': clean(devices) if devices is not None else current['devices'],
                 'sensors': clean(sensors) if sensors is not None else current['sensors'],
                 'buttons': clean(buttons) if buttons is not None else current['buttons']}
        if groups is not None:
            order['groups'] = {str(k)[:80]: clean(v) for k, v in list(groups.items())[:100]}
        else:
            order['groups'] = current.get('groups') or {}
        self.store.set_meta('overview_order', json.dumps(order))
        log('overview order saved: %d plug(s), %d card(s)' % (len(order['plugs']), len(order['devices'])))
        self.bump()
        return order

    # -- one file with everything the dashboard configured ------------------------
    def export_settings(self):
        aliases = {d['id']: d['alias'] for d in self.store.devices(include_removed=True) if d.get('alias')}
        return {'zigmon_export': __version__, 'exported_at': int(time.time()),
                'managed': self.managed(), 'bindings': self.bindings(), 'rules': self.rules(),
                'scenes': self.scenes(), 'schedules': self.schedules(), 'sequences': self.sequences(),
                'sequence_pos': self.sequence_positions(), 'order': self.overview_order(),
                'overview_layout': self.overview_layout(),
            'gateways': self.gateways_for_ui(),
                'notify': self.notify_settings(), 'aliases': aliases}

    def import_settings(self, data):
        if not isinstance(data, dict) or 'zigmon_export' not in data:
            raise ValueError('this is not a zigmon export')
        counts = []
        if isinstance(data.get('managed'), dict):
            self.store.set_meta('managed', json.dumps(data['managed']))
            self.reload_devices()
            counts.append('%d device(s)' % (len(data['managed'].get('plugs') or []) + len(data['managed'].get('sensors') or [])))
        for key, label in (('bindings', 'binding(s)'), ('rules', 'rule(s)'), ('scenes', 'scene(s)'), ('schedules', 'schedule(s)'), ('sequences', 'sequence(s)')):
            if isinstance(data.get(key), list):
                self.store.set_meta(key, json.dumps(data[key]))
                counts.append('%d %s' % (len(data[key]), label))
        if isinstance(data.get('order'), dict):
            self.store.set_meta('overview_order', json.dumps(data['order']))
        if isinstance(data.get('sequence_pos'), dict):
            self.store.set_meta('sequence_pos', json.dumps(data['sequence_pos']))
        if isinstance(data.get('overview_layout'), list):
            self.store.set_meta('overview_layout', json.dumps([str(x)[:80] for x in data['overview_layout']][:300]))
        if isinstance(data.get('notify'), dict):
            self.store.set_meta('notify', json.dumps(data['notify']))
        for device_id, alias in (data.get('aliases') or {}).items():
            if self.store.device(device_id):
                self.store.set_alias(device_id, str(alias))
        self.rule_runtime.clear()
        self.store.add_event('control', 'settings imported: ' + (', '.join(counts) or 'nothing'))
        log('settings imported: %s' % (', '.join(counts) or 'nothing'))
        self.bump()
        return counts

    # -- energy: what each plug drank, and what it cost ---------------------------
    def energy_summary(self):
        now = time.time()
        lt = time.localtime(now)
        midnight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
        month_start = time.mktime((lt.tm_year, lt.tm_mon, 1, 0, 0, 0, 0, 0, -1))
        last_month_start = time.mktime((lt.tm_year - (1 if lt.tm_mon == 1 else 0),
                                        12 if lt.tm_mon == 1 else lt.tm_mon - 1, 1, 0, 0, 0, 0, 0, -1))
        year_start = time.mktime((lt.tm_year, 1, 1, 0, 0, 0, 0, 0, -1))
        last_year_start = time.mktime((lt.tm_year - 1, 1, 1, 0, 0, 0, 0, 0, -1))
        price = numeric(CONFIG.get('price_per_kwh'))
        zero = self.energy_zero()
        out = []
        for p in self.plugs.values():
            base = zero.get(p.device_id) or 0

            def span(t0, t1):
                if t1 <= base:
                    return 0.0
                return self.store.counter_delta(p.device_id, 'switch.aenergy.total', max(t0, base), t1)
            row = {'name': p.name,
                   'today_wh': span(midnight, now),
                   'yesterday_wh': span(midnight - 86400, midnight),
                   'month_wh': span(month_start, now),
                   'last_month_wh': span(last_month_start, month_start),
                   'year_wh': span(year_start, now),
                   'last_year_wh': span(last_year_start, year_start),
                   'zero_ts': int(base) or None}
            out.append(row)
        return {'plugs': out, 'price_per_kwh': price, 'currency': CONFIG.get('currency') or ''}

    def energy_zero(self):
        try:
            data = json.loads(self.store.get_meta('energy_zero') or '{}')
        except ValueError:
            data = {}
        return {str(k): float(v) for k, v in data.items() if numeric(v)}

    def reset_energy_summary(self, plug_name):
        """Start the dashboard's energy sums from zero, now - for one plug or
        all of them. Recorded history and the plug's own meters stay."""
        zero = self.energy_zero()
        now = time.time()
        if plug_name == '*':
            names = []
            for p in self.plugs.values():
                zero[p.device_id] = now
                names.append(p.name)
            label = 'every plug' if names else 'nothing'
        else:
            p = self.plug_by_name(plug_name)
            if p is None:
                raise ValueError('unknown plug %r' % plug_name)
            zero[p.device_id] = now
            label = p.name
        self.store.set_meta('energy_zero', json.dumps(zero))
        self.store.add_event('control', 'energy summary restarted from zero: %s' % label)
        log('energy summary zeroed: %s' % label)
        self.bump()
        return label

    # -- the curated Overview: any mix of plugs, sensors and buttons, freely chosen -
    def overview_layout(self):
        """None means "no custom layout yet" - the dashboard falls back to
        showing everything, so a fresh install looks exactly as before."""
        raw = self.store.get_meta('overview_layout')
        if raw is None:
            return None
        try:
            data = json.loads(raw)
        except ValueError:
            return None
        if not isinstance(data, list):
            return None
        return [str(x)[:80] for x in data][:300]

    def save_overview_layout(self, items):
        valid_ids = {d['id'] for d in self.store.devices()}
        out = []
        for x in items or []:
            x = str(x)[:80]
            if x and x in valid_ids and x not in out:
                out.append(x)
        self.store.set_meta('overview_layout', json.dumps(out))
        self.bump()
        return out

    # -- Zigbee gateways: read a SMLIGHT SLZB-06 (or similar) over the network --
    #
    # SLZB-06 / SLZB-OS exposes two documented, stable HTTP JSON endpoints
    # meant for exactly this kind of polling: /ha_info (identity, uptime,
    # network, socket state) and /ha_sensors (live sensor readings - board
    # temperature, RSSI, etc). Reference: smlight.tech/support/manuals ->
    # SLZB-OS -> "SLZB-OS API endpoints" -> "Home Assistant endpoints".
    # Field names below are the documented, intended-for-integration surface;
    # if a firmware version renames or adds fields, flatten() below still
    # captures them under their own key rather than dropping them, and
    # `zigmon gateway <name> dump` shows exactly what came back so a mismatch
    # is visible immediately rather than silently wrong.
    def managed_gateways(self):
        try:
            data = json.loads(self.store.get_meta('gateways') or '[]')
        except ValueError:
            data = []
        return [g for g in data if isinstance(g, dict)]

    def gateway_configs(self):
        """config.json entries first (read-only in the UI), then the ones
        added on the dashboard - same shape as plugs/sensors."""
        out, seen = [], set()
        for g in CONFIG.get('zigbee_gateways') or []:
            if isinstance(g, dict) and g.get('name') and g.get('host'):
                out.append(dict(g, source='config'))
                seen.add(str(g['name']))
        for g in self.managed_gateways():
            if g.get('name') and g.get('host') and str(g['name']) not in seen:
                out.append(dict(g, source='ui'))
                seen.add(str(g['name']))
        return out

    def gateways_for_ui(self):
        return [{'name': g['name'], 'host': g['host'], 'target': g.get('target') or 'coordinator',
                'username': g.get('username') or '', 'password_set': bool(g.get('password')),
                'source': g.get('source', 'ui')} for g in self.gateway_configs()]

    def save_managed_gateways(self, items):
        old = {str(g['name']): g for g in self.managed_gateways()}
        configured = {str(g.get('name')) for g in CONFIG.get('zigbee_gateways') or [] if isinstance(g, dict)}
        clean = []
        for index, g in enumerate(items or []):
            if not isinstance(g, dict):
                continue
            name = str(g.get('name') or '').strip()
            host = str(g.get('host') or '').strip()
            if not name or not host:
                raise ValueError('gateway %d needs a name and an address' % (index + 1))
            if name in configured:
                raise ValueError('%r is already in config.json - edit it there' % name)
            target = str(g.get('target') or 'coordinator').strip() or 'coordinator'
            username = str(g.get('username') or '').strip()
            password = g.get('password')
            if password is None or password == '':
                password = old.get(name, {}).get('password') or ''
            clean.append({'name': name[:80], 'host': host[:200], 'target': target[:80],
                          'username': username[:80], 'password': str(password)[:200]})
        self.store.set_meta('gateways', json.dumps(clean))
        self.store.add_event('control', '%d Zigbee gateway(s) saved' % len(clean))
        self.bump()
        return clean

    def gateway_fetch(self, host, path, timeout=5.0, username='', password=''):
        import urllib.request, base64
        url = 'http://%s%s' % (host.rstrip('/'), path)
        headers = {'Accept': 'application/json'}
        if username or password:
            # SLZB-OS's optional "web server authentication" is plain HTTP
            # Basic Auth - the same credentials as its own web UI login.
            token = base64.b64encode(('%s:%s' % (username, password)).encode('utf-8')).decode('ascii')
            headers['Authorization'] = 'Basic ' + token
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8', 'replace')
        if path == '/metrics':
            return parse_prometheus_text(raw)
        return json.loads(raw)

    def poll_gateway_auth(self, g):
        return g.get('username') or '', g.get('password') or ''

    def gateway_device_id(self, g):
        """Where the gateway's readings land: an existing Zigbee device (by
        name - a router already visible on the mesh gets *extended*, never
        duplicated) or a synthetic 'coordinator' row when there is none."""
        target = str(g.get('target') or g['name'])
        if target.lower() == 'coordinator':
            return 'gw:coordinator'
        resolved = self.store.resolve(target)
        return resolved  # None if the named device hasn't been seen yet

    def poll_gateway(self, g):
        host = g['host']
        device_id = self.gateway_device_id(g)
        if device_id is None:
            log('gateway %s: no Zigbee device named %r yet, will retry' % (g['name'], g.get('target') or g['name']), 'debug')
            return
        merged = {}
        ok = False
        for path in ('/ha_info', '/ha_sensors', '/metrics'):
            try:
                user, pw = self.poll_gateway_auth(g)
                data = self.gateway_fetch(host, path, username=user, password=pw)
                merged.update(flatten(data, 'gw'))
                ok = True
            except Exception as e:
                log('gateway %s %s: %s' % (g['name'], path, e), 'debug')
        if not ok:
            return
        if device_id == 'gw:coordinator' and self.store.device('gw:coordinator') is None:
            self.store.upsert_device({'id': 'gw:coordinator', 'name': g['name'], 'source': 'gateway',
                                      'kind': 'Coordinator', 'model': 'SLZB-06 (or compatible)',
                                      'vendor': 'SMLIGHT', 'last_seen': int(time.time())})
        now = int(time.time())
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': now})
        entry['payload'] = dict(entry.get('payload') or {}, **merged)
        entry['ts'] = now
        self.store.touch_device(device_id, now)
        numeric_vals = {k: numeric(v) for k, v in merged.items() if numeric(v) is not None}
        if numeric_vals:
            self.store.store_sample(device_id, now, numeric_vals)
        self.bump()

    def gateway_loop(self):
        while getattr(self, '_stop', None) is None:
            time.sleep(0.5)
        last = {}
        while not self._stop.wait(5):
            interval = int(CONFIG.get('gateway_poll_interval') or 30)
            now = time.time()
            for g in self.gateway_configs():
                if now - last.get(g['name'], 0) < interval:
                    continue
                last[g['name']] = now
                try:
                    self.poll_gateway(g)
                except Exception as e:
                    log('gateway %s: %s' % (g['name'], e), 'warn')

    # -- weekly schedules: "every Monday at 07:00 on, Wednesday 22:00 off" -------
    WEEKDAY_NAMES = ('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')

    def schedules(self):
        try:
            data = json.loads(self.store.get_meta('schedules') or '[]')
        except ValueError:
            data = []
        return [x for x in data if isinstance(x, dict)]

    def save_schedules(self, items):
        clean = []
        seen_ids = set()
        for index, sch in enumerate(items or []):
            if not isinstance(sch, dict):
                continue
            target = self._valid_target(str(sch.get('target') or ''))
            if target is None:
                raise ValueError('schedule %d: unknown plug or switch' % (index + 1))
            do = str(sch.get('do') or 'on').strip().lower()
            if do not in BINDING_ACTIONS:
                raise ValueError('do must be one of %s' % ', '.join(BINDING_ACTIONS))
            days = sch.get('days')
            if days in (None, '', 'all', '*'):
                days = list(range(7))
            elif isinstance(days, str):
                parsed = []
                for d in days.split(','):
                    d = d.strip()[:3].lower()
                    if d not in self.WEEKDAY_NAMES:
                        raise ValueError('schedule %d: unknown day %r (use mon,tue,...)' % (index + 1, d))
                    parsed.append(self.WEEKDAY_NAMES.index(d))
                days = parsed
            days = sorted({int(d) for d in (days or []) if 0 <= int(d) <= 6})
            if not days:
                raise ValueError('schedule %d: pick at least one day' % (index + 1))
            at = str(sch.get('at') or '').strip().lower()
            if re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', at):
                if CONFIG.get('latitude') is None or CONFIG.get('longitude') is None:
                    raise ValueError('sunrise/sunset need "latitude" and "longitude" in config.json')
            elif not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', at):
                raise ValueError('schedule %d: time must look like 07:00, sunset, or sunset-30' % (index + 1))
            else:
                at = '%02d:%s' % (int(at.split(':')[0]), at.split(':')[1])
            entry = {'id': str(sch.get('id') or '') or secrets.token_hex(4),
                     'target': target, 'days': days, 'at': at, 'do': do,
                     'enabled': bool(sch.get('enabled', True))}
            if do == 'pulse':
                ms = numeric(sch.get('pulse_ms'))
                entry['pulse_ms'] = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(ms or PULSE_MS_DEFAULT)))
            if entry['id'] in seen_ids:
                entry['id'] = secrets.token_hex(4)
            seen_ids.add(entry['id'])
            clean.append(entry)
        self.store.set_meta('schedules', json.dumps(clean))
        kept = {x['id'] for x in clean}
        for sid in list(self.schedule_runtime):
            if sid not in kept:
                del self.schedule_runtime[sid]
        self.store.add_event('control', '%d schedule(s) saved' % len(clean))
        self.bump()
        return clean

    def check_schedules(self):
        """Once a minute: has a schedule's day and time just arrived? Fires
        once per entry per day - a missed minute (daemon restart, a stalled
        tick) still fires within the same day, never twice."""
        now = time.time()
        t = time.localtime(now)
        weekday = t.tm_wday   # Monday = 0, matches WEEKDAY_NAMES
        today_key = time.strftime('%Y-%m-%d')
        current_minute = t.tm_hour * 60 + t.tm_min
        for sch in self.schedules():
            if not sch.get('enabled', True) or weekday not in (sch.get('days') or []):
                continue
            at = sch['at']
            m = re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', at)
            if m:
                if CONFIG.get('latitude') is None or CONFIG.get('longitude') is None:
                    continue
                base = sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude']), now, sunset=m.group(1) == 'sunset')
                if base is None:
                    continue
                target_minute = (base + int(m.group(2) or 0)) % 1440
            else:
                target_minute = int(at[:2]) * 60 + int(at[3:])
            if current_minute < target_minute or current_minute - target_minute > 4:
                continue                     # not due yet, or the window to catch up (4 min) has passed
            rt = self.schedule_runtime.setdefault(sch['id'], {'last_day': None})
            if rt['last_day'] == today_key:
                continue
            rt['last_day'] = today_key
            for target in self._binding_targets(sch['target']):
                pretty = self.target_label(sch['target'])
                origin = 'schedule: %s %s %s' % (self.WEEKDAY_NAMES[weekday], at, pretty)
                log('schedule fired: %s -> %s' % (origin, sch['do']))
                self.store.add_event('schedule', '%s -> %s' % (origin, sch['do']), 'info')
                self._fire_target(target, sch['do'], origin, sch.get('pulse_ms'))

    # -- scenes: a named bundle of target actions --------------------------------
    def scenes(self):
        try:
            data = json.loads(self.store.get_meta('scenes') or '[]')
        except ValueError:
            data = []
        return [x for x in data if isinstance(x, dict)]

    def save_scenes(self, items):
        clean = []
        for index, scene in enumerate(items or []):
            if not isinstance(scene, dict):
                continue
            name = str(scene.get('name') or '').strip()
            if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', name):
                raise ValueError('scene %d needs a sensible name' % (index + 1))
            if any(x['name'].lower() == name.lower() for x in clean):
                raise ValueError('two scenes called "%s"' % name)
            actions = []
            for a in scene.get('actions') or []:
                if not isinstance(a, dict):
                    continue
                target = self._valid_target(str(a.get('target') or ''))
                do = str(a.get('do') or 'on').strip().lower()
                if target is None or target == '*' or target.startswith('scene:'):
                    raise ValueError('scene "%s": each line needs a plug or a switch' % name)
                if do not in BINDING_ACTIONS:
                    raise ValueError('do must be one of %s' % ', '.join(BINDING_ACTIONS))
                entry = {'target': target, 'do': do}
                if do == 'pulse':
                    entry['pulse_ms'] = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(numeric(a.get('pulse_ms')) or PULSE_MS_DEFAULT)))
                after = numeric(a.get('after_s'))
                if after is not None and after > 0:
                    if after > 3600:
                        raise ValueError('scene "%s": a step delay tops out at an hour' % name)
                    entry['after_s'] = round(float(after), 1)
                actions.append(entry)
            if not actions:
                raise ValueError('scene "%s" has no actions' % name)
            clean.append({'id': str(scene.get('id') or '') or secrets.token_hex(4), 'name': name, 'actions': actions})
        self.store.set_meta('scenes', json.dumps(clean))
        self.store.add_event('control', '%d scene(s) saved' % len(clean))
        self.bump()
        return clean

    def run_scene(self, scene_id, origin='the dashboard'):
        scene = next((x for x in self.scenes() if x['id'] == scene_id), None)
        if scene is None:
            return False, 'unknown scene'
        def fire(action):
            for target in self._binding_targets(action['target']):
                self._fire_target(target, action['do'], 'scene "%s"' % scene['name'], action.get('pulse_ms'))

        def delayed(action, wait_s):
            if not self._stop.wait(wait_s):
                fire(action)

        for a in scene['actions']:
            after = float(a.get('after_s') or 0)
            if after > 0:
                threading.Thread(target=delayed, args=(a, after), name='scene-step', daemon=True).start()
            else:
                fire(a)
        self.store.add_event('scene', 'scene "%s" from %s' % (scene['name'], origin))
        log('scene %s (%s): %d action(s)' % (scene['name'], origin, len(scene['actions'])))
        self.bump()
        return True, 'scene "%s": %d action(s) fired' % (scene['name'], len(scene['actions']))

    # -- sequences: press once -> step 1, press again (even days later) -> step 2,
    #    ... and around again. A second trigger can reset the cycle and run
    #    a "reset" scene (all off, say). Steps are scenes, so each step can
    #    drive many targets, at once or with delays.
    def sequences(self):
        try:
            data = json.loads(self.store.get_meta('sequences') or '[]')
        except ValueError:
            data = []
        return [x for x in data if isinstance(x, dict)]

    def sequence_positions(self):
        try:
            return {str(k): int(v) for k, v in json.loads(self.store.get_meta('sequence_pos') or '{}').items()}
        except (ValueError, TypeError):
            return {}

    def save_sequences(self, items):
        scene_ids = {x['id'] for x in self.scenes()}
        clean = []
        for index, sq in enumerate(items or []):
            if not isinstance(sq, dict):
                continue
            name = str(sq.get('name') or '').strip()
            if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', name):
                raise ValueError('sequence %d needs a sensible name' % (index + 1))
            if any(x['name'].lower() == name.lower() for x in clean):
                raise ValueError('two sequences called "%s"' % name)
            steps = [str(x) for x in (sq.get('steps') or []) if str(x) in scene_ids]
            if not steps:
                raise ValueError('sequence "%s" needs at least one step (a scene)' % name)
            reset_scene = str(sq.get('reset_scene') or '')
            if reset_scene and reset_scene not in scene_ids:
                reset_scene = ''
            clean.append({'id': str(sq.get('id') or '') or secrets.token_hex(4), 'name': name,
                          'steps': steps[:50], 'reset_scene': reset_scene})
        self.store.set_meta('sequences', json.dumps(clean))
        positions = self.sequence_positions()
        kept = {x['id'] for x in clean}
        positions = {k: v for k, v in positions.items() if k in kept}
        self.store.set_meta('sequence_pos', json.dumps(positions))
        self.store.add_event('control', '%d sequence(s) saved' % len(clean))
        self.bump()
        return clean

    def sequence_by_id(self, sid):
        return next((x for x in self.sequences() if x['id'] == sid), None)

    def advance_sequence(self, sid, origin='the dashboard'):
        sq = self.sequence_by_id(sid)
        if sq is None:
            return False, 'unknown sequence'
        positions = self.sequence_positions()
        pos = positions.get(sid, 0) % len(sq['steps'])
        scene_id = sq['steps'][pos]
        scene = next((x for x in self.scenes() if x['id'] == scene_id), None)
        positions[sid] = (pos + 1) % len(sq['steps'])
        label = scene['name'] if scene else scene_id
        # the relay first, the paperwork after (same rule as bindings)
        if scene:
            self.run_scene(scene_id, 'sequence "%s" step %d' % (sq['name'], pos + 1))
        self.store.set_meta('sequence_pos', json.dumps(positions))
        self.store.add_event('sequence', 'sequence "%s" step %d/%d: %s (%s)'
                             % (sq['name'], pos + 1, len(sq['steps']), label, origin))
        log('sequence %s: step %d/%d -> scene %s (%s)' % (sq['name'], pos + 1, len(sq['steps']), label, origin))
        self.bump()
        return True, 'sequence "%s": step %d/%d, %s' % (sq['name'], pos + 1, len(sq['steps']), label)

    def reset_sequence(self, sid, origin='the dashboard'):
        sq = self.sequence_by_id(sid)
        if sq is None:
            return False, 'unknown sequence'
        positions = self.sequence_positions()
        positions[sid] = 0
        if sq.get('reset_scene'):
            self.run_scene(sq['reset_scene'], 'sequence "%s" reset' % sq['name'])
        self.store.set_meta('sequence_pos', json.dumps(positions))
        self.store.add_event('sequence', 'sequence "%s" reset to step 1 (%s)' % (sq['name'], origin))
        log('sequence %s: reset (%s)' % (sq['name'], origin))
        self.bump()
        return True, 'sequence "%s" back to step 1' % sq['name']

    # -- zigbee switches as targets: publish to <name>/set -----------------------
    ZB_STATE_RE = re.compile(r'^state(_[a-z0-9]+)?$')

    def zigbee_targets(self):
        """Every settable on/off state a Zigbee device offers - a wall switch
        channel, a bulb, a relay module. Each is addressable as zb:<id>:<key>."""
        out = []
        for dev in self.store.devices():
            if dev['source'] != 'zigbee' or dev['id'].startswith('name:'):
                continue
            exposes = dev.get('exposes') or {}
            for key, info in sorted(exposes.items()):
                if not self.ZB_STATE_RE.match(key):
                    continue
                access = (info or {}).get('access')
                if access is not None and not (access & 2):
                    continue                      # read-only state (a sensor, not a switch)
                live = self.live.get(dev['id']) or {}
                display = dev.get('alias') or dev['name']
                if key != 'state':
                    display += ' \u00b7 ' + key.replace('state_', '').upper()
                out.append({'value': 'zb:%s:%s' % (dev['id'], key), 'id': dev['id'], 'key': key,
                            'name': display,
                            'online': (live.get('availability') or '') != 'offline',
                            'state': (live.get('payload') or {}).get(key)})
        return out

    def _valid_target(self, spec):
        """Canonical form of a binding/rule target, or None: a plug name, '*',
        or zb:<device>:<state key>."""
        spec = str(spec or '').strip()
        if spec == '*':
            return '*'
        if spec.startswith('scene:'):
            sid = spec[6:]
            return spec if any(x['id'] == sid for x in self.scenes()) else None
        if spec.startswith('seqreset:'):
            return spec if self.sequence_by_id(spec[9:]) else None
        if spec.startswith('seq:'):
            return spec if self.sequence_by_id(spec[4:]) else None
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            if len(pieces) < 3:
                return None
            key = pieces[-1]
            device = ':'.join(pieces[1:-1])
            resolved = self.store.resolve(device)
            if not resolved or not self.ZB_STATE_RE.match(key):
                return None
            dev = self.store.device(resolved)
            if not dev or dev['source'] != 'zigbee':
                return None
            return 'zb:%s:%s' % (resolved, key)
        canonical = next((n for n in self.plug_names_all() if n.lower() == spec.lower()), None)
        return canonical

    def target_label(self, spec):
        if spec.startswith('seqreset:'):
            sq = self.sequence_by_id(spec[9:])
            return 'reset sequence ' + (sq['name'] if sq else '?')
        if spec.startswith('seq:'):
            sq = self.sequence_by_id(spec[4:])
            return 'sequence ' + (sq['name'] if sq else '?')
        if spec.startswith('scene:'):
            scene = next((x for x in self.scenes() if x['id'] == spec[6:]), None)
            return 'scene ' + (scene['name'] if scene else '?')
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            dev = self.store.device(':'.join(pieces[1:-1]))
            if dev:
                label = dev.get('alias') or dev['name']
                return label + ('' if pieces[-1] == 'state' else ' \u00b7 ' + pieces[-1].replace('state_', '').upper())
        return spec

    def _binding_targets(self, spec):
        """('plug', PlugState) and ('zb', device_id, key) tuples for one target
        spec; '*' means every enabled plug (never the Zigbee switches)."""
        if spec == '*':
            return [('plug', p) for p in self.plugs.values() if not p.cfg.get('monitor_only')]
        if spec.startswith('scene:'):
            return [('scene', spec[6:])]
        if spec.startswith('seqreset:'):
            return [('seqreset', spec[9:])]
        if spec.startswith('seq:'):
            return [('seq', spec[4:])]
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            return [('zb', ':'.join(pieces[1:-1]), pieces[-1])]
        p = self.plug_by_name(spec)
        return [('plug', p)] if p is not None else []

    def _fire_target(self, target, do, origin, pulse_ms=None):
        if target[0] == 'scene':
            threading.Thread(target=self.run_scene, args=(target[1], origin), name='scene', daemon=True).start()
            return
        if target[0] == 'seq':
            threading.Thread(target=self.advance_sequence, args=(target[1], origin), name='sequence', daemon=True).start()
            return
        if target[0] == 'seqreset':
            threading.Thread(target=self.reset_sequence, args=(target[1], origin), name='sequence', daemon=True).start()
            return
        if target[0] == 'plug':
            threading.Thread(target=self._run_binding, args=(target[1], do, origin, pulse_ms),
                             name='binding', daemon=True).start()
        else:
            threading.Thread(target=self._run_zigbee_switch, args=(target[1], target[2], do, origin, pulse_ms),
                             name='binding-zb', daemon=True).start()

    def _run_zigbee_switch(self, device_id, key, do, origin, pulse_ms=None):
        try:
            ok, message = self.zigbee_switch(device_id, key, do, origin, pulse_ms)
            if not ok:
                log('zigbee target failed: %s' % message, 'warn')
        except Exception as e:
            log('zigbee target failed: %s' % e, 'error')

    def zigbee_switch(self, device_id, key, action, origin='the dashboard', pulse_ms=None):
        """Drive a Zigbee switch through Zigbee2MQTT: publish {key: ON/OFF/TOGGLE}
        to <name>/set. The device's own report comes back through the bridge
        and repaints the dashboard."""
        dev = self.store.device(device_id)
        if dev is None:
            return False, 'unknown device'
        if not self.connected or not self.client:
            return False, 'not connected to the broker'
        label = self.target_label('zb:%s:%s' % (device_id, key))
        topic = '%s/%s/set' % (CONFIG['base_topic'].rstrip('/'), dev['name'])

        def put(value):
            info = self.client.publish(topic, json.dumps({key: value}), qos=1)
            if hasattr(info, 'rc') and info.rc != 0:
                raise RuntimeError('publish failed (%s) - the broker ACL must allow writing %s' % (info.rc, topic))

        if action == 'pulse':
            ms = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(pulse_ms or PULSE_MS_DEFAULT)))
            current = str((self.live.get(device_id, {}).get('payload') or {}).get(key) or '').upper()
            if current in ('ON', 'OFF'):
                first, back = ('OFF', 'ON') if current == 'ON' else ('ON', 'OFF')
            else:
                first, back = 'TOGGLE', 'TOGGLE'   # state unknown; a blind flip both ways
            put(first)
            self.store.add_event('switch', 'pulse: %s for %.1f s from %s' % (first, ms / 1000.0, origin),
                                 'info', device_id)
            self._stop.wait(ms / 1000.0)
            put(back)
            self.store.add_event('switch', 'pulse: back %s' % back, 'info', device_id)
            log('%s pulsed %s for %d ms (%s)' % (label, first, ms, origin))
            self.bump()
            return True, '%s pulsed %s for %.1f s' % (label, first.lower(), ms / 1000.0)
        value = 'TOGGLE' if action == 'toggle' else action.upper()
        put(value)
        self.store.add_event('switch', 'set %s from %s' % (value, origin),
                             'info', device_id)
        log('%s set %s (%s)' % (label, value, origin))
        self.bump()
        return True, '%s set %s' % (label, value.lower())

    # -- button bindings -------------------------------------------------------
    def bindings(self):
        raw = self.store.get_meta('bindings')
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except ValueError:
            return []
        return [b for b in data if isinstance(b, dict)]

    def save_bindings(self, items):
        clean = []
        for index, b in enumerate(items or []):
            if not isinstance(b, dict):
                continue
            device = str(b.get('device') or '').strip()
            action = str(b.get('action') or '').strip()
            plug = str(b.get('plug') or '').strip()
            do = str(b.get('do') or 'toggle').strip().lower()
            if not device or not action or not plug:
                raise ValueError('binding %d needs a device, an action and a plug' % (index + 1))
            if do not in BINDING_ACTIONS:
                raise ValueError('do must be one of %s' % ', '.join(BINDING_ACTIONS))
            canonical = self._valid_target(plug)
            if canonical is None:
                raise ValueError('unknown plug or switch %r' % plug)
            resolved = self.store.resolve(device) or device
            entry = {'device': resolved, 'action': action,
                     'plug': canonical,
                     'do': do, 'enabled': bool(b.get('enabled', True))}
            if do == 'pulse':
                try:
                    ms = int(b.get('pulse_ms') or PULSE_MS_DEFAULT)
                except (TypeError, ValueError):
                    raise ValueError('pulse delay must be a number of milliseconds')
                if not PULSE_MS_MIN <= ms <= PULSE_MS_MAX:
                    raise ValueError('pulse delay must be between %d and %d ms' % (PULSE_MS_MIN, PULSE_MS_MAX))
                entry['pulse_ms'] = ms
            clean.append(entry)
        self.store.set_meta('bindings', json.dumps(clean))
        self.store.add_event('control', '%d button binding(s) saved' % len(clean))
        return clean

    # -- value rules: "when a reading crosses a line, drive a plug" -----------
    def rules(self):
        raw = self.store.get_meta('rules')
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except ValueError:
            return []
        return [r for r in data if isinstance(r, dict)]

    def save_rules(self, items):
        clean = self._validate_rules(items)
        self.store.set_meta('rules', json.dumps(clean))
        kept_ids = {r['id'] for r in clean}
        for rid in list(self.rule_runtime):
            if rid not in kept_ids:
                del self.rule_runtime[rid]
        self.store.add_event('control', '%d rule(s) saved' % len(clean))
        self.bump()
        return clean

    def _validate_rules(self, items):
        clean = []
        kept = {r.get('id'): r for r in self.rules()}
        for index, r in enumerate(items or []):
            if not isinstance(r, dict):
                continue
            device = str(r.get('device') or '').strip()
            key = str(r.get('key') or '').strip()
            op = str(r.get('op') or '>=').strip()
            plug = str(r.get('plug') or '').strip()
            do = str(r.get('do') or 'on').strip().lower()
            value = numeric(r.get('value'))
            if not device or not key or not plug:
                raise ValueError('rule %d needs a source, a value key and a plug' % (index + 1))
            if op not in RULE_OPS:
                raise ValueError('the comparison must be one of %s' % ', '.join(RULE_OPS))
            if value is None:
                raise ValueError('rule %d: the threshold must be a number' % (index + 1))
            if do not in BINDING_ACTIONS:
                raise ValueError('do must be one of %s' % ', '.join(BINDING_ACTIONS))
            canonical_rule = self._valid_target(plug)
            if canonical_rule is None:
                raise ValueError('unknown plug or switch %r' % plug)
            cooldown = numeric(r.get('cooldown_s'))
            def hhmm(value, what):
                value = str(value or '').strip().lower()
                if not value:
                    return ''
                if re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', value):
                    if CONFIG.get('latitude') is None or CONFIG.get('longitude') is None:
                        raise ValueError('sunrise/sunset need "latitude" and "longitude" in config.json')
                    return value
                if not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', value):
                    raise ValueError('%s must look like 22:30, sunset, or sunset-30' % what)
                return '%02d:%s' % (int(value.split(':')[0]), value.split(':')[1])
            window_from = hhmm(r.get('from'), 'the window start')
            window_to = hhmm(r.get('to'), 'the window end')
            if bool(window_from) != bool(window_to):
                raise ValueError('give both ends of the time window, or neither')
            window_end = str(r.get('window_end') or '').strip().lower()
            if window_end not in ('', 'off', 'on'):
                raise ValueError('when the window closes, the plug can be left alone, switched off or on')
            for_s = numeric(r.get('for_s'))
            if for_s is not None and not 0 <= for_s <= 86400:
                raise ValueError('"must hold for" is seconds, up to a day')
            back = numeric(r.get('back'))
            if back is not None and do not in ('on', 'off'):
                raise ValueError('the way-back threshold only makes sense with switch on/off')
            mode = str(r.get('mode') or 'abs')
            if mode not in ('abs', 'delta24'):
                raise ValueError("compare must be 'abs' or 'delta24'")
            max_ph = int(numeric(r.get('max_per_hour')) or 0)
            if not 0 <= max_ph <= 1000:
                raise ValueError('max per hour is 0 (off) to 1000')
            entry = {'id': str(r.get('id') or '') or secrets.token_hex(4),
                     'device': self.store.resolve(device) or device, 'key': key, 'op': op, 'value': value,
                     'plug': canonical_rule, 'do': do,
                     'cooldown_s': int(cooldown) if cooldown is not None and cooldown >= 0 else RULE_COOLDOWN_DEFAULT,
                     'from': window_from, 'to': window_to, 'window_end': window_end,
                     'for_s': int(for_s or 0), 'back': back,
                     'mode': mode, 'max_per_hour': max_ph,
                     'enabled': bool(r.get('enabled', True))}
            device2 = str(r.get('device2') or '').strip()
            key2 = str(r.get('key2') or '').strip()
            if device2 and key2:
                op2 = str(r.get('op2') or '>=').strip()
                value2 = numeric(r.get('value2'))
                if op2 not in RULE_OPS:
                    raise ValueError('the second comparison must be one of %s' % ', '.join(RULE_OPS))
                if value2 is None:
                    raise ValueError('the second threshold must be a number')
                entry.update({'device2': self.store.resolve(device2) or device2, 'key2': key2,
                              'op2': op2, 'value2': value2})
            if do == 'pulse':
                try:
                    ms = int(r.get('pulse_ms') or PULSE_MS_DEFAULT)
                except (TypeError, ValueError):
                    raise ValueError('pulse delay must be a number of milliseconds')
                if not PULSE_MS_MIN <= ms <= PULSE_MS_MAX:
                    raise ValueError('pulse delay must be between %d and %d ms' % (PULSE_MS_MIN, PULSE_MS_MAX))
                entry['pulse_ms'] = ms
            if entry['id'] not in kept:
                self.rule_runtime.pop(entry['id'], None)
            clean.append(entry)
        return clean

    def avg24(self, device_id, key):
        """The rolling day average of one reading, cached ten minutes."""
        cache = getattr(self, '_avg24', None)
        if cache is None:
            cache = self._avg24 = {}
        hit = cache.get((device_id, key))
        now = time.time()
        if hit and now - hit[1] < 600:
            return hit[0]
        with self.store.lock:
            rows = self.store.db.execute(
                'SELECT AVG(value) v FROM samples WHERE device=? AND key=? AND ts>=?',
                (device_id, key, int(now - 86400))).fetchone()
            value = rows['v']
            if value is None:
                rows = self.store.db.execute(
                    'SELECT AVG(avg) v FROM samples_hourly WHERE device=? AND key=? AND ts>=?',
                    (device_id, key, int(now - 86400))).fetchone()
                value = rows['v']
        cache[(device_id, key)] = (value, now)
        return value

    def _effective_reading(self, r, reading):
        if r.get('mode') == 'delta24':
            base = self.avg24(r['device'], r['key'])
            return None if base is None else reading - base
        return reading

    def _rate_limited(self, r, rt):
        limit = int(r.get('max_per_hour') or 0)
        if not limit:
            return False
        now = time.time()
        fires = [t for t in rt.get('fire_log', []) if now - t < 3600]
        rt['fire_log'] = fires
        if len(fires) >= limit:
            if not rt.get('limited'):
                rt['limited'] = True
                self.store.add_event('rule', 'rate limit: %s %s %g hit %d/h, holding fire'
                                     % (r['key'], r['op'], r['value'], limit), 'warn', r['device'])
            return True
        rt['limited'] = False
        fires.append(now)
        return False

    def dryrun_rule(self, r, days=7):
        """Walk a week of recorded samples and answer: when would this rule
        have fired? Windows, edges, hold-for, cooldown and delta24 are
        honoured; the AND condition uses the other series' nearest value."""
        rules = self._validate_rules([dict(r, id='dryrun')])
        r = rules[0]
        now = time.time()
        with self.store.lock:
            rows = self.store.db.execute(
                'SELECT ts, value FROM samples WHERE device=? AND key=? AND ts>=? ORDER BY ts',
                (r['device'], r['key'], int(now - days * 86400))).fetchall()
            other = []
            if r.get('device2') and r.get('key2'):
                other = self.store.db.execute(
                    'SELECT ts, value FROM samples WHERE device=? AND key=? AND ts>=? ORDER BY ts',
                    (r['device2'], r['key2'], int(now - days * 86400))).fetchall()
        fires, holds_since, last_fire, prev_holds = [], None, -1e12, False
        oi = 0
        window = [x['value'] for x in rows[:48]]
        for row in rows:
            ts, reading = row['ts'], row['value']
            if reading is None or not self.rule_window_active(r, ts):
                prev_holds = False
                holds_since = None
                continue
            if r.get('mode') == 'delta24':
                window.append(reading)
                if len(window) > 1440:
                    window.pop(0)
                reading = reading - (sum(window) / len(window))
            holds = self._rule_holds(r['op'], reading, r['value'])
            if holds and other:
                while oi + 1 < len(other) and other[oi + 1]['ts'] <= ts:
                    oi += 1
                second = other[oi]['value'] if other and other[oi]['ts'] <= ts else None
                holds = second is not None and self._rule_holds(r['op2'], second, r['value2'])
            wait_s = int(r.get('for_s') or 0)
            if holds and not prev_holds:
                holds_since = ts
            if not holds:
                holds_since = None
            fire = False
            if holds:
                if wait_s:
                    fire = holds_since is not None and ts - holds_since >= wait_s and not any(
                        f >= holds_since for f in fires[-3:])
                else:
                    fire = not prev_holds
            if fire and ts - last_fire >= int(r.get('cooldown_s') or 0):
                fires.append(ts)
                last_fire = ts
            prev_holds = holds
        return {'days': days, 'samples': len(rows), 'fires': fires[-200:], 'count': len(fires)}

    def latest_value(self, device_id, key):
        """The device's last reported value for one key, as a number."""
        entry = self.live.get(device_id) or {}
        return numeric((entry.get('payload') or {}).get(key))

    @staticmethod
    def rule_window_active(r, now=None):
        """True when the rule's clock window is open. 22:00-06:00 crosses
        midnight and means exactly that; no window means always."""
        if not r.get('from') or not r.get('to'):
            return True
        t = time.localtime(now if now is not None else time.time())
        minutes = t.tm_hour * 60 + t.tm_min

        def spec_minutes(spec):
            m = re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', spec)
            if m:
                base = sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude']),
                                   now, sunset=m.group(1) == 'sunset')
                if base is None:
                    return None
                return (base + int(m.group(2) or 0)) % 1440
            return int(spec[:2]) * 60 + int(spec[3:])
        f = spec_minutes(r['from'])
        to = spec_minutes(r['to'])
        if f is None or to is None:
            return True                      # polar day/night: no astro edge, stay open
        if f == to:
            return True
        if f < to:
            return f <= minutes < to
        return minutes >= f or minutes < to

    @staticmethod
    def _rule_holds(op, reading, threshold):
        if op == '>=':
            return reading >= threshold
        if op == '<=':
            return reading <= threshold
        if op == '>':
            return reading > threshold
        return reading < threshold

    def fire_rules(self, device_id, name, values):
        """Edge-triggered: a rule fires when its condition becomes true, not on
        every reading while it stays true; the cooldown guards against a value
        that dances around the line."""
        for r in self.rules():
            if not r.get('enabled', True):
                continue
            mine = r['device'] in (device_id, name)
            second = bool(r.get('device2')) and r['device2'] in (device_id, name)
            if not mine and not second:
                continue
            if not self.rule_window_active(r):
                continue                     # outside its hours; the ticker handles the edges
            reading = values.get(r['key']) if mine else self.latest_value(r['device'], r['key'])
            if reading is not None:
                reading = self._effective_reading(r, reading)
            if reading is None:
                continue
            rt = self.rule_runtime.setdefault(r['id'], {'holds': None, 'fired': 0.0, 'reading': None})
            rt['reading'] = reading
            # the way back of a hysteresis pair folded into one rule
            if r.get('back') is not None and self._rule_holds(
                    {'>=': '<=', '<=': '>=', '>': '<', '<': '>'}[r['op']], reading, r['back']):
                if rt.get('back_done') is not True:
                    rt['back_done'] = True
                    rt['holds'] = False
                    rt.pop('since', None)
                    opposite = 'off' if r['do'] == 'on' else 'on'
                    origin = '%s %s %g back past %g' % (name, r['key'], reading, r['back'])
                    for target in self._binding_targets(r['plug']):
                        pretty = self.target_label(r['plug'])
                        log('rule back: %s -> %s %s' % (origin, pretty, opposite))
                        self.store.add_event('rule', '%s: %s %s' % (origin, pretty, opposite), 'info', device_id)
                        self._fire_target(target, opposite, 'rule: ' + origin)
                continue
            holds = self._rule_holds(r['op'], reading, r['value'])
            if holds and r.get('device2') and r.get('key2'):
                other = values.get(r['key2']) if second else None
                if other is None:
                    other = self.latest_value(r['device2'], r['key2'])
                holds = other is not None and self._rule_holds(r['op2'], other, r['value2'])
            was = rt['holds']
            rt['holds'] = holds
            if not holds:
                rt.pop('since', None)
                continue
            rt['back_done'] = False
            if was is not True or 'since' not in rt:
                rt.setdefault('since', time.time())
            wait_s = int(r.get('for_s') or 0)
            if wait_s:
                if time.time() - rt['since'] < wait_s:
                    continue                 # not held long enough; the ticker finishes it
                if rt.get('for_fired') == rt['since']:
                    continue                 # this stretch already fired
            elif was is True:
                continue
            now = time.time()
            if now - rt['fired'] < int(r.get('cooldown_s') or 0):
                continue
            if self._rate_limited(r, rt):
                continue
            rt['fired'] = now
            if wait_s:
                rt['for_fired'] = rt['since']
            origin = '%s %s %g %s %g' % (name, r['key'], reading, r['op'], r['value'])
            targets = self._binding_targets(r['plug'])
            if not targets and r['plug'] != '*':
                log('rule skipped: %s is disabled or gone' % r['plug'], 'debug')
            for target in targets:
                pretty = self.target_label(r['plug'])
                log('rule: %s -> %s %s' % (origin, pretty, r['do']))
                self.store.add_event('rule', '%s: %s %s' % (origin, pretty, r['do']), 'info', device_id)
                self._fire_target(target, r['do'], 'rule: ' + origin, r.get('pulse_ms'))

    def fire_bindings(self, device_id, name, action):
        hits = [b for b in self.bindings()
                if b.get('enabled', True) and b['device'] in (device_id, name)
                and (b['action'] == action or b['action'] == '*')]
        for b in hits:
            origin = 'button %s (%s)' % (name, action)
            targets = self._binding_targets(b['plug'])
            if not targets and b['plug'] != '*':
                log('binding skipped: %s is disabled or gone' % b['plug'], 'debug')
            for target in targets:
                log('binding: %s %s -> %s %s' % (name, action, self.target_label(b['plug']), b['do']))
                self._fire_target(target, b['do'], origin, b.get('pulse_ms'))

    def _run_binding(self, p, do, origin, pulse_ms=None):
        try:
            if do == 'toggle':
                ok, message = self.toggle_plug(p, origin)
            elif do == 'pulse':
                ok, message = self.pulse_plug(p, pulse_ms, origin)
            else:
                ok, message = self.set_plug_output(p, do == 'on', origin)
            if not ok:
                log('binding failed: %s' % message, 'warn')
        except Exception as e:
            log('binding failed: %s' % e, 'error')


    # -- Shelly sensors polled over RPC, and pushed webhooks -----------------
    def setup_sensors(self):
        for entry in self.active_entries('sensors'):
            name = str(entry['name'])
            self.sensors[name] = PlugState(name, entry)
            self.sensors[name].device_id = 'sensor:' + name
            self.store.upsert_device({'id': 'sensor:' + name, 'name': name, 'source': 'shelly',
                                      'kind': 'wifi', 'vendor': 'Shelly', 'exposes': {}})

    def poll_sensor(self, s):
        """A battery H&T is asleep almost always, so failure here is not an error."""
        now = time.time()
        if now - s.last_poll < int(CONFIG.get('plug_poll_interval') or 15):
            return
        s.last_poll = now
        rpc = s.rpc()
        try:
            status = rpc.call('Shelly.GetStatus')
            if not s.info:
                s.info = rpc.device_info()
        except PlugError as e:
            s.failures += 1
            s.error = str(e)
            log('sensor %s: %s' % (s.name, e), 'debug')
            return
        if s.failures >= 3:
            log('sensor %s answers again' % s.name)
        s.failures = 0
        s.error = None
        flat = normalise_shelly_status(flatten(status))
        if not flat:
            return
        self.record(s.device_id, s.name, flat)
        info = s.info or {}
        self.store.upsert_device({'id': s.device_id, 'name': s.name, 'source': 'shelly', 'kind': 'wifi',
                                  'vendor': 'Shelly', 'model': info.get('model'),
                                  'description': ' '.join(x for x in (info.get('app'), info.get('ver')) if x) or None,
                                  'exposes': {}})

    def accept_push(self, fields, raw, client):
        """One webhook from a sleeping sensor. Returns True when something usable arrived."""
        source = str(fields.get('id') or fields.get('device') or fields.get('name') or client)
        values = {}
        aliases = {'tC': ('t', 'tC', 'temperature', 'temp'), 'rh': ('rh', 'humidity', 'h'),
                   'battery.V': ('bv', 'battery.V', 'V'), 'battery.percent': ('bp', 'battery.percent', 'percent', 'battery'),
                   'wifi.rssi': ('rssi', 'wifi.rssi'), 'lux': ('lux', 'illuminance')}
        for key, names in aliases.items():
            for n in names:
                if n in fields and numeric(fields[n]) is not None:
                    values[key] = numeric(fields[n])
                    break
        self.pushes_received += 1
        self.last_push_at = time.time()
        if not values:
            self.pushes_rejected += 1
            log('sensor push from %s carried nothing usable: %s' % (client, (raw or '')[:200]), 'warn')
            return False
        device_id = 'push:' + source
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': source, 'source': 'shelly', 'kind': 'wifi',
                                      'vendor': 'Shelly', 'description': 'webhook from %s' % client, 'exposes': {}})
            self.store.add_event('device', 'first push from %s' % client, 'info', device_id)
            log('first sensor push from %s (%s): %s' % (source, client, values))
        self.record(device_id, source, values)
        return True

    def serve_pushes(self):
        daemon = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def _answer(self, ok):
                self.send_response(200 if ok else 400)
                self.send_header('Content-Length', '0')
                self.end_headers()

            def do_GET(self):
                query = parse_qs(urlparse(self.path).query)
                fields = {k: v[0] for k, v in query.items() if v}
                self._answer(daemon.accept_push(fields, json.dumps(fields), self.client_address[0]))

            def do_POST(self):
                length = int(self.headers.get('Content-Length') or 0)
                raw = self.rfile.read(length).decode('utf-8', 'replace') if length else ''
                fields = {}
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        fields = flatten(parsed)
                except ValueError:
                    fields = {k: v[0] for k, v in parse_qs(raw).items() if v}
                short = {}
                for key, value in fields.items():
                    short[key.rsplit('.', 1)[-1]] = value
                short.update(fields)
                self._answer(daemon.accept_push(short, raw, self.client_address[0]))

        host, port = CONFIG['sensor_listen_host'] or '0.0.0.0', int(CONFIG['sensor_listen_port'])
        try:
            server = ThreadingHTTPServer((host, port), Handler)
        except OSError as e:
            log('cannot listen for sensor pushes on %s:%s - %s' % (host, port, e), 'error')
            return
        server.daemon_threads = True
        log('listening for sensor pushes on http://%s:%s/' % (host, port))
        server.serve_forever()

    # -- assessment ---------------------------------------------------------
    def describe(self, dev, snap):
        """One device for the API: identity, readings, verdict."""
        now = time.time()
        payload = (snap or {}).get('payload') or {}
        ts = (snap or {}).get('ts')
        availability = (snap or {}).get('availability')
        exposes = dev.get('exposes') or {}
        values = {}
        for key, value in payload.items():
            if key in IGNORE_KEYS:
                continue
            info = exposes.get(key) or {}
            values[key] = {
                'value': value,
                'label': info.get('label') or key_label(key),
                'unit': info.get('unit') or key_unit(key),
                'description': info.get('description') or '',
                'category': info.get('category') or '',
            }
            if info.get('values'):
                values[key]['options'] = list(info['values'])
        # What a button can send: the definition's list first, then anything
        # it has actually sent that the definition did not mention.
        declared = list((exposes.get('action') or {}).get('values') or [])
        actions = declared + [a for a in self.store.actions_seen(dev['id']) if a not in declared]
        display = dev.get('alias') or dev['name']
        via = None
        relation = getattr(self, 'parents', {}).get(dev['id'])
        if relation and dev['source'] == 'zigbee':
            parent_row = self.store.device(relation.get('parent') or '')
            parent_type = (relation.get('parent_type') or '').lower()
            via = {'id': relation.get('parent'),
                   'name': (parent_row.get('alias') or parent_row['name']) if parent_row
                           else ('coordinator' if parent_type == 'coordinator' else relation.get('parent')),
                   'type': relation.get('parent_type') or ('Coordinator' if parent_type == 'coordinator' else ''),
                   'lqi': relation.get('lqi'), 'ts': relation.get('ts')}
        reasons = []
        level = 'ok'

        def worst(new):
            nonlocal level
            order = ['ok', 'warn', 'crit']
            if order.index(new) > order.index(level):
                level = new

        age = (now - ts) if ts else None
        if availability == 'offline':
            worst('crit')
            reasons.append('not answering' if dev['source'] == 'plug' else 'reported offline by the bridge')
        battery = numeric(payload.get('battery')) if 'battery' in payload else \
            numeric(payload.get('battery.percent')) if 'battery.percent' in payload else None
        if battery is not None:
            if battery <= CONFIG['battery_crit']:
                worst('crit')
                reasons.append('battery %d%%' % battery)
            elif battery <= CONFIG['battery_warn']:
                worst('warn')
                reasons.append('battery %d%%' % battery)
        lqi = numeric(payload.get('linkquality')) if 'linkquality' in payload else None
        if lqi is not None:
            if lqi <= CONFIG['lqi_crit']:
                worst('warn')
                reasons.append('very weak signal (%d)' % lqi)
            elif lqi <= CONFIG['lqi_warn']:
                worst('warn')
                reasons.append('weak signal (%d)' % lqi)
        temp = numeric(payload.get('temperature')) if 'temperature' in payload else \
            numeric(payload.get('tC')) if 'tC' in payload else None
        if temp is not None:
            if CONFIG.get('temperature_max') is not None and temp > CONFIG['temperature_max']:
                worst('warn')
                reasons.append('temperature %.1f above %.1f' % (temp, CONFIG['temperature_max']))
            if CONFIG.get('temperature_min') is not None and temp < CONFIG['temperature_min']:
                worst('warn')
                reasons.append('temperature %.1f below %.1f' % (temp, CONFIG['temperature_min']))
        hum = numeric(payload.get('humidity')) if 'humidity' in payload else \
            numeric(payload.get('rh')) if 'rh' in payload else None
        if hum is not None and CONFIG.get('humidity_max') is not None and hum > CONFIG['humidity_max']:
            worst('warn')
            reasons.append('humidity %.0f%% above %.0f%%' % (hum, CONFIG['humidity_max']))
        if payload.get('water_leak') in (True, 'true', 1):
            worst('crit')
            reasons.append('water leak')
        if payload.get('battery_low') in (True, 'true', 1):
            worst('warn')
            reasons.append('battery low flag')
        stale_warn = int(CONFIG.get('stale_warn_min') or 0) * 60
        stale_crit = int(CONFIG.get('stale_crit_min') or 0) * 60
        if dev['source'] == 'plug':
            stale_warn, stale_crit = 0, 0
        if ts is None:
            worst('warn')
            reasons.append('never reported')
        elif stale_crit and age > stale_crit:
            worst('crit')
            reasons.append('silent for %s' % human_age(age))
        elif stale_warn and age > stale_warn:
            worst('warn')
            reasons.append('silent for %s' % human_age(age))

        ranked = []
        for key, entry in values.items():
            if dev['source'] == 'plug':
                rank = PLUG_HEADLINE.index(key) if key in PLUG_HEADLINE else None
            else:
                rank = headline_rank(key)
            if dev.get('kind') == 'Router' and key in ('state', 'led_state'):
                continue        # a leftover on/off cluster in router firmware; it routes nothing
            if rank is not None and not key.endswith('.tF'):
                ranked.append((rank, key, entry))
        ranked.sort()
        headline = [dict(entry, key=key) for _, key, entry in ranked[:4]]
        return {
            'id': dev['id'], 'name': display, 'topic_name': dev['name'],
            'alias': dev.get('alias') or None, 'source': dev['source'],
            'via': via,
            'kind': dev.get('kind'), 'model': dev.get('model'), 'vendor': dev.get('vendor'),
            'description': dev.get('description'),
            'first_seen': dev.get('first_seen'), 'last_seen': ts or dev.get('last_seen'),
            'age_s': int(age) if age is not None else None,
            'availability': availability,
            'online': availability != 'offline' and ts is not None and not (stale_crit and age > stale_crit),
            'level': level, 'reasons': reasons,
            'battery': battery, 'linkquality': lqi, 'temperature': temp, 'humidity': hum,
            'headline': headline,
            'values': values,
            'actions': actions,
            'has_action': bool(actions) or 'action' in exposes,
            'last_action': self.store.last_action(dev['id']) if (actions or 'action' in exposes) else None,
        }

    def status(self):
        now = time.time()
        devices = [self.describe(d, self.live.get(d['id'])) for d in self.store.devices()]
        order = {'ok': 0, 'warn': 1, 'crit': 2}
        level = 'ok'
        for d in devices:
            if order[d['level']] > order[level]:
                level = d['level']
        if not self.connected:
            level = 'crit'
        elif self.bridge.get('state') == 'offline':
            level = 'crit'
        elif not devices:
            level = 'unknown'
        pj_end = self.bridge.get('permit_join_end')
        permit = bool(self.bridge.get('permit_join'))
        if permit and pj_end and pj_end / 1000.0 < now:
            permit = False
        return {
            'ok': True, 'ts': int(now), 'level': level,
            'connected': self.connected,
            'broker': '%s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port']),
            'bridge': dict(self.bridge, permit_join=permit),
            'devices': devices,
            'counts': {'devices': len(devices),
                       'online': sum(1 for d in devices if d['online']),
                       'ok': sum(1 for d in devices if d['level'] == 'ok'),
                       'warn': sum(1 for d in devices if d['level'] == 'warn'),
                       'crit': sum(1 for d in devices if d['level'] == 'crit')},
            'thresholds': {k: CONFIG[k] for k in ('battery_warn', 'battery_crit', 'lqi_warn',
                                                   'lqi_crit', 'stale_warn_min', 'stale_crit_min',
                                                   'temperature_min', 'temperature_max',
                                                   'humidity_max')},
            'seq': self.seq,
            'pin_required': bool(CONFIG.get('pin')),
            'unlocked_until': int(self.unlocked_until()) if self.unlocked_until() else None,
            'pin_length': len(str(CONFIG.get('pin') or '')),
            'pin_numeric': str(CONFIG.get('pin') or '').isdigit(),
            'plugs': [self.plug_snapshot(p) for p in self.plugs.values()],
            'bindings': self.bindings(),
            'rules': [dict(r, **{'holds': (self.rule_runtime.get(r['id']) or {}).get('holds'),
                                 'reading': (self.rule_runtime.get(r['id']) or {}).get('reading')})
                      for r in self.rules()],
            'rule_ops': RULE_OPS,
            'switch_targets': self.zigbee_targets(),
            'scenes': [{'id': x['id'], 'name': x['name'], 'actions': len(x['actions'])} for x in self.scenes()],
            'schedule_count': len(self.schedules()),
            'sequences': [{'id': x['id'], 'name': x['name'], 'steps': len(x['steps']),
                           'pos': self.sequence_positions().get(x['id'], 0) % max(1, len(x['steps']))}
                          for x in self.sequences()],
            'notify': {'channels': self.notify_channels(), 'settings': self.notify_settings()},
            'runtime_config': self.runtime_config(),
            'overview_layout': self.overview_layout(),
            'gateways': self.gateways_for_ui(),
            'db': {'bytes': (db_path().stat().st_size if db_path().exists() else 0),
                   'last_aggregate': self.store.get_meta('last_aggregate_ts')},
            'astro': ({'sunrise': sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude'])),
                       'sunset': sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude']), sunset=True)}
                      if CONFIG.get('latitude') is not None and CONFIG.get('longitude') is not None else None),
            'binding_actions': BINDING_ACTIONS,
            'pulse_ms': {'default': PULSE_MS_DEFAULT, 'min': PULSE_MS_MIN, 'max': PULSE_MS_MAX},
            'pulsing': [p.name for p in self.plugs.values() if p.pulsing],
            'managed': self.managed_for_ui(),
            'order': self.overview_order(),
        }

    def health(self):
        t0 = time.perf_counter()
        out = {
            'ok': True,
            'version': __version__,
            'uptime_s': int(time.time() - self.started),
            'connected': self.connected,
            'last_connect': int(self.last_connect) if self.last_connect else None,
            'last_disconnect': int(self.last_disconnect) if self.last_disconnect else None,
            'connect_failures': self.connect_failures,
            'last_error': self.last_error,
            'messages': self.messages,
            'last_message': int(self.last_message_at) if self.last_message_at else None,
            'bridge_state': self.bridge.get('state'),
            'subscriptions': [t for t, _ in self.topics()],
            'pushes': {'listening': bool(CONFIG.get('sensor_listen')),
                       'endpoint': 'http://%s:%s/' % (CONFIG['sensor_listen_host'], CONFIG['sensor_listen_port'])
                       if CONFIG.get('sensor_listen') else None,
                       'received': self.pushes_received, 'rejected': self.pushes_rejected,
                       'last': int(self.last_push_at) if self.last_push_at else None},
            'db': dict(self.store.stats(), **self.store.latency()),
            'last_aggregate': self.store.get_meta('last_aggregate_ts'),
            'config_notes': CONFIG_NOTES,
        }
        # how long the daemon itself needed to answer this (a status build is similar work)
        out['api_ms'] = round((time.perf_counter() - t0) * 1000, 2)
        return out

    # -- privileged actions -------------------------------------------------
    def session_valid(self, token):
        entry = self.sessions.get(str(token or ''))
        if not entry:
            return False
        if entry['until'] < time.time():
            self.sessions.pop(str(token), None)
            return False
        return True

    def unlocked_until(self):
        now = time.time()
        for token, entry in list(self.sessions.items()):
            if entry['until'] < now:
                del self.sessions[token]
        return max((e['until'] for e in self.sessions.values()), default=None)

    def unlock(self, pin, minutes, client=''):
        err = self.check_pin(pin)
        if err:
            return None, err
        minutes = max(1, min(720, int(minutes or 15)))
        token = secrets.token_urlsafe(24)
        self.store.add_event('audit', 'editing unlocked for %d min%s'
                             % (minutes, (' from ' + client) if client else ''))
        until = time.time() + minutes * 60
        self.sessions[token] = {'until': until, 'minutes': minutes, 'client': client, 'since': int(time.time())}
        self.store.add_event('security', 'editing unlocked for %d min' % minutes)
        log('dashboard editing unlocked for %d min' % minutes)
        return {'token': token, 'until': int(until), 'minutes': minutes}, None

    def lock_editing(self, token=None):
        if token and token in self.sessions:
            del self.sessions[token]
        else:
            self.sessions.clear()
        self.store.add_event('security', 'editing locked')
        log('dashboard editing locked')

    def check_pin(self, given, session=None):
        """None when allowed: a valid unlock session, no PIN configured, or the right PIN."""
        if session and self.session_valid(session):
            return None
        pin = str(CONFIG.get('pin') or '')
        if not pin:
            return None
        if session and not given:
            return 'the editing session has expired - unlock again'
        now = time.time()
        if now < self.pin_locked_until:
            return 'too many wrong PINs; try again in %ds' % (self.pin_locked_until - now)
        if str(given or '') != pin:
            self.pin_failures += 1
            if self.pin_failures >= int(CONFIG.get('pin_attempts') or 5):
                self.pin_locked_until = now + int(CONFIG.get('pin_lockout_s') or 300)
                self.pin_failures = 0
                self.store.add_event('security', 'PIN locked after repeated failures', 'warn')
                return 'too many wrong PINs; locked for %ds' % int(CONFIG.get('pin_lockout_s') or 300)
            return 'wrong PIN'
        self.pin_failures = 0
        return None

    def permit_join(self, enable, seconds=254):
        if not self.connected or not self.client:
            raise RuntimeError('not connected to the broker')
        topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/permit_join'
        body = {'time': int(seconds) if enable else 0}
        info = self.client.publish(topic, json.dumps(body), qos=1)
        if hasattr(info, 'rc') and info.rc != 0:
            raise RuntimeError('publish failed (%s) - check the broker ACL for %s' % (info.rc, topic))
        self.bridge['permit_join'] = bool(enable)
        self.bridge['permit_join_end'] = int((time.time() + seconds) * 1000) if enable else None
        self.store.add_event('control', 'permit join %s' % ('enabled for %ds' % seconds if enable else 'disabled'))
        log('permit join %s' % ('on' if enable else 'off'))
        return body

    def reset(self, scope, device=None):
        device_id = self.store.resolve(device) if device else None
        if scope == 'device' and not device_id:
            raise ValueError('unknown device %r' % device)
        dropped = []
        if scope == 'device':
            row = self.store.device(device_id)
            dropped = self.forget_device_cleanup(device_id, (row.get('alias') or row['name']) if row else device_id)
        self.store.reset(scope, device_id)
        if scope in ('all',):
            self.live.clear()
            self.names.clear()
        elif scope == 'device':
            self.live.pop(device_id, None)
            for n, i in list(self.names.items()):
                if i == device_id:
                    del self.names[n]
        elif scope == 'history':
            pass
        self.store.add_event('control', 'recorded data erased: %s%s' % (scope, ' ' + device if device else ''),
                             'warn')
        log('data reset: %s %s' % (scope, device or ''))
        self.bump()
        return dropped

    # -- main loop ------------------------------------------------------------
    def run(self):
        for note in CONFIG_NOTES:
            log('config: ' + note, 'warn')
        try:
            server = ApiServer(self)
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                log('cannot listen on %s:%s - another zigmon is already running there '
                    '(systemctl status zigmon). Stop it first, or point --config at a file '
                    'with a different api_port.' % (CONFIG['api_host'], CONFIG['api_port']), 'error')
            else:
                log('cannot listen on %s:%s - %s' % (CONFIG['api_host'], CONFIG['api_port'], e), 'error')
            return 2
        self.connect()
        server.start()
        self._running = True
        if self.plugs or self.sensors:
            self._plug_thread = threading.Thread(target=self.plug_loop, name='plugs', daemon=True)
            self._plug_thread.start()
            log('polling %d plug(s) and %d sensor(s): %s' % (len(self.plugs), len(self.sensors),
                                                            ', '.join(list(self.plugs) + list(self.sensors))))
        if CONFIG.get('sensor_listen'):
            threading.Thread(target=self.serve_pushes, name='pushes', daemon=True).start()
        log('zigmon %s running; API on http://%s:%d' % (__version__, CONFIG['api_host'], CONFIG['api_port']))
        while not self._stop.is_set():
            self._stop.wait(30)
            ensure_log_current()
            now = time.time()
            if now - self.last_aggregate_at >= int(CONFIG.get('aggregate_interval') or 3600):
                self.last_aggregate_at = now
                self.store.set_meta('last_aggregate_ts', str(int(now)))
                try:
                    self.purge_per_device()
                except Exception as e:
                    log('per-device retention: %s' % e, 'warn')
                try:
                    n = self.store.aggregate()
                    if n:
                        log('rolled up %d hourly rows' % n, 'debug')
                except Exception as e:
                    log('aggregate: %s' % e, 'error')
        log('stopping')
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass
        server.stop()
        return 0

    def stop(self, *_):
        self._stop.set()

    def reopen_log(self, *_):
        open_log()
        log('log file reopened')


# ---------------------------------------------------------------------------
# HTTP API
# ---------------------------------------------------------------------------
class ApiHandler(BaseHTTPRequestHandler):
    server_version = 'zigmon/' + __version__
    daemon = None

    def log_message(self, fmt, *args):
        log('api %s' % (fmt % args), 'debug')

    def _send(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _error(self, status, message):
        self._send(status, {'ok': False, 'error': message})

    def _query(self):
        url = urlparse(self.path)
        return url.path, {k: v[-1] for k, v in parse_qs(url.query).items()}

    def _body(self):
        length = int(self.headers.get('Content-Length') or 0)
        if length <= 0:
            return {}
        if length > 65536:
            raise ValueError('body too large')
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise ValueError('body is not JSON')
        return data if isinstance(data, dict) else {}

    def _authorised(self):
        given = self.headers.get('X-Zigmon-Token') or ''
        return bool(given) and secrets.compare_digest(given, self.daemon.token)

    def do_GET(self):
        d = self.daemon
        path, q = self._query()
        try:
            if path == '/api/status':
                return self._send(200, d.status())
            if not CONFIG.get('public_view', True):
                token = self.headers.get('X-Zigmon-Session') or ''
                if path != '/api/health' and not d.session_valid(token):
                    return self._error(403, 'view locked - unlock with the PIN')
            if path == '/api/health':
                return self._send(200, d.health())
            if path == '/api/db/backups':
                return self._send(200, {'ok': True, 'backups': d.db_backups(), 'dir': str(d.backup_dir())})
            if path == '/api/devices':
                return self._send(200, {'ok': True, 'devices': d.status()['devices']})
            if path == '/api/device':
                device_id = d.store.resolve(q.get('id') or q.get('name') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                dev = d.store.device(device_id)
                out = d.describe(dev, d.live.get(device_id))
                out['keys'] = d.store.keys_for(device_id)
                out['exposes'] = dev.get('exposes') or {}
                return self._send(200, dict(out, ok=True))
            if path == '/api/history':
                device_id = d.store.resolve(q.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                seconds = parse_span(q.get('range', '24h'))
                points = max(20, min(5000, int(q.get('points', 600))))
                keys = [k for k in (q.get('keys') or '').split(',') if k]
                if not keys:
                    keys = [k for k in d.store.keys_for(device_id) if k != 'linkquality'][:4]
                rows = d.store.history(device_id, keys, seconds, points)
                return self._send(200, {'ok': True, 'device': device_id, 'keys': keys,
                                        'range_s': seconds, 'rows': rows})
            if path == '/api/events':
                limit = max(1, min(1000, int(q.get('limit', 100))))
                device_id = d.store.resolve(q.get('device')) if q.get('device') else None
                rows = d.store.events(limit, device_id)
                names = {x['id']: x['name'] for x in d.store.devices(include_removed=True)}
                for r in rows:
                    r['device_name'] = names.get(r['device']) if r['device'] else None
                return self._send(200, {'ok': True, 'events': rows})
            if path == '/api/wait':
                since = int(numeric(q.get('seq')) or 0)
                timeout = float(numeric(q.get('timeout')) or 25.0)
                seq = d.wait_for_change(since, timeout)
                return self._send(200, {'ok': True, 'seq': seq})
            if path == '/api/plugs':
                return self._send(200, {'ok': True, 'plugs': [d.plug_snapshot(p) for p in d.plugs.values()]})
            if path == '/api/plug':
                p = d.plug_by_name(q.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                if q.get('refresh'):
                    d.poll_plug(p, force=True)
                return self._send(200, dict(d.plug_snapshot(p), ok=True))
            if path == '/api/bindings':
                return self._send(200, {'ok': True, 'bindings': d.bindings(), 'actions': BINDING_ACTIONS,
                                        'plugs': list(d.plugs)})
            if path == '/api/managed':
                return self._send(200, dict(d.managed_for_ui(), ok=True))
            if not CONFIG.get('public_view', True):
                token = self.headers.get('X-Zigmon-Session') or ''
                if path != '/api/health' and not d.session_valid(token):
                    return self._error(403, 'view locked - unlock with the PIN')
            if path == '/api/energy/daily':
                name = (parse_qs(urlparse(self.path).query).get('plug') or [''])[0]
                targets = list(d.plugs.values()) if name == '*' else [d.plug_by_name(name)]
                if not targets or targets[0] is None:
                    return self._error(404, 'unknown plug')
                now = time.time()
                lt = time.localtime(now)
                midnight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
                days = []
                for i in range(29, -1, -1):
                    t0 = midnight - i * 86400
                    t1 = min(t0 + 86400, now)
                    wh = sum(d.store.counter_delta(p.device_id, 'switch.aenergy.total', t0, t1) for p in targets)
                    days.append({'day': time.strftime('%m-%d', time.localtime(t0)), 'wh': round(wh, 2)})
                return self._send(200, {'ok': True, 'plug': 'All plugs' if name == '*' else targets[0].name, 'days': days})
            if path == '/api/health':
                return self._send(200, {'ok': True, 'version': __version__,
                                        'broker': bool(d.connected),
                                        'bridge': d.bridge.get('state') or 'unknown'})
            if path == '/api/rules':
                return self._send(200, {'ok': True, 'rules': d.rules(), 'ops': RULE_OPS})
            if path == '/api/scenes':
                return self._send(200, {'ok': True, 'scenes': d.scenes()})
            if path == '/api/schedules':
                return self._send(200, {'ok': True, 'schedules': d.schedules()})
            if path == '/api/sequences':
                return self._send(200, {'ok': True, 'sequences': d.sequences(), 'positions': d.sequence_positions()})
            if path == '/api/energy':
                return self._send(200, dict(d.energy_summary(), ok=True))
            if path == '/api/export':
                return self._send(200, dict(d.export_settings(), ok=True))
            if path == '/api/keys':
                device_id = d.store.resolve(q.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                return self._send(200, {'ok': True, 'keys': d.store.keys_for(device_id)})
            return self._error(404, 'no such endpoint')
        except ValueError as e:
            return self._error(400, str(e))
        except Exception as e:
            log('api %s: %s' % (path, e), 'error')
            return self._error(500, 'internal error: %s' % e)

    def do_POST(self):
        d = self.daemon
        path, _ = self._query()
        if not self._authorised():
            return self._error(403, 'missing or wrong API token')
        try:
            body = self._body()
        except ValueError as e:
            return self._error(400, str(e))
        try:
            if path == '/api/unlock':
                result, err = d.unlock(body.get('pin'), body.get('minutes'),
                                       str(self.headers.get('X-Zigmon-Client') or '')[:60])
                if err:
                    return self._error(403, err)
                return self._send(200, dict(result, ok=True))
            if path == '/api/lock':
                d.lock_editing(body.get('session'))
                return self._send(200, {'ok': True})
            if path == '/api/permit-join':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                enable = bool(body.get('enable', True))
                seconds = max(10, min(254, int(body.get('time', 254))))
                result = d.permit_join(enable, seconds)
                return self._send(200, {'ok': True, 'permit_join': enable, 'request': result})
            if path == '/api/plug/switch':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                p = d.plug_by_name(body.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                if body.get('pulse'):
                    ok, message = d.pulse_plug(p, body.get('ms'))
                elif body.get('toggle'):
                    ok, message = d.toggle_plug(p)
                else:
                    ok, message = d.set_plug_output(p, bool(body.get('on')))
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message,
                                                        'plug': d.plug_snapshot(p)})
            if path == '/api/plug/reset':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                p = d.plug_by_name(body.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                types = body.get('types') if isinstance(body.get('types'), list) else []
                ok, message = d.reset_plug_counters(p, types)
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message,
                                                        'plug': d.plug_snapshot(p)})
            if path == '/api/bindings':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_bindings(body.get('bindings') or [])
                return self._send(200, {'ok': True, 'bindings': saved})
            if path == '/api/order':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_overview_order(body.get('plugs'), body.get('devices'), body.get('groups'),
                                              body.get('sensors'), body.get('buttons'))
                return self._send(200, dict(saved, ok=True))
            if path == '/api/device/rename':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                device_id = d.store.resolve(body.get('id') or body.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                try:
                    message = d.rename_device(device_id, body.get('name'))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/scenes':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_scenes(body.get('scenes') or [])
                return self._send(200, {'ok': True, 'scenes': saved})
            if path == '/api/sequences':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    saved = d.save_sequences(body.get('sequences') or [])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'sequences': saved})
            if path in ('/api/sequence/advance', '/api/sequence/reset'):
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                fn = d.advance_sequence if path.endswith('advance') else d.reset_sequence
                ok, message = fn(str(body.get('id') or ''), 'the dashboard')
                if not ok:
                    return self._error(404, message)
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/schedules':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    saved = d.save_schedules(body.get('schedules') or [])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'schedules': saved})
            if path == '/api/scene/run':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                ok, message = d.run_scene(str(body.get('id') or ''), 'the dashboard')
                if not ok:
                    return self._error(404, message)
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/rule/dryrun':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    result = d.dryrun_rule(body.get('rule') or {}, int(numeric(body.get('days')) or 7))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, dict(result, ok=True))
            if path == '/api/sessions':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                now = time.time()
                out = [{'client': e.get('client') or '?', 'until': int(e['until']), 'since': e.get('since')}
                       for e in d.sessions.values() if e['until'] > now]
                return self._send(200, {'ok': True, 'sessions': out})
            if path == '/api/db/check':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, dict(d.store.integrity_check(), ok=True))
            if path == '/api/db/optimize':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                result = d.store.optimize()
                d.store.add_event('control', 'database optimised: %.1f -> %.1f MB in %.1f s'
                                  % (result['before_bytes'] / 1048576.0, result['after_bytes'] / 1048576.0, result['seconds']))
                return self._send(200, dict(result, ok=True))
            if path == '/api/db/backup':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, dict(d.db_backup_now(), ok=True, backups=d.db_backups()))
            if path == '/api/db/restore':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    result = d.db_restore(str(body.get('file') or ''))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, dict(result, ok=True))
            if path == '/api/backup/run':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                d.run_backup()
                return self._send(200, {'ok': True, 'message': 'Backup written to ' + str(d.backup_dir())
                                        + (' (the Zigbee2MQTT part arrives when the bridge answers)'
                                           if int(CONFIG.get('backup_zigbee') or 0) else '')})
            if path == '/api/lock-all':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                n = len(d.sessions)
                d.sessions.clear()
                d.store.add_event('audit', 'every editing session locked (%d)' % n)
                d.bump()
                return self._send(200, {'ok': True, 'message': '%d session(s) locked' % n})
            if path == '/api/config':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    changed = d.save_config_overrides(body)
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'changed': changed})
            if path == '/api/gateways':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    saved = d.save_managed_gateways(body.get('gateways') or [])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'gateways': saved})
            if path == '/api/overview-layout':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_overview_layout(body.get('items'))
                return self._send(200, {'ok': True, 'items': saved})
            if path == '/api/energy/reset':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    label = d.reset_energy_summary(str(body.get('plug') or '*'))
                except ValueError as e:
                    return self._error(404, str(e))
                return self._send(200, {'ok': True, 'message': 'Energy summary starts from zero for ' + label})
            if path == '/api/notify':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                settings = {k: bool(body.get(k)) for k in ('crit', 'warn', 'rule', 'offline', 'switch')}
                devices = body.get('devices')
                if isinstance(devices, dict):
                    settings['devices'] = {str(k)[:80]: str(v)[:80] for k, v in list(devices.items())[:300]
                                           if notify_override_set(v) is not None}
                d.store.set_meta('notify', json.dumps(settings))
                d.bump()
                return self._send(200, dict(settings, ok=True))
            if path == '/api/notify/test':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                if not d.notify_channels():
                    return self._error(400, 'no channel configured - set notify_ntfy or the telegram pair in config.json')
                d.notify('A test message from the dashboard. If you can read this, it works.', 'info')
                return self._send(200, {'ok': True, 'channels': d.notify_channels()})
            if path == '/api/import':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    counts = d.import_settings(body.get('data'))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'imported': counts})
            if path == '/api/rules':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_rules(body.get('rules') or [])
                return self._send(200, {'ok': True, 'rules': saved})
            if path == '/api/managed':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_managed(body.get('plugs') or [], body.get('sensors') or [])
                return self._send(200, dict(saved, ok=True))
            if path == '/api/managed/test':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                host = str(body.get('host') or '').strip()
                if not host:
                    return self._error(400, 'no address')
                try:
                    return self._send(200, d.test_device(host, body.get('password') or ''))
                except PlugError as e:
                    return self._error(502, str(e))
            if path == '/api/managed/discover':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'devices': d.discover_devices(3.0)})
            if path == '/api/reset':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                scope = str(body.get('scope') or 'history')
                if scope not in ('all', 'history', 'events', 'device'):
                    return self._error(400, 'scope must be all, history, events or device')
                dropped = d.reset(scope, body.get('device'))
                return self._send(200, {'ok': True, 'scope': scope, 'removed_with_it': dropped or []})
            return self._error(404, 'no such endpoint')
        except (ValueError, RuntimeError) as e:
            return self._error(400, str(e))
        except Exception as e:
            log('api %s: %s' % (path, e), 'error')
            return self._error(500, 'internal error: %s' % e)


class ApiServer(object):
    def __init__(self, daemon):
        handler = type('BoundHandler', (ApiHandler,), {'daemon': daemon})
        self.httpd = ThreadingHTTPServer((CONFIG['api_host'], int(CONFIG['api_port'])), handler)
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, name='api', daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------
class Palette(object):
    def __init__(self, enabled):
        self.on = enabled

    def _c(self, code, text):
        return '\033[%sm%s\033[0m' % (code, text) if self.on else str(text)

    def ok(self, t): return self._c('32', t)
    def warn(self, t): return self._c('33', t)
    def crit(self, t): return self._c('31', t)
    def dim(self, t): return self._c('2', t)
    def bold(self, t): return self._c('1', t)
    # the names the Shelly toolkit uses
    def title(self, t): return self._c('1;36', t)
    def rule(self, t): return self._c('36', t)
    def group(self, t): return self._c('1;35', t)
    def key(self, t): return self._c('37', t)
    def value(self, t): return self._c('1;33', t)
    def note(self, t): return self._c('2;37', t)
    def bad(self, t): return self._c('1;31', t)
    def info(self, t): return self._c('34', t)

    def level(self, level, text=None):
        text = level if text is None else text
        return {'ok': self.ok, 'warn': self.warn, 'crit': self.crit}.get(level, self.dim)(text)


def api_call(path, method='GET', payload=None, timeout=10.0, token=None):
    import urllib.request
    import urllib.error
    url = 'http://%s:%d%s' % (CONFIG['api_host'], int(CONFIG['api_port']), path)
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header('Accept', 'application/json')
    if data is not None:
        req.add_header('Content-Type', 'application/json')
    if method != 'GET':
        token = token or read_token()
        if token:
            req.add_header('X-Zigmon-Token', token)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode('utf-8'))
        except Exception:
            return e.code, {'ok': False, 'error': str(e)}
    except (urllib.error.URLError, OSError, ValueError) as e:
        return 0, {'ok': False, 'error': str(e)}


def read_token():
    try:
        return token_path().read_text().strip()
    except OSError:
        return None


def fmt_value(entry):
    v = entry.get('value')
    unit = entry.get('unit') or ''
    if isinstance(v, float):
        text = ('%.2f' % v).rstrip('0').rstrip('.')
    elif isinstance(v, bool):
        text = 'yes' if v else 'no'
    else:
        text = str(v)
    return (text + (' ' + unit if unit else '')).strip()


def cmd_status(args, pal):
    status_code, data = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    b = data['bridge']
    print(pal.bold('Broker    ') + data['broker'] + '  ' +
          (pal.ok('connected') if data['connected'] else pal.crit('disconnected')))
    print(pal.bold('Bridge    ') + '%s  %s  ch %s  %s' % (
        pal.level('ok' if b.get('state') == 'online' else 'crit', b.get('state') or '?'),
        b.get('version') or '', b.get('channel') or '?',
        pal.warn('PERMIT JOIN OPEN') if b.get('permit_join') else ''))
    print(pal.bold('Overall   ') + pal.level(data['level'], data['level']))
    print()
    devices = data['devices']
    if not devices:
        print(pal.dim('no devices recorded yet'))
        return 0
    width = max(len(d['name']) for d in devices)
    for d in devices:
        parts = [fmt_value(h) for h in d['headline']]
        extras = []
        if d.get('battery') is not None:
            extras.append('bat %d%%' % d['battery'])
        if d.get('linkquality') is not None:
            extras.append('lqi %d' % d['linkquality'])
        line = '%s  %-*s  %-6s %s  %s' % (
            pal.level(d['level'], '●'), width, d['name'], pal.level(d['level'], d['level']),
            '  '.join(parts), pal.dim(' '.join(extras)))
        print(line)
        print('   ' + pal.dim('%s %s · last %s ago%s' % (
            d.get('vendor') or '', d.get('model') or '', human_age(d['age_s']),
            (' · ' + '; '.join(d['reasons'])) if d['reasons'] else '')))
    return 0 if data['level'] in ('ok', 'unknown') else 1


def cmd_devices(args, pal):
    status_code, data = api_call('/api/devices')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    rows = data['devices']
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    print('%-22s %-20s %-10s %-12s %-24s %-8s %s' % ('NAME', 'ID', 'SOURCE', 'KIND', 'MODEL', 'LEVEL', 'LAST'))
    for d in rows:
        print('%-22s %-20s %-10s %-12s %-24s %s %s' % (
            d['name'][:22], d['id'][:20], d['source'], d.get('kind') or '',
            ((d.get('vendor') or '') + ' ' + (d.get('model') or '')).strip()[:24],
            pal.level(d['level'], '%-8s' % d['level']),
            human_age(d['age_s']) + ' ago' if d['age_s'] is not None else 'never'))
    return 0


def cmd_history(args, pal):
    span = args.range or '24h'
    query = '/api/history?device=%s&range=%s&points=%d' % (args.history, span, args.points)
    if args.keys:
        query += '&keys=' + args.keys
    status_code, data = api_call(query, timeout=60)
    if status_code != 200:
        print(pal.crit('error: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data, indent=2))
        return 0
    keys = data['keys']
    print('%-19s ' % 'TIME' + ' '.join('%12s' % k[:12] for k in keys))
    for r in data['rows']:
        stamp = datetime.fromtimestamp(r['ts']).strftime('%Y-%m-%d %H:%M:%S')
        print('%-19s ' % stamp + ' '.join(
            '%12s' % (('%.2f' % r[k]).rstrip('0').rstrip('.') if r.get(k) is not None else '-') for k in keys))
    print(pal.dim('%d rows' % len(data['rows'])))
    return 0


def cmd_events(args, pal):
    status_code, data = api_call('/api/events?limit=%d' % args.limit)
    if status_code != 200:
        print(pal.crit('error: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data['events'], indent=2, ensure_ascii=False))
        return 0
    for e in reversed(data['events']):
        stamp = datetime.fromtimestamp(e['ts']).strftime('%Y-%m-%d %H:%M:%S')
        who = e.get('device_name') or e.get('device') or ''
        print('%s  %s  %-12s %-18s %s' % (stamp, pal.level(e.get('level') or 'info', '●'),
                                          e['kind'], who[:18], e.get('detail') or ''))
    return 0


def cmd_watch(args, pal):
    """Subscribe directly and print what arrives, without the daemon."""
    seen = {'n': 0}
    done = threading.Event()

    def on_connect(client, userdata, flags, rc, *rest):
        if rc_failed(rc):
            print(pal.crit('connect refused: %s' % reason_text(rc)))
            done.set()
            return
        topics = [(CONFIG['base_topic'].rstrip('/') + '/#', 0)]
        topics += [(t, 0) for t in CONFIG.get('extra_topics') or []]
        client.subscribe(topics)
        print(pal.dim('connected to %s:%s, watching %s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port'],
                                                             ', '.join(t for t, _ in topics))))

    def on_message(client, userdata, msg):
        seen['n'] += 1
        text = msg.payload.decode('utf-8', 'replace')
        if '/bridge/' in msg.topic and not args.bridge:
            return
        if len(text) > 400 and not args.raw:
            text = text[:400] + '…'
        print('%s  %s  %s' % (pal.dim(datetime.now().strftime('%H:%M:%S')), pal.bold(msg.topic), text))
        if args.count and seen['n'] >= args.count:
            done.set()

    client = make_mqtt_client('zigmon-watch-%d' % os.getpid())
    client.on_connect = on_connect
    client.on_message = on_message
    try:
        client.connect(CONFIG['mqtt_host'], int(CONFIG['mqtt_port']), 30)
    except OSError as e:
        print(pal.crit('cannot connect: %s' % e))
        return 2
    client.loop_start()
    try:
        done.wait(args.seconds if args.seconds else None)
    except KeyboardInterrupt:
        pass
    client.loop_stop()
    client.disconnect()
    return 0


def cmd_permit_join(args, pal):
    enable = args.permit_join.lower() in ('on', 'yes', '1', 'true', 'open')
    payload = {'enable': enable, 'time': 254}
    if CONFIG.get('pin'):
        payload['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/permit-join', 'POST', payload)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok('permit join is now %s' % ('open for 254 s' if enable else 'closed')))
    return 0


def cmd_reset(args, pal):
    scope = args.reset_data
    device = None
    if scope not in ('all', 'history', 'events'):
        device, scope = scope, 'device'
    if not args.yes:
        answer = input('Erase %s%s? This cannot be undone [y/N] ' % (scope, ' for ' + device if device else ''))
        if answer.strip().lower() not in ('y', 'yes'):
            print('nothing done')
            return 0
    payload = {'scope': scope}
    if device:
        payload['device'] = device
    if CONFIG.get('pin'):
        payload['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/reset', 'POST', payload, timeout=120)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok('erased: %s' % scope))
    return 0


def _plug_line(pal, snap):
    v = snap['values']
    state = pal.dim('unreachable') if not snap['online'] else (pal.ok('ON') if snap['output'] else pal.warn('OFF'))
    parts = []
    if v.get('power') is not None:
        parts.append('%.1f W' % v['power'])
    if v.get('voltage') is not None:
        parts.append('%.1f V' % v['voltage'])
    if v.get('current') is not None:
        parts.append('%.3f A' % v['current'])
    if v.get('energy') is not None:
        parts.append('%.3f kWh' % (v['energy'] / 1000.0))
    if v.get('temperature') is not None:
        parts.append('%.1f °C' % v['temperature'])
    return '%s  %s  %s' % (pal.bold('%-14s' % snap['name']), state, '  '.join(parts))


def cmd_plug(args, pal):
    status_code, data = api_call('/api/plugs')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    plugs = data['plugs']
    if args.json:
        print(json.dumps(plugs, indent=2, ensure_ascii=False))
        return 0
    if not plugs:
        print(pal.dim('no plugs configured (see "plugs" in %s)' % CONFIG_FILE))
        return 0
    for snap in plugs:
        if args.plug not in ('all', snap['name']):
            continue
        print(_plug_line(pal, snap))
        info = snap.get('info') or {}
        print('   ' + pal.dim('%s %s %s · %s · %s' % (
            info.get('model') or '', info.get('app') or '', info.get('ver') or '', snap['host'],
            (snap['error'] or ('stale, ' + human_age(snap['age']) + ' old')) if snap['stale']
            else 'read %s ago' % human_age(snap['age']))))
        for c in snap['counters']:
            if c['value'] is None:
                continue
            since = ('since ' if c['reset_exact'] else 'since at least ') + \
                datetime.fromtimestamp(c['reset_at']).strftime('%Y-%m-%d') if c['reset_at'] else 'no reset date'
            print('   %-20s %-14s %s' % (c['label'], '%g' % c['value'], pal.dim(since)))
    return 0


def cmd_plug_switch(args, pal):
    if args.plug_on:
        name, body = args.plug_on, {'on': True}
    elif args.plug_off:
        name, body = args.plug_off, {'on': False}
    elif args.plug_pulse:
        name, body = args.plug_pulse, {'pulse': True, 'ms': args.ms}
    else:
        name, body = args.plug_toggle, {'toggle': True}
    body['name'] = name
    if CONFIG.get('pin'):
        body['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/plug/switch', 'POST', body, timeout=30 + (args.ms / 1000.0 if args.plug_pulse else 0))
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok(data.get('message')))
    return 0


def cmd_plug_reset(args, pal):
    name = args.plug_reset
    types = [t for t in (args.types or '').split(',') if t]
    body = {'name': name, 'types': types}
    if CONFIG.get('pin'):
        body['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/plug/reset', 'POST', body, timeout=60)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok(data.get('message')))
    return 0


def cmd_bindings(args, pal):
    status_code, data = api_call('/api/bindings')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data['bindings'], indent=2))
        return 0
    if not data['bindings']:
        print(pal.dim('no bindings; add them on the Control tab of the dashboard'))
        return 0
    status_code, st = api_call('/api/status')
    names = {x['id']: x['name'] for x in st.get('devices', [])} if status_code == 200 else {}
    targets = {t['value']: t['name'] for t in st.get('switch_targets', [])} if status_code == 200 else {}
    for sc in (st.get('scenes', []) if status_code == 200 else []):
        targets['scene:' + sc['id']] = 'scene ' + sc['name']
    for b in data['bindings']:
        what = b['do'] + (' %d ms' % b['pulse_ms'] if b['do'] == 'pulse' and b.get('pulse_ms') else '')
        print('%s %-18s %-10s -> %-18s %s' % (
            pal.ok('●') if b.get('enabled', True) else pal.dim('○'),
            names.get(b['device'], b['device']), b['action'],
            targets.get(b['plug'], b['plug']), pal.bold(what)))
    return 0


def cmd_rules(args, pal):
    status_code, data = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    rules = data.get('rules') or []
    if args.json:
        print(json.dumps(rules, indent=2))
        return 0
    if not rules:
        print(pal.dim('no rules; add them on the Control tab of the dashboard'))
        return 0
    names = {x['id']: x['name'] for x in data.get('devices', [])}
    targets = {t['value']: t['name'] for t in data.get('switch_targets', [])}
    for sc in data.get('scenes', []):
        targets['scene:' + sc['id']] = 'scene ' + sc['name']
    for r in rules:
        what = r['do'] + (' %d ms' % r['pulse_ms'] if r.get('pulse_ms') else '')
        state = pal.dim('?') if r.get('holds') is None else (pal.warn('TRUE') if r['holds'] else pal.ok('false'))
        print('%s %-18s %-22s -> %-12s %s %s %s' % (
            pal.ok('●') if r.get('enabled', True) else pal.dim('○'),
            names.get(r['device'], r['device']),
            '%s %s %g' % (r['key'], r['op'], r['value']),
            targets.get(r['plug'], r['plug']), pal.bold('%-12s' % what),
            state, pal.dim('now %g' % r['reading']) if r.get('reading') is not None else ''))
    return 0


def cmd_check(args, pal):
    problems = 0

    def verdict(ok, text, detail=''):
        nonlocal problems
        if not ok:
            problems += 1
        print('  %s  %s%s' % (pal.ok('✔') if ok else pal.crit('✘'), text,
                              pal.dim('  ' + detail) if detail else ''))

    print(pal.bold('zigmon %s' % __version__))
    verdict(mqtt is not None, 'paho-mqtt importable', '' if mqtt else 'dnf install python3-paho-mqtt')
    verdict(not CONFIG_FATAL, 'configuration readable', '; '.join(CONFIG_FATAL))
    t0 = time.time()
    status_code, health = api_call('/api/health', timeout=5)
    ms = (time.time() - t0) * 1000
    verdict(status_code == 200, 'daemon API answering', '%.0f ms' % ms if status_code == 200 else health.get('error', ''))
    if status_code != 200:
        print(pal.dim('  is zigmon.service running?  journalctl -u zigmon -n 30'))
        return 1
    verdict(health['connected'], 'connected to the broker', health.get('last_error') or '')
    verdict(health.get('bridge_state') == 'online', 'Zigbee2MQTT bridge online',
            'state: %s' % health.get('bridge_state'))
    age = time.time() - health['last_message'] if health.get('last_message') else None
    verdict(age is not None and age < 3600, 'messages flowing',
            'last %s ago' % human_age(age) if age is not None else 'none since start')
    token = read_token()
    verdict(bool(token), 'API token readable by %s' % _whoami(), str(token_path()))
    status_code, status = api_call('/api/status', timeout=5)
    if status_code == 200:
        c = status['counts']
        verdict(c['devices'] > 0, '%d device(s): %d ok, %d warn, %d crit' % (
            c['devices'], c['ok'], c['warn'], c['crit']), '')
        for d in status['devices']:
            if d['level'] != 'ok':
                print('     %s %s: %s' % (pal.level(d['level'], '●'), d['name'], '; '.join(d['reasons'])))
    status_code, plugs = api_call('/api/plugs', timeout=5)
    if status_code == 200:
        for snap in plugs['plugs']:
            verdict(snap['online'] and not snap['stale'], 'plug %s' % snap['name'],
                    snap['error'] or ('%s, %.1f W' % ('on' if snap['output'] else 'off', snap['values'].get('power') or 0)))
    db = health['db']
    verdict(True, 'database %s' % db['path'], '%s, %d samples, %d hourly, %d events' % (
        '%.1f MB' % (db['bytes'] / 1048576.0) if db.get('bytes') else '?', db['samples'],
        db['samples_hourly'], db['events']))
    return 1 if problems else 0


def cmd_diag(args, pal):
    print(pal.bold('Configuration in force (%s)' % CONFIG_FILE))
    for key in sorted(CONFIG):
        value = CONFIG[key]
        if key == 'mqtt_password' and value:
            value = '********'
        if key == 'pin' and value:
            value = '****'
        print('  %-24s %s' % (key, json.dumps(value)))
    for note in CONFIG_NOTES:
        print('  ' + pal.warn(note))
    for note in CONFIG_FATAL:
        print('  ' + pal.crit(note))
    print()
    for path in ('/api/health', '/api/status', '/api/events?limit=5'):
        t0 = time.time()
        status_code, data = api_call(path, timeout=5)
        print('  %-24s %s  %.0f ms' % (path, pal.ok(str(status_code)) if status_code == 200 else pal.crit(str(status_code)),
                                       (time.time() - t0) * 1000))
    status_code, health = api_call('/api/health', timeout=5)
    if status_code == 200:
        print()
        print(pal.bold('Daemon'))
        for key in ('version', 'uptime_s', 'connected', 'connect_failures', 'last_error', 'messages',
                    'bridge_state', 'subscriptions'):
            print('  %-24s %s' % (key, health.get(key)))
        print(pal.bold('Database'))
        for key, value in health['db'].items():
            if key == 'oldest' and value:
                value = datetime.fromtimestamp(value).strftime('%Y-%m-%d')
            if key == 'bytes' and value:
                value = '%.1f MB' % (value / 1048576.0)
            print('  %-24s %s' % (key, value))
    return 0


# ===========================================================================
# The Shelly toolkit - "zigmon shelly ..." - ported whole from upsmon
# ===========================================================================
def describe_plug_field(path):
    """A description for a status field, whichever component prefix it carries."""
    tail = re.sub(r'^[a-z_0-9]+:\d+\.', '', path)
    for candidate in (path, 'switch.' + tail, tail):
        if candidate in PLUG_DESCRIPTIONS:
            return PLUG_DESCRIPTIONS[candidate]
    return ''


RPC_METHODS = {
    # -- identity and housekeeping -----------------------------------------
    'Shelly.GetDeviceInfo': ('Model, name, firmware version and MAC.', None),
    'Shelly.GetStatus': ('Every component\'s current state in one reply.', None),
    'Shelly.GetConfig': ('Every component\'s configuration in one reply.', None),
    'Shelly.ListMethods': ('The list this command is built on.', None),
    'Shelly.GetComponents': ('Which components exist, with their keys.',
                             '{"offset":0}'),
    'Shelly.Reboot': ('Restart the device. Takes about ten seconds.', None),
    'Shelly.CheckForUpdate': ('Ask Shelly whether newer firmware exists.', None),
    'Shelly.Update': ('Install firmware. "stable" or "beta".',
                      '{"stage":"stable"}'),
    'Shelly.Identify': ('Flash the LED so you can tell which device it is.', None),
    'Shelly.DetectLocation': ('Set the timezone from the public IP address.', None),
    'Shelly.ListTimezones': ('Every timezone name the device accepts.', None),
    'Shelly.SetAuth': ('Set or clear the web password. The username is always '
                       'admin; a null password removes authentication.',
                       '{"user":"admin","realm":"shellyplug-xxxx","ha1":"..."}'),
    'Shelly.FactoryReset': ('Erase everything, including the Wi-Fi settings. '
                            'The device comes back as an access point.', None),
    'Shelly.ResetWiFiConfig': ('Forget the Wi-Fi settings only.', None),

    # -- the switch ---------------------------------------------------------
    'Switch.GetStatus': ('Power, voltage, current, energy, temperature and '
                         'relay state.', '{"id":0}'),
    'Switch.GetConfig': ('Name, auto-off timers, limits, initial state.',
                         '{"id":0}'),
    'Switch.SetConfig': ('Change any of those.',
                         '{"id":0,"config":{"auto_off":true,"auto_off_delay":300}}'),
    'Switch.Set': ('Switch the relay. "toggle_after" turns it back after N '
                   'seconds.', '{"id":0,"on":false}'),
    'Switch.Toggle': ('Flip the relay to the other state.', '{"id":0}'),
    'Switch.ResetCounters': ('Reset the running totals. Without "type", all of '
                             'them.', '{"id":0,"type":["aenergy"]}'),

    # -- system, network, radios -------------------------------------------
    'Sys.GetStatus': ('Uptime, free memory, filesystem, time, restart flag.', None),
    'Sys.GetConfig': ('Device name, timezone, location, debug settings.', None),
    'Sys.SetConfig': ('Change them.',
                      '{"config":{"device":{"name":"UPS socket"}}}'),
    'Sys.SetTime': ('Set the clock by hand, for a device with no internet.',
                    '{"unixtime":1788195638}'),
    'Wifi.GetStatus': ('Address, SSID, signal strength, connection state.', None),
    'Wifi.GetConfig': ('Both configured networks and the access point.', None),
    'Wifi.SetConfig': ('Change them. Getting this wrong takes the device off '
                       'the network.',
                       '{"config":{"sta":{"ssid":"net","pass":"secret","enable":true}}}'),
    'Wifi.Scan': ('List the networks the device can see.', None),
    'Wifi.ListAPClients': ('Who is connected to its own access point.', None),
    'Cloud.GetStatus': ('Whether it is talking to Shelly Cloud.', None),
    'Cloud.SetConfig': ('Turn the cloud connection on or off.',
                        '{"config":{"enable":false}}'),
    'Mqtt.GetStatus': ('Whether it is connected to an MQTT broker.', None),
    'Mqtt.SetConfig': ('Point it at a broker.',
                       '{"config":{"enable":true,"server":"10.0.0.2:1883"}}'),
    'BLE.GetConfig': ('Bluetooth radio and RPC-over-Bluetooth switches.', None),
    'BLE.SetConfig': ('Turn either on or off. Needs a reboot.',
                      '{"config":{"enable":true,"rpc":{"enable":true}}}'),
    'BLE.StartPairing': ('Accept a Bluetooth pairing for a while.', None),
    'BLE.ListPairedDevices': ('What is already paired.', None),
    'Matter.GetStatus': ('Whether Matter is on and commissionable.', None),
    'Matter.GetSetupCode': ('The pairing code a Matter controller needs.', None),
    'Matter.SetConfig': ('Turn Matter on or off. Needs a reboot.',
                         '{"config":{"enable":true}}'),
    'Matter.FactoryReset': ('Forget every Matter fabric it has joined.', None),
    'WS.GetConfig': ('Outbound websocket: where it connects out to.', None),
    'WS.SetConfig': ('Point it at a listener - what "shelly serve" accepts.',
                     '{"config":{"enable":true,"server":"ws://10.0.0.9:8089"}}'),

    # -- automation on the device itself -----------------------------------
    'Webhook.Create': ('Call a URL when something happens. This is how a '
                       'sleeping sensor reports.',
                       '{"cid":0,"enable":true,"event":"temperature.change",'
                       '"urls":["http://10.0.0.9:8088/?t=${ev.tC}"]}'),
    'Webhook.List': ('Every webhook currently set.', None),
    'Webhook.ListSupported': ('Which events this device can trigger on.', None),
    'Webhook.Delete': ('Remove one by id.', '{"id":1}'),
    'Webhook.DeleteAll': ('Remove all of them.', None),
    'Schedule.Create': ('Run something on a cron schedule, on the device.',
                        '{"enable":true,"timespec":"0 0 22 * * *",'
                        '"calls":[{"method":"Switch.Set","params":{"id":0,"on":false}}]}'),
    'Schedule.List': ('Every schedule currently set.', None),
    'Schedule.Delete': ('Remove one by id.', '{"id":1}'),
    'Script.List': ('Scripts stored on the device.', None),
    'Script.Create': ('Make an empty script slot.', '{"name":"watchdog"}'),
    'Script.PutCode': ('Upload JavaScript into a slot.',
                       '{"id":1,"code":"print(1);"}'),
    'Script.Start': ('Run it.', '{"id":1}'),
    'Script.Stop': ('Stop it.', '{"id":1}'),
    'KVS.Set': ('Store a value on the device, for scripts to read.',
                '{"key":"note","value":"UPS socket"}'),
    'KVS.Get': ('Read one back.', '{"key":"note"}'),
    'KVS.List': ('Every key stored.', None),
    'KVS.Delete': ('Remove one.', '{"key":"note"}'),
    'HTTP.GET': ('Make the device fetch a URL itself.',
                 '{"url":"http://10.0.0.9/ping"}'),
    'HTTP.POST': ('And post to one.',
                  '{"url":"http://10.0.0.9/hook","body":"{}"}'),
    'RPC.Ping': ('Check the device is answering at all.', None),
    'plugs_ui.GetConfig': ('The LED ring: colours, brightness, night mode.', None),
    'plugs_ui.SetConfig': ('Change them.',
                           '{"config":{"leds":{"mode":"power"}}}'),
}

# Components whose methods are all variations on a theme, so the group can be
# summarised rather than repeating a note against each entry.
RPC_COMPONENTS = {
    'Shelly': 'the device as a whole: identity, status, firmware, reboot',
    'Switch': 'the relay and its meter',
    'Sys': 'clock, name, timezone, memory',
    'Wifi': 'network settings and signal',
    'Cloud': 'the Shelly Cloud connection',
    'Mqtt': 'the MQTT broker connection',
    'BLE': 'the Bluetooth radio and RPC over Bluetooth',
    'Matter': 'Matter, for Apple Home and other controllers',
    'WS': 'the outbound websocket this tool can receive with "serve"',
    'Webhook': 'call a URL when something happens on the device',
    'Schedule': 'run something on a timer, on the device itself',
    'Script': 'JavaScript stored and run on the device',
    'KVS': 'a small key-value store for scripts',
    'HTTP': 'make the device fetch or post a URL itself',
    'OTA': 'firmware upload, used by Shelly.Update',
    'KNX': 'the KNX building-automation protocol',
    'BTHome': 'Bluetooth sensors reporting through this device',
    'BTHomeDevice': 'one such sensor',
    'BTHomeSensor': 'one measurement from such a sensor',
    'BTHomeControl': 'Bluetooth buttons and remotes',
    'Virtual': 'virtual components for scripts and the app UI',
    'Boolean': 'a virtual on/off value',
    'Number': 'a virtual number',
    'Text': 'a virtual string',
    'Enum': 'a virtual choice',
    'Group': 'a virtual group of components',
    'Button': 'a virtual button',
    'LNM': 'local network messaging between Shelly devices',
    'plugs_ui': 'the LED ring on the plug',
    'RPC': 'the RPC channel itself',
}



def shelly_targets():
    """Every device the configuration or the dashboard names: plugs first, then sensors."""
    out = {}
    for entry in CONFIG.get('plugs') or []:
        if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
            out[str(entry['name'])] = dict(entry, kind='plug')
    for entry in CONFIG.get('sensors') or []:
        if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
            out[str(entry['name'])] = dict(entry, kind='sensor')
    # what was added on the dashboard sits in the database
    try:
        db = sqlite3.connect('file:%s?mode=ro' % db_path(), uri=True, timeout=2)
        row = db.execute("SELECT value FROM meta WHERE key='managed'").fetchone()
        db.close()
        managed = json.loads(row[0]) if row and row[0] else {}
        for kind in ('plugs', 'sensors'):
            for entry in managed.get(kind) or []:
                if isinstance(entry, dict) and entry.get('name') and entry.get('host') \
                        and str(entry['name']) not in out:
                    out[str(entry['name'])] = dict(entry, kind=kind[:-1])
    except (sqlite3.Error, ValueError, OSError):
        pass
    return out


def shelly_for(role, args=None):
    """Build a client for a device named in the configuration, or an address given directly."""
    override_host = getattr(args, 'host', None) if args else None
    override_password = getattr(args, 'password', None) if args else None
    if override_host:
        return ShellyRPC(override_host, override_password or '', getattr(args, 'switch_id', 0) or 0,
                         label='the device at %s' % override_host)
    targets = shelly_targets()
    if not role:
        if not targets:
            raise PlugError('nothing configured - add a plug under "plugs" in %s, or give --host' % CONFIG_FILE)
        role = list(targets)[0]
    match = targets.get(role) or next((t for n, t in targets.items() if n.lower() == role.lower()), None)
    if match is None:
        raise PlugError('unknown device "%s" - configured: %s, or give --host'
                        % (role, ', '.join(targets) or 'none'))
    password = override_password if override_password is not None else (match.get('password') or '')
    return ShellyRPC(match['host'], password, match.get('switch_id') or 0,
                     label='%s %s' % (match['kind'], role))


SHELLY_COMPONENTS = ('Shelly.GetStatus', 'Shelly.GetConfig', 'Shelly.GetDeviceInfo',
                     'Sys.GetStatus', 'Wifi.GetStatus', 'Cloud.GetStatus',
                     'MQTT.GetStatus', 'BLE.GetConfig', 'Matter.GetStatus',
                     'Switch.GetStatus', 'Temperature.GetStatus',
                     'Humidity.GetStatus', 'DevicePower.GetStatus')


def shelly_everything(rpc):
    """Ask for every component the device might have; skip what it lacks."""
    out = {}
    for method in SHELLY_COMPONENTS:
        params = None
        if method.split('.')[0] in ('Switch', 'Temperature', 'Humidity', 'DevicePower'):
            params = {'id': rpc.switch_id
                      if method.startswith('Switch') else 0}
        try:
            result = rpc.call(method, params)
        except PlugError as e:
            if not is_missing_component(e):
                raise                # a rate limit or a dead network, not absence
            continue                 # not present on this model, which is normal
        if result is not None:
            out[method] = result
    return out


def shelly_print_flat(pal, flat, title=None):
    if title:
        print(pal.group(title))
    width = max([len(k) for k in flat] + [10])
    for key in sorted(flat):
        value = flat[key]
        if isinstance(value, list):
            value = ', '.join(str(v) for v in value)
        text = 'ON' if value is True else 'OFF' if value is False else str(value)
        painter = (pal.ok if value is True else pal.bad if value is False
                   else pal.note if value is None or value == '' else pal.value)
        print('  %s : %s' % (pal.key(key.ljust(width)), painter(text)))
        note = describe_plug_field(key)
        if note:
            print('  %s   %s' % (' ' * width, pal.note(note)))


# ---- mDNS discovery -------------------------------------------------------
def local_ipv4_addresses():
    """Every IPv4 address this machine holds, one per interface.

    A multi-homed host routes 224.0.0.251 out one interface only - whichever
    the default route uses. On a machine with several VLANs that is usually not
    the one the device or its proxy is on, so the query has to be sent out of
    each of them deliberately.
    """
    import fcntl
    import struct
    addresses = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        for _, name in socket.if_nameindex():
            try:
                packed = fcntl.ioctl(sock.fileno(), 0x8915,   # SIOCGIFADDR
                                     struct.pack('256s', name.encode()[:15]))
                address = socket.inet_ntoa(packed[20:24])
            except OSError:
                continue
            if not address.startswith('127.'):
                addresses.append((name, address))
    except (OSError, AttributeError):
        pass
    finally:
        sock.close()
    return addresses


def shelly_discover(pal, seconds=4.0):
    """Find Shelly devices by asking over multicast DNS.

    Two sockets, deliberately. Answers to a multicast query come back two ways:
    to the group on port 5353, and - when the question asks for it - by unicast
    to whatever port the query went out from.

    Binding 5353 alone is not enough and can be worse than useless: avahi-daemon
    usually holds it already, and with SO_REUSEPORT a unicast datagram to that
    port is delivered to exactly one of the sockets bound to it. That is as
    likely to be avahi as us. So the query is sent from a socket on a port
    nobody else has, which is where the unicast reply then arrives, while a
    second socket joins the group to catch the multicast one.
    """
    import struct

    def encode_name(name):
        out = b''
        for label in name.split('.'):
            if label:
                out += bytes([len(label)]) + label.encode('ascii')
        return out + b'\x00'

    def read_name(data, offset, depth=0):
        parts = []
        while offset < len(data) and depth < 20:
            length = data[offset]
            if length == 0:
                offset += 1
                break
            if length & 0xC0 == 0xC0:
                pointer = struct.unpack('!H', data[offset:offset + 2])[0] & 0x3FFF
                parts.append(read_name(data, pointer, depth + 1)[0])
                offset += 2
                break
            parts.append(data[offset + 1:offset + 1 + length].decode('ascii', 'replace'))
            offset += 1 + length
        return '.'.join(p for p in parts if p), offset

    services = ['_shelly._tcp.local', '_http._tcp.local',
                '_services._dns-sd._udp.local']

    # The querying socket, on a port of our own.
    asker = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
    asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
    asker.settimeout(0.2)
    try:
        asker.bind(('', 0))
    except OSError as e:
        print(pal.bad('cannot open a socket for the query: %s' % e))
        return {}

    # And a listener on the group, for replies sent the multicast way.
    listener = None
    try:
        listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, 'SO_REUSEPORT'):
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        listener.bind(('', 5353))
        listener.settimeout(0.2)
    except OSError:
        if listener:
            listener.close()
        listener = None

    interfaces = local_ipv4_addresses()

    # Join the group on each interface by name. INADDR_ANY leaves the choice to
    # the kernel, which picks one - on a host with several VLANs that is
    # usually not the one the answer arrives on.
    joined = 0
    if listener:
        targets = [address for _, address in interfaces] or ['0.0.0.0']
        for address in targets:
            try:
                listener.setsockopt(
                    socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                    struct.pack('4s4s', socket.inet_aton('224.0.0.251'),
                                socket.inet_aton(address)))
                joined += 1
            except OSError as e:
                log('could not join the multicast group on %s: %s' % (address, e),
                    'debug')
        if not joined:
            listener.close()
            listener = None
    shelly_discover.joined = joined
    shelly_discover.interfaces = interfaces
    shelly_discover.query_port = asker.getsockname()[1]

    sent = 0
    for service in services:
        # Two questions, differing only in the top bit of the class.
        #
        # 0x8001 asks for a unicast answer, which is what gets a reply back
        # through a router that will not carry multicast.
        #
        # 0x0001 asks for the ordinary multicast answer, and that is the one an
        # avahi reflector can work with: a reflector repeats multicast between
        # interfaces and does nothing at all with unicast replies. On a network
        # where the only path is a reflector, asking for unicast quietly
        # guarantees no answer.
        for qclass in (0x8001, 0x0001):
            query = (struct.pack('!HHHHHH', 0, 0, 1, 0, 0, 0)
                     + encode_name(service) + struct.pack('!HH', 12, qclass))
            # Out of every interface, not just whichever the default route picks.
            for name, address in (interfaces or [(None, None)]):
                try:
                    if address:
                        asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF,
                                         socket.inet_aton(address))
                    asker.sendto(query, ('224.0.0.251', 5353))
                    sent += 1
                except OSError as e:
                    log('mDNS query out of %s failed: %s'
                        % (name or 'default', e), 'debug')
    if not sent:
        print(pal.bad('could not send the query out of any interface'))
        asker.close()
        if listener:
            listener.close()
        return {}

    found = {}
    addresses = {}
    sockets = [s for s in (asker, listener) if s]
    deadline = time.time() + seconds
    while time.time() < deadline:
        ready, _, _ = select.select(sockets, [], [], 0.3)
        for sock in ready:
            try:
                data, addr = sock.recvfrom(9000)
            except (socket.timeout, OSError):
                continue

            names = []
            try:
                counts = struct.unpack('!HHHHHH', data[:12])
                offset = 12
                for _ in range(counts[2]):
                    _, offset = read_name(data, offset)
                    offset += 4
                for _ in range(counts[3] + counts[4] + counts[5]):
                    name, offset = read_name(data, offset)
                    rtype, _cls, _ttl, length = struct.unpack(
                        '!HHIH', data[offset:offset + 10])
                    offset += 10
                    body = data[offset:offset + length]
                    if rtype == 12:                   # PTR
                        target, _ = read_name(data, offset)
                        names.append(target)
                    elif rtype == 33 and length > 6:  # SRV
                        target, _ = read_name(data, offset + 6)
                        names.append(target)
                    elif rtype == 1 and length == 4:  # A
                        addresses[name.split('.')[0].lower()] = socket.inet_ntoa(body)
                    offset += length
            except (struct.error, IndexError):
                pass

            entry = found.setdefault(addr[0], {'ip': addr[0], 'names': set()})
            for name in names:
                short = name.split('.')[0]
                # A name beginning with an underscore is a service type, not a
                # device: enumerating _services._dns-sd._udp.local answers with
                # "_shelly._tcp.local", which is the question, not a device.
                if short.startswith('_'):
                    continue
                if 'shelly' in short.lower():
                    entry['names'].add(short)

    asker.close()
    if listener:
        listener.close()

    # Prefer the address a device published for itself over the packet's source,
    # which is the proxy when one is in the way.
    result = {}
    for entry in found.values():
        if not entry['names']:
            continue
        for name in entry['names']:
            ip = addresses.get(name.lower(), entry['ip'])
            record = result.setdefault(ip, {'ip': ip, 'names': {},
                                            'via': entry['ip'] if ip != entry['ip'] else None})
            # Devices answer with the same name in different case depending on
            # which record it came from; keep one of each, preferring the form
            # the device uses for its own hostname.
            record['names'].setdefault(name.lower(), name)
            if name.islower():
                record['names'][name.lower()] = name
    return {ip: {'ip': ip, 'names': sorted(r['names'].values()), 'via': r['via']}
            for ip, r in result.items()}


# ---- WebSocket, for live pushes -------------------------------------------
def _ws_send(sock, payload):
    """Send one masked text frame, as a client must."""
    import struct
    data = payload.encode('utf-8')
    header = bytes([0x81])
    mask = secrets.token_bytes(4)
    if len(data) < 126:
        header += bytes([0x80 | len(data)])
    elif len(data) < 65536:
        header += bytes([0x80 | 126]) + struct.pack('!H', len(data))
    else:
        header += bytes([0x80 | 127]) + struct.pack('!Q', len(data))
    masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    sock.sendall(header + mask + masked)


def _ws_frames(sock):
    """Yield the payload of each text frame arriving on an open socket."""
    import struct
    buffer = b''

    def need(count):
        nonlocal buffer
        while len(buffer) < count:
            chunk = sock.recv(65536)
            if not chunk:
                raise ConnectionError('the connection closed')
            buffer += chunk
        taken, buffer = buffer[:count], buffer[count:]
        return taken

    while True:
        first, second = need(2)
        opcode = first & 0x0F
        masked = second & 0x80
        length = second & 0x7F
        if length == 126:
            length = struct.unpack('!H', need(2))[0]
        elif length == 127:
            length = struct.unpack('!Q', need(8))[0]
        mask = need(4) if masked else None
        payload = need(length) if length else b''
        if mask:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        if opcode == 0x8:                       # close
            return
        if opcode == 0x9:                       # ping, answer with a pong
            sock.sendall(bytes([0x8A, 0x00]))
            continue
        if opcode in (0x1, 0x2) and payload:
            yield payload.decode('utf-8', 'replace')



def shelly_build_parser():
    """One subparser per command, so each has its own --help like any tool."""
    parser = argparse.ArgumentParser(
        prog='zigmon shelly',
        description='Talk to the Shelly devices named in the configuration over '
                    'their local RPC API. No pairing and no cloud: the device '
                    'answers on plain HTTP while it stays connected to the '
                    'Shelly app, the cloud and Apple Home over Matter.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
addressing a device
  zigmon shelly Lednice info         a plug or sensor by the name it has in the configuration
  zigmon shelly info                 with no name, the first configured plug is assumed
  zigmon shelly --host 10.0.0.5 info  something not in the configuration at all

commands at a glance
  reading        discover, info, dump, methods, poll, watch, listen, serve
  controlling    on, off, toggle, reset-counters, reboot
  configuring    config, matter, ble
  anything else  call

quoting JSON
  Linux and PowerShell:  call Switch.SetConfig '{"id":0,"config":{"power_limit":2900}}'
  cmd.exe:               call Switch.SetConfig "{\\"id\\":0,\\"config\\":{\\"power_limit\\":2900}}"

Run 'zigmon shelly COMMAND --help' for the options of one command.
""")
    # These are accepted before the command and after it, because insisting on
    # one position is exactly the kind of thing that makes a tool annoying.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--host', metavar='ADDR',
                        help='address of the device, overriding the configuration')
    common.add_argument('--password', metavar='PASS',
                        help='password if the device has one; the username is '
                             'always admin and cannot be changed')
    common.add_argument('--switch-id', dest='switch_id', type=int, default=0,
                        help='relay id on a multi-channel device (default 0)')
    common.add_argument('--no-color', action='store_true',
                        help='plain output with no colour codes')
    common.add_argument('--json', action='store_true',
                        help='machine-readable output where the command has any')
    for action in common._actions:
        parser._add_action(action)

    subs = parser.add_subparsers(dest='command', metavar='COMMAND')

    def add(name, help_text, description=None, epilog=None):
        return subs.add_parser(
            name, help=help_text, description=description or help_text,
            epilog=epilog, parents=[common],
            formatter_class=argparse.RawDescriptionHelpFormatter)

    found = add('discover', 'find Shelly devices on the network',
                'Ask the local network for Shelly devices over multicast DNS. '
                'This does not cross subnets, and some networks block it.')
    found.add_argument('--seconds', type=float, default=4.0,
                       help='how long to listen (default 4)')

    add('info', 'identity, firmware and auth state',
        'A short summary: model, name, firmware version, generation, and '
        'whether authentication and Matter are switched on.')

    add('dump', 'everything the device exposes, in one go',
        'Every component the device has, each with every field it reports. '
        'Use --json to get the replies exactly as the device sent them.')

    methods = add('methods', 'list every RPC method the device supports',
                  'Asks the device for its own method list, and explains the '
                  'ones worth knowing. Useful before reaching for "call": '
                  'whatever appears here can be invoked, and nothing else can.',
                  epilog="""
examples
  zigmon shelly plug methods                 everything, with notes
  zigmon shelly plug methods Switch          just one component
  zigmon shelly plug methods --examples      with a ready-made call for each
  zigmon shelly plug methods Webhook --examples --described
""")
    methods.add_argument('component', nargs='?',
                         help='only this component: Switch, Wifi, Webhook ...')
    methods.add_argument('--examples', action='store_true',
                         help='print a ready-made call under each method')
    methods.add_argument('--described', action='store_true',
                         help='hide methods there is nothing useful to say about')

    config = add('config', 'read or change a component configuration',
                 'With no arguments, the whole device configuration. With a '
                 'component, just that one. With a component and a JSON object, '
                 'the settings in that object are written.',
                 epilog="""
examples
  zigmon shelly plug config                       everything
  zigmon shelly plug config switch:0              one component
  zigmon shelly plug config sys                   the system section
  zigmon shelly plug config switch:0 '{"auto_off": true, "auto_off_delay": 60}'
  zigmon shelly plug config ble '{"enable": true}'

A write is checked by reading the value back, so a setting the firmware quietly
ignores is reported rather than assumed to have taken.
""")
    config.add_argument('component', nargs='?',
                        help='switch:0, sys, wifi, ble, matter, cloud, mqtt ...')
    config.add_argument('settings', nargs='?',
                        help='JSON object of settings to write')
    config.add_argument('--reboot', action='store_true',
                        help='restart the device afterwards, which some '
                             'settings need before they take effect')

    poll = add('poll', 'read the device on a timer, optionally to CSV',
               'A live table of the numbers the device reports. A sleeping '
               'battery device is retried rather than treated as an error.')
    poll.add_argument('--interval', type=float, default=5.0,
                      help='seconds between readings (default 5)')
    poll.add_argument('--count', type=int, help='stop after this many readings')
    poll.add_argument('--csv', metavar='FILE', help='append readings to a CSV file')

    add('watch', 'live push updates over websocket',
        'Subscribe to the device\'s own notifications instead of polling it. '
        'The websocket carries no authentication, so this does not work on a '
        'device with a password set - use poll there.')

    listen = add('listen', 'receive webhooks from a sleeping battery device',
                 'Print pushes as they arrive. Nothing is recorded; the daemon '
                 'stores them when sensor_listen is on.')
    listen.add_argument('--port', type=int, help='port to listen on')

    serve = add('serve', 'accept outbound websocket pushes from devices',
                'For a device configured to connect out to us rather than be '
                'polled.')
    serve.add_argument('--port', type=int, default=8089, help='port (default 8089)')

    add('on', 'switch the relay on')
    add('off', 'switch the relay off')
    add('toggle', 'flip the relay to the other state')

    reset = add('reset-counters', 'reset the plug\'s running totals',
                'With no type, every counter the device has. The values are '
                'read back afterwards, so a counter the firmware refuses to '
                'clear is reported rather than assumed reset.',
                epilog="""
counter types
  aenergy        active energy, the kilowatt-hour total
  ret_aenergy    energy returned to the grid
  on_time        total runtime, how long the relay has been on
  switch_on      switching cycles
  on_above_thr   active load runtime, time above the plug's threshold
""")
    reset.add_argument('types', nargs='*', help='which counters; none means all')

    reboot = add('reboot', 'restart the device')
    reboot.add_argument('--wait', action='store_true',
                        help='wait for it to come back and report the firmware')

    matter = add('matter', 'Matter on, off, status, or the pairing code',
                 'Matter has to be enabled before a controller can commission '
                 'the device, and the change needs a reboot.')
    matter.add_argument('action', nargs='?', default='status',
                        choices=['status', 'on', 'off', 'code'])
    matter.add_argument('--reboot', action='store_true',
                        help='restart afterwards so the change takes effect')

    ble = add('ble', 'Bluetooth radio and BLE RPC on, off or status',
              'The radio and the RPC-over-Bluetooth service are separate '
              'switches. Both need a reboot to take effect.')
    ble.add_argument('action', nargs='?', default='status',
                     choices=['status', 'on', 'off', 'rpc-on', 'rpc-off'])
    ble.add_argument('--reboot', action='store_true',
                     help='restart afterwards so the change takes effect')

    call = add('call', 'invoke any RPC method directly',
               'For anything the commands above do not cover. Run "methods" '
               'first to see what this device accepts.',
               epilog="""
examples
  zigmon shelly plug call Shelly.GetStatus
  zigmon shelly plug call Switch.GetStatus '{"id":0}'
  zigmon shelly plug call Switch.SetConfig '{"id":0,"config":{"power_limit":2900}}'
""")
    call.add_argument('method', help='for example Switch.GetStatus')
    call.add_argument('params', nargs='?', help='JSON object of parameters')

    return parser


def gateway_main(argv, pal):
    """zigmon gateway [name] <command> - read a Zigbee gateway (e.g. an
    SLZB-06) over the network: its own uptime, temperature, network and
    socket state, on top of what Zigbee2MQTT already reports about it."""
    import argparse as _argparse
    p = _argparse.ArgumentParser(prog='zigmon gateway', add_help=True,
        description='Poll a Zigbee gateway\'s own HTTP API (SLZB-06 / SLZB-OS: '
                    '/ha_info, /ha_sensors and /metrics) once and print what it returns.',
        epilog="""
examples
  zigmon gateway Router dump          both endpoints, raw JSON, as the device sent them
  zigmon gateway Router info          just /ha_info
  zigmon gateway Router sensors       just /ha_sensors
  zigmon gateway --host 192.168.1.51 dump   a device not (yet) in config.json

Run this after adding a "zigbee_gateways" entry to config.json to see exactly
what fields your firmware returns - field names can vary by version, and
zigmon keeps whatever it gets under a "gw." prefix regardless of the names.
""", formatter_class=_argparse.RawDescriptionHelpFormatter)
    p.add_argument('name', nargs='?', help='the gateway\'s "name" in config.json')
    p.add_argument('command', choices=['info', 'sensors', 'metrics', 'dump'], default='dump', nargs='?')
    p.add_argument('--host', metavar='ADDR', help='talk to this address instead of looking the name up')
    p.add_argument('--username', metavar='USER', help='HTTP Basic Auth user, if SLZB-OS "web server authentication" is on')
    p.add_argument('--password', metavar='PASS', help='HTTP Basic Auth password')
    p.add_argument('--json', action='store_true', help='raw JSON, no formatting')
    args = p.parse_args(argv)
    load_config()
    for problem in CONFIG_FATAL:
        sys.stderr.write('CONFIG: %s\n' % problem)
    host = args.host
    name = args.name
    username, password = args.username or '', args.password or ''
    if not host:
        # ask the running daemon first - it knows the config.json entries
        # AND anything added on the dashboard, with its stored password
        gateways = {}
        status_code, data = api_call('/api/status')
        if status_code == 200:
            for g in data.get('gateways') or []:
                gateways[g['name']] = g
        if name and name in gateways:
            host = gateways[name]['host']
            if not username:
                username = gateways[name].get('username') or ''
            if not password and gateways[name].get('password_set') and gateways[name].get('source') == 'ui':
                # the status API never returns a stored password (by design) -
                # for a dashboard-added gateway, read it straight from the
                # database the daemon already uses, on this same machine
                try:
                    store = Storage()
                    for g in json.loads(store.get_meta('gateways') or '[]'):
                        if isinstance(g, dict) and g.get('name') == name:
                            password = g.get('password') or ''
                            break
                except Exception:
                    pass
        else:
            configured = {g['name']: g for g in (CONFIG.get('zigbee_gateways') or []) if isinstance(g, dict)}
            if name and name in configured:
                host = configured[name]['host']
                username = username or configured[name].get('username') or ''
                password = password or configured[name].get('password') or ''
            elif not name and len(configured) == 1:
                host = list(configured.values())[0]['host']
                name = list(configured.keys())[0]
            else:
                known = sorted(set(gateways) | set(configured))
                sys.stderr.write('Name a configured gateway, or pass --host.\n'
                                 '  Configured: %s\n' % (', '.join(known) or '(none)'))
                return 2
    d = Daemon.__new__(Daemon)   # a bare instance: only gateway_fetch is used, nothing else touched
    paths = {'info': ['/ha_info'], 'sensors': ['/ha_sensors'], 'metrics': ['/metrics'],
             'dump': ['/ha_info', '/ha_sensors', '/metrics']}[args.command]
    ok_any = False
    header_shown = False
    for path in paths:
        try:
            data = Daemon.gateway_fetch(d, host, path, timeout=6.0, username=username, password=password)
        except Exception as e:
            print(pal.warn('%s: %s' % (path, e)))
            continue
        ok_any = True
        if args.json:
            print(json.dumps({path: data}, indent=1))
        else:
            if not header_shown:
                print(pal.title(name or host) + pal.note('  ' + host))
                header_shown = True
            flat = flatten(data)
            if not flat:
                continue
            print('\n' + pal.group('-- %s ' % path) + pal.rule('-' * max(1, 74 - len(path))))
            shelly_print_flat(pal, flat)
    return 0 if ok_any else 1


def shelly_main(argv, pal):
    """zigmon shelly [name] <command> - the whole toolkit, addressed by name."""
    arguments = list(argv)

    # The global options are accepted anywhere. argparse lets a subcommand's
    # defaults overwrite what was given before it, so they are taken off by
    # hand first and put back after parsing.
    globals_ = {'host': None, 'password': None, 'switch_id': None, 'json': False, 'no_color': False}
    cleaned = []
    skip = False
    for index, value in enumerate(arguments):
        if skip:
            skip = False
            continue
        if value in ('--host', '--password', '--switch-id') and index + 1 < len(arguments):
            key = value.lstrip('-').replace('-', '_')
            globals_[key] = arguments[index + 1]
            skip = True
            continue
        if value.startswith('--host='):
            globals_['host'] = value.split('=', 1)[1]
            continue
        if value.startswith('--password='):
            globals_['password'] = value.split('=', 1)[1]
            continue
        if value == '--json':
            globals_['json'] = True
            continue
        if value == '--no-color':
            globals_['no_color'] = True
            continue
        cleaned.append(value)
    arguments = cleaned

    # The device name comes before the command, which subparsers cannot
    # express. Take it off the front first; everything after is ordinary.
    targets = shelly_targets()
    names = {n.lower(): n for n in targets}
    commands = ('discover', 'info', 'dump', 'methods', 'config', 'poll', 'watch', 'listen', 'serve',
                'on', 'off', 'toggle', 'reset-counters', 'reboot', 'matter', 'ble', 'call')
    role = None
    for index, value in enumerate(arguments):
        if value.startswith('-'):
            continue
        if value.lower() in names:
            role = names[value.lower()]
            arguments.pop(index)
        elif value not in commands and not globals_['host'] and value not in ('-h', '--help'):
            print(pal.bad('ERROR: ') + 'unknown device "%s"' % value, file=sys.stderr)
            print(pal.note('  configured: %s' % (', '.join(targets) or 'none')
                           + '; or give --host ADDR'), file=sys.stderr)
            return 2
        break
    if role is None and not globals_['host'] and targets:
        role = list(targets)[0]

    parser = shelly_build_parser()
    args = parser.parse_args(arguments)
    args.device = role
    args.host = globals_['host']
    args.password = globals_['password']
    args.switch_id = int(globals_['switch_id'] or 0)
    args.json = globals_['json']
    args.no_color = globals_['no_color']
    if not args.command:
        parser.print_help()
        return 0
    if args.no_color:
        pal = Palette(False)

    handler = {
        'discover': shelly_cmd_discover, 'info': shelly_cmd_info,
        'dump': shelly_cmd_dump, 'methods': shelly_cmd_methods,
        'config': shelly_cmd_config, 'poll': shelly_cmd_poll,
        'watch': shelly_cmd_watch, 'listen': shelly_cmd_listen,
        'serve': shelly_cmd_serve, 'on': shelly_cmd_switch,
        'off': shelly_cmd_switch, 'toggle': shelly_cmd_switch,
        'reset-counters': shelly_cmd_reset, 'call': shelly_cmd_call,
        'reboot': shelly_cmd_reboot, 'ble': shelly_cmd_radio,
        'matter': shelly_cmd_radio,
    }[args.command]

    try:
        return handler(args, pal)
    except PlugError as e:
        print(pal.bad('ERROR: ') + str(e), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print('\nstopped.')
        return 0


def shelly_cmd_discover(args, pal):
    print(pal.note('asking the network for Shelly devices, %.0fs...' % args.seconds))
    found = shelly_discover(pal, args.seconds)
    if args.json:
        print(json.dumps(list(found.values()), indent=2))
        return 0
    if not found:
        print(pal.warn('nothing answered'))
        for line in discovery_diagnosis(pal):
            print(line)
        print()
        print(pal.note('  Nothing here depends on discovery. Give the address '
                       'directly and everything else works:'))
        print(pal.note('    zigmon shelly --host 172.16.16.12 info'))
        print(pal.note('  or add it under "plugs" in %s.' % CONFIG_FILE))
        return 1
    for entry in sorted(found.values(), key=lambda e: e['ip']):
        line = '  %s  %s' % (pal.value(entry['ip'].ljust(15)),
                             pal.note(', '.join(entry['names'])))
        if entry.get('via'):
            line += pal.note('  (relayed by %s)' % entry['via'])
        print(line)
    print(pal.note('  %d device(s)' % len(found)))
    return 0


def discovery_diagnosis(pal):
    """Why an empty result is usually the local machine's own doing.

    On a stock AlmaLinux 9 the firewall drops inbound multicast DNS until the
    service is allowed, and a reply to a multicast query is not something
    connection tracking will let back in on its own. That is the first thing to
    check, and the tool can check it rather than leaving it to guesswork.
    """
    lines = []

    interfaces = getattr(shelly_discover, 'interfaces', [])
    if interfaces:
        lines.append(pal.note('  The query went out of %d interface(s): %s'
                              % (len(interfaces),
                                 ', '.join('%s (%s)' % (n, a) for n, a in interfaces))))
        if len(interfaces) == 1:
            lines.append(pal.note('    If the device is reached through a VLAN '
                                  'this machine has no address on, only a proxy '
                                  'can carry the query there.'))
    joined = getattr(shelly_discover, 'joined', 0)
    if not joined:
        lines.append(pal.warn('  Could not join the multicast group on port 5353.'))
        lines.append(pal.note('    Only a unicast reply can reach us, and an '
                              'avahi reflector does not forward those - it '
                              'repeats multicast between interfaces and nothing '
                              'else. Check what holds the port:'))
        lines.append(pal.key('      ss -lunp | grep 5353'))
    else:
        lines.append(pal.note('  Joined the multicast group on %d interface(s), '
                              'and asked for both a unicast and a multicast '
                              'answer.' % joined))
        lines.append(pal.note('    A reflector can only carry the multicast one, '
                              'so that path is covered.'))

    blocked = firewalld_blocks_mdns()
    if blocked is True:
        lines.append(pal.bad('  firewalld is running and mDNS is not allowed in '
                             'the active zone.'))
        lines.append(pal.note('    Replies to a multicast query are dropped, '
                              'because connection tracking has nothing to match '
                              'them against. Allow the service:'))
        lines.append(pal.key('      sudo firewall-cmd --permanent --add-service=mdns'))
        lines.append(pal.key('      sudo firewall-cmd --reload'))
    elif blocked is False:
        lines.append(pal.ok('  firewalld allows mDNS, so the firewall is not the '
                            'problem here.'))
    else:
        lines.extend(iptables_diagnosis(pal))

    lines.append(pal.note('  Multicast DNS does not cross subnets on its own. A '
                          'proxy or repeater between VLANs forwards it, but many '
                          'forward only the query and not the reply.'))
    if shutil.which('avahi-browse'):
        lines.append(pal.note('  avahi is installed here, so it can be asked the '
                              'same question independently:'))
        lines.append(pal.key('      avahi-browse -art | grep -i shelly'))
        lines.append(pal.note('    If that finds nothing either, the replies are '
                              'not reaching this machine at all and the cause is '
                              'in the network, not here.'))
    lines.append(pal.note('  Strict reverse-path filtering also drops replies '
                          'that arrive from another VLAN. Check with:'))
    lines.append(pal.key('      sysctl net.ipv4.conf.all.rp_filter'))
    lines.append(pal.note('    2 (loose) or 0 tolerates it; 1 (strict) will not.'))
    return lines


def iptables_diagnosis(pal):
    """The same question for a machine running iptables directly.

    Two rules are needed, not one. Answers arrive at port 5353 when we hold it,
    and at whatever port the query went out from when avahi already has 5353 -
    the unicast-response bit is what makes that second case work, and it needs
    a rule of its own because connection tracking will not match a reply to a
    multicast destination.
    """
    import subprocess
    lines = []
    try:
        rules = subprocess.run(['iptables', '-S', 'INPUT'],
                               capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return lines
    if rules.returncode != 0:
        if 'permission' in (rules.stderr or '').lower():
            lines.append(pal.note('  Run as root to have the firewall checked '
                                  'as well.'))
        return lines

    text = rules.stdout
    # A chain whose policy is ACCEPT but which ends in a catch-all REJECT is
    # every bit as closed as one with a DROP policy. Looking only at the policy
    # was wrong.
    policy_drops = any(line.startswith('-P INPUT') and 'ACCEPT' not in line
                       for line in text.split('\n'))
    catch_all = any(('-j REJECT' in line or '-j DROP' in line)
                    and '-p ' not in line and '--dport' not in line
                    for line in text.split('\n'))
    policy_drops = policy_drops or catch_all
    accepts_5353 = any('5353' in line and '-j ACCEPT' in line
                       for line in text.split('\n'))
    accepts_group = any('224.0.0.251' in line and '-j ACCEPT' in line
                        for line in text.split('\n'))

    if not policy_drops:
        lines.append(pal.ok('  iptables accepts by default, so the firewall is '
                            'not blocking this.'))
        return lines
    if accepts_5353:
        lines.append(pal.ok('  iptables already allows mDNS both ways, so the '
                            'firewall is not the problem.'))
        return lines

    if accepts_group:
        lines.append(pal.warn('  iptables allows the multicast group but not a '
                              'unicast reply.'))
        lines.append(pal.note('    A proxy answers from port 5353 to whatever '
                              'port the query went out from, which the existing '
                              'rule does not cover. Add:'))
        lines.append(pal.key('      iptables -I INPUT -p udp --sport 5353 -j ACCEPT'))
    else:
        lines.append(pal.bad('  iptables drops by default and nothing allows mDNS.'))
        lines.append(pal.note('    Two rules, because answers arrive two ways:'))
        lines.append(pal.key('      iptables -I INPUT -p udp --dport 5353 -j ACCEPT'))
        lines.append(pal.note('        replies to the multicast group, when we '
                              'hold port 5353'))
        lines.append(pal.key('      iptables -I INPUT -p udp --sport 5353 -j ACCEPT'))
        lines.append(pal.note('        unicast replies to a temporary port, which '
                              'is what a proxy sends and what avahi leaves us with'))

    lines.append(pal.note('    Then make it survive a reboot:'))
    lines.append(pal.key('      service iptables save'))
    lines.append(pal.note('        or iptables-save > /etc/sysconfig/iptables'))
    return lines


def firewalld_blocks_mdns():
    """True, False, or None when firewalld is not running or not installed."""
    import subprocess
    try:
        state = subprocess.run(['firewall-cmd', '--state'],
                               capture_output=True, text=True, timeout=5)
        if state.returncode != 0:
            return None
        allowed = subprocess.run(['firewall-cmd', '--query-service=mdns'],
                                 capture_output=True, text=True, timeout=5)
        if 'yes' in allowed.stdout:
            return False
        ports = subprocess.run(['firewall-cmd', '--list-ports'],
                               capture_output=True, text=True, timeout=5)
        return '5353/udp' not in ports.stdout
    except (OSError, subprocess.SubprocessError):
        return None


def shelly_cmd_info(args, pal):
    rpc = shelly_for(args.device, args)
    info = rpc.call('Shelly.GetDeviceInfo')
    if args.json:
        print(json.dumps(info, indent=2))
        return 0
    shelly_print_flat(pal, flatten(info), '  %s' % rpc.host)
    return 0


def shelly_cmd_dump(args, pal):
    rpc = shelly_for(args.device, args)
    everything = shelly_everything(rpc)
    if not everything:
        raise PlugError('the device answered nothing we recognise')
    if args.json:
        print(json.dumps(everything, indent=2))
        return 0
    info = everything.get('Shelly.GetDeviceInfo', {})
    bar = '=' * 78
    print(pal.rule(bar))
    print('  ' + pal.title('%s  %s' % (info.get('model', args.device or rpc.host),
                                       info.get('name', ''))))
    print('  ' + pal.note('zigmon v%s   |   %s   |   firmware %s   |   %s'
                          % (__version__, rpc.host, info.get('ver', '?'),
                             datetime.now().strftime('%Y-%m-%d %H:%M:%S'))))
    print(pal.rule(bar))
    for method in sorted(everything):
        flat = flatten(everything[method])
        if not flat:
            continue
        print('\n' + pal.group('-- %s ' % method)
              + pal.rule('-' * max(1, 74 - len(method))))
        shelly_print_flat(pal, flat)
    print('\n' + pal.rule(bar))
    return 0


# What a live table should show first. Timestamps and component ids are
# numbers too, and picking those over the actual measurements made the poll
# output useless.
POLL_PREFERRED = ['apower', 'voltage', 'current', 'pf', 'freq', 'aenergy.total',
                  'ret_aenergy.total', 'temperature.tC', 'tC', 'rh',
                  'battery.percent', 'battery.V', 'wifi.rssi', 'sys.uptime']
POLL_SKIP = re.compile(r'(_ts$|\.id$|^id$|minute_ts|\.0$|ram_|fs_)')


def shelly_numeric(flat):
    numeric = [k for k, v in flat.items()
               if isinstance(v, (int, float)) and not isinstance(v, bool)
               and not POLL_SKIP.search(k)]
    def rank(key):
        tail = re.sub(r'^[a-z_0-9]+:\d+\.', '', key)
        for index, wanted in enumerate(POLL_PREFERRED):
            if tail == wanted:
                return (0, index)
        return (1, key)
    return sorted(numeric, key=rank)


def shelly_cmd_methods(args, pal):
    """Everything this device will answer, straight from the device."""
    rpc = shelly_for(args.device, args)
    try:
        result = rpc.call('Shelly.ListMethods')
    except PlugError as e:
        if is_missing_component(e):
            raise PlugError('this device does not publish a method list; it is '
                            'probably older than Gen2 firmware 0.14')
        raise
    methods = sorted((result or {}).get('methods', []))
    if args.component:
        wanted = args.component.lower().rstrip('.')
        methods = [m for m in methods if m.split('.')[0].lower() == wanted]
        if not methods:
            print(pal.warn('no component called "%s" on this device'
                           % args.component))
            return 1

    if args.json:
        if args.described:
            print(json.dumps({m: {'description': RPC_METHODS[m][0],
                                  'example': RPC_METHODS[m][1]}
                              for m in methods if m in RPC_METHODS}, indent=2))
        else:
            print(json.dumps(methods, indent=2))
        return 0
    if not methods:
        print(pal.warn('the device returned an empty list'))
        return 1

    groups = {}
    for method in methods:
        groups.setdefault(method.split('.')[0], []).append(method)

    described = 0
    for component in sorted(groups):
        note = RPC_COMPONENTS.get(component, '')
        heading = '-- %s ' % component
        print('\n' + pal.group(heading) + pal.rule('-' * max(1, 70 - len(heading))))
        if note:
            print('  ' + pal.note(note))
        for method in groups[component]:
            entry = RPC_METHODS.get(method)
            if not entry and args.described:
                continue
            print('  ' + pal.value(method))
            if entry:
                described += 1
                print('      ' + pal.note(entry[0]))
                if entry[1] and args.examples:
                    print('      ' + pal.key('zigmon shelly %s call %s %s'
                                             % (args.device or 'NAME', method,
                                                shell_quote(entry[1]))))
                elif not entry[1] and args.examples:
                    print('      ' + pal.key('zigmon shelly %s call %s'
                                             % (args.device or 'NAME', method)))

    print('\n' + pal.rule('=' * 74))
    print(pal.note('  %d method(s) across %d component(s); %d of them described '
                   'here.' % (len(methods), len(groups), described)))
    if not args.examples:
        print(pal.note('  --examples adds a ready-made call for each one, '
                       '--described hides the rest.'))
    print(pal.note('  Anything listed can be used with "call", described or not.'))
    return 0


def shell_quote(text):
    """Quote a JSON argument for a shell, or leave it for cmd.exe to mangle."""
    if os.name == 'nt':
        return '"' + text.replace('"', '\\"') + '"'
    return "'" + text + "'"


def shelly_cmd_config(args, pal):
    """Read a configuration, or write one and check it took."""
    rpc = shelly_for(args.device, args)

    if not args.component:
        config = rpc.call('Shelly.GetConfig')
        if args.json:
            print(json.dumps(config, indent=2))
            return 0
        flat = flatten(config)
        for component in sorted({k.split('.')[0] for k in flat}):
            section = {k: v for k, v in flat.items()
                       if k == component or k.startswith(component + '.')}
            print('\n' + pal.group('-- %s ' % component)
                  + pal.rule('-' * max(1, 70 - len(component))))
            shelly_print_flat(pal, section)
        print('\n' + pal.note('  %d setting(s). Give a component to narrow it, '
                              'and a JSON object to change it.' % len(flat)))
        return 0

    # Reading one component: Switch.GetConfig wants an id, Sys.GetConfig does not.
    component = args.component
    name, _, index = component.partition(':')
    # Shelly method names are case-insensitive, but the canonical spelling
    # reads better in the output and some proxies are picky.
    canonical = {'ble': 'BLE', 'mqtt': 'MQTT', 'wifi': 'WiFi', 'kvs': 'KVS', 'ws': 'WS', 'http': 'HTTP',
                 'ui': 'UI', 'bthome': 'BTHome', 'pm1': 'PM1', 'em1': 'EM1', 'em': 'EM'}
    method_base = canonical.get(name.lower()) or (name[0].upper() + name[1:] if name.islower() else name)
    params = {'id': int(index)} if index.isdigit() else None

    if not args.settings:
        config = rpc.call('%s.GetConfig' % method_base, params)
        if args.json:
            print(json.dumps(config, indent=2))
            return 0
        shelly_print_flat(pal, flatten(config), '  %s' % component)
        return 0

    try:
        settings = json.loads(args.settings)
    except ValueError:
        raise PlugError('the settings must be a JSON object: %s' % args.settings)
    if not isinstance(settings, dict):
        raise PlugError('the settings must be a JSON object, not a %s'
                        % type(settings).__name__)

    before = flatten(rpc.call('%s.GetConfig' % method_base, params))
    write = dict(params or {})
    write['config'] = settings
    result = rpc.call('%s.SetConfig' % method_base, write)
    after = flatten(rpc.call('%s.GetConfig' % method_base, params))

    # Firmware accepts a whole config object and silently drops keys it does
    # not know, so say which ones actually changed rather than assuming.
    applied, ignored = [], []
    for key, wanted in flatten(settings).items():
        now = after.get(key)
        (applied if now == wanted else ignored).append(
            '%s=%s' % (key, now if now is not None else 'absent'))
    for key in applied:
        print(pal.ok('  set   ') + key)
    for key in ignored:
        print(pal.warn('  kept  ') + key
              + pal.note('  (the device did not take the new value)'))

    changed = [k for k in after if before.get(k) != after.get(k)]
    if not applied and not changed:
        print(pal.warn('  nothing changed'))
        return 1
    if (result or {}).get('restart_required') or args.reboot:
        if args.reboot:
            return shelly_cmd_reboot(args, pal)
        print(pal.note('  the device says a restart is needed: '
                       'zigmon shelly %s reboot --wait' % (args.device or 'NAME')))
    return 0


def shelly_cmd_poll(args, pal):
    rpc = shelly_for(args.device, args)
    import csv as csv_module
    handle = open(args.csv, 'a', newline='', encoding='utf-8') if args.csv else None
    writer = csv_module.writer(handle) if handle else None

    columns, printed, count = None, 0, 0
    try:
        while True:
            try:
                try:
                    status = rpc.call('Switch.GetStatus', {'id': rpc.switch_id})
                except PlugError as e:
                    if not is_missing_component(e):
                        raise
                    status = rpc.call('Shelly.GetStatus')
                flat = flatten(status)
            except PlugError as e:
                # A battery sensor is asleep most of the time; say so and retry
                # rather than giving up, which is what makes poll usable at all.
                print(pal.note('%s  %s' % (datetime.now().strftime('%H:%M:%S'), e)))
                time.sleep(args.interval)
                continue

            if columns is None:
                columns = shelly_numeric(flat)[:8]
                if writer and handle.tell() == 0:
                    writer.writerow(['timestamp'] + columns)
            if printed % 20 == 0:
                print(pal.group('  %-8s ' % 'time'
                                + ' '.join(c.rsplit('.', 1)[-1][:10].rjust(11)
                                           for c in columns)))
            print('  %-8s ' % datetime.now().strftime('%H:%M:%S')
                  + ' '.join(pal.value(('%g' % flat[c] if isinstance(flat.get(c), float)
                                        else str(flat.get(c, '-'))).rjust(11))
                             for c in columns))
            if writer:
                writer.writerow([datetime.now().isoformat(timespec='seconds')]
                                + [flat.get(c) for c in columns])
                handle.flush()
            printed += 1
            count += 1
            if args.count and count >= args.count:
                return 0
            time.sleep(args.interval)
    finally:
        if handle:
            handle.close()


def shelly_cmd_watch(args, pal):
    """Subscribe to the device's own notifications instead of polling."""
    import base64
    rpc = shelly_for(args.device, args)
    host = rpc.host.split(':')[0]
    port = int(rpc.host.split(':')[1]) if ':' in rpc.host else 80
    key = base64.b64encode(secrets.token_bytes(16)).decode()

    if rpc.password:
        print(pal.warn('this device has a password set. The websocket channel '
                       'does not carry that authentication - use poll instead.'))
        return 1

    try:
        sock = socket.create_connection((host, port), 10)
    except OSError as e:
        raise PlugError('cannot reach %s (%s)' % (rpc.host, e))
    request = ('GET /rpc HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\n'
               'Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n'
               'Sec-WebSocket-Version: 13\r\n\r\n' % (rpc.host, key))
    sock.sendall(request.encode())
    reply = b''
    while b'\r\n\r\n' not in reply:
        chunk = sock.recv(4096)
        if not chunk:
            raise PlugError('the device closed the connection during the handshake')
        reply += chunk
    if b'101' not in reply.split(b'\r\n')[0]:
        raise PlugError('the device refused the websocket upgrade')

    print(pal.note('connected to %s - press Ctrl+C to stop' % rpc.host))
    _ws_send(sock, json.dumps({'id': 1, 'src': 'zigmon',
                               'method': 'Shelly.GetStatus'}))
    try:
        for message in _ws_frames(sock):
            try:
                body = json.loads(message)
            except ValueError:
                continue
            payload = body.get('params') or body.get('result') or {}
            flat = flatten(payload)
            if not flat:
                continue
            stamp = datetime.now().strftime('%H:%M:%S')
            if args.json:
                print(json.dumps({'ts': stamp, 'data': payload}))
                continue
            print(pal.note('  ' + stamp) + '  ' + body.get('method', 'result'))
            shelly_print_flat(pal, flat)
    except (ConnectionError, OSError) as e:
        print(pal.warn('connection lost: %s' % e))
    finally:
        sock.close()
    return 0


def shelly_cmd_listen(args, pal):
    """Print webhook pushes as they arrive, without touching the database."""
    port = args.port or int(CONFIG['sensor_listen_port'])
    host = CONFIG['sensor_listen_host'] or '0.0.0.0'

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *ignored):
            pass

        def _show(self, payload):
            print('%s  %s  %s'
                  % (pal.note(datetime.now().strftime('%H:%M:%S')),
                     pal.info(self.client_address[0]), pal.value(payload)))
            self.send_response(200)
            self.send_header('Content-Length', '0')
            self.end_headers()

        def do_GET(self):
            query = parse_qs(urlparse(self.path).query)
            fields = {k: v[0] for k, v in query.items() if v}
            self._show(json.dumps(fields) if fields else self.path)

        def do_POST(self):
            length = int(self.headers.get('Content-Length') or 0)
            self._show(self.rfile.read(length).decode('utf-8', 'replace'))

    try:
        server = ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            running = 'the daemon is probably already listening there' \
                if port == int(CONFIG['sensor_listen_port']) \
                and CONFIG['sensor_listen'] else 'something else has that port'
            print(pal.bad('port %s on %s is already in use' % (port, host)))
            print(pal.note('  %s. Either stop it, or watch on a spare port and '
                           'point a webhook at that:' % running))
            print(pal.note('    zigmon shelly listen --port %d' % (port + 1)))
            return 1
        print(pal.bad('cannot listen on %s:%s - %s' % (host, port, e)))
        return 1
    print(pal.note('listening on http://%s:%s/ - point the sensor webhook here, '
                   'Ctrl+C to stop' % (host, port)))
    print(pal.note('nothing is recorded; this only shows what arrives. The daemon '
                   'stores pushes when sensor_listen is on.'))
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


def shelly_cmd_serve(args, pal):
    """Accept an outbound websocket from a device configured to call us."""
    import base64
    import hashlib
    port = args.port or 8089
    guid = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'

    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind(('0.0.0.0', port))
    except OSError as e:
        print(pal.bad('cannot listen on port %s - %s' % (port, e)))
        if e.errno == errno.EADDRINUSE:
            print(pal.note('  try another: zigmon shelly serve --port %d'
                           % (port + 1)))
        return 1
    listener.listen(4)
    print(pal.note('waiting for a device to connect to ws://<this-host>:%d/ - '
                   'Ctrl+C to stop' % port))
    try:
        while True:
            client, address = listener.accept()
            request = b''
            while b'\r\n\r\n' not in request:
                chunk = client.recv(4096)
                if not chunk:
                    break
                request += chunk
            match = re.search(rb'Sec-WebSocket-Key:\s*(\S+)', request, re.I)
            if not match:
                client.close()
                continue
            accept = base64.b64encode(
                hashlib.sha1(match.group(1) + guid.encode()).digest()).decode()
            client.sendall(('HTTP/1.1 101 Switching Protocols\r\n'
                            'Upgrade: websocket\r\nConnection: Upgrade\r\n'
                            'Sec-WebSocket-Accept: %s\r\n\r\n' % accept).encode())
            print(pal.ok('  connected: ') + address[0])
            try:
                for message in _ws_frames(client):
                    stamp = datetime.now().strftime('%H:%M:%S')
                    try:
                        body = json.loads(message)
                    except ValueError:
                        print('  %s  %s' % (pal.note(stamp), message))
                        continue
                    flat = flatten(body.get('params') or body)
                    print('  %s  %s' % (pal.note(stamp),
                                        body.get('method', 'message')))
                    shelly_print_flat(pal, flat)
            except (ConnectionError, OSError):
                pass
            finally:
                client.close()
                print(pal.note('  disconnected: %s' % address[0]))
    finally:
        listener.close()
    return 0


def shelly_cmd_switch(args, pal):
    rpc = shelly_for(args.device, args)
    switch_id = rpc.switch_id
    if args.command == 'toggle':
        rpc.call('Switch.Toggle', {'id': switch_id})
    else:
        rpc.call('Switch.Set', {'id': switch_id, 'on': args.command == 'on'})
    state = rpc.call('Switch.GetStatus', {'id': switch_id})
    on = bool(state.get('output'))
    print(pal.ok('  socket is ON') if on else pal.bad('  socket is OFF'))
    if state.get('apower') is not None:
        print(pal.note('  drawing %s W' % state['apower']))
    return 0


def shelly_cmd_reset(args, pal):
    """reset-counters [type ...] — no type means every counter the plug has."""
    rpc = shelly_for(args.device, args)
    switch_id = rpc.switch_id
    types = [t for arg in args.types for t in arg.split(',') if t]
    unknown = [t for t in types if t not in PLUG_COUNTER_TYPES]
    if unknown:
        print(pal.bad('  unknown counter: %s' % ', '.join(unknown)))
        print(pal.note('  choose from: %s' % ', '.join(PLUG_COUNTER_TYPES)))
        return 1

    rpc.reset_counters(types or None)
    state = rpc.call('Switch.GetStatus', {'id': switch_id})
    print(pal.ok('  reset %s' % (', '.join(types) if types else 'every counter')))
    flat = flatten(state)
    for key in ('aenergy.total', 'ret_aenergy.total', 'counts.on_time',
                'counts.switch_on', 'counts.on_above_thr'):
        if key in flat:
            print(pal.note('    %-22s %s' % (key, flat[key])))
    return 0


def shelly_cmd_call(args, pal):
    rpc = shelly_for(args.device, args)
    method = args.method
    params = None
    if args.params:
        try:
            params = json.loads(args.params)
        except ValueError:
            raise PlugError('the parameters must be JSON: %s' % args.params)
    result = rpc.call(method, params)
    if args.json or not isinstance(result, dict):
        print(json.dumps(result, indent=2))
        return 0
    shelly_print_flat(pal, flatten(result), '  %s' % method)
    return 0


def shelly_cmd_reboot(args, pal):
    rpc = shelly_for(args.device, args)
    rpc.call('Shelly.Reboot')
    print(pal.ok('  reboot requested'))
    # Called from ble/matter/config --reboot there is no --wait flag; those
    # want to check the result afterwards, so they wait.
    if not getattr(args, 'wait', True):
        return 0
    print(pal.note('  waiting for it to come back...'))
    deadline = time.time() + 60
    time.sleep(3)
    while time.time() < deadline:
        try:
            info = rpc.call('Shelly.GetDeviceInfo')
            print(pal.ok('  back after %ds' % int(60 - (deadline - time.time())))
                  + pal.note('  firmware %s' % info.get('ver')))
            return 0
        except PlugError:
            time.sleep(2)
    print(pal.warn('  it has not answered within 60s'))
    return 1


def is_missing_component(error):
    """Did the device say it does not have this, or did something else fail?"""
    text = str(error).lower()
    if 'rate limiting' in text or '429' in text or 'cannot reach' in text:
        return False
    return ('unknown method' in text or 'no handler' in text
            or '-105' in text or 'not found' in text or '404' in text)


def ble_report(rpc, pal):
    """Config and live status of the Bluetooth radio, with the reason it may still advertise."""
    config = rpc.call('BLE.GetConfig')
    enabled = bool(config.get('enable'))
    over_ble = bool((config.get('rpc') or {}).get('enable'))
    observer = (config.get('observer') or {}).get('enable')
    print('  %s is %s' % ('BLE', pal.ok('enabled') if enabled else pal.bad('disabled')))
    print('  %s is %s' % ('RPC over Bluetooth', pal.ok('enabled') if over_ble else pal.bad('disabled')))
    if observer is not None:
        print('  %s is %s' % ('BLE observer (BLU gateway)', pal.ok('enabled') if observer else pal.bad('disabled')))
    status = {}
    try:
        status = rpc.call('BLE.GetStatus') or {}
        shelly_print_flat(pal, flatten(status))
    except PlugError:
        pass
    flags = str(status.get('flags') or '')
    advertising = 'advertising' in flags
    if advertising and not enabled:
        print(pal.warn('  the radio is still advertising although BLE is disabled:'))
        # A change to ble.enable only takes effect after a restart.
        print(pal.note('    - the setting takes effect after a reboot: zigmon shelly %s reboot --wait'
                       % (getattr(rpc, 'role', None) or 'NAME')))
        # Matter commissioning keeps its own BLE beacon on until the device is
        # commissioned, whatever ble.enable says.
        try:
            mconf = rpc.call('Matter.GetConfig') or {}
            mstat = rpc.call('Matter.GetStatus') or {}
            if mconf.get('enable') and not (mstat.get('num_fabrics') or 0):
                print(pal.note('    - Matter is enabled and the device is not commissioned, so it keeps '
                               'advertising for a Matter controller regardless of the BLE switch.'))
                print(pal.note('      Turn it off too: zigmon shelly %s matter off --reboot'
                               % (getattr(rpc, 'role', None) or 'NAME')))
        except PlugError:
            pass
    return enabled, over_ble, advertising


def shelly_cmd_radio(args, pal):
    """ble and matter: status, on, off - both are a config flag plus a reboot."""
    rpc = shelly_for(args.device, args)
    rpc.role = args.device
    component = 'BLE' if args.command == 'ble' else 'Matter'
    action = (args.action or 'status').lower()

    if action == 'status':
        try:
            if component == 'BLE':
                ble_report(rpc, pal)
                return 0
            config = rpc.call('%s.GetConfig' % component)
        except PlugError as e:
            if is_missing_component(e):
                raise PlugError('%s is not available on this device' % component)
            raise
        enabled = bool(config.get('enable'))
        print('  %s is %s' % (component, pal.ok('enabled') if enabled else pal.bad('disabled')))
        try:
            shelly_print_flat(pal, flatten(rpc.call('%s.GetStatus' % component)))
        except PlugError:
            pass
        return 0

    if action == 'code':
        if component != 'Matter':
            raise PlugError('only matter has a pairing code')
        try:
            status = rpc.call('Matter.GetStatus')
        except PlugError as e:
            if is_missing_component(e):
                raise PlugError('this device does not support Matter')
            raise
        code = status.get('setup_code') or status.get('manual_pairing_code')
        payload = status.get('setup_payload') or status.get('qr_code')
        if not code and not payload:
            raise PlugError('the device did not return a pairing code. Matter has to be enabled '
                            'and the device not yet commissioned for one to exist.')
        if code:
            print('  manual pairing code : ' + pal.value(str(code)))
        if payload:
            print('  setup payload       : ' + pal.value(str(payload)))
        print(pal.note('  a controller needs one of these to commission the device'))
        return 0

    if action in ('rpc-on', 'rpc-off'):
        if component != 'BLE':
            raise PlugError('only ble has an rpc switch')
        rpc.call('BLE.SetConfig', {'config': {'rpc': {'enable': action == 'rpc-on'}}})
        config = rpc.call('BLE.GetConfig')
        settled = bool((config.get('rpc') or {}).get('enable'))
        if settled != (action == 'rpc-on'):
            print(pal.warn('  the device did not accept the change'))
            return 1
        print(pal.ok('  BLE RPC %s' % ('enabled' if settled else 'disabled')))
        if args.reboot:
            return shelly_cmd_reboot(args, pal)
        print(pal.note('  a reboot is needed for this to take effect: zigmon shelly %s reboot --wait'
                       % (args.device or 'NAME')))
        return 0

    if action not in ('on', 'off'):
        raise PlugError('use %s status, %s on or %s off' % (args.command, args.command, args.command))

    if component == 'BLE' and action == 'off':
        # Off means off: the radio, RPC over it, and the observer that scans
        # for BLU devices. Firmware without an observer ignores that key.
        rpc.call('BLE.SetConfig', {'config': {'enable': False, 'rpc': {'enable': False},
                                              'observer': {'enable': False}}})
    else:
        rpc.call('%s.SetConfig' % component, {'config': {'enable': action == 'on'}})
    config = rpc.call('%s.GetConfig' % component)
    settled = bool(config.get('enable'))
    if settled != (action == 'on'):
        print(pal.warn('  the device did not accept the change'))
        return 1
    print(pal.ok('  %s %s' % (component, 'enabled' if settled else 'disabled')))
    if args.reboot:
        rc = shelly_cmd_reboot(args, pal)
        if rc == 0 and component == 'BLE':
            print()
            _, _, advertising = ble_report(rpc, pal)
            if action == 'off' and advertising:
                return 1
        return rc
    print(pal.note('  a reboot is needed for this to take effect: zigmon shelly %s reboot --wait'
                   % (args.device or 'NAME')))
    if component == 'BLE' and action == 'off':
        try:
            mconf = rpc.call('Matter.GetConfig') or {}
            mstat = rpc.call('Matter.GetStatus') or {}
            if mconf.get('enable') and not (mstat.get('num_fabrics') or 0):
                print(pal.warn('  Matter is enabled and not commissioned: it will keep the BLE beacon on '
                               'even after the reboot. Turn it off too: zigmon shelly %s matter off --reboot'
                               % (args.device or 'NAME')))
        except PlugError:
            pass
    return 0


def build_parser():
    p = argparse.ArgumentParser(
        prog='zigmon',
        description='Zigbee2MQTT sensor monitor: daemon, history, localhost API (zigmon %s).' % __version__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Run with no arguments to start the daemon in the foreground - that is what the
systemd unit does. Everything else below is for testing and day-to-day use.

  zigmon --status                    every device with its latest readings
  zigmon --devices                   the device table (--json for machines)
  zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
  zigmon --events                    what the daemon has logged
  zigmon --watch                     live feed straight from the broker
  zigmon --watch --bridge --raw      including bridge/* topics, untruncated
  zigmon --permit-join on            open the Zigbee network for four minutes
  zigmon --plug                      every smart plug, live from the device
  zigmon --plug-on Lednice           switch a plug; also --plug-off, --plug-toggle
  zigmon --plug-pulse Lednice --ms 3000   flip it, hold 3 s, flip it back
  zigmon --plug-reset Lednice --types aenergy,switch_on
  zigmon --bindings                  which button action drives which plug
  zigmon --rules                     which reading drives which plug
  zigmon --check                     is the whole system healthy
  zigmon --diag                      settings, API latency, database size
  zigmon --aggregate                 roll old samples up now (daemon stopped)
  zigmon --reset-data history        erase: all, history, events, or a device name

Every command the standalone Shelly reader had is available under "shelly",
addressed by the name a device has in the configuration - the address and
password come from there:

  zigmon shelly Lednice info         identity and firmware
  zigmon shelly Lednice dump         every value the device reports
  zigmon shelly Lednice methods      every RPC method it supports (--examples)
  zigmon shelly Lednice config       the whole configuration
  zigmon shelly Lednice config switch:0 '{"auto_off": true}'
  zigmon shelly Lednice poll         a live table of the numbers (--csv FILE)
  zigmon shelly Lednice watch        the same, pushed rather than polled
  zigmon shelly Lednice on|off|toggle
  zigmon shelly Lednice reset-counters [aenergy ...]
  zigmon shelly Lednice reboot --wait
  zigmon shelly Lednice ble status|on|off|rpc-on|rpc-off [--reboot]
  zigmon shelly Lednice matter status|on|off|code [--reboot]
  zigmon shelly Lednice call Switch.GetStatus '{"id":0}'
  zigmon shelly HT-Sklep dump        a sensor, while it is awake
  zigmon shelly listen               show webhook pushes as they arrive
  zigmon shelly serve                accept an outbound websocket
  zigmon shelly discover             find Shelly devices on the LAN
  zigmon shelly --host 10.0.0.5 info a device not in the configuration
  zigmon shelly --help               the command list
  zigmon shelly config --help        the options of one command

A Zigbee gateway with its own network API (e.g. a SMLIGHT SLZB-06) is read
the same way, under "gateway" - set it up in config.json first under
"zigbee_gateways": [{"name": ..., "host": ..., "target": ...}], where
"target" is either "coordinator" or the name an existing Zigbee router
already has, so its readings extend that device instead of duplicating it:

  zigmon gateway Router dump         everything /ha_info, /ha_sensors and /metrics return
  zigmon gateway Router info         just /ha_info
  zigmon gateway Router sensors      just /ha_sensors
  zigmon gateway Router metrics      just /metrics (Prometheus text - heap, uptime, temps...)
  zigmon gateway --host 192.168.1.51 dump   a device not in config.json yet

Configuration lives in /etc/zigmon/config.json; every scalar key can also be
given as an environment variable with a ZIGMON_ prefix (ZIGMON_MQTT_HOST=...).
""")
    p.add_argument('--version', action='version', version='zigmon ' + __version__)
    p.add_argument('--config', metavar='FILE', help='configuration file (default %s)' % CONFIG_FILE)
    p.add_argument('--debug', action='store_true', help='verbose logging')
    p.add_argument('--json', action='store_true', help='machine-readable output where supported')
    p.add_argument('--no-color', action='store_true')
    p.add_argument('-y', '--yes', action='store_true', help='do not ask for confirmation')
    p.add_argument('--allow-root', action='store_true',
                   help='run the daemon as root anyway (only with a scratch --config)')
    a = p.add_argument_group('actions')
    a.add_argument('--status', action='store_true', help='every device with its latest readings')
    a.add_argument('--devices', action='store_true', help='the device table')
    a.add_argument('--history', metavar='DEVICE', help='recorded samples of one device')
    a.add_argument('--range', metavar='SPAN', help='for --history: 6h, 24h, 7d, 30d, 1y (default 24h)')
    a.add_argument('--keys', metavar='K1,K2', help='for --history: which readings')
    a.add_argument('--points', type=int, default=200, help='for --history: at most this many rows')
    a.add_argument('--events', action='store_true', help='the event log')
    a.add_argument('--limit', type=int, default=50, help='for --events')
    a.add_argument('--watch', action='store_true', help='live feed straight from the broker')
    a.add_argument('--seconds', type=float, default=0, help='for --watch: stop after this long')
    a.add_argument('--count', type=int, default=0, help='for --watch: stop after this many messages')
    a.add_argument('--bridge', action='store_true', help='for --watch: include bridge/* topics')
    a.add_argument('--raw', action='store_true', help='for --watch: do not shorten payloads')
    a.add_argument('--permit-join', metavar='on|off', help='open or close the Zigbee network')
    a.add_argument('--plug', metavar='NAME', nargs='?', const='all', help='the smart plug(s), live')
    a.add_argument('--plug-on', metavar='NAME', help='switch a plug on')
    a.add_argument('--plug-off', metavar='NAME', help='switch a plug off')
    a.add_argument('--plug-toggle', metavar='NAME', help='switch a plug to the other state')
    a.add_argument('--plug-pulse', metavar='NAME', help='flip a plug, wait --ms, flip it back')
    a.add_argument('--ms', type=int, default=PULSE_MS_DEFAULT, help='for --plug-pulse: the hold time in milliseconds')
    a.add_argument('--plug-reset', metavar='NAME', help='reset its counters (all, or --types a,b)')
    a.add_argument('--types', metavar='T1,T2', help='for --plug-reset: %s' % ', '.join(PLUG_COUNTER_TYPES))
    a.add_argument('--bindings', action='store_true', help='which button action drives which plug')
    a.add_argument('--rules', action='store_true', help='which reading drives which plug')
    a.add_argument('--reset-data', metavar='SCOPE', help='erase: all, history, events, or a device name')
    a.add_argument('--check', action='store_true', help='health check against the running daemon')
    a.add_argument('--diag', action='store_true', help='config, API latency, database size')
    a.add_argument('--aggregate', action='store_true', help='roll old samples up now (daemon must be stopped)')
    return p


def main(argv=None):
    global DEBUG, CONFIG_FILE
    arguments = list(sys.argv[1:] if argv is None else argv)

    # "zigmon gateway ..." reads a Zigbee gateway's own HTTP API (SLZB-06 etc).
    if arguments and arguments[0] == 'gateway':
        pal = Palette('--no-color' not in arguments and sys.stdout.isatty())
        return gateway_main(arguments[1:], pal)

    # "zigmon shelly ..." is a world of its own, with its own options.
    if arguments and arguments[0] == 'shelly':
        rest = []
        skip = False
        for index, value in enumerate(arguments[1:]):
            if skip:
                skip = False
                continue
            if value == '--config' and index + 2 < len(arguments):
                CONFIG_FILE = Path(arguments[index + 2])
                skip = True
                continue
            rest.append(value)
        load_config()
        for problem in CONFIG_FATAL:
            sys.stderr.write('CONFIG: %s\n' % problem)
        pal = Palette('--no-color' not in rest and sys.stdout.isatty())
        return shelly_main(rest, pal)

    args = build_parser().parse_args(arguments)
    if args.config:
        CONFIG_FILE = Path(args.config)
    DEBUG = args.debug
    load_config()
    pal = Palette(not args.no_color and sys.stdout.isatty())

    if CONFIG_FATAL and not (args.check or args.diag):
        for note in CONFIG_FATAL:
            sys.stderr.write('ERROR: %s\n' % note)
        return 2

    if args.status:
        return cmd_status(args, pal)
    if args.devices:
        return cmd_devices(args, pal)
    if args.history:
        return cmd_history(args, pal)
    if args.events:
        return cmd_events(args, pal)
    if args.watch:
        return cmd_watch(args, pal)
    if args.permit_join:
        return cmd_permit_join(args, pal)
    if args.plug:
        return cmd_plug(args, pal)
    if args.plug_on or args.plug_off or args.plug_toggle or args.plug_pulse:
        return cmd_plug_switch(args, pal)
    if args.plug_reset:
        return cmd_plug_reset(args, pal)
    if args.bindings:
        return cmd_bindings(args, pal)
    if args.rules:
        return cmd_rules(args, pal)
    if args.reset_data:
        return cmd_reset(args, pal)
    if args.check:
        return cmd_check(args, pal)
    if args.diag:
        return cmd_diag(args, pal)
    if args.aggregate:
        store = Storage()
        n = store.aggregate()
        print('rolled up %d hourly rows' % n)
        return 0

    if mqtt is None:
        sys.stderr.write('ERROR: python3-paho-mqtt is not installed (dnf install -y python3-paho-mqtt)\n')
        return 2

    # The daemon writes the database, its WAL and the token. Started as root
    # over the service's own files it leaves root-owned pieces behind that the
    # service cannot open on its next start.
    if os.geteuid() == 0 and not args.allow_root and str(db_path()).startswith(str(STATE_DIR)):
        try:
            import pwd
            pwd.getpwnam(SERVICE_USER)
            sys.stderr.write('ERROR: do not run the daemon as root over %s.\n'
                             '  installed service:   systemctl status zigmon\n'
                             '  foreground, as the service user:   sudo -u %s %s\n'
                             '  a scratch copy as root:   --config /tmp/test.json with db_file and api_port '
                             'of its own, plus --allow-root\n' % (STATE_DIR, SERVICE_USER, sys.argv[0]))
            return 2
        except KeyError:
            pass                        # no service user on this machine; a test box

    try:
        daemon = Daemon()
    except StorageError as e:
        sys.stderr.write('ERROR: %s\n' % e)
        return 2
    signal.signal(signal.SIGTERM, daemon.stop)
    signal.signal(signal.SIGINT, daemon.stop)
    signal.signal(signal.SIGHUP, daemon.reopen_log)
    return daemon.run()


if __name__ == '__main__':
    sys.exit(main())
