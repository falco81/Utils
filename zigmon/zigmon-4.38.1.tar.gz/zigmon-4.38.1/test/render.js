const { JSDOM } = require('jsdom');
(async () => {
  const base = 'http://127.0.0.1:8099/';
  const html = await (await fetch(base + 'index.php')).text();
  const errors = [];
  const dom = new JSDOM(html, { url: base + 'index.php', runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true,
    beforeParse(window) {
      window.fetch = (url, opts) => fetch(new URL(url, base).href, opts);
      window.confirm = () => true;
      window.addEventListener('error', e => errors.push(e.message));
      window.console.error = (...a) => errors.push(a.join(' '));
      Object.defineProperty(window.HTMLElement.prototype, 'clientWidth', { get() { return 600; } });
      Object.defineProperty(window.HTMLElement.prototype, 'clientHeight', { get() { return 240; } });
      Object.defineProperty(window.HTMLElement.prototype, 'offsetParent', { get() { return this.parentNode; } });
    }});
  const w = dom.window, d = w.document;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  await wait(1500);
  const txt = id => (d.getElementById(id) || {}).textContent;
  console.log('pill:', txt('pill-text'), '| devices:', txt('m-devices'), '| cards:', d.querySelectorAll('#device-cards .dev').length);
  console.log('ov-temp svg paths:', d.querySelectorAll('#ov-temp path').length, 'legend:', txt('ov-temp-legend'));
  for (const tab of ['history','devices','events','control','all']) {
    d.querySelector('.tabs button[data-tab="'+tab+'"]').click();
    await wait(1200);
  }
  console.log('history charts:', d.querySelectorAll('#h-charts .card').length, '| note:', txt('h-note'));
  console.log('devices rows:', d.querySelectorAll('#devices-table tbody tr').length);
  console.log('events rows:', d.querySelectorAll('#events-table tbody tr').length);
  console.log('health rows:', d.querySelectorAll('#health-kv .kv').length);
  console.log('all cards:', d.querySelectorAll('#all-values .card').length);
  // control: reset events with PIN flow
  d.querySelector('.tabs button[data-tab="control"]').click(); await wait(300);
  d.querySelector('[data-reset="events"]').click(); await wait(200);
  console.log('modal shown:', !d.getElementById('pinback').hidden);
  // the PIN is one box per digit since 2.x
  Array.from(d.getElementById('pindigits').querySelectorAll('input')).forEach((i, n) => { i.value = '1234'[n] || ''; i.dispatchEvent(new w.Event('input', {bubbles: true})); });
  d.getElementById('pinok').click(); await wait(1200);
  console.log('toast:', txt('toast'));
  // hover a chart
  d.querySelector('.tabs button[data-tab="overview"]').click(); await wait(800);
  const c = d.getElementById('ov-temp');
  c.dispatchEvent(new w.MouseEvent('mousemove', {clientX: 300, clientY: 100, bubbles: true}));
  console.log('tip:', (c.querySelector('.tip')||{}).style && c.querySelector('.tip').style.display, (c.querySelector('.tip')||{}).textContent);
  // A rule dragged by its handle must survive the house reporting while the
  // pointer is down: the guard against redrawing under a drag knew only about
  // the cards, so in a busy house every drag was undone by the next report.
  try {
    const r2 = await (await fetch(base + 'index.php?api=unlock', {method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({pin: '1234', minutes: 30})})).json();
    if (r2 && r2.token) {
      w.LOCK.token = r2.token; w.LOCK.until = r2.until; w.SIGS = {}; w.tick(true);
      d.querySelector('.tabs button[data-tab="control"]').click(); await wait(400);
      w.showControlSection('automation'); await wait(2500);
      const packs = Array.from(d.querySelectorAll('#rules-list .rule-pack'));
      if (packs.length > 1) {
        const a = packs[0], b = packs[1], parent = a.parentNode;
        const dt = {effectAllowed: '', setData() {}, getData() { return 'row'; }};
        a.querySelector('.rowgrab').dispatchEvent(new w.MouseEvent('mousedown', {bubbles: true}));
        a.dispatchEvent(Object.assign(new w.Event('dragstart', {bubbles: true}), {dataTransfer: dt}));
        // exactly what a report from the house does, and what used to rebuild
        // the list out from under the pointer
        w.SIGS = {}; w.tick(true); await wait(1800);
        if (!d.body.contains(a)) errors.push('the row being dragged was rebuilt out from under the pointer');
        b.dispatchEvent(Object.assign(new w.Event('dragover', {bubbles: true, cancelable: true}), {dataTransfer: dt}));
        const moved = Array.prototype.indexOf.call(parent.children, a)
                    > Array.prototype.indexOf.call(parent.children, b);
        a.dispatchEvent(new w.Event('dragend', {bubbles: true}));
        await wait(400);
        console.log('a rule dragged through a redraw moves:', moved);
        if (!moved) errors.push('a rule could not be dragged while the house was reporting');
      }
    }
  } catch (e) { errors.push('the drag check itself failed: ' + e.message); }

  // Every way in must lead somewhere, and everything meant for a section must
  // be reachable from it. A card filed under a section with no button, or a
  // tab with no panel, is invisible however right the code behind it is.
  try {
    const tabs = Array.from(d.querySelectorAll('.tabs button[data-tab]')).map(b => b.dataset.tab);
    const panels = Array.from(d.querySelectorAll('section.panel[id^="tab-"]')).map(s => s.id.slice(4));
    tabs.forEach(t => { if (panels.indexOf(t) < 0) errors.push('the ' + t + ' tab has no panel'); });
    panels.forEach(p => { if (tabs.indexOf(p) < 0) errors.push('the ' + p + ' panel has no tab button'); });
    const navSecs = Array.from(d.querySelectorAll('#control-nav button[data-sec]')).map(b => b.dataset.sec);
    const cardSecs = Array.from(d.querySelectorAll('#tab-control [data-sec]'))
      .filter(x => x.tagName !== 'BUTTON').map(x => x.dataset.sec);
    cardSecs.forEach(s2 => {
      if (navSecs.indexOf(s2) < 0) errors.push('a card is filed under "' + s2 + '", which has no button');
    });
    navSecs.forEach(s2 => {
      if (cardSecs.indexOf(s2) < 0) errors.push('the "' + s2 + '" button leads to nothing');
    });
    console.log('ways in: %d tab(s), %d section(s), all of them leading somewhere',
                tabs.length, navSecs.length);
  } catch (e) { errors.push('the reachability check itself failed: ' + e.message); }

  // Every column header against the rows it names. Two faults kept appearing
  // one editor at a time: a header without the indent its rows get for the
  // drag handle, so every name sits one notch left of its column; and a
  // header that inherits its row's rounded corners, which lifts the ends of
  // its underline off the line.
  try {
    // The gateways are only there to measure when one is configured, and a
    // check that says nothing when there are none is how their header was
    // wrong three times over. Plant one for the measurement and take it away.
    var plantedGateway = false;
    if (!d.querySelector('.gw-row:not(.gw-head)')) {
      var gwSave = await (await fetch(base + 'index.php?api=gateways-save', {method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({pin: '1234', gateways: [{name: 'Measure-Me', host: '127.0.0.1', kind: 'slzb'}]})})).json();
      if (gwSave && gwSave.ok) { plantedGateway = true; w.SIGS = {}; w.tick(true); await wait(1500); }
      else errors.push('no gateway on the page and none could be planted to measure the header');
    }
    // every card has to be drawn before its header can be measured
    for (var si = 0; si < ['devices', 'automation', 'presence', 'alerts', 'system'].length; si++) {
      w.showControlSection(['devices', 'automation', 'presence', 'alerts', 'system'][si]);
      await wait(1500);
    }
    await wait(800);
    var headTrouble = [];
    // Every column header on the page, measured the way the eye measures it:
    // the header stands above the folds and the boxes it names sit inside
    // them, so a fold's own inset moves the boxes and not the names. Some
    // editors fold their rows and some do not, and the header has to follow
    // whichever it is - calling the difference "the fold rather than a
    // misalignment" is how this was waved away twice.
    var headsSeen = 0;
    Array.prototype.forEach.call(d.querySelectorAll('[class*="-head"]'), function (head) {
      var kind = (String(head.className).match(/([a-z0-9]+)-head/) || [])[1];
      if (!kind) return;
      var card = head.closest('.card') || d;
      var rows = Array.prototype.filter.call(card.querySelectorAll('.' + kind + '-row'),
        function (x) { return !x.classList.contains(kind + '-head'); });
      if (!rows.length) return;
      var reach = function (node) {
        var total = 0;
        while (node && node !== card) {
          total += parseFloat(w.getComputedStyle(node).paddingLeft) || 0;
          node = node.parentElement;
        }
        return total;
      };
      headsSeen++;
      // every row, not the first: the gateways mix rows from config.json,
      // which cannot be dragged, with rows made on the page, which can, and
      // a header can only line up with all of them if they agree
      var nameAt = reach(head);
      var offRows = rows.map(function (row) { return reach(row); })
        .filter(function (at) { return at !== nameAt; });
      if (offRows.length) {
        headTrouble.push(kind + ': the names start at ' + nameAt + 'px and ' + offRows.length + ' of '
          + rows.length + ' row(s) start at ' + offRows[0] + 'px'
          + (rows[0].closest('.section-body') ? ' (its rows are in a fold)' : ''));
      }
      // Only a header drawn as a row of its table can curve away from its own
      // underline; a plain caption above a list is not that and has nothing
      // to line up with.
      var hs = w.getComputedStyle(head);
      if (head.classList.contains(kind + '-row')
          && hs.borderRadius !== '0px' && hs.borderBottomWidth !== '0px') {
        headTrouble.push(kind + ': rounded header with an underline, which lifts at the ends');
      }
    });
    headTrouble.forEach(function (t) { errors.push('column header - ' + t); });
    if (!d.querySelector('.gw-row:not(.gw-head)')) errors.push('the gateway header was never measured');
    if (plantedGateway) {
      await fetch(base + 'index.php?api=gateways-save', {method: 'POST',
        headers: {'Content-Type': 'application/json'}, body: JSON.stringify({pin: '1234', gateways: []})});
    }
    console.log('column headers: %d measured, %s', headsSeen,
      headTrouble.length ? 'some out of line' : 'every name over its box');
  } catch (e) { errors.push('the column header check itself failed: ' + e.message); }

  // A link telling something of its own has the same writing desk an alert
  // has: the symbol picker, the fact picker, the completer, and a preview
  // that says what the watch would read out.
  try {
    w.showControlSection('automation');
    await wait(1800);
    var tapRow = d.querySelector('#taps-list .tap-row:not(.tap-head)');
    if (tapRow && (w.TAPS.rows || []).length) {
      var theTap = w.TAPS.rows[0];
      theTap.target = 'tell'; theTap.do = 'own';
      theTap.text = 'Inside {inside_c} and outside {outside_c}.';
      w.TAPS.dirty = true; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
      await wait(300);
      var desk = d.querySelector('.tap-storybox');
      if (!desk || desk.hidden) errors.push('a link of your own has no writing desk');
      else {
        if (!desk.querySelector('textarea')) errors.push('the writing desk has no text area');
        var deskBtns = Array.prototype.map.call(desk.querySelectorAll('button'),
          function (b) { return b.textContent; }).join(' ');
        if (deskBtns.indexOf('Emoji') < 0) errors.push('the writing desk has no symbol picker');
        if (deskBtns.indexOf('Facts') < 0) errors.push('the writing desk has no fact picker');
        // the section sweep above leaves another section showing, so come
        // back to the links before looking for their preview
        w.showControlSection('automation');
        await wait(1200);
        w.scheduleTellPreview();
        // what it must show is a sentence with the {...} filled in - not a
        // digit. A house with no indoor temperature fills {inside_c} with
        // nothing, which is correct and used to be called a failure here.
        var shown = null, says = '';
        for (var pw = 0; pw < 12; pw++) {
          shown = d.querySelector('.tap-preview[data-tap="' + theTap.id + '"]');
          says = (shown && shown.textContent || '').trim();
          if (says.length > 20 && says.indexOf('{') < 0) break;
          await wait(300);
        }
        if (!says) errors.push('the preview says nothing about what the watch would read');
        else if (says.indexOf('{') >= 0) errors.push('the preview left a {fact} standing: ' + says.slice(0, 60));
        // and it must survive a redraw landing in the middle of the asking.
        // The answer used to be written into the box the round began with,
        // which a redraw had thrown away by then: the line stayed empty on
        // that link until something else made the card redraw, which is why
        // it went missing only sometimes and only somewhere.
        // and a prepared report with nothing to say right now must say so.
        // It used to leave the line blank and remember that it had, so the
        // link kept an empty preview until its text or its report changed -
        // indistinguishable from a preview that never arrived.
        var realApi = w.api, wasDo = theTap.do;
        theTap.do = 'house';                 // a prepared report, not a sentence of your own
        w.api = function (what) {
          if (String(what).indexOf('tell&') === 0) return Promise.resolve({said: ''});
          return realApi.apply(null, arguments);
        };
        var quiet = d.querySelector('.tap-preview[data-tap="' + theTap.id + '"]');
        if (quiet) { delete quiet.dataset.shown; quiet.innerHTML = ''; }   // so what appears is this round's
        w.scheduleTellPreview();
        var saidNothing = '';
        for (var pq = 0; pq < 10; pq++) {
          await wait(300);
          var qn = d.querySelector('.tap-preview[data-tap="' + theTap.id + '"]');
          saidNothing = (qn && qn.textContent || '').trim();
          if (saidNothing) break;
        }
        w.api = realApi; theTap.do = wasDo;
        if (!saidNothing) errors.push('a report with nothing to say leaves the preview blank');
      }
      // the row above the desk keeps its shape whatever the link is doing:
      // a switch, a prepared report, or a sentence of your own
      var shapes = [];
      var trials = [['Probe-Plug', 'toggle'], ['tell', 'house'], ['tell', 'own']];
      for (var ti = 0; ti < trials.length; ti++) {
        var pair = trials[ti];
        theTap.target = pair[0]; theTap.do = pair[1];
        w.TAPS.dirty = true; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
        var again = d.querySelector('#taps-list .tap-row:not(.tap-head)');
        var onLine = Array.prototype.filter.call(again.children, function (c) {
          return !c.classList.contains('rowgrab') && !c.classList.contains('tap-storybox');
        }).length;
        var area = again.querySelector('.tap-story');
        var tools = again.querySelector('.tap-storytools');
        shapes.push(onLine);
        if (area && tools && area.hidden !== tools.hidden) {
          errors.push('the text box and its buttons do not come and go together');
        }
        // What is on the screen, not what the script believes: display:flex
        // beats the hidden attribute, and that is how the pickers stayed
        // visible however carefully they were hidden.
        var seen = function (node) { return node && w.getComputedStyle(node).display !== 'none'; };
        var own = pair[0] === 'tell' && pair[1] === 'own';
        var telling = pair[0] === 'tell';
        if (seen(tools) !== own) {
          errors.push('the pickers are ' + (own ? 'not shown for' : 'shown outside') + ' a sentence of your own');
        }
        if (seen(area) !== own) {
          errors.push('the text box is ' + (own ? 'not shown for' : 'shown outside') + ' a sentence of your own');
        }
        // an empty preview is hidden by its own rule, so wait for the answer
        // rather than for the element
        var preBox = again.querySelector('.tap-preview');
        if (telling) {
          w.scheduleTellPreview();
          for (var tries = 0; tries < 12 && !(preBox.textContent || '').trim(); tries++) await wait(300);
          if (!(preBox.textContent || '').trim()) errors.push('no preview on a ' + pair[1] + ' link');
        } else if (seen(preBox)) {
          errors.push('a switching link shows a preview of something that has not happened');
        }
      }
      var headCells = d.querySelector('.tap-head').children.length;
      if (shapes.some(function (n) { return n !== headCells; })) {
        errors.push('the link row changes shape: ' + shapes.join(', ') + ' against ' + headCells + ' headings');
      }
      // A link that was already there, edited through the controls rather than
      // by setting the model: a redraw replaces the rows, and a handler that
      // held on to the object it was built with writes into a discarded one.
      // That is why a new link behaved and an old one did not.
      theTap.target = 'Probe-Plug'; theTap.do = 'toggle';
      w.TAPS.dirty = false; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
      await wait(200);
      var liveRow = d.querySelector('#taps-list .tap-row:not(.tap-head)');
      var targetSel = liveRow.querySelectorAll('select')[0];
      if (targetSel) {
        targetSel.value = 'tell';
        targetSel.onchange();
        await wait(150);
        if ((w.TAPS.rows[0] || {}).target !== 'tell') {
          errors.push('editing a link that was already there does not take');
        }
      }
      // A new row must start with nothing chosen, not with whatever happens
      // to be first in the list: that had it showing "tell me something" with
      // "toggle" beside it, a pair that cannot be, until it was clicked away
      // and back again.
      d.getElementById('tap-add').onclick();
      await wait(400);
      var made = Array.prototype.slice.call(d.querySelectorAll('#taps-list .tap-row'))
        .filter(function (x) { return !x.classList.contains('tap-head'); });
      var fresh = made[made.length - 1];
      var freshModel = w.TAPS.rows[w.TAPS.rows.length - 1];
      // A new row may come filled in, but the two lists must agree: it used
      // to offer "tell me something" with "toggle" beside it, a pair that
      // cannot be, until it was clicked away and back again.
      var freshSels = fresh.querySelectorAll('select');
      var offered = Array.prototype.map.call(freshSels[1].options, function (o) { return o.value; });
      if (offered.indexOf(freshModel.do) < 0) {
        errors.push('a new link offers ' + JSON.stringify(freshModel.do) + ' which is not one of its own actions');
      }
      if (freshSels[0].value !== freshModel.target || freshSels[1].value !== freshModel.do) {
        errors.push('a new link shows something other than what it holds');
      }
      w.TAPS.rows.pop(); w.TAPS.dirty = false;

      // and asking the house something belongs to the links alone
      var elsewhere = [];
      ['#bindings-list select', '#rules-list select', '#scenes-list select'].forEach(function (sel) {
        Array.prototype.forEach.call(d.querySelectorAll(sel), function (x) {
          if (Array.prototype.some.call(x.options, function (o) { return o.value === 'tell'; })) {
            elsewhere.push(sel);
          }
        });
      });
      if (elsewhere.length) errors.push('"tell me something" is offered in ' + elsewhere[0]);

      // The preview reads the row as it stands on the screen; until it is
      // saved, the link itself still does the old thing. Both places have to
      // say so, or a preview is just a confident wrong answer.
      theTap.target = 'tell'; theTap.do = 'house';
      w.TAPS.dirty = true; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
      await wait(200);
      w.scheduleTellPreview();
      for (var pt = 0; pt < 12; pt++) {
        var lbl = d.querySelector('.tap-preview .lbl');
        if (lbl && lbl.textContent) break;
        await wait(300);
      }
      var label = d.querySelector('.tap-preview .lbl');
      if (!label || label.textContent.indexOf('saved') < 0) {
        errors.push('with changes unsaved the preview does not say so: '
          + JSON.stringify(label && label.textContent));
      }
      var told = null;
      var keepToast = w.toast;
      w.toast = function (m) { told = m; };
      w.showTapSetup(theTap);
      await wait(200);
      w.toast = keepToast;
      if (!told || String(told).indexOf('Save') < 0) {
        errors.push('the setup dialog hands out an address that does not match the screen');
      }
      w.TAPS.dirty = false;
      console.log('a telling link: writing desk, pickers and preview all there');
    }
  } catch (e) { errors.push('the telling-link check itself failed: ' + e.message); }

  // Renaming a section that has rows in it must move the rows, not leave them
  // behind under the old name with an empty section beside it. A row holds the
  // object it was built with, and a redraw replaces those with fresh copies -
  // so writing through the row's own copy renamed something already discarded.
  try {
    var storesWithSections = [['taps', w.TAPS], ['messages', w.MESSAGES], ['ptrig', w.PTRIG],
                              ['bindings', w.BINDINGS]];
    var regroupTrouble = [];
    storesWithSections.forEach(function (pair) {
      var store = pair[1];
      if (!store || !(store.rows || []).length) return;
      var was = store.rows[0].group || '';
      var mine = store.rows.filter(function (r) { return (r.group || '') === was; }).length;
      var moved = w.regroupRows(store, was, 'A-New-Name');
      if (moved !== mine) {
        regroupTrouble.push(pair[0] + ': renaming moved ' + moved + ' of ' + mine + ' row(s)');
      }
      var left = store.rows.filter(function (r) { return (r.group || '') === was; }).length;
      if (left) regroupTrouble.push(pair[0] + ': ' + left + ' row(s) stayed under the old name');
      w.regroupRows(store, 'A-New-Name', was);          // put it back
    });
    regroupTrouble.forEach(function (t) { errors.push('renaming a section - ' + t); });
    console.log('renaming a section: %d editor(s) checked, rows follow their section',
      storesWithSections.filter(function (p) { return p[1] && (p[1].rows || []).length; }).length);
  } catch (e) { errors.push('the section-rename check itself failed: ' + e.message); }

  // A scene or a sequence runs its own steps and the daemon takes no notice of
  // what is asked of it, so offering on, off and toggle beside one offers a
  // choice that does not exist. Two editors said so in a note beside the list
  // and the rest quietly did not; it is decided in one place now, so every
  // editor that fills an action list gets it.
  try {
    var st = w.STATE.status || {};
    var runners = [];
    ((st.scenes || [])[0] ? [['a scene', 'scene:' + st.scenes[0].id]] : [])
      .concat((st.sequences || [])[0] ? [['a sequence', 'sequence:' + st.sequences[0].id]] : [])
      .forEach(function (pair) {
        var opts = w.doOptionsFor(st, pair[1], 'on');
        if (opts.length !== 1) {
          errors.push(pair[0] + ' offers ' + opts.length + ' actions, and it has only one: its own steps');
        } else if (opts[0][1].indexOf('own steps') < 0) {
          errors.push(pair[0] + ' does not say that it runs its own steps: ' + JSON.stringify(opts[0][1]));
        }
        runners.push(pair[0]);
      });
    // and a socket must still have its full set, or the rule above is too keen
    var plugName = ((st.plugs || [])[0] || {}).name;
    if (plugName && w.doOptionsFor(st, plugName, 'on').length < 3) {
      errors.push('a socket lost its actions');
    }
    // and it must be a plain line, not a list with one thing in it: nobody
    // should be given a menu to choose from when there is nothing to choose
    var seenAt = w.getComputedStyle.bind(w);
    var shownBeside = [];
    Array.prototype.forEach.call(d.querySelectorAll('select'), function (sel) {
      if (seenAt(sel).display === 'none') return;
      var prev = sel.previousElementSibling;
      if (prev && prev.tagName === 'SELECT' && String(prev.value).indexOf('scene:') === 0) {
        shownBeside.push(((sel.closest('.card') || {}).id || 'a card'));
      }
    });
    if (shownBeside.length) {
      errors.push('a list of actions is still offered beside a scene in ' + shownBeside[0]);
    }
    // The line has to be where the list was, not an extra cell beside it: in a
    // row laid out as a grid an extra cell shifts every column after it, which
    // is how choosing a scene resized the name box next to it.
    Array.prototype.forEach.call(d.querySelectorAll('.tap-row:not(.tap-head)'), function (row) {
      var note = row.querySelector('.scene-note');
      if (!note || seenAt(note).display === 'none') return;
      var onLine = Array.prototype.filter.call(row.children, function (c) {
        return !c.classList.contains('rowgrab') && !c.classList.contains('tap-storybox');
      }).length;
      var headings = (d.querySelector('.tap-head') || {children: []}).children.length;
      if (onLine !== headings) {
        errors.push('a link showing the plain line has ' + onLine + ' cells against ' + headings + ' headings');
      }
      if (!note.closest('.tap-act')) {
        errors.push('the plain line sits outside the cell the list was in, so it moves the columns');
      }
    });
    var plainLines = Array.prototype.filter.call(d.querySelectorAll('.scene-note'),
      function (n) { return seenAt(n).display !== 'none'; });
    console.log('what runs its own steps: %s, said as a plain line in %d place(s)',
      runners.join(' and ') || 'nothing', plainLines.length);
  } catch (e) { errors.push('the own-steps check itself failed: ' + e.message); }

  // ---- a road apiece, not a list of combinations ---------------------------
  // Three roads make eight ways of choosing, and the list of combinations
  // offered seven: ntfy and a text but not Telegram could not be said at all.
  try {
    d.querySelector('.tabs button[data-tab="control"]').click(); await wait(400);
    const alerts = d.querySelector('#control-nav button[data-sec="alerts"]');
    if (alerts) { alerts.click(); await wait(1200); }
    const rows = d.querySelectorAll('#notify-systems .notify-sys');
    if (!rows.length) errors.push('no kind of message has its own roads to switch');
    if (d.querySelectorAll('#notify-systems select').length) {
      errors.push('a kind of message is still chosen from a list of combinations');
    }
    const row = rows[0];
    const sw = row.querySelectorAll('.swrow input');
    if (sw.length !== 4) errors.push('a kind of message has ' + sw.length + ' switches, wanted four');
    if (!Array.prototype.slice.call(sw, 1).every(i => i.disabled)) {
      errors.push('the roads can be switched while the kind still follows the house');
    }
    sw[0].checked = true; sw[0].dispatchEvent(new w.Event('change', { bubbles: true }));
    await wait(50);
    const road = k => row.querySelector('input[data-road="' + k + '"]');
    if (road('sms').disabled) errors.push('a kind with its own roads still cannot pick one');
    road('ntfy').checked = true; road('telegram').checked = false; road('sms').checked = true;
    road('sms').dispatchEvent(new w.Event('change', { bubbles: true }));
    await wait(50);
    const picked = Array.prototype.filter.call(row.querySelectorAll('input[data-road]'), b => b.checked)
      .map(b => b.dataset.road).join(',');
    if (picked !== 'ntfy,sms') errors.push('ntfy and a text without Telegram cannot be chosen: got ' + picked);
    road('ntfy').checked = false; road('sms').checked = false;
    road('sms').dispatchEvent(new w.Event('change', { bubbles: true }));
    await wait(50);
    if (!/nothing/.test(row.querySelector('.notify-sys-says').textContent)) {
      errors.push('with no road on, the row does not say it will stay silent');
    }
    console.log('alerts: %d kind(s), a switch per road, all eight ways sayable', rows.length);
  } catch (e) { errors.push('the alert-roads check itself failed: ' + e.message); }

  // ---- what is waiting for somebody to say yes -----------------------------
  try {
    const tab = d.querySelector('.tabs button[data-tab="approvals"]');
    if (!tab) errors.push('there is no place to see what is waiting to be approved');
    else {
      tab.click(); await wait(1200);
      if (!d.getElementById('approvals-live')) errors.push('the approvals tab is empty of itself');
      if (!d.getElementById('approvals-stop-all')) errors.push('there is no way to call them all off');
      if (!d.querySelector('#approvals-past tbody')) errors.push('there is nowhere for the history');
      const order = Array.from(d.querySelectorAll('.tabs button')).map(b => b.dataset.tab);
      if (order.indexOf('approvals') !== order.indexOf('events') + 1) {
        errors.push('the approvals tab does not sit after Events');
      }
      // the habits the rest of the page keeps: an icon on every button, the
      // lock on every button that changes something, and a row that answers
      // the pointer
      const btns = Array.from(d.querySelectorAll('#tab-approvals button'));
      // an icon name nobody drew makes an empty <svg>, which looked like an
      // icon to this check and like nothing at all to a person
      const bare = btns.filter(b => {
        const svg = b.querySelector('svg');
        const drawn = (svg && svg.innerHTML.trim().length > 0) || b.querySelector('img');
        return !drawn && !/[\u2190-\u27bf\ud83c-\udbff]/.test(b.textContent);
      });
      if (bare.length) {
        errors.push('button(s) with no icon on the presses tab: '
          + bare.map(b => b.textContent.trim().slice(0, 20)).join(', '));
      }
      // A button with an icon, wearing the lock, and with nothing behind it
      // looks exactly like one that works. One of these lost its handler in a
      // move and nobody could tell by looking.
      const wired = ['approvals-stop-all', 'approvals-forget-btn', 'blocked-add',
                     'blocked-add-forever', 'blocked-clear', 'blocked-forget',
                     'blocked-forget-counters'];
      const dead = wired.filter(id => {
        const b = d.getElementById(id);
        return b && !b.onclick;
      });
      if (dead.length) errors.push('button(s) with nothing behind them: ' + dead.join(', '));
      const changes = ['approvals-stop-all', 'blocked-add', 'blocked-add-forever', 'blocked-clear',
                       'blocked-forget'];
      const unlocked = changes.filter(id => {
        const b = d.getElementById(id);
        return b && !b.classList.contains('needs-unlock');
      });
      if (unlocked.length) {
        errors.push('button(s) that change something but do not wear the lock: ' + unlocked.join(', '));
      }
      const styled = [];
      Array.from(d.styleSheets || []).forEach(sh => {
        try {
          Array.from(sh.cssRules).forEach(r => {
            if (r.selectorText && /\.appr-row:hover/.test(r.selectorText)) styled.push(r.selectorText);
          });
        } catch (e) { /* a sheet from elsewhere */ }
      });
      if (!styled.length) errors.push('a row on the presses tab does not answer the pointer');
      // and the settings panel for the router's key, which lives elsewhere
      try {
        w.renderSettings(w.STATE.status);
        const panel = d.querySelector('#settings-grid .subpanel');
        if (panel) {
          const dull = Array.from(panel.querySelectorAll('button')).filter(b => {
            const svg = b.querySelector('svg');
            return !(svg && svg.innerHTML.trim().length);
          });
          if (dull.length) {
            errors.push('the router key panel has button(s) with an empty icon: '
              + dull.map(b => b.textContent.trim()).join(', '));
          }
        }
      } catch (e) { errors.push('the key panel check itself failed: ' + e.message); }
      // taking an address off the list must take its line with it, without
      // waiting for a fetch that may be slow, refused, or held back
      try {
        const un = await (await fetch(base + 'index.php?api=unlock', { method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: '1234', minutes: 10 }) })).json();
        w.LOCK.token = un.token; w.LOCK.until = un.until;
        await fetch(base + 'index.php?api=blocked', { method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: '1234', ip: '89.24.5.7', forever: true, session: un.token }) });
        w.loadApprovals(true); await wait(900);
        // both kinds live in a fold now, so the rows are inside one - opened
        // here, because a fold that is shut draws nothing until it is
        const shutFolds = Array.from(d.querySelectorAll('#blocked-list .listed-head'));
        shutFolds.forEach(h => h.click());
        const rows = d.querySelectorAll('#blocked-list .appr-row').length;
        if (!rows) errors.push('an address that was blocked does not show on the list');
        const cross = d.querySelector('#blocked-list .appr-row button');
        if (cross) {
          cross.click(); await wait(1200);
          if (d.querySelectorAll('#blocked-list .appr-row').length >= rows) {
            errors.push('taking an address off the list left its line there');
          }
        }
      } catch (e) { errors.push('the blocked-list check itself failed: ' + e.message); }
      // the variables dialogue: boxes with the page's shape, buttons with
      // icons, and the rule's own names offered only on that rule
      try {
        const row = {phrase: 'unban', vars: [{name: 'ip', from: 'rest', note: ''}]};
        w.editRowVars(row, 'command', function () {});
        await wait(300);
        const box = d.querySelector('#attnbody input');
        if (!box || !box.classList.contains('varbox')) {
          errors.push('the variables dialogue has a box with no shape');
        }
        const bare = Array.from(d.querySelectorAll('#attnbody button')).filter(b => {
          const svg = b.querySelector('svg');
          return !(svg && svg.innerHTML.trim());
        });
        if (bare.length) {
          errors.push('the variables dialogue has button(s) with no icon: '
            + bare.map(b => b.textContent.trim()).join(', '));
        }
        // a name written into the phrase is also kept on the row, so both say
        // it: the list must say it once, and with the braces the list draws
        w.COMPLETE_LOCAL = w.rowVars(row).concat(w.phraseNames('unban {ip}'));
        const mine = w.completerItems('ip').filter(x => x.label === 'ip');
        if (mine.length !== 1) {
          errors.push('a name a rule made up is offered ' + mine.length + ' time(s), not once');
        }
        if (w.completerItems('ip').some(x => /^\{|\}$/.test(x.label || ''))) {
          errors.push('a name is offered with braces the list draws itself');
        }
        if (!w.completerItems('ip.').length) {
          errors.push('a name a rule made up takes no turns of phrase');
        }
        w.COMPLETE_LOCAL = [];
        const shut = d.getElementById('attnback');
        if (shut) shut.hidden = true;
      } catch (e) { errors.push('the variables check itself failed: ' + e.message); }
      // the scripts: their verbs are what the box offers, and their names are
      // what a command may point at - under a heading of their own
      try {
        if (!(w.SCRIPTS.verbs || []).length) {
          errors.push('the script verbs never arrived, so the box can offer none');
        } else {
          w.COMPLETE_LOCAL = w.verbNames();
          if (!w.completerItems('unb').some(x => x.label === 'unban')) {
            errors.push('the script box does not offer its own verbs');
          }
          w.COMPLETE_LOCAL = [];
          // ...and it has to offer them where they are written, which is at
          // the start of a line and not inside braces
          // a house with no script yet has no box; one is added to type in
          if (!d.querySelector('#scripts-list textarea')) {
            const add = d.getElementById('script-add');
            if (add) { add.click(); await wait(400); }
          }
          const box = d.querySelector('#scripts-list textarea');
          if (!box) {
            errors.push('adding a script leaves nothing to type in');
          } else {
            box.value = 'un';
            box.focus();
            box.selectionStart = 2;
            box.dispatchEvent(new w.KeyboardEvent('keydown', {key: ' ', ctrlKey: true, bubbles: true}));
            await wait(400);
            const pop = d.querySelector('.acbox');
            const names = pop ? Array.from(pop.querySelectorAll('.ac-name')).map(x => x.textContent) : [];
            if (names.indexOf('unban') < 0) {
              errors.push('Ctrl+Space at the start of a script line offers no verb: ' + names.slice(0, 3));
            }
            if (names.some(n => /^\{/.test(n))) {
              errors.push('a verb is offered as though it were a fact in braces');
            }
            box.dispatchEvent(new w.KeyboardEvent('keydown', {key: 'Enter', bubbles: true}));
            await wait(250);
            if (box.value.indexOf('}') >= 0) errors.push('picking a verb wrote a brace: ' + box.value);
            box.value = '';
          }
          // put the page back as it was found: a row added here and left
          // behind marks the editors as having something unsaved, and the
          // checks that come after are skipped while anything is
          w.SCRIPTS.rows = (w.SCRIPTS.rows || []).filter(one => one.id);
          w.SCRIPTS.dirty = false;
          w.paintScripts();
          const note = d.getElementById('script-note');
          if (note) note.textContent = '';
        }
        ['script-add', 'script-save'].forEach(id => {
          const b = d.getElementById(id), svg = b && b.querySelector('svg');
          if (b && !(svg && svg.innerHTML.trim())) {
            errors.push('the scripts card has a button with no icon: ' + id);
          }
        });
      } catch (e) { errors.push('the scripts check itself failed: ' + e.message); }
      // an escape written into the markup is read out as \u2014 rather than
      // as a dash: the page is PHP, and a backslash there is just a backslash
      // ...read from what is shown, not from the page's own source: the text
      // of a <script> is part of the body's text and is full of them
      const shown = Array.from(d.querySelectorAll('p, h1, h2, h3, li, td, th, label, button, span'))
        .map(n => n.textContent || '').join(' ');
      const loose = shown.match(/\\u[0-9a-fA-F]{4}/g);
      if (loose) errors.push('the page shows escapes as text: ' + loose.slice(0, 3).join(' '));
      // the page's own habits, across every tab and section rather than the
      // one card being worked on: an id used twice makes $('x') pick the
      // wrong one, and a command button with no icon reads as unfinished
      const idsSeen = {}, twice = [];
      d.querySelectorAll('[id]').forEach(n => {
        idsSeen[n.id] = (idsSeen[n.id] || 0) + 1;
        if (idsSeen[n.id] === 2) twice.push(n.id);
      });
      if (twice.length) errors.push('id(s) used more than once: ' + twice.slice(0, 5).join(', '));
      const plainButtons = Array.from(d.querySelectorAll('button.btn')).filter(b =>
        !b.closest('.tabs') && !b.closest('#control-nav') && !b.classList.contains('pg'));
      const noIcon = plainButtons.filter(b => {
        const svg = b.querySelector('svg');
        const drawn = (svg && svg.innerHTML.trim().length > 0) || b.querySelector('img')
          || /[\u2190-\u27bf\ud83c-\udbff]/.test(b.textContent)
          || /^\s*[{}\d]/.test(b.textContent);      // { } Facts, and the 6h/24h chips
        return !drawn && b.textContent.trim();
      }).map(b => b.id || b.textContent.trim().slice(0, 22));
      if (noIcon.length) {
        errors.push('command button(s) with no icon: ' + [...new Set(noIcon)].slice(0, 6).join(', '));
      }
      // The button in a locked card has to survive the polling behind it.
      // This tab asks for its lists once a second and every one of them is
      // refused while editing is locked; redrawing the note on each refusal
      // threw the button away between the press and the release, so the first
      // click did nothing and the second worked.
      try {
        const hold = w.LOCK.token;
        w.LOCK.token = null;
        w.LOCK.until = 0;
        w.APPROVALS.locked = true;
        w.paintApprovalsLocked();
        const live = d.getElementById('approvals-live');
        const first = live.querySelector('button');
        if (!first) {
          errors.push('the locked press list offers no way to unlock');
        } else {
          w.paintApprovalsLocked();
          w.paintApprovalsLocked();          // as three refusals would
          if (live.querySelector('button') !== first) {
            errors.push('the unlock button is replaced while the tab polls, so a click can miss it');
          }
        }
        w.LOCK.token = hold;
        w.LOCK.until = Date.now() / 1000 + 600;
        w.APPROVALS.locked = false;
        if (live) live.dataset.locked = '';
      } catch (e) { errors.push('the locked-card check itself failed: ' + e.message); }
      // The router's own list, joined with what the house knows. Drawn from
      // an answer shaped like the daemon's, so the sheet is checked without a
      // router to read.
      try {
        const now = Date.now() / 1000;
        w.drawRouterSheet({ok: true, list: 'ZigMon', read_in_ms: 37, carrying: [
          {address: '185.234.9.7', family: 'IPv4', ours: true, comment: 'zigmon: kept out',
           known: true, why: '5 in 10 min', how: 'the third time from this address: 24 h',
           since: now - 3600, left: 82800, hits: 14, auto: true, before: 2, from_proxy: true,
           score: 28, bar: 15,
           evidence: [{when: now - 100, kind: 'proxy-poking', words: 'a path that is not there',
                       detail: 'GET /.env'}],
           tried_since: [{when: now - 20, kind: 'shut-road', words: 'a road that is shut',
                          detail: 'POST /tap'}],
           story: [{ts: now - 3600, what: 'blocked', why: '5 in 10 min', by: 'by itself'}]},
          {address: '2a02:1:2::9/128', family: 'IPv6', ours: false, comment: 'theirs',
           known: false, evidence: [], story: []}],
          not_carried: [{address: '10.9.9.9', family: 'IPv4', known: true, why: 'by hand',
                         by: 'by hand', evidence: [], story: []}]});
        await wait(250);
        const cards = Array.from(d.querySelectorAll('.rtr .ak'));
        if (cards.length !== 3) errors.push('the router sheet drew ' + cards.length + ' of 3 cards');
        const marks = cards.map(c => Array.from(c.querySelectorAll('h4 .road'))
          .map(r => r.textContent).join(' '));
        if (!/carried/.test(marks[0] || '')) errors.push('an address on the router is not marked as carried');
        if (!/somebody else/.test(marks[1] || '')) errors.push("another hand's entry is not marked as theirs");
        if (!/not on the router/.test(marks[2] || '')) {
          errors.push('an address kept out here but not on the router is not marked');
        }
        if (!cards[0].querySelector('.proof .pl')) errors.push('the sheet shows no evidence at all');
        // and the two halves are told apart: what earned it, and what it has
        // tried since - one reads as the reason and the other must not
        const heads = Array.from(cards[0].querySelectorAll('.proof .ph')).map(x => x.textContent);
        if (!heads.some(h => /what earned it/.test(h))) {
          errors.push('the evidence is not labelled as what earned the block');
        }
        if (!cards[0].querySelector('.story .s')) errors.push('the sheet shows no story at all');
        // a router carrying a few hundred addresses is a sheet nobody can
        // read: a box to narrow it, and the country beside each address
        const rfind = d.querySelector('#attnbody input');
        if (!rfind) {
          errors.push('the router sheet has no box to filter it with');
        } else {
          const seen = () => d.querySelectorAll('#attnbody .ak').length;
          const was = seen();
          rfind.value = 'nonsense-nothing-matches';
          rfind.oninput();
          if (seen() !== 0) errors.push('a filter matching nothing still shows router cards');
          rfind.value = '';
          rfind.oninput();
          if (seen() !== was) errors.push('clearing the router filter does not bring them back');
        }
        if (!cards[0].querySelector('.cflag')) {
          errors.push('the router sheet says no country beside an address');
        }
        if (!heads.some(h => /since it was kept out/.test(h))) {
          errors.push('what it tried after being kept out is not told apart from the reason');
        }
        const fields = Array.from(cards[0].querySelectorAll('.cell b')).map(b => b.textContent);
        ['why that long', 'kept out before', 'on its account now'].forEach(need => {
          if (fields.indexOf(need) < 0) errors.push('the router sheet leaves out "' + need + '"');
        });
        const close = d.getElementById('attnclose');
        if (close) close.click();
        await wait(200);
      } catch (e) { errors.push('the router-sheet check itself failed: ' + e.message); }
      // Every kind of message the house sends, on one sheet: the categories
      // the daemon offers, where each goes, and an example of each. A sheet
      // that lists a kind without showing one is a list of names.
      try {
        d.querySelector('#control-nav button[data-sec="alerts"]').click();
        await wait(1200);
        // one button per road as well as the one that tries them all: sending
        // down everything tells you something arrived, not which one did not
        ['notify-test', 'notify-test-ntfy', 'notify-test-telegram'].forEach(id => {
          const b = d.getElementById(id);
          if (!b) errors.push('there is no ' + id + ' button');
          else if (!b.querySelector('svg')) errors.push(id + ' has no icon');
        });
        const roads = ((w.STATE.status || {}).notify || {}).channels || [];
        const ntfyBtn = d.getElementById('notify-test-ntfy');
        if (ntfyBtn && ntfyBtn.disabled !== (roads.indexOf('ntfy') < 0)) {
          errors.push('the ntfy test button does not follow whether ntfy is set up');
        }
        const perKind = d.querySelectorAll('#notify-systems .notify-sys').length;
        if (perKind < 15) errors.push('only ' + perKind + ' kinds may take a road of their own');
        d.getElementById('notify-sheet').click();
        await wait(600);
        // the first sheet is the kinds; the second, when there is one, is what
        // was written by hand under Messages
        const allSheets = d.querySelectorAll('#attnbody .alertsheet');
        const cards = Array.from(allSheets[0] ? allSheets[0].querySelectorAll('.ak') : []);
        if (cards.length !== perKind) {
          errors.push('the sheet shows ' + cards.length + ' kinds and the card offers ' + perKind);
        }
        const noExample = cards.filter(c => !c.querySelector('.eg'));
        if (noExample.length) {
          errors.push(noExample.length + ' kind(s) on the sheet show no example: '
            + noExample.slice(0, 3).map(c => c.querySelector('h4').textContent).join(', '));
        }
        const blocked = cards.find(c => /address kept out/i.test(c.querySelector('h4').textContent));
        if (!blocked) errors.push('an address being kept out is not a kind of its own');
        // the ones written by hand under Messages belong on it too: they carry
        // their own words, their own level and their own roads
        const sheets = d.querySelectorAll('#attnbody .alertsheet');
        const written = (w.STATE.status || {}).messages || [];
        if (written.length && sheets.length < 2) {
          errors.push('the sheet leaves out the ' + written.length + ' alert(s) written by hand');
        }
        if (sheets.length > 1 && sheets[1].querySelectorAll('.ak').length !== written.length) {
          errors.push('the sheet shows ' + sheets[1].querySelectorAll('.ak').length
            + ' hand-written alert(s) and there are ' + written.length);
        }
        const close = d.getElementById('attnclose');
        if (close) close.click();
        await wait(200);
      } catch (e) { errors.push('the alert-sheet check itself failed: ' + e.message); }
      // The ladder is built from its steps rather than typed: a box to type a
      // list into is a box to make a mistake in, and one comma out of place
      // is a house that keeps somebody out for a thousand days.
      try {
        const rung = Array.from(d.querySelectorAll('#settings-grid .set-item'))
          .find(i => i.querySelector('[data-k="block_ladder"]'));
        if (!rung) {
          errors.push('the ladder is not on the settings card');
        } else {
          const field = rung.querySelector('[data-k="block_ladder"]');
          if (field.tagName === 'INPUT' && field.type !== 'hidden') {
            errors.push('the ladder is a box to type a list into');
          }
          const preset = rung.querySelector('select');
          if (!preset || preset.options.length < 4) {
            errors.push('the ladder offers no presets');
          } else {
            preset.value = '10, 60, 1440, forever';
            preset.onchange();
            await wait(150);
            if (field.value !== '10, 60, 1440, forever') {
              errors.push('choosing a preset wrote ' + JSON.stringify(field.value));
            }
            if (rung.querySelectorAll('.ladder-row').length !== 4) {
              errors.push('the ladder drew ' + rung.querySelectorAll('.ladder-row').length
                + ' of 4 steps');
            }
            const add = rung.querySelector('.btnrow button');
            if (add && !add.disabled) {
              errors.push('a step can be added after "for good", which cannot happen');
            }
            // the settings a ladder takes over say so rather than sitting there
            // looking as though they still applied
            const stillOn = ['block_minutes', 'block_minutes_serious', 'block_repeat', 'block_mode']
              .filter(function (k) {
                const box = d.querySelector('#settings-grid [data-k="' + k + '"]');
                return box && !box.closest('.set-item').classList.contains('idle');
              });
            if (stillOn.length) {
              errors.push('with a ladder set, ' + stillOn.join(', ') + ' still read as in use');
            }
            // "for good" in the middle ends the ladder there
            preset.value = '60, 1440, 10080, forever';
            preset.onchange();
            await wait(120);
            const second = rung.querySelectorAll('.ladder-row select')[1];
            second.value = '0';
            second.onchange();
            await wait(120);
            if (field.value !== '60, forever') {
              errors.push('"for good" in the middle left steps after it: ' + field.value);
            }
            preset.value = '';
            preset.onchange();
            await wait(150);
            // it may still be idle for a broader reason - the whole of the
            // blocking switched off, say - but not for the ladder's
            const why = (d.querySelector('#settings-grid [data-k="block_minutes"]')
              .closest('.set-item').querySelector('.idle-note') || {}).textContent || '';
            if (/ladder/.test(why)) {
              errors.push('with no ladder, the lengths still say they are taken over by one');
            }
            // ...and the same everywhere else: a setting another one has
            // taken over says which one, rather than sitting there looking
            // exactly like a setting that is doing something.
            const marked = Array.from(d.querySelectorAll('#settings-grid .set-item.idle'));
            if (marked.length < 10) {
              errors.push('only ' + marked.length + ' setting(s) say they are being ignored; '
                + 'the rest of the card cannot all be in use');
            }
            const speechless = marked.filter(i => !(i.querySelector('.idle-note') || {}).textContent);
            if (speechless.length) {
              errors.push(speechless.length + ' setting(s) are dimmed without saying why');
            }
            // A switch is a checkbox, and a checkbox's value is the word "on"
            // whether it is ticked or not - so every rule that asked whether
            // a switch was off read NaN, answered yes, and marked a whole
            // card as unused while it was plainly working.
            const swOn = Array.from(d.querySelectorAll('#settings-grid [data-bool]'))
              .filter(b => b.checked);
            const wronglyIdle = swOn.map(b => b.closest('.set-item'))
              .filter(i => i.classList.contains('idle'))
              .map(i => (i.querySelector('[data-k]') || {}).dataset.k);
            if (wronglyIdle.length) {
              errors.push(wronglyIdle.length + ' switch(es) are on and marked as not used: '
                + wronglyIdle.slice(0, 4).join(', '));
            }
            // and the ones a switched-on master governs are in use with it
            ['weather', 'backup_enabled', 'binding_watch'].forEach(master => {
              const box = d.querySelector('#settings-grid [data-k="' + master + '"]');
              if (!box || !box.checked) return;
              const kin = {weather: 'weather_name', backup_enabled: 'backup_time',
                           binding_watch: 'binding_mend'}[master];
              const item = d.querySelector('#settings-grid [data-k="' + kin + '"]');
              if (item && item.closest('.set-item').classList.contains('idle')) {
                errors.push(kin + ' reads as unused while ' + master + ' is on');
              }
            });
            // switching the whole of the blocking off takes over all of it
            // a switch is turned off by unticking it, not by setting a value
            const master = d.querySelector('#settings-grid [data-k="blacklist"]');
            const was = master.checked;
            master.checked = false;
            w.applySettingsWhen();
            await wait(100);
            const score = d.querySelector('#settings-grid [data-k="block_score"]')
              .closest('.set-item');
            if (!score.classList.contains('idle')) {
              errors.push('with addresses not kept out at all, what earns a block still reads as in use');
            }
            master.checked = was;
            w.applySettingsWhen();
          }
        }
      } catch (e) { errors.push('the ladder check itself failed: ' + e.message); }
      // Every settings item is three bands - label, control, note - so a
      // second line of label, or a note about being taken over, moves only
      // itself. As a flex column, anything added to an item pushed its box
      // up and left the boxes in one row at four different heights.
      try {
        const css = Array.from(d.querySelectorAll('style')).map(x => x.textContent).join('');
        if (css.indexOf('#settings-grid .set-grid > .set-item{display:grid;grid-template-rows:subgrid') < 0) {
          errors.push('the settings items are not laid out in bands, so a note moves its neighbours');
        }
        // every part named to a band, rather than left to the order it was
        // added in - and the switch in the second band, beside the boxes,
        // not up at the label line
        [['> .set-item > label{grid-row:1', 'the label is not pinned to the first band'],
         ['> .set-item > .idle-note{grid-row:3', 'the note is not pinned to the third band'],
         ['.set-bool > .sw{grid-row:2', 'a switch does not sit in the band the boxes are in'],
         ['.set-bool > .idle-note{grid-row:3;grid-column:1/-1', 'a note on a switch row does not span it'],
         ['> .set-head{grid-column:1/-1;grid-row:span 1', 'a section heading is not a band of its own']
        ].forEach(function (pair) {
          if (css.indexOf(pair[0]) < 0) errors.push(pair[1]);
        });
        const crowded = Array.from(d.querySelectorAll('#settings-grid .set-item'))
          .filter(i => i.children.length > 3);
        if (crowded.length) {
          errors.push(crowded.length + ' settings item(s) have more than three parts, which the '
            + 'three bands cannot hold: '
            + crowded.slice(0, 3).map(i => (i.querySelector('[data-k]') || {dataset: {}}).dataset.k).join(', '));
        }
        // a tall thing takes a line of its own: sharing a row with short
        // boxes stretches their bands to its height and leaves their notes
        // stranded half a screen below the box they are about
        if (css.indexOf('.set-item.set-tall{grid-column:1/-1') < 0) {
          errors.push('a tall setting shares its row, which strands its neighbours\' notes');
        }
        const tall = d.querySelector('#settings-grid .set-item.set-tall');
        if (!tall) errors.push('nothing on the card is marked as tall, so the ladder shares a row');
        // Things that belong together are in a cluster of their own, so a
        // stream of boxes cannot wrap a user onto one line and its password
        // onto the next with something else in between.
        const clusters = Array.from(d.querySelectorAll('#settings-grid .set-cluster'));
        if (clusters.length < 25) {
          errors.push('only ' + clusters.length + ' cluster(s); sections have gone back to one stream');
        }
        // not one setting left loose in a section: a loose one is in the
        // section's own stream, which wraps wherever the width runs out
        const strays = [];
        Array.from(d.querySelectorAll('#settings-grid .set-grid')).forEach(g => {
          Array.from(g.children).filter(c => c.classList.contains('set-item')).forEach(c => {
            strays.push((c.querySelector('[data-k]') || {dataset: {}}).dataset.k || '?');
          });
        });
        if (strays.length) {
          errors.push(strays.length + ' setting(s) are not in any cluster: ' + strays.slice(0, 5).join(', '));
        }
        const keysIn = c => Array.from(c.querySelectorAll('[data-k]')).map(b => b.dataset.k);
        const together = [['proxy_user', 'proxy_password'], ['proxy_log', 'proxy_error_log'],
                          ['ntfy_log', 'ntfy_error_log'], ['ntfy_own_log', 'ntfy_ban_log'],
                          ['ntfy_watch', 'ntfy_log'], ['ntfy_own_watch', 'ntfy_ban_log']];
        together.forEach(pair => {
          const home = clusters.find(c => keysIn(c).indexOf(pair[0]) >= 0);
          if (!home || keysIn(home).indexOf(pair[1]) < 0) {
            errors.push(pair[0] + ' and ' + pair[1] + ' are not in the same cluster');
          }
        });
      } catch (e) { errors.push('the bands check itself failed: ' + e.message); }
      // An ntfy address is a server, a topic and whichever credentials that
      // server wants. Typed as one line it is the colons and the at-sign that
      // get put in the wrong place, once, and are then not found.
      try {
        const round = [
          ['https://ntfy.sh/plain-topic', 'public'],
          ['https://:tk_abc123@ntfy.falco81.net/zigmon-house', 'token'],
          ['https://falco:a%40b@ntfy.falco81.net/zigmon-house', 'login']
        ];
        round.forEach(pair => {
          const p = w.ntfyParts(pair[0]);
          if (p.mode !== pair[1]) errors.push(pair[0] + ' was read as ' + p.mode);
          if (w.ntfyJoin(p) !== pair[0]) {
            errors.push('taking ' + pair[0] + ' apart and back gave ' + w.ntfyJoin(p));
          }
        });
        if (w.ntfyJoin({mode: 'public', base: 'https://x', topic: ''}) !== '') {
          errors.push('half an address is saved as though it were whole');
        }
        const nt = Array.from(d.querySelectorAll('#settings-grid .set-item'))
          .find(i => i.querySelector('[data-k="notify_ntfy"]'));
        if (!nt) {
          errors.push('the ntfy address is not on the settings card');
        } else {
          const field = nt.querySelector('[data-k="notify_ntfy"]');
          if (field.tagName === 'INPUT' && field.type !== 'hidden') {
            errors.push('the ntfy address is still one box to type a URL into');
          }
          const sel = nt.querySelector('select');
          const shown = () => Array.from(nt.querySelectorAll('.compose-row label'))
            .map(l => l.textContent).join('|');
          sel.value = 'token';
          sel.onchange();
          await wait(80);
          if (!/token/i.test(shown()) || /password/i.test(shown())) {
            errors.push('the token choice shows the wrong boxes: ' + shown());
          }
          sel.value = 'login';
          sel.onchange();
          await wait(80);
          if (!/user/i.test(shown()) || !/password/i.test(shown()) || /token/i.test(shown())) {
            errors.push('the user choice shows the wrong boxes: ' + shown());
          }
          sel.value = 'public';
          sel.onchange();
          await wait(80);
          if (/token|password/i.test(shown())) {
            errors.push('the public choice still asks for credentials: ' + shown());
          }
        }
      } catch (e) { errors.push('the ntfy address check itself failed: ' + e.message); }
      // A panel holds values nobody chose the length of - a list of
      // addresses, a key, a path - and without a rule to break them they run
      // out the side of the box and over whatever is behind it.
      try {
        const sheet = Array.from(d.querySelectorAll('style'))
          .map(x => x.textContent).join('\n');
        const rule = function (selector) {
          const at = sheet.indexOf(selector);
          if (at < 0) return '';
          return sheet.slice(at, sheet.indexOf('}', at));
        };
        [['.sethelp{', 'the help panel'], ['#attnbody, #attnbody *', 'a dialogue']].forEach(function (pair) {
          const body = rule(pair[0]);
          if (!/overflow-wrap|word-break/.test(body)) {
            errors.push(pair[1] + ' has no rule for a word that does not fit');
          }
        });
        if (!/max-width:min\(/.test(rule('.sethelp{'))) {
          errors.push('the help panel can be wider than a narrow window');
        }
      } catch (e) { errors.push('the wrapping check itself failed: ' + e.message); }
      // A setting's words are escaped as text, which is right - that is how a
      // value with a bracket in it stays a value. A few were written with a
      // little markup in them and appeared as markup; three harmless tags are
      // let back in afterwards, and nothing else is.
      try {
        const dressed = w.richText('the list <code>10, 60</code> or <i>forever</i>');
        if (dressed.indexOf('<code>') < 0 || dressed.indexOf('<i>') < 0) {
          errors.push('the help panel shows its own markup as words: ' + dressed);
        }
        const nasty = w.richText('a <script>alert(1)</script> and <img src=x onerror=1>');
        if (nasty.indexOf('<script') >= 0 || nasty.indexOf('<img') >= 0) {
          errors.push('the help panel lets a tag through that is not on the list: ' + nasty);
        }
        const spotted = Array.from(d.querySelectorAll('.sethelp, #attnbody'))
          .map(n => n.textContent).join(' ');
        if (/<(code|i|b|br)>/.test(spotted)) {
          errors.push('a panel is showing a tag as text rather than drawing it');
        }
      } catch (e) { errors.push('the markup check itself failed: ' + e.message); }
      // The shield already means the router is carrying an address. A second
      // meaning on the same mark is worse than no mark - it becomes a mark
      // that has to be asked about - so a list somebody else keeps has one of
      // its own.
      try {
        const page = Array.from(d.querySelectorAll('script')).map(x => x.textContent).join('');
        if (/from_feed \? ' \\ud83d\\udee1/.test(page) || /from_feed\).*udee1/.test(page)) {
          errors.push('a list is marked with the shield, which already means the router carries it');
        }
      } catch (e) { errors.push('the mark check itself failed: ' + e.message); }
      // A label's "for" must name a form element. Five of ours named a span
      // that a switch is drawn into, or an id that is on nothing at all: the
      // browser cannot tie them together, clicking the word does nothing, and
      // a screen reader reads the two as unrelated. Chrome says so in Issues.
      try {
        const FIELDS = 'input,select,textarea,button,meter,output,progress,fieldset';
        const wrong = Array.from(d.querySelectorAll('label[for]')).filter(l => {
          const target = d.getElementById(l.htmlFor);
          return !target || !target.matches(FIELDS);
        });
        if (wrong.length) {
          errors.push(wrong.length + ' label(s) point at something that is not a form field: '
            + wrong.slice(0, 3).map(l => l.htmlFor).join(', '));
        }
      } catch (e) { errors.push('the label check itself failed: ' + e.message); }
      // One kind of explanation, not two. A title left on an element shows the
      // browser's own white box on top of the page's dark one, saying the
      // same thing in a different face - which is what somebody sees.
      try {
        // the page sweeps titles away on a slow beat; a walk that lands
        // between two beats saw whatever was set in that moment, and the
        // check failed for the timing rather than for a fault
        if (w.explainLongTitles) w.explainLongTitles(d);
        const stillTitled = Array.from(d.querySelectorAll('[title]'))
          .filter(n => String(n.getAttribute('title') || '').trim());
        if (stillTitled.length) {
          errors.push(stillTitled.length + ' element(s) still show the browser\'s own tooltip: '
            + stillTitled.slice(0, 3).map(n => n.tagName.toLowerCase() + ' "'
              + String(n.title).slice(0, 28) + '"').join(', '));
        }
        const explained = d.querySelectorAll('[data-explains]');
        if (explained.length < 100) {
          errors.push('only ' + explained.length + ' element(s) explain themselves; the sweep '
            + 'is not reaching the page');
        }
        // and what a screen reader is left with
        const first = explained[0];
        if (first && !first.getAttribute('aria-label')) {
          errors.push('taking the title away left nothing for a screen reader');
        }
      } catch (e) { errors.push('the one-kind-of-tooltip check itself failed: ' + e.message); }
      // Every mark in the Public API section answers the pointer in the same
      // words as the rest of the page. A mark nobody can read is a mark that
      // has to be asked about.
      try {
        const wasApprovals = w.APPROVALS;
        w.APPROVALS = {
          waiting: [{link: 'Osoby', what: 'tell you something', who: '89.24.5.7',
                     left: 60, ticket: 't1'}],
          recent: [{ts: 1, state: 'done', link: 'Osoby', what: 'x', way: 'by a header',
                    factor: 'Duo', device: 'iPhone16', who: '192.168.40.170', country: 'CZ'},
                   {ts: 2, state: 'refused', link: 'Svetla', what: 'x', way: 'by its address',
                    factor: 'none', who: '45.9.148.9', country: 'NL'}],
          matched: 2, total: 2, blocked: [], blockedPast: [], blocklistOn: true};
        if (w.paintApprovals) w.paintApprovals(true);
        // ...and every kind of row the whole tab can show, at once: the
        // blocked lists both ways, the counters, the story, the presses
        w.APPROVALS.blocklistOn = true;
        w.APPROVALS.blocked = [
          {ip: '77.90.185.226', why: 'x', since: 1, hits: 1, forever: true, auto: true, left: 0,
           on_feeds: ['firehol1'], from_feed: 'firehol1', country: 'DE', router: 'yes'},
          {ip: '1.1.1.1', why: 'added by hand', since: 1, hits: 1, left: 600, auto: false,
           country: 'AU', router: 'no', router_trouble: 'x', from_proxy: true},
          {ip: '192.168.40.5', why: 'x', since: 1, hits: 1, left: 600, auto: true, spared: 'the house'}];
        w.APPROVALS.counters = [
          {ip: '5.5.5.5', score: 9, bar: 15, tries: 3, spread: 2, last: 1, from_proxy: true,
           kinds: [{kind: 'proxy-poking', n: 3, words: 'w'}]}];
        w.APPROVALS.blockedPast = [
          {ts: 1, ip: '77.90.185.226', what: 'blocked', why: 'x (seen at the server in front)',
           by: '', auto: 1, country: 'DE', from_feed: 'firehol1'},
          {ts: 2, ip: '6.6.6.6', what: 'blocked', why: 'x (seen at the notification server)',
           by: '', auto: 1},
          {ts: 3, ip: '1.1.1.1', what: 'let back in', why: 'taken off', by: '192.168.40.12', auto: 0}];
        w.BLOCKSTORY.total = 3;
        w.paintBlocked(true);
        if (w.paintWatched) w.paintWatched();
        Array.from(d.querySelectorAll('#blocked-list .listed-head')).forEach(h => h.click());
        const tab = d.getElementById('tab-approvals');
        const shutAgain = () => { if (w.FOLDS) Object.keys(w.FOLDS).forEach(k => { w.FOLDS[k].open = false; }); };
        const marks = Array.from(tab.querySelectorAll('.appr-icon, .cflag, .road'))
          .filter(m => m.textContent.trim());
        if (marks.length < 20) errors.push('the Public API tab draws only ' + marks.length + ' marks');
        const silent = marks.filter(m => !(m.dataset.explains || m.querySelector('[data-explains]')));
        if (silent.length) {
          errors.push(silent.length + ' mark(s) on the Public API tab say nothing to the pointer: '
            + silent.slice(0, 4).map(m => JSON.stringify(m.textContent.slice(0, 12))).join(' '));
        }
        shutAgain();
        w.APPROVALS = wasApprovals;
        if (w.paintApprovals) w.paintApprovals(true);
        w.paintBlocked(true);
      } catch (e) { errors.push('the Public API marks check itself failed: ' + e.message); }
      const wasFetch = w.fetch;
      // Two views hold addresses, so the daemon refuses them without the PIN.
      // The tab asked for them twice a second anyway, locked or not - 1,754
      // refusals from one browser in an afternoon, 594 in the worst hour, and
      // nothing on the screen either way.
      try {
        const wasToken = w.LOCK.token;
        const wasUntil = w.LOCK.until;
        let asked = [];
        // the request is counted and answered here, not let out: a real one
        // lands later and repaints over whatever the next check has set up,
        // which is how this walk started failing in a place it does not touch
        w.fetch = (u, o) => {
          const where = String(u);
          if (/api=(blocked|approvals)/.test(where)) {
            asked.push(where);
            return Promise.resolve({ok: true, status: 200,
                                    json: () => Promise.resolve({ok: true}),
                                    text: () => Promise.resolve('{"ok":true}')});
          }
          return wasFetch(u, o);
        };
        w.LOCK.token = null;
        w.LOCK.until = 0;
        w.APPROVALS.refused = false;
        asked = [];
        for (let i = 0; i < 5; i++) w.loadApprovals(true);
        if (asked.length > 2) {
          errors.push('locked, the tab asked ' + asked.length + ' times for views that are refused');
        }
        w.LOCK.token = wasToken;
        w.LOCK.until = wasUntil;
        w.APPROVALS.refused = false;
        if (w.isUnlocked()) {
          asked = [];
          w.loadApprovals(true);
          w.loadApprovals(true);
          if (asked.length < 4) {
            errors.push('unlocked, the tab stopped asking for them altogether');
          }
        }
        w.fetch = wasFetch;
      } catch (e) {
        errors.push('the locked-polling check itself failed: ' + e.message);
      } finally {
        if (w.fetch !== wasFetch) w.fetch = wasFetch;
      }
      // A search that matches nothing must not take the search box away with
      // it: emptying the whole section on an empty answer left somebody
      // looking at a blank card with no way to clear what they had typed.
      try {
        const wasApprovals = w.APPROVALS;
        const wasText = w.BLOCKSTORY.text;
        w.APPROVALS = {blocked: [], blocklistOn: true, blockedPast: [
          {ts: 1, ip: '89.24.5.7', what: 'blocked', why: 'a wrong secret', by: ''}]};
        w.BLOCKSTORY.total = 1;
        w.BLOCKSTORY.text = '';
        w.paintBlocked(true);
        const box = () => d.querySelector('#blocked-past input[type=search]');
        if (!box()) errors.push('the story has no box to search it with');
        w.BLOCKSTORY.text = 'nonsense';
        w.APPROVALS.blockedPast = [];
        w.paintBlocked(true);
        if (!box()) {
          errors.push('a search matching nothing takes the search box away with it');
        } else if (box().value !== 'nonsense') {
          errors.push('the box forgot what was typed into it');
        }
        if (!d.querySelector('#blocked-past .btnhelp')) {
          errors.push('a search matching nothing says nothing at all');
        }
        w.BLOCKSTORY.text = wasText;
        w.APPROVALS = wasApprovals;
        w.paintBlocked(true);
      } catch (e) { errors.push('the story search check itself failed: ' + e.message); }
      // The ones somebody else's list already knew go into a fold of their
      // own, shut to begin with: there will be a great many of them in time,
      // and a long list of them buries the handful that are here for what
      // they did here.
      try {
        const many = [];
        for (let i = 0; i < 60; i++) {
          many.push({ip: '45.9.148.' + i, why: '1 in 10 min', since: 1, hits: 1, forever: true,
                     on_feeds: i % 3 === 0 ? ['firehol1', 'blocklist_de'] : ['firehol1'],
                     from_feed: 'firehol1', country: i % 2 ? 'NL' : 'CZ', auto: true, left: 0});
        }
        many.push({ip: '89.24.9.9', why: 'a wrong secret', since: 1, hits: 2, left: 600, auto: true});
        const wasApprovals = w.APPROVALS;
        w.APPROVALS = {blocked: many, blockedPast: [], blocklistOn: true};
        w.paintBlocked(true);
        const host = d.getElementById('blocked-list');
        const loose = Array.from(host.children).filter(c => c.classList.contains('appr-row')).length;
        if (loose !== 0) {
          errors.push(loose + ' row(s) loose on the card; every one belongs in one of the two folds');
        }
        const fold = host.querySelector('.listed-fold');
        if (!fold) throw new Error('the ones on a list are not folded away');
        if (!fold.querySelector('.listed-body').hidden) {
          errors.push('the fold is open to begin with');
        }
        fold.querySelector('.listed-head').click();
        const inside = () => fold.querySelectorAll('.listed-body .appr-row').length;
        if (inside() !== 25) errors.push('a page of the fold holds ' + inside() + ' rather than 25');
        // the same marks on a blocked row as anywhere else: the book for a
        // list, and the country. Both were written into the counters list and
        // never into this one - two renderers, one of them missed.
        const first = fold.querySelector('.listed-body .appr-row');
        const marks = Array.from(first.querySelectorAll('.appr-icon')).map(x => x.textContent).join('');
        if (marks.indexOf('\ud83d\udcd5') < 0) {
          errors.push('a blocked row on a list does not wear the book: ' + marks);
        }
        if (!first.querySelector('.cflag') || !first.querySelector('.cflag').textContent) {
          errors.push('a blocked row does not say which country it is in');
        }
        if (fold.querySelector('.listed-head').textContent.indexOf('Blacklisted IPs') < 0) {
          errors.push('the fold is not called what it holds');
        }
        // two folds of the same shape: what a list knew, and what this house
        // decided on its own. Both get a filter and pages.
        const folds = Array.from(d.querySelectorAll('.listed-fold'));
        const names = folds.map(f => f.querySelector('.listed-head').textContent);
        if (!names.some(n => /Blocked by system/.test(n))) {
          errors.push('there is no fold for the ones this house decided about itself');
        }
        folds.forEach(f => {
          if (!f.querySelector('input')) {
            errors.push('a fold has no box to filter it with: '
              + f.querySelector('.listed-head').textContent.slice(0, 30));
          }
        });
        // and the country sits in a column of its own in the story, rather
        // than tacked on to a cell whose text is a different width every row
        // the story's marks sit in fixed slots too: five on every row, filled
        // or not, so a column of them reads down the page
        const storyRows = Array.from(d.querySelectorAll('#blocked-past tbody tr'));
        const storyCounts = new Set(storyRows.map(
          r => (r.querySelector('.story-marks') || {children: []}).children.length));
        if (storyRows.length && (storyCounts.size > 1 || !storyCounts.has(5))) {
          errors.push('the story rows carry ' + Array.from(storyCounts).join(' and ')
            + ' mark slots; they want five each');
        }
        const heads = d.querySelectorAll('#blocked-past thead th').length;
        const row = d.querySelector('#blocked-past tbody tr');
        if (row && row.children.length !== heads) {
          errors.push('the story table has ' + heads + ' headings and ' + row.children.length
            + ' cells, so nothing under them lines up');
        }
        const find = fold.querySelector('input');
        find.value = 'blocklist_de';
        find.oninput();
        if (inside() !== 20) errors.push('filtering by a list name gives ' + inside() + ' of 20');
        find.value = 'nonsense';
        find.oninput();
        if (inside() !== 0) errors.push('a filter matching nothing still shows rows');
        find.value = '';
        find.oninput();
        if (inside() !== 25) errors.push('clearing the filter does not bring the page back');
        w.APPROVALS = wasApprovals;
        w.paintBlocked(true);
      } catch (e) { errors.push('the listed-fold check itself failed: ' + e.message); }
      // an escape written into an HTML attribute is five characters of
      // nonsense, not a dash: the box to ask about an address said
      // "ask about one address \u2014 45.9.148.9" in so many letters
      try {
        const boxes = ['look-ip', 'wifi-seen-find', 'blocked-ip'];
        boxes.forEach(id => {
          const b = d.getElementById(id);
          if (b && /\\u[0-9a-f]{4}/i.test(b.placeholder || '')) {
            errors.push(id + ' shows an escape in its placeholder: ' + b.placeholder);
          }
        });
        const visible = Array.from(d.querySelectorAll('input[placeholder], [title]'))
          .map(n => (n.placeholder || '') + ' ' + (n.title || '')).join(' ');
        const anywhere = visible.match(/\\u[0-9a-f]{4}/i);
        if (anywhere) errors.push('an escape is shown to somebody: ' + anywhere[0]);
      } catch (e) { errors.push('the placeholder check itself failed: ' + e.message); }
      // where an address was seen: the globe for anything read off the server
      // in front, the bell beside it for the notification server's own logs,
      // a house for what this machine saw itself
      try {
        const wasA = w.APPROVALS;
        w.APPROVALS = {blocklistOn: true, blockedPast: [], blocked: [
          {ip: '1.1.1.1', why: 'x', since: 1, hits: 1, forever: true, auto: true, from_proxy: true},
          {ip: '2.2.2.2', why: 'x', since: 1, hits: 1, forever: true, auto: true,
           from_proxy: true, from_ntfy: true},
          {ip: '3.3.3.3', why: 'a wrong secret', since: 1, hits: 1, left: 60, auto: true}]};
        w.paintBlocked(true);
        Array.from(d.querySelectorAll('#blocked-list .listed-head')).forEach(h => h.click());
        const marksOf = ip => {
          const row = Array.from(d.querySelectorAll('#blocked-list .appr-row'))
            .find(r => (r.querySelector('.appr-link') || {}).textContent === ip);
          return row ? Array.from(row.querySelectorAll('.appr-slot'))
            .map(x => x.textContent).join('') : '';
        };
        if (marksOf('1.1.1.1').indexOf('\ud83c\udf10') < 0) {
          errors.push('something read off the server in front wears no globe');
        }
        if (marksOf('2.2.2.2').indexOf('\ud83d\udd14') < 0
            || marksOf('2.2.2.2').indexOf('\ud83c\udf10') < 0) {
          errors.push('the notification server wants the globe AND the bell: ' + marksOf('2.2.2.2'));
        }
        if (marksOf('3.3.3.3').indexOf('\ud83c\udfe0') < 0) {
          errors.push('something this machine saw itself wears no house: ' + marksOf('3.3.3.3'));
        }
        if (marksOf('3.3.3.3').indexOf('\ud83c\udf10') >= 0) {
          errors.push('something seen here is marked as read off the server in front');
        }
        if (w.FOLDS) Object.keys(w.FOLDS).forEach(k => { w.FOLDS[k].open = false; });
        w.APPROVALS = wasA;
        w.paintBlocked(true);
      } catch (e) { errors.push('the where-it-was-seen check itself failed: ' + e.message); }
      // two letters into a flag, and a box to ask about one address
      try {
        if (w.flagOf('CZ') !== '\u{1F1E8}\u{1F1FF}') {
          errors.push('two letters do not become a flag: ' + w.flagOf('CZ'));
        }
        // the flag is a picture served from this house, with the two letters
        // beside it - so it looks the same everywhere and needs no internet
        const badge = w.countryBadge('CZ');
        const pic = badge.querySelector('img');
        if (!pic) errors.push('a country badge carries no picture');
        else if (!/^flags\/[a-z]{2}\.svg$/.test(pic.getAttribute('src'))) {
          errors.push('the flag picture is fetched from somewhere other than this house: '
            + pic.getAttribute('src'));
        }
        if (!badge.querySelector('.cflag-cc')) errors.push('a badge has no letters beside the picture');
        if (w.flagOf('') !== '' || w.flagOf('nonsense') !== '') {
          errors.push('something that is not two letters was turned into a flag');
        }
        if (!d.getElementById('look-ip') || !d.getElementById('look-go')) {
          errors.push('there is nowhere to ask about one address');
        }
        // the flag is a picture served from this house, with the two letters
        // beside it - so it looks the same everywhere and needs no internet
        const czBadge = w.countryBadge('CZ');
        const czPic = czBadge.querySelector('img');
        if (!czPic) errors.push('a country badge carries no picture');
        else if (!/^flags\/[a-z]{2}\.svg$/.test(czPic.getAttribute('src'))) {
          errors.push('the flag picture is fetched from somewhere other than this house: '
            + czPic.getAttribute('src'));
        }
        if (!czBadge.querySelector('.cflag-cc')) errors.push('a badge has no letters beside the picture');
        // every blocked row has the same number of mark slots, filled or not,
        // so the addresses start at the same place down the page
        const rowsWithMarks = Array.from(d.querySelectorAll('#blocked-list .appr-row'));
        const counts = new Set(rowsWithMarks.map(r => r.querySelectorAll('.appr-slot').length));
        if (rowsWithMarks.length && counts.size > 1) {
          errors.push('the rows have ' + Array.from(counts).join(' and ')
            + ' mark slots, so the addresses do not line up');
        }
        rowsWithMarks.forEach(r => {
          if (!r.querySelector('.appr-marks')) {
            errors.push('a blocked row draws its marks loose rather than in slots');
          }
        });
      } catch (e) { errors.push('the flag check itself failed: ' + e.message); }
      // the filter over what the air has been heard to carry
      try {
        const heard = [
          {ssid: 'UPC1234567', bssid: 'aa:bb:cc:00:11:22', band: 5, channel: 36,
           security: 'WPA2', best: -61, times: 12, first: 1, last: 2},
          {ssid: 'Sousedi_2G', bssid: 'aa:bb:cc:00:11:33', band: 2.4, channel: 6,
           security: 'WPA2/WPA3', best: -77, times: 3, first: 1, last: 2},
          {ssid: '', bssid: 'de:ad:be:ef:00:01', band: 5, channel: 100,
           security: 'open', best: -88, times: 1, first: 1, last: 2}
        ];
        w.WIFI_SEEN_OPEN = true;
        w.paintWifiSeen(heard);
        const box = d.getElementById('wifi-seen-find');
        if (!box) throw new Error('there is nowhere to type a filter');
        const shown = () => d.querySelectorAll('#wifi-seen .oth-row:not(.head)').length;
        const type = t => { box.value = t; box.oninput(); };
        if (shown() !== 3) errors.push('the history does not draw what it was given');
        type('upc');
        if (shown() !== 1) errors.push('a filter in the wrong case finds nothing: ' + shown());
        type('WPA2 2.4');
        if (shown() !== 1) errors.push('two words are not both required: ' + shown());
        type('de:ad');
        if (shown() !== 1) errors.push('a BSSID is not matched: ' + shown());
        type('nonsense');
        if (shown() !== 0) errors.push('a filter matching nothing still shows rows');
        type('');
        if (shown() !== 3) errors.push('clearing the filter does not bring them back');
        w.WIFI_SEEN_OPEN = false;
      } catch (e) { errors.push('the wifi filter check itself failed: ' + e.message); }
      // Settings: a label of a few words, and the long word under the pointer
      // with the key it has in config.json and whether the file is what is
      // running. A label that runs to a paragraph is the page doing the
      // tooltip's job.
      try {
        d.querySelector('#control-nav button[data-sec="system"]').click();
        await wait(900);
        const setItems = Array.from(d.querySelectorAll('#settings-grid .set-item'));
        if (setItems.length < 50) errors.push('the settings drew only ' + setItems.length + ' items');
        const tooLong = setItems
          .map(i => ((i.querySelector('label') || {}).textContent || ''))
          .filter(l => l.length > 60);
        if (tooLong.length) {
          errors.push(tooLong.length + ' setting label(s) longer than a label should be: '
            + tooLong[0].slice(0, 40));
        }
        const heads = Array.from(d.querySelectorAll('#settings-grid .set-head')).map(h => h.textContent.trim());
        const asKey = heads.filter(h => /^[a-z_]+$/.test(h));
        if (asKey.length) errors.push('a settings section is headed by a key name: ' + asKey.join(', '));
        const probe = setItems.find(i => i.querySelector('[data-k="stale_warn_min"]'));
        if (!probe) {
          errors.push('a known setting is not on the page');
        } else {
          probe.onmouseenter();
          await wait(100);
          const tip = d.querySelector('.sethelp');
          if (!tip || tip.style.display !== 'block') errors.push('no popup on a setting');
          else if (tip.textContent.indexOf('stale_warn_min') < 0
                   || tip.textContent.indexOf('config.json') < 0) {
            errors.push('the popup does not name the key in config.json');
          }
          probe.onmouseleave();
        }
      } catch (e) { errors.push('the settings check itself failed: ' + e.message); }
      // and the same panel everywhere else: anything carrying more than a
      // label's worth of title says it in the page's own words rather than in
      // the browser's tooltip, which waits a second and cannot be reached at
      // all on a touchscreen
      // the page sweeps titles away on a slow beat; a walk that lands between
      // two beats saw whatever was set in that moment, so it is swept here
      // first and the check is about faults rather than about timing
      if (w.explainLongTitles) w.explainLongTitles(d);
      const plainLong = Array.from(d.querySelectorAll('[title]'))
        .filter(n => !n.dataset.explains && String(n.title).length >= 55);
      if (plainLong.length) {
        errors.push(plainLong.length + ' long tooltip(s) left to the browser: '
          + String(plainLong[0].title).slice(0, 40));
      }
      if (d.querySelectorAll('[data-explains]').length < 30) {
        errors.push('almost nothing on the page carries the help panel');
      }
      // Every control, not only the buttons: a box, a switch, a dropdown, a
      // file picker. One that is wrapped by something already explained is
      // taken as explained - the panel opens over the whole row.
      // the named ones: a control with an id is a control somebody meant,
      // rather than one of hundreds drawn from a list
      await wait(300);                       // the sweep runs a moment after a drawing
      const bareControls = Array.from(d.querySelectorAll('[id]'))
        .filter(n => /^(input|textarea|select)$/i.test(n.tagName)
                  || (n.tagName === 'BUTTON' && n.classList.contains('btn')))
        .filter(n => !n.title && !n.dataset.explains
                  && !n.closest('[data-explains]')
                  && !n.closest('.tabs') && !n.closest('#control-nav'));
      if (bareControls.length > 8) {
        errors.push(bareControls.length + ' control(s) with nothing said about them, e.g. '
          + bareControls.slice(0, 3).map(n => (n.id || n.tagName.toLowerCase())).join(', '));
      }
      // a dropdown that says nothing at all: a list of names with no word
      // about what choosing one of them does
      const bareSelects = Array.from(d.querySelectorAll('select'))
        .filter(x => !x.title && !x.dataset.explains);
      if (bareSelects.length) {
        errors.push(bareSelects.length + ' dropdown(s) with nothing said about them: '
          + bareSelects.map(x => x.id || '(unnamed)').slice(0, 4).join(', '));
      }
      // and the buttons that do something a person might hesitate over
      ['blocked-clear', 'blocked-forget', 'db-prune', 'db-upload', 'backup-export-secrets',
       'stale-drop', 'reset-device-btn', 'join-toggle'].forEach(id => {
        const b = d.getElementById(id);
        if (b && !b.title && !b.dataset.explains) {
          errors.push('a button that cannot be undone says nothing about itself: ' + id);
        }
      });
      console.log('approvals: a tab of its own, %d waiting, %d button(s) all with icons',
        d.querySelectorAll('.appr-row').length, btns.length);
    }
  } catch (e) { errors.push('the approvals check itself failed: ' + e.message); }

  // ---- a secret is never written into its own box --------------------------
  // The daemon says only whether a secret is set, not what it is. Writing
  // what it says into the box put the word "true" there, and saving wrote
  // that word over the secret - every one of them, in four releases.
  try {
    d.querySelector('.tabs button[data-tab="control"]').click(); await wait(300);
    const sys1 = d.querySelector('#control-nav button[data-sec="system"]');
    if (sys1) { sys1.click(); await wait(1200); }
    const secrets = Array.from(d.querySelectorAll('#settings-grid input[type="password"][data-k]'));
    if (!secrets.length) errors.push('no secret is drawn in the settings at all');
    const filled = secrets.filter(b => b.value !== '').map(b => b.dataset.k);
    if (filled.length) errors.push('a secret is written into its own box: ' + filled.join(', '));
    if (secrets.some(b => !b.dataset.secret)) {
      errors.push('a secret box is not marked, so saving would send it as empty');
    }
    console.log('settings: %d secret(s), none of them written into its box', secrets.length);
  } catch (e) { errors.push('the secret-box check itself failed: ' + e.message); }

  // ---- a contract SIM has no credit, and is not asked about it -------------
  try {
    d.querySelector('.tabs button[data-tab="control"]').click(); await wait(300);
    const sys0 = d.querySelector('#control-nav button[data-sec="system"]');
    if (sys0) { sys0.click(); await wait(1200); }
    const was = (((w.STATE.status || {}).runtime_config || {}).sms_sim || {}).value || 'prepaid';
    const setSim = async kind => {
      await fetch(base + 'index.php?api=config-save', { method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: '1234', sms_sim: kind }) });
      w.forgetSig('sms'); w.tick(true); await wait(1400);
    };
    await setSim('prepaid');
    if (!d.getElementById('sms-f-sms_sim')) errors.push('the SMS card does not ask what kind of SIM it is');
    if (!d.getElementById('sms-f-sms_credit_code')) errors.push('a prepaid SIM is not asked for its credit code');
    await setSim('contract');
    if (d.getElementById('sms-f-sms_credit_code') || d.getElementById('sms-f-sms_credit_every_h')) {
      errors.push('a contract SIM is still asked about credit');
    }
    if (!d.getElementById('sms-credit').hidden) errors.push('a contract SIM still offers to ask the network');
    const every = (((w.STATE.status || {}).runtime_config || {}).sms_credit_every_h || {}).value;
    if (every) errors.push('a contract SIM is still asked every ' + every + ' h');
    console.log('a contract SIM: nothing about credit on the card, and nothing asked');
    await setSim(was);
  } catch (e) { errors.push('the SIM check itself failed: ' + e.message); }

  // ---- a text from a number nobody knows, by whichever roads ---------------
  try {
    d.querySelector('.tabs button[data-tab="control"]').click(); await wait(300);
    const sys = d.querySelector('#control-nav button[data-sec="system"]');
    if (sys) { sys.click(); await wait(1200); }
    const f = d.getElementById('sms-f-sms_stranger_alert');
    if (!f) errors.push('the SMS card no longer asks about a text from a stranger');
    else if (f.tagName.toLowerCase() === 'select') {
      errors.push('a text from a stranger is still chosen from a list of combinations');
    } else {
      const road = k => f.querySelector('input[data-road="' + k + '"]');
      if (!road('ntfy') || !road('telegram') || !road('sms')) {
        errors.push('a text from a stranger has no switch for every road');
      } else {
        road('ntfy').checked = true; road('telegram').checked = false; road('sms').checked = true;
        road('sms').dispatchEvent(new w.Event('change', { bubbles: true }));
        await wait(50);
        if (w.SMS_EDIT.sms_stranger_alert !== 'ntfy,sms') {
          errors.push('ntfy and a text without Telegram cannot be chosen for a stranger: got '
            + w.SMS_EDIT.sms_stranger_alert);
        }
        road('ntfy').checked = false; road('sms').checked = false;
        road('sms').dispatchEvent(new w.Event('change', { bubbles: true }));
        await wait(50);
        if (w.SMS_EDIT.sms_stranger_alert !== '') errors.push('with no road on it is not written down only');
        console.log('a stranger\u2019s text: a switch per road, all eight ways sayable');
      }
    }
  } catch (e) { errors.push('the stranger-roads check itself failed: ' + e.message); }

  // ---- nothing is taken away while somebody is holding it -----------------
  // A live update rebuilds a card, and what was inside it goes: a dropdown
  // that was open shuts, a run of text being copied is lost. Both are held
  // now, at applyStatus, and let go the moment the dropdown shuts or the
  // selection does.
  try {
    d.querySelector('.tabs button[data-tab="control"]').click(); await wait(400);
    const nav = d.querySelector('#control-nav button[data-sec="automation"]');
    if (nav) { nav.click(); await wait(900); }
    const sel = d.querySelector('#taps-list select') || d.querySelector('select');
    if (!sel) {
      console.log('nothing to hold open here - skipped');
    } else {
      sel.dispatchEvent(new w.MouseEvent('mousedown', { bubbles: true }));
      if (!w.userHolding()) errors.push('a dropdown held open does not hold the page');
      w.applyStatus(JSON.parse(JSON.stringify(w.STATE.status)));
      if (!d.contains(sel)) errors.push('a live update rebuilt the card under an open dropdown');
      sel.dispatchEvent(new w.Event('change', { bubbles: true }));
      await wait(300);
      if (w.userHolding()) errors.push('the page is still held after the dropdown shut');
    }
    const words = d.querySelector('.note') || d.querySelector('p');
    const range = d.createRange();
    range.selectNodeContents(words);
    const picked = w.getSelection();
    picked.removeAllRanges(); picked.addRange(range);
    if (!w.userHolding()) errors.push('a run of selected text does not hold the page');
    w.applyStatus(JSON.parse(JSON.stringify(w.STATE.status)));
    if (!d.contains(words) || !String(w.getSelection()).length) {
      errors.push('a live update took away the text that was being copied');
    }
    picked.removeAllRanges();
    if (w.userHolding()) errors.push('the page is still held after the text was let go');
    console.log('held while open or selected, let go afterwards: yes');
  } catch (e) { errors.push('the holding check itself failed: ' + e.message); }

  console.log('errors:', errors.length ? errors : 'none');
  w.close(); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
