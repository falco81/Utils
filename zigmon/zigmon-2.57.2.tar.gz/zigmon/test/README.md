# Development checks

Nothing here ships to the server.

* `replay.py` — feeds the daemon real Zigbee2MQTT and Shelly messages without
  a broker, then exercises every API endpoint including wrong PIN and token.
  Run with a scratch configuration:

      cat > /tmp/zt.json <<'JSON'
      {"db_file": "/tmp/zt.db", "token_file": "/tmp/zt-token", "log_file": "/tmp/zt.log",
       "api_port": 19849, "pin": "1234", "sample_interval": 0, "log_to_journal": false}
      JSON
      ZIGMON_CONFIG=/tmp/zt.json PYTHONPATH=. python3 test/replay.py

* `render.js` — drives the dashboard in jsdom against a running daemon and
  `php -S 127.0.0.1:8099 -t web`, walks every tab, renders the charts, goes
  through the PIN dialogue and reports any JavaScript error.

      npm install jsdom && node test/render.js

* `mockplug.py PORT [PASSWORD]` — a Shelly Plug M Gen3 lookalike: `/rpc` with
  SHA-256 digest authentication, a switch, counters and resets. Point a plug
  entry at `127.0.0.1:PORT` to exercise polling, switching, resets and
  button bindings without hardware.
