import json, time, threading, sys
sys.argv=['zigmon']
import zigmon
zigmon.load_config()
d = zigmon.Daemon()
B = 'zigbee2mqtt/'
def send(t, p): d.handle(t, json.dumps(p).encode() if not isinstance(p, str) else p.encode())
send(B+'Temp-Balkon', {"battery":100,"humidity":45.48,"last_seen":"2026-09-01T11:16:21.138Z","linkquality":68,"temperature":24.77})
send(B+'bridge/state', {"state":"online"})
send(B+'bridge/info', {"version":"2.13.0","coordinator":{"type":"EmberZNet","ieee_address":"0x00","meta":{"revision":"8.0.2"}},"network":{"channel":25,"pan_id":40435},"permit_join":False})
devices = [
 {"ieee_address":"0x0000","type":"Coordinator","friendly_name":"Coordinator"},
 {"ieee_address":"0xc02cedfffe2c7248","type":"EndDevice","friendly_name":"Temp-Balkon","power_source":"Battery","model_id":"SBHT-203C","manufacturer":"Shelly",
  "definition":{"model":"SBHT-203C","vendor":"Shelly","description":"Humidity & temperature sensor","exposes":[
    {"access":5,"category":"diagnostic","label":"Battery","name":"battery","property":"battery","type":"numeric","unit":"%"},
    {"access":5,"label":"Temperature","name":"temperature","property":"temperature","type":"numeric","unit":"°C","description":"Measured temperature value"},
    {"access":5,"label":"Humidity","name":"humidity","property":"humidity","type":"numeric","unit":"%"},
    {"access":1,"label":"Linkquality","name":"linkquality","property":"linkquality","type":"numeric","unit":"lqi"}]}},
 {"ieee_address":"0xc02cedfffe4979aa","type":"EndDevice","friendly_name":"Button","definition":{"model":"SBBT-102C","vendor":"Shelly","description":"BLU Button Tough 1 ZB","exposes":[{"type":"enum","name":"action","property":"action","values":["single","double","long"]},{"property":"battery","type":"numeric","unit":"%","label":"Battery"}]}},
]
send(B+'bridge/devices', devices)
send(B+'Button', {"action":"single","battery":100,"linkquality":112})
send(B+'Button/availability', {"state":"online"})
send(B+'Temp-Balkon/availability', "offline")
send(B+'Temp-Balkon', {"temperature":25.1,"humidity":40.0,"battery":12,"linkquality":30})
send('shellies/ht-temp/status/temperature:0', {"id":0,"tC":22.4,"tF":72.3})
send('shellies/ht-temp/status/humidity:0', {"id":0,"rh":47.5})
send('shellies/ht-temp/status/devicepower:0', {"id":0,"battery":{"V":2.9,"percent":85},"external":{"present":False}})
send('shellies/plug-lednice/status/switch:0', {"id":0,"output":True,"apower":85.2,"voltage":231.1,"current":0.38,"aenergy":{"total":1234.5,"by_minute":[1,2,3],"minute_ts":1}})
send(B+'bridge/event', {"type":"device_joined","data":{"friendly_name":"X","ieee_address":"0xabc"}})
devices[1]['friendly_name']='Temp-Venek'
send(B+'bridge/devices', devices)
send(B+'Temp-Venek', {"temperature":26.0})
st = d.status()
print(json.dumps({k:v for k,v in st.items() if k!='devices'}, indent=1)[:700])
for dev in st['devices']:
    print(dev['name'], dev['id'], dev['level'], dev['reasons'], [ (h['key'], h['value'], h['unit']) for h in dev['headline']], dev['battery'], dev['availability'])
print(d.store.keys_for('0xc02cedfffe2c7248'))
print(d.store.history('0xc02cedfffe2c7248', ['temperature','humidity'], 3600))
for e in d.store.events(20): print(e)
print(d.store.stats())
print('aggregate', d.store.aggregate())
srv = zigmon.ApiServer(d); srv.start(); time.sleep(0.3)
for p in ['/api/status','/api/health','/api/devices','/api/device?name=Temp-Venek','/api/history?device=Temp-Venek&range=6h','/api/events','/api/nope','/api/history?device=zz']:
    c, r = zigmon.api_call(p); print(p, c, str(r)[:160])
c, r = zigmon.api_call('/api/reset','POST',{'scope':'events','pin':'0000'}, token=d.token); print('wrongpin', c, r)
c, r = zigmon.api_call('/api/reset','POST',{'scope':'events','pin':'1234'}, token='bad'); print('badtoken', c, r)
c, r = zigmon.api_call('/api/permit-join','POST',{'enable':True,'pin':'1234'}, token=d.token); print('pj', c, r)
c, r = zigmon.api_call('/api/reset','POST',{'scope':'device','device':'Button','pin':'1234'}, token=d.token); print('reset', c, r)
c, r = zigmon.api_call('/api/devices'); print([x['name'] for x in r['devices']])
srv.stop()
