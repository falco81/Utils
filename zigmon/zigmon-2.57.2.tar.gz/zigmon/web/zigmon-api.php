<?php
/**
 * zigmon-api.php — the page's side of the daemon API.
 *
 * index.php collects nothing itself. The daemon does all the work and exposes
 * it on http://127.0.0.1:<port>; this file is the thin client that talks to it.
 * Read endpoints are open; the two that change something (opening the Zigbee
 * network, erasing history) send the token the daemon dropped in a file
 * readable only by root and the web server's group.
 *
 * The browser never sees the token, and the web user holds no broker
 * credentials — the daemon owns those and is the only thing that talks to MQTT.
 */
declare(strict_types=1);

const ZIGMON_HOST  = '127.0.0.1';
const ZIGMON_PORT  = 9849;
const ZIGMON_TOKEN = '/run/zigmon/api-token';

/** Read the API token the daemon wrote for us, or null if we can't. */
function zigmon_token(): ?string
{
    if (!is_readable(ZIGMON_TOKEN)) {
        return null;
    }
    $token = trim((string) @file_get_contents(ZIGMON_TOKEN));
    return $token !== '' ? $token : null;
}

/**
 * Call the daemon. Returns [status, body-string]; status 0 means unreachable.
 * $payload, when given, is sent as a JSON body and turns this into a POST.
 */
function zigmon_call(string $path, string $method = 'GET', ?array $payload = null,
                     float $timeout = 10.0): array
{
    $headers = ['Accept: application/json'];
    $headers[] = 'X-Zigmon-Client: ' . ($_SERVER['REMOTE_ADDR'] ?? '');
    if (isset($_GET['session']) && $_GET['session'] !== '') {
        $headers[] = 'X-Zigmon-Session: ' . substr((string) $_GET['session'], 0, 80);
    }
    $body    = null;

    if ($payload !== null) {
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Content-Length: ' . strlen($body);
    }
    if ($method !== 'GET') {
        $token = zigmon_token();
        if ($token === null) {
            return [0, ''];
        }
        $headers[] = 'X-Zigmon-Token: ' . $token;
        if ($body === null) {
            $headers[] = 'Content-Length: 0';
        }
    }

    $context = stream_context_create(['http' => [
        'method'        => $method,
        'timeout'       => $timeout,
        'ignore_errors' => true,
        'header'        => implode("\r\n", $headers),
        'content'       => $body,
    ]]);

    $url = 'http://' . ZIGMON_HOST . ':' . ZIGMON_PORT . $path;
    $reply = @file_get_contents($url, false, $context);
    if ($reply === false) {
        return [0, ''];
    }

    $status = 0;
    foreach (($http_response_header ?? []) as $header) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $header, $m)) {
            $status = (int) $m[1];
        }
    }
    return [$status, (string) $reply];
}

/** Call the daemon and return the decoded reply, or null. */
function zigmon_get(string $path, float $timeout = 10.0): ?array
{
    [$status, $body] = zigmon_call($path, 'GET', null, $timeout);
    if ($status !== 200) {
        return null;
    }
    $data = json_decode($body, true);
    return is_array($data) ? $data : null;
}

/** Pass a daemon reply straight through to the browser. */
function zigmon_relay(string $path, string $method = 'GET', ?array $payload = null,
                      float $timeout = 10.0): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');

    if ($method !== 'GET' && zigmon_token() === null) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'error' =>
            'the API token is unreadable — is zigmon.service running, and is '
            . ZIGMON_TOKEN . ' readable by the web server?']);
        return;
    }

    [$status, $body] = zigmon_call($path, $method, $payload, $timeout);
    if ($status === 0) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'error' =>
            'the monitoring daemon is not responding — is zigmon.service running?']);
        return;
    }
    http_response_code($status);
    echo $body;
}
