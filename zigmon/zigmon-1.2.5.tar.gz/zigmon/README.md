# zigmon

Monitoring, history and control for every sensor that reaches an MQTT broker
through Zigbee2MQTT — and, optionally, for Shelly WiFi devices publishing to
the same broker. The same shape as `upsmon`: a Python daemon that owns the
data, SQLite for history, and a PHP dashboard behind nginx that only relays
JSON.

* `install.sh` — sets the whole thing up on AlmaLinux 9, and can upgrade or remove it
* `zigmon.py` — the daemon and the command-line tool, one file (standard library + paho-mqtt)
* `web/index.php`, `web/zigmon-api.php` — the dashboard and its thin API client
* `deploy/` — systemd unit, logrotate rules, sample configuration, nginx server block
* `INSTALL.md` — the AlmaLinux 9 walkthrough, by hand

## Installing

```bash
sudo ./install.sh
```

Packages, service user, configuration, the broker account, systemd unit, log
rotation, nginx with TLS, php-fpm, SELinux, firewall, and a check that it all
works. `--dry-run` shows what it would do, `--upgrade` replaces the program
files, `--uninstall` removes it while keeping the recorded history. Every
question has a command-line option; `--help` lists them.

## How the pieces fit

```
Zigbee sensors ──► SLZB-06 ──► Zigbee2MQTT ──┐
                                             │      AlmaLinux 9
Shelly WiFi (H&T, Plug) ─────────────────────┤   ┌────────────────────────────────────────┐
                                             ▼   │ zigmon.service   (user "zigmon")       │
                                        mosquitto│   subscribes to zigbee2mqtt/#, shellies/#│
                                       1883/8883 │   writes /var/lib/zigmon/history.db    │
                                             ────►   serves 127.0.0.1:9849, token-guarded │
                                                 │        ↑                               │
                                                 │ php-fpm ← nginx :443 ← browser         │
                                                 └────────────────────────────────────────┘
```

The daemon is the only thing that talks to the broker. PHP relays JSON and
holds no credentials; the two endpoints that change something (opening the
network for joining, erasing history) send a token read from a file the
browser never sees, and are guarded by a PIN on top. Nothing in the chain
needs root.

## What it watches

**Every device Zigbee2MQTT knows.** The bridge's device list gives the model,
vendor, description and — through the "exposes" definition — the label and
unit of every value the device reports. Nothing is specific to a model: a
temperature sensor, a button, a contact, a plug with power metering all land
in the same tables and on the same dashboard. New devices appear by
themselves the moment they pair.

**Shelly smart plugs**, optionally, over local RPC exactly as upsmon does it:
the watts actually being drawn, voltage, current, power factor, frequency,
the plug's own temperature, the energy total and the runtime and switching
counters. Any number of plugs; each can be switched and its counters reset
from the dashboard, and **a Zigbee button can be bound to it** — single press
toggles the fridge, long press switches it off, whatever you set up on the
Control tab. The editor offers only devices that can send an action, and for
each one the exact actions its Zigbee2MQTT definition declares (plus any it
has actually sent), so nothing has to be typed or guessed.

**Shelly WiFi sensors**, three ways, all optional: over MQTT (anything under
`shellies/<name>/status/…`), polled over RPC when the sensor has an address
and answers (an H&T on USB power), or **pushed by webhook** from a battery
sensor that sleeps and cannot be polled — the daemon can listen for those
on a port of its own, exactly as upsmon did.

**The bridge itself**: online/offline, version, channel, whether the network
is open for joining, and the events it publishes (join, leave, interview,
rename).

## Why it is built this way

**Readings are rows, not columns.** `(device, key, value)` rather than a fixed
schema, because what one sensor reports is not what the next one does, and a
device added next month should need no code change.

**History is keyed by address, not by name.** Renaming a device in
Zigbee2MQTT keeps its history; the rename shows up as an event. A device that
reports before the bridge has listed it is filed under its name and moved
across when the address arrives.

**SQLite in two layers.** Full-resolution samples for a fortnight, hourly
averages with min and max for two years. A year of history for a dozen
sensors is a few megabytes, and a year-long chart costs a few hundred rows.

**A bursty device does not flood the table.** Readings arriving within
`sample_interval` of the previous one replace it rather than adding a row —
some devices send four messages for one measurement.

**Availability is inferred as well as reported.** Zigbee2MQTT publishes
`availability` when that feature is on; when it is not, a device that has
been silent longer than a battery sensor's reporting interval is flagged
anyway. A device that reports is by definition reachable, whatever the last
availability message said.

**Button presses are events, not readings.** `action` values go to the event
log with a timestamp; there is nothing to chart in a press.

**Button bindings run in the daemon, not the browser.** A press arrives over
MQTT, the daemon looks the binding up and talks to the plug over RPC; nothing
depends on a dashboard being open. Each switch is an event with the button
and the action that caused it.

**A plug reset is verified, not assumed.** The plug answers
`Switch.ResetCounters` with success whether or not it understood the counter
name, so the values are read back and compared.

**Requests to a plug are paced.** Gen3 firmware with authentication answers
429 when requests arrive closer together than about a second, and the digest
challenge is reused rather than renegotiated on every call.

**A missed reading does not blank the panel.** The last values stay on screen,
greyed out and dated, and after a restart they come from the recorded
snapshots until a fresh reading lands.

**The daemon never gives up.** paho reconnects to the broker by itself with
backoff; the systemd unit restarts the daemon without limit if it ever
crashes; a broker that is down for an hour simply means an hour without data.

**An error inside an endpoint answers rather than raises.** The dashboard
polls every five seconds; one bad payload from one device must not stop the
feed or bury the journal.

## The dashboard

Six tabs. **Overview**: counts, bridge state, permit-join state, a socket
panel per plug with a switch and its live figures, a card per sensor with its
main readings, battery, signal and last report, and 6h/24h/7d charts of
temperature and humidity across all devices. **History**: pick a
device, pick 6 hours to a year, one chart per value it reports. **Devices**:
the table. **Events**: joins, leaves, renames, availability changes, button
presses, bridge state. **Control**: open or close the Zigbee network, switch each plug and reset
its counters, edit the button bindings, erase recorded data, forget a device
— all behind the PIN. **All values**: everything
every device reports, with the description Zigbee2MQTT gives for it.

It refreshes every five seconds, pauses when the tab is hidden, and can be
paused by hand from the indicator in the corner. Control buttons carry a
plain label and an icon; resting the pointer on one for five seconds
reveals the exact request behind it and what it does. There are no browser
pop-ups — the PIN dialogue is the only confirmation. The tab icon is coloured by
the overall verdict.

## Command line

```bash
zigmon --status                       # every device with its latest readings
zigmon --devices                      # the device table
zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
zigmon --events                       # the event log
zigmon --watch                        # live feed straight from the broker
zigmon --watch --bridge --raw         # including bridge/* topics, untruncated
zigmon --permit-join on               # open the network for four minutes
zigmon --plug                         # every plug, live from the device
zigmon --plug-on Lednice              # switch a plug; also --plug-off, --plug-toggle
zigmon --plug-reset Lednice --types aenergy,switch_on
zigmon --bindings                     # which button action drives which plug
zigmon shelly Lednice dump            # the Shelly toolkit, see below
zigmon --reset-data history           # erase: all, history, events, or a device name
zigmon --check                        # is the whole system healthy
zigmon --diag                         # settings, API latency, database size
zigmon                                # run the daemon in the foreground
```

## The full Shelly toolkit

Everything the standalone Shelly reader in upsmon could do, ported whole and
addressed by the name a device has in the configuration — the address and
password come from there. Each command has its own `--help`.

```
zigmon shelly [NAME] <command> [options]
```

| reading | |
|---|---|
| `discover` | find Shelly devices on the LAN over multicast DNS, with a diagnosis when nothing answers |
| `info` | identity, firmware, auth and Matter state |
| `dump` | every value the device exposes, every component |
| `methods [COMPONENT] [--examples]` | every RPC method it supports, with a note on what each is for |
| `poll` | a live table. `--interval`, `--count`, `--csv FILE` |
| `watch` | the same, pushed over the device's websocket |
| `listen`, `serve` | receive webhooks, or an outbound websocket |

| controlling | |
|---|---|
| `on`, `off`, `toggle` | switch the relay |
| `reset-counters [type…]` | no type means every counter |
| `reboot [--wait]` | restart, optionally waiting for it to come back |

| configuring | |
|---|---|
| `config [COMPONENT] ['{JSON}']` | read or write a component's settings — a write is read back and the keys the firmware dropped are listed |
| `matter status\|on\|off\|code` | Matter, and the pairing code |
| `ble status\|on\|off\|rpc-on\|rpc-off` | radio and RPC over Bluetooth |
| `call METHOD ['{JSON}']` | anything the above does not cover |

```bash
zigmon shelly Lednice dump
zigmon shelly Lednice config switch:0 '{"auto_off": true, "auto_off_delay": 300}'
zigmon shelly Lednice ble on --reboot
zigmon shelly Lednice methods Switch --examples
zigmon shelly --host 172.16.16.13 --password secret info
zigmon shelly discover
```

`--host`, `--password`, `--switch-id`, `--json` and `--no-color` work
anywhere, before the command or after it. With no name, the first
configured plug is assumed. `watch` needs a device without a password, the
websocket carrying no authentication. `discover` does not cross subnets.
`ble` and `matter` take effect after a reboot, which `--reboot` will do.

## Sensors over RPC and webhooks

```json
"sensors": [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}],
"sensor_listen": true,
"sensor_listen_host": "0.0.0.0",
"sensor_listen_port": 8088
```

A sensor with an address is polled like a plug; while it sleeps the poll
simply fails quietly. A battery sensor pushes instead — point its webhook at
`http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=NAME` (`bp` for battery
percent, `bv` for volts, `rssi`). JSON bodies are accepted as well. Each
source becomes a device like any other; `zigmon shelly listen` shows what
arrives without recording it, and the Control tab's daemon card counts the
pushes.

## API

Read endpoints are open on the loopback; the two that change something
require `X-Zigmon-Token` and, when configured, the PIN.

| endpoint | returns |
|---|---|
| `GET /api/status` | every device: identity, latest values with labels and units, verdict and reasons; the bridge; counts |
| `GET /api/health` | daemon uptime, broker connection, message count, database statistics |
| `GET /api/devices` | the device list (same shape as in status) |
| `GET /api/device?id=NAME` | one device, plus the keys it has history for and the full exposes map |
| `GET /api/history?device=NAME&keys=temperature,humidity&range=24h&points=600` | rows of `{ts, key…}`, hourly beyond two weeks |
| `GET /api/events?limit=100&device=NAME` | the event log |
| `GET /api/keys?device=NAME` | which values have history |
| `POST /api/permit-join` | `{"enable": true, "time": 254, "pin": "…"}` |
| `POST /api/reset` | `{"scope": "all|history|events|device", "device": "…", "pin": "…"}` |

The plugs:

| endpoint | returns |
|---|---|
| `GET /api/plugs` | every plug: state, live figures, each counter with its value and the date it started from |
| `GET /api/plug?name=Lednice&refresh=1` | one plug, optionally read again first |
| `POST /api/plug/switch` | `{"name": "Lednice", "on": false}` or `{"name": "…", "toggle": true}` — needs the PIN |
| `POST /api/plug/reset` | `{"name": "Lednice", "types": ["aenergy"]}`, or `[]` for every counter — needs the PIN |
| `GET /api/bindings` | the button bindings |
| `POST /api/bindings` | `{"bindings": [{"device": "Button", "action": "single", "plug": "Lednice", "do": "toggle"}]}` — replaces the list, needs the PIN |

Plugs are configured in `config.json`:

```json
"plugs": [
  {"name": "Lednice", "host": "172.16.16.12", "password": "", "switch_id": 0, "mqtt_name": ""}
]
```

`mqtt_name` is the plug's `shellies/<name>` prefix, if it also publishes to
the broker, so the same device is not recorded twice. A plug shows up as a
device like any other, so History and All values cover it too.

`device` and `id` accept the friendly name or the IEEE address.

## Broker account

The daemon needs a broker login with these rights (the installer can create
it in a local mosquitto):

```
user zigmon
topic read zigbee2mqtt/#
topic write zigbee2mqtt/bridge/request/#
topic read shellies/#
```

## What was verified

Without a broker in the build environment, against replayed messages from a
real Zigbee2MQTT 2.13 with Shelly BLU H&T ZB, BLU Button Tough ZB, a Shelly
H&T Gen3 and a Plug M Gen3 over `shellies/`:

* device discovery from `bridge/devices`, readings before the list arrives,
  rename, removal, availability, button actions, bridge events
* every API endpoint, token and PIN handling, erasing by scope
* the plugs against a mock Shelly Plug M Gen3 with SHA-256 digest
  authentication: polling, switching, per-counter resets including ones the
  firmware only pretends to clear, and a button press toggling the plug
  through a binding
* the dashboard driven in a headless browser through every tab, chart
  rendering, the PIN dialogue and a reset
* the whole Shelly toolkit against the same mock: info, dump, methods,
  config read and write with keys the firmware drops, ble and matter
  switches, on/off/toggle, counter resets, call, poll to CSV, reboot --wait,
  and the discovery diagnosis on a network with no answer
* a polled sensor, GET and POST webhook pushes, and a push carrying nothing usable
* the installer's dry run

Current version: **1.2.3**
