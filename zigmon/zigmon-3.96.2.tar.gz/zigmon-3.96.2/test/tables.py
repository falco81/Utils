#!/usr/bin/env python3
"""The tables the daemon keeps by hand must not say the same thing twice.

Python keeps the last of two entries with the same key, so an earlier one is
dead text: editing it changes nothing, which is a trap for whoever comes to
edit it. Three had crept into KEY_INFO before this test existed.
"""
import re
import sys
from collections import Counter
from pathlib import Path

source = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
bad = False

for name in ('KEY_INFO', 'WEATHER_WORDS', 'NOTIFY_PRESETS'):
    block = re.search(r'\n%s = \{(.*?)\n\}' % name, source, re.S)
    if not block:
        continue
    keys = re.findall(r"^\s*'?([\w.]+)'?\s*:", block.group(1), re.M)
    dupes = [k for k, c in Counter(keys).items() if c > 1]
    print('%-16s %3d entries%s' % (name, len(keys), '' if not dupes else '  <-- said twice: ' + ', '.join(dupes)))
    bad = bad or bool(dupes)

names = re.findall(r'^    def (\w+)\(', source, re.M)
inner = {'__init__', 'snapshots', 'reset', 'stop', 'value', 'paint'}   # each in a class of its own
dupes = [n for n, c in Counter(names).items() if c > 1 and n not in inner]
print('%-16s %3d methods%s' % ('classes', len(names), '' if not dupes else '  <-- defined twice: ' + ', '.join(dupes)))
if bad or dupes:
    # not sys.exit here: everything below this line used to be unreachable,
    # which is how two checks written weeks apart both quietly did nothing
    raise SystemExit(1)

# Every setting the daemon will accept must have a default, and every default
# must be one it will accept: one added to the checks but not to the defaults
# is invisible to the settings page and silently absent from config.json.
import zigmon as _z   # noqa: E402
_tun = set(_z.Daemon.TUNABLE)
_def = set(_z.DEFAULTS)
_no_default = sorted(_tun - _def)
_unchecked = sorted(k for k in _def - _tun
                    if k not in ('plugs', 'sensors', 'zigbee_gateways', 'db_file', 'token_file', 'log_file',
                                 'pin', 'mqtt_host', 'mqtt_port', 'mqtt_username', 'mqtt_password', 'mqtt_tls',
                                 'mqtt_ca', 'mqtt_client_id', 'mqtt_keepalive', 'api_host', 'api_port',
                                 'base_topic', 'extra_topics', 'log_to_journal', 'plug_mqtt_password'))
print('%-16s %3d settings the page may change' % ('tunable', len(_tun)))
if _no_default:
    print('   these can be changed but have no default:')
    for _k in _no_default:
        print('      ' + _k)
    raise SystemExit(1)


# A function defined twice at module level is not an error in Python: the
# later one quietly replaces the earlier, and every caller of the first gets
# the second. That is how every chart range longer than a day came back as
# nothing, for days, without a word anywhere.
import re as _re2
_src = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
_defs = _re2.findall(r'^def (\w+)\(', _src, _re2.M)
_twice = sorted({n for n in _defs if _defs.count(n) > 1})
if _twice:
    print('module-level functions defined more than once:')
    for _n in _twice:
        print('   ' + _n)
    raise SystemExit(1)
print('%d module-level function(s), each defined once' % len(_defs))


# The same thing again, one level down: a dictionary written out in the middle
# of a function. `message_facts` said 'uptime' and 'plugs_on' twice each, and
# the first of each pair was dead text - one of them worked the figure out a
# different way, from a different attribute, and nothing ever used it. The
# named tables above are checked by hand; this looks at every dictionary
# literal in the file.
import ast as _ast   # noqa: E402
_dupes = []
for _node in _ast.walk(_ast.parse(_src)):
    if not isinstance(_node, _ast.Dict):
        continue
    _keys = [k.value for k in _node.keys
             if isinstance(k, _ast.Constant) and isinstance(k.value, str)]
    _said_twice = sorted({k for k in _keys if _keys.count(k) > 1})
    if _said_twice:
        _dupes.append((_node.lineno, _said_twice))
if _dupes:
    print('a dictionary says the same key twice - the earlier one is dead text:')
    for _line, _keys in _dupes:
        print('   line %d: %s' % (_line, ', '.join(_keys)))
    raise SystemExit(1)
print('every dictionary literal in the file says each key once')
