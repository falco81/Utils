#!/usr/bin/env python3
"""A column header must stand over the boxes it names.

Every table on the Control page is built as a grid per row: the header is one
grid, each row is another. Two things then have to hold, and neither is
checked by anything that runs:

  * the header must have as many cells as the row has columns, or the names
    shift along by one from wherever the missing cell is;

  * no column may be sized by its own content (`max-content`, `auto`,
    `fit-content`), because each row answers that question for itself. The
    gateways had `max-content` on the buttons column: the header's last cell
    is empty and so asked for nothing, the five columns above the boxes ate
    the width the buttons take in the rows, and every name from Address on
    walked right - a hundred and fifty pixels of it by Target. A row carrying
    the `config.json` label drifted from its neighbours in the same way.

A content-sized column is allowed only through a variable - `var(--gw-btns,
max-content)` - which is measured once from the widest row and handed to the
header and every row alike. This test insists such a variable is really set
somewhere in the page's script, so the fallback is not the whole story.

    python3 test/columns.py
"""
import re
import sys
from pathlib import Path

page = (Path(__file__).resolve().parent.parent / 'web' / 'index.php').read_text()
bad = []

CONTENT = ('max-content', 'min-content', 'fit-content', 'auto')


def tracks(spec):
    """Split a grid-template-columns value into tracks, keeping ( ) together."""
    out, depth, cur = [], 0, ''
    for ch in spec:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch.isspace() and depth == 0:
            if cur:
                out.append(cur)
            cur = ''
        else:
            cur += ch
    if cur:
        out.append(cur)
    return out


def template(kind):
    """The base rule for .kind-row, ignoring the ones inside media queries."""
    for m in re.finditer(r'\.%s-row\{([^}]*)\}' % re.escape(kind), page):
        # a media query opens a brace before the rule; the base rule is the
        # one that also says display:grid
        body = m.group(1)
        if 'grid-template-columns' in body and 'display:grid' in body:
            return re.search(r'grid-template-columns:([^;}]*)', body).group(1).strip()
    return None


def header_cells(at):
    """Count the cells the script appends to a header built at this offset."""
    tail = page[at:at + 900]
    m = re.search(r'\[(.*?)\]\s*\.?\s*\n?\s*\.?forEach', tail, re.S)
    if not m:
        return None
    items, depth, n = m.group(1), 0, 1
    if not items.strip():
        return 0
    for ch in items:
        if ch in '[(':
            depth += 1
        elif ch in ')]':
            depth -= 1
        elif ch == ',' and depth == 0:
            n += 1
    return n


heads = re.finditer(r"el\('div', '([a-z0-9]+)-row ([a-z0-9]+)-head'\)", page)
seen = 0
for m in heads:
    kind, headname = m.group(1), m.group(2)
    spec = template(kind)
    if not spec or 'repeat(' in spec:
        continue
    seen += 1
    cols = tracks(spec)
    cells = header_cells(m.end())
    note = ''
    for t in cols:
        plain = t if not t.startswith('var(') else ''
        if any(c in plain for c in CONTENT):
            bad.append('.%s-row sizes a column by its content (%s) - '
                       'each row then answers it alone and the header cannot line up' % (kind, t))
            note = '  <-- content-sized column'
        if t.startswith('var('):
            name = re.match(r'var\((--[a-z0-9-]+)', t).group(1)
            set_here = ("setProperty('%s'" % name) in page
            measured = re.search(r"shareColumn\([^;]*?'%s'\s*\)" % re.escape(name), page)
            if not (set_here or measured):
                bad.append('.%s-row reads %s, which nothing ever sets' % (kind, name))
                note = '  <-- variable never set'
    if cells is not None and cells != len(cols):
        bad.append('.%s-head has %d cells over %d columns' % (headname, cells, len(cols)))
        note = '  <-- header does not cover the row'
    print('%-12s %d columns, header %s cells%s'
          % ('.' + kind + '-row', len(cols), '?' if cells is None else cells, note))

if not seen:
    print('no grid headers found - has the page moved?')
    sys.exit(1)
if bad:
    print()
    for b in bad:
        print('   ' + b)
    sys.exit(1)
print('\n%d header(s) stand over their rows' % seen)
