// What Ctrl+Space offers inside {…}, checked against the rules the daemon
// fills a message by. It needs neither the daemon nor php: the functions are
// lifted out of index.php and run against a made-up dashboard.
//
//     node test/completer.js
//
// It exists because {PIR-Chodba.model.nl} could not be typed. A dot after a
// device name offered that device's readings, and a dot after a fact offered
// the turns of phrase - but a dot after a device's READING offered nothing at
// all, which is exactly where .nl belongs. Worse, what was chosen was put
// back over everything after the first dot, so picking a turn there turned
// {Name.model.nl} into {Name.nl}.
const fs = require('fs');
const path = require('path');

const page = fs.readFileSync(path.join(__dirname, '..', 'web', 'index.php'), 'utf8');
const script = page.slice(page.indexOf('<script>')).split('\n');

function grab(name) {                       // a top-level function, brace at column 0
  const start = script.findIndex(l => l.startsWith('function ' + name + '('));
  if (start < 0) throw new Error('index.php no longer has function ' + name);
  let end = start + 1;
  while (end < script.length && script[end] !== '}') end++;
  return script.slice(start, end + 1).join('\n');
}
function grabList(name) {
  const m = script.join('\n').match(new RegExp('var ' + name + ' = \\[[\\s\\S]*?\\n\\];'));
  if (!m) throw new Error('index.php no longer has ' + name);
  return m[0];
}

const lifted = [grabList('FACT_TURN_LIST'), grabList('DEVICE_FACT_KEYS'),
  'deviceForFacts', 'isFactTurn', 'factWithoutTurns', 'deviceKeyNames', 'turnItems', 'completerItems']
  .map(x => (x.indexOf('\n') >= 0 ? x : grab(x))).join('\n');

const stand = `
var STATE = {status: {devices: [
  {name:'PIR-Chodba', model:'SBMO-003Z', vendor:'Shelly', battery:88, linkquality:90, age_s:10, source:'zigbee',
   values:{occupancy:{value:true,label:'Occupancy'}, battery:{value:88,unit:'%'}, 'switch.apower':{value:12,unit:'W'}}}
], plugs: []}};
function factCatalogue(){ return [['Facts', [['home','who is in','Falco'],['attention_list','what wants a look','A, B']]]]; }
function deviceIcon(){ return ''; }
function ago(){ return '10s ago'; }
`;

const scope = {};
new Function('scope', stand + lifted + '\nscope.completerItems = completerItems;')(scope);
const completerItems = scope.completerItems;

// what the box would hold if the first offer were taken, caret at the end
function accept(token) {
  const items = completerItems(token);
  if (!items.length) return '';
  const it = items[0];
  return ('{' + token).slice(0, 1 + (it.at || 0)) + it.text;
}

const cases = [
  // typed                        first offer          taken, it reads
  ['PIR-Chodba.',                 'state',             '{PIR-Chodba.state}'],
  ['PIR-Chodba.mod',              'model',             '{PIR-Chodba.model}'],
  ['PIR-Chodba.model.',           '.nl',               '{PIR-Chodba.model.nl}'],
  ['PIR-Chodba.model.n',          '.nl',               '{PIR-Chodba.model.nl}'],
  ['PIR-Chodba.model.nl.',        '.nl',               '{PIR-Chodba.model.nl.nl}'],
  ['PIR-Chodba.occupancy.yes',    '.yesno',            '{PIR-Chodba.occupancy.yesno}'],
  ['PIR-Chodba.switch.',          'switch.apower',     '{PIR-Chodba.switch.apower}'],
  ['PIR-Chodba.switch.apower.rou', '.round',           '{PIR-Chodba.switch.apower.round}'],
  ['home.',                       '.nl',               '{home.nl}'],
  ['home.nl.',                    '.nl',               '{home.nl.nl}'],
  ['PIR-Chodba.',                 'state',             '{PIR-Chodba.state}']
];

let bad = 0;
for (const [token, offer, reads] of cases) {
  const items = completerItems(token);
  const first = items.length ? items[0].label : '(nothing)';
  const got = accept(token);
  const ok = first === offer && got === reads;
  if (!ok) bad++;
  console.log('%s {%s%s %s%s',
    ok ? ' ' : '!', token, ' '.repeat(Math.max(1, 30 - token.length)), got || '(nothing offered)',
    ok ? '' : '   <-- wanted ' + reads + ' from ' + offer);
}
// a key that is not there is not a fact either: offering turns for it would
// promise something the daemon will fill with nothing
if (completerItems('PIR-Chodba.nosuchkey.').length) {
  console.log('! a key the device does not have is still offered turns');
  bad++;
}
if (bad) {
  console.log('\n' + bad + ' case(s) wrong');
  process.exit(1);
}
console.log('\n' + cases.length + ' completions, each offered and each put where it belongs');
