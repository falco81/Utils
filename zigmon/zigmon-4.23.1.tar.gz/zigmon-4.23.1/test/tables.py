#!/usr/bin/env python3
"""The tables the daemon keeps by hand must not say the same thing twice.

Python keeps the last of two entries with the same key, so an earlier one is
dead text: editing it changes nothing, which is a trap for whoever comes to
edit it. Three had crept into KEY_INFO before this test existed.
"""
import re
import sys
from collections import Counter
from pathlib import Path

source = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
bad = False

for name in ('KEY_INFO', 'WEATHER_WORDS', 'NOTIFY_PRESETS'):
    block = re.search(r'\n%s = \{(.*?)\n\}' % name, source, re.S)
    if not block:
        continue
    keys = re.findall(r"^\s*'?([\w.]+)'?\s*:", block.group(1), re.M)
    dupes = [k for k, c in Counter(keys).items() if c > 1]
    print('%-16s %3d entries%s' % (name, len(keys), '' if not dupes else '  <-- said twice: ' + ', '.join(dupes)))
    bad = bad or bool(dupes)

names = re.findall(r'^    def (\w+)\(', source, re.M)
inner = {'__init__', 'snapshots', 'reset', 'stop', 'value', 'paint'}   # each in a class of its own
dupes = [n for n, c in Counter(names).items() if c > 1 and n not in inner]
print('%-16s %3d methods%s' % ('classes', len(names), '' if not dupes else '  <-- defined twice: ' + ', '.join(dupes)))
if bad or dupes:
    # not sys.exit here: everything below this line used to be unreachable,
    # which is how two checks written weeks apart both quietly did nothing
    raise SystemExit(1)

# Every setting the daemon will accept must have a default, and every default
# must be one it will accept: one added to the checks but not to the defaults
# is invisible to the settings page and silently absent from config.json.
import zigmon as _z   # noqa: E402
_tun = set(_z.Daemon.TUNABLE)
_def = set(_z.DEFAULTS)
_no_default = sorted(_tun - _def)
_unchecked = sorted(k for k in _def - _tun
                    if k not in ('plugs', 'sensors', 'zigbee_gateways', 'db_file', 'token_file', 'log_file',
                                 'pin', 'mqtt_host', 'mqtt_port', 'mqtt_username', 'mqtt_password', 'mqtt_tls',
                                 'mqtt_ca', 'mqtt_client_id', 'mqtt_keepalive', 'api_host', 'api_port',
                                 'base_topic', 'extra_topics', 'log_to_journal', 'plug_mqtt_password'))
print('%-16s %3d settings the page may change' % ('tunable', len(_tun)))
if _no_default:
    print('   these can be changed but have no default:')
    for _k in _no_default:
        print('      ' + _k)
    raise SystemExit(1)


# A function defined twice at module level is not an error in Python: the
# later one quietly replaces the earlier, and every caller of the first gets
# the second. That is how every chart range longer than a day came back as
# nothing, for days, without a word anywhere.
import re as _re2
_src = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
_defs = _re2.findall(r'^def (\w+)\(', _src, _re2.M)
_twice = sorted({n for n in _defs if _defs.count(n) > 1})
if _twice:
    print('module-level functions defined more than once:')
    for _n in _twice:
        print('   ' + _n)
    raise SystemExit(1)
print('%d module-level function(s), each defined once' % len(_defs))


# The same thing again, one level down: a dictionary written out in the middle
# of a function. `message_facts` said 'uptime' and 'plugs_on' twice each, and
# the first of each pair was dead text - one of them worked the figure out a
# different way, from a different attribute, and nothing ever used it. The
# named tables above are checked by hand; this looks at every dictionary
# literal in the file.
import ast as _ast   # noqa: E402
_dupes = []
for _node in _ast.walk(_ast.parse(_src)):
    if not isinstance(_node, _ast.Dict):
        continue
    _keys = [k.value for k in _node.keys
             if isinstance(k, _ast.Constant) and isinstance(k.value, str)]
    _said_twice = sorted({k for k in _keys if _keys.count(k) > 1})
    if _said_twice:
        _dupes.append((_node.lineno, _said_twice))
if _dupes:
    print('a dictionary says the same key twice - the earlier one is dead text:')
    for _line, _keys in _dupes:
        print('   line %d: %s' % (_line, ', '.join(_keys)))
    raise SystemExit(1)
print('every dictionary literal in the file says each key once')


# A value stored again and again unchanged is most of what a house writes
# down: on a real one a fortnight old, eighteen per cent of every row was a
# value that never changed once, and sixty-two per cent was a row saying what
# the row before it said. Clearing that out must leave every chart the same
# shape, which is what keeping the first and the last of each flat run does.
import threading as _threading
import time as _time
_z.load_config()
_z.CONFIG['db_file'] = '/tmp/zt-prune.db'
import os as _os
if _os.path.exists('/tmp/zt-prune.db'):
    _os.remove('/tmp/zt-prune.db')
_store = _z.Storage(_z.CONFIG['db_file'])
_now = _time.time()
for _i in range(300):
    # a flat stretch, then a change, then flat again
    _value = 21.0 if _i < 120 else (22.5 if _i < 240 else 21.0)
    _store.db.execute('INSERT INTO samples (ts, device, key, value) VALUES (?,?,?,?)',
                      (_now - (300 - _i) * 60, 'test:flat', 'temperature', _value))
_store.db.commit()
_before = _store.history('test:flat', ['temperature'], 6 * 3600, 400)
_out = _store.prune(apply=True)
_after = _store.history('test:flat', ['temperature'], 6 * 3600, 400)


def _shape(rows):
    _seen = [r.get('temperature') for r in rows if r.get('temperature') is not None]
    return (min(_seen), max(_seen), len(set(_seen))) if _seen else None


assert _out['repeated_rows'] > 200, 'a flat series of 300 points lost only %d' % _out['repeated_rows']
assert _shape(_before) == _shape(_after), \
    'the chart changed shape: %r became %r' % (_shape(_before), _shape(_after))
assert len(_after) >= 4, 'a flat run kept %d points; its ends and its anchors should remain' % len(_after)
print('clearing out values stored again unchanged leaves every chart the same shape')

# Better than clearing it out afterwards: not writing it down. A reading equal
# to the last one written is skipped until the anchor is due, so a flat line
# still has points and every hour still has rows to fold - and a reading that
# differs by any amount at all is written the moment it arrives.
_z.CONFIG['sample_interval'] = 0
_z.CONFIG['sample_anchor_s'] = 900
_when = int(_time.time())
for _i in range(120):                      # an hour of a sensor reporting every 30 s
    _store._write_sample('test:anchor', _when - (120 - _i) * 30,
                         {'temperature': 21.0 if _i < 60 else 22.5})
_store.db.commit()
_kept = _store.db.execute(
    "SELECT ts, value FROM samples WHERE device='test:anchor' ORDER BY ts").fetchall()
assert len(_kept) <= 8, '120 identical-ish readings wrote %d rows' % len(_kept)
assert {r['value'] for r in _kept} == {21.0, 22.5}, 'a value was lost: %r' % {r['value'] for r in _kept}
assert any(abs(r['ts'] - (_when - 60 * 30)) < 31 and r['value'] == 22.5 for r in _kept), \
    'the moment the reading changed was not written down'
_chart = _store.history('test:anchor', ['temperature'], 2 * 3600, 400)
_seen = [r['temperature'] for r in _chart if r.get('temperature') is not None]
assert min(_seen) == 21.0 and max(_seen) == 22.5, 'the chart lost its range'
# and with it off, everything is written as it always was
_z.CONFIG['sample_anchor_s'] = 0
for _i in range(30):
    _store._write_sample('test:every', _when - (30 - _i) * 30, {'temperature': 19.0})
_store.db.commit()
_all = _store.db.execute("SELECT COUNT(*) c FROM samples WHERE device='test:every'").fetchone()['c']
assert _all == 30, 'with the anchor off only %d of 30 readings were written' % _all
_z.CONFIG['sample_anchor_s'] = 900
# ...and with a sample_interval set, where a reading inside the gap replaces
# the row rather than adding one, the memory of what is stored has to follow
# it - or a later reading equal to the value that was replaced would be
# skipped as a repeat of something no longer in the database.
_z.CONFIG['sample_interval'] = 60
_z.CONFIG['sample_anchor_s'] = 900
for _i, _v in enumerate([21.0, 21.5, 22.0]):
    _store._write_sample('test:gap', _when - (300 - _i * 10), {'t': _v})
_store._write_sample('test:gap', _when, {'t': 21.0})       # after the gap, an old value again
_store.db.commit()
_gap = [r['value'] for r in _store.db.execute(
    "SELECT value FROM samples WHERE device='test:gap' ORDER BY ts")]
assert _gap[-1] == 21.0, 'a value seen before was skipped after the gap: %r' % _gap
assert 22.0 in _gap, 'the value that replaced the others inside the gap was lost: %r' % _gap
_z.CONFIG['sample_interval'] = 30
# The chart of what the house is drawing was built from the hourly table
# alone, which is written nightly - so it ended hours ago, often before the
# whole of today, while the card beside it said what the house was drawing a
# moment ago. The two disagreed about the lights all evening.
_z.CONFIG['sample_anchor_s'] = 0
_now = int(_time.time())
for _i in range(90):                       # an hour and a half of two sockets
    _store._write_sample('plug:Test-Lamp', _now - _i * 60, {'switch.apower': 30.0 + (_i % 3)})
    _store._write_sample('plug:Test-Fridge', _now - _i * 60, {'switch.apower': 80.0})
_store.db.commit()


class _Pretend(object):
    def __init__(self, name, role):
        self.name = name
        self.cfg = {'role': role}


_daemon = _z.Daemon.__new__(_z.Daemon)
_daemon.store = _store
_daemon.plugs = {'Test-Lamp': _Pretend('Test-Lamp', 'light'),
                 'Test-Fridge': _Pretend('Test-Fridge', 'plug')}
_series = _daemon.power_series(6 * 3600)
assert _series, 'the chart is empty although the sockets reported this hour'
assert _series[-1]['ts'] >= _now - 3600, \
    'the chart ends %d minute(s) ago while the readings are current' % ((_now - _series[-1]['ts']) // 60)
assert any(r['lights'] > 0 for r in _series), 'the lights are missing from the chart'
assert any(r['sockets'] > 0 for r in _series), 'the sockets are missing from the chart'
_z.CONFIG['sample_anchor_s'] = 900
# Seven hundred thousand country ranges in one transaction hold the only lock
# this database has for as long as it takes to write them, and everything else
# - the status the page asks for twice a second, the charts, the writing down
# of readings - waits behind it. The card went away for half a minute.
_geo_rows = [(_z.pack_address('1.%d.%d.0' % (_i // 256 % 256, _i % 256))[0],
              _z.pack_address('1.%d.%d.255' % (_i // 256 % 256, _i % 256))[0], 4, 'XX')
             for _i in range(60000)]
_worst = [0.0]
_stop = _threading.Event()


def _asker():
    while not _stop.is_set():
        _at = _time.time()
        _store.get_meta('a-thing-nobody-set')
        _worst[0] = max(_worst[0], _time.time() - _at)
        _time.sleep(0.005)


_watcher = _threading.Thread(target=_asker, daemon=True)
_watcher.start()
_store.put_geo(_geo_rows)
_stop.set()
_time.sleep(0.05)
assert _store.geo_size() == 60000, 'the country list was not written whole'
assert _worst[0] < 1.0, \
    'writing the country list held the database for %.1f s - everything else waited' % _worst[0]
_store.put_geo([])
print('the country list is written in pieces, so nothing else waits on it')
print('the chart of what the house is drawing reaches the hour it is in')
print('a reading that has not changed is not written twice, and the one that changes is written at once')

