#!/usr/bin/env python3
"""Sensors, buttons, and the switching that follows: instantly, or not at all.

    python3 test/realtime.py

The house here is a fake Shelly on a port of its own, so the whole chain is
real - the report arrives the way the broker delivers it, the rules and the
bindings run on their own threads, the command goes out over HTTP - and the
only thing left out is the broker itself.

Every check is a stopwatch: a motion report, a button press and a click must
reach the box in milliseconds, and a press must not wait out a poll already on
the wire.
"""
import json
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.argv = ['zigmon']
import zigmon                                            # noqa: E402

BOX = {'output': False, 'sets': [], 'poll_delay': 0.0, 'polls': 0}


class Box(BaseHTTPRequestHandler):
    """A Shelly that answers Switch.Set at once and can be told to be slow."""

    def log_message(self, *a):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
        method, params = body.get('method'), body.get('params') or {}
        if method == 'Switch.Set':
            BOX['sets'].append((time.time(), bool(params.get('on'))))
            was, BOX['output'] = BOX['output'], bool(params.get('on'))
            out = {'was_on': was}
        elif method in ('Shelly.GetStatus', 'Switch.GetStatus'):
            BOX['polls'] += 1
            if BOX['poll_delay']:
                time.sleep(BOX['poll_delay'])
            out = {'switch:0': {'id': 0, 'output': BOX['output'], 'apower': 12.0,
                                'voltage': 231.0, 'aenergy': {'total': 1.0}}}
        elif method == 'Shelly.GetDeviceInfo':
            out = {'id': 'shellyplug-test', 'model': 'S3PL-00112EU', 'gen': 3, 'ver': '1.7.1'}
        else:
            out = {}
        raw = json.dumps({'id': body.get('id'), 'result': out}).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


server = ThreadingHTTPServer(('127.0.0.1', 19871), Box)
threading.Thread(target=server.serve_forever, daemon=True).start()

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-realtime.db'
zigmon.CONFIG['api_port'] = 19872
zigmon.CONFIG['token_file'] = '/tmp/zigmon-realtime-token'
zigmon.CONFIG['pin'] = '1234'
zigmon.CONFIG['plugs'] = []
zigmon.CONFIG['sensors'] = []
zigmon.CONFIG['mqtt_host'] = ''
for old in ('/tmp/zigmon-realtime.db', '/tmp/zigmon-realtime.db-wal', '/tmp/zigmon-realtime.db-shm'):
    Path(old).unlink(missing_ok=True)

d = zigmon.Daemon()
d.store.set_meta('managed', json.dumps({'plugs': [{'name': 'Light-Test', 'host': '127.0.0.1:19871',
                                                   'switch_id': 0, 'kind': 'plug', 'host_state': 'enabled'}],
                                        'sensors': []}))
d.reload_devices()
# the two rule threads, as the daemon starts them
threading.Thread(target=d.rule_worker, name='rules', daemon=True).start()
threading.Thread(target=d.rule_worker, args=(True,), name='rules-presence', daemon=True).start()

FAST_MS = 400          # a whole chain, on one machine, over loopback


def check(ok, what):
    if not ok:
        raise AssertionError(what)


def waited(n=1, limit=3.0):
    """Wait for the box to be told something, and say how long it took."""
    asked = time.time()
    while time.time() - asked < limit:
        if len(BOX['sets']) >= n:
            return (BOX['sets'][n - 1][0] - asked) * 1000
        time.sleep(0.002)
    return None


# -- a PIR sees somebody: the light is on before anybody has taken a step ---------
d.store.upsert_device({'id': 'zigbee:PIR-Test', 'name': 'PIR-Test', 'source': 'zigbee', 'kind': 'sensor',
                       'exposes': {'occupancy': {}}})
d.names['PIR-Test'] = 'zigbee:PIR-Test'        # as the bridge's list would say
d.store.set_meta('rules', json.dumps([{'id': 'r-rt', 'device': 'zigbee:PIR-Test', 'key': 'occupancy',
                                       'op': '=', 'value': 1, 'plug': 'Light-Test', 'do': 'on',
                                       'enabled': True}]))
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': False}).encode())
BOX['sets'] = []
started = time.time()
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': True}).encode())
took = waited(1)
check(took is not None, 'motion never reached the light')
took = (BOX['sets'][0][0] - started) * 1000
check(took < FAST_MS, 'motion took %.0f ms to reach the light' % took)
print('a PIR seeing somebody reaches the light in %.0f ms' % took)

# -- a button press: the relay moves before the finger is off it ------------------
d.store.upsert_device({'id': 'zigbee:Button-Test', 'name': 'Button-Test', 'source': 'zigbee', 'kind': 'button',
                       'exposes': {'action': {}}})
d.names['Button-Test'] = 'zigbee:Button-Test'
d.store.set_meta('bindings', json.dumps([{'device': 'zigbee:Button-Test', 'action': 'single',
                                          'plug': 'Light-Test', 'do': 'off', 'enabled': True}]))
BOX['sets'] = []
started = time.time()
d.handle_zigbee('Button-Test', json.dumps({'action': 'single'}).encode())
check(waited(1) is not None, 'a button press never reached the light')
took = (BOX['sets'][0][0] - started) * 1000
check(took < FAST_MS, 'a button press took %.0f ms to reach the light' % took)
print('a button press reaches the light in %.0f ms' % took)

# -- and a press does not wait out a poll already on the wire ---------------------
# The box is told to take two seconds over its next poll; the press must land
# long before that poll is answered.
BOX['sets'] = []
BOX['poll_delay'] = 2.0
plug = d.plugs['Light-Test']
threading.Thread(target=lambda: plug.rpc().call('Shelly.GetStatus'), daemon=True).start()
time.sleep(0.25)                      # the poll is on the wire now
started = time.time()
d.handle_zigbee('Button-Test', json.dumps({'action': 'single'}).encode())
check(waited(1) is not None, 'a press during a slow poll never reached the light')
took = (BOX['sets'][0][0] - started) * 1000
BOX['poll_delay'] = 0.0
check(took < FAST_MS, 'a press waited %.0f ms for a poll that was already on the wire' % took)
print('a press during a two-second poll still reaches the light in %.0f ms' % took)

# -- what the pages are woken for --------------------------------------------------
# A state - a light, a PIR, a door, a leak - is on the screen at once. The slow
# numbers wake them together, at most twice a second.
woke = []
d.bump = lambda: woke.append('now')
d.bump_soon = lambda delay=0.5: woke.append('soon')
d.store.upsert_device({'id': 'zigbee:Mixed-Test', 'name': 'Mixed-Test', 'source': 'zigbee', 'kind': 'sensor',
                       'exposes': {'state': {}, 'occupancy': {}, 'contact': {}, 'water_leak': {},
                                   'temperature': {}, 'humidity': {}, 'linkquality': {}, 'battery': {}}})
d.names['Mixed-Test'] = 'zigbee:Mixed-Test'
d.handle_zigbee('Mixed-Test',
                json.dumps({'state': 'OFF', 'occupancy': False, 'contact': True, 'water_leak': False,
                            'temperature': 21.0, 'humidity': 40, 'linkquality': 90, 'battery': 100}).encode())
for said, what in (({'state': 'ON'}, 'a light switching'),
                   ({'occupancy': True}, 'a PIR seeing somebody'),
                   ({'contact': False}, 'a door opening'),
                   ({'water_leak': True}, 'a leak')):
    woke[:] = []
    d.handle_zigbee('Mixed-Test', json.dumps(said).encode())
    check(woke == ['now'], '%s waited for the next half second: %r' % (what, woke))
for said, what in (({'temperature': 21.4}, 'a temperature'),
                   ({'humidity': 41}, 'a humidity'),
                   ({'linkquality': 88}, 'a link quality'),
                   ({'battery': 99}, 'a battery level')):
    woke[:] = []
    d.handle_zigbee('Mixed-Test', json.dumps(said).encode())
    check(woke == ['soon'], '%s woke every page on its own: %r' % (what, woke))
# and saying the same thing again wakes nobody twice
woke[:] = []
d.handle_zigbee('Mixed-Test', json.dumps({'state': 'ON'}).encode())
check(woke == ['soon'], 'a light saying the same thing again woke every page: %r' % woke)
print('states are seen at once; the slow numbers wake the pages together')

print('the whole chain: a sensor or a button to the light, and the pages, without a wait')

# ============================================================================
# 5.4: an action put off for a while - "off, then wait 120 s"
# ============================================================================
# A PIR holds its own occupancy for a minute or two after the last movement
# and then says 0. The light should go out some time AFTER that, and not at
# all if somebody moves again in the meantime.
threading.Thread(target=lambda: [d.check_rule_waiting() or time.sleep(0.05) for _ in range(2000)],
                 name='beat', daemon=True).start()
d.store.set_meta('rules', json.dumps([
    {'id': 'r-late', 'device': 'zigbee:PIR-Test', 'key': 'occupancy', 'op': '==', 'value': 0,
     'plug': 'Light-Test', 'do': 'off', 'enabled': True, 'after_s': 2, 'cooldown_s': 0},
]))
d.rule_runtime.pop('r-late', None)
d.rule_waiting.clear()
BOX['sets'] = []
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': True}).encode())    # somebody is there
time.sleep(0.2)
started = time.time()
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': False}).encode())   # ...and gone
time.sleep(0.4)
check(not BOX['sets'], 'the light went off at once, not after the wait')
check('r-late' in d.rule_waiting, 'nothing was put down as waiting')
check(waited(1, limit=4.0) is not None, 'the light never went off')
took = BOX['sets'][0][0] - started
check(1.6 < took < 2.8, 'the wait was %.1f s, not the two it was told' % took)
print('a rule told to wait two seconds switches off after %.1f s' % took)

# ...and somebody moving again calls it off
d.rule_runtime.pop('r-late', None)
d.rule_waiting.clear()
BOX['sets'] = []
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': True}).encode())
time.sleep(0.2)
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': False}).encode())
time.sleep(0.3)
check('r-late' in d.rule_waiting, 'nothing was put down as waiting the second time: %r %r'
      % (d.rule_runtime.get('r-late'), d.rule_waiting))
time.sleep(0.5)
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': True}).encode())    # moved again
time.sleep(0.3)
check('r-late' not in d.rule_waiting, 'the waiting action was not called off by the new movement')
time.sleep(2.2)
check(not BOX['sets'], 'the light went off although somebody had moved again')
print('somebody moving again calls the waiting off, and the light stays on')

# ...and the waiting starts again from the last time it became true
d.rule_runtime.pop('r-late', None)
d.rule_waiting.clear()
BOX['sets'] = []
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': False}).encode())
time.sleep(0.3)
_first_due = d.rule_waiting['r-late']['due']
time.sleep(0.6)
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': True}).encode())
time.sleep(0.2)
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': False}).encode())
time.sleep(0.3)
check(d.rule_waiting['r-late']['due'] > _first_due + 0.4,
      'the waiting was not counted again from the last movement')
d.rule_waiting.clear()
print('the wait is counted from the last time the condition became true')

# ...and what is waiting is said in the status, so the page can count it down
d.rule_runtime.pop('r-late', None)
BOX['sets'] = []
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': True}).encode())
time.sleep(0.2)
d.handle_zigbee('PIR-Test', json.dumps({'occupancy': False}).encode())
time.sleep(0.3)
_said = next(x for x in d.status()['rules'] if x['id'] == 'r-late')
check(_said.get('waiting_s') is not None and _said['waiting_s'] <= 2,
      'the status does not say what is waiting: %r' % _said.get('waiting_s'))
_why = d.rule_why('r-late') if hasattr(d, 'rule_why') else None
d.rule_waiting.clear()
d.rule_runtime.pop('r-late', None)
print('what is waiting to happen is in the status, with the seconds left')

# ...a rule switched off while something of its own is waiting does nothing
d.store.set_meta('rules', json.dumps([
    {'id': 'r-late', 'device': 'zigbee:PIR-Test', 'key': 'occupancy', 'op': '==', 'value': 0,
     'plug': 'Light-Test', 'do': 'off', 'enabled': False, 'after_s': 1, 'cooldown_s': 0},
]))
d.rule_waiting['r-late'] = {'due': time.time() - 1, 'origin': 'a test', 'facts': {},
                            'device_id': 'zigbee:PIR-Test', 'do': 'off', 'at': time.time()}
BOX['sets'] = []
d.check_rule_waiting()
check('r-late' not in d.rule_waiting and not BOX['sets'],
      'a rule switched off still did what it had waiting')
print('a rule switched off while it was waiting does nothing when the moment comes')

server.shutdown()
