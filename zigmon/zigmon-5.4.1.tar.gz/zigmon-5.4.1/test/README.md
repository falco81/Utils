# Development checks

Nothing here ships to the server.

* `replay.py` — feeds the daemon real Zigbee2MQTT and Shelly messages without
  a broker, then exercises every API endpoint including wrong PIN and token.
  Run with a scratch configuration:

      cat > /tmp/zt.json <<'JSON'
      {"db_file": "/tmp/zt.db", "token_file": "/tmp/zt-token", "log_file": "/tmp/zt.log",
       "api_port": 19849, "pin": "1234", "sample_interval": 0, "log_to_journal": false}
      JSON
      ZIGMON_CONFIG=/tmp/zt.json PYTHONPATH=. python3 test/replay.py

* `render.js` — drives the dashboard in jsdom against a running daemon and
  `php -S 127.0.0.1:8099 -t web`, walks every tab, renders the charts, goes
  through the PIN dialogue and reports any JavaScript error.

      npm install jsdom && node test/render.js

* `mockplug.py PORT [PASSWORD]` — a Shelly Plug M Gen3 lookalike: `/rpc` with
  SHA-256 digest authentication, a switch, counters and resets. Point a plug
  entry at `127.0.0.1:PORT` to exercise polling, switching, resets and
  button bindings without hardware.

## endpoints.py

`python3 test/endpoints.py` — every `/api/...` path the web relay forwards
must be one the daemon serves, and in the branch that matches the method.
Needs nothing running; it reads the two files. It exists because *Put back*
once shipped answering "no such endpoint": the handler had been written into
the read branch while the page posted to it.

## mocksms.py

`python3 test/mocksms.py 18110 [user] [password]` — a Teltonika-lookalike SMS
gateway: `/cgi-bin/sms_send`, `/cgi-bin/sms_list`, `/cgi-bin/sms_delete` with
the same query parameters and the same plain-text listing. `GET /` returns
what it was asked to send, `POST /inbox {"from":…,"text":…}` puts a message
in for the daemon to find, `POST /reset` empties both. Enough to test alerts
going out and commands coming in without a SIM card.

## facts.py

`python3 test/facts.py` — every `{fact}` the daemon fills must appear in the
page's picker, and every one the picker offers must be filled. The two drifted
apart once: the picker advertised `{sunrise}`, `{sunset}` and `{daylight}`
while the daemon filled none of them, so a message quoting them arrived with
the words simply missing.

## objects.py

`PYTHONPATH=. python3 test/objects.py` — everything as an object: every kind
of thing in the house has an address `type:id` that stays when it is renamed,
properties, functions and procedures; `{Name.member}` reads them; a name two
kinds share goes to the one it always meant (a room over a link called the
same); and no secret, token or password is in anything the object view sends,
while a phone number needs the PIN. An address on the blocked list and a
Wi-Fi client are objects by their address (kept out, let back in, given to a
person), and a scene's steps are read and set as one line that loses nothing.

## realtime.py

`python3 test/realtime.py` - a sensor, a button and the light that follows,
with a stopwatch. A fake Shelly on a port of its own, the rules and the
bindings on their own threads, the command over HTTP: motion to the light,
a press to the relay, and a press while a two-second poll is already on the
wire (which used to wait the poll out). It also checks what the pages are
woken for - a light's state, a PIR, a door, a leak at once; a temperature, a
humidity, a link quality and a battery together.

## bugs.py

`PYTHONPATH=. python3 test/bugs.py` — the faults a read through the whole
application found in 4.94, each proved on its own: targets written as text,
presence triggers, lists switched off, the open door and the flat battery,
per-caller PIN lockout, sequences pressed twice, the texts counted today,
a Shelly's online word, restoring the oldest backup, and over HTTP the
switched-off view, keys with no PIN, a device's detail, a bad tap and the
mesh scan.

## nginx.py

`python3 test/nginx.py` — the shipped nginx file, read for the things nginx
itself would refuse: an unquoted brace in a location pattern, a rewrite using
`$1` while capturing nothing, a `gzip_types` naming `text/html`, unbalanced
braces, and anything inside an `if` block that nginx does not allow there. A
fault in this file stops the web server and takes every other site on the
machine with it, which is worse than any fault inside the dashboard — and
`default_type` inside an `if` did exactly that once.

## taps.py

`ZIGMON_CONFIG=… PYTHONPATH=. python3 test/taps.py` — the one-tap links: all
three positions of the switch, both roads, and the code. It checks the TOTP
maths against the four test vectors in RFC 6238, that a code is taken for its
own window and one step either side and never after, that the second press
inside one code works, that a road which is shut answers word for word what an
unknown link answers, that no code secret leaves with the status, and that
asking for a code with no phone to show one is refused with neither setting
left half-changed.

## completer.js

`node test/completer.js` — the `{…}` completer, lifted out of `index.php` and
run against a made-up dashboard; it needs neither php nor a running daemon.
For each of eleven things typed it checks what is offered and where what is
chosen lands. `{PIR-Chodba.model.nl}` could not be written before it existed:
a dot after a device's reading offered nothing, and what was picked was put
back over everything after the first dot, so a turn chosen there turned
`{Name.model.nl}` into `{Name.nl}`.

## listeners.py

`python3 test/listeners.py` — a listener put on the whole page from inside a
function runs as often as that function is called, so it has to come off
again. `showDialog` added an Escape handler every time it opened and took it
off only when the dialog was closed with Escape; closed with *OK* or by
clicking outside, it stayed, and the next dialog added another. An unnamed
function cannot be taken off at all and is refused outright.

## columns.py

`python3 test/columns.py` — reads the page's own stylesheet. Every table on
Control is a grid per row, so a column left to size itself by what it holds
is answered separately in each of them: the gateways' header, whose last cell
is empty, gave that width to the five columns above the boxes and stood every
name to the right of what it named — a hundred and fifty pixels of it by
*Target*. A content-sized column is allowed only through a variable measured
off the page and handed to the header and all the rows alike, and the test
insists something really sets it. It also counts the header's cells against
the row's columns.

## version.py

`python3 test/version.py` — zigmon.py, install.sh and README.md must state
the same version. They drifted apart once: a release script replaced a string
that had moved, said nothing about it, and several releases went out carrying
an old number inside a differently named file.

`mocksms.py` also speaks RutOS 7's own API — `/api/login`, `/api/modems/status`,
`/api/modems/signal/status`, `/api/messages/status`,
`/api/messages/actions/send` — with the same rules the device enforces: a
Bearer token that expires, a required `modem` field, and a number that must
carry its country code behind a `+`. That is what a TRB140 offers out of the
box, so it is what the tests use.

`zigmon --check-sms` walks the whole road to the gateway — the settings, the
device, the SIM, the signal, who would be told, who may command, what a text
may do, and whether anything is stuck — and ends with a list of what to do
about whatever failed.

## inputs.py

`python3 test/inputs.py` — every setting the page draws must be the kind of
box the daemon says it is. The page used to keep its own idea of which
settings were yes-or-no questions and fell behind, so two were drawn as number
boxes asking for a 1 or a 0.

## tables.py

The tables the daemon keeps by hand — KEY_INFO, the weather words, the
notification presets — must not say the same thing twice: Python keeps the
last of two entries with the same key, so an earlier one is dead text that
can be edited to no effect. Three had crept into KEY_INFO before this
existed. It also refuses a class with the same method defined twice.

## switches.py

Every switch tried both ways, watching what the daemon *does* rather than
what was stored. The debug switch was saved, shown on the page and ignored
for its whole life because nothing ever checked that turning it on changed
anything; this is that check.

## roundtrip.py

Writes something distinctive into a field of every editor, saves it through
the same path the page uses, and asks for it back. A control can be wired to
a record and the record can be saved while the field is quietly dropped on
the way, by a validator that does not know it or a reader that never looks.
It also proves a scene can be called Ložnice večer.

## nginx.py

The shipped nginx file, read for what nginx itself would refuse: a brace in an
unquoted location pattern (which nginx reads as the end of the block, cutting
the expression in half), text/html named in gzip_types, unbalanced braces, a
pattern that is not a regular expression. A mistake here stops the web server
rather than the dashboard, which takes everything else on that machine with
it.
