<?php
/**
 * index.php — sensor dashboard.
 *
 * Renders from the daemon's snapshot and refreshes itself over the small JSON
 * endpoints below. It does nothing privileged: no shell, no broker
 * credentials, no direct access to MQTT.
 */
declare(strict_types=1);

require_once __DIR__ . '/zigmon-api.php';

/**
 * PHP falls back to UTC when date.timezone isn't set, which makes every
 * timestamp here disagree with the server's own clock. Follow the system zone.
 */
function use_system_timezone(): void
{
    $set = (string) ini_get('date.timezone');
    if ($set !== '' && strcasecmp($set, 'UTC') !== 0) {
        return;
    }
    $tz = '';
    if (is_readable('/etc/timezone')) {
        $tz = trim((string) @file_get_contents('/etc/timezone'));
    }
    if ($tz === '' && is_link('/etc/localtime')) {
        $target = (string) @readlink('/etc/localtime');
        if (preg_match('#zoneinfo/(.+)$#', $target, $m)) {
            $tz = $m[1];
        }
    }
    if ($tz !== '' && in_array($tz, timezone_identifiers_list(), true)) {
        date_default_timezone_set($tz);
    }
}
use_system_timezone();

// ---- JSON endpoints the page polls ---------------------------------------
if (isset($_GET['api'])) {
    $what = (string) $_GET['api'];

    if ($what === 'status') {
        zigmon_relay('/api/status');
        exit;
    }
    if ($what === 'health') {
        zigmon_relay('/api/health');
        exit;
    }
    if ($what === 'device') {
        $id = (string) ($_GET['id'] ?? '');
        zigmon_relay('/api/device?id=' . rawurlencode($id));
        exit;
    }
    if ($what === 'history') {
        $device = (string) ($_GET['device'] ?? '');
        $range  = preg_replace('/[^0-9smhdwy.]/', '', (string) ($_GET['range'] ?? '24h'));
        $points = max(50, min(3000, (int) ($_GET['points'] ?? 600)));
        $keys   = preg_replace('/[^A-Za-z0-9_.,:-]/', '', (string) ($_GET['keys'] ?? ''));
        zigmon_relay('/api/history?device=' . rawurlencode($device) . '&range=' . rawurlencode($range)
                     . '&points=' . $points . ($keys !== '' ? '&keys=' . rawurlencode($keys) : ''),
                     'GET', null, 30.0);
        exit;
    }
    if ($what === 'events') {
        $limit = max(1, min(1000, (int) ($_GET['limit'] ?? 200)));
        $device = (string) ($_GET['device'] ?? '');
        zigmon_relay('/api/events?limit=' . $limit
                     . ($device !== '' ? '&device=' . rawurlencode($device) : ''));
        exit;
    }
    if ($what === 'plugs') {
        zigmon_relay('/api/plugs');
        exit;
    }
    if ($what === 'plug') {
        $name = (string) ($_GET['name'] ?? '');
        zigmon_relay('/api/plug?name=' . rawurlencode($name) . (!empty($_GET['refresh']) ? '&refresh=1' : ''), 'GET', null, 20.0);
        exit;
    }
    if ($what === 'bindings') {
        zigmon_relay('/api/bindings');
        exit;
    }
    if ($what === 'managed') {
        zigmon_relay('/api/managed');
        exit;
    }
    if ($what === 'rules') {
        zigmon_relay('/api/rules');
        exit;
    }
    if ($what === 'order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = [
            'plugs'   => array_values(array_map('strval', (is_array($in) && isset($in['plugs']) && is_array($in['plugs'])) ? $in['plugs'] : [])),
            'devices' => array_values(array_map('strval', (is_array($in) && isset($in['devices']) && is_array($in['devices'])) ? $in['devices'] : [])),
        ];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/order', 'POST', $body, 10.0);
        exit;
    }
    if ($what === 'rename' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['id' => (string) ($in['id'] ?? ''), 'name' => (string) ($in['name'] ?? '')];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/device/rename', 'POST', $body, 15.0);
        exit;
    }
    if ($what === 'wait') {
        $seq = (int) ($_GET['seq'] ?? 0);
        zigmon_relay('/api/wait?seq=' . $seq . '&timeout=25', 'GET', null, 30.0);
        exit;
    }
    if ($what === 'rules-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $clean = [];
        foreach ((is_array($in) && isset($in['rules']) && is_array($in['rules'])) ? $in['rules'] : [] as $r) {
            if (!is_array($r)) {
                continue;
            }
            $row = [
                'id'         => (string) ($r['id'] ?? ''),
                'device'     => (string) ($r['device'] ?? ''),
                'key'        => (string) ($r['key'] ?? ''),
                'op'         => (string) ($r['op'] ?? '>='),
                'value'      => (float) ($r['value'] ?? 0),
                'plug'       => (string) ($r['plug'] ?? ''),
                'do'         => (string) ($r['do'] ?? 'on'),
                'cooldown_s' => (int) ($r['cooldown_s'] ?? 300),
                'from'       => (string) ($r['from'] ?? ''),
                'to'         => (string) ($r['to'] ?? ''),
                'window_end' => (string) ($r['window_end'] ?? ''),
                'enabled'    => !isset($r['enabled']) || !empty($r['enabled']),
            ];
            if ($row['do'] === 'pulse') {
                $row['pulse_ms'] = (int) ($r['pulse_ms'] ?? 5000);
            }
            $clean[] = $row;
        }
        $body = ['rules' => $clean];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/rules', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'managed-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['plugs' => [], 'sensors' => []];
        foreach (['plugs', 'sensors'] as $kind) {
            foreach ((is_array($in) && isset($in[$kind]) && is_array($in[$kind])) ? $in[$kind] : [] as $e) {
                if (!is_array($e)) {
                    continue;
                }
                $row = [
                    'name'      => (string) ($e['name'] ?? ''),
                    'host'      => (string) ($e['host'] ?? ''),
                    'switch_id' => (int) ($e['switch_id'] ?? 0),
                    'mqtt_name' => (string) ($e['mqtt_name'] ?? ''),
                    'source'    => (string) ($e['source'] ?? 'ui'),
                    'enabled'   => !isset($e['enabled']) || !empty($e['enabled']),
                ];
                if (isset($e['password']) && $e['password'] !== '') {
                    $row['password'] = (string) $e['password'];
                }
                if (!empty($e['clear_password'])) {
                    $row['clear_password'] = true;
                }
                $body[$kind][] = $row;
            }
        }
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/managed', 'POST', $body, 30.0);
        exit;
    }
    if ($what === 'managed-test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['host' => (string) ($in['host'] ?? ''), 'password' => (string) ($in['password'] ?? '')];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/managed/test', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'managed-discover' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = [];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/managed/discover', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'plug-switch' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['name' => (string) ($in['name'] ?? '')];
        if (!empty($in['pulse'])) {
            $body['pulse'] = true;
            $body['ms'] = max(100, min(3600000, (int) ($in['ms'] ?? 5000)));
        } elseif (!empty($in['toggle'])) {
            $body['toggle'] = true;
        } else {
            $body['on'] = !empty($in['on']);
        }
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/plug/switch', 'POST', $body, 30.0 + (!empty($body['pulse']) ? $body['ms'] / 1000.0 : 0));
        exit;
    }
    if ($what === 'plug-reset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['name' => (string) ($in['name'] ?? '')];
        $allowed = ['aenergy', 'ret_aenergy', 'on_time', 'switch_on', 'on_above_thr'];
        $body['types'] = (is_array($in) && isset($in['types']) && is_array($in['types']))
            ? array_values(array_intersect($in['types'], $allowed)) : [];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/plug/reset', 'POST', $body, 60.0);
        exit;
    }
    if ($what === 'bindings-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $clean = [];
        foreach ((is_array($in) && isset($in['bindings']) && is_array($in['bindings'])) ? $in['bindings'] : [] as $b) {
            if (!is_array($b)) {
                continue;
            }
            $row = [
                'device'  => (string) ($b['device'] ?? ''),
                'action'  => (string) ($b['action'] ?? ''),
                'plug'    => (string) ($b['plug'] ?? ''),
                'do'      => (string) ($b['do'] ?? 'toggle'),
                'enabled' => !isset($b['enabled']) || !empty($b['enabled']),
            ];
            if ($row['do'] === 'pulse') {
                $row['pulse_ms'] = (int) ($b['pulse_ms'] ?? 5000);
            }
            $clean[] = $row;
        }
        $body = ['bindings' => $clean];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/bindings', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'unlock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['pin' => (string) ($in['pin'] ?? ''), 'minutes' => max(1, min(720, (int) ($in['minutes'] ?? 15)))];
        zigmon_relay('/api/unlock', 'POST', $body, 10.0);
        exit;
    }
    if ($what === 'lock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        zigmon_relay('/api/lock', 'POST', ['session' => (string) ($in['session'] ?? '')], 10.0);
        exit;
    }
    if ($what === 'permit-join' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['enable' => !empty($in['enable']), 'time' => 254];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (is_array($in) && isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/permit-join', 'POST', $body, 15.0);
        exit;
    }
    if ($what === 'reset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $scope = (string) ($in['scope'] ?? '');
        if (!in_array($scope, ['all', 'history', 'events', 'device'], true)) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad scope']);
            exit;
        }
        $body = ['scope' => $scope];
        if (isset($in['device'])) {
            $body['device'] = (string) $in['device'];
        }
        if (isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        if (isset($in['session'])) {
            $body['session'] = (string) $in['session'];
        }
        zigmon_relay('/api/reset', 'POST', $body, 120.0);
        exit;
    }
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'unknown endpoint']);
    exit;
}

// ---- The page ------------------------------------------------------------
$status  = zigmon_get('/api/status', 5.0);
$initial = $status ? json_encode($status, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) : 'null';
$host    = (string) ($_SERVER['HTTP_HOST'] ?? php_uname('n'));

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="dark">
<title>Sensors — <?= h($host) ?></title>
<link rel="icon" href="favicon.svg" type="image/svg+xml" id="favicon">
<meta name="theme-color" content="#161b22">
<style>
  :root{
    --bg:#0d1117; --panel:#161b22; --panel2:#1c222b; --line:#262c37;
    --tx:#e6e9ef; --tx-dim:#8b94a3; --tx-mut:#5b6472;
    --ok:#3fb950; --warn:#d29922; --crit:#f85149; --info:#58a6ff;
    --batt:#a371f7; --load:#f0883e; --sleep:#6e7681;
    --ok-bg:rgba(63,185,80,.12); --warn-bg:rgba(210,153,34,.12);
    --crit-bg:rgba(248,81,73,.13); --info-bg:rgba(88,166,255,.12);
    --r:14px;
  }
  *{box-sizing:border-box}
  html{-webkit-text-size-adjust:100%}
  body{margin:0;background:var(--bg);color:var(--tx);
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    -webkit-font-smoothing:antialiased;
    padding:26px max(16px,env(safe-area-inset-left)) 56px}
  .wrap{max-width:1280px;margin:0 auto}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}

  header{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:16px}
  header h1{font-size:20px;margin:0;font-weight:650;letter-spacing:.2px}
  header .host{color:var(--tx-dim);font-weight:400}
  .spacer{flex:1}
  .updated{color:var(--tx-mut);font-size:13px;text-align:right;line-height:1.35;cursor:pointer;user-select:none}
  .updated b{color:var(--tx-dim);font-weight:600}
  .updated.paused b{color:var(--warn)}

  .tabs{display:flex;gap:4px;margin-bottom:20px;border-bottom:1px solid var(--line);flex-wrap:wrap}
  .tabs button{appearance:none;background:none;border:0;border-bottom:2px solid transparent;
    color:var(--tx-dim);font:inherit;font-weight:600;font-size:14px;padding:9px 15px;
    cursor:pointer;border-radius:8px 8px 0 0;transition:color .15s,border-color .15s}
  .tabs button:hover{color:var(--tx)}
  .tabs button[aria-selected="true"]{color:var(--info);border-bottom-color:var(--info)}
  .panel[hidden]{display:none}

  .pill{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:999px;
        font-weight:600;font-size:14px;border:1px solid transparent}
  .pill .dot{width:9px;height:9px;border-radius:50%;flex:0 0 auto}
  .pill.ok{background:var(--ok-bg);color:var(--ok);border-color:rgba(63,185,80,.3)}
  .pill.warn{background:var(--warn-bg);color:var(--warn);border-color:rgba(210,153,34,.3)}
  .pill.crit{background:var(--crit-bg);color:var(--crit);border-color:rgba(248,81,73,.3)}
  .pill.unknown{background:var(--panel2);color:var(--tx-dim)}
  .pill.ok .dot{background:var(--ok)} .pill.warn .dot{background:var(--warn)}
  .pill.crit .dot{background:var(--crit);animation:pulse 1.4s infinite}
  .pill.unknown .dot{background:var(--tx-mut)}
  .lockpill{appearance:none;display:inline-flex;align-items:center;gap:7px;padding:7px 13px;border-radius:999px;
    font:inherit;font-weight:600;font-size:13px;cursor:pointer;border:1px solid var(--line);
    background:var(--panel2);color:var(--tx-dim);transition:color .15s,border-color .15s,background .15s}
  .lockpill:hover{border-color:var(--tx-dim);color:var(--tx)}
  .lockpill[hidden]{display:none}
  .lockpill.unlocked{background:var(--warn-bg);color:var(--warn);border-color:rgba(210,153,34,.4)}
  .lockpill.unlocked .lockpill-time{font-family:ui-monospace,Menlo,Consolas,monospace;font-variant-numeric:tabular-nums}
  body.locked .needs-unlock{opacity:.55}
  body.locked .needs-unlock:not(:disabled){cursor:pointer}
  .unlockbox{margin:12px 0 4px;display:flex;gap:10px;justify-content:center;align-items:center;font-size:13px;color:var(--tx-dim)}
  .unlockbox[hidden]{display:none}
  .unlockbox select{padding:7px 30px 7px 12px}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}

  .grid{display:grid;gap:14px}
  .top{grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}
  .devices{grid-template-columns:repeat(auto-fill,minmax(270px,1fr))}
  .charts{grid-template-columns:repeat(auto-fit,minmax(460px,1fr))}
  .full{grid-column:1/-1}
  @media (max-width:560px){.charts{grid-template-columns:1fr}}

  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:17px 19px}
  .card h2{margin:0 0 13px;font-size:12px;font-weight:700;letter-spacing:.7px;
           text-transform:uppercase;color:var(--tx-mut)}
  .card h2 .right{float:right;font-weight:600;letter-spacing:0;text-transform:none;color:var(--tx-dim)}

  .metric .label{font-size:12px;font-weight:700;letter-spacing:.7px;text-transform:uppercase;
                 color:var(--tx-mut);margin-bottom:9px}
  .metric .value{font-size:30px;font-weight:680;line-height:1.05;letter-spacing:-.5px}
  .metric .value .unit{font-size:16px;font-weight:600;color:var(--tx-dim);margin-left:3px}
  .metric .sub{color:var(--tx-dim);font-size:13px;margin-top:6px}
  .metric.ok .value{color:var(--ok)} .metric.warn .value{color:var(--warn)}
  .metric.crit .value{color:var(--crit)}

  .dev{display:flex;flex-direction:column;gap:10px;cursor:pointer;transition:border-color .15s}
  .dev:hover{border-color:var(--info)}
  .dev.crit{border-color:rgba(248,81,73,.45)} .dev.warn{border-color:rgba(210,153,34,.4)}
  .dev .head{display:flex;align-items:flex-start;gap:10px}
  .dev .name{font-weight:650;font-size:16px;line-height:1.25}
  .dev .model{color:var(--tx-dim);font-size:12.5px}
  .dev .readings{display:flex;flex-wrap:wrap;gap:6px 18px;align-items:baseline}
  .dev .reading .v{font-size:28px;font-weight:680;letter-spacing:-.5px;line-height:1.05}
  .dev .reading .v .unit{font-size:14px;font-weight:600;color:var(--tx-dim);margin-left:2px}
  .dev .reading .l{font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .dev .reading.small .v{font-size:19px}
  .dev .foot{display:flex;flex-wrap:wrap;gap:6px 12px;font-size:12.5px;color:var(--tx-dim);align-items:center}
  .dev .foot .reason{color:var(--warn)}
  .dev.crit .foot .reason{color:var(--crit)}
  .dev.stale .reading .v{color:var(--tx-dim)}

  .bar{height:6px;border-radius:99px;background:var(--panel2);overflow:hidden;flex:1;min-width:60px}
  .bar span{display:block;height:100%;border-radius:99px;transition:width .4s ease}
  .batt{display:flex;align-items:center;gap:8px;min-width:120px}

  .kv{display:flex;justify-content:space-between;align-items:baseline;padding:5px 0;
      font-size:14px;gap:12px;border-bottom:1px solid rgba(38,44,55,.5)}
  .kv:last-child{border-bottom:0}
  .kv .k{color:var(--tx-dim)} .kv .v{font-weight:600;text-align:right}
  .kv .d{display:block;color:var(--tx-mut);font-size:12px;font-weight:400}

  table{width:100%;border-collapse:collapse;font-size:13.5px}
  th{text-align:left;font-size:11px;letter-spacing:.7px;text-transform:uppercase;
     color:var(--tx-mut);font-weight:700;padding:6px 10px 6px 0;border-bottom:1px solid var(--line)}
  td{padding:7px 10px 7px 0;border-bottom:1px solid rgba(38,44,55,.55);vertical-align:top}
  tr:last-child td{border-bottom:0}
  td.num{text-align:right;font-family:ui-monospace,Menlo,Consolas,monospace}
  .scroll{overflow-x:auto}

  .tag{display:inline-block;padding:1px 7px;border-radius:6px;font-size:11px;font-weight:700;
       letter-spacing:.4px;text-transform:uppercase;white-space:nowrap}
  .tag.ok{background:var(--ok-bg);color:var(--ok)}
  .tag.warn{background:var(--warn-bg);color:var(--warn)}
  .tag.crit{background:var(--crit-bg);color:var(--crit)}
  .tag.info{background:var(--info-bg);color:var(--info)}
  .tag.dim{background:var(--panel2);color:var(--tx-dim)}
  .tag.zb{background:rgba(163,113,247,.14);color:var(--batt)}

  .btn{appearance:none;border:1px solid var(--line);background:var(--panel2);color:var(--tx);
       font:inherit;font-weight:600;font-size:13.5px;padding:9px 15px;border-radius:10px;
       cursor:pointer;transition:border-color .15s,background .15s,transform .05s}
  .btn:hover:not(:disabled){border-color:var(--info);color:var(--info)}
  .btn:active:not(:disabled){transform:translateY(1px)}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn.danger:hover:not(:disabled){border-color:var(--crit);color:var(--crit)}
  .btn.primary{background:var(--info-bg);border-color:rgba(88,166,255,.35);color:var(--info)}
  .btn.small{padding:5px 10px;font-size:12.5px;border-radius:8px}
  .btn.on{background:var(--info-bg);border-color:var(--info);color:var(--info)}
  .btn.busy{opacity:.6;cursor:progress}
  .btnrow{display:flex;gap:9px;flex-wrap:wrap}
  .btn.cmd{display:inline-flex;align-items:center;gap:9px;padding:10px 16px}
  .btn.cmd.small{padding:6px 12px;gap:7px}
  .btn.iconbtn{padding:6px 9px;line-height:0}
  .btn.cmd svg{flex:0 0 auto;opacity:.85}
  .btn.cmd:hover:not(:disabled) svg{opacity:1}
  .btnhelp{color:var(--tx-mut);font-size:12.5px;margin:6px 0 16px}
  .hint{position:fixed;z-index:200;max-width:min(340px,88vw);
    background:linear-gradient(160deg,#1b2230 0%,#141922 100%);
    border:1px solid #2b3444;border-radius:12px;padding:11px 14px;
    font-size:12.5px;line-height:1.5;color:var(--tx-dim);
    box-shadow:0 14px 40px rgba(0,0,0,.55);
    opacity:0;transform:translateY(4px);transition:opacity .14s,transform .14s;
    pointer-events:none}
  .hint.show{opacity:1;transform:none}
  .hint b{color:var(--tx);font-weight:600;font-family:ui-monospace,Menlo,Consolas,monospace}
  .hint em{color:var(--crit);font-style:normal}
  .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
  select{appearance:none;background:var(--panel2);color:var(--tx);border:1px solid var(--line);
         font:inherit;font-size:13.5px;font-weight:600;padding:8px 32px 8px 12px;border-radius:10px;
         background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='%238b94a3' d='M4 6l4 4 4-4'/%3E%3C/svg%3E");
         background-repeat:no-repeat;background-position:right 10px center;background-size:14px}

  .chart{position:relative;width:100%;height:240px}
  .chart svg{width:100%;height:100%;display:block}
  .chart .empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
                color:var(--tx-mut);font-size:13.5px}
  .chart .tip{position:absolute;pointer-events:none;background:#0d1117ee;border:1px solid var(--line);
              border-radius:9px;padding:7px 10px;font-size:12.5px;line-height:1.4;white-space:nowrap;
              display:none;z-index:2;box-shadow:0 6px 20px rgba(0,0,0,.35)}
  .chart .tip b{font-weight:650}
  .chart .tip .sw{display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:6px;vertical-align:middle}
  .chart svg{cursor:grab;touch-action:none}
  .chart.dragging svg{cursor:grabbing}
  .chart.dragging{user-select:none}
  .chint{position:absolute;top:6px;right:8px;font-size:11.5px;color:var(--tx-mut);
    background:rgba(13,17,23,.82);padding:3px 9px;border-radius:7px;pointer-events:none;opacity:0;transition:opacity .18s}
  .chart:hover .chint{opacity:1}
  .creset{position:absolute;top:4px;left:50px;font-size:11.5px;padding:3px 10px;border-radius:7px;
    border:1px solid var(--line);background:var(--panel2);color:var(--tx-dim);cursor:pointer;font-family:inherit}
  .creset:hover{color:var(--info);border-color:var(--info)}
  .creset[hidden]{display:none}
  .legend{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12.5px;color:var(--tx-dim);margin-top:6px}
  .legend .sw{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}

  /* the socket panel: state on the left, live figures on the right */
  /* one full-width row per plug, stacked - the figures spread out to the right */
  .sockets{display:flex;flex-direction:column;gap:12px;margin-bottom:14px}
  .card.socket .socket-state{min-width:280px}
  .socket-figures{justify-content:flex-end}
  @media (max-width:700px){.socket-figures{justify-content:flex-start}}
  .card.socket{display:flex;align-items:center;gap:22px;flex-wrap:wrap;padding:18px 20px}
  .socket-state{display:flex;align-items:center;gap:14px;min-width:200px}
  .socket-toggle{appearance:none;cursor:pointer;width:58px;height:58px;border-radius:50%;display:grid;place-items:center;
    flex:0 0 auto;border:2px solid var(--line);background:var(--panel2);color:var(--tx-mut);
    transition:color .2s,border-color .2s,background .2s,box-shadow .2s}
  .socket-toggle:hover:not(:disabled){border-color:var(--tx-dim)}
  .socket-toggle:disabled{cursor:progress;opacity:.6}
  .card.socket.on .socket-toggle{color:var(--ok);border-color:rgba(63,185,80,.55);background:rgba(63,185,80,.12);box-shadow:0 0 0 6px rgba(63,185,80,.07)}
  .card.socket.off .socket-toggle{color:var(--tx-mut)}
  .card.socket.stale .socket-figures{opacity:.45}
  .card.socket.stale .socket-label{color:var(--warn)}
  .card.socket.stale .socket-toggle{color:var(--warn);border-color:rgba(210,153,34,.45);background:rgba(210,153,34,.10);box-shadow:none}
  .socket-label{font-size:19px;font-weight:680;letter-spacing:-.2px}
  .card.socket.on .socket-label{color:var(--ok)} .card.socket.off .socket-label{color:var(--tx-dim)}
  .socket-sub{font-size:12.5px;margin-top:2px;color:var(--tx-dim)}
  .socket-figures{display:flex;gap:20px;flex-wrap:wrap;flex:1}
  .socket-figures div{min-width:70px}
  .socket-figures .k{font-size:11px;letter-spacing:.7px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .socket-figures .v{font-size:18px;font-weight:650;margin-top:2px}
  .bind-row{display:grid;grid-template-columns:1.4fr 1fr 1.2fr 1fr .9fr auto;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .bind-row .ms{display:flex;align-items:center;gap:6px;visibility:hidden}
  .bind-row .ms.show{visibility:visible}
  .bind-row .ms input{width:100%}
  .bind-row .ms span{color:var(--tx-mut);font-size:12px}
  .bind-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%}
  .bind-row input:focus,select:focus{outline:none;border-color:var(--info)}
  .bind-row select{width:100%}
  .dev-row{display:grid;grid-template-columns:.55fr 1.15fr 1.15fr 1fr 52px .95fr .8fr 84px 112px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .dev-row .btn.cmd{width:100%;justify-content:center}
  body:not(.locked) .cangrab{cursor:grab}
  .draggingcard{opacity:.45;outline:1.5px dashed var(--info);outline-offset:2px}
  .foot .via{color:var(--info);opacity:.85}
  .sig{display:inline-flex;align-items:flex-end;gap:2px;height:13px;margin-right:7px;vertical-align:-1px}
  .sig i{width:3.5px;border-radius:1px;background:var(--line)}
  .sig i:nth-child(1){height:4px}.sig i:nth-child(2){height:7px}.sig i:nth-child(3){height:10px}.sig i:nth-child(4){height:13px}
  .sig.q4 i,.sig.q3 i:nth-child(-n+3),.sig.q2 i:nth-child(-n+2),.sig.q1 i:nth-child(1){background:var(--sigc)}
  .sigwrap{display:inline-flex;align-items:center}
  .managed-sub{margin:16px 0 2px;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--tx-mut)}
  .managed-sub:first-child{margin-top:4px}
  .dev-row input,.dev-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%}
  .dev-row input:focus{outline:none;border-color:var(--info)}
  .dev-row input:disabled,.dev-row select:disabled{opacity:.55}
  .dev-row .state{font-size:12px;white-space:nowrap}
  @media (max-width:900px){.dev-row{grid-template-columns:1fr 1fr 1fr;} .dev-head{display:none}}
  .rule-row{display:grid;grid-template-columns:1.1fr 1fr .55fr .7fr 1fr .9fr .7fr auto;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .rule-row input,.rule-row select{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%}
  .rule-row input:focus{outline:none;border-color:var(--info)}
  .rule-row .now{font-size:11.5px;color:var(--tx-mut);white-space:nowrap}
  .rule-row .now b{color:var(--warn)}
  .rule-sub{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:2px 0 10px 4px;margin-top:-2px;
    border-bottom:1px solid rgba(38,44,55,.5);font-size:12.5px;color:var(--tx-dim)}
  .rule-sub .muted{font-size:11.5px}
  .rule-sub input[type=time]{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 8px}
  .rule-sub select{font:inherit;font-size:12.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 26px 5px 9px}
  .rule-row{border-bottom:none}
  @media (max-width:900px){.rule-row{grid-template-columns:1fr 1fr 1fr}}
  .bind-head{color:var(--tx-mut);font-size:11px;letter-spacing:.7px;text-transform:uppercase;font-weight:700;border-bottom:1px solid var(--line)}
  @media (max-width:700px){.bind-row{grid-template-columns:1fr 1fr;} .bind-head{display:none}}

  .actchips{display:flex;flex-wrap:wrap;gap:5px;margin-top:10px}
  .actchips .chip{font-size:10.5px;letter-spacing:.3px;padding:2.5px 9px;border-radius:999px;
    background:var(--panel2);border:1px solid var(--line);color:var(--tx-mut);white-space:nowrap}
  .actchips .chip.more{border-style:dashed;cursor:help}
  .actchips .chip.groups{color:var(--info);border-color:rgba(88,166,255,.3);background:rgba(88,166,255,.07)}
  .lastact .v{transition:color .3s}
  .reading.fresh .v{color:var(--ok);animation:pressed 1.6s ease-out}
  .reading.fresh .l{color:var(--ok)}
  @keyframes pressed{0%{text-shadow:0 0 18px rgba(63,185,80,.85);transform:scale(1.06)}
    60%{text-shadow:0 0 8px rgba(63,185,80,.35)}100%{text-shadow:none;transform:none}}
  .muted{color:var(--tx-dim)} .small{font-size:13px} .center{text-align:center;color:var(--tx-mut);padding:26px 0}
  .note{color:var(--tx-dim);font-size:13px;margin:0 0 12px}
  code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;background:var(--panel2);
       padding:1px 6px;border-radius:6px}

  .toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(20px);opacity:0;
         background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:11px 18px;
         font-size:14px;font-weight:600;transition:opacity .2s,transform .2s;z-index:10;pointer-events:none;
         box-shadow:0 8px 30px rgba(0,0,0,.4)}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .toast.ok{border-color:rgba(63,185,80,.4);color:var(--ok)} .toast.bad{border-color:rgba(248,81,73,.4);color:var(--crit)}

  /* ---- PIN dialog, as in upsmon ---- */
  .backdrop{position:fixed;inset:0;z-index:100;display:flex;align-items:center;
    justify-content:center;background:rgba(2,5,10,.72);backdrop-filter:blur(3px);
    padding:20px;animation:fade .16s ease}
  .backdrop[hidden]{display:none}
  @keyframes fade{from{opacity:0}to{opacity:1}}
  .pinbox{width:min(380px,94vw);border-radius:20px;padding:28px 26px 22px;text-align:center;
    background:linear-gradient(160deg,#1b2230 0%,#141922 60%,#11151d 100%);
    border:1px solid #2b3444;
    box-shadow:0 24px 70px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.03) inset;
    animation:rise .2s cubic-bezier(.2,.9,.3,1)}
  @keyframes rise{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
  .pinicon{width:52px;height:52px;margin:0 auto 14px;border-radius:50%;
    display:flex;align-items:center;justify-content:center;color:var(--info);
    background:radial-gradient(circle at 50% 35%,rgba(88,166,255,.28),rgba(88,166,255,.07));
    border:1px solid rgba(88,166,255,.34)}
  .pinicon.danger{color:var(--crit);
    background:radial-gradient(circle at 50% 35%,rgba(248,81,73,.26),rgba(248,81,73,.07));
    border-color:rgba(248,81,73,.34)}
  .pinbox h3{margin:0 0 5px;font-size:18px;font-weight:650;letter-spacing:.2px}
  .pinwhat{margin:0 0 20px;color:var(--tx-dim);font-size:13.5px;line-height:1.45;word-break:break-word}
  .pinwhat b{color:var(--tx);font-weight:600}
  .pindigits{display:flex;gap:11px;justify-content:center;margin-bottom:6px}
  .pindigits[hidden]{display:none}
  .pindigits input{width:54px;height:64px;text-align:center;font-size:26px;font-weight:650;
    color:var(--tx);background:#0d1117;border:1.5px solid #2b3444;border-radius:13px;
    caret-color:var(--info);transition:border-color .14s,box-shadow .14s,transform .08s}
  .pindigits.wide input{width:min(260px,80vw);font-size:22px;letter-spacing:6px}
  .pindigits input:focus{outline:none;border-color:var(--info);box-shadow:0 0 0 3.5px rgba(88,166,255,.16)}
  .pindigits input.filled{border-color:#3d4a5f;background:#111823}
  .pindigits.bad input{border-color:var(--crit);box-shadow:0 0 0 3.5px rgba(248,81,73,.13)}
  .pindigits.bad{animation:shake .32s}
  @keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}
    40%{transform:translateX(7px)}60%{transform:translateX(-4px)}80%{transform:translateX(3px)}}
  .pinerr{min-height:19px;margin:8px 0 16px;font-size:13px;color:var(--crit)}
  .pinrow{display:flex;gap:10px;justify-content:center}
  .pinrow .btn{min-width:108px;justify-content:center}
  .btn.primary.danger{background:var(--crit-bg);border-color:rgba(248,81,73,.45);color:var(--crit)}
  .btn.primary.danger:hover:not(:disabled){background:rgba(248,81,73,.2);border-color:var(--crit)}
  .btn.primary:hover:not(:disabled){background:rgba(88,166,255,.2);border-color:var(--info)}
</style>
</head>
<body>
<div class="wrap">

<header>
  <h1>Sensors <span class="host">· <?= h($host) ?></span></h1>
  <span class="pill unknown" id="pill"><span class="dot"></span><span id="pill-text">Connecting…</span></span>
  <button class="lockpill locked" id="lockpill" type="button" title="Editing is locked. Click to unlock for a while.">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
    <span id="lockpill-text">Locked</span>
  </button>
  <span class="spacer"></span>
  <div class="updated" id="updated" title="Click to pause or resume refreshing">
    <b id="updated-label">Loading</b><br><span id="updated-time">—</span>
  </div>
</header>

<div class="tabs" role="tablist">
  <button role="tab" aria-selected="true"  data-tab="overview">Overview</button>
  <button role="tab" aria-selected="false" data-tab="history">History</button>
  <button role="tab" aria-selected="false" data-tab="devices">Devices</button>
  <button role="tab" aria-selected="false" data-tab="events">Events</button>
  <button role="tab" aria-selected="false" data-tab="control">Control</button>
  <button role="tab" aria-selected="false" data-tab="all">All values</button>
</div>

<section class="panel" id="tab-overview">
  <div class="grid top" style="margin-bottom:14px">
    <div class="card metric"><div class="label">Devices</div><div class="value" id="m-devices">–</div><div class="sub" id="m-devices-sub">&nbsp;</div></div>
    <div class="card metric" id="m-online-card"><div class="label">Online</div><div class="value" id="m-online">–</div><div class="sub" id="m-online-sub">&nbsp;</div></div>
    <div class="card metric" id="m-attn-card"><div class="label">Needs attention</div><div class="value" id="m-attn">–</div><div class="sub" id="m-attn-sub">&nbsp;</div></div>
    <div class="card metric" id="m-bridge-card"><div class="label">Zigbee2MQTT</div><div class="value" id="m-bridge">–</div><div class="sub" id="m-bridge-sub">&nbsp;</div></div>
    <div class="card metric" id="m-join-card"><div class="label">Permit join</div><div class="value" id="m-join">–</div><div class="sub" id="m-join-sub">&nbsp;</div></div>
  </div>
  <div class="sockets" id="sockets" hidden></div>
  <div class="grid devices" id="device-cards" style="margin-bottom:14px"></div>
  <div class="grid charts">
    <div class="card">
      <h2>Temperature <span class="right" id="ov-temp-range">24h</span></h2>
      <div class="chart" id="ov-temp"></div><div class="legend" id="ov-temp-legend"></div>
    </div>
    <div class="card">
      <h2>Humidity <span class="right" id="ov-hum-range">24h</span></h2>
      <div class="chart" id="ov-hum"></div><div class="legend" id="ov-hum-legend"></div>
    </div>
  </div>
  <div class="row" style="margin-top:12px" id="ov-ranges"></div>
</section>

<section class="panel" id="tab-history" hidden>
  <div class="row" style="margin-bottom:14px">
    <select id="h-device"></select>
    <span id="h-ranges" class="row"></span>
    <span class="spacer"></span>
    <span class="muted small" id="h-note"></span>
  </div>
  <div class="grid charts" id="h-charts"></div>
</section>

<section class="panel" id="tab-devices" hidden>
  <div class="card scroll"><table id="devices-table"><thead><tr>
    <th>Name</th><th>Model</th><th>Source</th><th>Address</th><th>Status</th><th>Battery</th><th>Signal</th><th>Last report</th><th>First seen</th>
  </tr></thead><tbody></tbody></table></div>
</section>

<section class="panel" id="tab-events" hidden>
  <div class="card scroll">
    <h2>Last 200 events</h2>
    <table id="events-table"><thead><tr><th>When</th><th></th><th>Kind</th><th>Device</th><th>Detail</th></tr></thead><tbody></tbody></table>
    <div class="center" id="events-empty" hidden>Nothing recorded yet</div>
  </div>
</section>

<section class="panel" id="tab-control" hidden>
  <div class="card full" id="lock-card" style="margin-bottom:14px">
    <h2>Editing</h2>
    <p class="note" id="lock-note">Everything on this tab that changes something is locked. Unlock with the PIN for a chosen time; while unlocked nothing here asks for it again. It locks itself when the time is up, or when you lock it. The socket buttons on the Overview follow it too: unlocked they switch at once, locked they ask for the PIN per click without unlocking anything.</p>
    <div class="btnrow">
      <button class="btn cmd primary" id="lock-unlock">Unlock editing</button>
      <button class="btn cmd" id="lock-lock" hidden>Lock now</button>
      <span class="muted small" id="lock-state" style="align-self:center"></span>
    </div>
  </div>
  <div class="grid charts">
    <div class="card">
      <h2>Pairing</h2>
      <p class="note">Opening the network lets new Zigbee devices join for four minutes. On a Shelly BLU device press the button five times quickly; on most other devices hold the button until the LED blinks.</p>
      <div class="btnrow">
        <button class="btn cmd primary" id="join-open">Open network (254 s)</button>
        <button class="btn cmd" id="join-close">Close network</button>
        <span class="muted small" id="join-state" style="align-self:center"></span>
      </div>
    </div>
    <div class="card">
      <h2>Recorded data</h2>
      <p class="note">Erasing cannot be undone. Devices stay known to Zigbee2MQTT; only what this dashboard recorded is removed.</p>
      <div class="btnrow">
        <button class="btn cmd danger" data-reset="history">Erase history</button>
        <button class="btn cmd danger" data-reset="events">Erase events</button>
        <button class="btn cmd danger" data-reset="all">Erase everything</button>
      </div>
      <div class="btnrow" style="margin-top:10px">
        <select id="reset-device"></select>
        <button class="btn cmd danger" id="reset-device-btn">Forget this device</button>
      </div>
    </div>
    <div class="card full" id="managed-card">
      <h2>Plugs and sensors</h2>
      <p class="note">Shelly devices the daemon reads over local RPC: a <b>plug</b> is switched and metered, a <b>sensor</b> is only read (an H&T on USB power; on battery it sleeps and is better served by the webhook). Entries from <code>config.json</code> are shown but edited there (including <code>"enabled": false</code>). Passwords are stored in the daemon's database, readable by the daemon alone; leave the field blank to keep the one already set. A <b>disabled</b> entry is not polled and disappears from the lists, but its history, bindings and rules stay for when it is enabled again.</p>
      <div id="managed-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="managed-add-plug">Add plug</button>
        <button class="btn cmd" id="managed-add-sensor">Add sensor</button>
        <button class="btn cmd" id="managed-discover">Find Shelly devices</button>
        <button class="btn cmd primary" id="managed-save">Save devices</button>
        <span class="muted small" id="managed-note" style="align-self:center"></span>
      </div>
      <div id="managed-found" class="muted small" style="margin-top:10px"></div>
    </div>
    <div class="card full" id="plug-control" hidden>
      <h2>Smart plugs</h2>
      <p class="note">Switching a socket cuts power to whatever is plugged into it. The counters are the plug's own running totals; resetting one starts it from zero, the history recorded here is untouched.</p>
      <div id="plug-control-list"></div>
    </div>
    <div class="card full" id="bindings-card" hidden>
      <h2>Button bindings</h2>
      <p class="note">When a Zigbee button reports an action, the daemon switches the plug. <code>*</code> matches any action. One button and action may appear on several rows — every matching row fires, in parallel — and the plug column offers <b>all plugs</b> as one row. Entries marked \u26a1 are <b>Zigbee switches</b> (a wall switch channel, a bulb): the daemon drives them through Zigbee2MQTT; <b>all plugs</b> never includes them. <b>pulse</b> flips the socket and flips it back after the delay: off → wait → on when it is on, on → wait → off when it is off. Saved behind the PIN; takes effect immediately.</p>
      <div id="bindings-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="binding-add">Add binding</button>
        <button class="btn cmd primary" id="binding-save">Save bindings</button>
        <span class="muted small" id="binding-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full" id="rules-card" hidden>
      <h2>Sensor rules</h2>
      <p class="note">When a reading crosses the line, the daemon drives the plug — any device with numbers works as the source: a thermometer, a plug's own power, Wi-Fi signal. A rule fires when its condition <b>becomes</b> true, not on every report while it stays true, and then not again until the cooldown has passed. Pair the switch-on rule with a switch-off one the other way (e.g. <code>≥ 30 → on</code> and <code>≤ 27 → off</code>) to get a thermostat with a dead band. Each rule can be limited to a <b>clock window</b> (22:00–06:00 crosses midnight) and can put the plug into a safe state when the window closes — a motion-driven light goes off in the morning even if nobody walked past at the boundary. Yes/no readings (occupancy, contact) count as 1 and 0, so <code>occupancy ≥ 1 → on</code> with the sensor's own clear-timeout makes a motion light — aimed at a plug or at a \u26a1 <b>Zigbee switch</b> alike.</p>
      <div id="rules-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="rule-add">Add rule</button>
        <button class="btn cmd primary" id="rule-save">Save rules</button>
        <span class="muted small" id="rule-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full">
      <h2>Daemon</h2>
      <div id="health-kv"></div>
    </div>
  </div>
</section>

<section class="panel" id="tab-all" hidden>
  <div class="grid charts" id="all-values"></div>
</section>

</div>

<div class="toast" id="toast"></div>

<!-- PIN dialog -->
<div class="backdrop" id="pinback" hidden>
  <div class="pinbox" role="dialog" aria-modal="true" aria-labelledby="pintitle">
    <div class="pinicon" id="pinicon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor"
           stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="10.5" width="16" height="10" rx="2.5"/>
        <path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>
      </svg>
    </div>
    <h3 id="pintitle">Enter PIN</h3>
    <p class="pinwhat" id="pinwhat"></p>
    <div class="pindigits" id="pindigits"></div>
    <div class="unlockbox" id="unlockbox" hidden>
      <span>Unlock editing for</span>
      <select id="unlock-minutes">
        <option value="5">5 min</option><option value="15" selected>15 min</option>
        <option value="30">30 min</option><option value="60">1 h</option><option value="240">4 h</option>
      </select>
    </div>
    <p class="pinerr" id="pinerr"></p>
    <div class="pinrow">
      <button class="btn" id="pincancel">Cancel</button>
      <button class="btn primary" id="pinok" disabled>Confirm</button>
    </div>
  </div>
</div>

<script>
'use strict';
var INITIAL = <?= $initial ?>;
var REFRESH_MS = 5000;
var COLORS = ['#58a6ff','#3fb950','#f0883e','#a371f7','#d29922','#f85149','#39d2c0','#e2a9f5','#79c0ff','#ffa657'];
var STATE = { status: null, paused: false, tab: 'overview', ovRange: '24h', hRange: '24h',
              hDevice: null, timer: null, busy: false, charts: {} };

// ---- small helpers --------------------------------------------------------
function $(id) { return document.getElementById(id); }
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) {
  return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function isNum(v) { return typeof v === 'number' && isFinite(v); }
function fmt(v, digits) {
  if (v === null || v === undefined) return '–';
  if (typeof v === 'boolean') return v ? 'yes' : 'no';
  if (!isNum(v)) return String(v);
  if (digits === undefined) digits = Math.abs(v) >= 100 ? 0 : (Math.abs(v) >= 10 ? 1 : 2);
  var s = v.toFixed(digits);
  return s.indexOf('.') >= 0 ? s.replace(/\.?0+$/, '') : s;
}
function ago(ts) {
  if (!ts) return 'never';
  var s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (s < 60) return s + ' s ago';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ' + Math.floor((s % 3600) / 60) + ' min ago';
  return Math.floor(s / 86400) + ' d ' + Math.floor((s % 86400) / 3600) + ' h ago';
}
function pad(n) { return (n < 10 ? '0' : '') + n; }
function stamp(ts) {
  if (!ts) return '–';
  var d = new Date(ts * 1000);
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}
function shortStamp(ts, spanS) {
  var d = new Date(ts * 1000);
  if (spanS > 3 * 86400) return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.';
  if (spanS > 36 * 3600) return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':00';
  return pad(d.getHours()) + ':' + pad(d.getMinutes());
}
function toast(message, ok) {
  var t = $('toast');
  t.textContent = message;
  t.className = 'toast show ' + (ok ? 'ok' : 'bad');
  clearTimeout(t._h);
  t._h = setTimeout(function () { t.className = 'toast'; }, 3200);
}
function api(what, options) {
  return fetch('?api=' + what, options).then(function (r) {
    return r.json().then(function (data) {
      if (!r.ok && data && data.error) throw new Error(data.error);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return data;
    });
  });
}
function post(what, body) {
  body = body || {};
  if (LOCK.token && body.session === undefined) body.session = LOCK.token;
  return api(what, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body) });
}
function levelWord(level) {
  return {ok: 'All good', warn: 'Needs attention', crit: 'Problem', unknown: 'No data'}[level] || level;
}
function deviceById(id) {
  var devs = (STATE.status && STATE.status.devices) || [];
  for (var i = 0; i < devs.length; i++) if (devs[i].id === id) return devs[i];
  return null;
}
function tempKey(d) { return d.values.temperature ? 'temperature' : (d.values.tC ? 'tC' : null); }
function humKey(d)  { return d.values.humidity ? 'humidity' : (d.values.rh ? 'rh' : null); }

// ---- favicon ---------------------------------------------------------------
function setFavicon(level) {
  var color = {ok: '#3fb950', warn: '#d29922', crit: '#f85149'}[level] || '#6e7681';
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    + '<rect x="18" y="4" width="28" height="44" rx="14" fill="none" stroke="' + color + '" stroke-width="6"/>'
    + '<circle cx="32" cy="46" r="10" fill="' + color + '"/><rect x="29" y="18" width="6" height="26" fill="' + color + '"/></svg>';
  $('favicon').href = 'data:image/svg+xml,' + encodeURIComponent(svg);
}

// ---- charts ----------------------------------------------------------------
// ---- charts: inline SVG, drag to pan, wheel to zoom, as in upsmon ------------------
// Every chart keeps its own view window over the data it was given. Dragging
// moves that window, the wheel zooms it around the pointer, a double click
// (or the reset button) puts it back. Nothing is re-fetched while panning.
// series: [{name, color, unit, points: [[ts, value], ...]}]
var CHART_STATE = {};   // container id -> {rows, series, opts, extent, from, to, zoomed}

function drawChart(container, series, opts) {
  opts = opts || {};
  var id = container.id || (container.id = 'c' + Math.random().toString(36).slice(2));
  STATE.charts[id] = {series: series, opts: opts};
  var byTs = {};
  series.forEach(function (s, i) {
    s.points.forEach(function (p) {
      if (!isNum(p[1])) return;
      (byTs[p[0]] = byTs[p[0]] || {ts: p[0]})['s' + i] = p[1];
    });
  });
  var rows = Object.keys(byTs).map(Number).sort(function (a, b) { return a - b; }).map(function (t) { return byTs[t]; });
  if (!rows.length) {
    container.innerHTML = '';
    container.appendChild(el('div', 'empty', opts.empty || 'No data for this range yet'));
    delete CHART_STATE[id];
    return;
  }
  var now = Math.floor(Date.now() / 1000);
  var extent = [rows[0].ts, rows[rows.length - 1].ts];
  if (opts.spanS) { extent = [Math.min(extent[0], now - opts.spanS), Math.max(extent[1], now)]; }
  if (extent[1] - extent[0] < 60) { extent[0] -= 30; extent[1] += 30; }
  var old = CHART_STATE[id];
  var keep = old && old.zoomed;
  CHART_STATE[id] = { rows: rows, series: series, opts: opts, extent: extent,
                      from: keep ? old.from : extent[0], to: keep ? old.to : extent[1], zoomed: !!keep };
  if (keep) applyView(id, old.from, old.to);
  renderChart(id);
}

function renderChart(id) {
  var state = CHART_STATE[id];
  if (!state) return;
  var container = $(id), all = state.rows, series = state.series, opts = state.opts;
  if (!container) return;
  var W = Math.max(280, container.clientWidth || 600), H = container.clientHeight || 240;
  var padL = 46, padR = 12, padT = 12, padB = 26;
  var plotW = W - padL - padR, plotH = H - padT - padB;
  var t0 = state.from, t1 = state.to;
  if (t1 - t0 < 60) t1 = t0 + 60;

  // one row either side of the window, so lines reach the edges
  var first = 0, last = all.length - 1, i;
  for (i = 0; i < all.length; i++) { if (all[i].ts >= t0) { first = Math.max(0, i - 1); break; } }
  for (i = all.length - 1; i >= 0; i--) { if (all[i].ts <= t1) { last = Math.min(all.length - 1, i + 1); break; } }
  var rows = all.slice(first, last + 1);
  if (!rows.length) rows = all;

  var lo = null, hi = null;
  rows.forEach(function (r) { series.forEach(function (s, n) {
    var v = r['s' + n]; if (!isNum(v)) return;
    lo = lo === null || v < lo ? v : lo; hi = hi === null || v > hi ? v : hi; }); });
  if (lo === null) { lo = 0; hi = 1; }
  if (opts.min !== undefined && opts.min < lo) lo = opts.min;
  if (opts.max !== undefined && opts.max > hi) hi = opts.max;
  if (hi - lo < 1e-9) { lo -= 1; hi += 1; }
  var padY = (hi - lo) * 0.08; lo -= padY; hi += padY;
  function px(ts) { return padL + (ts - t0) / (t1 - t0) * plotW; }
  function py(v) { return padT + plotH - (v - lo) / (hi - lo) * plotH; }

  var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none">';
  svg += '<defs><clipPath id="clip-' + id + '"><rect x="' + padL + '" y="' + padT + '" width="' + plotW + '" height="' + plotH + '"/></clipPath></defs>';
  for (var g = 0; g <= 4; g++) {
    var value = lo + (hi - lo) * g / 4, y = py(value);
    svg += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#262c37"/>';
    svg += '<text x="' + (padL - 6) + '" y="' + (y + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="#5b6472">' + fmt(value, Math.abs(hi - lo) < 5 ? 1 : 0) + '</text>';
  }
  var span = t1 - t0, xTicks = Math.max(2, Math.min(8, Math.floor(plotW / 90)));
  for (var j = 0; j <= xTicks; j++) {
    var ts = t0 + span * j / xTicks;
    svg += '<text x="' + px(ts).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="' + (j === 0 ? 'start' : (j === xTicks ? 'end' : 'middle')) + '" font-size="11" fill="#5b6472">' + shortStamp(ts, span) + '</text>';
  }
  svg += '<g clip-path="url(#clip-' + id + ')">';
  series.forEach(function (s, n) {
    var d = '', prev = null, count = 0;
    rows.forEach(function (r) {
      var v = r['s' + n];
      if (!isNum(v)) return;
      count++;
      d += (prev === null || r.ts - prev > Math.max(span / 10, 7200) ? 'M' : 'L') + px(r.ts).toFixed(1) + ' ' + py(v).toFixed(1) + ' ';
      prev = r.ts;
    });
    svg += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>';
    if (count < 60) rows.forEach(function (r) {
      var v = r['s' + n];
      if (isNum(v)) svg += '<circle cx="' + px(r.ts).toFixed(1) + '" cy="' + py(v).toFixed(1) + '" r="2.2" fill="' + s.color + '"/>';
    });
  });
  svg += '</g>';
  svg += '<line class="cross" x1="0" x2="0" y1="' + padT + '" y2="' + (padT + plotH) + '" stroke="#8b94a3" stroke-width="1" stroke-dasharray="3 3" opacity="0"/>';
  svg += '</svg>';
  var full = t0 <= state.extent[0] && t1 >= state.extent[1];
  container.innerHTML = svg
    + '<button class="creset" type="button"' + (full ? ' hidden' : '') + '>reset view</button>'
    + '<span class="chint">drag to pan · wheel to zoom · double-click to reset</span>'
    + '<div class="tip"></div>';
  wireChart(id, { t0: t0, t1: t1, padL: padL, padR: padR, W: W, H: H, rows: rows });
}

function wireChart(id, view) {
  var container = $(id), state = CHART_STATE[id];
  var svg = container.querySelector('svg'), tip = container.querySelector('.tip');
  var cross = container.querySelector('.cross'), reset = container.querySelector('.creset');
  if (!svg || !state) return;
  var series = state.series;

  function tsAt(clientX) {
    var box = svg.getBoundingClientRect();
    var frac = box.width ? (clientX - box.left) / box.width : 0;
    var plotFrom = view.padL / view.W, plotTo = (view.W - view.padR) / view.W;
    return view.t0 + (frac - plotFrom) / (plotTo - plotFrom) * (view.t1 - view.t0);
  }

  // ---- hover readout ----
  function hover(clientX, clientY) {
    if (container.classList.contains('dragging')) return;
    var ts = tsAt(clientX);
    if (ts < view.t0 || ts > view.t1) { leave(); return; }
    var html = '<b>' + stamp(Math.round(ts)) + '</b>', any = false;
    series.forEach(function (s, n) {
      var best = null, bd = Infinity;
      view.rows.forEach(function (r) { var v = r['s' + n]; if (!isNum(v)) return; var dd = Math.abs(r.ts - ts); if (dd < bd) { bd = dd; best = r; } });
      if (best && bd < Math.max((view.t1 - view.t0) / 40, 900)) {
        any = true;
        html += '<br><span class="sw" style="background:' + s.color + '"></span>' + esc(s.name) + ': <b>' + fmt(best['s' + n]) + (s.unit ? ' ' + s.unit : '') + '</b>';
      }
    });
    if (!any) { leave(); return; }
    tip.innerHTML = html; tip.style.display = 'block';
    var rect = container.getBoundingClientRect();
    var x = clientX - rect.left, y = clientY - rect.top, tw = tip.offsetWidth, th = tip.offsetHeight;
    tip.style.left = Math.min(rect.width - tw - 4, Math.max(0, x + 14)) + 'px';
    tip.style.top = Math.max(0, Math.min(rect.height - th, y - th - 10)) + 'px';
    var box = svg.getBoundingClientRect();
    var cx = box.width ? (clientX - box.left) / box.width * view.W : 0;
    cross.setAttribute('x1', cx.toFixed(1)); cross.setAttribute('x2', cx.toFixed(1)); cross.setAttribute('opacity', '1');
  }
  function leave() { tip.style.display = 'none'; cross.setAttribute('opacity', '0'); }
  svg.addEventListener('mousemove', function (e) { hover(e.clientX, e.clientY); });
  svg.addEventListener('mouseleave', leave);

  // ---- drag to pan: followed on the window, so the redraw under the pointer cannot break the gesture ----
  var dragFrom = null, dragFrame = null;
  function onDragMove(e) {
    if (!dragFrom) return;
    e.preventDefault();
    var plotWidth = dragFrom.width * (view.W - view.padL - view.padR) / view.W;
    var perPixel = (dragFrom.t1 - dragFrom.t0) / Math.max(1, plotWidth);
    var shift = -(e.clientX - dragFrom.x) * perPixel;
    if (Math.abs(e.clientX - dragFrom.x) > 2) state.zoomed = true;
    applyView(id, dragFrom.t0 + shift, dragFrom.t1 + shift);
    if (dragFrame === null) dragFrame = requestAnimationFrame(function () { dragFrame = null; if (dragFrom) renderChart(id); });
  }
  function endDrag() {
    if (!dragFrom) return;
    dragFrom = null;
    if (dragFrame !== null) { cancelAnimationFrame(dragFrame); dragFrame = null; }
    container.classList.remove('dragging');
    window.removeEventListener('pointermove', onDragMove);
    window.removeEventListener('pointerup', endDrag);
    window.removeEventListener('pointercancel', endDrag);
    renderChart(id);
  }
  svg.addEventListener('pointerdown', function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    if (e.pointerType === 'touch' && pinch) return;
    e.preventDefault();
    dragFrom = { x: e.clientX, t0: state.from, t1: state.to, width: svg.getBoundingClientRect().width };
    container.classList.add('dragging');
    leave();
    window.addEventListener('pointermove', onDragMove);
    window.addEventListener('pointerup', endDrag);
    window.addEventListener('pointercancel', endDrag);
  });

  // ---- wheel to zoom, anchored on the pointer ----
  svg.addEventListener('wheel', function (e) {
    e.preventDefault();
    var anchor = tsAt(e.clientX);
    var factor = e.deltaY > 0 ? 1.25 : 0.8;
    state.zoomed = true;
    applyView(id, anchor - (anchor - state.from) * factor, anchor + (state.to - anchor) * factor);
    renderChart(id);
  }, { passive: false });
  svg.addEventListener('dblclick', function () { resetView(id); });
  if (reset) reset.onclick = function () { resetView(id); };

  // ---- pinch to zoom on a touch screen ----
  var pinch = null;
  svg.addEventListener('touchstart', function (e) {
    if (e.touches.length === 2) { pinch = { distance: touchGap(e), t0: state.from, t1: state.to }; endDrag(); }
  }, { passive: true });
  svg.addEventListener('touchmove', function (e) {
    if (!pinch || e.touches.length !== 2) return;
    e.preventDefault();
    var factor = pinch.distance / Math.max(1, touchGap(e));
    var middle = (pinch.t0 + pinch.t1) / 2, half = (pinch.t1 - pinch.t0) / 2 * factor;
    state.zoomed = true;
    applyView(id, middle - half, middle + half);
    renderChart(id);
  }, { passive: false });
  svg.addEventListener('touchend', function () { pinch = null; });
}
function touchGap(e) {
  var dx = e.touches[0].clientX - e.touches[1].clientX, dy = e.touches[0].clientY - e.touches[1].clientY;
  return Math.sqrt(dx * dx + dy * dy);
}
// Keep the window inside the data's extent and never narrower than a minute.
function applyView(id, from, to) {
  var state = CHART_STATE[id];
  if (!state) return;
  var firstTs = state.extent[0], lastTs = state.extent[1], full = (lastTs - firstTs) || 60;
  var width = Math.max(60, Math.min(to - from, full));
  var middle = (from + to) / 2;
  from = middle - width / 2; to = from + width;
  if (from < firstTs) { from = firstTs; to = from + width; }
  if (to > lastTs) { to = lastTs; from = Math.max(firstTs, to - width); }
  state.from = from; state.to = to;
  if (from <= firstTs && to >= lastTs) state.zoomed = false;
}
function resetView(id) {
  var state = CHART_STATE[id];
  if (!state) return;
  state.from = state.extent[0]; state.to = state.extent[1]; state.zoomed = false;
  renderChart(id);
}
function redrawCharts() {
  Object.keys(CHART_STATE).forEach(function (id) {
    var c = $(id);
    if (c && c.offsetParent !== null) renderChart(id);
  });
}
function legend(host, series) {
  host.innerHTML = '';
  series.forEach(function (s) {
    var item = el('span');
    item.innerHTML = '<span class="sw" style="background:' + s.color + '"></span>' + esc(s.name);
    host.appendChild(item);
  });
}
window.addEventListener('resize', function () { clearTimeout(window._rt); window._rt = setTimeout(redrawCharts, 150); });

// ---- overview ----------------------------------------------------------------
function renderOverview(st) {
  var c = st.counts || {devices: 0, online: 0, ok: 0, warn: 0, crit: 0};
  $('m-devices').textContent = c.devices;
  $('m-devices-sub').textContent = c.devices ? (c.ok + ' ok · ' + c.warn + ' warn · ' + c.crit + ' crit') : 'none paired yet';
  $('m-online').textContent = c.online;
  $('m-online-sub').textContent = c.devices ? 'of ' + c.devices : '';
  $('m-online-card').className = 'card metric ' + (c.devices && c.online < c.devices ? 'warn' : '');
  var attn = c.warn + c.crit;
  $('m-attn').textContent = attn;
  $('m-attn-card').className = 'card metric ' + (c.crit ? 'crit' : (c.warn ? 'warn' : 'ok'));
  $('m-attn-sub').textContent = attn ? 'see the cards below' : 'everything reporting';
  var b = st.bridge || {};
  var bstate = st.connected ? (b.state || 'unknown') : 'broker down';
  $('m-bridge').textContent = bstate;
  $('m-bridge-card').className = 'card metric ' + (st.connected && b.state === 'online' ? 'ok' : 'crit');
  $('m-bridge-sub').textContent = (b.version ? 'v' + b.version : '') + (b.channel ? ' · channel ' + b.channel : '') + (b.coordinator ? ' · ' + b.coordinator : '');
  $('m-join').textContent = b.permit_join ? 'OPEN' : 'closed';
  $('m-join-card').className = 'card metric ' + (b.permit_join ? 'warn' : '');
  $('m-join-sub').textContent = b.permit_join ? 'new devices may join' : 'network locked';
  $('join-state').textContent = b.permit_join ? 'The network is open for joining.' : 'The network is closed.';

  renderSockets(st);
  var host = $('device-cards');
  if (ORDER.drag || Date.now() - ORDER.justDropped < 800) return;   // never redraw under a drag
  host.innerHTML = '';
  if (!st.devices.length) {
    var empty = el('div', 'card center', 'No devices yet. Open the network under Control and pair a sensor.');
    empty.style.gridColumn = '1/-1';
    host.appendChild(empty);
  }
  sortByOrder(st.devices, 'devices', function (d) { return d.id; }).forEach(function (d) {
    if (d.source === 'plug') return;      // shown as a socket above
    var stale = !d.online;
    var card = el('div', 'card dev ' + d.level + (stale ? ' stale' : ''));
    card.onclick = function () { if (Date.now() - ORDER.justDropped < 500) return; STATE.hDevice = d.id; showTab('history'); };
    var head = el('div', 'head');
    var nm = el('div');
    nm.appendChild(el('div', 'name', d.name));
    nm.appendChild(el('div', 'model', [d.vendor, d.model].filter(Boolean).join(' ') + (d.description ? ' · ' + d.description : '')));
    head.appendChild(nm);
    head.appendChild(el('span', 'spacer'));
    head.appendChild(el('span', 'tag ' + (d.availability === 'offline' ? 'crit' : (stale ? 'warn' : (d.level === 'ok' ? 'ok' : d.level))),
                        d.availability === 'offline' ? 'offline' : (stale ? 'silent' : (d.level === 'ok' ? 'online' : d.level))));
    card.appendChild(head);
    var readings = el('div', 'readings');
    if (d.kind === 'Router') {
      // What matters on a range extender: that it routes, how good its link
      // is, and how long it has been holding the mesh together.
      var routing = el('div', 'reading');
      var rv = el('div', 'v', d.availability === 'offline' ? 'down' : 'routing');
      rv.style.color = d.availability === 'offline' ? 'var(--crit)' : 'var(--ok)';
      routing.appendChild(rv);
      routing.appendChild(el('div', 'l', 'mains-powered mesh router'));
      readings.appendChild(routing);
      var link = el('div', 'reading');
      link.appendChild(el('div', 'v', isNum(d.linkquality) ? fmt(d.linkquality, 0) : '—'));
      link.appendChild(el('div', 'l', 'link quality'));
      readings.appendChild(link);
      var since = el('div', 'reading small');
      since.appendChild(el('div', 'v', d.first_seen ? stamp(d.first_seen).slice(0, 10) : '—'));
      since.appendChild(el('div', 'l', 'in the network since'));
      readings.appendChild(since);
    } else if (!d.headline.length && d.has_action) {
      readings.appendChild(lastActionReading(d));
    } else if (!d.headline.length) {
      readings.appendChild(el('span', 'muted small', d.age_s === null ? 'Waiting for the first report'
        : 'No measurements — see All values'));
    }
    if (d.kind !== 'Router') d.headline.forEach(function (hd, i) {
      var r = el('div', 'reading' + (i > 1 ? ' small' : ''));
      var v = el('div', 'v');
      v.innerHTML = esc(fmt(hd.value)) + (hd.unit ? '<span class="unit">' + esc(hd.unit) + '</span>' : '');
      r.appendChild(v);
      r.appendChild(el('div', 'l', hd.label));
      readings.appendChild(r);
    });
    card.appendChild(readings);
    if (d.has_action && d.actions && d.actions.length) card.appendChild(actionChips(d));
    var foot = el('div', 'foot');
    if (isNum(d.battery)) {
      var bw = el('span', 'batt');
      var bar = el('span', 'bar'); var fill = el('span');
      var bl = d.battery <= st.thresholds.battery_crit ? 'var(--crit)' : (d.battery <= st.thresholds.battery_warn ? 'var(--warn)' : 'var(--ok)');
      fill.style.width = Math.max(0, Math.min(100, d.battery)) + '%'; fill.style.background = bl;
      bar.appendChild(fill);
      bw.appendChild(el('span', '', 'Battery ' + fmt(d.battery, 0) + '%'));
      bw.appendChild(bar);
      foot.appendChild(bw);
    }
    if (isNum(d.linkquality)) {
      var lw = el('span', 'sigwrap');
      lw.appendChild(signalBars('lqi', d.linkquality, st.thresholds));
      lw.appendChild(el('span', '', 'LQI ' + fmt(d.linkquality, 0)));
      foot.appendChild(lw);
    }
    if (d.via && d.via.name) {
      var via = el('span', 'via', 'via ' + d.via.name);
      via.title = 'Connected through ' + d.via.name + (d.via.type ? ' (' + d.via.type.toLowerCase() + ')' : '')
        + (isNum(d.via.lqi) ? ', link ' + fmt(d.via.lqi, 0) : '')
        + (d.via.ts ? ' — from the network map ' + ago(d.via.ts) : '');
      foot.appendChild(via);
    }
    foot.appendChild(el('span', '', ago(d.last_seen)));
    if (d.reasons.length) foot.appendChild(el('span', 'reason', d.reasons.join('; ')));
    card.appendChild(foot);
    makeReorderable(card, host, 'devices', d.id);
    host.appendChild(card);
  });
}

function loadOverviewCharts() {
  var st = STATE.status;
  if (!st) return;
  var spanS = spanSeconds(STATE.ovRange);
  var jobs = [];
  st.devices.forEach(function (d) {
    var tk = tempKey(d), hk = humKey(d);
    if (!tk && !hk) return;
    var keys = [tk, hk].filter(Boolean).join(',');
    jobs.push(api('history&device=' + encodeURIComponent(d.id) + '&keys=' + keys + '&range=' + STATE.ovRange + '&points=400')
      .then(function (r) { return {dev: d, tk: tk, hk: hk, rows: r.rows}; }, function () { return null; }));
  });
  $('ov-temp-range').textContent = STATE.ovRange; $('ov-hum-range').textContent = STATE.ovRange;
  Promise.all(jobs).then(function (results) {
    var temps = [], hums = [];
    results.forEach(function (r, i) {
      if (!r) return;
      var color = COLORS[i % COLORS.length];
      if (r.tk) temps.push({name: r.dev.name, color: color, unit: '°C', points: r.rows.map(function (x) { return [x.ts, x[r.tk]]; })});
      if (r.hk) hums.push({name: r.dev.name, color: color, unit: '%', points: r.rows.map(function (x) { return [x.ts, x[r.hk]]; })});
    });
    drawChart($('ov-temp'), temps, {spanS: spanS}); legend($('ov-temp-legend'), temps);
    drawChart($('ov-hum'), hums, {spanS: spanS}); legend($('ov-hum-legend'), hums);
  });
}
function spanSeconds(range) {
  var m = /^(\d+)([smhdwy])$/.exec(range); if (!m) return 86400;
  return parseInt(m[1], 10) * {s: 1, m: 60, h: 3600, d: 86400, w: 604800, y: 31557600}[m[2]];
}
function rangeButtons(host, ranges, current, onpick) {
  host.innerHTML = '';
  ranges.forEach(function (r) {
    var b = el('button', 'btn small' + (r === current ? ' on' : ''), r);
    b.onclick = function () { onpick(r); };
    host.appendChild(b);
  });
}

// ---- history ------------------------------------------------------------------
function renderHistoryControls() {
  var st = STATE.status; if (!st) return;
  var sel = $('h-device');
  var current = STATE.hDevice || (sel.value || (st.devices[0] && st.devices[0].id));
  sel.innerHTML = '';
  st.devices.forEach(function (d) {
    var o = el('option', '', d.name + ' — ' + [d.vendor, d.model].filter(Boolean).join(' '));
    o.value = d.id; sel.appendChild(o);
  });
  if (current && deviceById(current)) sel.value = current;
  STATE.hDevice = sel.value || null;
  sel.onchange = function () { STATE.hDevice = sel.value; loadHistory(); };
  rangeButtons($('h-ranges'), ['6h', '24h', '7d', '30d', '1y'], STATE.hRange, function (r) { STATE.hRange = r; renderHistoryControls(); loadHistory(); });
}
function loadHistory() {
  var id = STATE.hDevice, host = $('h-charts');
  if (!id) { host.innerHTML = '<div class="card center full">No device selected</div>'; return; }
  var d = deviceById(id);
  $('h-note').textContent = 'Loading…';
  api('device&id=' + encodeURIComponent(id)).then(function (info) {
    var keys = (info.keys || []).filter(function (k) { return k !== 'linkquality'; });
    if (info.keys && info.keys.indexOf('linkquality') >= 0) keys.push('linkquality');
    if (!keys.length) { host.innerHTML = '<div class="card center full">Nothing numeric recorded for this device yet</div>'; $('h-note').textContent = ''; return; }
    return api('history&device=' + encodeURIComponent(id) + '&keys=' + keys.join(',') + '&range=' + STATE.hRange + '&points=700').then(function (r) {
      host.innerHTML = '';
      var spanS = spanSeconds(STATE.hRange);
      keys.forEach(function (k, i) {
        var meta = (info.values && info.values[k]) || {};
        var card = el('div', 'card');
        var h2 = el('h2'); h2.innerHTML = esc(meta.label || k) + (meta.unit ? ' <span class="right">' + esc(meta.unit) + '</span>' : '');
        card.appendChild(h2);
        var box = el('div', 'chart'); box.id = 'h-chart-' + i;
        card.appendChild(box);
        host.appendChild(card);
        var pts = r.rows.map(function (x) { return [x.ts, x[k]]; }).filter(function (p) { return p[1] !== undefined; });
        var opts = {spanS: spanS};
        if (k === 'battery' || k === 'humidity' || k === 'rh') { opts.min = 0; opts.max = 100; }
        drawChart(box, [{name: (d ? d.name : id), color: COLORS[i % COLORS.length], unit: meta.unit || '', points: pts}], opts);
      });
      $('h-note').textContent = r.rows.length + ' points' + (spanS > 14 * 86400 ? ' · older than two weeks is hourly average' : '');
    });
  }).catch(function (e) { $('h-note').textContent = 'Error: ' + e.message; });
}

// ---- devices table --------------------------------------------------------------
var RENAME = { active: false };
function renameDevice(d) {
  var editable = d.source !== 'plug' && d.id.indexOf('sensor:') !== 0;
  if (!editable) { toast('This one is named in "Plugs and sensors" on the Control tab', false); return; }
  var cell = $('name-' + cssId(d.id));
  if (!cell || cell.querySelector('input')) return;
  RENAME.active = true;              // the table must not redraw under the typing
  var old = d.name;
  cell.innerHTML = '';
  var input = el('input'); input.value = old; input.maxLength = 41;
  input.style.cssText = 'font:inherit;font-size:14px;background:var(--panel2);color:var(--tx);border:1px solid var(--info);border-radius:8px;padding:6px 10px;width:100%;max-width:220px';
  var hint = el('div', 'muted small', d.source === 'zigbee' ? 'Renames it in Zigbee2MQTT too (Enter saves, Esc cancels)' : 'A dashboard name; the MQTT topic stays (Enter saves, Esc cancels)');
  cell.appendChild(input); cell.appendChild(hint);
  input.focus(); input.select();
  var done = false;
  function cancel() { if (done) return; done = true; RENAME.active = false; tick(true); }
  function save() {
    if (done) return;
    var name = input.value.trim();
    if (!name || name === old) { cancel(); return; }
    done = true;
    RENAME.active = false;
    withPin('Rename ' + old, 'New name: <b>' + esc(name) + '</b>' + (d.source === 'zigbee' ? '<br>Zigbee2MQTT is told as well, so the name holds everywhere.' : ''), function (pin) {
      return post('rename', {id: d.id, name: name, pin: pin}).then(function (r) { return r.message || 'renamed'; });
    });
  }
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') save();
    if (e.key === 'Escape') cancel();
  });
  input.addEventListener('blur', function () { setTimeout(cancel, 150); });
}
// Deleting is destructive enough that even an unlocked session gets the
// danger dialogue - just without the PIN boxes, one Confirm.
function withDangerConfirm(title, text, action) {
  if (isUnlocked() && pinNeeded()) {
    askPin(title, text, true, false, true).then(function (ok) {
      if (ok === null) return;
      action('').then(function (msg) { toast(msg, true); tick(true); }, function (e) { toast(e.message || String(e), false); });
    });
    return;
  }
  withPin(title, text, action, true);
}
function deleteDevice(d) {
  withDangerConfirm('Delete ' + d.name,
    'Every reading, event and snapshot recorded for it here is erased, and any binding or rule with it as the source goes too.<br>'
    + (d.source === 'zigbee' ? 'Zigbee2MQTT still knows the device: when it next reports, it appears here again, fresh.' : 'If it reports again, it appears here again, fresh.'),
    function (pin) {
      return post('reset', {scope: 'device', device: d.id, pin: pin}).then(function (r) {
        var extra = (r.removed_with_it || []).length;
        return 'Deleted ' + d.name + (extra ? ' and ' + extra + ' binding(s)/rule(s) that used it' : '');
      });
    }, true);
}
function cssId(id) { return id.replace(/[^A-Za-z0-9_-]/g, '_'); }
function renderDevices(st) {
  if (RENAME.active) return;         // an inline rename is open; leave the table alone
  var tb = $('devices-table').querySelector('tbody');
  tb.innerHTML = '';
  st.devices.forEach(function (d) {
    var tr = el('tr');
    tr.innerHTML = '<td id="name-' + cssId(d.id) + '"><b>' + esc(d.name) + '</b>'
      + (d.alias ? '<br><span class="muted small">topic: ' + esc(d.topic_name) + '</span>' : '')
      + (d.description ? '<br><span class="muted small">' + esc(d.description) + '</span>' : '') + '</td>'
      + '<td>' + esc([d.vendor, d.model].filter(Boolean).join(' ') || '–') + '</td>'
      + '<td><span class="tag ' + (d.source === 'zigbee' ? 'zb' : 'info') + '">' + esc(d.source) + '</span> <span class="muted small">' + esc(d.kind || '') + '</span></td>'
      + '<td class="mono small">' + esc(d.id) + '</td>'
      + '<td><span class="tag ' + d.level + '">' + esc(d.level) + '</span>' + (d.reasons.length ? '<br><span class="muted small">' + esc(d.reasons.join('; ')) + '</span>' : '') + '</td>'
      + '<td class="num">' + (isNum(d.battery) ? fmt(d.battery, 0) + ' %' : '–') + '</td>'
      + '<td class="num">' + (isNum(d.linkquality) ? fmt(d.linkquality, 0) : '–') + '</td>'
      + '<td>' + esc(ago(d.last_seen)) + '<br><span class="muted small">' + esc(stamp(d.last_seen)) + '</span></td>'
      + '<td class="small">' + esc(stamp(d.first_seen)) + '</td>';
    var actions = el('td');
    actions.style.whiteSpace = 'nowrap';
    var ren = el('button', 'btn small iconbtn needs-unlock'); ren.innerHTML = iconMarkup('pencil', 15); ren.title = 'Rename';
    ren.onclick = function () { if (!isUnlocked()) { unlockFlow(function () { renameDevice(d); }); } else renameDevice(d); };
    var del = el('button', 'btn small iconbtn danger needs-unlock'); del.innerHTML = iconMarkup('trash', 15); del.title = 'Delete the device and everything recorded for it';
    del.onclick = function () { deleteDevice(d); };
    actions.appendChild(ren); actions.appendChild(document.createTextNode(' ')); actions.appendChild(del);
    tr.appendChild(actions);
    tb.appendChild(tr);
  });
  var sel = $('reset-device'), cur = sel.value;
  sel.innerHTML = '';
  st.devices.forEach(function (d) { var o = el('option', '', d.name); o.value = d.id; sel.appendChild(o); });
  if (cur) sel.value = cur;
}

// ---- events ----------------------------------------------------------------------
function loadEvents() {
  api('events&limit=200').then(function (r) {
    var tb = $('events-table').querySelector('tbody');
    tb.innerHTML = '';
    $('events-empty').hidden = r.events.length > 0;
    r.events.forEach(function (e) {
      var tr = el('tr');
      tr.innerHTML = '<td class="small" style="white-space:nowrap">' + esc(stamp(e.ts)) + '</td>'
        + '<td><span class="tag ' + esc(e.level || 'info') + '">' + esc(e.level || 'info') + '</span></td>'
        + '<td>' + esc(e.kind) + '</td>'
        + '<td>' + esc(e.device_name || e.device || '') + '</td>'
        + '<td>' + esc(e.detail || '') + '</td>';
      tb.appendChild(tr);
    });
  }).catch(function (e) { toast('Events: ' + e.message, false); });
}

// ---- all values ------------------------------------------------------------------
function renderAll(st) {
  var host = $('all-values');
  host.innerHTML = '';
  st.devices.forEach(function (d) {
    var card = el('div', 'card');
    var h2 = el('h2'); h2.innerHTML = esc(d.name) + ' <span class="right">' + esc([d.vendor, d.model].filter(Boolean).join(' ')) + '</span>';
    card.appendChild(h2);
    var keys = Object.keys(d.values).sort();
    if (!keys.length) card.appendChild(el('div', 'muted small', 'Nothing reported yet'));
    keys.forEach(function (k) {
      var v = d.values[k];
      var row = el('div', 'kv');
      var kk = el('span', 'k'); kk.innerHTML = esc(v.label || k) + '<span class="d">' + esc(k) + (v.description ? ' — ' + esc(v.description) : '') + '</span>';
      var vv = el('span', 'v', fmt(v.value) + (v.unit ? ' ' + v.unit : ''));
      if (v.options && v.options.length) { var o = el('span', 'd', 'one of: ' + v.options.join(', ')); o.style.display = 'block'; o.style.color = 'var(--tx-mut)'; o.style.fontSize = '12px'; o.style.fontWeight = '400'; vv.appendChild(o); }
      row.appendChild(kk); row.appendChild(vv);
      card.appendChild(row);
    });
    if (d.via && d.via.name) {
      var via = el('div', 'kv');
      via.innerHTML = '<span class="k">Connected through<span class="d">from the Zigbee network map' + (d.via.ts ? ', ' + esc(ago(d.via.ts)) : '') + '</span></span>'
        + '<span class="v">' + esc(d.via.name) + (d.via.type ? ' <span style="color:var(--tx-mut);font-weight:400">(' + esc(d.via.type.toLowerCase()) + ')</span>' : '') + '</span>';
      card.appendChild(via);
    }
    var meta = el('div', 'kv');
    meta.innerHTML = '<span class="k">Last report</span><span class="v">' + esc(stamp(d.last_seen)) + '</span>';
    card.appendChild(meta);
    host.appendChild(card);
  });
}

// ---- control --------------------------------------------------------------------
function loadHealth() {
  api('health').then(function (h) {
    var pairs = [
      ['Version', h.version], ['Uptime', ago(Math.floor(Date.now() / 1000) - h.uptime_s).replace(' ago', '')],
      ['Broker', h.connected ? 'connected' : 'disconnected' + (h.last_error ? ' — ' + h.last_error : '')],
      ['Bridge', h.bridge_state || 'unknown'], ['Messages received', h.messages],
      ['Last message', h.last_message ? ago(h.last_message) : 'none'],
      ['Subscriptions', (h.subscriptions || []).join(', ')],
      ['Database', h.db.path + ' — ' + (h.db.bytes ? (h.db.bytes / 1048576).toFixed(1) + ' MB' : '?') + ', ' + h.db.samples + ' samples, ' + h.db.samples_hourly + ' hourly, ' + h.db.events + ' events'],
      ['Oldest data', h.db.oldest ? stamp(h.db.oldest) : '–'],
    ];
    if (h.pushes && h.pushes.listening) {
      pairs.push(['Webhook listener', h.pushes.endpoint + ' — ' + h.pushes.received + ' received, ' + h.pushes.rejected + ' rejected' + (h.pushes.last ? ', last ' + ago(h.pushes.last) : '')]);
    }
    var host = $('health-kv'); host.innerHTML = '';
    pairs.forEach(function (p) {
      var row = el('div', 'kv'); row.appendChild(el('span', 'k', p[0])); row.appendChild(el('span', 'v', String(p[1])));
      host.appendChild(row);
    });
  }).catch(function (e) { $('health-kv').textContent = 'Daemon not reachable: ' + e.message; });
}

var PIN = { resolve: null, length: 4 };
function pinInputs() { return Array.prototype.slice.call($('pindigits').querySelectorAll('input')); }
function pinNeeded() { return !!(STATE.status && STATE.status.pin_required); }

// One box per digit for a numeric PIN of 4–8, a single field for anything else.
function buildPinBoxes() {
  var st = STATE.status || {};
  var host = $('pindigits');
  var length = st.pin_length || 4, boxes = st.pin_numeric !== false && length >= 4 && length <= 8;
  var want = boxes ? 'boxes' + length : 'wide';
  if (host.getAttribute('data-kind') === want) return;
  host.setAttribute('data-kind', want);
  host.innerHTML = '';
  host.classList.toggle('wide', !boxes);
  PIN.length = boxes ? length : 0;
  var n = boxes ? length : 1;
  for (var i = 0; i < n; i++) {
    var input = el('input');
    input.type = 'password'; input.autocomplete = 'off';
    input.setAttribute('inputmode', boxes ? 'numeric' : 'text');
    if (boxes) input.maxLength = 1;
    input.setAttribute('aria-label', boxes ? 'digit ' + (i + 1) : 'PIN');
    host.appendChild(input);
  }
  wirePinInputs();
}
function pinValue() { return pinInputs().map(function (i) { return i.value; }).join(''); }
function pinComplete() { return PIN.length ? pinValue().length === PIN.length : pinValue().length > 0; }

function askPin(title, text, danger, unlock, confirmOnly) {
  // Resolves with the PIN, '' when none is configured, or null if the person backed out.
  return new Promise(function (resolve) {
    PIN.resolve = resolve;
    var needed = pinNeeded() && !confirmOnly;
    buildPinBoxes();
    $('pintitle').textContent = title;
    $('pinwhat').innerHTML = text;
    $('pinerr').textContent = '';
    $('pindigits').classList.remove('bad');
    $('pindigits').hidden = !needed;
    $('unlockbox').hidden = !unlock;
    $('pinicon').className = 'pinicon' + (danger ? ' danger' : '');
    $('pinok').className = 'btn primary' + (danger ? ' danger' : '');
    pinInputs().forEach(function (input) { input.value = ''; input.classList.remove('filled'); });
    $('pinok').disabled = needed;
    $('pinback').hidden = false;
    setTimeout(function () { (needed ? pinInputs()[0] : $('pinok')).focus(); }, 40);
  });
}
function closePin(value) {
  $('pinback').hidden = true;
  var resolve = PIN.resolve;
  PIN.resolve = null;
  if (resolve) resolve(value);
}
function pinShake(message) {
  $('pinerr').textContent = message;
  var box = $('pindigits');
  box.classList.add('bad');
  setTimeout(function () { box.classList.remove('bad'); }, 400);
  pinInputs().forEach(function (input) { input.value = ''; input.classList.remove('filled'); });
  $('pinok').disabled = true;
  pinInputs()[0].focus();
}
function wirePinInputs() {
  var inputs = pinInputs();
  inputs.forEach(function (input, index) {
    input.addEventListener('input', function () {
      if (PIN.length) {
        input.value = input.value.replace(/\D/g, '').slice(-1);
        input.classList.toggle('filled', input.value !== '');
        if (input.value && index < inputs.length - 1) inputs[index + 1].focus();
      }
      $('pinok').disabled = !pinComplete();
      if (PIN.length && pinComplete()) $('pinok').focus();
    });
    input.addEventListener('keydown', function (e) {
      if (PIN.length && e.key === 'Backspace' && !input.value && index > 0) {
        inputs[index - 1].focus(); inputs[index - 1].value = ''; inputs[index - 1].classList.remove('filled');
        e.preventDefault();
      } else if (PIN.length && e.key === 'ArrowLeft' && index > 0) {
        inputs[index - 1].focus();
      } else if (PIN.length && e.key === 'ArrowRight' && index < inputs.length - 1) {
        inputs[index + 1].focus();
      } else if (e.key === 'Enter' && pinComplete()) {
        closePin(pinValue());
      } else if (e.key === 'Escape') {
        closePin(null);
      }
    });
    input.addEventListener('paste', function (e) {
      if (!PIN.length) return;
      var text = (e.clipboardData || window.clipboardData).getData('text') || '';
      var digits = text.replace(/\D/g, '').slice(0, PIN.length);
      if (!digits) return;
      e.preventDefault();
      inputs.forEach(function (box, n) { box.value = digits[n] || ''; box.classList.toggle('filled', !!digits[n]); });
      $('pinok').disabled = digits.length !== PIN.length;
      inputs[Math.min(digits.length, PIN.length - 1)].focus();
    });
  });
}
$('pinok').onclick = function () {
  var digitsShown = !$('pindigits').hidden;
  if (!digitsShown) { closePin(''); return; }
  if (pinComplete()) closePin(pinValue());
};
$('pincancel').onclick = function () { closePin(null); };
$('pinback').addEventListener('mousedown', function (e) { if (e.target === $('pinback')) closePin(null); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('pinback').hidden) closePin(null); });

// ---- the editing lock ---------------------------------------------------------------
// Nothing that changes something works while locked. Unlocking takes the PIN
// once and lasts a chosen while; the daemon hands out a session token that
// every request carries instead of the PIN, and forgets it when time is up.
var LOCK = { token: null, until: 0 };
try { var savedLock = JSON.parse(sessionStorage.getItem('zigmon-unlock') || 'null'); if (savedLock && savedLock.until * 1000 > Date.now()) LOCK = Object.assign(LOCK, savedLock); } catch (e) {}
function isUnlocked() { return !pinNeeded() || !!(LOCK.token && LOCK.until * 1000 > Date.now()); }
function rememberLock() { try { if (LOCK.token) sessionStorage.setItem('zigmon-unlock', JSON.stringify({token: LOCK.token, until: LOCK.until})); else sessionStorage.removeItem('zigmon-unlock'); } catch (e) {} }
function setLocked(reason) {
  var was = !!LOCK.token;
  LOCK.token = null; LOCK.until = 0; rememberLock();
  renderLock();
  if (was) tick(true);                 // drop the drag affordances
  if (was && reason) toast(reason, false);
}
function renderLock() {
  var pinRequired = pinNeeded();
  var unlocked = isUnlocked();
  document.body.classList.toggle('locked', !unlocked);
  var pill = $('lockpill');
  pill.hidden = !pinRequired;
  pill.className = 'lockpill ' + (unlocked ? 'unlocked' : 'locked');
  var left = Math.max(0, Math.floor(LOCK.until - Date.now() / 1000));
  var mm = Math.floor(left / 60), ss = left % 60;
  $('lockpill-text').innerHTML = unlocked ? 'Editing <span class="lockpill-time">' + mm + ':' + (ss < 10 ? '0' : '') + ss + '</span>' : 'Locked';
  pill.title = unlocked ? 'Editing is unlocked. Click to lock it now.' : 'Editing is locked. Click to unlock for a while.';
  $('lock-unlock').hidden = unlocked;
  $('lock-lock').hidden = !unlocked;
  $('lock-card').hidden = !pinRequired;
  $('lock-state').textContent = !pinRequired ? '' : unlocked ? 'Unlocked, ' + mm + ' min ' + ss + ' s left.' : 'Locked.';
  if (LOCK.token && pinRequired && left === 0) setLocked('Editing locked: the time is up');
}
setInterval(renderLock, 1000);
function unlockFlow(then) {
  // Ask for the PIN and a duration, get a session from the daemon, then carry on.
  askPin('Unlock editing', 'While unlocked, nothing on the dashboard asks for the PIN again.', false, true).then(function go(pin) {
    if (pin === null) return;
    var minutes = parseInt($('unlock-minutes').value, 10) || 15;
    api('unlock', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({pin: pin, minutes: minutes})}).then(function (r) {
      LOCK.token = r.token; LOCK.until = r.until; rememberLock(); renderLock();
      toast('Editing unlocked for ' + minutes + ' min', true);
      tick(true);                      // re-render so cards become draggable at once
      if (then) then();
    }, function (e) {
      var message = e.message || String(e);
      if (/PIN/i.test(message) && !/locked|too many/i.test(message)) {
        $('pinback').hidden = false; pinShake(message); PIN.resolve = go; return;
      }
      toast(message, false);
    });
  });
}
function lockNow() {
  var token = LOCK.token;
  setLocked(null);
  if (token) post('lock', {session: token}).then(function () { toast('Editing locked', true); }, function () {});
}
$('lockpill').onclick = function () { if (LOCK.token) lockNow(); else unlockFlow(); };
$('lock-unlock').onclick = function () { unlockFlow(); };
$('lock-lock').onclick = lockNow;

// The socket buttons on the overview: while editing is unlocked they act at
// once like everything else; while locked they ask for the PIN per click,
// without unlocking anything. The wrong-PIN retry happens in the same
// dialogue; a lockout closes it with a toast.
function withPinAlways(title, text, action, danger) {
  if (isUnlocked()) {
    action('').then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/session has expired/i.test(message)) { setLocked('Editing locked: ' + message); return; }
      toast(message, false);
    });
    return;
  }
  askPin(title, text, danger).then(function run(pin) {
    if (pin === null) return;
    action(pin).then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/PIN/i.test(message) && !/locked|too many/i.test(message) && pinNeeded()) {
        $('pinback').hidden = false; pinShake(message); PIN.resolve = run; return;
      }
      toast(message, false);
    });
  });
}

// Everything on the Control tab goes through here. Locked: offer to unlock,
// then do it. Unlocked: just do it - the session token stands in for the PIN,
// and the PIN dialogue is never shown.
function withPin(title, text, action, danger) {
  function run() {
    action('').then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/session has expired|missing or wrong API token/i.test(message)) { setLocked('Editing locked: ' + message); return; }
      toast(message, false);
    });
  }
  if (isUnlocked()) { run(); return; }
  unlockFlow(run);
}
$('join-open').onclick = function () {
  withPin('Open the Zigbee network', 'New devices will be able to join for 254 seconds.', function (pin) {
    return post('permit-join', {enable: true, pin: pin}).then(function () { return 'Network open — pair your device now'; });
  });
};
$('join-close').onclick = function () {
  withPin('Close the Zigbee network', 'Joining will be disabled.', function (pin) {
    return post('permit-join', {enable: false, pin: pin}).then(function () { return 'Network closed'; });
  });
};
Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) {
  b.onclick = function () {
    var scope = b.getAttribute('data-reset');
    var what = {history: 'all recorded samples', events: 'the event log', all: 'everything this dashboard has recorded'}[scope];
    withPin('Erase ' + what, '<b>This cannot be undone.</b>', function (pin) {
      return post('reset', {scope: scope, pin: pin}).then(function () { return 'Erased ' + what; });
    }, true);
  };
});
$('reset-device-btn').onclick = function () {
  var id = $('reset-device').value, d = deviceById(id);
  if (!d) return;
  withPin('Forget ' + d.name, 'Its history is erased. It reappears when it next reports.', function (pin) {
    return post('reset', {scope: 'device', device: id, pin: pin}).then(function () { return 'Forgot ' + d.name; });
  }, true);
};


// ---- icons and hints, as in upsmon -------------------------------------------------
var ICONS = {
  power: '<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  reset: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
  reboot: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
  cancel: '<circle cx="12" cy="12" r="9"/><path d="M15 9l-6 6M9 9l6 6"/>',
  trash: '<path d="M4 7h16"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13"/><path d="M10 11v6M14 11v6"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  plug: '<path d="M9 3v6M15 3v6"/><path d="M6 9h12v3a6 6 0 0 1-12 0z"/><path d="M12 18v3"/>',
  join: '<path d="M12 20V10"/><path d="M8.5 13.5a5 5 0 0 1 7 0"/><path d="M5.6 10.6a9 9 0 0 1 12.8 0"/><path d="M2.8 7.8a13 13 0 0 1 18.4 0"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  add: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  link: '<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
  pencil: '<path d="M17 3a2.4 2.4 0 0 1 3.4 3.4L8 18.8 3 20l1.2-5z"/>',
  forget: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M9 11l6 6M15 11l-6 6"/>'
};
function iconMarkup(key, size) {
  return '<svg viewBox="0 0 24 24" width="' + (size || 17) + '" height="' + (size || 17)
    + '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
    + (ICONS[key] || '') + '</svg>';
}
function setButtonIcon(button, key, label) {
  button.innerHTML = iconMarkup(key) + '<span>' + esc(label !== undefined ? label : button.textContent) + '</span>';
  return button;
}
function cmdButton(label, key, cls) {
  var b = el('button', 'btn cmd needs-unlock' + (cls ? ' ' + cls : ''));
  b.type = 'button';
  return setButtonIcon(b, key, label);
}

// Resting the pointer on a button for a while reveals what it really does.
var HINT_DELAY_MS = 5000;
var HINT = { timer: null, node: null };
function attachHint(element, html) {
  element.addEventListener('mouseenter', function () {
    clearTimeout(HINT.timer);
    HINT.timer = setTimeout(function () { showHint(element, html); }, HINT_DELAY_MS);
  });
  element.addEventListener('mouseleave', hideHint);
  element.addEventListener('blur', hideHint);
  element.addEventListener('touchstart', function () {
    clearTimeout(HINT.timer);
    HINT.timer = setTimeout(function () { showHint(element, html); }, 600);
  }, { passive: true });
  element.addEventListener('touchend', hideHint);
}
function showHint(element, html) {
  hideHint();
  var tip = el('div', 'hint');
  tip.innerHTML = html;
  document.body.appendChild(tip);
  var box = element.getBoundingClientRect();
  var width = tip.offsetWidth, height = tip.offsetHeight;
  var left = box.left + box.width / 2 - width / 2;
  left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
  var top = box.top - height - 10;
  if (top < 8) top = box.bottom + 10;
  tip.style.left = Math.round(left) + 'px';
  tip.style.top = Math.round(top) + 'px';
  requestAnimationFrame(function () { tip.classList.add('show'); });
  HINT.node = tip;
}
function hideHint() {
  clearTimeout(HINT.timer);
  if (HINT.node && HINT.node.parentNode) HINT.node.parentNode.removeChild(HINT.node);
  HINT.node = null;
}
window.addEventListener('scroll', hideHint, true);

// The buttons that live in the markup get their icons and hints once.
(function decorateStaticButtons() {
  ['join-open', 'join-close', 'reset-device-btn', 'binding-save', 'managed-save', 'managed-discover', 'rule-save'].forEach(function (id) { $(id).classList.add('needs-unlock'); });
  Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) { b.classList.add('needs-unlock'); });
  setButtonIcon($('join-open'), 'join');
  attachHint($('join-open'), '<b>bridge/request/permit_join</b> {"time": 254}<br>Lets new devices join for four minutes. Asks for the PIN.');
  setButtonIcon($('join-close'), 'lock');
  attachHint($('join-close'), '<b>bridge/request/permit_join</b> {"time": 0}<br>Closes the network to new devices.');
  var resetHints = {
    history: '<b>POST /api/reset</b> {"scope": "history"}<br>Every recorded sample, full and hourly. Devices and events stay.',
    events: '<b>POST /api/reset</b> {"scope": "events"}<br>The event log only.',
    all: '<b>POST /api/reset</b> {"scope": "all"}<br><em>Everything</em> this dashboard recorded. Button bindings are kept.'
  };
  Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) {
    setButtonIcon(b, 'trash');
    attachHint(b, resetHints[b.getAttribute('data-reset')] || '');
  });
  setButtonIcon($('reset-device-btn'), 'forget');
  attachHint($('reset-device-btn'), '<b>POST /api/reset</b> {"scope": "device"}<br>Removes the device and its history from here. Zigbee2MQTT still knows it; it comes back with its next report.');
  setButtonIcon($('binding-add'), 'add');
  setButtonIcon($('binding-save'), 'save');
  setButtonIcon($('rule-add'), 'add');
  setButtonIcon($('rule-save'), 'save');
  attachHint($('rule-save'), '<b>POST /api/rules</b><br>Replaces the whole list. Edge-triggered with a cooldown; the daemon evaluates every report and every plug poll.');
  attachHint($('binding-save'), '<b>POST /api/bindings</b><br>Replaces the whole list. The daemon applies it at once, no restart.');
})();

// ---- smart plugs -----------------------------------------------------------------
function powerIcon() {
  return '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/></svg>';
}
function runtimeText(seconds) {
  if (!isNum(seconds)) return '–';
  var d = Math.floor(seconds / 86400), h = Math.floor((seconds % 86400) / 3600), m = Math.floor((seconds % 3600) / 60);
  if (d) return d + 'd ' + h + 'h';
  if (h) return h + 'h ' + m + 'm';
  return m + 'm';
}
function counterSince(counter) {
  if (!counter || !counter.reset_at) return 'the plug does not say since when';
  return (counter.reset_exact ? 'since ' : 'counting since at least ') + stamp(counter.reset_at) + ' · ' + ago(counter.reset_at);
}
function counterText(type, value) {
  if (type === 'aenergy' || type === 'ret_aenergy') return value >= 1000 ? fmt(value / 1000, 2) + ' kWh' : fmt(value, 1) + ' Wh';
  if (type === 'switch_on') return fmt(value, 0) + '×';
  return runtimeText(value);
}
function plugByName(name) {
  var plugs = (STATE.status && STATE.status.plugs) || [];
  for (var i = 0; i < plugs.length; i++) if (plugs[i].name === name) return plugs[i];
  return null;
}
// ---- buttons: what was just pressed, and what the device can send -----------------
function prettyAction(action) {
  var m = /^([0-9]+)_(.+)$/.exec(action || '');
  return {
    text: (m ? m[2] : action || '').replace(/_/g, ' '),
    button: m ? m[1] : null,
  };
}
function lastActionReading(d) {
  var r = el('div', 'reading lastact');
  var last = d.last_action;
  if (!last) {
    r.appendChild(el('div', 'v', '—'));
    r.appendChild(el('div', 'l', 'No press seen yet'));
    return r;
  }
  var p = prettyAction(last.action);
  var fresh = STATE.status && (STATE.status.ts - last.ts) < 20;
  if (fresh) r.className += ' fresh';
  var v = el('div', 'v', p.text);
  r.appendChild(v);
  r.appendChild(el('div', 'l', (p.button ? 'button ' + p.button + ' · ' : '') + (fresh ? 'just now' : ago(last.ts))));
  r.title = 'Last action: ' + last.action + ' · ' + stamp(last.ts);
  return r;
}
function actionChips(d) {
  var box = el('div', 'actchips');
  var actions = d.actions || [];
  // A multi-button remote names everything N_action; fold the buttons away
  // and list each gesture once.
  var suffixes = [], buttons = {}, grouped = actions.length > 0;
  actions.forEach(function (a) {
    var m = /^([0-9]+)_(.+)$/.exec(a);
    if (!m) { grouped = false; return; }
    buttons[m[1]] = true;
    if (suffixes.indexOf(m[2]) < 0) suffixes.push(m[2]);
  });
  var list = actions, buttonCount = Object.keys(buttons).length;
  if (grouped && buttonCount > 1) {
    list = suffixes;
    var g = el('span', 'chip groups', buttonCount + ' buttons');
    g.title = 'Each gesture exists for every button: ' + actions.join(', ');
    box.appendChild(g);
  }
  var shown = list.slice(0, 7);
  shown.forEach(function (a) { box.appendChild(el('span', 'chip', a.replace(/_/g, ' '))); });
  if (list.length > shown.length) {
    var more = el('span', 'chip more', '+' + (list.length - shown.length));
    more.title = list.join(', ');
    box.appendChild(more);
  }
  return box;
}
// ---- the overview layout: drag to reorder while editing is unlocked ----------------
// The saved order lives in the daemon (meta), so every browser sees the same
// layout. While a card is being dragged the two lists are not re-rendered;
// the drop reads the final order straight from the DOM and saves it.
var ORDER = { drag: null, justDropped: 0, local: {} };
function savedOrder(kind) {
  if (ORDER.local[kind]) return ORDER.local[kind];
  return ((STATE.status || {}).order || {})[kind] || [];
}
function sortByOrder(items, kind, keyFn) {
  var saved = savedOrder(kind);
  if (!saved.length) return items;
  var pos = {};
  saved.forEach(function (k, i) { pos[k] = i; });
  return items.slice().sort(function (a, b) {
    var x = pos[keyFn(a)], y = pos[keyFn(b)];
    return (x === undefined ? 1e9 : x) - (y === undefined ? 1e9 : y);
  });
}
function makeReorderable(node, host, kind, key) {
  node.dataset.okey = key;
  if (!isUnlocked()) return;
  node.draggable = true;
  node.classList.add('cangrab');
  node.addEventListener('dragstart', function (e) {
    ORDER.drag = { kind: kind, key: key, node: node };
    node.classList.add('draggingcard');
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', key); } catch (err) {} }
  });
  node.addEventListener('dragover', function (e) {
    if (!ORDER.drag || ORDER.drag.kind !== kind || ORDER.drag.key === key) return;
    e.preventDefault();
    var dragged = ORDER.drag.node;
    var siblings = Array.prototype.slice.call(host.children);
    if (siblings.indexOf(dragged) < siblings.indexOf(node)) host.insertBefore(dragged, node.nextSibling);
    else host.insertBefore(dragged, node);
  });
  node.addEventListener('dragend', function () {
    node.classList.remove('draggingcard');
    if (!ORDER.drag) return;
    ORDER.drag = null;
    ORDER.justDropped = Date.now();
    var keys = Array.prototype.map.call(host.children, function (c) { return c.dataset.okey; }).filter(Boolean);
    ORDER.local[kind] = keys;
    var payload = { plugs: savedOrder('plugs'), devices: savedOrder('devices') };
    post('order', payload).then(function () { toast('Layout saved', true); },
      function (e) { toast('Layout not saved: ' + (e.message || e), false); ORDER.local = {}; tick(true); });
  });
}

// Four little bars beside every signal figure; the number stays. LQI is the
// Zigbee link (0-255, higher is better), rssi the plug's Wi-Fi in dBm.
function signalBars(kind, value, thresholds) {
  var q = 0, color;
  if (kind === 'lqi') {
    var crit = (thresholds || {}).lqi_crit || 20, warn = (thresholds || {}).lqi_warn || 40;
    q = value >= 160 ? 4 : value >= 100 ? 3 : value > warn ? 2 : value > crit ? 1 : 0;
    color = value <= crit ? 'var(--crit)' : (value <= warn ? 'var(--warn)' : 'var(--ok)');
  } else {
    q = value >= -55 ? 4 : value >= -65 ? 3 : value >= -75 ? 2 : value >= -85 ? 1 : 0;
    color = q >= 3 ? 'var(--ok)' : (q === 2 ? 'var(--warn)' : 'var(--crit)');
  }
  var box = el('span', 'sig q' + q);
  box.style.setProperty('--sigc', color);
  for (var i = 0; i < 4; i++) box.appendChild(el('i'));
  box.title = kind === 'lqi' ? 'Zigbee link quality ' + fmt(value, 0) + ' of 255' : 'Wi-Fi signal ' + fmt(value, 0) + ' dBm';
  return box;
}
function renderSockets(st) {
  var host = $('sockets');
  if (ORDER.drag || Date.now() - ORDER.justDropped < 800) return;   // never redraw under a drag
  var plugs = sortByOrder(st.plugs || [], 'plugs', function (p) { return p.name; });
  host.hidden = !plugs.length;
  host.innerHTML = '';
  plugs.forEach(function (plug) {
    var v = plug.values || {};
    var on = plug.output === 1;
    var card = el('div', 'card socket ' + (plug.online ? (on ? 'on' : 'off') : 'off') + (plug.stale ? ' stale' : ''));
    var state = el('div', 'socket-state');
    var btn = el('button', 'socket-toggle'); btn.type = 'button'; btn.innerHTML = powerIcon();
    btn.title = 'Switch ' + plug.name + (on ? ' off' : ' on') + (isUnlocked() ? '' : ' (asks for the PIN)');
    btn.disabled = !plug.online || plug.stale;
    btn.onclick = function () { switchPlug(plug, !on, btn, 'pin'); };
    state.appendChild(btn);
    var txt = el('div');
    txt.appendChild(el('div', 'socket-label', !plug.online ? plug.name + ' unreachable' : plug.name + (on ? ' on' : ' off')));
    var info = plug.info || {};
    var sub = plug.stale
      ? 'last answer ' + ago(plug.generated) + ' — ' + (plug.error || 'no answer') + (plug.retry_in ? ', retrying in ' + plug.retry_in + ' s' : '')
      : [info.model, info.app ? info.app + ' ' + (info.ver || '') : '', plug.host].filter(Boolean).join(' · ');
    txt.appendChild(el('div', 'socket-sub', sub));
    state.appendChild(txt);
    card.appendChild(state);
    var figures = el('div', 'socket-figures');
    var pairs = [
      ['Power', isNum(v.power) ? fmt(v.power, 1) + ' W' : '–'],
      ['Voltage', isNum(v.voltage) ? fmt(v.voltage, 1) + ' V' : '–'],
      ['Current', isNum(v.current) ? fmt(v.current, 3) + ' A' : '–'],
      ['Energy', isNum(v.energy) ? fmt(v.energy / 1000, 3) + ' kWh' : '–'],
      ['Plug temp', isNum(v.temperature) ? fmt(v.temperature, 1) + ' °C' : '–'],
    ];
    if (isNum(v.on_time)) pairs.push(['On time', runtimeText(v.on_time)]);
    if (isNum(v.switch_on)) pairs.push(['Switched', fmt(v.switch_on, 0) + '×']);
    if (isNum(v.rssi)) pairs.push(['Wi-Fi', fmt(v.rssi, 0) + ' dBm', v.rssi]);
    pairs.forEach(function (pr) {
      var box = el('div'); box.appendChild(el('div', 'k', pr[0]));
      var val = el('div', 'v');
      if (pr.length > 2) val.appendChild(signalBars('rssi', pr[2]));
      val.appendChild(document.createTextNode((pr.length > 2 ? ' ' : '') + pr[1]));
      box.appendChild(val); figures.appendChild(box);
    });
    card.appendChild(figures);
    makeReorderable(card, host, 'plugs', plug.name);
    host.appendChild(card);
  });
}
function switchPlug(plug, on, button, mode) {
  if (button) { button.disabled = true; button.classList.add('busy'); }
  var ask = mode === 'pin' ? withPinAlways : withPin;
  ask('Switch ' + plug.name + ' ' + (on ? 'on' : 'off'), on ? 'Restores power to the socket.' : '<b>Everything plugged into it loses power.</b>', function (pin) {
    var body = {name: plug.name, on: on, pin: pin};
    if (mode === 'pin' && !isUnlocked()) body.session = '';   // locked: the PIN alone decides
    return post('plug-switch', body).then(function (r) { return r.message || 'done'; });
  }, !on);
  setTimeout(function () { if (button) { button.disabled = false; button.classList.remove('busy'); } }, 3000);
}
function resetPlugCounters(plug, types, what, button) {
  if (button) { button.disabled = true; button.classList.add('busy'); }
  withPin('Reset ' + what + ' on ' + plug.name, 'That running total starts again from zero. Readings already recorded here are kept.', function (pin) {
    return post('plug-reset', {name: plug.name, types: types, pin: pin}).then(function (r) { return r.message || 'done'; });
  }, true);
  setTimeout(function () { if (button) { button.disabled = false; button.classList.remove('busy'); } renderPlugControls(STATE.status); }, 3000);
}
function renderPlugControls(st) {
  var card = $('plug-control'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  var host = $('plug-control-list'); host.innerHTML = '';
  plugs.forEach(function (plug) {
    var on = plug.output === 1, online = plug.online && !plug.stale;
    var info = plug.info || {};
    var block = el('div'); block.style.cssText = 'padding:12px 0;border-bottom:1px solid var(--line)';
    var head = el('div', 'row');
    head.appendChild(el('b', '', plug.name));
    head.appendChild(el('span', 'tag ' + (online ? (on ? 'ok' : 'dim') : 'crit'), online ? (on ? 'on' : 'off') : 'unreachable'));
    block.appendChild(head);
    block.appendChild(el('p', 'btnhelp', plug.stale
      ? 'The plug last answered ' + ago(plug.generated) + ': ' + (plug.error || 'no answer') + '. Controls are disabled until it responds.'
      : online ? [info.model, info.app ? info.app + ' ' + (info.ver || '') : '', plug.host].filter(Boolean).join(' · ') + ' — switching the socket cuts power to whatever is plugged into it.'
              : 'The plug is not answering: ' + (plug.error || 'unknown reason')));
    var row = el('div', 'btnrow');
    var toggle = cmdButton(on ? 'Switch the socket off' : 'Switch the socket on', 'power', on ? 'danger' : 'primary');
    toggle.disabled = !online;
    attachHint(toggle, '<b>Switch.Set ' + (on ? 'off' : 'on') + '</b><br>' + (on ? 'Cuts power to everything plugged into this socket.' : 'Restores power to the socket.') + '<br>Asks for the PIN.');
    toggle.onclick = function () { switchPlug(plug, !on, toggle); };
    row.appendChild(toggle);
    var pulse = cmdButton('Pulse ' + (on ? 'off' : 'on') + ' for ' + ((st.pulse_ms || {}).default || 5000) / 1000 + ' s', 'reboot');
    pulse.disabled = !online || (st.pulsing || []).indexOf(plug.name) >= 0;
    attachHint(pulse, '<b>Switch.Set ' + (on ? 'off' : 'on') + '</b>, wait, <b>Switch.Set ' + (on ? 'on' : 'off') + '</b><br>' + (on ? 'Cuts power briefly - a power-cycle for whatever is plugged in.' : 'Powers the socket briefly and switches it off again.') + '<br>Asks for the PIN.');
    pulse.onclick = function () {
      pulse.disabled = true; pulse.classList.add('busy');
      withPin('Pulse ' + plug.name, (on ? '<b>Power is cut for ' : 'Power is on for ') + ((st.pulse_ms || {}).default || 5000) / 1000 + ' s</b>, then the socket goes back to ' + (on ? 'on' : 'off') + '.', function (pin) {
        return post('plug-switch', {name: plug.name, pulse: true, ms: (st.pulse_ms || {}).default || 5000, pin: pin}).then(function (r) { return r.message || 'done'; });
      }, on);
      setTimeout(function () { pulse.disabled = false; pulse.classList.remove('busy'); }, 3000);
    };
    row.appendChild(pulse);
    block.appendChild(row);

    var counters = (plug.counters || []).filter(function (c) { return c.value !== null && c.value !== undefined; });
    if (counters.length && online) {
      var heading = el('h3', '', 'Reset a counter');
      heading.style.cssText = 'font-size:12px;letter-spacing:.8px;text-transform:uppercase;color:var(--tx-mut);margin:18px 0 6px';
      block.appendChild(heading);
      block.appendChild(el('p', 'btnhelp', "These are the plug's own running totals, the same ones its web interface lists. Resetting one starts it from zero; the history recorded here is untouched."));
      var crow = el('div', 'btnrow');
      counters.forEach(function (c) {
        var b = cmdButton(c.label + ' · ' + counterText(c.type, c.value), 'reset');
        b.disabled = c.value === 0;
        attachHint(b, '<b>Switch.ResetCounters</b> {"type": ["' + c.type + '"]}<br>' + c.help + '.<br>'
          + (c.reset_at ? counterSince(c).replace(/^./, function (x) { return x.toUpperCase(); }) : 'Never reset from here, and the plug does not say when it was.')
          + (c.value === 0 ? '<br><em>Already at zero.</em>' : ''));
        b.onclick = function () { resetPlugCounters(plug, [c.type], c.label.toLowerCase(), b); };
        crow.appendChild(b);
      });
      var all = cmdButton('All counters', 'trash', 'danger');
      attachHint(all, '<b>Switch.ResetCounters</b><br>Every counter above, back to zero in one go.');
      all.onclick = function () { resetPlugCounters(plug, [], 'every counter', all); };
      crow.appendChild(all);
      block.appendChild(crow);
    }
    host.appendChild(block);
  });
}

// ---- plugs and sensors managed from here -------------------------------------------
var MANAGED = { rows: null, dirty: false };
function managedRows(st) {
  var out = [];
  ['plugs', 'sensors'].forEach(function (kind) {
    ((st && st.managed && st.managed[kind]) || []).forEach(function (e) {
      out.push(Object.assign({kind: kind === 'plugs' ? 'plug' : 'sensor', password: ''}, e));
    });
  });
  return out;
}
function markManaged() { MANAGED.dirty = true; $('managed-note').textContent = 'Unsaved changes'; }
function renderManaged(st) {
  if (MANAGED.rows === null || !MANAGED.dirty) MANAGED.rows = managedRows(st);
  var host = $('managed-list'); host.innerHTML = '';
  if (!MANAGED.rows.length) host.appendChild(el('div', 'muted small', 'No plug or sensor yet. Add one, or let the daemon look for them.'));
  var fromCfg = [], fromUi = [];
  MANAGED.rows.forEach(function (e, i) { (e.source === 'config' ? fromCfg : fromUi).push([e, i]); });
  function managedHead() {
    var head = el('div', 'dev-row dev-head bind-head');
    ['Type', 'Name', 'Address', 'Password', 'Relay', 'MQTT prefix', 'State', '', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
    return head;
  }
  if (fromCfg.length) {
    host.appendChild(el('div', 'managed-sub', 'From config.json — read-only here'));
    host.appendChild(managedHead());
    fromCfg.forEach(function (pair) { host.appendChild(managedRow(pair[0], pair[1])); });
  }
  if (fromUi.length || fromCfg.length) {
    host.appendChild(el('div', 'managed-sub', 'Managed on this dashboard'));
  }
  if (fromUi.length) {
    host.appendChild(managedHead());
    fromUi.forEach(function (pair) { host.appendChild(managedRow(pair[0], pair[1])); });
  } else if (fromCfg.length) {
    host.appendChild(el('div', 'muted small', 'Nothing yet — Add plug, Add sensor, or Find Shelly devices.'));
  }
  function managedRow(e, i) {
    var fromConfig = e.source === 'config';
    var row = el('div', 'dev-row');
    var kind = el('select'); fillSelect(kind, [['plug', 'plug'], ['sensor', 'sensor']], e.kind); kind.disabled = fromConfig;
    kind.onchange = function () { e.kind = kind.value; markManaged(); renderManaged(STATE.status); };
    var name = el('input'); name.value = e.name || ''; name.placeholder = 'Lednice'; name.disabled = fromConfig;
    name.oninput = function () { e.name = name.value; markManaged(); };
    var addr = el('input'); addr.value = e.host || ''; addr.placeholder = '172.16.16.14'; addr.disabled = fromConfig;
    addr.oninput = function () { e.host = addr.value; markManaged(); };
    var pw = el('input'); pw.type = 'password'; pw.autocomplete = 'new-password'; pw.disabled = fromConfig;
    pw.placeholder = fromConfig ? (e.password_set ? 'set in config.json' : 'none') : (e.password_set ? '(kept)' : 'none');
    pw.oninput = function () { e.password = pw.value; markManaged(); };
    var sw = el('input'); sw.type = 'number'; sw.min = 0; sw.max = 7; sw.value = e.switch_id || 0; sw.disabled = fromConfig || e.kind !== 'plug';
    sw.oninput = function () { e.switch_id = parseInt(sw.value, 10) || 0; markManaged(); };
    var mq = el('input'); mq.value = e.mqtt_name || ''; mq.placeholder = 'shellies/…'; mq.disabled = fromConfig; mq.title = 'The device\'s shellies/<name> prefix if it also publishes over MQTT, so it is not recorded twice';
    mq.oninput = function () { e.mqtt_name = mq.value; markManaged(); };
    var en = el('select');
    fillSelect(en, [['1', 'enabled'], ['0', 'disabled']], (e.enabled === false ? '0' : '1'));
    en.disabled = fromConfig;
    en.title = fromConfig ? 'Set "enabled": false in config.json' : 'Disabled: not polled, not controllable, hidden from the lists - its history and any bindings or rules stay for when it comes back';
    en.style.opacity = e.enabled === false ? '.6' : '';
    en.onchange = function () { e.enabled = en.value === '1'; markManaged(); renderManaged(STATE.status); };
    var test = cmdButton('Test', 'check', 'small');
    attachHint(test, '<b>Shelly.GetDeviceInfo</b> from the server to this address.<br>Fills in the model and says whether it is a plug or a sensor. Asks for the PIN.');
    test.onclick = function () {
      test.disabled = true; test.classList.add('busy');
      withPin('Test ' + (e.name || e.host), 'The daemon asks the device at <b>' + esc(e.host || '?') + '</b> who it is.', function (pin) {
        return post('managed-test', {host: e.host, password: e.password || '', pin: pin}).then(function (r) {
          if (r.kind && r.kind !== e.kind && !fromConfig) { e.kind = r.kind; markManaged(); renderManaged(STATE.status); }
          return (r.model || '?') + ' · ' + (r.app || '') + ' ' + (r.ver || '') + (r.auth && !e.password && !e.password_set ? ' · needs a password' : '') + ' · ' + (r.kind === 'plug' ? 'has a switch' : 'no switch, a sensor');
        });
      });
      setTimeout(function () { test.disabled = false; test.classList.remove('busy'); }, 3000);
    };
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.disabled = fromConfig;
    if (fromConfig) del.title = 'Defined in config.json';
    del.onclick = function () { MANAGED.rows.splice(i, 1); markManaged(); renderManaged(STATE.status); };
    if (e.enabled === false) [kind, name, addr, pw, sw, mq].forEach(function (x) { x.style.opacity = '.55'; });
    [kind, name, addr, pw, sw, mq, en, test, del].forEach(function (x) { row.appendChild(x); });
    return row;
  }
  if (!MANAGED.dirty) $('managed-note').textContent = '';
}
$('managed-add-plug').onclick = function () {
  MANAGED.rows = MANAGED.rows || []; MANAGED.rows.push({kind: 'plug', name: '', host: '', password: '', switch_id: 0, mqtt_name: '', source: 'ui'});
  markManaged(); renderManaged(STATE.status);
  var inputs = $('managed-list').querySelectorAll('.dev-row:last-child input'); if (inputs[0]) inputs[0].focus();
};
$('managed-add-sensor').onclick = function () {
  MANAGED.rows = MANAGED.rows || []; MANAGED.rows.push({kind: 'sensor', name: '', host: '', password: '', switch_id: 0, mqtt_name: '', source: 'ui'});
  markManaged(); renderManaged(STATE.status);
};
$('managed-discover').onclick = function () {
  var b = $('managed-discover'); b.disabled = true; b.classList.add('busy');
  $('managed-found').textContent = 'Asking the network…';
  withPin('Find Shelly devices', 'The daemon sends a multicast DNS query and lists what answers within three seconds. Only this subnet.', function (pin) {
    return post('managed-discover', {pin: pin}).then(function (r) {
      var box = $('managed-found'); box.innerHTML = '';
      if (!r.devices.length) { box.textContent = 'Nothing answered. Devices on other subnets do not; add them by address.'; return 'no answer'; }
      r.devices.forEach(function (dv) {
        var line = el('div'); line.style.margin = '4px 0';
        line.appendChild(el('span', 'mono', dv.ip + '  '));
        line.appendChild(el('span', '', dv.names.join(', ') + (dv.known ? ' — already listed' : '') + ' '));
        if (!dv.known) {
          var add = cmdButton('Add', 'add', 'small');
          add.onclick = function () {
            MANAGED.rows = MANAGED.rows || [];
            MANAGED.rows.push({kind: /plug/i.test(dv.names.join()) ? 'plug' : 'sensor', name: (dv.names[0] || dv.ip).replace(/\..*$/, ''), host: dv.ip, password: '', switch_id: 0, mqtt_name: '', source: 'ui'});
            markManaged(); renderManaged(STATE.status); line.remove();
          };
          line.appendChild(add);
        }
        box.appendChild(line);
      });
      return r.devices.length + ' device(s) answered';
    });
  });
  setTimeout(function () { b.disabled = false; b.classList.remove('busy'); }, 4000);
};
$('managed-save').onclick = function () {
  var plugs = [], sensors = [];
  (MANAGED.rows || []).forEach(function (e) {
    var row = {name: e.name, host: e.host, switch_id: e.switch_id || 0, mqtt_name: e.mqtt_name || '', source: e.source || 'ui', enabled: e.enabled !== false};
    if (e.password) row.password = e.password;
    (e.kind === 'plug' ? plugs : sensors).push(row);
  });
  withPin('Save devices', 'The daemon starts polling new entries at once and drops removed ones.', function (pin) {
    return post('managed-save', {plugs: plugs, sensors: sensors, pin: pin}).then(function (r) {
      MANAGED.dirty = false; MANAGED.rows = null;
      return (r.plugs || []).length + ' plug(s), ' + (r.sensors || []).length + ' sensor(s) saved';
    });
  });
};

// ---- button bindings --------------------------------------------------------------
var BINDINGS = {rows: null, dirty: false};
function bindingDevices(st) {
  // Only devices that can send an action - a button, a remote, a contact with
  // a click - plus anything a saved binding still points at.
  var list = st.devices.filter(function (d) { return d.has_action; });
  var ids = list.map(function (d) { return d.id; });
  (BINDINGS.rows || []).forEach(function (b) {
    var d = b.device && deviceById(b.device);
    if (d && ids.indexOf(d.id) < 0) { list.push(d); ids.push(d.id); }
  });
  return list;
}
function actionOptions(device, current) {
  var opts = device && device.actions ? device.actions.slice() : [];
  if (!opts.length) opts = ['single', 'double', 'triple', 'long', 'hold', 'release'];
  if (current && current !== '*' && opts.indexOf(current) < 0) opts.push(current);
  opts.push('*');
  return opts;
}
function fillSelect(select, options, current) {
  select.innerHTML = '';
  options.forEach(function (o) {
    var opt = el('option', '', typeof o === 'string' ? o : o[1]);
    opt.value = typeof o === 'string' ? o : o[0];
    select.appendChild(opt);
  });
  if (current !== undefined && current !== null && Array.prototype.some.call(select.options, function (o) { return o.value === String(current); })) select.value = current;
  return select.value;
}
function renderBindings(st) {
  var card = $('bindings-card'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  if (!plugs.length) return;
  if (BINDINGS.rows === null || !BINDINGS.dirty) BINDINGS.rows = (st.bindings || []).map(function (b) { return Object.assign({}, b); });
  var host = $('bindings-list'); host.innerHTML = '';
  var head = el('div', 'bind-row bind-head');
  ['Device', 'Action', 'Plug', 'Do', 'Pulse delay', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  var devices = bindingDevices(st);
  if (!BINDINGS.rows.length) host.appendChild(el('div', 'muted small', devices.length ? 'No bindings yet.' : 'No device that sends actions has been seen yet. Pair a button and press it once.'));
  BINDINGS.rows.forEach(function (b, i) {
    var row = el('div', 'bind-row');
    var dev = el('select'), act = el('select'), plug = el('select'), doSel = el('select');
    b.device = fillSelect(dev, devices.map(function (d) { return [d.id, d.name + (d.actions && d.actions.length ? ' (' + d.actions.length + ' actions)' : '')]; }), b.device);
    function refillActions() {
      b.action = fillSelect(act, actionOptions(deviceById(b.device), b.action), b.action || 'single');
    }
    refillActions();
    dev.onchange = function () { b.device = dev.value; b.action = null; refillActions(); BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    act.onchange = function () { b.action = act.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    var plugOptions = plugs.map(function (p) { return [p.name, p.name + (p.online ? '' : ' (unreachable)')]; });
    (st.switch_targets || []).forEach(function (t) { plugOptions.push([t.value, '\u26a1 ' + t.name + (t.online ? '' : ' (offline)')]); });
    if (plugs.length > 1) plugOptions.push(['*', '\u2014 all plugs \u2014']);
    if (b.plug && b.plug !== '*' && !plugOptions.some(function (o) { return o[0] === b.plug; })) plugOptions.push([b.plug, b.plug + ' (disabled)']);
    b.plug = fillSelect(plug, plugOptions, b.plug);
    plug.onchange = function () { b.plug = plug.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    b.do = fillSelect(doSel, (st.binding_actions || ['toggle', 'on', 'off', 'pulse']).map(function (a) {
      return [a, {toggle: 'toggle', on: 'switch on', off: 'switch off', pulse: 'pulse (flip, wait, flip back)'}[a] || a]; }), b.do || 'toggle');
    var limits = st.pulse_ms || {default: 5000, min: 100, max: 3600000};
    var msBox = el('span', 'ms' + (b.do === 'pulse' ? ' show' : ''));
    var ms = el('input'); ms.type = 'number'; ms.min = limits.min; ms.max = limits.max; ms.step = 100;
    ms.value = b.pulse_ms || limits.default; ms.title = 'How long the plug stays flipped before it is switched back';
    if (b.do === 'pulse') b.pulse_ms = parseInt(ms.value, 10);
    ms.oninput = function () { b.pulse_ms = parseInt(ms.value, 10) || limits.default; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    msBox.appendChild(ms); msBox.appendChild(el('span', '', 'ms'));
    doSel.onchange = function () {
      b.do = doSel.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes';
      msBox.classList.toggle('show', b.do === 'pulse');
      if (b.do === 'pulse') { b.pulse_ms = parseInt(ms.value, 10) || limits.default; ms.focus(); }
    };
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.onclick = function () { BINDINGS.rows.splice(i, 1); BINDINGS.dirty = true; renderBindings(STATE.status); };
    [dev, act, plug, doSel, msBox, del].forEach(function (x) { row.appendChild(x); });
    host.appendChild(row);
  });
  $('binding-add').disabled = !devices.length;
  $('binding-note').textContent = BINDINGS.dirty ? 'Unsaved changes' : (devices.length ? '' : 'Pair a button first');
}
$('binding-add').onclick = function () {
  BINDINGS.rows = BINDINGS.rows || [];
  BINDINGS.rows.push({device: '', action: null, plug: '', do: 'toggle', enabled: true});
  BINDINGS.dirty = true;
  renderBindings(STATE.status);
};
$('binding-save').onclick = function () {
  withPin('Save button bindings', 'Confirm with the dashboard PIN.', function (pin) {
    return post('bindings-save', {bindings: BINDINGS.rows || [], pin: pin}).then(function (r) {
      BINDINGS.dirty = false; BINDINGS.rows = null;
      return (r.bindings || []).length + ' binding(s) saved';
    });
  });
};

// ---- sensor rules -------------------------------------------------------------------
var RULES = { rows: null, dirty: false };
function markRules() { RULES.dirty = true; $('rule-note').textContent = 'Unsaved changes'; }
function ruleSources(st) {
  return st.devices.filter(function (d) {
    return Object.keys(d.values || {}).some(function (k) { return isNum((d.values[k] || {}).value); });
  });
}
function ruleWorthy(v) {
  if (isNum(v)) return true;
  if (typeof v === 'boolean') return true;
  if (typeof v === 'string') return ['ON', 'OFF', 'OPEN', 'CLOSE', 'CLOSED', 'TRUE', 'FALSE', 'OCCUPIED', 'CLEAR', 'YES', 'NO'].indexOf(v.toUpperCase()) >= 0;
  return false;
}
function numericKeys(device, current) {
  var keys = device ? Object.keys(device.values || {}).filter(function (k) { return ruleWorthy((device.values[k] || {}).value); }) : [];
  if (current && keys.indexOf(current) < 0) keys.push(current);
  return keys;
}
function renderRules(st) {
  var card = $('rules-card'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  if (!plugs.length) return;
  if (RULES.rows === null || !RULES.dirty) RULES.rows = (st.rules || []).map(function (r) { return Object.assign({}, r); });
  var host = $('rules-list'); host.innerHTML = '';
  var head = el('div', 'rule-row bind-head');
  ['Source', 'Value', 'Is', 'Threshold', 'Plug', 'Do', 'Cooldown', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  var sources = ruleSources(st);
  if (!RULES.rows.length) host.appendChild(el('div', 'muted small', sources.length ? 'No rules yet.' : 'No device with numeric readings seen yet.'));
  RULES.rows.forEach(function (r, i) {
    var row = el('div', 'rule-row');
    var dev = el('select'), key = el('select'), op = el('select'), plug = el('select'), doSel = el('select');
    var list = sources.slice();
    if (r.device && !list.some(function (d) { return d.id === r.device; })) { var known = deviceById(r.device); if (known) list.push(known); }
    r.device = fillSelect(dev, list.map(function (d) { return [d.id, d.name]; }), r.device);
    function refillKeys() {
      var device = deviceById(r.device);
      r.key = fillSelect(key, numericKeys(device, r.key).map(function (k) {
        var label = ((device || {}).values || {})[k] || {};
        var binary = !isNum(label.value) && ruleWorthy(label.value);
        return [k, (label.label || k) + (label.unit ? ' (' + label.unit + ')' : (binary ? ' (1 = yes/on)' : ''))];
      }), r.key);
    }
    refillKeys();
    dev.onchange = function () { r.device = dev.value; r.key = null; refillKeys(); unitHint(); markRules(); };
    key.onchange = function () { r.key = key.value; unitHint(); markRules(); };
    r.op = fillSelect(op, (st.rule_ops || ['>=', '<=', '>', '<']).map(function (o) { return [o, {'>=': '\u2265', '<=': '\u2264', '>': '>', '<': '<'}[o] || o]; }), r.op || '>=');
    op.onchange = function () { r.op = op.value; markRules(); };
    var val = el('input'); val.type = 'number'; val.step = 'any'; val.value = r.value !== undefined && r.value !== null ? r.value : '';
    function unitHint() {
      var device = deviceById(r.device), info = device && device.values ? device.values[r.key] : null;
      val.placeholder = (info && info.unit) || 'value';
      val.title = info ? (info.label || r.key) + (info.unit ? ' in ' + info.unit : '') + ', now ' + fmt(info.value) : '';
    }
    unitHint();
    val.oninput = function () { r.value = parseFloat(val.value); markRules(); };
    var plugOptions = plugs.map(function (p) { return [p.name, p.name]; });
    (st.switch_targets || []).forEach(function (t) { plugOptions.push([t.value, '\u26a1 ' + t.name + (t.online ? '' : ' (offline)')]); });
    if (plugs.length > 1) plugOptions.push(['*', '\u2014 all plugs \u2014']);
    if (r.plug && r.plug !== '*' && !plugOptions.some(function (o) { return o[0] === r.plug; })) plugOptions.push([r.plug, r.plug + ' (disabled)']);
    r.plug = fillSelect(plug, plugOptions, r.plug);
    plug.onchange = function () { r.plug = plug.value; markRules(); };
    var doBox = el('span'); doBox.style.display = 'flex'; doBox.style.gap = '6px'; doBox.style.alignItems = 'center';
    var limits = st.pulse_ms || {default: 5000, min: 100, max: 3600000};
    var ms = el('input'); ms.type = 'number'; ms.min = limits.min; ms.max = limits.max; ms.step = 100; ms.value = r.pulse_ms || limits.default;
    ms.style.width = '90px'; ms.title = 'pulse hold time, ms'; ms.hidden = r.do !== 'pulse';
    ms.oninput = function () { r.pulse_ms = parseInt(ms.value, 10) || limits.default; markRules(); };
    r.do = fillSelect(doSel, (st.binding_actions || []).map(function (a) {
      return [a, {toggle: 'toggle', on: 'switch on', off: 'switch off', pulse: 'pulse'}[a] || a]; }), r.do || 'on');
    doSel.onchange = function () { r.do = doSel.value; ms.hidden = r.do !== 'pulse'; if (r.do === 'pulse') r.pulse_ms = parseInt(ms.value, 10) || limits.default; markRules(); };
    doBox.appendChild(doSel); doBox.appendChild(ms);
    var cool = el('input'); cool.type = 'number'; cool.min = 0; cool.step = 10; cool.value = r.cooldown_s !== undefined ? r.cooldown_s : 300; cool.title = 'seconds before the same rule may fire again';
    cool.oninput = function () { r.cooldown_s = parseInt(cool.value, 10) || 0; markRules(); };
    var last = el('span', 'now');
    if (r.reading !== undefined && r.reading !== null) last.innerHTML = 'now ' + fmt(r.reading) + (r.holds ? ' <b>&middot; true</b>' : '');
    var del = cmdButton('Remove', 'cancel', 'small danger'); del.classList.remove('needs-unlock');
    del.onclick = function () { RULES.rows.splice(i, 1); markRules(); renderRules(STATE.status); };
    var cell = el('span'); cell.style.display = 'flex'; cell.style.gap = '8px'; cell.style.alignItems = 'center';
    cell.appendChild(cool); cell.appendChild(last);
    [dev, key, op, val, plug, doBox, cell, del].forEach(function (x) { row.appendChild(x); });
    host.appendChild(row);

    // the clock window, on its own quiet line under the rule
    var sub = el('div', 'rule-sub');
    sub.appendChild(el('span', '', 'Active'));
    var tFrom = el('input'); tFrom.type = 'time'; tFrom.value = r.from || '';
    tFrom.onchange = function () { r.from = tFrom.value; markRules(); };
    var tTo = el('input'); tTo.type = 'time'; tTo.value = r.to || '';
    tTo.onchange = function () { r.to = tTo.value; markRules(); };
    sub.appendChild(tFrom); sub.appendChild(el('span', '', '\u2013')); sub.appendChild(tTo);
    sub.appendChild(el('span', 'muted', 'empty = around the clock; 22:00\u201306:00 crosses midnight \u00b7 when the window closes'));
    var endSel = el('select');
    fillSelect(endSel, [['', 'leave the plug as it is'], ['off', 'switch it off'], ['on', 'switch it on']], r.window_end || '');
    endSel.onchange = function () { r.window_end = endSel.value; markRules(); };
    endSel.title = 'The safe state: a motion-driven light is switched off when its night window ends, whether or not anyone walked by at that moment';
    sub.appendChild(endSel);
    if (r.from && !STATE_RULE_WINDOW_OPEN(r)) sub.appendChild(el('span', 'tag dim', 'outside its hours now'));
    host.appendChild(sub);
  });
  function STATE_RULE_WINDOW_OPEN(r) {
    if (!r.from || !r.to) return true;
    var d = new Date(), m = d.getHours() * 60 + d.getMinutes();
    var f = parseInt(r.from.slice(0, 2), 10) * 60 + parseInt(r.from.slice(3), 10);
    var t = parseInt(r.to.slice(0, 2), 10) * 60 + parseInt(r.to.slice(3), 10);
    if (f === t) return true;
    return f < t ? (m >= f && m < t) : (m >= f || m < t);
  }
  if (!RULES.dirty) $('rule-note').textContent = '';
  $('rule-add').disabled = !sources.length;
}
$('rule-add').onclick = function () {
  RULES.rows = RULES.rows || [];
  RULES.rows.push({device: '', key: null, op: '>=', value: '', plug: '', do: 'on', cooldown_s: 300, enabled: true});
  markRules(); renderRules(STATE.status);
};
$('rule-save').onclick = function () {
  withPin('Save sensor rules', 'The daemon applies them at once; each fires when its condition becomes true.', function (pin) {
    return post('rules-save', {rules: RULES.rows || [], pin: pin}).then(function (r) {
      RULES.dirty = false; RULES.rows = null;
      return (r.rules || []).length + ' rule(s) saved';
    });
  });
};

// ---- live updates: a long poll rides beside the 5 s tick --------------------------
// The daemon holds /api/wait open until something visible changes (a report,
// a plug switching, a bridge event) and answers at once when it does, so a
// button press shows up here in well under a second. The 5 s tick stays as
// the safety net; if the wait endpoint fails, nothing is worse than before.
var WAIT = { running: false, failures: 0 };
function waitLoop() {
  if (WAIT.running) return;
  WAIT.running = true;
  (function loop() {
    if (document.hidden || !STATE.status) { WAIT.running = false; setTimeout(waitLoop, 1000); return; }
    var seen = STATE.status.seq || 0;
    api('wait&seq=' + seen).then(function (r) {
      WAIT.failures = 0;
      if (r.seq !== seen) tick(true);
      setTimeout(loop, 120);
    }, function () {
      WAIT.failures++;
      setTimeout(loop, Math.min(15000, 2000 * WAIT.failures));
    });
  })();
}
document.addEventListener('visibilitychange', function () { if (!document.hidden) waitLoop(); });

// ---- refresh loop ------------------------------------------------------------------
function applyStatus(st) {
  STATE.status = st;
  var pill = $('pill');
  pill.className = 'pill ' + st.level;
  $('pill-text').textContent = levelWord(st.level) + (st.connected ? '' : ' — broker unreachable');
  setFavicon(st.level);
  waitLoop();
  if (LOCK.token && st.pin_required && !st.unlocked_until) setLocked('Editing locked by the daemon');
  renderLock();
  document.title = (st.level === 'ok' ? '' : (st.level === 'crit' ? '⚠ ' : '● ')) + 'Sensors — ' + st.counts.devices + ' devices';
  renderOverview(st);
  renderHistoryControls();
  renderDevices(st);
  renderAll(st);
  renderPlugControls(st);
  if (!BINDINGS.dirty) renderBindings(st);   // never redraw under someone's typing
  if (!MANAGED.dirty) renderManaged(st);
  if (!RULES.dirty) renderRules(st);
  $('updated-time').textContent = stamp(st.ts);
}
function tick(force) {
  if ((STATE.paused || document.hidden) && !force) return;
  if (STATE.busy) return;
  STATE.busy = true;
  api('status').then(function (st) {
    applyStatus(st);
    $('updated-label').textContent = STATE.paused ? 'Paused' : 'Live';
    if (STATE.tab === 'overview' && (force || !STATE._ovLoaded || (Date.now() - STATE._ovLoaded) > 60000)) { loadOverviewCharts(); STATE._ovLoaded = Date.now(); }
    if (STATE.tab === 'events' && force) loadEvents();
    if (STATE.tab === 'control') loadHealth();
  }).catch(function (e) {
    $('pill').className = 'pill crit'; $('pill-text').textContent = 'Dashboard offline';
    $('updated-label').textContent = 'Error';
    $('updated-time').textContent = e.message;
    setFavicon('crit');
  }).then(function () { STATE.busy = false; });
}
function showTab(name) {
  STATE.tab = name;
  Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
    b.setAttribute('aria-selected', b.getAttribute('data-tab') === name ? 'true' : 'false');
  });
  Array.prototype.forEach.call(document.querySelectorAll('.panel'), function (p) { p.hidden = p.id !== 'tab-' + name; });
  if (name === 'history') { renderHistoryControls(); loadHistory(); }
  if (name === 'events') loadEvents();
  if (name === 'control') loadHealth();
  if (name === 'overview') { redrawCharts(); if (!STATE._ovLoaded) { loadOverviewCharts(); STATE._ovLoaded = Date.now(); } }
  try { history.replaceState(null, '', '#' + name); } catch (e) {}
}
Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
  b.onclick = function () { showTab(b.getAttribute('data-tab')); };
});
$('updated').onclick = function () {
  STATE.paused = !STATE.paused;
  $('updated').classList.toggle('paused', STATE.paused);
  $('updated-label').textContent = STATE.paused ? 'Paused' : 'Live';
  if (!STATE.paused) tick(true);
};
document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(true); });
function pickOverviewRange(r) {
  STATE.ovRange = r; rangeButtons($('ov-ranges'), ['6h', '24h', '7d'], r, pickOverviewRange); loadOverviewCharts();
}
rangeButtons($('ov-ranges'), ['6h', '24h', '7d'], STATE.ovRange, pickOverviewRange);

if (INITIAL) applyStatus(INITIAL);
var wanted = (location.hash || '#overview').substring(1);
showTab(['overview', 'history', 'devices', 'events', 'control', 'all'].indexOf(wanted) >= 0 ? wanted : 'overview');
tick(true);
STATE.timer = setInterval(function () { tick(false); }, REFRESH_MS);
</script>
</body>
</html>
