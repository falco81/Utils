#!/usr/bin/env python3
"""Every path the web relay forwards must be one the daemon actually serves.

Run before a release. It reads both files rather than the running daemon, so
it needs nothing set up, and it catches the mistake that shipped in 2.90.0:
an endpoint written into the daemon's read branch while the page posts to it.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
php = (here / 'web' / 'index.php').read_text()
py = (here / 'zigmon.py').read_text()

relayed = set(re.findall(r"zigmon_relay\('(/api/[a-z0-9/_-]+)", php))
relayed |= set(re.findall(r"=> '(/api/[a-z0-9/_-]+)'", php))

served = set(re.findall(r"path == '(/api/[a-z0-9/_-]+)'", py))
for group in re.findall(r"path in \(([^)]+)\)", py):
    served |= set(re.findall(r"'(/api/[a-z0-9/_-]+)'", group))

# a path the daemon answers by its opening rather than in full, such as a
# one-tap link, where the rest of the path is the link's own secret
starts = re.findall(r"path\.startswith\('(/api/[a-z0-9/_-]+)'\)", py)
missing = sorted(p for p in relayed - served
                 if not any(p.startswith(x) for x in starts))
if missing:
    print('the relay forwards paths the daemon does not serve:')
    for p in missing:
        print('   ', p)
    sys.exit(1)
print('%d relayed path(s), all served' % len(relayed))


# Every name the page calls must be one the relay serves. It caught a save
# that used a button's id as a path and answered "unknown endpoint".
import re as _re
_src = (here / 'web' / 'index.php').read_text() if 'here' in dir() else open(str(__file__).rsplit('/', 2)[0] + '/web/index.php').read()
_js = _re.search(r'<script>(.*?)</script>', _src, _re.S).group(1)
_called = set(_re.findall(r"post\('([a-z0-9-]+)'", _js)) | set(_re.findall(r"api\('([a-z0-9-]+)", _js))
_allow = set(_re.findall(r"'([a-z0-9-]+)'", _re.search(r"if \(in_array\(\$what, \[(.*?)\], true\)", _src, _re.S).group(1)))
_gets = set(_re.findall(r"\$what === '([a-z0-9-]+)'", _src))
_paths = set(_re.findall(r"'([a-z0-9-]+)' => '/api", _src))
_missing = sorted(_called - _allow - _gets - _paths)
if _missing:
    print('the page calls names the relay does not serve:')
    for _name in _missing:
        print('   %s' % _name)
    raise SystemExit(1)
print('%d name(s) the page calls, all of them served' % len(_called))

# ?ask has to survive every hop. It is dropped in two ways that look like
# nothing at all: an nginx rewrite whose replacement holds a ? throws the
# original query away, and a relay that rebuilds the path leaves it behind.
# Either way, asking how things stand quietly becomes switching them.
php = (Path(__file__).resolve().parent.parent / 'web' / 'index.php').read_text()
conf = (Path(__file__).resolve().parent.parent / 'deploy' / 'nginx-zigmon.conf').read_text()
lost = []
for line in php.split('\n'):
    if "'/api/tap/'" in line and 'relay' in line and 'ask' not in line:
        lost.append('the relay drops ?ask: %s' % line.strip()[:70])
for line in conf.split('\n'):
    if line.strip().startswith('rewrite') and '?' in line and '$args' not in line:
        lost.append('this rewrite throws the query away: %s' % line.strip()[:70])
if lost:
    print('?ask would not arrive:')
    for line in lost:
        print('   ' + line)
    sys.exit(1)
print('?ask survives the relay and the rewrite')


# Some answers are not a view of the house but the whole of how it is set up:
# the sockets' password, the router's password and its ssh key, every person's
# phone number and MAC address, a person's own token. Those went out to
# whoever could reach the page, because public_view means anybody may watch
# the house and was taken to mean anybody may read its keys. They ask for the
# PIN whatever public_view says, and this holds the daemon to that list.
sys.path.insert(0, str(here))
sys.argv = ['zigmon']
import zigmon                                             # noqa: E402
_locked = set(zigmon.ApiHandler.ALWAYS_LOCKED)
for _must in ('/api/export', '/api/log', '/api/managed', '/api/sms/log', '/api/mqtt/acl'):
    assert _must in _locked, '%s is readable by anybody' % _must
_words = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
_where = _words.index('if path in self.ALWAYS_LOCKED:')
_before = _words[:_where]
assert "if not CONFIG.get('public_view', True):" not in _before.rsplit('def do_GET', 1)[-1], \
    'the lock is applied after the public_view gate, so it never runs for a public view'
print('%d read(s) hold the PIN in front of them whatever the view is set to' % len(_locked))


# A name that is read with a GET and worked with by a POST is written twice in
# the relay: once as a branch of its own, once in the map of POST names. The
# branch stands first, so without a method on it every press went out as a GET
# - refused, because a GET of these wants the PIN in a session rather than in
# a body - and the page asked for the PIN again, and again.
_posted = set(re.findall(r"'([a-z0-9-]+)' => '/api/", php))
_branches = re.findall(r"if \(\$what === '([a-z0-9-]+)'([^)]*)\) \{", php)
_both = [(name, rest) for name, rest in _branches if name in _posted]
_loose = [name for name, rest in _both if 'REQUEST_METHOD' not in rest]
if _loose:
    print('these are read and written under one name, and the reading branch takes both:')
    for name in _loose:
        print('   %s' % name)
    raise SystemExit(1)
print('%d name(s) serve a GET and a POST, each branch saying which it takes' % len(_both))


# The reads that hold the PIN in front of them are let through to a tool on
# the machine itself - the command line, which can read the database directly
# anyway - and that has to mean a tool holding the API token. Without the
# token, anything able to open a socket to the daemon could read the export,
# passwords and all: the web server's own worker most of all, which is the
# very thing an attacker would be trying to subvert.
_daemon_src = open(str(__file__).rsplit('/', 2)[0] + '/zigmon.py').read()
_where = _daemon_src.index('local = (self.client_address[0]')
_lines = _daemon_src[_where:_where + 400]
if '_authorised()' not in _lines:
    print('the local road into the locked reads does not ask for the API token')
    raise SystemExit(1)
if 'X-Zigmon-Client' not in _lines:
    print('the local road does not refuse a browser coming by the relay')
    raise SystemExit(1)
print('the locked reads open only to a local tool holding the token')

# ...and the command line has to send one on a read, or the road it was opened
# for is a road it cannot take.
if "if token is None:\n        token = read_token()" not in _daemon_src:
    print('the command line does not send its token on a read, so the locked reads refuse it')
    raise SystemExit(1)
print('the command line sends its token on reads as well as on writes')

# With no PIN set at all, check_pin has nothing to check and lets everything
# through - and these reads hold passwords, people and their MAC addresses. A
# house that never set one was handing them to anybody who could reach the
# dashboard, with the whole of the locking machinery in place and doing
# nothing.
if "not str(CONFIG.get('pin') or '').strip()" not in _daemon_src[_where - 600:_where + 1200]:
    print('with no PIN set, the locked reads are open to every browser')
    raise SystemExit(1)
print('with no PIN set the locked reads are refused rather than opened')


# A secret travels in an address under more than one name, and the debug log
# writes addresses out. session was not among the names it blotted - and the
# page puts one on every request it makes, so with debug on the log filled
# with working keys; a PIN written into a query was written into the log
# beside it.
_at = _daemon_src.index('SECRET_IN_PATH = re.compile')
_pattern = _daemon_src[_at:_at + 400]
for _name in ('session', 'pin', 'token', 'secret', 'password', 'code'):
    if _name not in _pattern:
        print('a %s= in an address is written out in the log' % _name)
        raise SystemExit(1)
print('a secret in an address is blotted whatever name it travels under')


# A request that names no valid session locks nothing. /api/lock asks for no
# PIN - the page uses it to lock its own session - and it used to clear every
# session when handed a token it did not know, so one request with a made-up
# token from anything that could reach the relay logged every editor out.
import zigmon as _zz
_zz.load_config()
_zz.CONFIG['pin'] = '4321'
_dd = _zz.Daemon()
_one, _ = _dd.unlock('4321', 5, 'a phone')
_two, _ = _dd.unlock('4321', 5, 'a laptop')
assert len(_dd.sessions) == 2
_dd.lock_editing('made-up-token')
assert len(_dd.sessions) == 2, 'a token nobody issued locked %d session(s)' % (2 - len(_dd.sessions))
_dd.lock_editing(_one['token'])
assert len(_dd.sessions) == 1 and _two['token'] in _dd.sessions, 'locking one session touched the other'
print('a token nobody issued locks nothing; a real one locks only itself')

# ...and the proxy's read is configuration like the router's, behind the PIN
if "'/api/proxy'" not in _daemon_src[_daemon_src.index('ALWAYS_LOCKED = ('):_daemon_src.index('ALWAYS_LOCKED = (') + 900]:
    print('/api/proxy is open to every browser while /api/mikrotik is not')
    raise SystemExit(1)
print('the proxy and the router are behind the same PIN')

