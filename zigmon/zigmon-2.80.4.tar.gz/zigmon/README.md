# zigmon

Monitoring, history and control for every sensor that reaches an MQTT broker
through Zigbee2MQTT — and, optionally, for Shelly WiFi devices publishing to
the same broker. The same shape as `upsmon`: a Python daemon that owns the
data, SQLite for history, and a PHP dashboard behind nginx that only relays
JSON.

* `install.sh` — sets the whole thing up on AlmaLinux 9, and can upgrade or remove it
* `zigmon.py` — the daemon and the command-line tool, one file (standard library + paho-mqtt)
* `web/index.php`, `web/zigmon-api.php` — the dashboard and its thin API client
* `deploy/` — systemd unit, logrotate rules, sample configuration, nginx server block
* `INSTALL.md` — the AlmaLinux 9 walkthrough, by hand

## Installing

```bash
sudo ./install.sh
```

Packages, service user, configuration, the broker account, systemd unit, log
rotation, nginx with TLS, php-fpm, SELinux, firewall, and a check that it all
works. `--dry-run` shows what it would do, `--upgrade` replaces the program
files, `--uninstall` removes it while keeping the recorded history. Every
question has a command-line option; `--help` lists them.

## How the pieces fit

```
Zigbee sensors ──► SLZB-06 ──► Zigbee2MQTT ──┐
                                             │      AlmaLinux 9
Shelly WiFi (H&T, Plug) ─────────────────────┤   ┌────────────────────────────────────────┐
                                             ▼   │ zigmon.service   (user "zigmon")       │
                                        mosquitto│   subscribes to zigbee2mqtt/#, shellies/#│
                                       1883/8883 │   writes /var/lib/zigmon/history.db    │
                                             ────►   serves 127.0.0.1:9849, token-guarded │
                                                 │        ↑                               │
                                                 │ php-fpm ← nginx :443 ← browser         │
                                                 └────────────────────────────────────────┘
```

The daemon is the only thing that talks to the broker. PHP relays JSON and
holds no credentials; the two endpoints that change something (opening the
network for joining, erasing history) send a token read from a file the
browser never sees, and are guarded by a PIN on top. Nothing in the chain
needs root.

## What it watches

**Every device Zigbee2MQTT knows.** The bridge's device list gives the model,
vendor, description and — through the "exposes" definition — the label and
unit of every value the device reports. Nothing is specific to a model: a
temperature sensor, a button, a contact, a plug with power metering all land
in the same tables and on the same dashboard. New devices appear by
themselves the moment they pair.

**Shelly smart plugs**, optionally, over local RPC exactly as upsmon does it:
the watts actually being drawn, voltage, current, power factor, frequency,
the plug's own temperature, the energy total and the runtime and switching
counters. Any number of plugs; each can be switched and its counters reset
from the dashboard, and **a Zigbee button can be bound to it** — single press
toggles the fridge, long press switches it off, whatever you set up on the
Control tab. The editor offers only devices that can send an action, and for
each one the exact actions its Zigbee2MQTT definition declares (plus any it
has actually sent), so nothing has to be typed or guessed.

**Shelly WiFi sensors**, three ways, all optional: over MQTT (anything under
`shellies/<name>/status/…`), polled over RPC when the sensor has an address
and answers (an H&T on USB power), or **pushed by webhook** from a battery
sensor that sleeps and cannot be polled — the daemon can listen for those
on a port of its own, exactly as upsmon did.

**The bridge itself**: online/offline, version, channel, whether the network
is open for joining, and the events it publishes (join, leave, interview,
rename).

## Why it is built this way

**Readings are rows, not columns.** `(device, key, value)` rather than a fixed
schema, because what one sensor reports is not what the next one does, and a
device added next month should need no code change.

**History is keyed by address, not by name.** Renaming a device in
Zigbee2MQTT keeps its history; the rename shows up as an event. A device that
reports before the bridge has listed it is filed under its name and moved
across when the address arrives.

**SQLite in two layers.** Full-resolution samples for a fortnight, hourly
averages with min and max for two years. A year of history for a dozen
sensors is a few megabytes, and a year-long chart costs a few hundred rows.

**A bursty device does not flood the table.** Readings arriving within
`sample_interval` of the previous one replace it rather than adding a row —
some devices send four messages for one measurement.

**Availability is inferred as well as reported.** Zigbee2MQTT publishes
`availability` when that feature is on; when it is not, a device that has
been silent longer than a battery sensor's reporting interval is flagged
anyway. A device that reports is by definition reachable, whatever the last
availability message said.

**Button presses are events, not readings.** `action` values go to the event
log with a timestamp; there is nothing to chart in a press.

**Button bindings run in the daemon, not the browser.** A press arrives over
MQTT, the daemon looks the binding up and talks to the plug over RPC; nothing
depends on a dashboard being open. Each switch is an event with the button
and the action that caused it.

**A plug reset is verified, not assumed.** The plug answers
`Switch.ResetCounters` with success whether or not it understood the counter
name, so the values are read back and compared.

**Requests to a plug are paced.** Gen3 firmware with authentication answers
429 when requests arrive closer together than about a second, and the digest
challenge is reused rather than renegotiated on every call.

**A missed reading does not blank the panel.** The last values stay on screen,
greyed out and dated, and after a restart they come from the recorded
snapshots until a fresh reading lands.

**The daemon never gives up.** paho reconnects to the broker by itself with
backoff; the systemd unit restarts the daemon without limit if it ever
crashes; a broker that is down for an hour simply means an hour without data.

**An error inside an endpoint answers rather than raises.** The dashboard
polls every five seconds; one bad payload from one device must not stop the
feed or bury the journal.

## The dashboard

Six tabs. **Overview**: counts, bridge state, permit-join state, a socket
panel per plug with a switch and its live figures, a card per sensor with its
main readings, battery, signal and last report — a button's card shows the
**last press, big**, with which button and how long ago, glowing green for a
moment when it lands (live, under a second), and its gestures as small
chips; a multi-button remote is folded to "4 buttons" plus each gesture
once instead of a 28-item list — and 6h/24h/7d charts of
temperature and humidity across all devices. **History**: pick a
device, pick 6 hours to a year, one chart per value it reports. **Devices**:
the table. **Events**: joins, leaves, renames, availability changes, button
presses, bridge state. **Control**: open or close the Zigbee network, switch each plug and reset
its counters, edit the button bindings, erase recorded data, forget a device
— all behind the PIN. **All values**: everything
every device reports, with the description Zigbee2MQTT gives for it.

**The overview can be rearranged.** While editing is unlocked, drag any
socket row or device card where you want it; the order is saved the moment
you drop it (`POST /api/order`), lives in the daemon, and every browser sees
the same layout. Newly added devices go to the end. While locked, dragging
is off.

Every Zigbee device also shows **which router or coordinator it talks
through** — "via Router" on its Overview card (hover for the link quality
and how fresh the information is) and a "Connected through" line on All
values. The daemon asks Zigbee2MQTT for the raw network map every
`networkmap_interval` seconds (default 300, `0` turns it off; the answer
also survives a restart), so after moving a device or adding a router give
it a few minutes to reflect re-parenting.

Charts read each series' own rhythm: a thermometer that wakes every four
hours draws an unbroken line, and lines are always continuous, start to finish, whatever a source's
rhythm. Shading real outages on top — where a normally chatty source went
quiet for a while — is an opt-in setting (`chart_outages` in
config.json, or Settings on the dashboard); off by default, it applies to
every chart at once.

**Three more tabs join Plugs: Sensors and Buttons.** Every non-plug device
that reports measurements lives on Sensors; every button/remote lives on
Buttons. Both are full catalogs, unlocked-editable and reorderable by drag,
independent of Overview.

**Overview is yours to design.** While unlocked, an "Add to Overview" row
lets you place any plug, sensor, or button onto Overview; a small × on each
card removes it, and dragging reorders freely — plugs and sensor/button
tiles can sit in any order together. A fresh install shows everything (the
same combined view as before), so nothing looks empty until you start
customizing; from the first add or remove, Overview remembers your own
layout in the daemon, shared across every browser. It has nothing to do
with the Plugs/Sensors/Buttons tabs, which always show the full catalog.

**Zigbee gateways** now cover two kinds of hardware: a SMLIGHT SLZB-06 or
similar (plain HTTP JSON on `/ha_info`/`/ha_sensors`) and a **Shelly device
with the Zigbee component acting as a router** — e.g. a Power Strip 4
Gen4 — read over the same local JSON-RPC API (`/rpc`, digest auth) already
used for Shelly plugs, via `Shelly.GetStatus`, `Zigbee.GetStatus` and
`Zigbee.GetConfig`. **Detect** tries the SLZB path first and falls back to
the Shelly one automatically, remembers which one answered (`kind` in
`config.json`), and — for a router — offers the matching device on the
mesh as the target if there is exactly one, or one whose model matches
what Detect read. `zigmon gateway <name> dump` and the background poller
follow the same two-protocol logic, so a Shelly-based gateway needs no
extra setup once Detect has run once.

**Zigbee gateways** (a SMLIGHT SLZB-06 or similar) can be read over the
network for their own health — uptime, board temperature, Wi-Fi/Ethernet
and socket state — on top of what Zigbee2MQTT reports. Add one on the
Control tab, in **Zigbee gateways** (name, address, and — if the device's
"web server authentication" is switched on — a username and password sent
as HTTP Basic Auth), or in `config.json` for a read-only entry:

```json
"zigbee_gateways": [
  {"name": "Router", "host": "192.168.1.51", "target": "Router",
   "username": "admin", "password": "..."}
]
```

`target` is either the name an existing Zigbee router already has (its
readings *extend* that device — nothing is duplicated) or the literal
string `"coordinator"` for the local coordinator, which has no device row
of its own and gets a small synthetic one. `username`/`password` are
optional and only needed when the gateway's own web login is enabled.
Polled every `gateway_poll_interval` seconds (default 30) from the
documented `/ha_info` and `/ha_sensors` endpoints, plus `/metrics` (the
device's own Prometheus output — free heap, board temperature, Wi-Fi RSSI
and whatever else the firmware exposes, parsed generically since the
format is self-describing). Whatever comes back lands under a `gw.` prefix
in All values and gets recorded to history too — free heap over time is
often the earliest sign of a coordinator that is about to lock up. **Detect** on the row does the
same from the dashboard: it reads model, firmware, radio and mode, fills
the name if empty and suggests the target (coordinator, or the one router
on the mesh). Run
`zigmon gateway <name> dump` (or `--host <ip> dump` for one not yet in
config.json) to see exactly what your firmware returns before relying on
any particular field.

**A multi-relay strip reads as one box.** Its header carries what is the
box's — model, firmware, address, mains voltage and frequency, box
temperature, total power, Wi-Fi — and each channel row underneath shows
only its own power, current, energy, on-time and switch count, with the
same full-size switch button a single plug has. **Find Shelly devices → Add**
runs Detect on the spot, so a found box arrives with the right kind,
its relays and their names.

**Plugs are added as devices, not as relays.** In Plugs and sensors one
block is one box: address, password and a *device state* entered once.
**Detect** asks the box what it is (model, MAC, firmware) and how many
relays it has, and lays out one channel row per relay with the names the
device itself uses — a Pro 4PM becomes four channels in one click. The
device state wins: *monitor only* or *disabled* there applies to every
channel and locks their selects; *enabled* lets each channel keep its own
choice (a single channel can still be monitor-only or disabled). Passwords,
addresses and the device state are stored once per channel underneath, so
bindings, rules, history and the strip ordering on the Plugs tab work
exactly as before (the whole strip is dragged; channels reorder inside it).
In `config.json` the same is `"host_state": "enabled|monitor|disabled|optional"`
on each channel entry.

**A device that may be unplugged.** The fourth device state, *enabled, may
be unplugged* (`"host_state": "optional"`), is for a box that loses power
as part of normal life — a lamp on a switched outlet, a plug behind a
socket that gets turned off. It behaves exactly like *enabled* while the
box answers. When it stops answering, nothing is treated as a fault: no
warning event, no notification, no place in *needs attention*, the device
stays *ok*; its socket row goes grey and says *unplugged* with the last
reading, and bindings, rules and schedules aimed at it fail fast and
quietly (a two-second probe instead of the full timeout, so no thread and
no other device waits on it). It keeps being probed on the normal poll
interval, so the moment it has power again it is live — readings, switch,
bindings — with an *answering again* line in the log and nothing else to
clean up.

**Silence quiet-alerts for buttons** (Settings → Alert thresholds, on by
default) — a button or remote only reports when pressed, so going quiet for
hours or days is normal for it, not a fault. With this on, buttons never
turn WARN/CRIT or count toward "needs attention" just for being silent;
switch it off to get the old behavior back. Plugs were already exempt.

**On/off is a switch, everywhere.** One iOS-style toggle is used for every
enable/disable in the dashboard: the boolean settings (outage shading,
chart icons, daily backup, Zigbee2MQTT in the backup), the notification
categories and per-device custom picks, and — new — an enabled switch at
the start of every binding, rule and schedule row: off keeps the row but
the daemon ignores it (dimmed in the list). Backup time is a time picker,
tokens are masked, numbers have sensible steps.

**The way to a device's charts** is always the same small chart icon in
the top-right corner of its card or row, shown on hover — never the name,
never the whole card (a plug's row has the switch on it). It is on by
default and can be switched off per kind under Settings → Charts or in
`config.json` (`link_plugs`, `link_sensors`, `link_buttons`).

**Click the status pill** (or the Needs-attention card) for the details
behind it: a dialog listing every problem in one place — broker or bridge
down, each device flagged by a threshold with the reason and its last
report, every unreachable plug with the error — worst first; a device name
opens its History. When all is well it says so, with a one-line summary.

**Forget this device works without visiting Devices first.** The list it
offers was filled while the Devices tab was painted, so once painting became
per-tab that list stayed empty for anyone who went straight to Control, and
the button did nothing at all. It is filled from Control as well now, and
says which of the two went wrong instead of failing quietly.

**A tick paints only the tab you are looking at**, and only the parts
whose data actually changed (each grid and editor keeps a signature of its
slice of state; "x min ago" texts repaint once a minute). A hidden tab is
painted the moment it is shown. With a few dozen devices a refresh costs a
few milliseconds instead of hundreds, so a click on a socket repaints in
~30 ms even on a big mesh.

**`zigmon --map` scans the mesh on demand.** The map is otherwise refreshed
every `networkmap_interval` seconds (five minutes by default, `0` turns it
off), which is fine to live with but slow to wait for after moving a device.
The command asks Zigbee2MQTT for a fresh scan, waits for the answer, and
prints who talks through whom — and if the bridge does not answer in time it
says so and shows what it last knew.

**One coordinator, not two.** The coordinator is not listed as a device of
its own — a gateway entry stands in for it — but anything Zigbee2MQTT
published under its friendly name used to be adopted as a separate, silent
record, so it appeared twice and the gateway's Target offered a choice
between two things that were the same. Its name now points at the one
record, an existing stray copy is folded away on the next device list, and
Target lists the coordinator once. It also carries what Detect read — model
and firmware under its name, like every other device — and the network map
calls it by that name rather than the bare word `coordinator`. Any device a
gateway extends does the same: a range extender reads
`SMLIGHT SLZB-06Mg26U · Router · v3.3.8.dev3` rather than just `Router`,
in its card and in the Devices table. The firmware is added to what
Zigbee2MQTT already says rather than replacing it, so the two never fight
over the row.

**Rules compare with `=` and `≠` too**, next to the four inequalities — for
a reading that is a state rather than a level. Equality is matched with the
tolerance floats need, so a sensor reporting 21.0 matches a 21 typed in.

**A gateway poll no longer hides a silent mesh.** When a device's record is
extended by a gateway read over the network, that poll also refreshed the
“last report” age — so a router whose Zigbee side had gone quiet still looked
seconds fresh. The two are now tracked apart, and when they drift more than
two minutes the card says `Zigbee 30 min ago` next to the age, so the mesh
cannot hide behind Wi-Fi. A router with nothing of its own to report is only
heard from when the bridge pings it, every ten minutes or so, so under a
quarter of an hour the note is plain grey; it turns orange past that.

**A WiFi tab, for looking at.** Between Devices and Events, tiles for the
controller, each access point and each wireless network, and a list of
everything joined — with the ones assigned to a person marked. An access
point tile carries its clients per radio and channel, processor, memory and
uptime, and each one is recorded as a device of its own, so its history
charts like any sensor and it can be dragged onto the Overview.

The device list is a summary: it names the features and the interfaces
(“ports”, “radios”) without giving either, so each access point is read a
second time for the radios that carry its channel, width and Wi-Fi
generation, and for its ports — which are reported even where the controller gives a
socket's rating but not its live speed, or names a port without saying
whether it is up. If the tab is emptier than the controller's own pages, `zigmon --wifi-probe`
shows the outline of its replies — the field names, with the
values shortened and anything that looks like a key left out. Those names
have moved between firmware revisions, and guessing at them from the outside
is exactly how an empty tab happens: a controller answering
`features: ["accessPoint"]` was being compared against `ACCESS_POINT` and
every device it listed was quietly dropped. Spellings are now compared
without case or punctuation, the SSID is taken from whichever key carries
it, and a controller whose devices are not recognised at all says so on the
tab rather than showing nothing.

**The access points can be asked directly.** The controller's key interface
will not say which network a client is on, nor its signal or channel; the
points themselves know all three. Under **Control → Presence**, switch on
*Read them over SSH*, give the username they use, and either a password or a
key — which can be **generated here**, its public half shown for pasting
into the controller under Settings → System → Device SSH Authentication and
its private half downloadable once, or uploaded if you already have one.
Their addresses come from the controller, so nothing has to be typed twice.
Switching this on also **stops the controller being signed in to**: the
sign-in existed to get exactly these three things, and a controller that
locks an account out after a few failures is not worth troubling for
something already in hand. A setup carried over from before is moved to the
API key on its own and says so in Events. `zigmon --wifi-probe` reports on
the points now rather than on a sign-in nothing is using.

Each point also measures its own way out — latency, jitter and packet loss
to the gateway and to whatever carries it — which is how an access point
that is fine in itself but sits behind a bad wire tells you so; the
controller cannot see that at all. It says which switch and port it is
plugged into, where it sends its reports and what went wrong the last time
it could not, and how it is bearing up: how much of the flash's write life
is gone, why it last started, whether it has ever crashed, its board
revision and its addresses.

Some of it is turned into something to act on rather than only read. The
spectrum scan says how busy every channel in each band is, so a radio
sitting on a crowded one is shown the **quieter channels going spare** — on
a 2.4 GHz radio at 35% airtime, knowing channel 7 is at 18% is the whole
decision. A 5 GHz radio on a **radar channel** is marked DFS, because a
point told to leave one takes its network with it and that looks like a
fault. And a client's **retry rate** — how much of what it sends has to go
out again — catches one struggling long before its signal looks bad: an
iPad at –64 dBm repeating 18% of its frames is having a worse time than a
plug at –65 dBm repeating 2%.

What each point sees of the neighbourhood comes back too: every other
network on the air with its channel, width, signal and security, merged
across the points so one network seen twice is one line with the nearest
sighting, and listed on the tab with the ones sharing a channel with your
own marked — those are the ones dividing the airtime with you. Your own
networks are left out, including the hidden ones a point broadcasts, which
are recognised by the hardware their address comes from rather than by a
name they do not have. and the airtime in use and interference on each channel a radio
sits on. `info` is a shell function rather than a program on this firmware,
so several ways of asking are tried until one answers.

Nothing is ever written to a point. The commands are a fixed list in the
source — `info` and `mca-dump`, neither of which changes anything — and
none of it is built from anything typed or received; asking for anything
else is refused before a connection is made. What comes back fills in each client's network, signal, noise and margin,
channel, width, Wi-Fi generation, stream count, VLAN, negotiated rates,
retries, experience and whether it is dozing; each point's temperature per
radio, load, experience, serial, kernel and the speed and error counts of
its wired uplink; and the real number of clients on each network, which the
key interface cannot count at all. The field names follow a dump from a
U7-Pro rather than what looks likely — the channel and its width sit on each
wireless network, not on the radio; `signal` is dBm while `rssi` is the
margin above the noise floor; rates are counted in kilobits. A point that does not answer is noted on its own tile and the others carry
on. What they said is held between rounds: the controller is asked every
thirty seconds and the points every few minutes, and without that the signal
and the network would appear once and then vanish for the next several
rounds — which looked exactly like the reading being unreliable.

**A device is called what you called it.** The controller carries the name
somebody typed; the point reports the hostname the device announces for
itself. The first wins, and the second is shown beside it where the two
differ, so `iPhone16` stays `iPhone16` rather than turning into
`Jan--iPhone16` every few minutes.

How much is on show depends on which interface the controller is asked
over, and the tab says which one actually answered. Signing in is not free — the controller counts attempts and starts
answering `429 too many requests` — so a session is opened once and kept for
half an hour rather than signing in for every read, and never logged out,
since logging out is what forces the next read to sign in again. Twenty-two
reads now cost one sign-in instead of twenty-two. A sign-in that succeeds is not yet a session: UniFi OS wants a cross-site
token on every read, and that token rotates — a fresh one comes back under
`x-updated-csrf-token` rather than the name it was first sent under, so both
are watched for, and `/api/users/self` supplies it on the controllers that
withhold it from the sign-in altogether. The session is then **extended**
through `/api/auth/refresh`, the way the controller's own pages do, rather
than signed in again when it ages: twelve reads and four renewals cost one
sign-in. `rememberMe` is sent too, for the longer session it buys. Without it the sign-in
reports 200 and every read that follows reports 401, which looks like a
password problem and is not one. There are also two doors — UniFi OS answers
on `/api/auth/login`, the classic controller on `/api/login` — and a self-hosted server may refuse one
while letting the other through, so both are tried. A **rejected** username and password is a different matter from a busy
controller: it is tried once and then left alone until the stored details
change, because repeating a wrong password is exactly what locks an account
out of its own controller — and a controller answering
`AUTHENTICATION_FAILED_LIMIT_REACHED` is counting failed sign-ins, not
traffic, so that is read as a rejection too. Where the controller really is
asking for a pause it says for how long; that wait is honoured and doubles
with each refusal in a row, rather than being retried the moment it lapses
and renewing the lockout forever, and the key covers the gap. Reads are serialised and their answers held for a few seconds, so several
people looking at once, or somebody leaning on the refresh button, cost the
controller one round rather than one each: sixteen simultaneous polls make
one read of the clients, one of the devices and one sign-in. `zigmon
--wifi-probe` prints what the controller answers to each question, sign-in
included, for when the tab is thinner than it should be, and `zigmon --reset-order wifi` puts the cards back in their default
arrangement. The same command covers every set of cards that can be
rearranged — `overview`, `wifi`, `plugs`, `sensors`, `buttons`, `devices`,
`groups`, or `all` — and only forgets the order: nothing about the cards
themselves changes. **Access** offers three
choices: the API key, a username and password, or **both** — which signs in
for the fuller picture and keeps the key as the fallback, so a controller
that stops accepting the sign-in still fills the tab rather than emptying
it. The **API key** interface grew a great deal in 10.6: it lists the access
points with each radio's channel, width and Wi-Fi generation, the wireless
networks with their security and the VLAN behind each, and per client the
name, address, kind (wireless, wired, VPN or Teleport), whether it is a
guest, since when, and which access point carries it. What it does not report, on any version, is **which network a client is
joined to** — the access field on a client holds an authorisation type and
nothing else — nor its signal or channel. Where that is unknown it is left
blank rather than counted as nothing: a network nobody can be counted on
says so instead of claiming zero clients. Signing in with a **username and password** reaches what the controller's
own pages use: its `clients/active`, which already carries the signal, the
channel, the negotiated rates, the VLAN and the name of the access point —
with the older `stat/sta` as the fallback for controllers without it. That
shows: per client the
Wi-Fi generation and stream count, band, channel and channel width, signal,
throughput and total usage, experience and VLAN; per access point each radio
with its channel, width and airtime in use, its uplink and its experience;
and the real list of networks with their security, bands and the VLAN each
sits on — 6 GHz radios included, which the band mapping had been getting
wrong.

All of it is deliberately slow and second in line: the network is asked
about every three minutes on its own thread, readings are kept only when
they move, and nothing in the house waits on any of it. With a controller
that accepts a connection and then never answers, message handling stays at
0.10 ms and every reading still arrives.

**Presence: who is at home, and rules that care.** Whether a phone is on the
house Wi-Fi answers *is anyone in* well enough, and needs nothing installed
on the phone. **Control → Presence** takes a UniFi controller — an API key,
or a username and password on older firmware — lists the clients it can see,
and lets each one be assigned to a person. Someone is in when any of their
devices is on the network, so a watch or a laptop covers for a sleeping
phone.

Arriving is believed at once; leaving only after a grace period, ten minutes
by default. A phone parks its radio while its owner is asleep in the next
room, and without that delay the house would report them walking out every
night.

**A phone can be named instead of addressed.** Phones rotate their Wi-Fi
address now — iOS *Private Wi-Fi Address*, Android *randomised MAC* — and a
person listed by an address that has since changed is out for good, however
often the controller sees the phone under its new one. **+ by name** in
the People editor stores `name:iPhone16` instead: the device matches by
the name the controller shows, whatever its address is today. An **out**
tag says under it why the person counts as out — not among the clients
listed, last seen when, the grace that applies — so a wrong address or a
too-short *Gone after* is visible at a glance.

**A phone can say where it is itself.** The Wi-Fi has a floor: the
controller lists a phone a few seconds after it has joined, and only once it
has joined - by which time you are already inside. A handset's own geofence
trips while its owner is down the street. Switch **From their phone** on for
a person, press **Setup**, and you get two links to put in the handset:

    …/index.php?api=presence-report&state=home&token=…
    …/index.php?api=presence-report&state=away&token=…

**Setup** is the whole walkthrough, not just the links: the Location
Services setting the phone needs, each screen of the automation in order,
what to type where, how to test it, and what happens when. Every value that
belongs in the phone — the URL, the topic, the message with the token in it
— is a chip you tap to copy, and hovering one shows it as a **QR code** for
the phone to scan. That is as far as automation goes, and the limit is
Apple's: a personal automation cannot be shared or imported at all, and
since iOS 15 an unsigned shortcut file cannot be added to a phone either —
so the automation itself is always made by hand. The QR at least keeps a
24-character token from being typed twice. If a presence topic is set, the ntfy way is
what it walks through and the direct link is offered underneath; if not,
the other way round. Android is the same request from Tasker or MacroDroid. It travels over mobile data to the same address the dashboard
lives at, so a phone reports from the street, before it is on the Wi-Fi at
all.

The two sources are merged rather than swapped. **Arriving is taken at
once** - triggers fire, and the Wi-Fi confirms it moments later. **Leaving
is taken only if the controller cannot see them either**: a geofence that
wanders is common, and a phone sitting on the home network is not a phone
that has left, so a reported departure asks the controller once, quickly,
before it counts. A phone's word stands for half an hour unconfirmed, then
the Wi-Fi has the say again - a lost or flat handset cannot strand anybody.
Every *out* tag says which source decided it.

The token is what proves a request is that person's phone; it is per person,
never shown in the dashboard's own status, and *Make a new token* stops an
old link working. Losing one is worth what it can do: flip that person's
presence, and nothing else. Wrong tokens are counted and slowed to a crawl.

**Nothing has to be reachable from the internet for this.** Set a
**presence topic** on the Wi-Fi controller card - `https://ntfy.sh/` plus a
long random name - and the phone publishes `home <token>` there instead,
while the daemon holds an outbound stream to it. The topic is public, which
is why the token travels inside the message and why nothing but a name and a
state ever goes over it.

**Walking in is noticed before the hall sensor gets a word in.** The
controller is asked every *poll_s* (30 s by default, 3 s at the least) - and
for a minute after anybody has come or gone, every five seconds, since a
second person often walks in right behind the first. But
a rule limited to *nobody home* does not trust an answer that old: when it
is about to fire and the last look at the network is more than
`presence_fresh_s` old (4 s by default; `-1` switches this off), it asks
the controller again first, with a three-second timeout, and decides on
what it hears. Your phone joins the Wi-Fi at the door, the sensor trips two
seconds later, the rule asks, finds you in, and stays quiet. Only that rule
waits for the answer: rules run on a thread of their own and buttons,
reports and plugs never queue behind them.

What it is for:

- **Sensor rules take an `only when`**: nobody home, someone home, or one
  named person in or out. `motion` and `motion while the house is empty` are
  different things, and now they can be written differently.
- **Anything that switches something can send a notification instead** — a
  rule, a button, a scene, a schedule, a presence trigger.
- **Coming and going switches things**: per person, or once for the house
  when the first one gets in or the last one leaves. That last one is for
  turning everything off behind you.
- The Overview carries a chip per person, green when they are in, with the
  device they were seen as and when. `zigmon --presence` says the same on a
  terminal.

A gated rule stays quiet when nobody has been set up or the controller is
unreachable, rather than guessing. The key or password is stored in the
daemon's database and never sent back to the page — only whether one is
held. Presence settings travel in the settings backup with everything else.

**A button can take something over.** A light on a motion rule is a nuisance
the moment somebody wants it to stay on: they press the switch, and the
sensor turns it off again as they walk past. Switch **By hand** on for that
button's binding and while its press leaves the target on, rules, schedules
and window-closing leave it alone; the same button switching it off gives it
back. A pulse never takes anything over, and a hold expires by itself after
`manual_hold_s` (four hours by default, `0` for never) so a forgotten one
cannot strand a plug. The plug card shows `by hand` while it lasts, saying
who took it and how long is left, and clicking that gives it back at once.
When the binding's target is a scene or a sequence, the hold lands on every
light the scene switches, one by one and by what the scene did to each: the
ones it turned on are taken over, the ones it turned off are given back, a
toggle is read back to see where it landed. A scene of three lights pressed
by hand is then three holds, and the motion sensor over any of them keeps
its hands off until the same button (or the card) gives them back.

**A critical alert is logged in its own words.** That is the one somebody
comes back to and reads, so Events keeps the message as it was written, in
whatever language it was written in; what set it off is on the rule's own
line directly beneath, so nothing is lost. The quieter ones stay as the
daemon describing itself — `sent "Doorbell": a doorbell press` — rather than
repeating their words in the middle of its own English.

**One message, one alert, however many rules point at it.** The repeat
window silenced a duplicate notification but not the event or the band
behind it, so two rules watching the same sensor — an OR rule and the single
rule it replaced, say — raised the same alert twice while only telling you
once. The window now governs all three together. The rules editor also marks a rule when another one fires on exactly the
same crossing and does exactly the same thing to the same target. Only that:
a pair switching on above and off below is the pattern this very card
recommends, and a thermostat's dead band is two rules on one sensor by
design.

**Each side of an OR is its own event.** A rule fires when its condition
becomes true, and a pair joined by OR was treated as one condition: with two
motion sensors covering a hallway, whichever tripped second was never heard
while the first was still occupied — the combined condition had not stopped
being true, so there was no edge to fire on. Two separate rules worked,
which is the tell. Each side now carries its own edge, so both are
announced; AND keeps the combined edge, which is what it means. The event
and the message also name the reading that actually tripped rather than the
other sensor's, and a rule whose first source has never reported no longer
sits silent when its second one does.

**Nothing on the message path waits for the database.** A critical message
and a hand taking something over both record themselves in the settings
table, and that write stood behind the lock: during a VACUUM of a 135 MB
database one motion report took 770 ms to become an alert. Those writes now
join the same queue as events — the in-memory copy is updated at once, every
reader sees it, and the row lands when the lock is free. The same report
during the same VACUUM: 0.7 ms. The band of standing alerts is also
repainted only when the alerts change, not on every tick.

**A notification is not switched on.** Picking a message as the target now
hides the Do column, the pulse delay and the way-back threshold, and says
`sends the message` instead — in rules, button bindings, scenes, schedules
and presence triggers alike. They were offered before and meant nothing.

**Presence is worked out once a second, not once a rule.** A gated rule asks
who is home on every message it might match, and each ask rebuilt the whole
answer; with thirty such rules that halved what the message path could
carry. The answer can only change when the controller is asked again, so it
is held briefly: 11,400 messages a second back to 22,000.

**A request with no PIN is not a wrong PIN.** Anything privileged that
arrived without one was counted as a failed guess, so five stray requests —
a stale tab, a bug in the page — locked the owner out for five minutes with
“too many wrong PINs” while they were typing the right one. Only an actual
guess counts now; guessing is still limited exactly as before.

**Notifications say what you wrote.** *Messages*, under Alerts & energy, are
named texts picked as a target anywhere something is switched. Write
`{device}`, `{value}`, `{key}`, `{unit}`, `{label}`, `{target}`, `{action}`,
`{person}`, `{time}`, `{date}`, `{home}`, `{away}` or `{origin}` and the
facts of the moment are filled in — anything not known then is left out
rather than printed as a placeholder. The device that set it off also
offers `{model}`, `{battery}`, `{signal}`, `{temperature}`, `{humidity}`;
the moment offers `{weekday}`, `{sunrise}`, `{sunset}`, `{daylight}`
(day/night; the sun needs `latitude`/`longitude`), `{home_count}`; the
house offers `{attention}` (devices needing attention), `{attention_list}`,
`{alerts}` (standing critical alerts) and `{uptime}`.

**Any device, right now: `{Name.key}`.** Write the device's name as the
dashboard shows it (or its alias), a dot, and a key from *All values* —
`{Temp-Venek.temperature}`, `{Plug-UPS.switch.apower}`,
`{PIR-Vchod.occupancy}` — and the current reading is put in, whatever set
the message off. `{Name.state}` is on/off/unplugged of a plug or switch,
`{Name.age}` how long since it last reported, and `.battery`, `.signal`,
`.model`, `.name` work too. Names are matched case-insensitively; a device
or key that does not exist simply vanishes from the text. So a night-time
motion alert can read *Motion at {device}, outside {Temp-Venek.temperature}
°C, entrance light {Light-Vchod.state}*.

**The editor completes them like an IDE.** Type `{` in a message's text or
title (or press Ctrl+Space anywhere) and a list drops down at the cursor:
every fact with what it means and an example value taken from the live
dashboard, and every device by name. Keep typing to narrow it; Up/Down
move, Enter or Tab take, Esc closes. Taking a device puts `{Name.` in and
the list changes to that device's own readings with their current values —
`humidity → 71 %` — plus `state`, `age`, `battery`, `signal`, `model`,
`name`. The `{ } Facts` button shows the same catalogue grouped, with the
examples. Each says how long before the same message may be sent again, because a
tripping sensor will otherwise fill a phone, and whether it is **critical**:
sent at the highest priority the channel allows, written to Events as a
problem, and left standing in a band across the top of the page until
somebody clears it — which needs the PIN, and leaves it in Events either
way. A notification arrives while you are asleep; the band is still there in
the morning. The text runs to as many lines as it needs, and two buttons put things into
it where the cursor is: **Facts** for the placeholders, so nobody has to
remember them, and **Emoji** for a symbol, which both channels carry. A
message can also carry its own heading and a picture — a camera snapshot,
say; the phone fetches that itself, so the address has to be reachable from
wherever the phone is. The card shows what each will read like as it is
typed, and sends one on demand. Without a message, the notification carries the automatic
description, which is fine for testing and poor at three in the morning.

**The coordinator's card reads like a router's.** It was the one device
whose card said “no measurements” while its gateway was being polled
perfectly well — it has no link quality and no parent, so it fell through to
the branch for a sensor with nothing to show. It now says it is holding the
network and carries the same board temperature, Wi-Fi and uptime a router
does, or, when no gateway is set up for it, says where to set one up.

**A router card shows what the box itself reports.** A range extender used
to show only that it routes, its link quality and how long it has been in
the network — anything read over its own network API sat in All values and
nowhere else. When a gateway is set up for it, the card now carries the few
figures worth a glance: the sockets of a strip added up, board temperature,
Wi-Fi, uptime. Keys differ per vendor, so they are matched by shape rather
than named one by one.

**A router shows its route too.** Only end devices have a parent; two
routers are siblings, so a mains-powered router used to show no route at
all - the one thing worth knowing about it. The network map's sibling links
are now read as well, and a router carries its strongest neighbour with the
wording to match: `next to coordinator` rather than `via`. The mesh tree
lists them under it.

**A Zigbee switch is told the state, not asked to flip.** Toggling now
sends the explicit `ON` or `OFF` the last report says is the opposite,
exactly as the Zigbee2MQTT frontend does; `TOGGLE` is only used when the
channel has never reported. Some converters - the Shelly Power Strip 4
Gen4's among them - ignore `TOGGLE`, which made a binding look dead. And because a publish the broker refuses looks like success from here, a
set that is never confirmed within six seconds now says which half failed:
the daemon subscribes to the whole base topic, so a command the broker
accepted comes straight back to it. Echo but no action means Zigbee2MQTT
ignored it; no echo means the daemon's MQTT user may not publish there.
`zigmon --check` tests the same thing directly, without waiting for a
button press. On a broker with an ACL the daemon's user needs more than
read access — reading the whole base topic is not enough to *switch*
anything:

```
user zigmon
topic read  zigbee2mqtt/#
topic write zigbee2mqtt/bridge/request/#     # pairing, network map
topic write zigbee2mqtt/+/set                # switching a Zigbee device
topic write zigbee2mqtt/+/+/set              # ...one of its endpoints
```

The probe publishes to `zigbee2mqtt/zigmon-selftest/set` — the same shape a
real command uses, so it tests the permission that actually matters.
Zigbee2MQTT notes once that it does not know a device by that name, which
is expected and harmless — and that one complaint is kept out of the event
log, since it is ours rather than a fault.

**Detect names the relays the way the device does.** It reads the device's
own name and each output's name over the local API and combines them —
`PlugX4-TVLoznice-AppleTV` — with the MQTT prefix preset to the same thing
in lower case, `plugx4-tvloznice-appletv`. A single-relay plug is just the
device name. An output the device leaves unnamed falls back to its number,
and a device that reports no names at all never overwrites a name someone
chose. Anything it renames is listed in the result line, so nothing changes
quietly.

**Control is split into four sections** - Devices, Automation, Alerts &
energy, System - reached from a row of pills under the Editing card, so the
tab shows the handful of cards you came for instead of seventeen at once.
The choice lives in the address (`#control/automation`), so a bookmark or a
reload comes back where you were. Every card still exists and behaves
exactly as before; a section only decides which are on screen.

**A multi-relay box is read in one request.** Asking each channel
separately meant a four-way strip answered thirteen requests per round and,
with the pacing between them, spent most of every fifteen seconds busy with
its own polling - so a click on one of its sockets had to queue behind that.
One `Shelly.GetStatus` now covers every channel: thirteen requests become
one, and the box is busy 7% of the time instead of 80%.

**Commands jump the queue at the device.** Only one request is in flight
per box (that is all the hardware serves anyway), and a switch command goes
ahead of any poll still waiting - while the pacing delay itself is taken
outside that gate, so a waiting poll never holds the box shut.

**The card shows the new state at once.** A plug on Wi-Fi can take a moment
to answer; the socket flips immediately and dims until confirmed, and the
next refresh carries the truth, so a refused switch corrects itself.

**The energy summary is not recomputed from scratch.** Six spans per plug
over the whole samples table is most of what that card costs; yesterday,
last month and last year are periods that have ended and can never change,
so they are worked out once and kept, and the whole answer is held for
fifteen seconds so several open tabs cost one pass rather than one each.
Restarting a plug's counters throws the kept figures away.

**A gateway no longer fills the database with things that never change.**
Asked for its status, a box hands over everything it knows — its serial
numbers, memory sizes, counter reset stamps, per-minute arrays — and all of
it was written every thirty seconds. On one real installation that was 63%
of a 135 MB file, and 45% of every row stored was a value that had never
once changed. Bookkeeping keys are no longer recorded at all, and a gateway
reading is written when it moves, with a point every fifteen minutes so a
flat line still has one. Six polls of an idle strip now write eighteen rows
where they used to write eight hundred.

**A deleted device stays deleted.** A message under a name Zigbee2MQTT has
never listed used to create a device — which is right while the bridge has
not answered yet, and wrong afterwards: a broker replaying a retained
message for a device that was removed put the ghost straight back, every
restart, however often it was erased. Once the device list has arrived, a
name that is not on it is refused, and the log says once an hour which
topic it was. **Look for leftovers** lists those topics too, and offers to
clear them: the daemon writes the empty retained message that deletes each
one and reports which the broker actually took. Doing that needs its MQTT
user to be allowed to write there — `topic write zigbee2mqtt/#` — and when
the broker refuses, the message says so and names the topic, to clear by
hand with `mosquitto_pub -r -n`. A device usually has more than one retained
topic, `…/availability` besides its state, and each is listed separately:
clearing only one leaves the other putting the device back.

**Look for leftovers** on the Recorded data card finds what is still held
for devices the dashboard no longer shows — a rename or a removal leaves the
old name's recordings behind, and on one real installation that was 779,000
readings, 69% of the file. The scan counts them, lists the devices it found
in the Forget dropdown marked `⚠ … gone`, so a single one can be picked out,
and offers to erase the lot. Nothing belonging to a device still in use is
touched. Erasing history, events, everything or one device runs behind that panel
too, and each says in the daemon's log what it is starting and what it
finished with. The card is full width now that it holds all of this.

The size shown is also honest: SQLite reuses its write-ahead journal in
place, so after a compaction that file can sit at the size of the whole
database and was being counted into the total — a 135 MB database read as
270 MB. The journal is folded back in after every compaction and once an
hour besides, and the two are shown apart when one is there.

**Clear out noise** on the Database card applies the same judgement to what
is already stored: it counts first and removes only when asked again. On
that installation it took the file from 135 MB to 60 MB, and every
measurement that ever moved is still there.

**A database job says what it is doing while it does it.** Check, Optimise
and Back up can take a while on a large file, and a button that goes quiet
for half a minute reads as a broken one. Each now opens a panel with a
running bar, the seconds counting up, and the daemon's own log as it
arrives — the job announces its start and its finish there, with the file
size before and after. The panel stays afterwards with the result and how
long it took, green or red. The log is read from its end, not from its
start: it is asked for every second while a job runs, and a log that has
grown for months would otherwise be read whole each time.

**Nothing in the command line is cut to fit.** The listings used fixed
column widths, so a name or an id wider than the guess lost its end — an id
you cannot copy is not an id. Every table now measures its own contents and
sizes each column to the widest thing in it, numbers line up on the right,
and colour marks the level, the state and what a rule or binding does.

**Maintenance leaves the dashboard alone.** Checking, optimising, backing
up or erasing all hold SQLite for as long as they take, and anything that
had to fetch one more row in the meantime waited with them — the page went
to “Connecting…” for a second or two. Three things caused it: resolving a
name still went to the database, the header's row counts were counted
afresh on every refresh, and the caches were emptied a moment before a
VACUUM so the next read landed behind it. Names now resolve from the list
already in memory, the counts are kept for half a minute and never block —
the last ones are shown while the file is busy — and an erase refills what
the dashboard needs before it starts compacting, dropping only the device
it actually removed.

**Reading never makes anyone wait either.** The rows the hot paths need —
a device and its name, the actions a button has sent, a plug's counter
stamp, the whole device list the dashboard rebuilds from — are held in
memory and kept current as they change, instead of being fetched from the
database on every switch and every refresh. A poll that finds nothing new
about its plug no longer rewrites the row either. So a switch command and a
dashboard refresh cost the same whether the database is idle or busy: a
Zigbee command went from 915 ms to 0.2 ms during a VACUUM, and a status
build from 870 ms to 2 ms.

**Recording never makes anyone wait.** Everything the daemon writes while
handling a message — samples, snapshots, events, last-seen — goes onto a
queue drained by one background thread, and the config lists that decide
what to fire (bindings, rules, scenes, sequences, schedules) are held in
memory. So the automation path touches no database lock at all: a VACUUM
or an online backup, which hold SQLite for as long as they take, can no
longer stall a button press or back up the MQTT client thread. Maintenance
flushes the queue first, so a backup still captures everything.

**Switching is close to instant, and stays that way under load.** Per-host
pacing (so one relay is never hammered) used to sit behind one lock shared
by every plug — a slow background poll on any device could stall a click
on an unrelated one by up to a second. Pacing is now per host, so devices
never wait on each other. A command that meets a device's own HTTP 429
(rate limited) also fails fast — one short retry instead of the patient
multi-attempt backoff that suits an unattended background poll.

**Switching is close to instant.** A command to a plug takes a priority
lane past the polling pace (`plug_command_gap`, default 0.05 s, vs.
`plug_min_request_gap` for background polls), a toggle is a single
`Switch.Toggle` round trip, and the dashboard repaints the moment the relay
confirms — the power and energy figures follow from a background poll a
second later, so nobody waits for them. Click-to-repaint is typically
~100 ms on a LAN; a Zigbee button or a motion sensor reaches the relay
within a few milliseconds of its MQTT message (the relay is driven before
the event is even written to disk). Both gaps are tunable under
Settings → Polling.

It updates **live**: besides the five-second refresh, the page keeps one
long-poll request open (`/api/wait`) that the daemon answers the moment
anything visible changes — a report arriving, a plug switching, a binding or
rule firing, the bridge going up or down. A button press shows on every open
dashboard in well under a second; the five-second tick stays as the safety
net, and if the wait endpoint is unreachable the page simply behaves as
before. Each open tab holds one php-fpm worker for up to 25 s at a time,
which the default pool of dozens absorbs without noticing. Refreshing pauses
when the tab is hidden and can be paused by hand from the indicator in the
corner. Control buttons carry a
plain label and an icon; resting the pointer on one for five seconds
reveals the exact request behind it and what it does.

**The Control tab is locked by default.** Nothing there that changes
something works until editing is unlocked with the PIN for a chosen time
(5 min to 4 h) — from the lock pill in the header, the Editing card on the
tab, or simply by clicking any action, which offers to unlock first. The
socket buttons on the Overview follow the same mode: while editing is
unlocked they switch at once; while locked, each click asks for the PIN on
its own, without unlocking anything. While unlocked
nothing asks for the PIN again; the header counts the time down, and it
locks itself when the time is up or when you click *Lock now*. The daemon
issues a session token for the period and forgets it at the end, so an
expired session cannot be replayed; another tab, a restart of the daemon or
its own timer all relock the page. There are no browser pop-ups — the PIN
dialogue is the only one, the same as upsmon's: one box per digit, a wrong
PIN shakes and clears the boxes and asks again in place.

**Every chart pans and zooms**, as in upsmon: drag to move the window,
wheel to zoom around the pointer, pinch on a touch screen, double-click or
the *reset view* button to return. The view survives the five-second
refresh while it is zoomed. Nothing is re-fetched while panning. The tab icon is coloured by
the overall verdict.

## Rooms and heating

**A room is a name and the things in it.** Under Control → Automation, make
rooms and drop devices into them: a thermometer, a valve, a window sensor,
the plugs that live there. Nothing is forced — anything unassigned simply
stays out of the way. Rooms group the energy table, and they give the
Heating screen something to hold a temperature for.

**The Heating tab holds a temperature per room.** Each room has three
numbers — *comfort*, *eco* and *night* — and a plan of which one applies
when: a time, a level, and the days it runs on. The room reads its own
thermometer — several in the room are averaged, a valve's own measurement
is used only if there is nothing better — and whichever level is current is
pushed to every valve in the room. When a room has no thermometer, or has
several and one of them is the one that matters, the **Thermometer** choice
on its card picks the reading it holds against: the room's own are offered
first, then any other on the dashboard, marked *elsewhere*. *Right
now* overrides the plan with one level until it is put back to *follow the
plan*.

**Away** drops every room to one temperature until it is switched off —
the holiday switch. **An open window** in a room drops that room to 5 °C
while it is open, and picks up where it left off when it is shut; the
window sensor just has to be in the same room. With **Heating control**
off nothing is sent at all and the valves keep whatever they were last
told.

**A knob turns a number.** *Set to* on a numeric target has three moods:
**to** a value, **up by** a step, **down by** a step. Bind a rotary
button's *rotate_right* to a valve's target temperature *up by 0.5* and
*rotate_left* to *down by 0.5* and the knob is a thermostat dial; the
daemon keeps inside the range the device announced. It works for any number
a device will accept — a bulb's brightness, a blind's position.

A radiator head is a sleeping device, and a knob is handled with that in
mind: quick clicks accumulate on what was last *sent* rather than on a
report that is minutes old, the card shows the new number the instant the
knob moves, and a burst of clicks goes out as one message a quarter-second
after the last click, carrying the final number — ten messages queued in
the bridge and delivered one by one when the head wakes were what made a
knob feel dead. What no software can do is light the head's own display: a
Tuya head wakes its screen for its own dial, not for a value arriving over
the radio.

**What the sensor reads, while you set the rule.** Hovering the source,
the reading or the threshold of a sensor rule shows the device's current
values in a card, the chosen reading marked and the rest listed under it,
with when it last reported; a binding's device shows its last press. A
threshold is set against what is, not from memory.

**A hand on the room, not on the valve.** There are two ways to turn a
knob at a radiator. Pointed at the valve's own target temperature it sets
the head directly — and the room's plan knows nothing of it, keeps its own
number, and pushes it back at the next change of level. Pointed at 🔥
*temperature in ⟨room⟩* the knob turns the *room*: the card shows *set by
hand, 22.5 °C until 22:00, then the plan again*, every valve in the room
follows, a window still stops it, and when the plan's next step comes the
hand is lifted and the plan has the room back (four hours, if there is no
plan). That is the one to use — the same thing a hotel thermostat does when
you nudge it. The card has the same hand on it: **By hand** with a slider, the number
beside it, and *for how long*. The slider only speaks when it is let go —
dragging it moves the reading, not the valves — and arrow keys step half a
degree. While any control is in use — a slider held, a dropdown open, a cursor in a
field — the page stops rebuilding cards, so a reading landing mid-gesture
cannot close the menu, discard what was typed or pull the tile out from
under the thumb; it catches up the moment you let go — until the plan's next step by default,
or a fixed 1 / 2 / 4 / 8 / 24 hours that holds through whatever the plan
does meanwhile. The presets are one tap away on the same line — **Comfort · Eco · Night
· Off · Plan** — and a button can do the same: *heating in ⟨room⟩ set to
comfort* on one press, or **set to next** to cycle plan → comfort → eco →
night → plan on a single button. *Back to the plan now* on the card, or
*set to plan*, lifts a hand-set number early.

*Where the "until" comes from:* with a plan, the hand lasts until the plan
would next change level — set 22 at 15:00 with a *night* step at 22:00 and
it reads *until 22:00*; the plan's own steps are the natural moment to give
the room back. With no plan, or with a level picked on the preset buttons,
four hours. A fixed length chosen on the card or sent with a target
(`hold_s`) overrides both.

**Heating is a target like a plug.** Every place that offers a target — a
button binding, a sensor rule, a scene, a schedule, a presence trigger —
also offers 🔥 *heating control* and 🔥 *heating away mode* (on, off,
toggle) and 🔥 *heating in ⟨room⟩* with **set to** plan / comfort / eco /
night / off. So *everybody left → away on*, *first one home → away off*,
*the bedroom button → bedroom to night*, *22:30 → every room to night* are
ordinary entries, and a *Leaving* scene can switch the lights off and the
heating to away in one go. Setting a room's level this way is the same as
pressing one of the preset buttons on its card; *plan* hands it back to the
plan.

**Which sensors count as a room's windows.** With *stop for an open window*
on, the card lists the door and window sensors — the room's own first,
the rest marked *elsewhere*. Unticked, every contact in the room counts;
tick some and only those do, so a balcony door can stop the radiator while
the door to the hall does not.

**Control can be paused per room as well as for the house.** The
*Heating control* switch at the top stops everything; the **Control**
switch beside a room's temperature stops that room alone. Off, the room
keeps its plan, its three temperatures and its thermometer, but nothing is
sent — the heads keep whatever they were last told — and the card says
so. It is a target too: 🔥 *heating control in ⟨room⟩* takes on, off or
toggle from any binding, rule, scene, schedule or presence trigger, so a
button by the bed can hand the bedroom's valve back to its own dial for
the night and a schedule can take it back in the morning.

**A room without heating is switched off as a room.** The switch beside a
room's name on its card says whether it is heated at all. Off, the card
folds down to its title, nothing is ever sent for it, and it drops out of
the *heating in ⟨room⟩* targets — a bathroom with electric underfloor
heating on a plug, or a hallway with no radiator, is still a room for the
energy table and the sensors in it, just not one the Heating tab argues
with.

A valve's own card (Sensors) carries the same slider for its target, and
shows what it is doing rather than what it is configured with: the settings
a head keeps — its minimum and maximum, its own comfort/eco numbers, the
window-detection parameters — stay in *All values* and out of the headline,
and `position` on a head reads *valve open*. A remote's headline is the last
thing pressed or turned, not its cell voltage.

**What each head is doing is on the card.** A line per valve: what it is
holding, what its own thermometer reads (with the offset if one is set), how
far the valve is open, whether it is heating, its mode and its battery.
**Close** shuts the valves in that room. Where a head has an *off* mode
that is what is sent, because a set point of five does not actually close a
valve whose own thermometer sits on the radiator and reads warmer than the
room — it just carries on regulating; heads without an off mode get five
degrees, frost protection only. Any preset other than *Off* opens the head
again.
which is the same as the *Off* preset and is why it is offered on the room
rather than on the single head: a head shut on its own would be reopened by
the room on the next round. On a head that is in no room the button is its
own: the head's *off* mode where it has one, its lowest number where it does
not. **Match the room** sets the head's `local_temperature_calibration` so its
reading agrees with the room's thermometer — a head sits on the radiator and
runs warm, and the offset is there for exactly this.

**One vocabulary, not three.** A TuYa head has its own preset list —
*schedule, manual, boost, complex, comfort, eco, away* — which is the
firmware's own language and means nothing to the plan: *away* is the head's
away temperature, *schedule* is the head's weekly programme, *comfort* is a
number stored in the head. Zigmon's five — **Comfort, Eco, Night, Off,
Plan** — belong to the room, and they are what a button, a rule, a scene
and the Heating tab all speak. So when a head is in a room, its own card
offers exactly those five and the room's slider, not the firmware's list;
the head is kept in manual underneath and its own words never appear. A head
that is in no room keeps its raw controls, since then there is nothing else
driving it, and says so on the card with where to put it.

**A head with a mind of its own is taken off it.** A TuYa/Immax TS0601
radiator head keeps its own weekly programme, an away mode and a preset,
and while any of those is in charge a set point sent to it is obeyed for a
moment and then overwritten by its own schedule — which is what makes such
a head look like it ignores the dashboard. Before driving one, zigmon puts it in **manual** (`preset`), clears **away
mode**, and clears **force** — that last one pins the valve open or shut
whatever the set point says, and a head left on `force: open` heats flat out
and looks like it is ignoring the dashboard.

The mode needs care, because the words lie. On a TS0601 head `heat` means
*heat continuously without regulating* and `auto` means *hold the set
point* — the opposite of what they read like, and Zigbee2MQTT says so on
the device page. Those heads give themselves away by also exposing a
`preset`, which is what decides schedule versus manual there, so zigmon asks
for **auto** on them and **heat** on a plain thermostat that has no preset.
Every one of these is sent only when the head's own report says it is not
already there, so it is a message or two the first time and nothing
afterwards.

**The valves are simply the ones in the room.** There is nothing to
configure beyond putting a head into a room under Control → Automation →
Rooms; any device there with a target temperature is driven, and the card
names them. A head not in any room is left alone.

A valve is only told something when the wanted temperature has actually
changed, because a radiator head is a sleeping device and re-sending the
same number every minute would keep its radio awake for nothing. The same
reason means a change takes effect when the head next talks to the mesh —
seconds to a few minutes.

**A socket can be marked as a light.** In Plugs and sensors each channel has
a *What it is* column: **a socket** or **a light**. A light is polled,
switched, bound, ruled and recorded exactly like any other plug; what the
mark changes is how it reads.

A light also *reads* as one: its icon is a bulb rather than a socket
wherever it appears — its card, the device lists, and every dropdown that
offers a target — and the dropdowns group the lights together and sort by
name only within the group, so picking one is not a hunt through the
sockets.

**The energy table groups by room, and opens closed.** Each room is a line of
its own carrying the room's totals, and what is not in a room sits under
*Not in a room*; with no rooms set up at all, the sockets of one physical box
make a line instead (a four-way strip is one row, `PlugX4-TVLoznice · 4
sockets`) and the rest sit under *Single plugs*. Everything starts folded, so
the card is a handful of lines rather than a wall of numbers; click a group
to open it, **Open every group** for the lot, and what you opened is still
open after a reload. Every plug still
opens its last thirty days as bars, and so does *All plugs*.

**A monthly summary** goes out on the first of the month: what last month
drank, what it cost, the five biggest, and the totals by room. `zigmon
--monthly` prints it on demand; `"monthly_summary": false` in `config.json`
switches the notification off.

**Devices are sorted by what they are.** A device's kind is read from what
it reports, not from its name: ♨️ a radiator valve, 🎛️ a knob, 🔘 a button,
🚶 a motion sensor, 🚪 a door or window contact, 🌡️ a thermometer, 🔌 a
socket, 💡 a light, 📡 a router or coordinator. Every list and dropdown
groups by that and sorts by name inside the group, so picking the valve or
the PIR is not a hunt.

**Moving cards is a mode of its own.** Unlocking editing used to make every
tile on the Overview, Sensors, Plugs and WiFi draggable at once, which meant
a slider or a menu on a card could not be used without the card coming
along. There is a **Rearrange** switch beside the lock now — on the tabs that have
movable cards (Overview, Plugs, Sensors, Buttons, WiFi, Heating) and nowhere
else — off by default,
and while it is off the cards stay put and their controls work normally. On,
the movable cards are outlined, their controls are held inert, and a card
can be dragged where it belongs; the order is saved as before. It goes back
off when editing locks. The Heating cards move too, and the order they are
left in is the order the rooms keep everywhere else.

**Lists can be dragged into order.** Every editor under Control — button
bindings, sensor rules, scenes, rooms, sequences, schedules, people,
presence triggers, messages, devices and gateways — has a handle on the left
of each row. Drag it and the row moves; the new order is part of that
section's unsaved changes, and its **Save** button writes it like any other
edit. It is not decoration: bindings, rules and scene steps are considered
in the order they are listed, so being able to move one above another is
part of saying what should happen. A device drags with all its channels, a
rule with its clock line, a gateway with what it reported. Entries from
`config.json` have no handle, since they are not ours to reorder. The
handle only appears while editing is unlocked.

## Command line

```bash
zigmon --status                       # every device with its latest readings
zigmon --devices                      # the device table
zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
zigmon --events                       # the event log
zigmon --watch                        # live feed straight from the broker
zigmon --watch --bridge --raw         # including bridge/* topics, untruncated
zigmon --permit-join on               # open the network for four minutes
zigmon --plug                         # every plug, live from the device
zigmon --plug-on Lednice              # switch a plug; also --plug-off, --plug-toggle
zigmon --plug-pulse Lednice --ms 3000 # flip, hold 3 s, flip back
zigmon --plug-reset Lednice --types aenergy,switch_on
zigmon --bindings                     # which button action drives which plug
zigmon shelly Lednice dump            # the Shelly toolkit, see below
zigmon --reset-data history           # erase: all, history, events, or a device name
zigmon --check                        # is the whole system healthy
zigmon --diag                         # settings, API latency, database size
zigmon                                # run the daemon in the foreground
```

## The full Shelly toolkit

Everything the standalone Shelly reader in upsmon could do, ported whole and
addressed by the name a device has in the configuration — the address and
password come from there. Each command has its own `--help`.

```
zigmon shelly [NAME] <command> [options]
```

| reading | |
|---|---|
| `discover` | find Shelly devices on the LAN over multicast DNS, with a diagnosis when nothing answers |
| `info` | identity, firmware, auth and Matter state |
| `dump` | every value the device exposes, every component |
| `methods [COMPONENT] [--examples]` | every RPC method it supports, with a note on what each is for |
| `poll` | a live table. `--interval`, `--count`, `--csv FILE` |
| `watch` | the same, pushed over the device's websocket |
| `listen`, `serve` | receive webhooks, or an outbound websocket |

| controlling | |
|---|---|
| `on`, `off`, `toggle` | switch the relay |
| `reset-counters [type…]` | no type means every counter |
| `reboot [--wait]` | restart, optionally waiting for it to come back |

| configuring | |
|---|---|
| `config [COMPONENT] ['{JSON}']` | read or write a component's settings — a write is read back and the keys the firmware dropped are listed |
| `matter status\|on\|off\|code` | Matter, and the pairing code |
| `ble status\|on\|off\|rpc-on\|rpc-off` | radio and RPC over Bluetooth |
| `call METHOD ['{JSON}']` | anything the above does not cover |

```bash
zigmon shelly Lednice dump
zigmon shelly Lednice config switch:0 '{"auto_off": true, "auto_off_delay": 300}'
zigmon shelly Lednice ble on --reboot
zigmon shelly Lednice methods Switch --examples
zigmon shelly --host 172.16.16.13 --password secret info
zigmon shelly discover
```

`--host`, `--password`, `--switch-id`, `--json` and `--no-color` work
anywhere, before the command or after it. With no name, the first
configured plug is assumed. `watch` needs a device without a password, the
websocket carrying no authentication. `discover` does not cross subnets.
`ble` and `matter` take effect after a reboot, which `--reboot` will do.

## Sensors over RPC and webhooks

```json
"sensors": [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}],
"sensor_listen": true,
"sensor_listen_host": "0.0.0.0",
"sensor_listen_port": 8088
```

A sensor with an address is polled like a plug; while it sleeps the poll
simply fails quietly. A battery sensor pushes instead — point its webhook at
`http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=NAME` (`bp` for battery
percent, `bv` for volts, `rssi`). JSON bodies are accepted as well. Each
source becomes a device like any other; `zigmon shelly listen` shows what
arrives without recording it, and the Control tab's daemon card counts the
pushes.

## API

Read endpoints are open on the loopback; the two that change something
require `X-Zigmon-Token` and, when configured, the PIN.

| endpoint | returns |
|---|---|
| `GET /api/status` | every device: identity, latest values with labels and units, verdict and reasons; the bridge; counts |
| `GET /api/health` | daemon uptime, broker connection, message count, database statistics |
| `GET /api/devices` | the device list (same shape as in status) |
| `GET /api/device?id=NAME` | one device, plus the keys it has history for and the full exposes map |
| `GET /api/history?device=NAME&keys=temperature,humidity&range=24h&points=600` | rows of `{ts, key…}`, hourly beyond two weeks |
| `GET /api/events?limit=100&device=NAME` | the event log |
| `GET /api/keys?device=NAME` | which values have history |
| `POST /api/permit-join` | `{"enable": true, "time": 254, "pin": "…"}` |
| `POST /api/unlock` | `{"pin": "…", "minutes": 15}` → `{"token", "until"}`; the token then replaces the PIN as `session` in every other POST |
| `POST /api/lock` | `{"session": "…"}` ends it early |
| `POST /api/reset` | `{"scope": "all|history|events|device", "device": "…", "pin": "…"}` |

The plugs:

| endpoint | returns |
|---|---|
| `GET /api/plugs` | every plug: state, live figures, each counter with its value and the date it started from |
| `GET /api/plug?name=Lednice&refresh=1` | one plug, optionally read again first |
| `POST /api/plug/switch` | `{"name": "Lednice", "on": false}`, `{"name": "…", "toggle": true}` or `{"name": "…", "pulse": true, "ms": 5000}` — needs the PIN |
| `POST /api/plug/reset` | `{"name": "Lednice", "types": ["aenergy"]}`, or `[]` for every counter — needs the PIN |
| `GET /api/bindings` | the button bindings |
| `POST /api/bindings` | `{"bindings": [{"device": "Button", "action": "single", "plug": "Lednice", "do": "toggle"}]}` — replaces the list, needs the PIN. `do` is `toggle`, `on`, `off` or `pulse` with `pulse_ms`; `plug` may be `*` for every plug, and the same button and action may drive any number of rows — all matching rows fire in parallel |

**Devices can be renamed and deleted from the Devices tab.** Renaming a
Zigbee device goes through Zigbee2MQTT itself (`bridge/request/device/rename`),
so the friendly name — and the MQTT topic — change everywhere, permanently;
history stays, because everything is keyed by the IEEE address. A Shelly
seen over MQTT or a webhook gets a dashboard alias instead (the topic cannot
be renamed from here); the table then shows the alias with the topic
underneath. Plugs and sensors added on the Control tab are named there.
Deleting a device erases every reading, event and snapshot recorded for it,
and takes out any binding or rule that used it as the source (each removal
is logged); a plug used as the *target* of other rules stays, since the plug
itself was not deleted. If the device reports again it simply reappears,
fresh, under its default name. Bindings and rules store the device id, not
the name, so renaming breaks nothing. `POST /api/device/rename`.

**Zigbee switches are targets too.** Anything in the network with a
settable on/off state — a SONOFF ZBM5 wall-switch channel, a bulb, a relay
module — appears in the binding and rule editors marked ⚡ alongside the
Shelly plugs, one entry per channel (`Svetla · L1`). The daemon drives them
by publishing `{"state_l1": "ON"|"OFF"|"TOGGLE"}` to
`zigbee2mqtt/<name>/set`; toggle and pulse work (a pulse with an unknown
current state falls back to a blind double TOGGLE), the switch's own report
comes back through the bridge and repaints the dashboard, and every command
is logged as an event with its origin. `*` (all plugs) deliberately never
includes them. The daemon's broker account must be allowed to **write**
`zigbee2mqtt/+/set` — if commands vanish silently, that is the mosquitto
ACL (`topic readwrite zigbee2mqtt/#` for the zigmon user covers it).

**Thermostatic valves.** A radiator head — an IMMAX NEO 07703L, a Moes, any
Tuya TS0601 head, a Danfoss — is a device with values to set rather than a
state to flip, and it is handled as one. Its card shows what it measures,
what it is holding and how far the valve is open, and carries the controls:
**Target − 21.5 °C +** and the modes the head itself names (*off · heat ·
auto*, or its presets). Half a degree per press, within the limits the head
reports.

The same things are targets everywhere else: in the binding, rule, scene,
schedule and presence-trigger editors the head appears as
`TRV-Obyvak · target temperature` and `TRV-Obyvak · mode`, and the *Do*
column offers **set to …** with a number box carrying the head's own range,
or the list of its modes. So *at 06:30 on weekdays set the living-room head
to 21.5*, *when everybody leaves set every head to 16*, *the hall button
sets the bedroom head to 18* are all ordinary entries — a schedule, a
presence trigger, a binding.

Underneath it is one publish of `{"current_heating_setpoint": 21.5}` or
`{"system_mode": "off"}` to `zigbee2mqtt/<name>/set`, logged as an event
with its origin. A valve is a sleeping device: it collects what was sent for
it when it next talks to the mesh, which is anywhere from seconds to a few
minutes, so nothing waits on a confirmation — the card repaints when the
head reports its new state itself. Pairing is Zigbee2MQTT's business; once
it is in the network zigmon picks it up like any other device.

**Notifications.** Configure a channel in `config.json` — `notify_ntfy`
(a topic URL such as `https://ntfy.sh/moje-tajne-slovo`; subscribe to the
same topic in the ntfy app) and/or `notify_telegram_token` +
`notify_telegram_chat` — and pick on the Control tab what is worth a push:
critical problems, warnings, devices going quiet, every rule that fires.
The same story repeats at most once per 15 minutes; there is a test button.
Below the global choices sits a per-device list: any plug or sensor can be
set to **mute** (nothing about it, ever), **critical only**, or
**everything about it** (warnings, going quiet, rules touching it) —
overriding the global choices for that one device.

**Scenes** are named bundles of actions ("Vecer": lamp on, chandelier off,
TV plug on) edited on the Control tab, runnable from there and available as
🎬 targets for button bindings and rules. A step can carry **after N s**
(from the scene start, fractions allowed): steps without it fire at once,
together, so `0 / 2 / 5` makes a small cascade.

**Rules: AND or OR between the two conditions.** The second condition
(already there for "occupancy AND temperature", say) now has an AND/OR
choice. Two PIRs covering one room: one rule `occupancy ≥ 1 OR occupancy ≥ 1`
(the two sensors) → on; a second `occupancy ≤ 0 AND occupancy ≤ 0` → off,
so the light turns on the moment either one sees motion and off only once
both have gone quiet — two rules instead of four. Applies to both live
firing and Dry run.

**Sequences** turn one button into a cycle: the first press runs step 1,
the next press — minutes or days later — step 2, and so on, then around
again; the position is remembered across restarts. A step is a scene — many
targets at once or with delays — or any single target with an action: a
plug on, a light off, a valve set to 19, a room's heating to night. Bind a
button to
the 🔁 entry to advance; bind another button (or the same button's long
press) to the ↺ entry to run the optional *reset* — a scene, or a single
target with an action, all off say — and start over. Edited on the Control tab, with Advance/Reset buttons and
a "next press: step N — scene" line.

**Rules grew up.** Besides the clock window: an optional **AND** condition
against any second reading (`occupancy ≥ 1 AND illuminance ≤ 50`), a
**must-hold-for** time in seconds (no motion for 600 s, a washer under 5 W
for 180 s — the stretch completes even if the source goes quiet), a
**way-back threshold** folding a hysteresis pair into one rule (`≥ 65 → on,
back at 55` switches off past 55), and windows that take **sunrise/sunset**
with minute offsets (`sunset-30`–`23:30`; set `latitude` and `longitude`
in `config.json`).

**Energy** on the Overview: today / yesterday / this month / last month /
this year / last year per plug, with an **All plugs** total row at the
bottom when there is more than one — click its name for the same 30-day
bar chart as any single plug, summed across all of them, computed reset-proof from the meters' own counters; set
`price_per_kwh` (and `currency`) to see money next to the kWh. On the
Control tab, an **Energy summary** card restarts those sums from zero, now,
per plug or for all — a baseline marker, not a data wipe: history and the
plug's own meters stay, and a restarted plug carries ↺ next to its name.

**Settings on the dashboard.** The safe-to-change slice of `config.json`
lives in a Settings card on Control: alert thresholds, polling intervals,
price/currency, latitude/longitude, notification channels. Saved values are
stored in the daemon's database, apply immediately (no restart) and win
over the file; putting a value back to what the file says drops the
override, and overridden fields carry a blue edge with the file's value in
the tooltip. Connection, ports, paths and the PIN stay file-only.

**Database card** (Control): the file's size and row counts, the last
roll-up, **DB latency** (a trivial read and write, measured by the daemon)
and **app latency** (browser → daemon → back, plus the daemon's own time to
answer), with four buttons — **Check integrity** (SQLite's own check),
**Optimise** (ANALYZE + VACUUM; pauses writes while it runs), **Back up
database now** (a consistent copy via SQLite's online backup, into the
backups folder, kept `backup_keep` deep) and a **list of the backups on the server**,
each with **Download** (the file itself, to keep off-site), **Restore**
(replaces the live contents; the state right before is saved as its own
backup first, so a mistaken restore can be undone) and **Delete**; plus
**Upload a backup** to put a file back into the list — it travels in pieces
of a few MB and is checked to be a healthy zigmon database before it is
accepted. (Uploads need `client_max_body_size 6m` in nginx; the upgrade
raises it from the old 16k.)

**Backup**: one button downloads every dashboard-made setting (devices with
passwords, bindings, rules, scenes, layout, aliases, notification choices)
as a JSON file; import replaces them wholesale. The dashboard also carries
a PWA manifest, so "Add to home screen" gives it an icon and a standalone
window on a phone.

**Sensor rules** drive a plug from any numeric reading, not just a button:
source device, value, comparison (≥ ≤ > <), threshold, plug (or all plugs)
and the action, including pulse. Any device with numbers works as a source —
a thermometer, a plug's own power draw, Wi-Fi signal, battery. Rules are
edge-triggered: one fires when its condition **becomes** true, not on every
report while it stays true, and a per-rule cooldown (default 300 s) stops a
value dancing on the line from hammering the relay. Two rules make a
thermostat with a dead band: `temperature ≥ 30 → on`, `temperature ≤ 27 →
off`. Each rule can be limited to a **clock window** (`from`/`to`, `22:00`–`06:00`
crosses midnight; empty means around the clock) and can name a **safe state
for when the window closes** (`window_end`: `off` or `on`) — a
motion-driven light is switched off when its night window ends, whether or
not anyone walked past at that moment, and the rule re-arms freshly when
the window opens again. Outside its hours a rule does not fire at all.
Yes/no readings — occupancy, contact, ON/OFF states — count as 1 and 0, so
`occupancy ≥ 1 → on` with the sensor's own clear-timeout makes a motion
light. Edited on the Control tab, which shows each rule's current reading
and whether it holds; `GET/POST /api/rules`; `zigmon --rules` on the
command line.

A **pulse** flips the socket and flips it back after the delay: off → wait
→ on when the plug is on (a power-cycle for whatever is plugged in), on →
wait → off when it is off. The way back is retried three times and, if it
still fails, logged as a critical event; a second pulse while one is running
is refused.

Plugs and sensors are managed on the **Control tab** — add, test, remove,
save behind the PIN; the daemon starts polling at once, no restart. *Test*
asks the device who it is and fills in whether it is a plug or a sensor;
*Find Shelly devices* runs a multicast DNS query from the server and offers
what answered on this subnet. Passwords are kept in the daemon's database
(readable by the daemon alone) and never sent back to the browser — the
field shows "(kept)" and stays blank. The same endpoints:

| endpoint | |
|---|---|
| `GET /api/managed` | plugs and sensors, without passwords |
| `POST /api/managed` | `{"plugs": [...], "sensors": [...]}` — replaces the dashboard-managed list; omit `password` to keep it, `clear_password: true` to drop it |
| `POST /api/managed/test` | `{"host": "…", "password": "…"}` → model, firmware, whether it has a switch |
| `POST /api/managed/discover` | what mDNS finds in three seconds |

Every entry can be **disabled without deleting it** — the State column on
the tab, or `"enabled": false` on the entry in `config.json` or in the
`POST /api/managed` body. A disabled plug or sensor is not polled, cannot be
switched and disappears from the lists, but its history stays, and bindings
and rules that point at it are kept (they simply do not fire, and the plug
shows as "(disabled)" in their editors) — enable it again and everything
carries on where it left off.

`config.json` still works and wins: entries under `"plugs"` and `"sensors"`
there are shown on the tab as read-only and cannot be duplicated from the
dashboard. `mqtt_name` is the device's own MQTT prefix (whatever its *MQTT prefix*
setting says — `plugtst`, `shellies/xxx`, …). Fill it in and two things
happen: the daemon does not record the device twice, and it **subscribes to
that prefix and learns about relay changes the instant they happen** — a
press of the button on the plug, its web page, the Shelly app. Without it,
an outside change waits for the next poll (up to `plug_poll_interval`,
15 s). With it, the dashboard repaints in well under a second, with the
source in the event ("switched on (button)"). A plug shows up as a
device like any other, so History and All values cover it too, and `zigmon
shelly NAME …` addresses both kinds of entry.

`device` and `id` accept the friendly name or the IEEE address.

## Broker account

The daemon needs a broker login with these rights (the installer can create
it in a local mosquitto):

```
user zigmon
topic read zigbee2mqtt/#
topic write zigbee2mqtt/bridge/request/#
topic read shellies/#
```

## What was verified

Without a broker in the build environment, against replayed messages from a
real Zigbee2MQTT 2.13 with Shelly BLU H&T ZB, BLU Button Tough ZB, a Shelly
H&T Gen3 and a Plug M Gen3 over `shellies/`:

* device discovery from `bridge/devices`, readings before the list arrives,
  rename, removal, availability, button actions, bridge events
* every API endpoint, token and PIN handling, erasing by scope
* the plugs against a mock Shelly Plug M Gen3 with SHA-256 digest
  authentication: polling, switching, per-counter resets including ones the
  firmware only pretends to clear, and a button press toggling the plug
  through a binding
* the dashboard driven in a headless browser through every tab, chart
  rendering, the PIN dialogue and a reset
* the whole Shelly toolkit against the same mock: info, dump, methods,
  config read and write with keys the firmware drops, ble and matter
  switches, on/off/toggle, counter resets, call, poll to CSV, reboot --wait,
  and the discovery diagnosis on a network with no answer
* a polled sensor, GET and POST webhook pushes, and a push carrying nothing usable
* the installer's dry run

Current version: **2.80.4**

2.80.4 — ninth latency pass. A button press reaches the wire as a switch
command in 1.5 ms (median of fifteen, worst 1.8 ms); the knob path is the
one deliberate exception at a quarter-second, so a burst of clicks is one
message. A two-minute soak straight at the daemon with rules, heating and
polls live: wake-ups 1.2 ms median, 2.9 ms worst, no outlier. One thing
found: a dropdown keeps the keyboard focus after a choice, and the repaint
pause introduced in 2.78.5 honoured that focus — so after picking a level on
a card the page stood still until something else was clicked. A choice now
releases the focus, and the repaint with it.

2.80.3 — the explanation under a valve card's controls is a tooltip on the
level line rather than a paragraph taking up half the card.

2.80.2 — *Off* (and an open window) now shuts a valve with the head's own
**off** mode rather than a set point of five, which a head reading the
radiator's own warmth would simply regulate against; the next preset turns
it back on.

2.80.1 — the *Right now* dropdown on a Heating card is gone: the preset
buttons on the line above are the same choice, and two copies of it could
only disagree.

2.80.0 — taking a valve over now also clears `force` (which pins the valve
open or shut regardless of the set point) and asks a TS0601 head for **auto**
rather than **heat**, since on those heads `heat` means heat without
regulating and `auto` means hold the number. A valve that is still forced
says so on its line.

2.79.6 — on a valve's own card the five levels are a dropdown rather than a
row of small buttons, which is what fits on a device card; the Heating tab
keeps them as buttons, where there is room.

2.79.5 — the heating controls carry icons like everything else (🔆 Comfort,
🌿 Eco, 🌙 Night, ⛔ Off, 📅 Plan, ⏱️ for the hold, 🌡️ Match the room), and a
button on a valve line no longer sits against the text beside it.

2.79.4 — a **Close** button beside each valve shuts the room to frost
protection; on a valve that belongs to no room it switches the head off
directly.

2.79.3 — a valve outside any room says on its card that the presets it is
showing are the head's own, and where to put it to get the room's five
instead.

2.79.2 — the Rearrange switch appears only on the tabs whose cards can be
moved, and the Heating cards can now be moved as well; their order is the
rooms' order.

2.79.1 — a valve that belongs to a room shows the room's controls on its own
card — the same slider and the same Comfort / Eco / Night / Off / Plan — in
place of the head's firmware presets, so there is one set of words for
heating everywhere.

2.79.0 — a **Rearrange** switch beside the lock decides whether cards can be
dragged. Off by default, so a slider or a dropdown on a tile can be used
without the tile moving; on, the movable cards are outlined and their
controls step aside.

2.78.5 — an open dropdown, a focused field or a held slider anywhere on the
page now pauses the card repaint until it is let go, instead of being closed
or reset by the next reading.

2.78.4 — the slider is the whole control: the − and + beside it did the
same thing in bigger steps and are gone. Holding any slider now freezes the
repaint until it is let go, so a reading arriving mid-drag no longer
rebuilds the tile under the thumb.

2.78.3 — *Match the room* works: the web relay had no entry for the
calibrate call, so the browser's request never reached the daemon and came
back as *unknown endpoint*.

2.78.2 — a remote's card leads with what was pressed or turned again (a
knob that also reports its cell voltage was showing 3000 mV instead); a
valve's card leads with what it measures, holds and how far it is open, with
its stored settings left in All values; and its target is set with the same
slider the Heating cards use.

2.78.1 — devices are categorised by what they report and carry their own
icon (valve, knob, motion, contact, thermometer); the lists group by that
and sort by name inside. A heating card shows each head's own reading,
valve position, running state, mode and battery, and can set its offset to
match the room's thermometer.

2.78.0 — a self-programmed radiator head (TuYa/Immax TS0601) is put into
manual with away mode cleared before it is driven, so its own weekly
programme stops overwriting what the room asks for; and the temperature on
a Heating card is set with a slider that speaks when it is let go.

2.77.4 — eighth latency pass, over the knob, the room holds and the
presets. Two things fixed. Every heating save — every knob click, every
preset — wiped the memory of what each valve had last been sent, so the next
round re-sent every valve in the house its current number, and sleeping
heads drained a queue of repeats; the memory is kept now and only a changed
wish goes out. And the plug poll started every box's request in the same
instant; the boxes are now asked one after another across the first half of
the round. A knob press over MQTT reaches the dashboard in 8–13 ms
including the room update; a two-minute soak straight at the daemon, with
rules, heating and plug polls live, gave wake-ups of 1.0 ms median and 6.8
ms worst, not one outlier.

2.77.3 — the room's presets are buttons on its card (Comfort, Eco, Night,
Off, Plan), and a heating level target takes **next** to cycle through them
from a single button.

2.77.2 — a room's temperature can be set by hand on its card (−, a number,
+, and for how long: until the plan's next step, or a fixed 1–24 hours);
the same length can be sent with a target as `hold_s`.

2.77.1 — the number a room is holding is labelled on its card with why
(*eco*, *comfort*, *away*), and a hand-set one is shown large in amber with
*by hand until 22:00*, so a knob's effect is seen at a glance.

2.77.0 — a room's temperature is a target: 🔥 *temperature in ⟨room⟩* takes
to / up by / down by, so a knob nudges the room and every valve in it
follows; the nudge holds until the plan's next change of level (or four
hours without a plan), the card says so, and *Back to the plan now* ends it
early.

2.76.2 — a knob on a valve feels like a dial: steps accumulate on what was
last sent, the card updates the moment the knob moves, and a burst of
clicks leaves as one message with the final number instead of a queue the
sleeping head drains one at a time.

2.76.1 — in a binding row the *set to* trio (to/up by/down by, the number,
the unit) borrows the neighbouring pulse-ms column, so the number is a
field rather than a sliver.

2.76.0 — *set to* on a number can step **up by** or **down by** an amount,
so a rotary knob drives a valve's target temperature; hovering a rule's
source, reading or threshold shows the sensor's current values with the
chosen one marked; and a valve's settables are named by what they are
(*Frost protection*, *Heating stop*) rather than a converter's generic
*State*.

2.75.2 — seventh latency pass, over the heating targets, the sequence
steps and everything else since 2.72: nothing in the daemon's hot path
changed shape. A four-minute soak (959 reports, four a second, rules and
heating live): wake-up 1.5 ms median, 2.2 ms p99, no outlier; the same
again ran without a single error. One thing tightened: the process's RSS
crept up a few MB per hour of heavy dashboard use, and tracemalloc showed
nothing held — it was glibc handing every request thread its own malloc
arena. The unit now caps arenas at two.

2.75.1 — a sequence's reset takes the same choices as a step: a scene, or
any single target with an action.

2.75.0 — a sequence step can be any single target with an action — a plug,
a light, a valve's target, a room's heating level — not only a scene. A
scene is still the way to do several things in one step.

2.74.2 — heating control per room: a switch on the room's card, and a
*heating control in ⟨room⟩* target (on / off / toggle) everywhere a target
is chosen.

2.74.1 — a room can be marked as not heated: its card folds to the title,
nothing is sent for it, and it is not offered as a heating target.

2.74.0 — heating is a target everywhere: *heating control* and *away mode*
switch on/off/toggle, a room's level is set to plan / comfort / eco /
night / off, from any binding, rule, scene, schedule or presence trigger.
And a room can be told which of its door and window sensors count as
windows.

2.73.0 — each room on the Heating tab can be told which thermometer to read,
for a room that has none of its own or has several.

2.72.0 — sixth latency pass, over everything added since the last one
(rooms, heating, the phone reports, the ntfy listener, the rule workers,
the reorderable editors, the QR encoder). Two things found. The ntfy
listener read its stream with no timeout, so a link that died quietly would
have left it waiting forever; it now reconnects after two minutes of
silence, since ntfy keeps the line alive every forty-five seconds. And every
draggable row registered its own mouse-up listener on the document each
time an editor was repainted, which grew without bound over a long session;
there is one now. Measured on the real database: status 1.9 ms, the
heating state 0.2 ms, a two-minute soak at four reports a second with
wake-ups of 1.3 ms median and 3.3 ms worst, no outlier, memory flat.

2.71.6 — on a Heating card, the *stop for an open window* switch is set off
from the plan above it by a rule and some space, and sits level with its
label instead of riding above it.

2.71.5 — every line of the energy table carries its icon: a socket or a bulb
per plug, a house for a room, the strip's own mark where the grouping is by
box, and a sigma on the total.

2.71.4 — the energy table groups by room only: the separate *Lights* section
is gone, and every group now starts folded when the page loads.

2.71.3 — the QR code on a Setup chip was being drawn behind the dialog it
belongs to (z-index 80 under a backdrop at 100), so hovering appeared to do
nothing; and a browser that refuses the clipboard call did so silently,
which made clicking look dead. The QR now sits above everything, and a copy
falls back to the old method and says so if even that fails.

2.71.2 — the *What is in them* list under Rooms is ordered like every other
device list: sockets, lights, sensors, buttons, routers, and by name inside
each.

2.71.1 — a socket marked as a light carries a bulb icon everywhere it is
listed, and the dropdowns group the lights together, by name within the
group.

2.71.0 — the editors under Control can be reordered by dragging a row by
the handle on its left: bindings, rules, scenes, rooms, sequences,
schedules, people, presence triggers, messages, devices and gateways. The
order is saved by that section's own Save button.

2.70.1 — Rooms sits under Scenes in Control → Automation.

2.70.0 — hovering a copy chip in the phone Setup dialog shows its contents
as a QR code, so a link or a token goes to the phone by pointing a camera at
the screen. The encoder is written out in the page (byte mode, level L,
versions 1-10, all eight masks scored); every code it makes was read back
with an independent decoder across 154 payloads, including Czech diacritics.

2.69.1 — picking *a light* now survives Save: the web relay copies each
device field by name onto what it forwards to the daemon, and the new one
was not on that list, so the choice was dropped on the way and came back a
socket.

2.69.0 — a plug can be marked as **a light**: identical in every other way,
but listed in a section of its own in the energy table, folded away when the
page opens.

2.68.3 — a room just added can be assigned to straight away: it used to get
its id only when saved, so until then the only choice beside every device
was a dash that did nothing. The empty choice now reads *not in a room*,
and each room says how many things are in it.

2.68.2 — Rooms moved from Control → Devices to Control → Automation, above
the bindings, since what a room is for is the automation side.

2.68.1 — the phone Setup dialog opens wide (900 px) so a link is one line
rather than four, its copy chips stand on their own, and the bold in a step’s
heading is bold rather than the letters <b>.

2.68.0 — the phone **Setup** dialog carries the step-by-step for the
handset: the Location Services setting, every screen of the iOS automation
in order, the ntfy or direct variant depending on what is configured, how
to test it, and tap-to-copy chips for the URL, topic and token.

2.67.3 — the Rooms and Heating editors behave like every other one: their
buttons carry icons, and a locked page no longer greys the controls out and
leaves them dead — you edit, and the PIN is asked for when you save.

2.67.2 — the energy table groups even before any room exists: the sockets
of one strip fold into a line of their own, with a *Fold every group*
button, and the folds are remembered across a reload.

2.67.1 — the row above the Heating rooms lines its labels and controls up
in a grid instead of leaning them against each other, and the SSH fields
read in the order they are filled in: how to get in, port, username,
password.

2.67.0 — rooms, and a Heating screen built on them: three temperatures and
a weekly plan per room, an away switch, an open window that stops the room
while it lasts, all pushed to the valves in that room and only when the
number has changed. The energy table is grouped by room and folds. A
summary of what the month cost goes out on the first, by notification.

2.66.1 — settings layout: the SSH password sits next to the username it
belongs with and the port after them, and a label too long for its column no
longer wraps and drops its own field half a row below the others.

2.66.0 — a phone can report its own arrivals and departures, from its
geofence, over mobile data, before it is on the Wi-Fi: a token per person, a
link to paste into an iOS Shortcut or Tasker, and an ntfy topic as an
alternative for anyone who would rather expose nothing. Arriving counts at
once; a reported departure is checked against the controller first.

2.65.0 — fifth latency pass, nothing found in the daemon: a two-minute soak
on the real database (4 reports/s) gave wake-ups of 1.5 ms median, 2.1 ms
p99, 2.5 ms max with no outlier at all; a full garbage collection of the
70 MB heap costs 4 ms and gen-2 collections never ran during 3,000 status
builds. The one thing tightened is the web layer: the installer (and
`--upgrade`) sets the php-fpm pool to keep 6-24 idle workers with 8 started
(the stock five made an opening page wait for forks, since every open tab
already holds one worker for its live wait) and installs php-opcache.

2.64.1 — arriving and leaving are noticed when they happen. What the access
points last reported over SSH was being folded back into every presence
round whatever its age, so a phone that had left stayed on the network - and
its owner stayed home, and "when the last person leaves" stayed unfired -
until the next point probe, up to `detail_s` (three minutes by default)
later. That snapshot now only fills in detail on clients the controller
still lists, and carries a client of its own only while it is fresh. For a
minute after anybody comes or goes the controller is also asked every five
seconds instead of every `poll_s`.

2.64.0 — thermostatic radiator valves. The keys a head reports are named
and carry their units, its card gains a target-temperature control and a
mode picker, and a new action **set to …** makes its target and its mode
usable in bindings, rules, scenes, schedules and presence triggers, with
the head's own range and list of modes offered in the editor.

2.63.2 — fixes the Wi-Fi tab, blank since 2.62.2: the *why out* line meant
for the People editor had landed in the *Other networks* renderer, where it
threw on the first row and took the client list down with it. Both draw
again; the line is where it belongs.

2.63.1 — the Wi-Fi tab never goes blank: when the controller is not
answering, the client list says so with the error and when it was last
asked; a client record that cannot be drawn gets a one-line row instead of
taking the list down; and any tab that fails to draw shows the error at
its top while the rest of the page carries on.

2.63.0 — fourth latency pass. The API listener's backlog is 64 instead of
the default 5, so a page opening with a dozen requests on top of the parked
long polls no longer has connections dropped and retried a second later. A
presence rule's quick look at the Wi-Fi never waits behind a regular poll
stuck on a slow controller (it takes the lock for its own 3 s at most, then
goes with the last answer). *Must hold for N s* rules are finished on the
presence worker rather than the clock thread, and the clock beats every
half second. After the daemon comes back, the page's live wait retries at
once instead of after its backoff. Soak on the real database unchanged:
wake-up median 1.3 ms, status 6.7 ms, 3 % of one core.

2.62.2 — the *why out* explanation sits on its own line under the person
(it was crammed into the 54 px tag column) and reads more plainly.

2.62.1 — a person's device can be matched by the name the controller shows
(`name:iPhone16`) instead of a Wi-Fi address that rotates; every *out* tag
and the At home dialog say in words why the person counts as out.

2.62.0 — presence-gated rules look at the Wi-Fi *now* before firing: an
answer older than `presence_fresh_s` (4 s) is refreshed with a 3 s timeout,
so arriving is seen before the first motion alert. Rules are evaluated on
their own ordered thread (hand-over from the broker thread in microseconds),
so that wait never touches a button, a report or a plug. The controller can
now be asked as often as every 3 s (was 10).

2.61.0 — third latency pass, with a 60-second soak on the real database
(five reports a second with a browser-style long-poll client): wake-up
median 1.0 ms, p95 1.5 ms, max 1.8 ms; `/api/status` 5.5 ms; 1.9 % of one
core; no memory growth. Two things were found and fixed. *Must hold for
N s* rules and weekly schedules were checked from the plug poll loop every
30 s, so "no motion for 10 min" fired anywhere up to half a minute late and
a slow plug round pushed a 07:00 schedule to 07:01 — they now beat on their
own one-second thread (a 3 s rule fires at 3.0 s), and that thread runs
even with no plug configured, where before a house with only Zigbee
switches got no schedules at all. Notifications that sat in the queue for
five minutes (internet down) are dropped with a log line instead of
arriving as stale news, critical ones excepted.

2.60.3 — the coordinator is no longer shown as offline while it is plainly
running. Zigbee2MQTT marks it offline because it does not answer the
availability pings an end device answers, and that word used to stand even
when the box was answering on its own network API a second earlier. A
gateway that answers now vouches for its device: the bridge's *offline* is
ignored while its own API is replying, and counts again three poll rounds
after it stops.

2.60.2 — the Overview metric cards open the same detail dialog *Needs
attention* has: **Online** lists what is and is not reporting with why and
how long ago, **At home** each watched person with how they are known and
the state of the controller, **Devices** everything grouped by kind. A name
in any of them opens that device's History, as before.

2.60.1 — *By hand* works through scenes and sequences: the hold used to be
looked for on the scene itself, where no rule ever looks, so a PIR rule
switched the lights off again a minute after the button had set the scene.
Each light the scene touches is now held (or released) on its own.

2.60.0 — a second latency pass, measured on a real 4-day database. Every
message type costs under 4 ms on the broker thread (a device list 2 ms, a
PIR event with its rule 2.9 ms, a button with its binding 3.9 ms); the
message path, the wake-up and `/api/status` (1.7 ms warm) never wait for
the store lock, so a VACUUM or a backup stalls charts only, never a press.
On the page: the Overview rebuilds only the card whose facts changed (one
report used to rebuild all of them and restart every animation); a burst
of reports — twenty in 80 ms — becomes one status fetch instead of twenty,
with the first change still fetched at once; the broker keepalive is 20 s
and reconnects start after 1 s, so a dead link is noticed in ~30 s rather
than 90 and picked up again in a second.

2.59.4 — the Emoji and Facts pop-ups are wide and low (720 / 860 px,
capped at 70 % of the window and scrolling inside) instead of a 330 px
column; Facts lays its items out in a grid with the description beside
each placeholder; both open above the button when there is no room below.

2.59.3 — Ctrl+Space (and moving through the completion list) no longer
scrolls the page: the list scrolls itself, focus is restored without
scrolling, and when there is no room under the caret the list opens above
it.

2.59.2 — the live preview under every message is back and drawn as the
phone will show it (app, title, text, picture line), refreshed a beat
after each keystroke and after a level/picture change. It used to need an
unlocked session because it went through the PIN-guarded save endpoint;
it now has its own read-only `/api/message-preview`, so it shows locked or
not. The Emoji button offers seven groups (~180 symbols) instead of four.

2.59.1 — IDE-style completion in the message editor: `{` or Ctrl+Space
lists every fact with a description and a live example, a device name and
`.` lists that device's readings with their current values; the Facts
button carries the same catalogue with examples.

2.59.0 — messages know more: `{unit}`, `{label}`, `{model}`, `{battery}`,
`{signal}`, `{temperature}`, `{humidity}` of the device that set it off;
`{weekday}`, `{sunrise}`, `{sunset}`, `{daylight}`, `{home_count}`,
`{attention}`, `{attention_list}`, `{alerts}`, `{uptime}`; and
`{Name.key}` for the current reading of any device at all (`{Name.state}`,
`{Name.age}`, `{Name.battery}` …). The Facts picker lists them.

2.58.2 — Zigbee gateways editor: the Detect/Remove buttons sat in a fixed
104 px cell and hung out past the card; the cell now takes what they need,
the other columns may shrink, and on a narrower window the buttons wrap under
the row instead of overflowing. The *config.json* tag rides with them
rather than becoming a stray seventh cell.

2.58.1 — verified against a real 4-day database (35 devices, 15 plugs, 3
gateways, 11 bindings, 6 rules): a report, a button press with its binding
and a PIR event with its rule each wake the dashboard in 2–7 ms while every
plug is unreachable; `/api/status` builds in 9 ms. Its 140 kB of JSON is now
gzip-compressed by nginx (~15 kB on the wire; `--upgrade` adds the directive
to an existing server block).

2.58.0 — the *may be unplugged* device state; and a pass over latency:
the Overview charts load in one request (`/api/history-multi`) and, on a
live update, at most once every 15 s instead of once per message from any
device — the cards themselves still repaint the instant a report lands;
history is thinned inside SQLite (a 7-day series takes ~8 ms instead of
~40 ms of lock time per device); the systemd unit no longer caps the
daemon at 15 % CPU with idle I/O, which had been stretching sub-second
work into seconds whenever the machine was busy; a plug's MQTT push of new
watts wakes the dashboard at once; the plug poll period counts from the
start of a round, so one dead box no longer delays the others or the
schedules; a multi-relay strip now records *contact restored* and wakes the
dashboard when it comes back.
