#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zigmon.py - monitoring daemon for every sensor published by Zigbee2MQTT (and,
optionally, by Shelly WiFi devices) over an MQTT broker.

One file. Python standard library plus paho-mqtt, which AlmaLinux 9 ships in
EPEL as python3-paho-mqtt.

It subscribes to the broker, keeps a long-term history in SQLite, and exposes
everything on a localhost HTTP API that the PHP dashboard reads. The two
actions that change something (opening the network for joining, erasing
history) are guarded by a token, so the web user never holds broker
credentials.

Runs as a systemd service, but every function is also available from the
command line for testing:

    zigmon --status              every device with its latest readings
    zigmon --devices             the device table
    zigmon --history DEV 24h     recorded samples of one device as a table
    zigmon --events              the event log
    zigmon --watch               live feed straight from the broker
    zigmon --permit-join on      open the Zigbee network for four minutes
    zigmon --plug                the smart plugs, live from the devices
    zigmon --plug-toggle NAME    switch a plug (also --plug-on, --plug-off)
    zigmon --bindings            which button does what
    zigmon --check               health check against the running daemon
    zigmon --diag                API latency, database size, config in force
    zigmon                       run the daemon in the foreground
"""

# Bumped by hand with every change to this file.
__version__ = '2.80.4'

import argparse
import collections
import errno
import json
import math
import os
import re
import secrets
import select
import shutil
import signal
import subprocess
import tempfile
import socket
import sqlite3
import ssl
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

try:
    import paho.mqtt.client as mqtt
except ImportError:            # reported properly by preflight(), not here
    mqtt = None

# ---------------------------------------------------------------------------
# Paths and defaults
# ---------------------------------------------------------------------------
CONFIG_FILE = Path(os.environ.get('ZIGMON_CONFIG', '/etc/zigmon/config.json'))
STATE_DIR = Path('/var/lib/zigmon')
DB_FILE = STATE_DIR / 'history.db'
RUN_DIR = Path('/run/zigmon')
TOKEN_FILE = RUN_DIR / 'api-token'
SERVICE_USER = 'zigmon'

DEFAULTS = {
    # --- the broker ---------------------------------------------------------
    'mqtt_host': '127.0.0.1',
    'mqtt_port': 1883,
    'mqtt_username': '',
    'mqtt_password': '',
    'mqtt_tls': False,           # True for a TLS listener (usually port 8883)
    'mqtt_ca': '',               # CA file to verify the broker; empty = no verification
    'mqtt_client_id': 'zigmon',
    'mqtt_keepalive': 20,      # a dead broker link is noticed within ~30 s, not 90

    # --- what to listen to --------------------------------------------------
    'base_topic': 'zigbee2mqtt',
    # Additional topic filters. Shelly Gen2/Gen3 devices publishing their
    # status under a prefix (shellies/<name>/status/...) are understood; any
    # other topic carrying a JSON object is stored under the topic's second
    # element as the device name.
    'extra_topics': ['shellies/#'],
    'manual_hold_s': 14400,       # a hand-held target is given back after this long; 0 = never
    'presence_fresh_s': 4,        # a presence-gated rule re-asks the Wi-Fi controller if its answer is older than this; -1 = never
    'monthly_summary': True,      # a notification on the first of the month with what the last one cost
    'networkmap_interval': 300,   # seconds between network-map scans (who is whose parent); 0 turns it off

    # --- our own API --------------------------------------------------------
    'api_host': '127.0.0.1',
    'api_port': 9849,
    'token_file': '/run/zigmon/api-token',

    # --- timing (seconds) ---------------------------------------------------
    # A reading that arrives sooner than this after the previous stored one
    # replaces it instead of adding a row. 0 keeps every reading.
    'sample_interval': 30,
    'aggregate_interval': 3600,
    'db_file': '',               # empty = /var/lib/zigmon/history.db

    # --- retention ----------------------------------------------------------
    'retain_full_days': 14,
    'retain_hourly_days': 730,
    'retain_events_days': 730,

    # --- thresholds used for the health verdict -----------------------------
    'battery_warn': 30,
    'battery_crit': 15,
    'lqi_warn': 40,
    'lqi_crit': 20,
    # A device that has not reported for this long is flagged, whatever the
    # bridge says about its availability. 0 disables it.
    'silence_alert_buttons': 1,     # 0 = a button/remote that has not been pressed in a while never triggers "silent for..."
    'stale_warn_min': 180,
    'stale_crit_min': 1500,
    # Temperature and humidity limits, applied to every device. null = off.
    'temperature_min': None,
    'temperature_max': None,
    'humidity_max': None,

    # --- logging ------------------------------------------------------------
    'log_file': '/var/log/zigmon/zigmon.log',
    'log_level': 'info',
    'log_to_journal': True,

    # --- Shelly smart plugs, read and controlled over local RPC -------------
    # [{"name": "Lednice", "host": "172.16.16.12", "password": "", "switch_id": 0,
    #   "mqtt_name": ""}]  - mqtt_name: the plug's shellies/<name> prefix, so the
    # same device is not also picked up from MQTT.
    'plugs': [],
    'plug_poll_interval': 15,
    'plug_sample_interval': 60,
    'plug_min_request_gap': 1.0,
    'plug_command_gap': 0.05,       # a switch command may follow the last request this soon (s)
    'plug_timeout': 5.0,
    # Shelly sensors with an address of their own (an H&T on USB power answers
    # RPC; on battery it sleeps, and the webhook below is what carries it).
    # [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}]
    'sensors': [],
    # Accept webhook pushes from battery sensors that cannot be polled:
    #   http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=HT-Sklep
    'sensor_listen': False,
    'sensor_listen_host': '0.0.0.0',
    'sensor_listen_port': 8088,

    # --- the dashboard's PIN for permit-join and erasing data ---------------
    'pin': '',                   # empty disables the PIN (the token still applies)
    'pin_attempts': 5,
    'pin_lockout_s': 300,
    'public_view': True,
    'backup_enabled': 1,          # 1 = write the daily settings backup
    'backup_time': '03:30',       # local HH:MM
    'backup_keep': 14,            # how many of each to keep
    'backup_zigbee': 1,           # 1 = also ask Zigbee2MQTT for its coordinator backup
    'chart_outages': 0,            # 1 = shade stretches where a chatty source went quiet, on every chart
    'link_plugs': 1,               # 1 = a plug's name / chart button opens its history
    'link_sensors': 1,             # 1 = clicking a sensor card opens its history
    'link_buttons': 1,             # 1 = clicking a button card opens its history
    'gateway_poll_interval': 30,    # seconds between polls of each zigbee_gateways entry
    'zigbee_gateways': [],          # [{"name": "...", "host": "ip", "target": "coordinator" or an existing device name}]          # false = even reading the dashboard asks for the PIN first
    # notifications: fill a channel in and pick what to send on the dashboard
    'notify_ntfy': '',              # full topic URL, e.g. https://ntfy.sh/moje-tajne-slovo
    'notify_telegram_token': '',    # bot token from @BotFather
    'notify_telegram_chat': '',     # chat id
    # where the house stands, for sunrise/sunset in rule windows
    'latitude': None,
    'longitude': None,
    # money: per-kWh price for the energy summary
    'price_per_kwh': None,
    'currency': 'Kč',
}

CONFIG = dict(DEFAULTS)
CONFIG_NOTES = []
CONFIG_FATAL = []
DEBUG = False
LOG_HANDLE = None
LOG_PATH = None


def token_path():
    return Path(CONFIG.get('token_file') or str(TOKEN_FILE))


def db_path():
    return Path(CONFIG.get('db_file') or str(DB_FILE))


def _whoami():
    try:
        import pwd
        return pwd.getpwuid(os.geteuid()).pw_name
    except Exception:
        return str(os.geteuid())


def _coerce(current, value):
    """Make a config value the same type as its default, where that is sane."""
    if current is None:
        if value in ('', None):
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return value
    if isinstance(current, bool):
        if isinstance(value, str):
            return value.strip().lower() in ('1', 'true', 'yes', 'on')
        return bool(value)
    if isinstance(current, int):
        try:
            return int(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, float):
        try:
            return float(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, list):
        if isinstance(value, str):
            return [v.strip() for v in value.split(',') if v.strip()]
        return list(value) if isinstance(value, (list, tuple)) else current
    return value if value is not None else current


NOTIFY_CATEGORIES = ('crit', 'warn', 'offline', 'rule', 'switch')


def notify_override_set(value):
    """A per-device override: a preset name, or custom:cat1,cat2."""
    if value in NOTIFY_PRESETS:
        return NOTIFY_PRESETS[value]
    if isinstance(value, str) and value.startswith('custom:'):
        return {c for c in value[7:].split(',') if c in NOTIFY_CATEGORIES}
    return None


NOTIFY_PRESETS = {
    'mute': set(),
    'crit': {'crit'},
    'crit_offline': {'crit', 'offline'},
    'crit_offline_switch': {'crit', 'offline', 'switch'},
    'all': {'crit', 'warn', 'offline', 'rule', 'switch'},
}

KNOWN_PLUG_KEYS = {'host_state', 'model', 'mac', 'name', 'host', 'password', 'switch_id', 'mqtt_name', 'enabled', 'kind', 'retain_full_days', 'monitor_only'}


def warn_unknown_keys():
    for entry in (CONFIG.get('plugs') or []) + (CONFIG.get('sensors') or []):
        if isinstance(entry, dict):
            for k in entry:
                if k not in KNOWN_PLUG_KEYS:
                    log('config: unknown key %r on device %r - a typo?' % (k, entry.get('name')), 'warn')
    for entry in CONFIG.get('zigbee_gateways') or []:
        if isinstance(entry, dict):
            for k in entry:
                if k not in ('name', 'host', 'target', 'username', 'password', 'model', 'fw', 'kind'):
                    log('config: unknown key %r on zigbee_gateways entry %r - a typo?' % (k, entry.get('name')), 'warn')
    for k in CONFIG:
        if k not in DEFAULTS and not k.startswith('_'):
            log('config: unknown top-level key %r - a typo?' % k, 'warn')


def load_config():
    """File first, then ZIGMON_* environment variables, which win."""
    if CONFIG_FILE.is_file():
        try:
            raw = json.loads(CONFIG_FILE.read_text())
            if not isinstance(raw, dict):
                CONFIG_FATAL.append('%s is not a JSON object' % CONFIG_FILE)
            else:
                for key, value in raw.items():
                    if key not in DEFAULTS:
                        CONFIG_NOTES.append('unknown option "%s" ignored' % key)
                        continue
                    CONFIG[key] = _coerce(DEFAULTS[key], value)
        except PermissionError:
            CONFIG_FATAL.append(
                '%s exists but cannot be read as %s. Fix with:  '
                'sudo chown root:%s %s && sudo chmod 640 %s'
                % (CONFIG_FILE, _whoami(), SERVICE_USER, CONFIG_FILE, CONFIG_FILE))
        except ValueError as e:
            CONFIG_FATAL.append('%s is not valid JSON: %s' % (CONFIG_FILE, e))
        except OSError as e:
            CONFIG_FATAL.append('could not read %s: %s' % (CONFIG_FILE, e))

    for key in DEFAULTS:
        env = os.environ.get('ZIGMON_' + key.upper())
        if env is not None:
            CONFIG[key] = _coerce(DEFAULTS[key], env)
            CONFIG_NOTES.append('%s taken from the environment' % key)
    return CONFIG


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def open_log(path=None):
    """Open the log file for appending. Safe to call again to reopen it."""
    global LOG_HANDLE, LOG_PATH
    close_log()
    path = path if path is not None else CONFIG.get('log_file')
    if not path:
        return None
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        LOG_HANDLE = open(str(target), 'a', encoding='utf-8')
        LOG_PATH = target
    except OSError as e:
        LOG_HANDLE, LOG_PATH = None, None
        sys.stderr.write('cannot write the log file %s: %s\n' % (path, e))
    return LOG_HANDLE


def ensure_log_current():
    """Reopen if the file we hold is no longer the one at the configured path."""
    if not LOG_HANDLE or not LOG_PATH:
        return False
    try:
        same = os.stat(str(LOG_PATH)).st_ino == os.fstat(LOG_HANDLE.fileno()).st_ino
    except OSError:
        same = False
    if same:
        return False
    open_log()
    log('log file reopened - it was rotated without a signal reaching us')
    return True


def close_log():
    global LOG_HANDLE
    if LOG_HANDLE:
        try:
            LOG_HANDLE.close()
        except OSError:
            pass
    LOG_HANDLE = None


def log(msg, level='info'):
    if level == 'debug' and not (DEBUG or CONFIG.get('log_level') == 'debug'):
        return
    line = '%s  %-5s %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), level, msg)
    if LOG_HANDLE:
        try:
            LOG_HANDLE.write(line + '\n')
            LOG_HANDLE.flush()
        except (OSError, ValueError):
            try:
                open_log()
                if LOG_HANDLE:
                    LOG_HANDLE.write(line + '\n')
                    LOG_HANDLE.flush()
            except Exception:
                pass
    if CONFIG.get('log_to_journal', True) or not LOG_HANDLE:
        stream = sys.stderr if level in ('error', 'warn') else sys.stdout
        stream.write(line + '\n')
        stream.flush()


# ---------------------------------------------------------------------------
# Units, labels and what a payload key means
# ---------------------------------------------------------------------------
# Zigbee2MQTT tells us the unit and label of every property in the device's
# "exposes" definition; these are the fallbacks for keys that arrive without
# one, and for the Shelly devices, which describe nothing.
KEY_INFO = {
    'temperature':   ('Temperature', '°C'),
    'humidity':      ('Humidity', '%'),
    'battery':       ('Battery', '%'),
    'voltage':       ('Voltage', 'mV'),
    'linkquality':   ('Link quality', 'lqi'),
    'illuminance':   ('Illuminance', 'lx'),
    'illuminance_lux': ('Illuminance', 'lx'),
    'light_level':   ('Light level', ''),
    'pressure':      ('Pressure', 'hPa'),
    'co2':           ('CO₂', 'ppm'),
    'pm25':          ('PM2.5', 'µg/m³'),
    'voc':           ('VOC', 'ppb'),
    'power':         ('Power', 'W'),
    'energy':        ('Energy', 'kWh'),
    'current':       ('Current', 'A'),
    'contact':       ('Contact', ''),
    'occupancy':     ('Occupancy', ''),
    'water_leak':    ('Water leak', ''),
    'vibration':     ('Vibration', ''),
    'tamper':        ('Tamper', ''),
    'battery_low':   ('Battery low', ''),
    'action':        ('Action', ''),
    'state':         ('State', ''),
    'position':      ('Position', '%'),
    'force':         ('Valve override', ''),
    'window_detection': ('Window detection', ''),
    'away_mode':     ('Away mode', ''),
    'brightness':    ('Brightness', ''),
    'device_temperature': ('Device temperature', '°C'),
    'soil_moisture': ('Soil moisture', '%'),
    # thermostatic radiator valves (IMMAX NEO, Moes, Tuya, Danfoss ...)
    'local_temperature': ('Measured temperature', '°C'),
    'current_heating_setpoint': ('Target temperature', '°C'),
    'occupied_heating_setpoint': ('Target temperature', '°C'),
    'unoccupied_heating_setpoint': ('Away target', '°C'),
    'comfort_temperature': ('Comfort target', '°C'),
    'eco_temperature': ('Eco target', '°C'),
    'holiday_temperature': ('Holiday target', '°C'),
    'boost_heating': ('Boost', ''),
    'boost_heating_countdown': ('Boost left', 's'),
    'boost_time': ('Boost time', 's'),
    'pi_heating_demand': ('Valve open', '%'),
    'valve_position': ('Valve open', '%'),
    'position_valve': ('Valve open', '%'),
    'running_state': ('Heating', ''),
    'system_mode': ('Mode', ''),
    'preset': ('Preset', ''),
    'preset_mode': ('Preset', ''),
    'away_mode': ('Away', ''),
    'window_detection': ('Open window detection', ''),
    'window_open': ('Window open', ''),
    'open_window': ('Window open', ''),
    'child_lock': ('Child lock', ''),
    'valve_detection': ('Valve detection', ''),
    'valve_alarm': ('Valve alarm', ''),
    'local_temperature_calibration': ('Temperature offset', '°C'),
    'frost_protection': ('Frost protection', ''),
    'heating_stop': ('Heating stopped', ''),
    'schedule': ('Schedule', ''),
    # Shelly Gen2/3 component fields
    'tC':            ('Temperature', '°C'),
    'tF':            ('Temperature', '°F'),
    'rh':            ('Humidity', '%'),
    'apower':        ('Power', 'W'),
    'aenergy.total': ('Energy total', 'Wh'),
    'battery.V':     ('Battery voltage', 'V'),
    'battery.percent': ('Battery', '%'),
    'external.present': ('External power', ''),
    'lux':           ('Illuminance', 'lx'),
    'switch.output': ('Output', ''),
    'switch.apower': ('Power', 'W'),
    'switch.voltage': ('Voltage', 'V'),
    'switch.current': ('Current', 'A'),
    'switch.pf':     ('Power factor', ''),
    'switch.freq':   ('Frequency', 'Hz'),
    'switch.aenergy.total': ('Energy total', 'Wh'),
    'switch.temperature.tC': ('Device temperature', '°C'),
    'switch.temperature.tF': ('Device temperature', '°F'),
    'pm1.apower':    ('Power', 'W'),
    'pm1.voltage':   ('Voltage', 'V'),
    'pm1.current':   ('Current', 'A'),
    'pm1.aenergy.total': ('Energy total', 'Wh'),
    'wifi.rssi':     ('WiFi signal', 'dBm'),
    'sys.uptime':    ('Uptime', 's'),
}

# Keys that are bookkeeping rather than measurements.
IGNORE_KEYS = {'last_seen', 'elapsed', 'update', 'update_available', 'linkquality_raw',
               'id', 'ts', 'transaction', 'src', 'dst', 'method', 'params', 'result',
               'device_temperature_unit', 'ret_aenergy.total'}

# Keys that count as a "reading" for the overview cards, in display order.
HEADLINE_KEYS = ['temperature', 'local_temperature', 'current_heating_setpoint',
                 'occupied_heating_setpoint', 'pi_heating_demand', 'valve_position',
                 'tC', 'humidity', 'rh', 'illuminance', 'illuminance_lux',
                 'lux', 'light_level', 'pressure', 'co2', 'pm25', 'voc', 'apower', 'power',
                 'energy', 'aenergy.total', 'switch.output', 'voltage', 'contact', 'occupancy',
                 'water_leak', 'position', 'brightness', 'state']


def key_info(key):
    """Look the key up, then every shorter dotted suffix of it."""
    parts = key.split('.')
    for i in range(len(parts)):
        info = KEY_INFO.get('.'.join(parts[i:]))
        if info:
            return info
    return None


def key_base(key):
    parts = key.split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in KEY_INFO:
            return candidate
    return parts[-1]


def headline_rank(key):
    parts = key.split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in HEADLINE_KEYS:
            return HEADLINE_KEYS.index(candidate)
    return None


def parse_prometheus_text(raw):
    """A minimal reader for the Prometheus text exposition format that
    /metrics answers with: 'name{labels} value' or 'name value' per line,
    '#' lines are comments. Labels are folded into the key so a metric with
    several label sets doesn't overwrite itself."""
    out = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.rsplit(' ', 1)
        if len(parts) != 2:
            continue
        name, value = parts
        try:
            value = float(value)
        except ValueError:
            continue
        if '{' in name:
            base, labels = name.split('{', 1)
            labels = labels.rstrip('}')
            tag = '_'.join(v.strip('"') for _, v in
                           (kv.split('=', 1) for kv in labels.split(',') if '=' in kv))
            name = base + ('.' + tag if tag else '')
        out[name] = value
    return out


def key_label(key):
    info = key_info(key)
    if info:
        return info[0]
    return key.replace('_', ' ').replace('.', ' · ').capitalize()


def key_unit(key):
    info = key_info(key)
    return info[1] if info else ''


def flatten(obj, prefix=''):
    """{'battery': {'V': 2.9}} -> {'battery.V': 2.9}. Lists are kept as-is."""
    out = {}
    if not isinstance(obj, dict):
        return out
    for key, value in obj.items():
        name = ('%s.%s' % (prefix, key)) if prefix else str(key)
        if isinstance(value, dict):
            out.update(flatten(value, name))
        else:
            out[name] = value
    return out


SENSOR_COMPONENTS = ('temperature', 'humidity', 'devicepower', 'illuminance')


def normalise_shelly_status(flat):
    """Shelly.GetStatus flattened -> the keys the dashboard knows.

    temperature:0.tC becomes tC, devicepower:0.battery.V becomes battery.V;
    switch:0.apower becomes switch.apower; wifi.rssi and sys.uptime stay.
    """
    out = {}
    for key, value in flat.items():
        if isinstance(value, (dict, list)):
            continue
        m = re.match(r'^([a-z_]+):(\d+)\.(.+)$', key)
        if m:
            component, index, rest = m.group(1), m.group(2), m.group(3)
            if rest in ('id', 'source') or 'by_minute' in rest or 'minute_ts' in rest:
                continue
            if component in SENSOR_COMPONENTS:
                out[rest if index == '0' else '%s%s.%s' % (component, index, rest)] = value
            elif component in ('switch', 'pm1', 'cover', 'light', 'input'):
                out['%s%s.%s' % (component, '' if index == '0' else index, rest)] = value
        elif key in ('wifi.rssi', 'wifi.sta_ip', 'wifi.ssid', 'sys.uptime', 'sys.ram_free',
                     'cloud.connected', 'mqtt.connected'):
            out[key] = value
    return out


def sun_minutes(lat, lon, when=None, sunset=False):
    """Local minutes-of-day of sunrise or sunset (NOAA approximation), or None
    in polar conditions."""
    day = time.localtime(when if when is not None else time.time())
    lng_hour = lon / 15.0
    t = day.tm_yday + (((18 if sunset else 6) - lng_hour) / 24.0)
    mean = (0.9856 * t) - 3.289
    lsun = (mean + 1.916 * math.sin(math.radians(mean)) + 0.020 * math.sin(math.radians(2 * mean)) + 282.634) % 360
    ra = math.degrees(math.atan(0.91764 * math.tan(math.radians(lsun)))) % 360
    ra += (math.floor(lsun / 90) - math.floor(ra / 90)) * 90
    ra /= 15.0
    sin_dec = 0.39782 * math.sin(math.radians(lsun))
    cos_dec = math.cos(math.asin(sin_dec))
    cos_h = (math.cos(math.radians(90.833)) - sin_dec * math.sin(math.radians(lat))) / (cos_dec * math.cos(math.radians(lat)))
    if cos_h > 1 or cos_h < -1:
        return None
    hours = (math.degrees(math.acos(cos_h)) if sunset else 360 - math.degrees(math.acos(cos_h))) / 15.0
    ut = (hours + ra - 0.06571 * t - 6.622 - lng_hour) % 24
    local = (ut + (day.tm_gmtoff / 3600.0)) % 24
    return int(local * 60)


def numeric(value):
    """A float for anything worth charting, or None."""
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        v = value.strip().upper()
        if v in ('ON', 'OPEN', 'TRUE', 'OCCUPIED', 'YES'):
            return 1.0
        if v in ('OFF', 'CLOSE', 'CLOSED', 'FALSE', 'CLEAR', 'NO'):
            return 0.0
        try:
            return float(value)
        except ValueError:
            return None
    return None


def parse_span(text):
    """'6h', '24h', '7d', '30d', '1y', '90m' -> seconds."""
    m = re.match(r'^\s*(\d+(?:\.\d+)?)\s*([smhdwy])?\s*$', str(text or ''))
    if not m:
        raise ValueError('bad range %r (use e.g. 24h, 7d, 1y)' % text)
    n = float(m.group(1))
    unit = m.group(2) or 'h'
    mult = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400, 'w': 604800, 'y': 31557600}[unit]
    return int(n * mult)


def ascii_header(text):
    """HTTP headers carry latin-1 only, and a title with an emoji in it would
    otherwise raise on the way out. ntfy reads a UTF-8 title encoded this way."""
    try:
        str(text).encode('latin-1')
        return str(text)
    except UnicodeEncodeError:
        import base64
        return '=?UTF-8?B?' + base64.b64encode(str(text).encode('utf-8')).decode('ascii') + '?='


def human_size(nbytes):
    """Bytes as something a person reads at a glance."""
    try:
        nbytes = float(nbytes or 0)
    except (TypeError, ValueError):
        return '?'
    for unit in ('B', 'KB', 'MB', 'GB'):
        if nbytes < 1024 or unit == 'GB':
            return '%.0f %s' % (nbytes, unit) if unit == 'B' else '%.1f %s' % (nbytes, unit)
        nbytes /= 1024.0
    return '%.1f GB' % nbytes


def human_age(seconds):
    if seconds is None:
        return 'never'
    seconds = int(seconds)
    if seconds < 60:
        return '%ds' % seconds
    if seconds < 3600:
        return '%dm' % (seconds // 60)
    if seconds < 86400:
        return '%dh %dm' % (seconds // 3600, (seconds % 3600) // 60)
    return '%dd %dh' % (seconds // 86400, (seconds % 86400) // 3600)


def thin(rows, points):
    """Keep at most `points` rows, evenly spaced, always keeping the last one."""
    if points <= 0 or len(rows) <= points:
        return rows
    step = len(rows) / float(points)
    out = [rows[int(i * step)] for i in range(points)]
    if out[-1] is not rows[-1]:
        out.append(rows[-1])
    return out


# ---------------------------------------------------------------------------
# Shelly Gen2+ RPC (the smart plugs)
# ---------------------------------------------------------------------------
class PlugError(Exception):
    pass


class ShellyRPC(object):
    """Minimal JSON-RPC client for a Shelly Gen2+ device, standard library only.

    Shelly answers the first request with 401 and a challenge, and expects
    SHA-256 digest with qop=auth; urllib's own digest handler predates SHA-256
    on the Python AlmaLinux 9 ships, so it is done by hand. One challenge is
    reused for every later call with the nonce counter stepping on each time,
    because re-authenticating doubles the request count and a Gen3 plug
    answers 429 when that adds up.
    """
    _challenges = {}
    _last_request = {}
    _pace_locks = {}                # host -> Lock: pacing serializes calls to ONE box, never across boxes
    _pace_locks_guard = threading.Lock()
    _gates = {}                     # host -> [Condition, busy, waiting_commands]
    _gates_guard = threading.Lock()

    def __init__(self, host, password='', switch_id=0, label='the plug'):
        self.host = host
        self.password = password or ''
        self.switch_id = int(switch_id or 0)
        self.timeout = float(CONFIG.get('plug_timeout') or 5.0)
        self.retry_after = 0.0
        self.label = label

    @property
    def url(self):
        return 'http://%s/rpc' % self.host

    COMMANDS = ('Switch.Set', 'Switch.Toggle')

    def call(self, method, params=None):
        if not self.host:
            raise PlugError('no host configured for %s' % self.label)
        payload = {'id': 1, 'method': method}
        if params:
            payload['params'] = params
        self._priority = method in self.COMMANDS   # a person is waiting; do not queue behind the poll
        body = json.dumps(payload).encode('utf-8')
        self._wait_turn()                     # pace outside the gate, never holding the box
        gate = self._enter_device(self._priority)
        try:
            known = self._challenges.get(self.host)
            auth = self._digest_header(known, 'POST', '/rpc') if known else None
            status, reply, headers = self._post(body, auth)
            if status == 401:
                challenge = headers.get('WWW-Authenticate', '')
                if not self.password:
                    raise PlugError('%s requires a password; set it in the config' % self.label)
                self._challenges[self.host] = self._parse_challenge(challenge)
                status, reply, headers = self._post(
                    body, self._digest_header(self._challenges[self.host], 'POST', '/rpc'))
                if status == 401:
                    self._challenges.pop(self.host, None)
                    raise PlugError('%s rejected the password' % self.label)
        finally:
            self._leave_device(gate)
        if status == 429:
            retry = headers.get('Retry-After')
            self.retry_after = numeric(retry) or 0
            attempt = getattr(self, '_retries', 0)
            # a person is waiting on a command: fail fast rather than the
            # patient multi-attempt backoff that suits an unattended poll
            urgent = getattr(self, '_priority', False)
            max_attempts = 1 if urgent else 3
            cap = 2.0 if urgent else 15.0
            if attempt < max_attempts:
                self._retries = attempt + 1
                delay = min(max(self.retry_after, 2.0) * (attempt + 1), cap)
                log('%s asked us to wait; retrying in %.0fs' % (self.label, delay), 'debug')
                time.sleep(delay)
                try:
                    return self.call(method, params)
                finally:
                    self._retries = attempt
            raise PlugError('%s is rate limiting us (HTTP 429)' % self.label)
        if status != 200:
            raise PlugError('%s answered HTTP %s' % (self.label, status))
        try:
            result = json.loads(reply.decode('utf-8'))
        except ValueError:
            raise PlugError('%s did not return JSON - is it a Gen2+ device?' % self.label)
        if 'error' in result:
            error = result['error']
            raise PlugError('RPC error %s: %s' % (error.get('code'), error.get('message')))
        return result.get('result')

    def _gate(self):
        with self._gates_guard:
            gate = self._gates.get(self.host)
            if gate is None:
                gate = self._gates[self.host] = {'cond': threading.Condition(), 'busy': False, 'commands': 0}
            return gate

    def _enter_device(self, urgent):
        """One request at a time per box - that is all the hardware can serve -
        and a command jumps ahead of any poll still queued behind it. Without
        this a click waits out every request already lined up for that plug."""
        gate = self._gate()
        with gate['cond']:
            if urgent:
                gate['commands'] += 1
            deadline = time.time() + 20
            while gate['busy'] or (not urgent and gate['commands']):
                if not gate['cond'].wait(max(0.01, deadline - time.time())):
                    break               # never deadlock on a request that never returned
            gate['busy'] = True
            if urgent:
                gate['commands'] -= 1
        return gate

    def _leave_device(self, gate):
        with gate['cond']:
            gate['busy'] = False
            gate['cond'].notify_all()

    def _host_lock(self):
        with self._pace_locks_guard:
            lock = self._pace_locks.get(self.host)
            if lock is None:
                lock = self._pace_locks[self.host] = threading.Lock()
            return lock

    def _wait_turn(self):
        gap = float(CONFIG.get('plug_min_request_gap') or 0)
        if getattr(self, '_priority', False):
            gap = min(gap, float(CONFIG.get('plug_command_gap') or 0))
        if gap <= 0:
            return
        # reserve this host's next slot, then sleep outside the lock - a
        # command to one box must never wait on another box's pacing sleep
        with self._host_lock():
            previous = self._last_request.get(self.host, 0.0)
            delay = previous + gap - time.time()
            self._last_request[self.host] = max(time.time(), previous + gap)
        if delay > 0:
            time.sleep(min(delay, gap))

    def _post(self, body, auth=None):
        import urllib.request
        import urllib.error
        request = urllib.request.Request(self.url, data=body, method='POST')
        request.add_header('Content-Type', 'application/json')
        if auth:
            request.add_header('Authorization', auth)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return response.status, response.read(), dict(response.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)
        except OSError as e:
            raise PlugError('cannot reach %s at %s (%s)' % (self.label, self.host, e))

    @staticmethod
    def _parse_challenge(header):
        fields = dict(re.findall(r'(\w+)="?([^",]+)"?', header))
        fields['nc'] = 0
        return fields

    def _digest_header(self, fields, method, path):
        import hashlib
        algorithm = (fields.get('algorithm') or 'SHA-256').upper()
        digest = hashlib.sha256 if 'SHA-256' in algorithm else hashlib.md5

        def h(text):
            return digest(text.encode('utf-8')).hexdigest()

        realm = fields.get('realm', '')
        nonce = fields.get('nonce', '')
        fields['nc'] = int(fields.get('nc', 0)) + 1
        nc = '%08x' % fields['nc']
        cnonce = secrets.token_hex(8)
        ha1 = h('admin:%s:%s' % (realm, self.password))
        ha2 = h('%s:%s' % (method, path))
        response = h('%s:%s:%s:%s:auth:%s' % (ha1, nonce, nc, cnonce, ha2))
        return ('Digest username="admin", realm="%s", nonce="%s", uri="%s", '
                'algorithm=%s, qop=auth, nc=%s, cnonce="%s", response="%s"'
                % (realm, nonce, path, algorithm, nc, cnonce, response))

    # -- the calls this daemon makes ---------------------------------------
    def switch_status(self):
        return self.call('Switch.GetStatus', {'id': self.switch_id})

    def device_status(self):
        return self.call('Shelly.GetStatus')

    def device_info(self):
        return self.call('Shelly.GetDeviceInfo')

    def set_output(self, on):
        return self.call('Switch.Set', {'id': self.switch_id, 'on': bool(on)})

    def toggle_output(self):
        """One round trip instead of read-then-set; the answer says what it was."""
        return self.call('Switch.Toggle', {'id': self.switch_id})

    def reset_counters(self, types=None):
        params = {'id': self.switch_id}
        if types:
            params['type'] = list(types)
        try:
            return self.call('Switch.ResetCounters', params)
        except PlugError:
            accepted = []
            for one in (types or PLUG_COUNTER_TYPES):
                try:
                    self.call('Switch.ResetCounters', {'id': self.switch_id, 'type': [one]})
                    accepted.append(one)
                except PlugError:
                    continue
            if not accepted:
                raise
            return {'reset': accepted}


# What Switch.ResetCounters accepts, in the order the plug's own web UI lists
# them. Sending no type at all resets everything.
PLUG_COUNTERS = [
    {'type': 'aenergy',      'label': 'Active energy',      'field': 'aenergy.total',
     'help': 'the energy consumed since the last reset'},
    {'type': 'ret_aenergy',  'label': 'Returned energy',    'field': 'ret_aenergy.total',
     'help': 'energy fed back to the grid; always zero on a plain socket'},
    {'type': 'on_time',      'label': 'Total runtime',      'field': 'counts.on_time',
     'help': 'how long the relay has been switched on, in total'},
    {'type': 'switch_on',    'label': 'Switching cycles',   'field': 'counts.switch_on',
     'help': 'how many times the relay has been switched on'},
    {'type': 'on_above_thr', 'label': 'Active load runtime', 'field': 'counts.on_above_thr',
     'help': 'time spent above the active load threshold set on the plug'},
]
PLUG_COUNTER_TYPES = [c['type'] for c in PLUG_COUNTERS]
PLUG_RESET_FIELDS = {
    'aenergy': 'aenergy.total_rst_ts', 'ret_aenergy': 'ret_aenergy.total_rst_ts',
    'on_time': 'counts.on_time_rst_ts', 'switch_on': 'counts.switch_on_rst_ts',
    'on_above_thr': 'counts.on_above_thr_rst_ts',
}

PLUG_DESCRIPTIONS = {
    'switch.output': 'Relay output',
    'switch.apower': 'Active power (W)',
    'switch.voltage': 'Voltage (V)',
    'switch.current': 'Current (A)',
    'switch.pf': 'Power factor',
    'switch.freq': 'Line frequency (Hz)',
    'switch.aenergy.total': 'Energy consumed since the counters were reset (Wh)',
    'switch.ret_aenergy.total': 'Energy returned to the grid (Wh)',
    'switch.temperature.tC': 'Plug temperature (°C)',
    'switch.counts.on_time': 'Total runtime - time the relay has been on (s)',
    'switch.counts.switch_on': 'Switching cycles - times the relay has been switched on',
    'switch.counts.on_above_thr': 'Active load runtime - time above the plug threshold (s)',
    'sys.uptime': 'Plug uptime (s)',
    'sys.ram_free': 'Free RAM (bytes)',
    'wifi.rssi': 'Wi-Fi signal (dBm)',
    'wifi.sta_ip': 'Plug IP address',
    'wifi.ssid': 'Wi-Fi network',
    'cloud.connected': 'Shelly Cloud',
    'mqtt.connected': 'MQTT broker',
}
BINDING_ACTIONS = ['toggle', 'on', 'off', 'pulse']
# Settable things that are not an on/off state: a valve's target temperature,
# its mode, the comforts around them. Driven with "set:<value>".
SETTABLE_KEYS = {
    'current_heating_setpoint', 'occupied_heating_setpoint', 'unoccupied_heating_setpoint',
    'comfort_temperature', 'eco_temperature', 'holiday_temperature', 'boost_time',
    'local_temperature_calibration', 'system_mode', 'preset', 'preset_mode', 'away_mode',
    'window_detection', 'child_lock', 'valve_detection', 'frost_protection', 'heating_stop',
    'boost_heating', 'brightness', 'color_temp', 'position',
}


def valid_action(do):
    """'on', 'off', 'toggle', 'pulse' or 'set:<value>' (a number, or a mode a
    device names, for a target temperature or a thermostat mode)."""
    do = str(do or '').strip()
    if do.lower() in BINDING_ACTIONS:
        return do.lower()
    if do.lower().startswith('set:') and 1 <= len(do[4:].strip()) <= 40:
        return 'set:' + do[4:].strip()
    return None
RULE_OPS = ['>=', '<=', '>', '<', '==', '!=']
RULE_COOLDOWN_DEFAULT = 300
PULSE_MS_DEFAULT = 5000
SELFTEST_NAME = 'zigmon-selftest'   # the probe uses a real /set topic, on a device that does not exist
PULSE_MS_MIN, PULSE_MS_MAX = 100, 3600000
PLUG_HEADLINE = ['switch.apower', 'switch.aenergy.total', 'switch.output', 'switch.voltage']


# ---------------------------------------------------------------------------
# Wi-Fi presence: who is at home
# ---------------------------------------------------------------------------
# A phone on the house Wi-Fi is a good enough answer to "is anyone in". It is
# not a perfect one: a phone sleeps its radio, so it drops off the controller
# for a minute or two while its owner is asleep in the next room. Arriving is
# therefore believed at once and leaving only after a grace period.

UNIFI_PREFIXES = ['/proxy/network/integration/v1', '/proxy/network/integrations/v1']
PRESENCE_GRACE_S = 600          # gone this long before we call it "out"
WIFI_POLL_S = 30


def _unifi_opener(verify_ssl):
    import urllib.request
    if verify_ssl:
        return urllib.request.build_opener()
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return urllib.request.build_opener(urllib.request.HTTPSHandler(context=context))


UNIFI_QUICK = threading.local()      # .timeout set by a thread that cannot wait the full 15 s


def _unifi_get(opener, url, headers, timeout=15, data=None, method=None):
    import urllib.error
    import urllib.request
    timeout = min(timeout, getattr(UNIFI_QUICK, 'timeout', timeout) or timeout)
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with opener.open(request, timeout=timeout) as response:
            body = response.read().decode('utf-8', 'replace')
            return response.status, dict(response.headers), (json.loads(body) if body.strip() else {})
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', 'replace')
        try:
            parsed = json.loads(body) if body.strip() else {}
        except ValueError:
            parsed = {'error': body[:200]}
        return e.code, dict(e.headers or {}), parsed
    except urllib.error.URLError as e:
        raise RuntimeError('cannot reach %s: %s' % (url.split('/')[2], e.reason))
    except socket.timeout:
        raise RuntimeError('%s did not answer in time' % url.split('/')[2])


# Signing in is not free: the controller counts attempts and answers 429 once
# there have been too many. Asking who is at home every thirty seconds and
# logging in each time is exactly the pattern it guards against, so a session
# is opened once and kept - and deliberately not logged out afterwards, since
# logging out is what forces the next request to sign in again.
_UNIFI_SESSIONS = {}
_UNIFI_SESSION_LOCK = threading.Lock()
UNIFI_SESSION_MAX_AGE = 1800
UNIFI_LOCKOUT_S = 600


def _creds_fingerprint(cfg):
    """Enough to tell one set of credentials from another, without keeping
    them: only whether what is stored has changed since it was refused."""
    import hashlib
    raw = '%s|%s' % (cfg.get('username') or '', cfg.get('password') or '')
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16]


def _unifi_session(cfg, force=False):
    """A signed-in opener for this controller, made once and reused."""
    import urllib.request
    key = (str(cfg.get('host')), int(cfg.get('port') or 443), str(cfg.get('username') or ''))
    now = time.time()
    with _UNIFI_SESSION_LOCK:
        entry = _UNIFI_SESSIONS.get(key)
        # a password that was rejected gets one more chance the moment it is
        # changed, and not before
        if entry and entry.get('rejected') and entry['rejected'] != _creds_fingerprint(cfg):
            entry = None
            _UNIFI_SESSIONS.pop(key, None)
        if entry and entry.get('blocked_until', 0) > now:
            if entry.get('rejected'):
                raise RuntimeError('the controller rejected this username and password (HTTP %s). '
                                   'Nothing more will be tried until they are changed, because '
                                   'repeating a wrong password is what locks the account out.'
                                   % entry.get('last_status'))
            raise RuntimeError('the controller asked for a pause after %d refusal(s) in a row; '
                               '%s left of it'
                               % (entry.get('strikes') or 1, human_age(entry['blocked_until'] - now)))
        # a record of a lockout carries no opener; once it lapses a real
        # sign-in has to happen rather than the note being handed back
        if entry and entry.get('opener') and not force:
            age = now - entry['at']
            if age < UNIFI_SESSION_MAX_AGE:
                return entry
            # past its age, ask the controller to extend it instead of signing
            # in again - a refusal here simply falls through to a fresh sign-in
            status, headers, _ = _unifi_get(entry['opener'], entry['base'] + '/api/auth/refresh',
                                            dict(entry['head'], **{'Content-Type': 'application/json'}),
                                            data=b'', method='POST')
            if status < 400:
                fresh = _unifi_csrf(headers)
                if fresh:
                    entry['head']['X-CSRF-Token'] = fresh
                entry['at'] = now
                return entry
        opener = _unifi_opener(bool(cfg.get('verify_ssl')))
        opener.add_handler(urllib.request.HTTPCookieProcessor())
        base = 'https://%s:%d' % (cfg.get('host'), int(cfg.get('port') or 443))
        payload = json.dumps({'username': cfg.get('username') or '',
                              'password': cfg.get('password') or '',
                              'token': '', 'rememberMe': True}).encode()
        # Two doors: UniFi OS answers on /api/auth/login, the classic
        # controller on /api/login. A self-hosted server may rate-limit one
        # and let the other through, so both are tried before giving up.
        status, headers, answer = None, {}, {}
        for path in ('/api/auth/login', '/api/login'):
            status, headers, answer = _unifi_get(opener, base + path,
                                                 {'Content-Type': 'application/json'}, data=payload)
            if status < 400:
                break
            if status not in (404, 429):
                break
        # "You've reached the login attempt limit" counts FAILED sign-ins: the
        # password is wrong, and trying again is what keeps the account locked.
        code = str((answer or {}).get('code') or '')
        if status == 429 and 'AUTHENTICATION_FAILED' in code.upper():
            status = 401
        if status in (400, 401, 403):
            # Repeating a rejected password is how an account gets locked out
            # of its own controller. It is not tried again until somebody
            # changes what is stored.
            _UNIFI_SESSIONS[key] = {'blocked_until': now + 86400, 'at': now, 'last_status': status,
                                    'rejected': _creds_fingerprint(cfg)}
            raise RuntimeError('the controller rejected the sign-in (HTTP %s%s). It will not be tried '
                               'again until the username or password is changed - repeating a wrong '
                               'password is what locks the account out.'
                               % (status, ', ' + code if code else ''))
        if status == 429:
            # Trying again the moment the wait lapses is how a lockout renews
            # itself forever: the controller's own window is longer than the
            # one it hands out. Each refusal in a row doubles the wait.
            strikes = int((entry or {}).get('strikes') or 0) + 1
            asked = numeric(headers.get('Retry-After'))
            wait = min(3600, int(asked or UNIFI_LOCKOUT_S) * (2 ** (strikes - 1)))
            _UNIFI_SESSIONS[key] = {'blocked_until': now + wait, 'at': now, 'strikes': strikes,
                                    'last_status': 429}
            raise RuntimeError('the controller answered 429 to the sign-in (%d in a row); '
                               'waiting %s before trying again' % (strikes, human_age(wait)))
        if status >= 400:
            raise RuntimeError('signing in failed with HTTP %s' % status)
        head = {'Accept': 'application/json'}
        token = _unifi_csrf(headers)
        if not token:
            # UniFi OS hands the cross-site token back on the first read rather
            # than with the sign-in; its own pages fetch this very endpoint for
            # it, and every read after that carries it.
            st, who, _ = _unifi_get(opener, base + '/api/users/self', head)
            token = _unifi_csrf(who)
        if token:
            head['X-CSRF-Token'] = token
        entry = {'opener': opener, 'head': head, 'at': now, 'base': base, 'strikes': 0}
        _UNIFI_SESSIONS[key] = entry
        return entry


def _unifi_csrf(headers):
    """The cross-site token from a reply. It rotates, and a fresh one comes
    back under x-updated-csrf-token rather than the name it was first sent
    under, so both are looked at."""
    for name in ('x-updated-csrf-token', 'X-Updated-Csrf-Token',
                 'x-csrf-token', 'X-CSRF-Token', 'X-Csrf-Token'):
        if headers.get(name):
            return headers[name]
    return None


def _unifi_signed_get(cfg, path):
    """One signed-in read, renewing the session if it has been dropped."""
    entry = _unifi_session(cfg)
    status, headers, body = _unifi_get(entry['opener'], entry['base'] + path, entry['head'])
    fresh = _unifi_csrf(headers)
    if fresh:
        entry['head']['X-CSRF-Token'] = fresh      # it rotates; keep up with it
    if status in (401, 403):
        entry = _unifi_session(cfg, force=True)
        status, headers, body = _unifi_get(entry['opener'], entry['base'] + path, entry['head'])
        fresh = _unifi_csrf(headers)
        if fresh:
            entry['head']['X-CSRF-Token'] = fresh
    return status, body


def _probe_access_points(d, cfg):
    """What each access point says when asked - the diagnostic that matters
    now that they are the source of the detail."""
    out = {}
    for ap in (d.wifi.get('detail') or {}).get('aps') or []:
        host = ap.get('ip')
        if not host:
            out[ap.get('name') or '?'] = {'error': 'the controller gave no address for it'}
            continue
        try:
            info = parse_ap_info(ap_run(cfg, host, 'info'))
            seen = parse_mca_dump(ap_run(cfg, host, 'dump'))
            out[ap.get('name') or host] = {
                'ok': True, 'address': host, 'model': info.get('model') or seen.get('model'),
                'version': info.get('version') or seen.get('version'),
                'clients': len(seen.get('clients') or []),
                'radios': len(seen.get('radios') or []),
                'networks': len(seen.get('networks') or []),
                'temperature': seen.get('temperature'),
            }
        except Exception as e:
            out[ap.get('name') or host] = {'ok': False, 'address': host, 'error': str(e)[:140]}
    return out or {'note': 'no access point with an address is known yet - ask the controller first'}


def unifi_signin_probe(cfg):
    """Sign in once, on purpose, and report exactly what came back. A 429 says
    the account is being rate-limited; a 401 says the credentials are wrong;
    they are not the same problem and the difference matters."""
    import urllib.request
    host = str(cfg.get('host') or '')
    base = 'https://%s:%d' % (host, int(cfg.get('port') or 443))
    out = {'host': host, 'username': cfg.get('username') or '(none)',
           'has_password': bool(cfg.get('password'))}
    key = (host, int(cfg.get('port') or 443), str(cfg.get('username') or ''))
    entry = _UNIFI_SESSIONS.get(key) or {}
    if entry.get('blocked_until', 0) > time.time():
        out['waiting_for'] = int(entry['blocked_until'] - time.time())
        out['refusals_in_a_row'] = entry.get('strikes')
    opener = _unifi_opener(bool(cfg.get('verify_ssl')))
    opener.add_handler(urllib.request.HTTPCookieProcessor())
    payload = json.dumps({'username': cfg.get('username') or '',
                          'password': cfg.get('password') or ''}).encode()
    for path in ('/api/auth/login', '/api/login'):
        status, headers, body = _unifi_get(opener, base + path,
                                           {'Content-Type': 'application/json'}, data=payload)
        entry_out = {'status': status}
        for name in ('Retry-After', 'X-Ratelimit-Limit', 'X-Ratelimit-Remaining', 'X-Ratelimit-Reset'):
            if headers.get(name):
                entry_out[name] = headers[name]
        if isinstance(body, dict):
            entry_out['answer'] = {k: str(v)[:80] for k, v in list(body.items())[:6]}
        out[path] = entry_out
        if status < 400:
            out[path]['csrf_from_signin'] = bool(headers.get('x-csrf-token') or headers.get('X-CSRF-Token'))
            site = cfg.get('site') or 'default'
            # exactly what the reader asks, with the same session and token
            for label, where in (('clients (v2)', '/proxy/network/v2/api/site/%s/clients/active' % site),
                                 ('clients (older)', '/proxy/network/api/s/%s/stat/sta' % site),
                                 ('access points', '/proxy/network/api/s/%s/stat/device' % site)):
                try:
                    st, sample = _unifi_signed_get(cfg, where)
                except Exception as e:
                    out[label] = {'error': str(e)[:90]}
                    continue
                rows = sample if isinstance(sample, list) else ((sample or {}).get('data') or [])
                out[label] = {'status': st, 'rows': len(rows)}
                if rows and label.startswith('clients'):
                    out[label]['fields'] = sorted(rows[0].keys())[:18]
            break
    return out


def unifi_wants_legacy(cfg):
    """Whether to sign in at all.

    Signing in is the older way to a client's network, signal and channel.
    Asking the access points over SSH answers the same questions without a
    sign-in for the controller to count, so once that is on, this is left
    alone: a controller that locks an account out after a few failures is not
    worth troubling for something already in hand."""
    method = str(cfg.get('method') or 'official')
    if method == 'official':
        return False
    if cfg.get('ssh_enabled') and method == 'both':
        return False
    if method == 'legacy':
        return True
    return bool(cfg.get('username')) and bool(cfg.get('password'))


def unifi_clients(cfg):
    """Everything the controller currently sees, normalised. Wired clients are
    kept: a desktop is as good a sign of someone being in as a phone."""
    host = str(cfg.get('host') or '').strip()
    if not host:
        raise ValueError('the controller needs an address')
    port = int(cfg.get('port') or 443)
    base = 'https://%s:%d' % (host, port)
    opener = _unifi_opener(bool(cfg.get('verify_ssl')))
    if not unifi_wants_legacy(cfg):
        return _unifi_official(cfg, base, opener)
    try:
        return _unifi_legacy(cfg, base, opener)
    except Exception as e:
        if str(cfg.get('method')) != 'both' or not cfg.get('api_key'):
            raise
        log('wifi: signing in failed (%s), falling back to the API key' % e, 'warn')
        return _unifi_official(cfg, base, _unifi_opener(bool(cfg.get('verify_ssl'))))


UNIFI_BANDS = {'ng': '2.4', 'na': '5', '6e': '6', 'ax': '6'}
UNIFI_GENERATIONS = {'a': 'WiFi 2', 'b': 'WiFi 1', 'g': 'WiFi 3', 'n': 'WiFi 4', 'ng': 'WiFi 4',
                     'ac': 'WiFi 5', 'ax': 'WiFi 6', 'be': 'WiFi 7'}


def unifi_band(radio, channel=None):
    """Which band a radio is on. The controller names them ng, na and 6e; a
    channel above 100 with a 6 GHz radio is not the same as one on 5 GHz, so
    the radio name is trusted first and the channel is only a fallback."""
    name = str(radio or '').lower()
    if name in UNIFI_BANDS:
        return UNIFI_BANDS[name]
    if isinstance(channel, int):
        if channel <= 14:
            return '2.4'
        return '5'
    return None


def unifi_generation(proto):
    name = str(proto or '').lower()
    for key in ('be', 'ax', 'ac', 'ng', 'n', 'g', 'b', 'a'):
        if name.endswith(key) or name == key:
            return UNIFI_GENERATIONS[key]
    return ''


def unifi_probe(cfg):
    """What the controller actually answers, in outline. Field names differ
    between firmware revisions, and guessing at them from the outside is how
    an empty tab happens; this shows the shape so it can be read rather than
    assumed. Values are shortened and anything that looks like a secret is
    left out."""
    def outline(value, depth=0):
        if isinstance(value, dict):
            if depth >= 3:
                return '{%d keys}' % len(value)
            return {k: outline(v, depth + 1) for k, v in list(value.items())[:40]
                    if not re.search(r'key|pass|secret|token', str(k), re.I)}
        if isinstance(value, list):
            return [outline(v, depth + 1) for v in value[:2]] if value else []
        if isinstance(value, str):
            return value[:60]
        return value

    host = str(cfg.get('host') or '').strip()
    base = 'https://%s:%d' % (host, int(cfg.get('port') or 443))
    opener = _unifi_opener(bool(cfg.get('verify_ssl')))
    out = {'method': cfg.get('method')}
    if not cfg.get('api_key'):
        out['note'] = 'No API key is stored, so there is nothing to ask this way.'
        return out
    headers = {'X-API-KEY': str(cfg.get('api_key') or ''), 'Accept': 'application/json'}
    prefix = site_id = None
    for candidate in UNIFI_PREFIXES:
        status, _, body = _unifi_get(opener, base + candidate + '/sites', headers)
        out.setdefault('sites', {})[candidate] = status
        if status < 400 and (body.get('data') or []):
            prefix, site_id = candidate, body['data'][0]['id']
            break
    if not prefix:
        out['error'] = 'no site could be read'
        return out
    out['prefix'], out['site'] = prefix, site_id
    for name, path in (('info', '/info'),
                       ('devices', '/sites/%s/devices?limit=3' % site_id),
                       ('clients', '/sites/%s/clients?limit=3' % site_id)):
        status, _, body = _unifi_get(opener, base + prefix + path, headers)
        rows = body.get('data') if isinstance(body, dict) else None
        entry = {'status': status}
        if isinstance(rows, list):
            entry['count'] = body.get('totalCount', len(rows))
            entry['first'] = outline(rows[0]) if rows else None
        else:
            entry['body'] = outline(body)
        out[name] = entry
    first = ((out.get('devices') or {}).get('first')) or {}
    if first:
        out['reads_as_access_point'] = _is_access_point(first)
        status, _, stats = _unifi_get(
            opener, '%s%s/sites/%s/devices/%s/statistics/latest' % (base, prefix, site_id, first.get('id')), headers)
        out['statistics'] = {'status': status, 'shape': outline(stats)}
    return out


# ---------------------------------------------------------------------------
# Asking the access points themselves
# ---------------------------------------------------------------------------
# The controller's key interface will not say which network a client is on,
# nor its signal. The points know both, and answer over SSH. Nothing here
# writes: the commands are a fixed list in this file, none of them changes
# anything, and no part of it is built from what somebody typed.

# `info` is a shell function from the interactive profile, not a program, so a
# non-interactive session cannot find it by that name. Each entry is therefore
# a list of ways to ask, tried in turn until one works.
AP_COMMANDS = {
    # the whole picture: radios, networks and every station on them
    'dump': ['mca-dump', '/usr/bin/mca-dump'],
    # what it is and how long it has been up; the dump carries all of this too,
    # so this is only a lighter way of asking
    'info': ['mca-cli-op info', '/usr/bin/mca-cli-op info',
             '. /etc/profile >/dev/null 2>&1; info', 'info'],
}
SSH_CONNECT_TIMEOUT = 8
SSH_RUN_TIMEOUT = 25


def ssh_available():
    return bool(shutil.which('ssh'))


def ssh_keygen_available():
    return bool(shutil.which('ssh-keygen'))


def generate_ssh_key(comment='zigmon'):
    """A fresh ed25519 pair. The private half is what gets stored; the public
    half is what goes into the controller."""
    if not ssh_keygen_available():
        raise RuntimeError('ssh-keygen is not installed (dnf install openssh-clients)')
    folder = tempfile.mkdtemp(prefix='zigmon-key-')
    path = os.path.join(folder, 'id')
    try:
        run = subprocess.run(['ssh-keygen', '-t', 'ed25519', '-N', '', '-C', comment, '-f', path],
                             capture_output=True, timeout=30)
        if run.returncode != 0:
            raise RuntimeError('ssh-keygen failed: %s' % (run.stderr or b'').decode('utf-8', 'replace')[:200])
        with open(path, encoding='utf-8') as f:
            private = f.read()
        with open(path + '.pub', encoding='utf-8') as f:
            public = f.read().strip()
        return private, public
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def ssh_public_from_private(private):
    """The public half of a key somebody uploaded, so it can be shown to them
    without asking for it twice."""
    if not ssh_keygen_available() or not private:
        return ''
    folder = tempfile.mkdtemp(prefix='zigmon-key-')
    path = os.path.join(folder, 'id')
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(private if private.endswith('\n') else private + '\n')
        os.chmod(path, 0o600)
        run = subprocess.run(['ssh-keygen', '-y', '-P', '', '-f', path], capture_output=True, timeout=20)
        if run.returncode != 0:
            return ''
        return run.stdout.decode('utf-8', 'replace').strip()
    except Exception:
        return ''
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def _ssh_argv(cfg, host, key_path=None):
    port = int(numeric(cfg.get('ssh_port')) or 22)
    argv = ['ssh', '-p', str(port),
            '-o', 'ConnectTimeout=%d' % SSH_CONNECT_TIMEOUT,
            '-o', 'StrictHostKeyChecking=accept-new',
            '-o', 'UserKnownHostsFile=%s' % str(RUN_DIR / 'known_hosts'),
            '-o', 'LogLevel=ERROR',
            '-o', 'PreferredAuthentications=' + ('publickey' if key_path else 'password,keyboard-interactive'),
            '-o', 'NumberOfPasswordPrompts=1']
    if key_path:
        argv += ['-i', key_path, '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes']
    argv.append('%s@%s' % (str(cfg.get('ssh_user') or 'admin'), host))
    return argv


def ap_run(cfg, host, what):
    """One read-only command on one access point.

    `what` names an entry in AP_COMMANDS; nothing else can be run, so no
    caller - and nothing arriving over the network - can turn this into a way
    of changing a device."""
    if what not in AP_COMMANDS:
        raise ValueError('%r is not one of the commands this can run' % what)
    if not ssh_available():
        raise RuntimeError('the ssh client is not installed (dnf install openssh-clients)')
    trouble = None
    for command in AP_COMMANDS[what]:
        try:
            return _ap_run_one(cfg, host, command)
        except RuntimeError as e:
            # "not found" means this firmware spells it differently; anything
            # else is a real problem and there is no point trying the rest
            if 'not found' not in str(e).lower():
                raise
            trouble = e
    raise trouble or RuntimeError('none of the ways of asking worked')


def _ap_run_one(cfg, host, command):
    key_path = None
    folder = None
    try:
        if str(cfg.get('ssh_auth') or 'key') == 'key':
            private = cfg.get('ssh_key') or ''
            if not private:
                raise RuntimeError('no private key is stored yet')
            folder = tempfile.mkdtemp(prefix='zigmon-ssh-')
            key_path = os.path.join(folder, 'id')
            with open(key_path, 'w', encoding='utf-8') as f:
                f.write(private if private.endswith('\n') else private + '\n')
            os.chmod(key_path, 0o600)
            argv = _ssh_argv(cfg, host, key_path) + [command]
            run = subprocess.run(argv, capture_output=True, timeout=SSH_RUN_TIMEOUT)
            out, err, code = run.stdout, run.stderr, run.returncode
        else:
            out, err, code = _ssh_with_password(cfg, host, command)
        text = out.decode('utf-8', 'replace')
        if code != 0:
            why = err.decode('utf-8', 'replace').strip().splitlines()
            raise RuntimeError(why[-1][:160] if why else 'ssh exited %s' % code)
        return text
    except subprocess.TimeoutExpired:
        raise RuntimeError('%s did not answer within %d s' % (host, SSH_RUN_TIMEOUT))
    finally:
        if folder:
            shutil.rmtree(folder, ignore_errors=True)


def _ssh_with_password(cfg, host, command):
    """Password authentication without another package: ssh insists on a
    terminal for the prompt, so it is given one and answered."""
    import pty
    argv = _ssh_argv(cfg, host) + [command]
    password = (str(cfg.get('ssh_password') or '') + '\n').encode()
    pid, fd = pty.fork()
    if pid == 0:                                  # the child becomes ssh
        try:
            os.execvp(argv[0], argv)
        finally:
            os._exit(127)
    out = b''
    sent = False
    finished = False
    deadline = time.time() + SSH_RUN_TIMEOUT
    try:
        while time.time() < deadline and not finished:
            ready, _, _ = select.select([fd], [], [], 0.4)
            if ready:
                try:
                    chunk = os.read(fd, 65536)
                except OSError:
                    finished = True          # the far end closed: it is done
                    break
                if not chunk:
                    finished = True
                    break
                out += chunk
                if not sent and b'assword' in out[-200:]:
                    os.write(fd, password)
                    sent = True
                    out = b''                # the prompt itself is not output
            else:
                done, status = os.waitpid(pid, os.WNOHANG)
                if done:
                    finished = True
                    break
        if not finished:
            os.kill(pid, signal.SIGKILL)
            raise subprocess.TimeoutExpired(argv, SSH_RUN_TIMEOUT)
        try:
            _, status = os.waitpid(pid, 0)
            code = os.WEXITSTATUS(status)
        except OSError:
            code = 0
        text = out.decode('utf-8', 'replace')
        if code != 0 or 'denied' in text.lower():
            return b'', out or b'the access point refused those details', code or 255
        return out, b'', 0
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.waitpid(pid, os.WNOHANG)
        except OSError:
            pass


def parse_ap_info(text):
    """The `info` command's few lines."""
    out = {}
    for line in (text or '').splitlines():
        if ':' not in line:
            continue
        name, _, value = line.partition(':')
        key = name.strip().lower().replace(' ', '_')
        if key in ('model', 'version', 'mac_address', 'ip_address', 'hostname', 'uptime', 'status', 'ntp'):
            out[key] = value.strip()
    if out.get('uptime'):
        out['uptime'] = numeric(out['uptime'].split()[0])
    return out


def is_dfs_channel(band, channel):
    """Radar-shared channels. An access point told to leave one by a radar
    detection takes its network with it, which looks like a fault and is not."""
    if str(band) != '5' or not isinstance(channel, int):
        return False
    return 52 <= channel <= 144


def _sta_generation(sta):
    """A station's Wi-Fi generation. The dump flags what it can do rather than
    naming a protocol, so the best flag set wins."""
    for flag, name in (('is_11be', 'WiFi 7'), ('is_11ax', 'WiFi 6'), ('is_11ac', 'WiFi 5'),
                       ('is_11n', 'WiFi 4'), ('is_11g', 'WiFi 3'), ('is_11a', 'WiFi 2'),
                       ('is_11b', 'WiFi 1')):
        if sta.get(flag):
            return name
    return ''


def parse_mca_dump(text):
    """What an access point knows about itself and everyone on it.

    Field names here follow a real dump from a U7-Pro rather than what looks
    likely: the channel and its width sit on each wireless network, not on the
    radio; a station carries `signal` in dBm while `rssi` is its
    signal-to-noise margin; and the rates are in kilobits."""
    start = (text or '').find('{')
    if start < 0:
        raise ValueError('no JSON in the answer')
    try:
        data = json.loads(text[start:text.rfind('}') + 1])
    except ValueError as e:
        raise ValueError('the answer was not JSON: %s' % e)

    heat = {t.get('name'): numeric(t.get('value')) for t in (data.get('temperatures') or [])
            if numeric(t.get('value')) is not None}
    radios, neighbours, spectrum = {}, [], []
    for radio in data.get('radio_table') or []:
        name = radio.get('name')
        band = unifi_band(radio.get('radio'))
        radios[name] = {'band': band, 'name': name,
                        'chains': radio.get('nss'), 'max_power': radio.get('max_txpower'),
                        'min_power': radio.get('min_txpower'),
                        'dfs_capable': bool(radio.get('has_dfs')),
                        'temperature': heat.get(name),
                        'clients': 0, 'networks': 0}
        # what else is on the air around this point, and how busy each channel is
        for other in radio.get('scan_table') or []:
            neighbours.append({'ssid': other.get('essid') or '', 'bssid': other.get('bssid'),
                               'band': unifi_band(other.get('band'), other.get('channel')),
                               'channel': other.get('channel'), 'width': other.get('bw'),
                               'signal': numeric(other.get('signal')),
                               'security': other.get('security') or '',
                               'ubiquiti': bool(other.get('is_ubnt')),
                               'seen': numeric(other.get('age'))})
        for slot in radio.get('spectrum_table') or []:
            busy = numeric(slot.get('utilization'))
            if busy is None:
                continue
            spectrum.append({'band': band, 'channel': slot.get('channel'),
                             'width': slot.get('width'), 'busy': busy,
                             'interference': numeric(slot.get('interference')),
                             'others': slot.get('other_bss_count')})

    clients, networks = [], []
    for vap in data.get('vap_table') or []:
        radio = radios.get(vap.get('radio_name'))
        band = (radio or {}).get('band') or unifi_band(vap.get('radio'), vap.get('channel'))
        if radio is not None:
            # the channel and its width live on the networks, not the radio
            if vap.get('channel') is not None:
                radio['channel'] = vap['channel']
            if vap.get('bw') is not None:
                radio['width'] = vap['bw']
            if vap.get('tx_power') is not None:
                radio['power'] = vap['tx_power']
            radio['clients'] += int(vap.get('num_sta') or 0)
            if vap.get('up'):
                radio['networks'] += 1
        if vap.get('essid'):
            attempts = numeric(vap.get('tx_total'))
            networks.append({'name': vap['essid'], 'band': band, 'channel': vap.get('channel'),
                             'width': vap.get('bw'), 'clients': vap.get('num_sta'),
                             'retry_pct': (round(100.0 * (numeric(vap.get('tx_retries')) or 0) / attempts, 1)
                                           if attempts else None),
                             'rx_errors': numeric(vap.get('rx_errors')),
                             'dropped': (numeric(vap.get('tx_dropped')) or 0) + (numeric(vap.get('rx_dropped')) or 0),
                             'power': vap.get('tx_power'),
                             'guest': str(vap.get('usage') or '') == 'guest',
                             'experience': vap.get('satisfaction'),
                             'avg_signal': vap.get('avg_client_signal'),
                             'up': bool(vap.get('up'))})
        for sta in vap.get('sta_table') or []:
            rates = (numeric(sta.get('tx_rate')), numeric(sta.get('rx_rate')))
            clients.append({
                'mac': str(sta.get('mac') or '').lower(),
                'name': sta.get('hostname') or sta.get('1x_identity') or '',
                'ip': sta.get('ip') or '',
                'wired': False, 'kind': 'WIRELESS',
                'ssid': vap.get('essid'),
                'guest': str(vap.get('usage') or '') == 'guest',
                # signal is dBm; rssi is the margin above the noise floor
                'signal': numeric(sta.get('signal')),
                'noise': numeric(sta.get('noise')),
                'snr': numeric(sta.get('rssi')),
                'channel': vap.get('channel'), 'band': band, 'width': vap.get('bw'),
                'technology': _sta_generation(sta),
                'chains': ('%sx%s' % (sta.get('nss'), sta.get('nss'))) if sta.get('nss') else '',
                'experience': sta.get('satisfaction'),
                'vlan': sta.get('vlan_id'),
                # the dump counts in kilobits a second
                'tx_rate': rates[0] * 1000 if rates[0] else None,
                'rx_rate': rates[1] * 1000 if rates[1] else None,
                'tx_bytes': numeric(sta.get('tx_bytes')), 'rx_bytes': numeric(sta.get('rx_bytes')),
                'usage': (numeric(sta.get('tx_bytes')) or 0) + (numeric(sta.get('rx_bytes')) or 0),
                'retries': numeric(sta.get('tx_retries')),
                'retry_pct': (round(100.0 * (numeric(sta.get('tx_retries')) or 0)
                                    / numeric(sta.get('tx_total')), 1)
                              if numeric(sta.get('tx_total')) else None),
                'ccq': numeric(sta.get('ccq')),
                'tx_power': numeric(sta.get('tx_power')),
                'ipv6': [a for a in (sta.get('ipv6_addresses') or []) if not str(a).startswith('fe80')],
                'uptime': numeric(sta.get('uptime')),
                'idle': numeric(sta.get('idletime')),
                'power_save': bool(sta.get('state_pwrmgt')),
                'authorized': bool(sta.get('authorized', True)),
                'mlo': bool(sta.get('is_mlo')),
                'from_ap': True,
            })

    # What the point measures on its own way out: latency, jitter and loss to
    # the gateway and to whatever carries it. An access point that is fine in
    # itself but sits behind a bad wire looks the same from the controller.
    paths = []
    for target in ((data.get('pathmon') or {}).get('targets') or []):
        latency = numeric(target.get('latency_us_ema'))
        paths.append({
            'to': target.get('type'), 'address': target.get('resolved'),
            'family': target.get('family'),
            'reachable': str(target.get('state') or '') == 'reachable',
            'latency_ms': round(latency / 1000.0, 2) if latency is not None else None,
            'jitter_ms': round(numeric(target.get('jitter_us_ema')) / 1000.0, 2)
                         if numeric(target.get('jitter_us_ema')) is not None else None,
            # loss arrives per million
            'loss_pct': round((numeric(target.get('loss_pcm_ema')) or 0) / 10000.0, 3),
        })

    # what it is plugged into, as the switch on the other end introduces itself
    wired_to = []
    for seen_on in data.get('lldp_table') or []:
        addresses = [a for a in (seen_on.get('mgmt_ips') or []) if ':' not in a] or seen_on.get('mgmt_ips') or []
        entry = {'mac': seen_on.get('chassis_id'), 'address': addresses[0] if addresses else None,
                 'port': seen_on.get('port_id'), 'our_port': seen_on.get('local_port_name')}
        if entry not in wired_to:
            wired_to.append(entry)

    uplink = next((i for i in (data.get('if_table') or []) if i.get('name') == data.get('uplink')),
                  (data.get('if_table') or [{}])[0])
    stats = data.get('system-stats') or {}
    detail_stats = data.get('sys_stats') or {}
    load = detail_stats.get('loadavg_1')
    # how busy the channel each radio sits on is, and whether a quieter one is
    # going spare - the whole point of the spectrum scan
    for radio in radios.values():
        here = [x for x in spectrum if x['band'] == radio.get('band') and x['channel'] == radio.get('channel')]
        if here:
            radio['utilization'] = here[0]['busy']
            radio['interference'] = here[0]['interference']
            radio['neighbours'] = here[0].get('others')
        radio['dfs'] = is_dfs_channel(radio.get('band'), radio.get('channel'))
        options = sorted((x for x in spectrum if x['band'] == radio.get('band')),
                         key=lambda x: (x['busy'], x.get('others') or 0))
        quieter = [x for x in options
                   if x['channel'] != radio.get('channel')
                   and radio.get('utilization') is not None
                   and x['busy'] + 8 < radio['utilization']]
        radio['quieter'] = [{'channel': x['channel'], 'busy': x['busy'],
                             'dfs': is_dfs_channel(radio.get('band'), x['channel'])}
                            for x in quieter[:3]]
    return {
        'clients': clients,
        'radios': [r for r in radios.values() if r.get('band')],
        'networks': networks,
        'neighbours': sorted(neighbours, key=lambda n: -(n['signal'] or -999)),
        'spectrum': spectrum,
        'uptime': numeric(data.get('uptime')),
        'uptime_text': data.get('uptime_str'),
        'load': numeric(load),
        'cpu': numeric(stats.get('cpu')),
        'memory': numeric(stats.get('mem')),
        'load_5': numeric(detail_stats.get('loadavg_5')),
        'load_15': numeric(detail_stats.get('loadavg_15')),
        'memory_used': numeric(detail_stats.get('mem_used')),
        'memory_total': numeric(detail_stats.get('mem_total')),
        'temperature': max(heat.values()) if heat else None,
        'experience': data.get('satisfaction'),
        'version': data.get('version'),
        'model': data.get('model_display') or data.get('model'),
        'name': data.get('hostname'),
        'serial': data.get('serial'),
        'kernel': data.get('kernel_version'),
        'internet': data.get('internet'),
        'wired': {'name': uplink.get('name'), 'speed': uplink.get('speed'),
                  'duplex': uplink.get('full_duplex'), 'up': uplink.get('up'),
                  'rx_bytes': uplink.get('rx_bytes'), 'tx_bytes': uplink.get('tx_bytes'),
                  'rx_errors': uplink.get('rx_errors'), 'tx_errors': uplink.get('tx_errors'),
                  'rx_dropped': uplink.get('rx_dropped'), 'tx_dropped': uplink.get('tx_dropped')},
        'paths': paths,
        'wired_to': wired_to,
        # where it sends its reports, and what went wrong last time it could not
        'inform_url': data.get('inform_url'),
        'adopted': data.get('state') == 2,
        'last_trouble': next((e.get('last_error_str') for e in (data.get('last_error_conns') or [])
                              if e.get('last_error_str')), None),
        # the health of the thing itself
        'boot_reason': (data.get('boot') or {}).get('reason'),
        'ever_crashed': data.get('ever_crash'),
        'flash_wear': data.get('emmc_wear_level'),
        'architecture': data.get('architecture'),
        'board': data.get('bomrev'),
        'gateway': data.get('gateway_ip'),
        'netmask': data.get('netmask'),
        'ipv6': [a for a in (data.get('ipv6') or []) if not str(a).startswith('fe80')],
        'six_ghz': data.get('support_wifi6e'),
        'guest_kicks': data.get('guest_kicks'),
        'antenna': next((a.get('name') for a in (data.get('antenna_table') or []) if a.get('default')), None),
    }


def unifi_detail(cfg):
    """What the controller knows about itself, its access points and its SSIDs.

    The official Integration API grew: 10.6 lists the wifi broadcasts and the
    networks behind them as well as the devices and clients, and its device
    statistics live under /statistics/latest. Older revisions have neither, so
    the SSIDs fall back to whatever the clients are joined to. Signing in with
    a password reaches the older API, which is still the only one reporting a
    client's signal and channel."""
    host = str(cfg.get('host') or '').strip()
    if not host:
        raise ValueError('the controller needs an address')
    base = 'https://%s:%d' % (host, int(cfg.get('port') or 443))
    opener = _unifi_opener(bool(cfg.get('verify_ssl')))
    if not unifi_wants_legacy(cfg):
        out = _unifi_detail_official(cfg, base, opener)
        out['read_with'] = 'key'
        return out
    try:
        out = _unifi_detail_legacy(cfg, base, opener)
        out['read_with'] = 'signin'
        return out
    except Exception as e:
        if str(cfg.get('method')) != 'both' or not cfg.get('api_key'):
            raise
        log('wifi detail: signing in failed (%s), falling back to the API key' % e, 'warn')
        out = _unifi_detail_official(cfg, base, _unifi_opener(bool(cfg.get('verify_ssl'))))
        out['read_with'] = 'key'
        out['fell_back'] = str(e)
        return out


def _port_summary(device):
    """How many wired ports there are and how many are up, when the device
    itself was read; the device list only says the word "ports"."""
    interfaces = device.get('interfaces')
    if not isinstance(interfaces, dict):
        return None
    ports = [p for p in (interfaces.get('ports') or []) if isinstance(p, dict)]
    if not ports:
        return None
    states = [str(p.get('state') or '').upper() for p in ports]
    up = [x for x in states if x == 'UP']
    live = max((numeric(p.get('speedMbps')) or 0) for p in ports)
    most = max((numeric(p.get('maxSpeedMbps')) or 0) for p in ports)
    return {'count': len(ports),
            'up': len(up) if any(states) else None,   # None: it did not say
            'speed': int(live) if live else None,
            'max_speed': int(most) if most else None,
            'connector': next((p.get('connector') for p in ports if p.get('connector')), None),
            'poe': any((p.get('poe') or {}).get('enabled') for p in ports if isinstance(p.get('poe'), dict))}


def _wifi_standard(name):
    """802.11ax and the like, as the generation people actually say."""
    return {'802.11a': 'WiFi 2', '802.11b': 'WiFi 1', '802.11g': 'WiFi 3', '802.11n': 'WiFi 4',
            '802.11ac': 'WiFi 5', '802.11ax': 'WiFi 6', '802.11be': 'WiFi 7'}.get(str(name or ''), '')


def _is_access_point(device):
    """Whether the controller is describing a wireless access point.

    The feature list has been spelled several ways across firmware -
    ACCESS_POINT, accessPoint, sometimes an object keyed by feature - so the
    comparison ignores case and punctuation instead of matching one spelling.
    A device with no feature list at all is not ruled out."""
    features = device.get('features')
    if isinstance(features, dict):
        names = list(features.keys())
    elif isinstance(features, (list, tuple)):
        names = list(features)
    else:
        names = []
    flat = {re.sub(r'[^a-z0-9]', '', str(f).lower()) for f in names}
    if flat:
        return 'accesspoint' in flat or 'wireless' in flat or 'wifi' in flat
    kind = re.sub(r'[^a-z0-9]', '', str(device.get('type') or device.get('deviceType') or '').lower())
    if kind:
        return kind in ('uap', 'accesspoint', 'wireless')
    return True                          # nothing said otherwise


def _client_ssid(client):
    """The network a client is joined to, when the controller says.

    The official API's access object holds an authorisation type - GUEST or
    DEFAULT - and no network name, on any version. A key that looks like an
    SSID is still accepted in case a later release adds one, but the honest
    answer there is usually None, and None is shown as unknown rather than
    quietly counted as nothing."""
    access = client.get('access')
    if not isinstance(access, dict):
        return None
    for key, value in access.items():
        if 'ssid' in str(key).lower() and value:
            return str(value)
    return None


def _ap_from_official(device, stats):
    # Two places describe the radios: the device says which channel and how
    # wide, the statistics say how busy. They are joined on the frequency.
    configured = {}
    for radio in ((device.get('interfaces') or {}).get('radios') or []) \
            if isinstance(device.get('interfaces'), dict) else []:
        band = radio.get('frequencyGHz')
        configured[str(band)] = {
            'band': str(band) if band is not None else None,
            'channel': radio.get('channel'),
            'width': radio.get('channelWidthMHz'),
            'standard': _wifi_standard(radio.get('wlanStandard')),
        }
    measured = (stats.get('interfaces') or {}).get('radios') if isinstance(stats, dict) else None
    for radio in measured or (stats.get('radios') if isinstance(stats, dict) else None) or []:
        band = str(radio.get('frequencyGHz'))
        entry = configured.setdefault(band, {'band': band})
        entry['tx_retries'] = radio.get('txRetriesPct')
        if radio.get('numberOfConnectedClients') is not None:
            entry['clients'] = radio['numberOfConnectedClients']
    radios = [r for r in configured.values() if r.get('band')]
    uplink = (stats or {}).get('uplink') or {}
    return {
        'mac': str(device.get('macAddress') or '').lower(),
        'name': device.get('name') or device.get('model') or 'access point',
        'model': device.get('model') or '',
        'state': str(device.get('state') or '').lower(),
        'ip': device.get('ipAddress') or '',
        'version': device.get('firmwareVersion') or '',
        'uptime': (stats or {}).get('uptimeSec'),
        'cpu': ((stats or {}).get('cpuUtilizationPct')),
        'memory': ((stats or {}).get('memoryUtilizationPct')),
        'updatable': bool(device.get('firmwareUpdatable')),
        'ports': _port_summary(device),
        'clients': sum(r['clients'] for r in radios if isinstance(r.get('clients'), int)) or None,
        'tx_bytes': uplink.get('txRateBps'), 'rx_bytes': uplink.get('rxRateBps'),
        'uplink': _uplink_text(uplink),
        'load': (stats or {}).get('loadAverage1Min'),
        'heartbeat': (stats or {}).get('lastHeartbeatAt'),
        'supported': device.get('supported'),
        'radios': radios,
    }


def _uplink_text(uplink):
    """What is flowing through the wire behind the access point."""
    def rate(bps):
        bps = numeric(bps)
        if not bps:
            return None
        if bps >= 1000000:
            return ('%.1f' % (bps / 1000000.0)).rstrip('0').rstrip('.') + ' Mbps'
        return ('%.1f' % (bps / 1000.0)).rstrip('0').rstrip('.') + ' Kbps'
    down, up = rate(uplink.get('rxRateBps')), rate(uplink.get('txRateBps'))
    if not down and not up:
        return ''
    return '\u2193 %s  \u2191 %s' % (down or '0', up or '0')


def _unifi_detail_official(cfg, base, opener):
    headers = {'X-API-KEY': str(cfg.get('api_key') or ''), 'Accept': 'application/json'}
    prefix = site_id = None
    for candidate in UNIFI_PREFIXES:
        status, _, body = _unifi_get(opener, base + candidate + '/sites', headers)
        if status >= 400:
            continue
        sites = body.get('data') or []
        if sites:
            prefix, site_id = candidate, sites[0]['id']
        break
    if not prefix:
        raise RuntimeError('the integration API is not answering')
    out = {'controller': {}, 'aps': [], 'ssids': [], 'source': 'official'}
    status, _, body = _unifi_get(opener, base + prefix + '/info', headers)
    if status < 400 and isinstance(body, dict):
        out['controller'] = {'version': body.get('applicationVersion') or body.get('version') or '',
                             'name': body.get('name') or ''}
    status, _, body = _unifi_get(opener, '%s%s/sites/%s/devices?limit=200' % (base, prefix, site_id), headers)
    devices = (body.get('data') or []) if status < 400 else []
    if status >= 400:
        out['error'] = 'listing devices failed with HTTP %s' % status
    out['seen_devices'] = len(devices)
    wireless = [d for d in devices if _is_access_point(d)]
    # Rather than show nothing at all, fall back to everything the controller
    # listed: a name and an address still beat an empty tab.
    out['filtered'] = bool(devices) and not wireless
    for device in (wireless or devices):
        stats = {}
        did = device.get('id')
        if did:
            # the list is a summary: interfaces come back as the words "ports"
            # and "radios", and the real ones are on the device itself
            st, _, full = _unifi_get(opener, '%s%s/sites/%s/devices/%s' % (base, prefix, site_id, did), headers)
            if st < 400 and isinstance(full, dict):
                device = dict(device, **full)
            for suffix in ('/statistics/latest', '/statistics'):
                st, _, sb = _unifi_get(opener, '%s%s/sites/%s/devices/%s%s'
                                       % (base, prefix, site_id, did, suffix), headers)
                if st < 400 and isinstance(sb, dict):
                    stats = sb
                    break
        ap = _ap_from_official(device, stats)
        ap['id'] = device.get('id')
        out['aps'].append(ap)
    # Newer firmware does list the networks after all - 10.6 has both the
    # broadcasts and the VLANs behind them, which earlier revisions did not.
    status, _, body = _unifi_get(opener, '%s%s/sites/%s/networks?limit=100' % (base, prefix, site_id), headers)
    networks = {}
    for net in (body.get('data') or []) if status < 400 else []:
        networks[net.get('id')] = {'name': net.get('name') or '', 'vlan': net.get('vlanId'),
                                   'default': bool(net.get('default')), 'enabled': net.get('enabled')}
    out['networks'] = sorted(({k: v for k, v in n.items() if k != 'default'} for n in networks.values()),
                             key=lambda x: str(x['name']).lower())
    ap_names = {ap.get('id'): ap.get('name') for ap in out['aps']}
    status, _, body = _unifi_get(opener, '%s%s/sites/%s/wifi/broadcasts?limit=100' % (base, prefix, site_id), headers)
    default_net = next((v for v in networks.values() if v.get('default')), {})
    for wlan in (body.get('data') or []) if status < 400 else []:
        ref = wlan.get('network') or {}
        if str(ref.get('type') or '').upper() == 'NATIVE':
            net = default_net                # the site's own network, not named again
        else:
            net = networks.get(ref.get('networkId') or ref.get('id')) or {}
        bands = sorted((str(b) for b in (wlan.get('broadcastingFrequenciesGHz') or [])),
                       key=lambda b: numeric(b) or 0)
        out['ssids'].append({
            'name': wlan.get('name') or '',
            'enabled': bool(wlan.get('enabled', True)),
            'security': _wifi_security((wlan.get('securityConfiguration') or {}).get('type')),
            'band': '/'.join(bands),
            'network': net.get('name') or ref.get('name') or '',
            'vlan': net.get('vlan'),
            'guest': str((wlan.get('hotspotConfiguration') or {}).get('type') or '').upper() == 'GUEST'
                     or bool(wlan.get('hotspotConfiguration')),
            'hidden': bool(wlan.get('hideSsid')),
            'on_aps': _broadcasting_on(wlan.get('broadcastingDeviceFilter'), ap_names),
        })
    return out


def _broadcasting_on(filt, ap_names):
    """Which access points carry a network. A filter naming devices lists
    them; anything else means every point on the site."""
    if not isinstance(filt, dict):
        return ''
    if str(filt.get('type') or '').upper() != 'DEVICES':
        return 'all'
    ids = filt.get('deviceIds') or filt.get('devices') or []
    named = [ap_names.get(i) or str(i)[:8] for i in ids]
    return ', '.join(named) if named else 'all'


def _wifi_security(kind):
    """WPA2_WPA3_PERSONAL and friends, said the way the controller says them."""
    name = str(kind or '').upper()
    if not name:
        return ''
    text = name.replace('_PERSONAL', '').replace('_', '/')
    if name.endswith('_ENTERPRISE'):
        text = text.replace('/ENTERPRISE', '') + ' Enterprise'
    return 'Open' if text == 'OPEN' else text


def _unifi_detail_legacy(cfg, base, opener):
    site = str(cfg.get('site') or 'default')
    out = {'controller': {}, 'aps': [], 'ssids': [], 'source': 'legacy'}
    st, body = _unifi_signed_get(cfg, '/proxy/network/api/s/%s/stat/device' % site)
    for device in (body.get('data') or []) if st < 400 else []:
        if str(device.get('type') or '') != 'uap':
            continue
        widths = {}
        for radio in device.get('radio_table') or []:
            widths[radio.get('name')] = {'width': radio.get('ht'), 'power': radio.get('tx_power'),
                                         'radio': radio.get('radio')}
        radios = []
        for radio in device.get('radio_table_stats') or []:
            extra = widths.get(radio.get('name')) or {}
            radios.append({'band': unifi_band(radio.get('radio') or extra.get('radio'), radio.get('channel')),
                           'channel': radio.get('channel'),
                           'width': int(numeric(extra.get('width'))) if numeric(extra.get('width')) is not None else None,
                           'power': extra.get('power'),
                           'clients': radio.get('user-num_sta'),
                           'guests': radio.get('guest-num_sta'),
                           'tx_retries': radio.get('tx_retries_pct'),
                           'utilization': radio.get('cu_total'),
                           'interference': radio.get('cu_self_rx')})
        sysstats = device.get('system-stats') or {}
        uplink = device.get('uplink') or {}
        out['aps'].append({
            'mac': str(device.get('mac') or '').lower(),
            'name': device.get('name') or device.get('model') or 'access point',
            'model': device.get('model') or '', 'ip': device.get('ip') or '',
            'state': 'online' if device.get('state') == 1 else 'offline',
            'version': device.get('version') or '',
            'uptime': device.get('uptime'),
            'cpu': numeric(sysstats.get('cpu')), 'memory': numeric(sysstats.get('mem')),
            'clients': device.get('num_sta'), 'guests': device.get('guest-num_sta'),
            'tx_bytes': device.get('tx_bytes'), 'rx_bytes': device.get('rx_bytes'),
            'experience': device.get('satisfaction'),
            'uplink': (uplink.get('type') or '') + (
                ' %s Mbps' % uplink.get('speed') if uplink.get('speed') else ''),
            'radios': radios,
        })
    networks = {}
    st, body = _unifi_signed_get(cfg, '/proxy/network/api/s/%s/list/networkconf' % site)
    for net in (body.get('data') or []) if st < 400 else []:
        networks[net.get('_id')] = {'name': net.get('name') or '', 'vlan': net.get('vlan')}
    out['networks'] = sorted(({k: v for k, v in n.items() if k != 'default'} for n in networks.values()),
                         key=lambda x: str(x['name']).lower())
    st, body = _unifi_signed_get(cfg, '/proxy/network/api/s/%s/list/wlanconf' % site)
    for wlan in (body.get('data') or []) if st < 400 else []:
        net = networks.get(wlan.get('networkconf_id')) or {}
        raw = str(wlan.get('security') or '').lower()
        security = {'wpapsk': 'WPA2', 'wpaeap': 'WPA2 Enterprise', 'wep': 'WEP',
                    'open': 'Open', 'none': 'Open'}.get(raw, raw.upper())
        if wlan.get('wpa3_support') or str(wlan.get('wpa_mode') or '').lower() == 'wpa3':
            security = security.replace('WPA2', 'WPA2/WPA3')
        if str(wlan.get('wpa_mode') or '').lower() == 'wpa3' and 'WPA2' not in security:
            security = 'WPA3'
        bands = []
        for key, label in (('wlan_band_2g', '2.4'), ('wlan_band_5g', '5'), ('wlan_band_6g', '6')):
            if wlan.get(key):
                bands.append(label)
        if not bands:
            band = str(wlan.get('wlan_band') or 'both')
            bands = ['2.4', '5'] if band == 'both' else [band.replace('g', '')]
        out['ssids'].append({'name': wlan.get('name') or '', 'enabled': bool(wlan.get('enabled', True)),
                             'security': security, 'hidden': bool(wlan.get('hide_ssid')),
                             'guest': bool(wlan.get('is_guest')), 'band': '/'.join(bands),
                             'network': net.get('name') or '', 'vlan': net.get('vlan')})
    st, body = _unifi_signed_get(cfg, '/proxy/network/api/s/%s/stat/health' % site)
    for sub in (body.get('data') or []) if st < 400 else []:
        if sub.get('subsystem') == 'wlan':
            out['controller']['wlan_status'] = sub.get('status')
            out['controller']['wlan_users'] = sub.get('num_user')
            out['controller']['wlan_guests'] = sub.get('num_guest')
    return out


def _unifi_official(cfg, base, opener):
    key = str(cfg.get('api_key') or '')
    if not key:
        raise ValueError('the official API needs an API key')
    headers = {'X-API-KEY': key, 'Accept': 'application/json'}
    prefix = sites = None
    last = ''
    for candidate in UNIFI_PREFIXES:      # the path changed between firmware revisions
        status, _, body = _unifi_get(opener, base + candidate + '/sites', headers)
        if status == 404:
            last = 'HTTP 404'
            continue
        if status in (401, 403):
            raise RuntimeError('the controller refused the API key')
        if status >= 400:
            last = 'HTTP %s' % status
            continue
        prefix, sites = candidate, body.get('data') or []
        break
    if prefix is None:
        raise RuntimeError('the integration API is not answering (%s). On a UniFi OS Server the '
                           'port is usually 11443, on a console 443.' % (last or 'no reply'))
    if not sites:
        raise RuntimeError('the controller returned no site')
    site_id = sites[0]['id']
    out, offset = [], 0
    while True:
        status, _, body = _unifi_get(
            opener, '%s%s/sites/%s/clients?limit=200&offset=%d' % (base, prefix, site_id, offset), headers)
        if status >= 400:
            raise RuntimeError('reading clients failed with HTTP %s' % status)
        page = body.get('data') or []
        out.extend(page)
        offset += len(page)
        if not page or offset >= int(body.get('totalCount') or offset):
            break
    return [{
        'name': c.get('name') or c.get('hostname') or '',
        'mac': str(c.get('macAddress') or '').lower(),
        'ip': c.get('ipAddress') or '',
        'wired': str(c.get('type') or '').upper() == 'WIRED',
        'kind': str(c.get('type') or '').upper(),          # WIRED, WIRELESS, VPN, TELEPORT
        'ssid': _client_ssid(c),
        'guest': str((c.get('access') or {}).get('type') or '').upper() == 'GUEST'
                 if isinstance(c.get('access'), dict) else False,
        'since': c.get('connectedAt'),
        # the newer firmware names the access point by id rather than by MAC
        'uplink_id': c.get('uplinkDeviceId'),
        'signal': None, 'ap': None,
    } for c in out if c.get('macAddress')]


def _unifi_legacy(cfg, base, opener):
    """The clients, as the controller's own pages see them.

    Its interface asks v2 for `clients/active`, which carries the signal, the
    channel, the rates and the name of the access point already resolved. The
    older `stat/sta` is the fallback for controllers without it - the fields
    overlap enough that one mapping reads both."""
    site = str(cfg.get('site') or 'default')
    raw, status = [], None
    for path in ('/proxy/network/v2/api/site/%s/clients/active?includeTrafficUsage=true&includeUnifiDevices=true' % site,
                 '/proxy/network/api/s/%s/stat/sta' % site):
        status, body = _unifi_signed_get(cfg, path)
        if status >= 400:
            continue
        rows = body if isinstance(body, list) else (body.get('data') or [])
        if rows or status < 400:
            raw = rows
            break
    if status is not None and status >= 400 and not raw:
        raise RuntimeError('reading clients failed with HTTP %s' % status)
    return [{
        'name': c.get('display_name') or c.get('name') or c.get('hostname') or c.get('oui') or '',
        'mac': str(c.get('mac') or '').lower(),
        'ip': c.get('ip') or '',
        'wired': bool(c.get('is_wired')),
        'kind': 'WIRED' if c.get('is_wired') else 'WIRELESS',
        'ssid': c.get('essid'),
        'guest': bool(c.get('is_guest')),
        'signal': c.get('signal'), 'noise': c.get('noise'),
        'ap': str(c.get('ap_mac') or c.get('uplink_mac') or c.get('last_uplink_mac') or '').lower(),
        'ap_name': c.get('last_uplink_name') or None,
        'vlan': c.get('vlan'),
        'channel': c.get('channel'),
        'band': unifi_band(c.get('radio'), c.get('channel')),
        'width': int(numeric(c.get('channel_width'))) if numeric(c.get('channel_width')) is not None else None,
        'technology': unifi_generation(c.get('radio_proto')),
        'chains': ('%sx%s' % (c.get('nss'), c.get('nss'))) if c.get('nss') else '',
        'experience': c.get('satisfaction') if c.get('satisfaction') is not None
                      else c.get('wifi_experience_score'),
        'retries': c.get('wifi_tx_retries_percentage'),
        'mimo': c.get('mimo'),
        'status': c.get('status'),
        'tx_rate': c.get('tx_rate'), 'rx_rate': c.get('rx_rate'),
        'down_bps': numeric(c.get('rx_bytes-r')), 'up_bps': numeric(c.get('tx_bytes-r')),
        'tx_bytes': c.get('tx_bytes'), 'rx_bytes': c.get('rx_bytes'),
        'usage': numeric(c.get('usage_bytes')) if c.get('usage_bytes') is not None
                 else (numeric(c.get('tx_bytes')) or 0) + (numeric(c.get('rx_bytes')) or 0),
        'uptime': c.get('uptime'), 'since': c.get('assoc_time'),
        'satisfaction': c.get('satisfaction'),
        'vendor': c.get('oui'), 'network': c.get('network'),
        'powersave': c.get('powersave_enabled'),
    } for c in raw if c.get('mac')]


# Readings worth no history: the hardware's own identity and sizes, counters'
# reset stamps, per-minute arrays, clocks and revision numbers. A gateway
# hands all of it over on every poll, and stored every thirty seconds it is
# what fills a database - without ever telling anyone anything.
NOISE_KEY = re.compile(
    r'(^|\.)('
    r'id|source|tag|mac|uptime_ts|unixtime|time|last_sync_ts|'
    r'hw_version|zb_version|fw_id|u_device|coord_mode|wifi_mode|zb_type|zb_channel|'
    r'fs_size|fs_total|ram_size|ram_total|psram_total|psram_size|zb_flash_size|zb_ram_size|'
    r'cfg_rev|kvs_rev|schedule_rev|webhook_rev|slot|gen'
    r')$'
    r'|_rst_ts$|\.minute_ts$|\.by_minute|(^|\.)ble\.[a-z_]*enabled$')

GATEWAY_ANCHOR_S = 900          # a flat reading still gets a point this often


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
# Readings are stored as (device, key, value) rows rather than in fixed
# columns, because what one sensor reports is not what the next one does.
# Full resolution is kept for a fortnight, hourly averages for two years; the
# latest complete payload of every device sits in `snapshots`.
SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    id          TEXT PRIMARY KEY,       -- IEEE address, or shelly:<name>
    name        TEXT NOT NULL,          -- friendly name (the MQTT topic)
    source      TEXT NOT NULL,          -- zigbee | shelly | mqtt
    kind        TEXT,                   -- EndDevice | Router | Coordinator | wifi
    model       TEXT,
    vendor      TEXT,
    description TEXT,
    exposes     TEXT,                   -- JSON: key -> {label, unit, description}
    first_seen  INTEGER,
    last_seen   INTEGER,
    removed     INTEGER NOT NULL DEFAULT 0,
    alias       TEXT                    -- a display name set on the dashboard
);

CREATE TABLE IF NOT EXISTS samples (
    ts      INTEGER NOT NULL,
    device  TEXT    NOT NULL,
    key     TEXT    NOT NULL,
    value   REAL,
    PRIMARY KEY (device, key, ts)
);
CREATE INDEX IF NOT EXISTS samples_ts ON samples (ts);

CREATE TABLE IF NOT EXISTS samples_hourly (
    ts      INTEGER NOT NULL,
    device  TEXT    NOT NULL,
    key     TEXT    NOT NULL,
    n       INTEGER,
    avg     REAL,
    min     REAL,
    max     REAL,
    PRIMARY KEY (device, key, ts)
);
CREATE INDEX IF NOT EXISTS samples_hourly_ts ON samples_hourly (ts);

CREATE TABLE IF NOT EXISTS snapshots (
    device  TEXT PRIMARY KEY,
    ts      INTEGER NOT NULL,
    payload TEXT NOT NULL,
    availability TEXT
);

CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      INTEGER NOT NULL,
    device  TEXT,
    kind    TEXT NOT NULL,
    level   TEXT,
    detail  TEXT
);
CREATE INDEX IF NOT EXISTS events_ts ON events (ts);
CREATE INDEX IF NOT EXISTS events_device_kind_ts ON events (device, kind, ts);

CREATE TABLE IF NOT EXISTS meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);
"""


class StorageError(Exception):
    pass


class Storage(object):
    def __init__(self, path=None):
        self.path = Path(path) if path else db_path()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        try:
            self.db = sqlite3.connect(str(self.path), check_same_thread=False,
                                      timeout=15, isolation_level=None)
        except sqlite3.OperationalError as e:
            raise StorageError('cannot open %s: %s' % (self.path, e))
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._meta_cache = {}
        # Recording must never make a person wait. Writes from the message
        # path are queued and drained by one background thread, so a VACUUM
        # or an online backup - which hold the database for as long as they
        # take - can never stall a button press or the MQTT client thread.
        self._snap_cache = {}     # device -> (payload, availability), the merge source of truth
        self._dev_cache = {}      # device id -> row (or None when there is no such device)
        self._dev_list = None     # the whole list, rebuilt after any change
        self._actions_cache = {}  # device id -> the actions it has reported
        self._last_action = {}    # device id -> its most recent action
        self._meta_raw = {}       # meta key -> its stored text
        self._stats_cache = None  # (when, row counts) for the header
        self._wq = collections.deque()
        self._wq_wake = threading.Event()
        self._wq_idle = threading.Event()
        self._wq_idle.set()
        self._wq_thread = threading.Thread(target=self._writer_loop, name='db-writer', daemon=True)
        self._wq_thread.start()
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=NORMAL')
        self.db.executescript(SCHEMA)
        try:
            self.db.execute('ALTER TABLE devices ADD COLUMN alias TEXT')
        except sqlite3.OperationalError:
            pass                        # already there
        self.last_sample = {}     # (device, key) -> ts of the last row written

    # -- devices --------------------------------------------------------------
    def upsert_device(self, dev):
        now = int(time.time())
        with self.lock:
            row = self.db.execute('SELECT * FROM devices WHERE id=?', (dev['id'],)).fetchone()
            if row is not None and not row['removed'] and self._same_device(row, dev):
                return 'known'               # nothing to write, nothing to forget
            self._forget_device(dev['id'])   # every path below changes the row
            if row is None:
                self.db.execute(
                    'INSERT INTO devices (id,name,source,kind,model,vendor,description,'
                    'exposes,first_seen,last_seen,removed) VALUES (?,?,?,?,?,?,?,?,?,?,0)',
                    (dev['id'], dev['name'], dev['source'], dev.get('kind'), dev.get('model'),
                     dev.get('vendor'), dev.get('description'),
                     json.dumps(dev.get('exposes') or {}), now, dev.get('last_seen')))
                return 'new'
            changed = 'renamed' if row['name'] != dev['name'] else None
            self.db.execute(
                'UPDATE devices SET name=?,source=?,kind=COALESCE(?,kind),model=COALESCE(?,model),'
                'vendor=COALESCE(?,vendor),description=COALESCE(?,description),'
                'exposes=CASE WHEN ? THEN ? ELSE exposes END,removed=0 WHERE id=?',
                (dev['name'], dev['source'], dev.get('kind'), dev.get('model'), dev.get('vendor'),
                 dev.get('description'), 1 if dev.get('exposes') else 0,
                 json.dumps(dev.get('exposes') or {}), dev['id']))
            if changed:
                return changed
            return 'known'

    def mark_removed(self, device_id):
        with self.lock:
            self.db.execute('UPDATE devices SET removed=1 WHERE id=?', (device_id,))
        self._forget_device(device_id)

    def touch_device(self, device_id, ts):
        self._defer(self._write_touch, device_id, ts)

    def _write_touch(self, device_id, ts):
        with self.lock:
            self.db.execute('UPDATE devices SET last_seen=? WHERE id=?', (ts, device_id))
        row = self._dev_cache.get(device_id)
        if row is not None:
            row['last_seen'] = ts        # keep it current without another read
        for d in (self._dev_list or []):
            if d['id'] == device_id:
                d['last_seen'] = ts
                break

    def devices(self, include_removed=False):
        """The whole list, in memory. The dashboard rebuilds its status from
        this on every refresh, so it must not queue behind a long write."""
        if self._dev_list is None:
            with self.lock:
                rows = self.db.execute(
                    'SELECT * FROM devices ORDER BY name COLLATE NOCASE').fetchall()
            listed = []
            for r in rows:
                d = dict(r)
                try:
                    d['exposes'] = json.loads(d.get('exposes') or '{}')
                except ValueError:
                    d['exposes'] = {}
                listed.append(d)
                self._dev_cache[d['id']] = d
            self._dev_list = listed
        return [dict(d) for d in self._dev_list
                if include_removed or not d.get('removed')]

    def device(self, device_id):
        """Kept in memory: this is read on the path a person is waiting on
        (a switch resolves its target here), and the row changes rarely."""
        if device_id in self._dev_cache:
            row = self._dev_cache[device_id]
            return dict(row) if row is not None else None
        with self.lock:
            r = self.db.execute('SELECT * FROM devices WHERE id=?', (device_id,)).fetchone()
        if r is None:
            self._dev_cache[device_id] = None
            return None
        d = dict(r)
        try:
            d['exposes'] = json.loads(d.get('exposes') or '{}')
        except ValueError:
            d['exposes'] = {}
        self._dev_cache[device_id] = d
        return dict(d)

    @staticmethod
    def _same_device(row, dev):
        """Would the update write anything new? A poll re-states the same
        description every round; rewriting it would cost a lock and throw the
        cached list away for nothing."""
        if row['name'] != dev['name'] or row['source'] != dev['source']:
            return False
        for field in ('kind', 'model', 'vendor', 'description'):
            value = dev.get(field)
            if value is not None and row[field] != value:
                return False
        exposes = dev.get('exposes')
        if exposes and json.dumps(exposes) != (row['exposes'] or ''):
            return False
        return True

    def trim_wal(self):
        """Fold the write-ahead log back into the file. SQLite reuses it in
        place, so after a VACUUM it can sit at the size of the whole database
        for good - and it counts towards what the disk, and the dashboard,
        report."""
        if not self.lock.acquire(timeout=0.05):
            return False
        try:
            self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        except sqlite3.OperationalError:
            return False
        finally:
            self.lock.release()
        self._stats_cache = None
        return True

    def _warm_actions(self):
        """Which actions each device has sent, for every device at once."""
        try:
            with self.lock:
                rows = self.db.execute(
                    "SELECT device, detail, MAX(ts) AS ts FROM events WHERE kind='action' "
                    "AND device IS NOT NULL GROUP BY device, detail ORDER BY ts DESC").fetchall()
        except Exception:
            return
        # every known device gets an entry, including the ones with nothing to
        # show: a missing entry means "go and look", which is the whole point
        seen = {d['id']: [] for d in (self._dev_list or [])}
        latest = {d['id']: None for d in (self._dev_list or [])}
        for r in rows:
            if not r['detail']:
                continue
            seen.setdefault(r['device'], []).append(r['detail'])
            if not latest.get(r['device']):
                latest[r['device']] = {'action': r['detail'], 'ts': r['ts']}
        self._actions_cache = seen
        self._last_action = latest

    def _warm_meta(self):
        """Read every setting row in one go, so nothing has to fetch one later
        at a bad moment."""
        try:
            with self.lock:
                rows = self.db.execute('SELECT key, value FROM meta').fetchall()
            # update, never replace: keys we already know are absent stay
            # remembered as absent, so nothing goes back to the database for them
            self._meta_raw.update({r['key']: r['value'] for r in rows})
        except Exception:
            pass

    def _forget_device(self, device_id=None):
        self._dev_list = None
        if device_id is None:
            self._dev_cache.clear()
        else:
            self._dev_cache.pop(device_id, None)

    def resolve(self, name_or_id):
        """Accept an IEEE address, an id, a friendly name or a dashboard alias.
        Answered from the device list already in memory: this sits on the
        dashboard path, where waiting on the database is what a long write
        turns into a stall."""
        key = str(name_or_id or '')
        if not key:
            return None
        if self._dev_list is None:
            self.devices(include_removed=True)      # fills the list once
        listed = self._dev_list or []
        for d in listed:
            if d['id'] == key:
                return d['id']
        low = key.lower()
        for d in listed:
            if (d['name'] or '').lower() == low or (d['alias'] or '').lower() == low:
                return d['id']
        return None

    def set_alias(self, device_id, alias):
        with self.lock:
            self.db.execute('UPDATE devices SET alias=? WHERE id=?', (alias or None, device_id))
        self._forget_device(device_id)

    # -- readings -------------------------------------------------------------
    def store_sample(self, device_id, ts, values):
        self._defer(self._write_sample, device_id, ts, dict(values or {}))

    def _write_sample(self, device_id, ts, values):
        """values: {key: float}. Honour sample_interval by replacing the row."""
        gap = int(CONFIG.get('sample_interval') or 0)
        with self.lock:
            for key, value in values.items():
                prev = self.last_sample.get((device_id, key))
                if prev is None:
                    r = self.db.execute('SELECT MAX(ts) AS ts FROM samples WHERE device=? AND key=?',
                                        (device_id, key)).fetchone()
                    prev = r['ts'] if r and r['ts'] is not None else 0
                if gap and prev and ts - prev < gap and prev != ts:
                    self.db.execute('UPDATE samples SET value=? WHERE device=? AND key=? AND ts=?',
                                    (value, device_id, key, prev))
                    continue
                self.db.execute('INSERT OR REPLACE INTO samples (ts,device,key,value) VALUES (?,?,?,?)',
                                (ts, device_id, key, value))
                self.last_sample[(device_id, key)] = ts

    def store_snapshot(self, device_id, ts, payload, availability=None):
        """Merge in memory and hand the result straight back - the dashboard
        shows this immediately - then write the row on the writer thread."""
        cached = self._snap_cache.get(device_id)
        if cached is None:
            cached = self._read_snapshot(device_id)
        merged = dict(cached[0])
        merged.update(payload or {})
        if availability is None:
            availability = cached[1]
        self._snap_cache[device_id] = (merged, availability)
        self._defer(self._write_snapshot, device_id, ts, merged, availability)
        return merged

    def _read_snapshot(self, device_id):
        with self.lock:
            row = self.db.execute('SELECT payload, availability FROM snapshots WHERE device=?',
                                  (device_id,)).fetchone()
        payload, availability = {}, None
        if row:
            try:
                payload = json.loads(row['payload'])
            except ValueError:
                payload = {}
            availability = row['availability']
        self._snap_cache[device_id] = (payload, availability)
        return self._snap_cache[device_id]

    def _write_snapshot(self, device_id, ts, merged, availability=None):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO snapshots (device,ts,payload,availability) '
                            'VALUES (?,?,?,?)', (device_id, ts, json.dumps(merged), availability))
        return merged

    def snapshots(self):
        with self.lock:
            rows = self.db.execute('SELECT * FROM snapshots').fetchall()
        out = {}
        for r in rows:
            try:
                payload = json.loads(r['payload'])
            except ValueError:
                payload = {}
            out[r['device']] = {'ts': r['ts'], 'payload': payload,
                                'availability': r['availability']}
            self._snap_cache[r['device']] = (payload, r['availability'])
        return out

    def keys_for(self, device_id):
        with self.lock:
            a = self.db.execute('SELECT DISTINCT key FROM samples WHERE device=?', (device_id,)).fetchall()
            b = self.db.execute('SELECT DISTINCT key FROM samples_hourly WHERE device=?',
                                (device_id,)).fetchall()
        return sorted({r['key'] for r in a} | {r['key'] for r in b})

    def history(self, device_id, keys, seconds, points=600):
        """Rows of {ts, key1, key2, ...} mixing hourly data for the old part."""
        now = int(time.time())
        since = now - seconds
        full_from = now - int(CONFIG.get('retain_full_days', 14)) * 86400
        # Thin inside SQLite, not in Python: a 7-day chart used to pull every
        # 30 s row (20k per key) through Python just to keep 400 of them, which
        # held the store lock for ~40 ms per device - and the Overview reloads
        # every chart on every live update. One real row per time bucket
        # (the last one in it, so the newest point is always kept) is the
        # same picture for a fraction of the work.
        bucket = max(1, seconds // max(1, int(points or 600)))
        rows = {}
        with self.lock:
            for key in keys:
                if since < full_from:
                    for r in self.db.execute(
                            'SELECT MAX(ts) AS ts, avg AS value, min, max FROM samples_hourly '
                            'WHERE device=? AND key=? AND ts>=? AND ts<? GROUP BY ts/? ORDER BY ts',
                            (device_id, key, since, full_from, max(3600, bucket))):
                        rows.setdefault(r['ts'], {'ts': r['ts']})[key] = r['value']
                        rows[r['ts']][key + '_min'] = r['min']
                        rows[r['ts']][key + '_max'] = r['max']
                for r in self.db.execute(
                        'SELECT MAX(ts) AS ts, value FROM samples WHERE device=? AND key=? AND ts>=? '
                        'GROUP BY ts/? ORDER BY ts',
                        (device_id, key, max(since, full_from), bucket)):
                    rows.setdefault(r['ts'], {'ts': r['ts']})[key] = r['value']
        ordered = [rows[t] for t in sorted(rows)]
        return thin(ordered, points)

    def history_many(self, wanted, seconds, points=400):
        """[(device_id, [keys]), ...] -> {device_id: rows}. One call, one
        lock, one round trip for the Overview charts instead of one request
        per device."""
        return {device_id: self.history(device_id, keys, seconds, points) for device_id, keys in wanted}

    # -- events ---------------------------------------------------------------
    on_event = None

    def add_event(self, kind, detail='', level='info', device=None, ts=None):
        if callable(self.on_event):
            try:
                self.on_event(kind, detail, level, device)
            except Exception:
                pass
        if kind == 'action' and device and detail:
            known = self._actions_cache.get(device)
            if known is not None and detail not in known:
                self._actions_cache[device] = [detail] + known    # most recent first
            self._last_action[device] = {'action': detail, 'ts': ts or int(time.time())}
        self._defer(self._write_event, kind, detail, level, device, ts or int(time.time()))

    def _write_event(self, kind, detail, level, device, ts):
        with self.lock:
            self.db.execute('INSERT INTO events (ts,device,kind,level,detail) VALUES (?,?,?,?,?)',
                            (ts, device, kind, level, detail))

    def events(self, limit=100, device=None):
        with self.lock:
            if device:
                rows = self.db.execute('SELECT * FROM events WHERE device=? ORDER BY ts DESC, id DESC '
                                       'LIMIT ?', (device, limit)).fetchall()
            else:
                rows = self.db.execute('SELECT * FROM events ORDER BY ts DESC, id DESC LIMIT ?',
                                       (limit,)).fetchall()
        return [dict(r) for r in rows]

    # -- maintenance: check, optimise, back up, restore -------------------------
    _latency_cache = (0.0, None)

    def latency(self):
        """Round-trip of a trivial read and a trivial write, in milliseconds.
        Measured at most every 15 s: the probe is a real commit under the
        store lock, and /api/health is polled on every refresh of the
        Control tab - nothing that automations should ever queue behind."""
        at, cached = self._latency_cache
        if cached is not None and time.time() - at < 15:
            return cached
        if not self.lock.acquire(timeout=0.05):
            # busy with something long: the last figures are far better than
            # holding up the page that asked for them
            return cached if cached is not None else {'read_ms': None, 'write_ms': None}
        try:
            t0 = time.perf_counter()
            self.db.execute('SELECT value FROM meta WHERE key=?', ('schema',)).fetchone()
            read_ms = (time.perf_counter() - t0) * 1000
            t0 = time.perf_counter()
            self.db.execute('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)', ('_latency_probe', str(int(time.time()))))
            self.db.commit()
            write_ms = (time.perf_counter() - t0) * 1000
        finally:
            self.lock.release()
        result = {'read_ms': round(read_ms, 2), 'write_ms': round(write_ms, 2)}
        self._latency_cache = (time.time(), result)
        return result

    def integrity_check(self):
        with self.lock:
            rows = self.db.execute('PRAGMA integrity_check').fetchall()
            fk = self.db.execute('PRAGMA foreign_key_check').fetchall()
        lines = [r[0] for r in rows]
        ok = lines == ['ok'] and not fk
        return {'ok': ok, 'lines': lines[:20], 'foreign_key_problems': len(fk)}

    def stale_data(self):
        """What is recorded for devices the dashboard no longer shows: ones
        marked removed, and any left behind with no device row at all. A
        rename leaves the old name's history here, and it adds up."""
        with self.lock:
            known = {r['id']: dict(r) for r in
                     self.db.execute('SELECT id, name, alias, removed, last_seen FROM devices')}
            counts = {}
            for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                for r in self.db.execute(
                        'SELECT device, COUNT(*) n FROM %s WHERE device IS NOT NULL GROUP BY device' % table):
                    if r['device'] in known and not known[r['device']]['removed']:
                        continue
                    entry = counts.setdefault(r['device'], {'device': r['device'], 'rows': 0})
                    entry[table] = r['n']
                    entry['rows'] += r['n']
        out = []
        for device_id, entry in counts.items():
            row = known.get(device_id)
            entry['name'] = (row.get('alias') or row.get('name')) if row else device_id
            entry['reason'] = 'removed' if row else 'no device record'
            entry['last_seen'] = row.get('last_seen') if row else None
            out.append(entry)
        out.sort(key=lambda x: -x['rows'])
        return {'devices': out, 'rows': sum(x['rows'] for x in out)}

    def drop_stale(self, only=None):
        """Erase what stale_data() found, or one device from it."""
        found = self.stale_data()['devices']
        wanted = [x for x in found if only is None or x['device'] == only]
        removed = 0
        with self.lock:
            for entry in wanted:
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    cur = self.db.execute('DELETE FROM %s WHERE device=?' % table, (entry['device'],))
                    removed += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
                self.db.execute('DELETE FROM devices WHERE id=? AND removed=1', (entry['device'],))
            self.db.commit()
        self._forget_device()
        self._snap_cache.clear()
        self._actions_cache.clear()
        self._last_action.clear()
        self.last_sample.clear()
        self._meta_raw.clear()
        self.devices(include_removed=True)
        self._warm_meta()
        self._warm_actions()
        self._stats_cache = None
        before = self.stats().get('bytes') or 0
        try:
            self.db.execute('VACUUM')
            self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        except sqlite3.OperationalError:
            pass
        self._stats_cache = None
        return {'devices': len(wanted), 'rows': removed,
                'before_bytes': before, 'after_bytes': self.stats().get('bytes') or 0}

    def prune(self, apply=False):
        """Throw away readings that were never worth keeping: the hardware's
        bookkeeping keys, and gateway values written again unchanged. Counts
        what it would remove unless asked to actually do it."""
        noise = flat = 0
        with self.lock:
            for table in ('samples', 'samples_hourly'):
                for row in self.db.execute('SELECT DISTINCT key FROM %s' % table).fetchall():
                    key = row[0] or ''
                    if not NOISE_KEY.search(key):
                        continue
                    noise += self.db.execute('SELECT COUNT(*) FROM %s WHERE key=?' % table,
                                             (key,)).fetchone()[0]
                    if apply:
                        self.db.execute('DELETE FROM %s WHERE key=?' % table, (key,))
            # the same value stored over and over by a gateway poll
            pairs = self.db.execute(
                "SELECT DISTINCT device, key FROM samples WHERE key LIKE 'gw.%'").fetchall()
            for device, key in [(r[0], r[1]) for r in pairs]:
                if NOISE_KEY.search(key):
                    continue
                drop, last = [], None
                for r in self.db.execute(
                        'SELECT ts, value FROM samples WHERE device=? AND key=? ORDER BY ts',
                        (device, key)):
                    if last is not None and r[1] == last[0] and r[0] - last[1] < GATEWAY_ANCHOR_S:
                        drop.append(r[0])
                    else:
                        last = (r[1], r[0])
                flat += len(drop)
                if apply and drop:
                    for i in range(0, len(drop), 400):
                        chunk = drop[i:i + 400]
                        self.db.execute(
                            'DELETE FROM samples WHERE device=? AND key=? AND ts IN (%s)'
                            % ','.join('?' * len(chunk)), [device, key] + chunk)
            if apply:
                self.db.commit()
        before = self.stats().get('bytes') or 0
        if apply:
            self._stats_cache = None
            try:
                self.db.execute('VACUUM')
                # fold the write-ahead log back in, or the file still looks
                # every bit as big as it was
                self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            except sqlite3.OperationalError:
                pass
        after = (self.stats().get('bytes') or 0) if apply else before
        return {'bookkeeping_rows': noise, 'repeated_rows': flat, 'applied': bool(apply),
                'before_bytes': before, 'after_bytes': after}

    def optimize(self):
        self.flush()
        before = db_path().stat().st_size if db_path().exists() else 0
        t0 = time.time()
        with self.lock:
            self.db.execute('PRAGMA optimize')
            self.db.execute('ANALYZE')
            self.db.commit()
            self.db.execute('VACUUM')
            self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        self._stats_cache = None
        after = db_path().stat().st_size if db_path().exists() else 0
        return {'before_bytes': before, 'after_bytes': after, 'seconds': round(time.time() - t0, 2)}

    def backup_to(self, target):
        """A consistent copy through SQLite's online backup API - safe while
        the daemon keeps writing."""
        import sqlite3
        self.flush()
        with self.lock:
            dest = sqlite3.connect(str(target))
            try:
                self.db.backup(dest)
            finally:
                dest.close()
        return target.stat().st_size

    def restore_from(self, source):
        """Replace the live database's contents with a backup's, in place:
        the file stays open, callers keep their connection, the daemon's
        in-memory state re-syncs from the next poll and report."""
        import sqlite3
        self.flush(5.0)
        self._wq.clear()                     # anything still queued belongs to the replaced contents
        self._meta_cache.clear()
        self._snap_cache.clear()
        self._dev_cache.clear()
        self._actions_cache.clear()
        self._last_action.clear()
        self._meta_raw.clear()
        self._dev_list = None
        self._stats_cache = None
        src = sqlite3.connect(str(source))
        try:
            with self.lock:
                src.backup(self.db)
                self.db.commit()
        finally:
            src.close()

    def counter_delta(self, device_id, key, t0, t1):
        """How much a monotonic counter grew between two times: the sum of its
        positive steps, so a counter reset in between does not go negative."""
        with self.lock:
            rows = self.db.execute('SELECT ts, value FROM samples WHERE device=? AND key=? AND ts BETWEEN ? AND ? '
                                   'ORDER BY ts', (device_id, key, int(t0), int(t1))).fetchall()
            if len(rows) < 2:
                rows = self.db.execute('SELECT ts, avg AS value FROM samples_hourly WHERE device=? AND key=? '
                                       'AND ts BETWEEN ? AND ? ORDER BY ts',
                                       (device_id, key, int(t0), int(t1))).fetchall()
        total = 0.0
        previous = None
        for row in rows:
            value = row['value']
            if value is None:
                continue
            if previous is not None and value > previous:
                total += value - previous
            previous = value
        return round(total, 2)

    def last_action(self, device_id):
        """The most recent action this device sent, with when. Read for every
        button on every refresh, and we are the ones who record it, so the
        answer is kept in memory and updated as the actions come in."""
        if device_id in self._last_action:
            return dict(self._last_action[device_id]) if self._last_action[device_id] else None
        with self.lock:
            r = self.db.execute("SELECT detail, ts FROM events WHERE device=? AND kind='action' "
                                "ORDER BY ts DESC LIMIT 1", (device_id,)).fetchone()
        found = {'action': r['detail'], 'ts': r['ts']} if r else None
        self._last_action[device_id] = found
        return dict(found) if found else None

    def actions_seen(self, device_id):
        """Every distinct action this device has ever reported, most recent
        first. Asked for every button on every dashboard refresh, and it only
        changes when a button reports something it never reported before."""
        cached = self._actions_cache.get(device_id)
        if cached is not None:
            return list(cached)
        with self.lock:
            rows = self.db.execute("SELECT detail, MAX(ts) AS ts FROM events WHERE device=? AND kind='action' "
                                   "GROUP BY detail ORDER BY ts DESC", (device_id,)).fetchall()
        seen = [r['detail'] for r in rows if r['detail']]
        self._actions_cache[device_id] = seen
        return list(seen)

    # -- meta -----------------------------------------------------------------
    def get_meta(self, key, default=None):
        """Small settings read on the dashboard path (a plug's counter reset
        stamp, for one), so the value is kept rather than fetched each time."""
        if key in self._meta_raw:
            value = self._meta_raw[key]
            return value if value is not None else default
        with self.lock:
            r = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        value = r['value'] if r else None
        self._meta_raw[key] = value
        return value if value is not None else default

    def _defer(self, fn, *args):
        """Run a write later, in order, on the writer thread."""
        if len(self._wq) > 20000:            # a pathological backlog: keep the newest
            try:
                self._wq.popleft()
            except IndexError:
                pass
        self._wq_idle.clear()
        self._wq.append((fn, args))
        self._wq_wake.set()

    def _writer_loop(self):
        while True:
            self._wq_wake.wait(0.5)
            self._wq_wake.clear()
            drained = False
            while True:
                try:
                    fn, args = self._wq.popleft()
                except IndexError:
                    break
                drained = True
                try:
                    fn(*args)
                except Exception as e:
                    try:
                        log('deferred write failed: %s' % e, 'error')
                    except Exception:
                        pass
            if drained or not self._wq:
                self._wq_idle.set()

    def flush(self, timeout=30.0):
        """Wait for the queued writes to land - before a backup or a VACUUM,
        so what they capture is everything that has happened."""
        self._wq_wake.set()
        deadline = time.time() + timeout
        while self._wq and time.time() < deadline:
            self._wq_idle.wait(0.05)
        return not self._wq

    def set_meta(self, key, value, deferred=False):
        """The in-memory copy is updated at once and every reader sees it; the
        row itself lands under the lock. Callers on the message path pass
        deferred=True and the write joins the queue instead, because a
        critical alert or a hand-taking-over must not stand behind a VACUUM
        for the best part of a second."""
        self._meta_raw[key] = str(value)
        if deferred:
            self._defer(self._write_meta, key, str(value))
        else:
            self._write_meta(key, str(value))
        # refresh rather than drop: a dropped cache means the next button press
        # goes to the database, and that press may land during a VACUUM
        try:
            data = json.loads(value) if isinstance(value, str) and value[:1] in '[{' else None
        except ValueError:
            data = None
        if isinstance(data, list):
            self._meta_cache[key] = [x for x in data if isinstance(x, dict)]
        else:
            self._meta_cache.pop(key, None)

    def _write_meta(self, key, value):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO meta (key,value) VALUES (?,?)', (key, value))

    def meta_json(self, key):
        """A config list (bindings, rules, scenes...) parsed once and kept in
        memory. These are read on EVERY incoming message to decide what to
        fire; going to the database each time put the automation path behind
        the same lock a VACUUM or an online backup holds for seconds."""
        cached = self._meta_cache.get(key)
        if cached is not None:
            return cached
        raw = self.get_meta(key)
        try:
            data = json.loads(raw) if raw else []
        except ValueError:
            data = []
        data = [x for x in data if isinstance(x, dict)]
        self._meta_cache[key] = data
        return data

    # -- housekeeping ---------------------------------------------------------
    def aggregate(self):
        """Roll full-resolution rows older than two hours into hourly buckets."""
        now = int(time.time())
        cutoff = (now // 3600) * 3600 - 7200
        done = 0
        with self.lock:
            r = self.db.execute("SELECT value FROM meta WHERE key='aggregated_to'").fetchone()
            start = int(r['value']) if r else 0
            if start >= cutoff:
                return 0
            self.db.execute('BEGIN')
            try:
                cur = self.db.execute(
                    'INSERT OR REPLACE INTO samples_hourly (ts,device,key,n,avg,min,max) '
                    'SELECT (ts/3600)*3600, device, key, COUNT(*), AVG(value), MIN(value), MAX(value) '
                    'FROM samples WHERE ts>=? AND ts<? GROUP BY device, key, ts/3600',
                    (start, cutoff))
                done = cur.rowcount if cur.rowcount is not None else 0
                self.db.execute("INSERT OR REPLACE INTO meta (key,value) VALUES ('aggregated_to',?)",
                                (str(cutoff),))
                full_days = int(CONFIG.get('retain_full_days', 14))
                hourly_days = int(CONFIG.get('retain_hourly_days', 730))
                event_days = int(CONFIG.get('retain_events_days', 730))
                self.db.execute('DELETE FROM samples WHERE ts<?', (now - full_days * 86400,))
                self.db.execute('DELETE FROM samples_hourly WHERE ts<?', (now - hourly_days * 86400,))
                self.db.execute('DELETE FROM events WHERE ts<?', (now - event_days * 86400,))
                self.db.execute('COMMIT')
            except Exception:
                self.db.execute('ROLLBACK')
                raise
        return done

    def reset(self, scope, device_id=None):
        """Erase recorded data. scope: all, history, events, device."""
        with self.lock:
            if scope == 'all':
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    self.db.execute('DELETE FROM %s' % table)
                self.db.execute("DELETE FROM meta WHERE key NOT IN ('bindings')")
                self.db.execute('DELETE FROM devices')
            elif scope == 'history':
                for table in ('samples', 'samples_hourly'):
                    self.db.execute('DELETE FROM %s' % table)
                self.db.execute("DELETE FROM meta WHERE key='aggregated_to'")
            elif scope == 'events':
                self.db.execute('DELETE FROM events')
            elif scope == 'device' and device_id:
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    self.db.execute('DELETE FROM %s WHERE device=?' % table, (device_id,))
                self.db.execute('DELETE FROM devices WHERE id=?', (device_id,))
            else:
                raise ValueError('unknown scope %r' % scope)
            self.last_sample.clear()
        self._forget_device()            # rows and whole tables just went away
        self._stats_cache = None         # the counts changed; refreshed below, before the VACUUM
        if scope == 'device' and device_id:
            for cache in (self._snap_cache, self._actions_cache, self._last_action):
                cache.pop(device_id, None)   # only this one went away
        else:
            self._snap_cache.clear()
            self._actions_cache.clear()
            self._last_action.clear()
        if scope in ('all', 'history'):
            self._meta_cache.clear()         # only those scopes touch meta rows
            self._meta_raw.clear()
        # Everything the dashboard reads must be back in memory BEFORE the
        # VACUUM starts: behind it, a first read waits for the whole thing.
        self.devices(include_removed=True)   # also fills the list the warm below needs
        self._warm_meta()
        if scope != 'device':
            self._warm_actions()
        self.stats()                     # the header's counts, while the file is still free
        try:
            self.db.execute('VACUUM')
            self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')   # or the file still looks as big
        except sqlite3.OperationalError:
            pass
        self._stats_cache = None

    def stats(self):
        """Row counts for the dashboard header. Counting half a million rows
        five times over is not something anyone should wait for, least of all
        behind a VACUUM: the figures are kept for half a minute, and while the
        database is busy the last ones are shown rather than blocking."""
        cached = self._stats_cache
        if cached and time.time() - cached[0] < 30:
            return dict(cached[1])
        if not self.lock.acquire(timeout=0.05):
            if cached:
                return dict(cached[1])
            self.lock.acquire()               # nothing to fall back on yet
        try:
            out = {}
            for table in ('devices', 'samples', 'samples_hourly', 'events', 'snapshots'):
                out[table] = self.db.execute('SELECT COUNT(*) AS n FROM %s' % table).fetchone()['n']
            r = self.db.execute('SELECT MIN(ts) AS a FROM samples_hourly').fetchone()
            r2 = self.db.execute('SELECT MIN(ts) AS a FROM samples').fetchone()
            oldest = [x for x in (r['a'], r2['a']) if x]
            out['oldest'] = min(oldest) if oldest else None
        finally:
            self.lock.release()
        try:
            size = self.path.stat().st_size
            wal = self.path.with_name(self.path.name + '-wal')
            wal_size = wal.stat().st_size if wal.exists() else 0
            out['bytes'] = size + wal_size
            out['file_bytes'] = size
            out['wal_bytes'] = wal_size
        except OSError:
            out['bytes'] = out['file_bytes'] = out['wal_bytes'] = None
        out['path'] = str(self.path)
        self._stats_cache = (time.time(), out)
        return dict(out)


# ---------------------------------------------------------------------------
# MQTT
# ---------------------------------------------------------------------------
def make_mqtt_client(client_id, clean=True):
    """A paho client that works with both the 1.x and the 2.x API."""
    if mqtt is None:
        raise RuntimeError('python3-paho-mqtt is not installed')
    if hasattr(mqtt, 'CallbackAPIVersion'):
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id,
                             clean_session=clean)
    else:
        client = mqtt.Client(client_id=client_id, clean_session=clean)
    if CONFIG.get('mqtt_username'):
        client.username_pw_set(CONFIG['mqtt_username'], CONFIG.get('mqtt_password') or None)
    if CONFIG.get('mqtt_tls'):
        ca = CONFIG.get('mqtt_ca') or None
        if ca:
            client.tls_set(ca_certs=ca, cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)
        else:
            client.tls_set(cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLS_CLIENT)
            client.tls_insecure_set(True)
    client.reconnect_delay_set(min_delay=1, max_delay=30)
    return client


def reason_text(rc):
    """paho 1.x gives an int, 2.x a ReasonCode; both print sensibly."""
    try:
        if hasattr(rc, 'is_failure'):
            return str(rc)
        return mqtt.connack_string(rc) if mqtt else str(rc)
    except Exception:
        return str(rc)


def rc_failed(rc):
    if hasattr(rc, 'is_failure'):
        return rc.is_failure
    return int(rc) != 0


def exposes_map(definition):
    """Zigbee2MQTT's exposes tree -> {property: {label, unit, description, type}}."""
    out = {}

    def walk(items, prefix=''):
        for item in items or []:
            if not isinstance(item, dict):
                continue
            prop = item.get('property')
            if prop:
                name = (prefix + prop) if prefix else prop
                out[name] = {
                    'access': item.get('access'),
                    'label': item.get('label') or key_label(name),
                    'unit': item.get('unit') or key_unit(name),
                    'description': item.get('description') or '',
                    'type': item.get('type') or '',
                    'category': item.get('category') or '',
                    'values': item.get('values') or None,
                    'min': item.get('value_min'),
                    'max': item.get('value_max'),
                }
            if item.get('features'):
                sub = (prefix + prop + '.') if prop else prefix
                walk(item['features'], sub)

    if isinstance(definition, dict):
        walk(definition.get('exposes'))
    return out


class PlugState(object):
    """Everything the daemon remembers about one configured plug."""

    def __init__(self, name, cfg):
        self.name = name
        self.cfg = cfg
        self.device_id = 'plug:' + name
        self.info = None
        self.device_status = None
        self.last_device_status = 0.0
        self.last_poll = 0.0
        self.last_sample = 0.0
        self.backoff_until = 0.0
        self.failures = 0
        self.error = None
        self.output = None
        self.flat = {}
        self.generated = None
        self.pulsing = False
        self.pulse_lock = threading.Lock()

    @property
    def optional(self):
        return bool(self.cfg.get('optional')) or str(self.cfg.get('host_state') or '') == 'optional'

    @property
    def unplugged(self):
        """An optional box that is not answering right now: expected, not a fault."""
        return self.optional and self.failures >= 3

    def rpc(self):
        rpc = ShellyRPC(self.cfg.get('host'), self.cfg.get('password') or '',
                        self.cfg.get('switch_id') or 0, label='plug %s' % self.name)
        if self.unplugged:
            # do not spend the full timeout on a box that is known to be
            # off: a quick probe is enough to notice it coming back, and a
            # command aimed at it fails fast instead of holding a thread
            rpc.timeout = min(rpc.timeout, 2.0)
        return rpc


# ---------------------------------------------------------------------------
# The daemon
# ---------------------------------------------------------------------------
class Daemon(object):
    def __init__(self, storage=None):
        open_log()
        self.store = storage or Storage()
        self.lock = threading.Lock()
        self.token = self._ensure_token()
        self.started = time.time()
        self.connected = False
        self.last_connect = None
        self.last_disconnect = None
        self.connect_failures = 0
        self.last_error = None
        self.messages = 0
        self.last_message_at = None
        self.last_aggregate_at = 0.0
        self.bridge = {'state': None, 'version': None, 'coordinator': None,
                       'permit_join': None, 'permit_join_end': None, 'channel': None,
                       'pan_id': None, 'log_level': None, 'updated': None,
                       'devices_at': None}
        self._stale_topics = {}  # topic -> when we last complained about it
        self._empty_seen = {}    # topic -> when we last saw it cleared
        self.names = {}          # friendly name -> device id (zigbee)
        self.live = {}           # device id -> {'payload', 'ts', 'availability'}
        self._gw_answered = {}   # device id -> when its own gateway API last answered
        self._rule_queue = collections.deque()
        self._rule_kick = threading.Event()
        self._report_hits = {}   # caller -> when it last reported, for the rate limit
        self._heat_last = {}     # valve target -> the last temperature we asked it for
        self._pending_set = {}   # (device, key) -> what a knob last asked for, and the timer that sends it
        self._valve_mode = {}    # device -> when we last told a head to use manual mode
        self._month_done = ''    # which month's summary has already gone out
        self._rule_queue_gated = collections.deque()
        self._rule_kick_gated = threading.Event()
        self.pin_failures = 0
        self.pin_locked_until = 0.0
        self.sessions = {}       # unlock token -> {'until': ts, 'minutes': n}
        self.rule_runtime = {}   # rule id -> {'holds', 'fired', 'reading'}
        self.schedule_runtime = {}   # schedule id -> {'last_day'}
        self.file_config = dict(CONFIG)      # what config.json says, before overrides
        self.apply_config_overrides()
        threading.Thread(target=self.backup_loop, name='backup', daemon=True).start()
        # always on: gateway_configs() covers both config.json and dashboard
        # entries, and simply does nothing on an empty list either way
        threading.Thread(target=self.gateway_loop, name='gateway', daemon=True).start()
        warn_unknown_keys()
        self.notify_queue = []
        self.notify_sent = {}    # dedup key -> last ts
        self._notify_kick = threading.Event()
        threading.Thread(target=self.notify_loop, name='notify', daemon=True).start()
        self.store.on_event = self.consider_notifying
        try:
            self.parents = json.loads(self.store.get_meta('parents') or '{}')
        except ValueError:
            self.parents = {}
        self.seq = 0             # bumped on every visible change; /api/wait hangs on it
        self._change = threading.Condition()
        self.client = None
        self._stop = threading.Event()
        # Friendly name -> id, prefilled from the database so a report or a
        # retained availability message arriving before bridge/devices after a
        # restart does not spawn a duplicate "name:" placeholder.
        for known in self.store.devices(include_removed=True):
            if known['source'] == 'zigbee' and not known['id'].startswith('name:'):
                self.names.setdefault(known['name'], known['id'])
        self.plugs = {}          # name -> PlugState
        self.sensors = {}        # name -> PlugState, for Shelly sensors polled over RPC
        self.pushes_received = 0
        self.pushes_rejected = 0
        self.last_push_at = None
        self._plug_lock = threading.Lock()
        self._zb_echo = {}       # Zigbee2MQTT name -> when we last saw our own /set echoed back
        self._gw_last = {}       # device -> {key: (value, when)} last written from a gateway poll
        self.presence = {}       # person id -> {home, last_seen, since, device, on_wifi}
        self.wifi = {'ok': None, 'error': None, 'checked': None, 'count': None,
                     'wifi_count': None, 'clients_list': [], 'names': {}}
        try:
            remembered = json.loads(self.store.get_meta('wifi_names') or '{}')
            if isinstance(remembered, dict):
                self.wifi['names'] = remembered
        except ValueError:
            pass
        self._wifi_kick = threading.Event()
        self._wifi_lock = threading.Lock()
        self._wifi_fetch_lock = threading.Lock()
        self._wifi_detail_lock = threading.Lock()
        self._wifi_detail_at = 0.0
        self._anyone_home_before = False
        self._presence_cache = None
        self._msg_last = {}      # message id + text -> when it last went out
        threading.Thread(target=self.wifi_loop, name='wifi', daemon=True).start()
        threading.Thread(target=self.presence_ntfy_loop, name='presence-ntfy', daemon=True).start()
        self.zigbee_seen = {}    # device id -> when it last reported over Zigbee itself
        self._energy_closed = {}  # (plug, from, to) -> the reading of a period that has ended
        self._energy_summary = None
        self._mqtt_selftest_seen = None
        self._map_stamp = 0.0        # bumped whenever a network map lands
        self.setup_plugs()
        self.setup_sensors()
        # What was recorded before the restart is the starting point, so the
        # dashboard is never blank while waiting for sleepy devices to report.
        for dev in self.store.devices():
            if dev['source'] == 'zigbee':
                self.names[dev['name']] = dev['id']
        for device_id, snap in self.store.snapshots().items():
            self.live[device_id] = snap

    # -- API token ----------------------------------------------------------
    def _ensure_token(self):
        token = None
        try:
            token = TOKEN_FILE.read_text().strip() or None
        except OSError:
            pass
        token = token or secrets.token_urlsafe(32)
        path = token_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(token)
            path.chmod(0o640)
            import grp
            import pwd
            info = path.stat()
            log('API token at %s (owner %s, group %s, mode %o)'
                % (path, pwd.getpwuid(info.st_uid).pw_name,
                   grp.getgrgid(info.st_gid).gr_name, info.st_mode & 0o777))
        except OSError as e:
            log('cannot write the API token to %s: %s - the privileged '
                'endpoints will refuse every request' % (path, e), 'error')
        return token

    # -- MQTT plumbing ------------------------------------------------------
    def connect(self):
        self.client = make_mqtt_client(CONFIG.get('mqtt_client_id') or 'zigmon')
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        if hasattr(self.client, 'on_connect_fail'):
            self.client.on_connect_fail = self._on_connect_fail
        host, port = CONFIG['mqtt_host'], int(CONFIG['mqtt_port'])
        log('connecting to mqtt://%s:%d as %s' % (host, port, CONFIG.get('mqtt_username') or 'anonymous'))
        try:
            self.client.connect_async(host, port, int(CONFIG.get('mqtt_keepalive') or 60))
        except (OSError, ValueError) as e:
            self.last_error = str(e)
            log('connect: %s' % e, 'error')
        self.client.loop_start()

    def topics(self):
        base = CONFIG['base_topic'].rstrip('/')
        wanted = [(base + '/#', 0)]
        for extra in CONFIG.get('extra_topics') or []:
            if extra and extra.rstrip('/') != base:
                wanted.append((extra, 0))
        seen = {t for t, _ in wanted}
        for prefix in self.plug_prefix_map():
            t = prefix + '/#'
            if t not in seen and not any(t.startswith(e.rstrip('#')) for e in seen):
                wanted.append((t, 0))
        return wanted

    def plug_prefix_map(self):
        """MQTT prefix -> the plug rows behind it (several for a multi-relay device)."""
        out = {}
        with self._plug_lock:
            for p in list(self.plugs.values()) + list(self.sensors.values()):
                prefix = str(p.cfg.get('mqtt_name') or '').strip().strip('/')
                if prefix:
                    out.setdefault(prefix, []).append(p)
        return out

    def _on_connect(self, client, userdata, flags, rc, *rest):
        if rc_failed(rc):
            self.connect_failures += 1
            self.last_error = 'connect refused: %s' % reason_text(rc)
            log(self.last_error, 'error')
            return
        self.connected = True
        self.last_connect = time.time()
        self.last_error = None
        client.subscribe(self.topics())
        log('connected; subscribed to %s' % ', '.join(t for t, _ in self.topics()))
        self.store.add_event('broker', 'connected to %s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port']))

    def _on_connect_fail(self, client, userdata, *rest):
        self.connect_failures += 1
        self.last_error = 'cannot reach the broker at %s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port'])
        # paho retries by itself; one line per minute is enough noise.
        if self.connect_failures in (1, 2) or self.connect_failures % 30 == 0:
            log(self.last_error + ' (attempt %d)' % self.connect_failures, 'warn')

    def _on_disconnect(self, client, userdata, *rest):
        # paho 2.x: (client, userdata, flags, reason_code, properties); 1.x: (client, userdata, rc)
        rc = rest[1] if len(rest) >= 2 else (rest[0] if rest else 0)
        was = self.connected
        self.connected = False
        self.last_disconnect = time.time()
        if was and not self._stop.is_set():
            self.last_error = 'broker connection lost (%s)' % reason_text(rc)
            log(self.last_error, 'warn')
            self.store.add_event('broker', 'connection lost', 'warn')

    def _on_message(self, client, userdata, msg):
        self.messages += 1
        self.last_message_at = time.time()
        try:
            self.handle(msg.topic, msg.payload)
        except Exception as e:      # one bad payload must never stop the feed
            log('handling %s: %s' % (msg.topic, e), 'error')

    # -- message routing ----------------------------------------------------
    def handle(self, topic, raw):
        base = CONFIG['base_topic'].rstrip('/')
        if topic == base or topic.startswith(base + '/'):
            rest = topic[len(base) + 1:] if topic != base else ''
            self.handle_zigbee(rest, raw)
            return
        parts = topic.split('/')
        prefixes = self.plug_prefix_map()
        for depth in range(min(3, len(parts) - 1), 0, -1):
            prefix = '/'.join(parts[:depth])
            if prefix in prefixes:
                self.handle_plug_push(prefixes[prefix], parts[depth:], raw)
                return
        if len(parts) >= 2:
            self.handle_generic(parts, raw)

    @staticmethod
    def decode(raw):
        text = raw.decode('utf-8', 'replace').strip() if isinstance(raw, bytes) else str(raw)
        if not text:
            return None
        if text[0] in '{[':
            try:
                return json.loads(text)
            except ValueError:
                return text
        return text

    def handle_zigbee(self, rest, raw):
        parts = rest.split('/')
        if not parts or not parts[0]:
            return
        if parts[0] == 'bridge':
            self.handle_bridge(parts[1:], raw)
            return
        name = parts[0]
        sub = parts[1] if len(parts) > 1 else ''
        if not raw:
            # an empty retained message: someone cleared this topic, possibly us
            self._empty_seen['%s/%s' % (CONFIG['base_topic'].rstrip('/'), rest)] = time.time()
            self._stale_topics.pop('%s/%s' % (CONFIG['base_topic'].rstrip('/'), rest), None)
            return
        if sub in ('set', 'get'):
            # our own command coming back to us: proof the broker accepted it
            if sub == 'set':
                self._zb_echo[name] = time.time()
                if name == SELFTEST_NAME:
                    payload = self.decode(raw)
                    self._mqtt_selftest_seen = payload if isinstance(payload, dict) else {}
            return

        payload = self.decode(raw)
        device_id = self.names.get(name)
        if sub == 'availability':
            state = payload.get('state') if isinstance(payload, dict) else payload
            if isinstance(state, str):
                target = device_id or self.adopt_unknown(name, 'availability')
                if target:
                    self.set_availability(target, state.lower(), name)
            return
        if sub:
            return          # some other sub-topic we do not care about
        if not isinstance(payload, dict):
            return
        if device_id is None:
            device_id = self.adopt_unknown(name)
            if device_id is None:
                return
        self.record(device_id, name, payload)

    def ghost_topics(self):
        """Topics the broker keeps replaying for devices Zigbee2MQTT no longer
        has. We only know about one once its retained message has arrived,
        which it does the moment we subscribe."""
        return sorted(self._stale_topics)

    def clear_ghost_topics(self):
        """Publish an empty retained message to each, which is how a retained
        message is deleted, and see which ones the broker actually took."""
        topics = self.ghost_topics()
        if not topics:
            return {'ok': True, 'cleared': [], 'refused': [], 'message': 'nothing left to clear'}
        if not self.connected or not self.client:
            return {'ok': False, 'error': 'not connected to the broker'}
        sent_at = time.time()
        for topic in topics:
            try:
                info = self.client.publish(topic, payload=None, qos=1, retain=True)
                info.wait_for_publish(3)
            except Exception as e:
                log('clearing %s: %s' % (topic, e), 'debug')
        deadline = time.time() + 5
        while time.time() < deadline:
            if all(self._empty_seen.get(t, 0) >= sent_at for t in topics):
                break
            if self._stop.wait(0.2):
                break
        cleared = [t for t in topics if self._empty_seen.get(t, 0) >= sent_at]
        refused = [t for t in topics if t not in cleared]
        for topic in cleared:
            self._stale_topics.pop(topic, None)
        out = {'ok': not refused, 'cleared': cleared, 'refused': refused}
        if refused:
            out['message'] = ('the broker would not let the daemon write to %s. Its MQTT user needs '
                              '"topic write %s/#" for this, or clear them by hand with mosquitto_pub -r -n'
                              % (refused[0], CONFIG['base_topic'].rstrip('/')))
        else:
            out['message'] = 'cleared %d topic(s)' % len(cleared)
        return out

    def adopt_unknown(self, name, sub=''):
        """A device the bridge list has not told us about yet.

        Once Zigbee2MQTT has told us what it has, a message under a name that
        is not on that list is not a new device - it is the broker replaying a
        retained message for one that was deleted. Adopting it puts a ghost
        back on the dashboard every restart, so it is refused. The warning
        names the exact topic holding the message, sub-topic and all: a device
        usually has more than one, and clearing the wrong one changes
        nothing."""
        if self.bridge.get('devices_at'):
            topic = '%s/%s%s' % (CONFIG['base_topic'].rstrip('/'), name, ('/' + sub) if sub else '')
            last = self._stale_topics.get(topic, 0)
            if time.time() - last > 3600:
                self._stale_topics[topic] = time.time()
                log('ignoring %s: Zigbee2MQTT does not have that device, so this is a message the '
                    'broker kept. Clear it with: mosquitto_pub -r -n -t \'%s\'' % (topic, topic), 'warn')
            return None
        device_id = 'name:' + name
        self.names[name] = device_id
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'zigbee',
                                      'kind': None, 'exposes': {}})
            log('device "%s" seen before the bridge listed it' % name)
        return device_id

    def handle_bridge(self, parts, raw):
        what = parts[0] if parts else ''
        payload = self.decode(raw)
        now = int(time.time())
        if what == 'state':
            state = payload.get('state') if isinstance(payload, dict) else payload
            state = str(state).lower() if state is not None else None
            old = self.bridge['state']
            self.bridge['state'] = state
            self.bridge['updated'] = now
            if old != state:
                log('bridge is %s' % state)
                if old is not None or state != 'online':
                    self.store.add_event('bridge', 'Zigbee2MQTT is %s' % state,
                                         'info' if state == 'online' else 'crit')
        elif what == 'response' and len(parts) > 1 and parts[1] == 'networkmap':
            self.handle_networkmap(payload)
        elif what == 'response' and len(parts) > 1 and parts[1] == 'backup':
            self.handle_zigbee_backup(payload)
        elif what == 'info' and isinstance(payload, dict):
            coord = payload.get('coordinator') or {}
            meta = coord.get('meta') or {}
            net = payload.get('network') or {}
            self.bridge.update({
                'version': payload.get('version'),
                'coordinator': ('%s %s' % (coord.get('type') or '', meta.get('revision') or '')).strip() or None,
                'coordinator_ieee': coord.get('ieee_address'),
                'permit_join': payload.get('permit_join'),
                'permit_join_end': payload.get('permit_join_end'),
                'channel': net.get('channel'),
                'pan_id': net.get('pan_id'),
                'log_level': payload.get('log_level'),
                'updated': now,
            })
        elif what == 'devices' and isinstance(payload, list):
            self.sync_devices(payload)
            self.bridge['devices_at'] = now
        elif what == 'event' and isinstance(payload, dict):
            self.bridge_event(payload)
        elif what == 'logging' and isinstance(payload, dict):
            level = str(payload.get('level') or '').lower()
            message = str(payload.get('message') or '')
            # Zigbee2MQTT rightly complains that it does not know the name our
            # publish test uses; that complaint is ours, not a fault worth
            # putting in front of anyone.
            if level == 'error' and SELFTEST_NAME not in message:
                self.store.add_event('bridge', message[:300], 'warn')
        # request/response/definitions/groups/extensions: nothing to record

    def sync_devices(self, devices):
        seen = set()
        for d in devices:
            if not isinstance(d, dict):
                continue
            ieee = d.get('ieee_address')
            name = d.get('friendly_name') or ieee
            if not ieee or not name:
                continue
            if d.get('type') == 'Coordinator':
                self.bridge['coordinator_name'] = name
                self.bridge['coordinator_ieee'] = ieee
                # The coordinator is not a device of its own here - a gateway
                # entry can stand in for it. Point its name at that one record
                # so its own reports do not create a second, silent copy.
                self.names[name] = 'gw:coordinator'
                stray = self.store.device('name:' + name)
                if stray is not None and not stray.get('removed'):
                    self.store.mark_removed('name:' + name)
                    self.live.pop('name:' + name, None)
                    log('folded the stray "%s" record into the coordinator' % name)
                continue
            definition = d.get('definition') or {}
            dev = {
                'id': ieee, 'name': name, 'source': 'zigbee',
                'kind': d.get('type'),
                'model': definition.get('model') or d.get('model_id'),
                'vendor': definition.get('vendor') or d.get('manufacturer'),
                'description': definition.get('description'),
                'exposes': exposes_map(definition),
                'power_source': d.get('power_source'),
            }
            seen.add(ieee)
            # A device that reported before the list arrived was filed under
            # its name; move that history across now that we know its address.
            placeholder = 'name:' + name
            if self.store.device(placeholder):
                self.migrate(placeholder, ieee)
            old_name = None
            for n, i in list(self.names.items()):
                if i == ieee and n != name:
                    old_name = n
                    del self.names[n]
            self.names[name] = ieee
            outcome = self.store.upsert_device(dev)
            if outcome == 'new':
                log('new device: %s (%s %s)' % (name, dev['vendor'] or '', dev['model'] or ''))
                self.store.add_event('device', 'added: %s %s' % (dev['vendor'] or '', dev['model'] or ''),
                                     'info', ieee)
            elif outcome == 'renamed':
                log('device renamed: %s -> %s' % (old_name or '?', name))
                self.store.add_event('device', 'renamed from "%s" to "%s"' % (old_name or '?', name),
                                     'info', ieee)
        for dev in self.store.devices():
            if dev['source'] != 'zigbee':
                continue
            if dev['id'].startswith('name:'):
                # A leftover placeholder from an earlier version or a race:
                # if the bridge list names that device, fold it in now.
                real = self.names.get(dev['name'])
                if real and real != dev['id'] and not real.startswith('name:'):
                    self.migrate(dev['id'], real)
                continue
            if dev['id'] not in seen:
                self.store.mark_removed(dev['id'])
                self.names.pop(dev['name'], None)
                log('device left: %s' % dev['name'])
                self.store.add_event('device', 'removed from the network', 'warn', dev['id'])

    def migrate(self, old_id, new_id):
        """Fold one device row into another: rename when the target does not
        exist yet, merge and delete the leftover when it does."""
        with self.store.lock:
            for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                self.store.db.execute('UPDATE OR REPLACE %s SET device=? WHERE device=?' % table,
                                      (new_id, old_id))
            target = self.store.db.execute('SELECT first_seen FROM devices WHERE id=?', (new_id,)).fetchone()
            if target is None:
                self.store.db.execute('UPDATE OR REPLACE devices SET id=? WHERE id=?', (new_id, old_id))
            else:
                old_row = self.store.db.execute('SELECT first_seen, alias FROM devices WHERE id=?',
                                                (old_id,)).fetchone()
                if old_row:
                    if old_row['first_seen'] and (not target['first_seen']
                                                  or old_row['first_seen'] < target['first_seen']):
                        self.store.db.execute('UPDATE devices SET first_seen=? WHERE id=?',
                                              (old_row['first_seen'], new_id))
                    if old_row['alias']:
                        self.store.db.execute('UPDATE devices SET alias=COALESCE(alias,?) WHERE id=?',
                                              (old_row['alias'], new_id))
                self.store.db.execute('DELETE FROM devices WHERE id=?', (old_id,))
            self.store.last_sample.clear()
        self.store._forget_device(old_id)
        self.store._forget_device(new_id)
        self.store._snap_cache.pop(old_id, None)
        if old_id in self.live:
            merged = self.live.pop(old_id)
            self.live.setdefault(new_id, merged)
        log('history recorded under "%s" now belongs to %s' % (old_id[5:], new_id))
        self.bump()

    def bridge_event(self, payload):
        kind = payload.get('type') or ''
        data = payload.get('data') or {}
        name = data.get('friendly_name') or data.get('ieee_address')
        ieee = data.get('ieee_address')
        if kind == 'device_joined':
            self.store.add_event('device', 'joined the network', 'info', ieee)
            log('device joined: %s' % name)
        elif kind == 'device_leave':
            self.store.add_event('device', 'left the network', 'warn', ieee)
            log('device left: %s' % name)
        elif kind == 'device_interview':
            status = data.get('status')
            if status == 'successful':
                d = data.get('definition') or {}
                self.store.add_event('device', 'interviewed: %s %s' % (d.get('vendor') or '',
                                     d.get('model') or ''), 'info', ieee)
            elif status == 'failed':
                self.store.add_event('device', 'interview failed', 'warn', ieee)
        elif kind == 'device_announce':
            self.store.add_event('device', 'announced itself', 'info', ieee)

    def set_availability(self, device_id, state, name):
        if state == 'offline' and time.time() - self._gw_answered.get(device_id, 0) < 300:
            log('%s: the bridge says offline, but its own API answered a moment ago - keeping it online' % name, 'debug')
            return
        prev = (self.live.get(device_id) or {}).get('availability')
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': None, 'availability': None})
        entry['availability'] = state
        self.store.store_snapshot(device_id, entry['ts'] or int(time.time()), {}, state)
        if prev != state and prev is not None:
            level = 'warn' if state == 'offline' else 'info'
            self.store.add_event('availability', state, level, device_id)
            log('%s is %s' % (name, state))

    def record(self, device_id, name, payload):
        now = int(time.time())
        self.zigbee_seen[device_id] = now
        if device_id == 'gw:coordinator' and self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'gateway',
                                      'kind': 'Coordinator', 'vendor': None, 'last_seen': now})
        flat = flatten(payload)
        values = {}
        for key, value in flat.items():
            if key in IGNORE_KEYS or key.startswith('update'):
                continue
            if key == 'action':
                if value not in (None, ''):
                    # the relay first, the paperwork after: a binding is the one
                    # thing here a person is physically waiting on
                    self.fire_bindings(device_id, name, str(value))
                    self.store.add_event('action', str(value), 'info', device_id, now)
                    log('%s: %s' % (name, value), 'debug')
                continue
            v = numeric(value)
            if v is not None:
                values[key] = v
        if values:
            self.queue_rules(device_id, name, values)    # motion -> light must not wait for a disk commit
            self.store.store_sample(device_id, now, values)
        clean = {k: v for k, v in flat.items() if not k.startswith('update')}
        merged = self.store.store_snapshot(device_id, now, clean)
        self.store.touch_device(device_id, now)
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': None, 'availability': None})
        entry['payload'] = merged
        entry['ts'] = now
        # A device that reports is by definition reachable.
        if entry.get('availability') == 'offline':
            self.set_availability(device_id, 'online', name)
        log('%s: %s' % (name, ', '.join('%s=%s' % kv for kv in sorted(values.items()))), 'debug')
        self.bump()

    def handle_plug_push(self, plugs, rest, raw):
        """The plug's own MQTT tells us the moment its relay changes - a wall
        button, its web page, the Shelly app - so the dashboard does not sit
        on the 15 s poll for state it can have now."""
        payload = self.decode(raw)
        if not isinstance(payload, dict):
            return
        updates = {}
        if rest == ['events', 'rpc'] and payload.get('method') == 'NotifyStatus':
            for key, value in (payload.get('params') or {}).items():
                m = re.match(r'^switch:(\d+)$', key)
                if m and isinstance(value, dict):
                    updates[int(m.group(1))] = value
        elif len(rest) == 2 and rest[0] == 'status':
            m = re.match(r'^switch:(\d+)$', rest[1])
            if m:
                updates[int(m.group(1))] = payload
        if not updates:
            return
        now = int(time.time())
        for p in plugs:
            value = updates.get(int(p.cfg.get('switch_id') or 0))
            if value is None:
                continue
            changed = False
            if 'output' in value:
                output = 1 if value.get('output') else 0
                if p.output is not None and output != p.output:
                    source = str(value.get('source') or 'outside this dashboard')
                    self.store.add_event('plug', 'switched %s (%s)' % ('on' if output else 'off', source),
                                         'info', p.device_id)
                    log('%s switched %s (%s, seen on its MQTT)' % (p.name, 'on' if output else 'off', source))
                    changed = True
                p.output = output
            if p.flat:
                for k, v in flatten(value).items():
                    if k in ('id', 'source'):
                        continue
                    p.flat['switch.' + k] = v
                p.generated = now
                if not changed and time.time() - getattr(p, '_push_bumped', 0.0) >= 1.0:
                    changed = True            # new watts: the socket row shows them now, not on the next 5 s tick
            entry = self.live.get(p.device_id)
            if entry:
                entry['ts'] = now
            if changed:
                p._push_bumped = time.time()
                self.bump()

    def handle_generic(self, parts, raw):
        """shellies/<name>/status/<component> and similar: a WiFi device."""
        payload = self.decode(raw)
        if not isinstance(payload, dict):
            return
        prefix, name = parts[0], parts[1]
        rest = parts[2:]
        if name in self.plug_mqtt_names():
            return          # polled over RPC; the MQTT copy would only duplicate it
        if rest and rest[0] == 'status' and len(rest) >= 2:
            component = rest[1]              # temperature:0, switch:0, devicepower:0
            comp_name = component.split(':')[0]
            multiple = component.split(':')[1] if ':' in component and component.split(':')[1] != '0' else ''
            keyed = {}
            for k, v in flatten(payload).items():
                if k in ('id',):
                    continue
                key = k if comp_name in ('temperature', 'humidity', 'devicepower', 'illuminance') \
                    else '%s.%s' % (comp_name, k)
                if multiple:
                    key = '%s%s.%s' % (comp_name, multiple, k)
                keyed[key] = v
            payload = keyed
        elif rest and rest[0] in ('events', 'rpc', 'online', 'command'):
            if rest[0] == 'online':
                state = 'online' if str(payload).lower() in ('true', '1', 'online') else 'offline'
                device_id = '%s:%s' % (prefix, name)
                if self.store.device(device_id):
                    self.set_availability(device_id, state, name)
            return
        elif rest:
            return
        device_id = '%s:%s' % (prefix, name)
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'shelly'
                                      if prefix == 'shellies' else 'mqtt', 'kind': 'wifi',
                                      'vendor': 'Shelly' if prefix == 'shellies' else None,
                                      'exposes': {}})
            log('new device: %s (%s)' % (name, prefix))
            self.store.add_event('device', 'first seen on %s/%s' % (prefix, name), 'info', device_id)
        self.record(device_id, name, payload)


    # -- settings tunable from the dashboard --------------------------------------
    TUNABLE = {
        'battery_warn': (0, 100), 'battery_crit': (0, 100),
        'lqi_warn': (0, 255), 'lqi_crit': (0, 255),
        'stale_warn_min': (1, 100000), 'stale_crit_min': (1, 100000), 'silence_alert_buttons': (0, 1),
        'temperature_min': (-100, 200, True), 'temperature_max': (-100, 200, True),
        'humidity_max': (0, 100, True),
        'plug_poll_interval': (2, 3600), 'plug_sample_interval': (10, 86400),
        'plug_min_request_gap': (0, 10), 'plug_command_gap': (0, 10),
        'sample_interval': (0, 86400), 'networkmap_interval': (0, 86400), 'manual_hold_s': (0, 604800),
        'presence_fresh_s': (-1, 600),
        'price_per_kwh': (0, 1000, True),
        'latitude': (-90, 90, True), 'longitude': (-180, 180, True),
        'backup_enabled': (0, 1), 'backup_keep': (1, 365), 'backup_zigbee': (0, 1),
        'chart_outages': (0, 1), 'link_plugs': (0, 1), 'link_sensors': (0, 1), 'link_buttons': (0, 1),
        'backup_time': 'str',
        'currency': 'str', 'notify_ntfy': 'str',
        'notify_telegram_token': 'str', 'notify_telegram_chat': 'str',
    }

    def config_overrides(self):
        try:
            return {k: v for k, v in json.loads(self.store.get_meta('config_overrides') or '{}').items()
                    if k in self.TUNABLE}
        except ValueError:
            return {}

    def apply_config_overrides(self):
        for key, value in self.config_overrides().items():
            CONFIG[key] = value

    def save_config_overrides(self, body):
        overrides = self.config_overrides()
        changed = []
        for key, spec in self.TUNABLE.items():
            if key not in body:
                continue
            raw = body.get(key)
            if spec == 'str':
                value = str(raw or '').strip()[:200]
                if key == 'notify_ntfy' and value and not value.startswith(('http://', 'https://')):
                    raise ValueError('notify_ntfy must be a full topic URL (https://ntfy.sh/...)')
                if key == 'backup_time' and not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', value or ''):
                    raise ValueError('backup_time must look like 03:30')
            else:
                low, high = spec[0], spec[1]
                allow_null = len(spec) > 2
                value = numeric(raw)
                if value is None:
                    if raw not in (None, '') or not allow_null:
                        if not allow_null:
                            raise ValueError('%s must be a number' % key)
                    value = None
                elif not low <= value <= high:
                    raise ValueError('%s must be between %g and %g' % (key, low, high))
                if value is not None and value == int(value) and key not in ('latitude', 'longitude', 'price_per_kwh', 'plug_min_request_gap', 'plug_command_gap'):
                    value = int(value)
            previous = CONFIG.get(key)
            if value == self.file_config.get(key):
                overrides.pop(key, None)     # back to what the file says
            else:
                overrides[key] = value
            CONFIG[key] = value
            if value != previous:
                changed.append(key)
        self.store.set_meta('config_overrides', json.dumps(overrides))
        if changed:
            self.store.add_event('control', 'settings changed: ' + ', '.join(sorted(changed)))
            log('settings changed: %s' % ', '.join(sorted(changed)))
        self.bump()
        return changed

    def runtime_config(self):
        overrides = self.config_overrides()
        out = {}
        for key in self.TUNABLE:
            out[key] = {'value': CONFIG.get(key), 'file': self.file_config.get(key),
                        'overridden': key in overrides}
        return out

    # -- notifications: ntfy and/or Telegram ------------------------------------
    # what a per-device preset switches on (None = follow the global choices)

    def notify_channels(self):
        out = []
        if CONFIG.get('notify_ntfy'):
            out.append('ntfy')
        if CONFIG.get('notify_telegram_token') and CONFIG.get('notify_telegram_chat'):
            out.append('telegram')
        return out

    def notify_settings(self):
        try:
            saved = json.loads(self.store.get_meta('notify') or '{}')
        except ValueError:
            saved = {}
        devices = saved.get('devices') or {}
        return {'crit': bool(saved.get('crit', True)), 'warn': bool(saved.get('warn', False)),
                'rule': bool(saved.get('rule', False)), 'offline': bool(saved.get('offline', True)),
                'switch': bool(saved.get('switch', False)),
                'devices': {str(k): v for k, v in devices.items()
                            if notify_override_set(v) is not None}}

    def consider_notifying(self, kind, detail, level, device_id):
        if kind == 'alert':
            return                       # a written message has already been sent, in its own words
        if not self.notify_channels():
            return
        settings = self.notify_settings()
        name = None
        if device_id:
            row = self.store.device(device_id)
            name = (row.get('alias') or row['name']) if row else device_id
        offline_ish = 'lost contact' in detail or 'offline' in detail or 'went quiet' in detail \
            or 'unreachable' in detail or 'back online' in detail or 'reporting again' in detail
        switch_ish = kind in ('plug', 'switch') and ('switched' in detail or detail.startswith('set ') or detail.startswith('pulse'))
        rule_ish = kind == 'rule' and 'window' not in detail
        override = settings['devices'].get(device_id or '')
        enabled = notify_override_set(override) if override else None
        if enabled is None:
            enabled = {k for k in ('crit', 'warn', 'offline', 'rule', 'switch') if settings.get(k)}
        wanted = (level == 'crit' and 'crit' in enabled) \
            or (level == 'warn' and 'warn' in enabled) \
            or (offline_ish and 'offline' in enabled) \
            or (rule_ish and 'rule' in enabled) \
            or (switch_ish and 'switch' in enabled)
        if not wanted:
            return
        self.notify(('%s: %s' % (name, detail)) if name else detail, level, dedup='%s|%s|%s' % (kind, device_id, detail[:40]))

    def notify(self, message, level='info', dedup=None, title=None, image=None):
        now = time.time()
        if dedup:
            if now - self.notify_sent.get(dedup, 0) < 900:
                return                       # the same story inside 15 min stays untold
            self.notify_sent[dedup] = now
        self.notify_queue.append({'message': message, 'level': level,
                                  'title': title, 'image': image, 'queued': time.time()})
        self._notify_kick.set()

    def notify_loop(self):
        import urllib.request
        while True:
            self._notify_kick.wait()
            self._notify_kick.clear()
            while self.notify_queue:
                item = self.notify_queue.pop(0)
                # With the internet down every send waits out its timeout and
                # the queue backs up; a "motion at 10:01" delivered at 10:20 is
                # noise, not news. Anything that sat here longer than five
                # minutes is dropped with a line in the log; a critical one is
                # still sent, late is better than never for those.
                waited = time.time() - item.get('queued', time.time())
                if waited > 300 and item['level'] != 'crit':
                    log('notification dropped, %s late: %s' % (human_age(waited), item['message'][:80]), 'warn')
                    continue
                title = item.get('title') or {'crit': 'PROBLEM', 'warn': 'Warning'}.get(item['level'], 'zigmon')
                image = item.get('image') or ''
                if CONFIG.get('notify_ntfy'):
                    try:
                        headers = {'Title': ascii_header(title),
                                   'Priority': 'high' if item['level'] == 'crit' else 'default',
                                   'Tags': 'rotating_light' if item['level'] == 'crit' else 'house'}
                        if image:
                            # ntfy shows a picture from a URL; it is fetched by
                            # the phone, so it has to be reachable from there
                            headers['Attach'] = image
                        req = urllib.request.Request(CONFIG['notify_ntfy'], data=item['message'].encode(),
                                                     headers=headers)
                        urllib.request.urlopen(req, timeout=10).read()
                    except Exception as e:
                        log('ntfy: %s' % e, 'warn')
                token, chat = CONFIG.get('notify_telegram_token'), CONFIG.get('notify_telegram_chat')
                if token and chat:
                    try:
                        text = '%s\n%s' % (title, item['message'])
                        if image:
                            method, body = 'sendPhoto', {'chat_id': str(chat), 'photo': image, 'caption': text[:1024]}
                        else:
                            method, body = 'sendMessage', {'chat_id': str(chat), 'text': text}
                        req = urllib.request.Request('https://api.telegram.org/bot%s/%s' % (token, method),
                                                     data=json.dumps(body).encode(),
                                                     headers={'Content-Type': 'application/json'})
                        urllib.request.urlopen(req, timeout=10).read()
                    except Exception as e:
                        log('telegram: %s' % e, 'warn')

    def bump(self):
        """Something the dashboard shows has changed; wake every /api/wait."""
        with self._change:
            self.seq += 1
            self._change.notify_all()

    def wait_for_change(self, since, timeout):
        deadline = time.time() + max(0.5, min(30.0, timeout))
        with self._change:
            while self.seq <= since and not self._stop.is_set():
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                self._change.wait(min(1.0, remaining))
        return self.seq

    # -- plugs and sensors: from config.json and from the dashboard ------------
    def managed(self):
        """The UI-managed entries, kept in the database."""
        raw = self.store.get_meta('managed')
        if not raw:
            return {'plugs': [], 'sensors': []}
        try:
            data = json.loads(raw)
        except ValueError:
            return {'plugs': [], 'sensors': []}
        return {'plugs': [e for e in data.get('plugs') or [] if isinstance(e, dict)],
                'sensors': [e for e in data.get('sensors') or [] if isinstance(e, dict)]}

    def all_entries(self, kind):
        """config.json entries first (read-only in the UI), then the managed ones."""
        out = []
        seen = set()
        for entry in CONFIG.get(kind) or []:
            if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
                e = dict(entry, source='config', enabled=bool(entry.get('enabled', True)))
                out.append(e)
                seen.add(str(entry['name']))
        for entry in self.managed().get(kind) or []:
            if entry.get('name') and entry.get('host') and str(entry['name']) not in seen:
                out.append(dict(entry, source='ui', enabled=bool(entry.get('enabled', True))))
                seen.add(str(entry['name']))
        # the device (host) state wins over the channel's own: a disabled or
        # monitor-only device makes every one of its channels so; an enabled
        # device lets each channel keep its own choice
        for e in out:
            e['own_enabled'] = bool(e.get('enabled', True))
            e['own_monitor_only'] = bool(e.get('monitor_only', False))
            hs = e.get('host_state') or 'enabled'
            if hs == 'disabled':
                e['enabled'] = False
            elif hs == 'monitor':
                e['monitor_only'] = True
            # 'optional': works exactly like enabled, but the box is expected
            # to lose power now and then (a lamp on a switched outlet). While
            # it is gone nothing is alerted, notified or retried hard; the
            # moment it answers again everything is back as if nothing happened.
            e['optional'] = hs == 'optional'
            e['host_state'] = hs
        return out

    def active_entries(self, kind):
        return [e for e in self.all_entries(kind) if e.get('enabled', True)]

    def plug_names_all(self):
        """Every configured plug name, enabled or not - for validating bindings and rules."""
        return {e['name'] for e in self.all_entries('plugs')}

    def managed_for_ui(self):
        """Entries without passwords - only whether one is set."""
        def strip(e):
            return {'name': str(e['name']), 'host': str(e['host']), 'password_set': bool(e.get('password')),
                    'switch_id': int(e.get('switch_id') or 0), 'mqtt_name': str(e.get('mqtt_name') or ''),
                    'source': e.get('source', 'ui'), 'enabled': bool(e.get('enabled', True)),
                    'monitor_only': bool(e.get('monitor_only', False)),
                    'host_state': e.get('host_state') or 'enabled',
                    'role': 'light' if str(e.get('role') or '') == 'light' else 'plug',
                    'own_enabled': bool(e.get('own_enabled', e.get('enabled', True))),
                    'own_monitor_only': bool(e.get('own_monitor_only', e.get('monitor_only', False))),
                    'model': str(e.get('model') or ''), 'mac': str(e.get('mac') or '')}
        return {'plugs': [strip(e) for e in self.all_entries('plugs')],
                'sensors': [strip(e) for e in self.all_entries('sensors')]}

    def save_managed(self, plugs, sensors):
        """Validate, keep passwords the UI did not resend, store, rebuild the live state."""
        old = {}
        old_by_addr = {}
        for kind in ('plugs', 'sensors'):
            for e in self.managed().get(kind) or []:
                old[(kind, str(e['name']))] = e
                old_by_addr[(str(e.get('host') or ''), int(e.get('switch_id') or 0))] = e
        config_names = {str(e['name']) for kind in ('plugs', 'sensors') for e in (CONFIG.get(kind) or [])
                        if isinstance(e, dict) and e.get('name')}
        clean = {'plugs': [], 'sensors': []}
        names = set()
        for kind, items in (('plugs', plugs), ('sensors', sensors)):
            for index, e in enumerate(items or []):
                if not isinstance(e, dict):
                    continue
                if e.get('source') == 'config':
                    continue                      # those live in config.json, not here
                name = str(e.get('name') or '').strip()
                host = str(e.get('host') or '').strip()
                if not name or not host:
                    raise ValueError('%s %d needs a name and an address' % (kind[:-1], index + 1))
                if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', name):
                    raise ValueError('"%s": letters, digits, space, dot, dash and underscore only' % name)
                if name in names or name in config_names:
                    raise ValueError('the name "%s" is used twice' % name)
                if not re.match(r'^[A-Za-z0-9.:\[\]-]+$', host):
                    raise ValueError('"%s" is not an address' % host)
                names.add(name)
                hs = str(e.get('host_state') or 'enabled')
                if hs not in ('enabled', 'monitor', 'disabled', 'optional'):
                    hs = 'enabled'
                # A light is a plug in every respect - polled, switched, bound,
                # recorded the same - and differs only in where its energy is
                # listed, which is the whole point: a hall light next to a
                # workshop PC in one column tells you nothing.
                role = str(e.get('role') or '').strip().lower()
                entry = {'name': name, 'host': host,
                         'role': 'light' if role == 'light' else 'plug',
                         'switch_id': max(0, min(7, int(e.get('switch_id') or 0))),
                         'mqtt_name': str(e.get('mqtt_name') or '').strip(),
                         'enabled': bool(e.get('enabled', True)),
                         'monitor_only': bool(e.get('monitor_only', False)),
                         'host_state': hs,
                         'model': str(e.get('model') or '')[:40], 'mac': str(e.get('mac') or '')[:20]}
                password = e.get('password')
                if password is None or password == '':
                    # a renamed row is still the same box: fall back to its address
                    previous = old.get((kind, name)) \
                        or old.get(('plugs' if kind == 'sensors' else 'sensors', name)) \
                        or old_by_addr.get((host, entry['switch_id'])) or {}
                    entry['password'] = previous.get('password') or ''
                    if e.get('clear_password'):
                        entry['password'] = ''
                else:
                    entry['password'] = str(password)
                clean[kind].append(entry)
        self.store.set_meta('managed', json.dumps(clean))
        self.reload_devices()
        self.store.add_event('control', '%d plug(s) and %d sensor(s) configured from the dashboard'
                             % (len(clean['plugs']), len(clean['sensors'])))
        log('device list saved from the dashboard: %s' % ', '.join(
            [e['name'] for e in clean['plugs']] + [e['name'] for e in clean['sensors']]) or 'nothing')
        return self.managed_for_ui()

    def detect_plug(self, host, password=None, name_hint=''):
        """Ask the box at `host` what it is: model, MAC, firmware, and how many
        relays it has (with their own names and the MQTT prefix), so the
        dashboard can lay out one row per channel without anyone counting."""
        host = str(host or '').strip()
        if not re.match(r'^[A-Za-z0-9.:\[\]-]+$', host):
            raise ValueError('not an address')
        if password is None or password == '':
            for e in self.all_entries('plugs') + self.all_entries('sensors'):
                if str(e.get('host')) == host and e.get('password'):
                    password = e['password']
                    break
        rpc = ShellyRPC(host, password or '', 0, label=name_hint or host)
        info = rpc.call('Shelly.GetDeviceInfo') or {}
        status = rpc.call('Shelly.GetStatus') or {}
        channels = []
        for key in sorted(k for k in status if re.match(r'^switch:\d+$', k)):
            sid = int(key.split(':')[1])
            label = ''
            try:
                cfg = rpc.call('Switch.GetConfig', {'id': sid}) or {}
                label = str(cfg.get('name') or '')
            except PlugError:
                pass
            channels.append({'id': sid, 'name': label, 'output': bool((status.get(key) or {}).get('output'))})
        prefix = ''
        try:
            prefix = str((rpc.call('MQTT.GetConfig') or {}).get('topic_prefix') or '')
        except PlugError:
            pass
        model = str(info.get('model') or info.get('app') or '')
        return {'host': host, 'model': model, 'app': str(info.get('app') or ''), 'mac': str(info.get('mac') or ''),
                'fw': str(info.get('ver') or info.get('fw_id') or ''), 'device_name': str(info.get('name') or ''),
                'id': str(info.get('id') or ''), 'mqtt_prefix': prefix or str(info.get('id') or ''),
                'channels': channels, 'multi': len(channels) > 1,
                'sensor_like': not channels and any(k.startswith(('temperature:', 'humidity:')) for k in status)}

    def reload_devices(self):
        """Rebuild self.plugs / self.sensors from config + managed, keeping live state where the entry is unchanged."""
        with self._plug_lock:
            wanted = {e['name']: e for e in self.active_entries('plugs')}
            known = {e['name'] for e in self.all_entries('plugs')}
            for name in list(self.plugs):
                if name not in wanted:
                    self.store.mark_removed('plug:' + name)
                    self.live.pop('plug:' + name, None)
                    del self.plugs[name]
                    if name in known:
                        log('plug disabled: %s (its history stays; enable it to carry on)' % name)
                        self.store.add_event('plug', 'disabled from the dashboard', 'warn', 'plug:' + name)
                    else:
                        log('plug removed: %s' % name)
            for name, entry in wanted.items():
                current = self.plugs.get(name)
                if current and current.cfg.get('host') == entry.get('host') \
                        and current.cfg.get('password', '') == entry.get('password', '') \
                        and int(current.cfg.get('switch_id') or 0) == int(entry.get('switch_id') or 0):
                    current.cfg = entry
                    continue
                self.plugs[name] = PlugState(name, entry)
                self.store.upsert_device({'id': 'plug:' + name, 'name': name, 'source': 'plug', 'kind': 'wifi',
                                          'vendor': 'Shelly', 'exposes': {}})
                remembered = self.store.get_meta('plug_info_' + name)
                if remembered and not current:
                    try:
                        self.plugs[name].info = json.loads(remembered)
                    except ValueError:
                        pass
                if not current:
                    log('plug added: %s (%s)' % (name, entry.get('host')))
            wanted = {e['name']: e for e in self.active_entries('sensors')}
            known = {e['name'] for e in self.all_entries('sensors')}
            for name in list(self.sensors):
                if name not in wanted:
                    self.store.mark_removed('sensor:' + name)
                    self.live.pop('sensor:' + name, None)
                    del self.sensors[name]
                    log('sensor %s: %s' % ('disabled' if name in known else 'removed', name))
            for name, entry in wanted.items():
                current = self.sensors.get(name)
                if current and current.cfg.get('host') == entry.get('host') \
                        and current.cfg.get('password', '') == entry.get('password', ''):
                    current.cfg = entry
                    continue
                self.sensors[name] = PlugState(name, entry)
                self.sensors[name].device_id = 'sensor:' + name
                self.store.upsert_device({'id': 'sensor:' + name, 'name': name, 'source': 'shelly',
                                          'kind': 'wifi', 'vendor': 'Shelly', 'exposes': {}})
                if not current:
                    log('sensor added: %s (%s)' % (name, entry.get('host')))
        if self.connected and self.client:
            try:
                self.client.subscribe(self.topics())
            except Exception as e:
                log('resubscribe: %s' % e, 'warn')
        # the polling thread starts lazily when the first device appears
        if (self.plugs or self.sensors) and not getattr(self, '_plug_thread', None):
            self._plug_thread = threading.Thread(target=self.plug_loop, name='plugs', daemon=True)
            if getattr(self, '_running', False):
                self._plug_thread.start()

    def test_device(self, host, password=''):
        """One Shelly.GetDeviceInfo, so the dashboard can check an address before saving it."""
        rpc = ShellyRPC(host, password or '', 0, label='the device at %s' % host)
        info = rpc.device_info()
        out = {'ok': True, 'id': info.get('id'), 'model': info.get('model'), 'app': info.get('app'),
               'ver': info.get('ver'), 'gen': info.get('gen'), 'auth': bool(info.get('auth_en')),
               'name': info.get('name')}
        try:
            status = rpc.device_status() or {}
            out['components'] = sorted(k for k in status if ':' in k)
            out['kind'] = 'plug' if any(k.startswith('switch:') for k in status) else 'sensor'
        except PlugError:
            out['components'] = []
            out['kind'] = 'plug' if (info.get('app') or '').lower().startswith('plug') else 'sensor'
        return out

    def discover_devices(self, seconds=3.0):
        found = shelly_discover(Palette(False), seconds)
        known = {e['host'].split(':')[0] for kind in ('plugs', 'sensors') for e in self.all_entries(kind)}
        return [{'ip': ip, 'names': r['names'], 'known': ip in known} for ip, r in sorted(found.items())]

    # -- smart plugs ---------------------------------------------------------
    def setup_plugs(self):
        """One PlugState per plug from config.json and the dashboard; stale rows for plugs that are gone."""
        configured = set()
        for entry in self.active_entries('plugs'):
            name = str(entry['name'])
            configured.add(name)
            self.plugs[name] = PlugState(name, entry)
            device_id = 'plug:' + name
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'plug', 'kind': 'wifi',
                                      'vendor': 'Shelly', 'exposes': {}})
            remembered = self.store.get_meta('plug_info_' + name)
            if remembered:
                try:
                    self.plugs[name].info = json.loads(remembered)
                except ValueError:
                    pass
        disabled = {e['name'] for e in self.all_entries('plugs') if not e.get('enabled', True)}
        for dev in self.store.devices():
            if dev['source'] == 'plug' and dev['name'] not in configured:
                self.store.mark_removed(dev['id'])
                if dev['name'] in disabled:
                    log('plug disabled: %s' % dev['name'])

    def plug_mqtt_names(self):
        names = set()
        for p in self.plugs.values():
            if p.cfg.get('mqtt_name'):
                names.add(p.cfg['mqtt_name'])
            if p.info and p.info.get('id'):
                names.add(p.info['id'])
        return names

    def purge_per_device(self):
        """A device row may carry its own retain_full_days (shorter than the
        global one) - chatty plugs need not fill two weeks of raw samples."""
        for p in list(self.plugs.values()) + list(self.sensors.values()):
            days = numeric(p.cfg.get('retain_full_days'))
            if not days or days <= 0:
                continue
            cutoff = int(time.time() - days * 86400)
            with self.store.lock:
                gone = self.store.db.execute('DELETE FROM samples WHERE device=? AND ts<?',
                                             (p.device_id, cutoff)).rowcount
                self.store.db.commit()
            if gone:
                log('%s: %d old sample(s) dropped (retain %g d)' % (p.name, gone, days), 'debug')

    def backup_dir(self):
        return db_path().parent / 'backups'

    def db_backups(self):
        directory = self.backup_dir()
        if not directory.exists():
            return []
        out = []
        for f in sorted(directory.glob('zigmon-db-*.sqlite'), reverse=True):
            st = f.stat()
            out.append({'file': f.name, 'bytes': st.st_size, 'ts': int(st.st_mtime)})
        return out

    def db_backup_now(self, suffix=''):
        directory = self.backup_dir()
        directory.mkdir(exist_ok=True)
        target = directory / ('zigmon-db-%s%s.sqlite' % (time.strftime('%Y-%m-%d-%H%M%S'), suffix))
        n = 1
        while target.exists():                 # two in one second: never overwrite
            n += 1
            target = directory / ('zigmon-db-%s%s-%d.sqlite' % (time.strftime('%Y-%m-%d-%H%M%S'), suffix, n))
        size = self.store.backup_to(target)
        keep = int(CONFIG.get('backup_keep') or 14)
        for f in sorted(directory.glob('zigmon-db-*.sqlite'))[:-keep]:
            f.unlink()
        self.store.add_event('control', 'database backed up: %s (%.1f MB)' % (target.name, size / 1048576.0))
        log('database backed up to %s' % target)
        return {'file': target.name, 'bytes': size}

    BACKUP_NAME = r'^zigmon-db-[0-9A-Za-z._-]+\.sqlite$'

    def db_backup_path(self, filename):
        if not re.match(self.BACKUP_NAME, str(filename)) or '..' in str(filename):
            raise ValueError('not a database backup file name')
        path = self.backup_dir() / str(filename)
        return path

    def db_backup_delete(self, filename):
        path = self.db_backup_path(filename)
        if not path.exists():
            raise ValueError('no such backup')
        path.unlink()
        self.store.add_event('control', 'database backup deleted: %s' % path.name)
        return path.name

    def db_backup_upload(self, filename, part, of, data_b64, upload_id):
        """A backup file arrives in base64 pieces (so no web-server body limit
        gets in the way); the last piece is checked to be a healthy SQLite
        file before it is allowed into the folder."""
        import base64, sqlite3
        name = re.sub(r'[^0-9A-Za-z._-]', '-', str(filename or ''))[:80]
        if not name.endswith('.sqlite'):
            name = name.rsplit('.', 1)[0] + '.sqlite' if '.' in name else name + '.sqlite'
        if not name.startswith('zigmon-db-'):
            name = 'zigmon-db-' + name
        if not re.match(self.BACKUP_NAME, name):
            raise ValueError('cannot make a safe file name out of that')
        uid = re.sub(r'[^0-9A-Za-z]', '', str(upload_id or ''))[:32]
        if not uid:
            raise ValueError('missing upload id')
        directory = self.backup_dir()
        directory.mkdir(exist_ok=True)
        tmp = directory / ('.upload-%s.part' % uid)
        part, of = int(part), int(of)
        if part < 1 or of < 1 or part > of or of > 4000:
            raise ValueError('bad part numbers')
        with open(tmp, 'ab' if part > 1 else 'wb') as fh:
            fh.write(base64.b64decode(data_b64 or ''))
        if tmp.stat().st_size > 2 * 1024 ** 3:
            tmp.unlink()
            raise ValueError('too large')
        if part < of:
            return {'received': part, 'of': of}
        with open(tmp, 'rb') as fh:
            magic = fh.read(16)
        if magic != b'SQLite format 3\x00':
            tmp.unlink()
            raise ValueError('that is not an SQLite database file')
        conn = sqlite3.connect(str(tmp))
        try:
            check = conn.execute('PRAGMA integrity_check').fetchone()[0]
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            conn.close()
        if check != 'ok':
            tmp.unlink()
            raise ValueError('the file fails SQLite\'s integrity check: %s' % check)
        if not {'samples', 'events', 'meta'} <= tables:
            tmp.unlink()
            raise ValueError('that SQLite file is not a zigmon database')
        target = directory / name
        n = 1
        while target.exists():
            n += 1
            target = directory / (name[:-7] + '-%d.sqlite' % n)
        tmp.rename(target)
        size = target.stat().st_size
        self.store.add_event('control', 'database backup uploaded: %s (%.1f MB)' % (target.name, size / 1048576.0))
        return {'file': target.name, 'bytes': size, 'received': part, 'of': of}

    def db_restore(self, filename):
        source = self.db_backup_path(filename)
        if not source.exists():
            raise ValueError('no such backup')
        pre = self.db_backup_now('-before-restore')   # the state right before, in case this was a mistake
        self.store.restore_from(source)
        self.rule_runtime.clear()
        self._energy_closed.clear()
        self._energy_summary = None
        self.parents = {}
        self.reload_devices()
        self.store.add_event('control', 'database restored from %s (previous state kept as %s)' % (filename, pre['file']), 'warn')
        log('database restored from %s' % filename, 'warn')
        self.bump()
        return {'restored': filename, 'previous_saved_as': pre['file']}

    def run_backup(self):
        """The daily backup: the dashboard settings as JSON, and (when asked)
        Zigbee2MQTT's own coordinator backup - the file that lets a dead stick
        be replaced without repairing every device."""
        directory = self.backup_dir()
        directory.mkdir(exist_ok=True)
        stamp_day = time.strftime('%Y-%m-%d')
        target = directory / ('zigmon-settings-%s.json' % stamp_day)
        made = []
        if not target.exists():
            target.write_text(json.dumps(self.export_settings(), indent=1))
            made.append(target.name)
        if int(CONFIG.get('backup_zigbee') or 0) and self.connected and self.client \
                and self.bridge.get('state') == 'online' \
                and not (directory / ('zigbee2mqtt-%s.zip' % stamp_day)).exists():
            self.client.publish(CONFIG['base_topic'].rstrip('/') + '/bridge/request/backup', '{}', qos=1)
        keep = int(CONFIG.get('backup_keep') or 14)
        for pattern in ('zigmon-settings-*.json', 'zigbee2mqtt-*.zip'):
            for f in sorted(directory.glob(pattern))[:-keep]:
                f.unlink()
        if made:
            log('backed up: %s' % ', '.join(made))
            self.store.add_event('control', 'backup written: ' + ', '.join(made))

    def handle_zigbee_backup(self, payload):
        data = (payload.get('data') or {}) if isinstance(payload, dict) else {}
        blob = data.get('zip')
        if not blob:
            return
        try:
            import base64
            directory = self.backup_dir()
            directory.mkdir(exist_ok=True)
            target = directory / ('zigbee2mqtt-%s.zip' % time.strftime('%Y-%m-%d'))
            target.write_bytes(base64.b64decode(blob))
            log('Zigbee2MQTT coordinator backup written to %s' % target)
            self.store.add_event('control', 'Zigbee2MQTT backup written: ' + target.name)
        except Exception as e:
            log('zigbee backup: %s' % e, 'warn')

    def backup_loop(self):
        while getattr(self, '_stop', None) is None:
            time.sleep(0.5)                  # the constructor is still at work
        last_day = None
        while not self._stop.wait(300):
            try:
                if not int(CONFIG.get('backup_enabled') or 0):
                    continue
                lt = time.localtime()
                when = str(CONFIG.get('backup_time') or '03:30')
                due = lt.tm_hour * 60 + lt.tm_min >= int(when[:2]) * 60 + int(when[3:])
                today = time.strftime('%Y-%m-%d')
                if due and last_day != today:
                    last_day = today
                    self.run_backup()
            except Exception as e:
                log('backup: %s' % e, 'warn')

    def request_networkmap(self):
        """Ask Zigbee2MQTT for the raw map. The answer tells us which router
        or coordinator each device is actually talking through."""
        if not self.connected or not self.client or self.bridge.get('state') != 'online':
            return
        topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/networkmap'
        try:
            self.client.publish(topic, json.dumps({'type': 'raw', 'routes': False}), qos=0)
            log('network map requested', 'debug')
        except Exception as e:
            log('network map request: %s' % e, 'warn')

    def refresh_networkmap(self, wait=90.0):
        """Ask for the map now and wait for the answer. A scan walks the whole
        mesh, so it takes a while and battery devices answer slowly."""
        if not self.connected or not self.client:
            return {'ok': False, 'error': 'not connected to the broker'}
        if self.bridge.get('state') != 'online':
            return {'ok': False, 'error': 'the Zigbee2MQTT bridge is not online'}
        before = self._map_stamp
        started = time.time()
        self.request_networkmap()
        while time.time() - started < wait:
            if self._stop.wait(0.25):
                break
            if self._map_stamp != before:
                return {'ok': True, 'relations': len(self.parents),
                        'seconds': round(time.time() - started, 1)}
        return {'ok': False, 'relations': len(self.parents),
                'seconds': round(time.time() - started, 1),
                'error': 'Zigbee2MQTT did not answer within %ds - a scan of a large mesh can take '
                         'longer, and the daemon will still record it when it arrives' % int(wait)}

    def handle_networkmap(self, payload):
        value = ((payload.get('data') or {}).get('value')) if isinstance(payload, dict) else None
        if not isinstance(value, dict):
            return
        nodes = {n.get('ieeeAddr'): n for n in value.get('nodes') or [] if isinstance(n, dict)}
        parents = {}
        siblings = {}          # router -> its strongest neighbour; routers have no parent
        for link in value.get('links') or []:
            if not isinstance(link, dict):
                continue
            source = link.get('sourceIeeeAddr') or (link.get('source') or {}).get('ieeeAddr')
            target = link.get('targetIeeeAddr') or (link.get('target') or {}).get('ieeeAddr')
            if not source or not target:
                continue
            relationship = link.get('relationship')
            lqi = link.get('linkquality') or link.get('lqi')
            # In the scanned device's neighbour table: 1 = the neighbour is its
            # child, 0 = the neighbour is its parent.
            if relationship == 1:
                parents[source] = {'parent': target, 'lqi': lqi}
            elif relationship == 0:
                parents.setdefault(target, {'parent': source, 'lqi': lqi})
            elif relationship == 2:
                # Two routers are siblings, never parent and child. The mesh
                # still reaches one through the other, so remember the best
                # of them - otherwise a mains-powered router shows no route
                # at all, which is exactly the thing worth knowing.
                for near, far in ((source, target), (target, source)):
                    best = siblings.get(near)
                    if best is None or (lqi or 0) > best['lqi']:
                        siblings[near] = {'parent': far, 'lqi': lqi or 0}
        now = int(time.time())
        coord = self.bridge.get('coordinator_ieee')

        def as_known(addr):
            """The coordinator has no device row under its own address; ours
            is the gateway record, and that is the one with its name on it."""
            return 'gw:coordinator' if coord and addr == coord else addr

        table = {}
        for ieee, info in parents.items():
            node = nodes.get(info['parent']) or {}
            table[as_known(ieee)] = {'parent': as_known(info['parent']),
                                     'parent_type': node.get('type') or '',
                                     'lqi': info['lqi'], 'ts': now}
        for ieee, info in siblings.items():
            if as_known(ieee) in table or (nodes.get(ieee) or {}).get('type') == 'Coordinator':
                continue
            node = nodes.get(info['parent']) or {}
            table[as_known(ieee)] = {'parent': as_known(info['parent']),
                                     'parent_type': node.get('type') or '',
                                     'lqi': info['lqi'], 'ts': now, 'relation': 'neighbour'}
        self.parents = table
        self._map_stamp = time.time()
        self.store.set_meta('parents', json.dumps(table))
        log('network map: %d parent relation(s)' % len(table))
        self.bump()

    def check_rule_for(self):
        """A "must hold for N s" rule whose source went quiet still fires once
        the stretch is long enough - no motion for ten minutes IS the event."""
        now = time.time()
        for r in self.rules():
            wait_s = int(r.get('for_s') or 0)
            if not wait_s or not r.get('enabled', True) or not self.rule_window_active(r):
                continue
            rt = self.rule_runtime.get(r['id'])
            if not rt or rt.get('holds') is not True or 'since' not in rt:
                continue
            if now - rt['since'] < wait_s or rt.get('for_fired') == rt['since']:
                continue
            if now - rt['fired'] < int(r.get('cooldown_s') or 0):
                continue
            if self._rate_limited(r, rt):
                continue
            rt['fired'] = now
            rt['for_fired'] = rt['since']
            origin = '%s %s held %d s (now %s)' % (
                self.store.resolve(r['device']) and (self.store.device(r['device']) or {}).get('name', r['device']) or r['device'],
                '%s %s %g' % (r['key'], r['op'], r['value']), wait_s,
                '%g' % rt['reading'] if rt.get('reading') is not None else '?')
            for target in self._binding_targets(r['plug']):
                pretty = self.target_label(r['plug'])
                log('rule (held): %s -> %s %s' % (origin, pretty, r['do']))
                self.store.add_event('rule', '%s: %s %s' % (origin, pretty, r['do']), 'info', r['device'])
                self._fire_target(target, r['do'], 'rule: ' + origin, r.get('pulse_ms'), honour_hold=True)

    def check_rule_windows(self):
        """Once a minute: notice windows opening and closing. Closing can put
        the plug into a safe state - a motion-driven light does not stay on
        into the morning just because nobody walked past at the boundary."""
        for r in self.rules():
            if not r.get('enabled', True) or not r.get('from'):
                continue
            active = self.rule_window_active(r)
            rt = self.rule_runtime.setdefault(r['id'], {'holds': None, 'fired': 0.0, 'reading': None})
            was = rt.get('window')
            rt['window'] = active
            if was is None or was == active:
                continue
            rt['holds'] = None               # a fresh edge inside the new window fires again
            what = r.get('window_end') if not active else None
            self.store.add_event('rule', 'window %s: %s %s %g -> %s%s' % (
                'opened' if active else 'closed', r['key'], r['op'], r['value'], r['plug'],
                (' (switching %s)' % what) if what else ''), 'info')
            if active or what not in ('off', 'on'):
                continue
            for target in self._binding_targets(r['plug']):
                if target[0] in ('scene', 'seq', 'seqreset'):
                    continue                 # a scene/sequence has no "off"; leave it be
                log('rule window closed: %s -> %s' % (self.target_label(r['plug']), what))
                self._fire_target(target, what, 'the rule window closing', honour_hold=True)

    def timer_loop(self):
        """The clock-driven side of the rules, on a thread of its own with a
        half-second beat: "must hold for N s" rules fire the second the stretch
        is long enough, schedules at the minute they name. These used to ride
        on the plug poll loop every 30 s - which also meant a slow plug round
        pushed a 07:00 schedule to 07:01."""
        last_windows = 0.0
        while not self._stop.wait(0.5):
            try:
                if time.time() - last_windows >= 10:
                    last_windows = time.time()
                    self.check_rule_windows()
                # a gated "for N s" rule may ask the Wi-Fi first; that wait
                # belongs on the presence worker, not on the clock
                if not self._rule_queue_gated:
                    self._rule_queue_gated.append(('__for__', None, None))
                    self._rule_kick_gated.set()
                self.check_schedules()
                if time.time() - getattr(self, '_heat_at', 0) >= 30:
                    self._heat_at = time.time()
                    self.heating_apply()
                    self.monthly_summary()
            except Exception as e:
                log('timers: %s' % e, 'error')

    def plug_loop(self):
        last_map = time.time() - max(0, int(CONFIG.get('networkmap_interval') or 0)) + 45
        while not self._stop.is_set():
            interval = int(CONFIG.get('networkmap_interval') or 0)
            if interval > 0 and time.time() - last_map >= interval:
                last_map = time.time()
                self.request_networkmap()
            if not self.plugs and not self.sensors:
                self._stop.wait(5)
                continue
            # every box in parallel: the pacing gap is per host, so five plugs
            # on five addresses take as long as one - not five times as long
            # (a round used to eat most of the poll interval, and a restart
            # showed "waiting for the first reading" for 15-20 s)
            # one job per BOX, not per relay: the channels of a strip share
            # one device and are read in a single request
            groups = {}
            for p in self.plugs.values():
                groups.setdefault(str(p.cfg.get('host') or p.name), []).append(p)
            jobs = []
            for host, members in groups.items():
                if len(members) > 1:
                    jobs.append((lambda ms=members: self.poll_plug_group(ms), members[0], 'strip'))
                else:
                    jobs.append((lambda m=members[0]: self.poll_plug(m), members[0], 'plug'))
            jobs += [(lambda s=s: self.poll_sensor(s), s, 'sensor') for s in self.sensors.values()]
            round_started = time.time()
            interval = max(2, int(CONFIG.get('plug_poll_interval') or 15))
            # Spread the boxes over the first half of the round instead of
            # asking all of them in the same instant. A dozen threads parsing
            # a dozen answers at once contend for the interpreter, and that
            # showed up as a 100 ms hiccup on the broker thread every round.
            # One request in flight at a time costs nothing in freshness.
            gap = (interval * 0.5) / max(1, len(jobs))
            threads = []
            for i, (fn, dev, kind) in enumerate(jobs):
                if self._stop.is_set():
                    break
                if i and gap > 0.05:
                    self._stop.wait(gap)
                def run(fn=fn, dev=dev, kind=kind):
                    try:
                        fn()
                    except Exception as e:      # never let one box stop the others
                        log('%s %s: %s' % (kind, dev.name, e), 'error')
                t = threading.Thread(target=run, name='poll-' + dev.name, daemon=True)
                t.start()
                threads.append(t)
            for t in threads:
                t.join(60)
            self._stop.wait(max(0.5, interval - (time.time() - round_started)))

    def poll_plug(self, p, force=False):
        """Read one plug and record it."""
        now = time.time()
        if not force and (now - p.last_poll < int(CONFIG.get('plug_poll_interval') or 15)
                          or now < p.backoff_until):
            return p
        p.last_poll = now
        rpc = p.rpc()
        try:
            switch = rpc.switch_status()
            # System, Wi-Fi and cloud sections change slowly and cost a whole
            # extra request; a Gen3 plug answers 429 when asked too often.
            if now - p.last_device_status >= 60 or not p.device_status:
                p.device_status = rpc.device_status()
                p.last_device_status = now
            if not p.info:
                p.info = rpc.device_info()
                self.store.set_meta('plug_info_' + p.name, json.dumps(p.info))
        except PlugError as e:
            self._plug_poll_failed(p, e, now, rpc)
            return p
        self._plug_poll_recovered(p)
        p.failures = 0
        p.error = None
        p.backoff_until = 0.0

        return self._record_plug(p, switch, p.device_status, now)

    def _record_plug(self, p, switch, device_status, now):
        """Turn one switch section (plus the box-wide sections) into the
        recorded state. Shared by the single-plug poll and the one-request
        poll of a multi-channel strip."""
        flat = {}
        for k, v in flatten(switch).items():
            if k in ('id', 'source') or k.startswith('aenergy.by_minute') or k.startswith('ret_aenergy.by_minute'):
                continue
            flat['switch.' + k] = v
        dev = flatten(device_status)
        for k in ('wifi.rssi', 'wifi.sta_ip', 'wifi.ssid', 'sys.uptime', 'sys.ram_free',
                  'cloud.connected', 'mqtt.connected'):
            if k in dev:
                flat[k] = dev[k]
        output = 1 if switch.get('output') else 0
        changed = p.output is None or output != p.output
        if p.output is not None and output != p.output:
            self.store.add_event('plug', 'switched %s' % ('on' if output else 'off'),
                                 'info', p.device_id)
        p.output = output
        p.flat = flat
        p.generated = int(now)

        values = {}
        for k in ('switch.output', 'switch.apower', 'switch.voltage', 'switch.current', 'switch.pf',
                  'switch.freq', 'switch.aenergy.total', 'switch.ret_aenergy.total',
                  'switch.temperature.tC', 'switch.counts.on_time', 'switch.counts.switch_on',
                  'switch.counts.on_above_thr', 'wifi.rssi', 'sys.uptime'):
            v = numeric(flat.get(k)) if k in flat else None
            if v is not None:
                values[k] = v
        if values and now - p.last_sample >= int(CONFIG.get('plug_sample_interval') or 60):
            self.store.store_sample(p.device_id, int(now), values)
            p.last_sample = now
        if values:
            self.queue_rules(p.device_id, p.name, values)
        self.store.store_snapshot(p.device_id, int(now), flat, 'online')
        self.store.touch_device(p.device_id, int(now))
        info = p.info or {}
        self.store.upsert_device({
            'id': p.device_id, 'name': p.name, 'source': 'plug', 'kind': 'wifi', 'vendor': 'Shelly',
            'model': info.get('model'),
            'description': ' '.join(x for x in (info.get('app'), info.get('ver')) if x) or None,
            'exposes': {k: {'label': key_label(k), 'unit': key_unit(k), 'description': PLUG_DESCRIPTIONS.get(k, '')}
                        for k in flat},
        })
        self.live[p.device_id] = {'payload': flat, 'ts': int(now), 'availability': 'online'}
        if changed:
            self.bump()
        return p

    def poll_plug_group(self, plugs, force=False):
        """Every channel of one multi-relay box in a single request. Asking
        per channel meant a four-way strip answered thirteen requests a round
        and, with the pacing between them, was busy with its own polling most
        of the time - so a click on it had to queue behind that."""
        now = time.time()
        due = [p for p in plugs
               if force or (now - p.last_poll >= int(CONFIG.get('plug_poll_interval') or 15)
                            and now >= p.backoff_until)]
        if not due:
            return plugs
        lead = due[0]
        for p in due:
            p.last_poll = now
        rpc = lead.rpc()
        try:
            full = rpc.call('Shelly.GetStatus') or {}
            if now - lead.last_device_status >= 60 or not lead.device_status:
                lead.device_status = full
                lead.last_device_status = now
            if not lead.info:
                lead.info = rpc.device_info()
                self.store.set_meta('plug_info_' + lead.name, json.dumps(lead.info))
        except PlugError as e:
            for p in due:
                self._plug_poll_failed(p, e, now, rpc)
            return plugs
        for p in due:
            switch = full.get('switch:%d' % int(p.cfg.get('switch_id') or 0))
            if not isinstance(switch, dict):
                continue
            self._plug_poll_recovered(p)          # was missing for strips: no "restored" event, no wake
            p.failures = 0
            p.error = None
            p.backoff_until = 0.0
            p.info = p.info or lead.info
            try:
                self._record_plug(p, switch, full, now)
            except Exception as e:
                log('plug %s: %s' % (p.name, e), 'error')
        return plugs

    def _plug_poll_failed(self, p, e, now, rpc):
        p.failures += 1
        p.error = str(e)
        if p.failures == 3:
            if p.optional:
                # expected for this one: note it quietly, no warning, no notification
                log('%s is not answering - treated as unplugged (optional device)' % p.name)
            else:
                self.store.add_event('plug', 'lost contact: %s' % e, 'warn', p.device_id)
            self.store.store_snapshot(p.device_id, int(now), {}, 'offline')
            self.bump()
        if '429' in str(e):
            p.backoff_until = now + max(getattr(rpc, 'retry_after', 0) or 0, 60)
            log('%s is rate limiting; backing off for %ds' % (p.name, int(p.backoff_until - now)),
                'warn' if p.failures == 3 and not p.optional else 'debug')
        else:
            log('plug %s poll failed: %s' % (p.name, e),
                'warn' if p.failures <= 3 and not p.optional else 'debug')

    def _plug_poll_recovered(self, p):
        if p.failures >= 3:
            if p.optional:
                log('%s is answering again (optional device back on)' % p.name)
            else:
                self.store.add_event('plug', 'contact restored', 'info', p.device_id)
            self.bump()

    def plug_snapshot(self, p):
        """What the dashboard needs about one plug."""
        now = time.time()
        stale = p.error is not None
        flat = p.flat
        if not flat:
            snap = self.live.get(p.device_id) or {}
            flat = snap.get('payload') or {}
            generated = snap.get('ts')
        else:
            generated = p.generated
        counters = []
        for c in PLUG_COUNTERS:
            value = numeric(flat.get('switch.' + c['field'])) if ('switch.' + c['field']) in flat else None
            reset_at, exact = self._counter_reset_at(p, flat, c['type'])
            counters.append(dict(c, value=value, reset_at=reset_at, reset_exact=exact))
        return {
            'name': p.name, 'id': p.device_id, 'host': p.cfg.get('host'),
            'online': bool(flat), 'stale': stale or not p.flat,
            'error': p.error if stale else (None if p.flat else 'waiting for the first reading'),
            'generated': generated, 'age': int(now - generated) if generated else None,
            'retry_in': int(p.backoff_until - now) if p.backoff_until > now else None,
            'output': (1 if flat.get('switch.output') else 0) if 'switch.output' in flat else None,
            'monitor_only': bool(p.cfg.get('monitor_only')),
            'role': str(p.cfg.get('role') or 'plug'),
            'optional': p.optional,
            'unplugged': p.unplugged,
            'values': {
                'power': numeric(flat.get('switch.apower')) if 'switch.apower' in flat else None,
                'voltage': numeric(flat.get('switch.voltage')) if 'switch.voltage' in flat else None,
                'current': numeric(flat.get('switch.current')) if 'switch.current' in flat else None,
                'pf': numeric(flat.get('switch.pf')) if 'switch.pf' in flat else None,
                'freq': numeric(flat.get('switch.freq')) if 'switch.freq' in flat else None,
                'energy': numeric(flat.get('switch.aenergy.total')) if 'switch.aenergy.total' in flat else None,
                'temperature': numeric(flat.get('switch.temperature.tC')) if 'switch.temperature.tC' in flat else None,
                'on_time': numeric(flat.get('switch.counts.on_time')) if 'switch.counts.on_time' in flat else None,
                'switch_on': numeric(flat.get('switch.counts.switch_on')) if 'switch.counts.switch_on' in flat else None,
                'rssi': numeric(flat.get('wifi.rssi')) if 'wifi.rssi' in flat else None,
                'uptime': numeric(flat.get('sys.uptime')) if 'sys.uptime' in flat else None,
            },
            'info': p.info or {},
            'counters': counters,
        }

    def _counter_reset_at(self, p, flat, counter):
        reported = numeric(flat.get('switch.' + PLUG_RESET_FIELDS[counter], None)) \
            if ('switch.' + PLUG_RESET_FIELDS[counter]) in flat else None
        if reported and reported > 1000000000:
            return int(reported), True
        remembered = self.store.get_meta('plug_reset_%s_%s' % (p.name, counter))
        if remembered:
            return int(float(remembered)), True
        return None, False

    def plug_by_name(self, name):
        p = self.plugs.get(str(name or ''))
        if p is None:
            for candidate in self.plugs.values():
                if candidate.device_id == name or candidate.name.lower() == str(name or '').lower():
                    return candidate
        return p

    @staticmethod
    def _monitor_guard(p):
        if p is not None and bool(p.cfg.get('monitor_only')):
            return False, '%s is monitor-only: watched, recorded, never switched from here' % p.name
        return True, ''

    def _plug_switched(self, p, on, origin):
        """The relay just obeyed: show it at once, confirm the numbers later.
        The dashboard repaints on this bump; the power/energy figures follow
        from a background poll a moment later, without anyone waiting for it."""
        p.output = 1 if on else 0           # so the confirming poll does not log it again
        if p.flat is not None:
            p.flat['switch.output'] = bool(on)
        entry = self.live.get(p.device_id)
        if entry:
            entry['ts'] = int(time.time())
        self.store.add_event('plug', 'switched %s from %s' % ('on' if on else 'off', origin),
                             'info', p.device_id)
        log('%s switched %s (%s)' % (p.name, 'on' if on else 'off', origin))
        self.bump()
        threading.Thread(target=self._confirm_poll, args=(p,), name='confirm', daemon=True).start()

    def _confirm_poll(self, p):
        try:
            self.poll_plug(p, force=True)
        except Exception as e:
            log('%s: confirming poll failed: %s' % (p.name, e), 'debug')

    def set_plug_output(self, p, on, origin='the dashboard'):
        ok, message = self._monitor_guard(p)
        if not ok:
            log('refused (%s): %s' % (origin, message), 'debug')
            return False, message
        try:
            p.rpc().set_output(on)
        except PlugError as e:
            self.store.add_event('plug', 'switch %s failed: %s' % ('on' if on else 'off', e), 'warn', p.device_id)
            return False, str(e)
        self._plug_switched(p, on, origin)
        return True, '%s switched %s' % (p.name, 'on' if on else 'off')

    def pulse_plug(self, p, ms, origin='the dashboard'):
        ok, message = self._monitor_guard(p)
        if not ok:
            return False, message
        """Flip the relay, hold for ms, flip it back: off-wait-on when it is on, on-wait-off when off."""
        ms = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(ms or PULSE_MS_DEFAULT)))
        fresh = p.output in (0, 1) and p.flat and not p.failures and p.generated \
            and time.time() - p.generated < int(CONFIG.get('plug_poll_interval') or 15) * 2
        if fresh:
            state = bool(p.output)          # fresh from the last poll or push: no extra round trip
        else:
            try:
                state = bool(p.rpc().switch_status().get('output'))
            except PlugError as e:
                return False, str(e)
        with p.pulse_lock:
            if p.pulsing:
                return False, '%s is already in a pulse' % p.name
            p.pulsing = True
        try:
            try:
                p.rpc().set_output(not state)
            except PlugError as e:
                self.store.add_event('plug', 'pulse failed: %s' % e, 'warn', p.device_id)
                return False, str(e)
            p.output = 0 if state else 1
            self.store.add_event('plug', 'pulse: switched %s for %s from %s' % (
                'off' if state else 'on', '%.1f s' % (ms / 1000.0), origin), 'info', p.device_id)
            self.bump()
            log('%s pulse: %s for %d ms (%s)' % (p.name, 'off' if state else 'on', ms, origin))
            self.poll_plug(p, force=True)
            self._stop.wait(ms / 1000.0)
            last = None
            for attempt in range(3):          # the way back must not be lost
                try:
                    p.rpc().set_output(state)
                    last = None
                    break
                except PlugError as e:
                    last = e
                    time.sleep(1.0)
            if last is not None:
                self.store.add_event('plug', 'pulse: could not switch back %s: %s' % ('on' if state else 'off', last),
                                     'crit', p.device_id)
                log('%s pulse: switching back failed: %s' % (p.name, last), 'error')
                return False, 'pulse sent, but switching back failed: %s' % last
            p.output = 1 if state else 0
            self.store.add_event('plug', 'pulse: back %s' % ('on' if state else 'off'),
                                 'info' if state else 'warn', p.device_id)
            self.poll_plug(p, force=True)
            self.bump()
            return True, '%s pulsed %s for %.1f s and is back %s' % (
                p.name, 'off' if state else 'on', ms / 1000.0, 'on' if state else 'off')
        finally:
            p.pulsing = False

    def toggle_plug(self, p, origin='the dashboard'):
        ok, message = self._monitor_guard(p)
        if not ok:
            return False, message
        try:
            reply = p.rpc().toggle_output() or {}
        except PlugError as e:
            self.store.add_event('plug', 'toggle failed: %s' % e, 'warn', p.device_id)
            return False, str(e)
        on = not bool(reply.get('was_on'))
        self._plug_switched(p, on, origin)
        return True, '%s switched %s' % (p.name, 'on' if on else 'off')

    def read_plug_counters(self, p, attempts=2):
        last = None
        for _ in range(attempts):
            try:
                flat = flatten(p.rpc().switch_status())
                break
            except PlugError as e:
                last = e
                time.sleep(1.5)
        else:
            raise last or PlugError('could not read the counters')
        return {c['type']: numeric(flat.get(c['field'])) if c['field'] in flat else None
                for c in PLUG_COUNTERS}

    def reset_plug_counters(self, p, types=None):
        """Reset counters and check they actually moved - the plug says OK regardless."""
        wanted = [t for t in (types or []) if t in PLUG_COUNTER_TYPES]
        try:
            before = self.read_plug_counters(p)
        except PlugError as e:
            return False, 'could not read the counters first: %s' % e
        try:
            p.rpc().reset_counters(wanted or None)
        except PlugError as e:
            return False, str(e)
        time.sleep(1.0)
        try:
            after = self.read_plug_counters(p)
        except PlugError as e:
            self.store.add_event('plug', 'reset requested but the result could not be checked: %s' % e,
                                 'warn', p.device_id)
            return True, 'the reset was sent, but the plug did not answer when asked to confirm it'
        checked = wanted or PLUG_COUNTER_TYPES
        labels = {c['type']: c['label'] for c in PLUG_COUNTERS}
        cleared, unchanged, already = [], [], []
        for counter in checked:
            was, now = before.get(counter), after.get(counter)
            if was is None and now is None:
                continue
            if now is not None and now == 0:
                (already if was in (0, None) else cleared).append(labels[counter])
            elif was is not None and now is not None and now < was:
                cleared.append(labels[counter])
            else:
                unchanged.append(labels[counter])
        stamped = int(time.time())
        for counter in checked:
            if labels[counter] in cleared:
                self.store.set_meta('plug_reset_%s_%s' % (p.name, counter), stamped)
        self.poll_plug(p, force=True)
        if cleared:
            message = 'reset ' + ', '.join(c.lower() for c in cleared)
            if unchanged:
                message += '; the plug did not clear ' + ', '.join(u.lower() for u in unchanged)
            self.store.add_event('plug', message, 'info', p.device_id)
            return True, message
        if already and not unchanged:
            return True, ', '.join(a.lower() for a in already) + ' was already at zero'
        message = ('the plug accepted the request but nothing changed: '
                   + ', '.join(u.lower() for u in unchanged or checked)
                   + '. This firmware may not support resetting those.')
        self.store.add_event('plug', message, 'warn', p.device_id)
        return False, message

    def rename_device(self, device_id, new_name):
        """A Zigbee device is renamed in Zigbee2MQTT itself, so the name holds
        everywhere; anything else gets a dashboard alias. Bindings and rules
        keep working either way - they store the id, not the name."""
        dev = self.store.device(device_id)
        if dev is None:
            raise ValueError('unknown device')
        new_name = str(new_name or '').strip()
        if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', new_name):
            raise ValueError('letters, digits, space, dot, dash and underscore only')
        if dev['source'] in ('plug',) or device_id.startswith('sensor:'):
            raise ValueError('this one is named in "Plugs and sensors"; rename it there')
        old = dev.get('alias') or dev['name']
        if dev['source'] == 'zigbee':
            if not self.connected or not self.client:
                raise RuntimeError('not connected to the broker')
            topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/device/rename'
            info = self.client.publish(topic, json.dumps({'from': dev['name'], 'to': new_name}), qos=1)
            if hasattr(info, 'rc') and info.rc != 0:
                raise RuntimeError('publish failed (%s) - check the broker ACL for %s' % (info.rc, topic))
            # Zigbee2MQTT confirms via bridge/devices; the row is updated now so
            # the dashboard does not flicker with the old name meanwhile.
            self.store.upsert_device({'id': device_id, 'name': new_name, 'source': dev['source']})
            message = 'renamed to %s (in Zigbee2MQTT, so the MQTT topic follows)' % new_name
        else:
            self.store.set_alias(device_id, new_name)
            message = 'renamed to %s on this dashboard (the MQTT name stays %s)' % (new_name, dev['name'])
        self.store.add_event('device', 'renamed %s -> %s' % (old, new_name), 'info', device_id)
        log('device %s %s' % (old, message))
        self.bump()
        return message

    def forget_device_cleanup(self, device_id, name):
        """Take the deleted device out of the bindings and rules that use it as
        the source - unless it is a managed plug or sensor, which comes right
        back. Plugs used as *targets* stay: the plug itself was not deleted."""
        if any(device_id == 'plug:' + e['name'] for e in self.all_entries('plugs')) \
                or any(device_id == 'sensor:' + e['name'] for e in self.all_entries('sensors')):
            return []
        dropped = []
        keep = []
        for b in self.bindings():
            if b['device'] in (device_id, name):
                dropped.append('binding: %s %s -> %s %s' % (name, b['action'], b['plug'], b['do']))
            else:
                keep.append(b)
        if dropped:
            self.store.set_meta('bindings', json.dumps(keep))
        keep = []
        rule_dropped = 0
        for r in self.rules():
            if r['device'] in (device_id, name):
                dropped.append('rule: %s %s %s %g -> %s %s' % (name, r['key'], r['op'], r['value'], r['plug'], r['do']))
                self.rule_runtime.pop(r['id'], None)
                rule_dropped += 1
            else:
                keep.append(r)
        if rule_dropped:
            self.store.set_meta('rules', json.dumps(keep))
        for line in dropped:
            self.store.add_event('control', 'removed with the device - ' + line, 'warn')
            log('removed with %s: %s' % (name, line))
        return dropped

    ARRANGEMENTS = {
        'overview': 'which cards the Overview shows and in what order',
        'wifi': 'the WiFi cards',
        'plugs': 'the plug cards',
        'sensors': 'the sensor cards',
        'buttons': 'the button cards',
        'devices': 'the device cards',
        'groups': 'the plug groups on the Overview',
    }

    def reset_arrangement(self, what):
        """Forget how somebody arranged one set of cards, so the default
        applies again. Nothing else about them changes: this is the order they
        are shown in, not what they are."""
        if what == 'all':
            done = []
            for name in self.ARRANGEMENTS:
                done.extend(self.reset_arrangement(name))
            return done
        if what not in self.ARRANGEMENTS:
            raise ValueError('%r is not one of: %s' % (what, ', '.join(sorted(self.ARRANGEMENTS))))
        if what == 'wifi':
            self.store.set_meta('wifi_order', json.dumps([]))
        elif what == 'overview':
            self.store.set_meta('overview_layout', json.dumps([]))
        else:
            order = self.overview_order()
            order[what] = {} if what == 'groups' else []
            self.store.set_meta('overview_order', json.dumps(order))
        self.store.add_event('control', 'the arrangement of %s was reset' % self.ARRANGEMENTS[what])
        self.bump()
        return [what]

    def overview_order(self):
        raw = self.store.get_meta('overview_order')
        if not raw:
            return {'plugs': [], 'devices': [], 'sensors': [], 'buttons': [], 'groups': {}}
        try:
            data = json.loads(raw)
        except ValueError:
            return {'plugs': [], 'devices': [], 'sensors': [], 'buttons': [], 'groups': {}}
        groups = data.get('groups') or {}
        if not isinstance(groups, dict):
            groups = {}
        return {'plugs': [str(x) for x in (data.get('plugs') or [])][:200],
                'devices': [str(x) for x in (data.get('devices') or [])][:200],
                'sensors': [str(x) for x in (data.get('sensors') or [])][:200],
                'buttons': [str(x) for x in (data.get('buttons') or [])][:200],
                'groups': {str(k): [str(x) for x in (v or [])][:50] for k, v in list(groups.items())[:100]}}

    def save_overview_order(self, plugs, devices, groups=None, sensors=None, buttons=None):
        def clean(items):
            out = []
            for x in items or []:
                x = str(x)[:80]
                if x and x not in out:
                    out.append(x)
            return out[:200]
        current = self.overview_order()
        order = {'plugs': clean(plugs) if plugs is not None else current['plugs'],
                 'devices': clean(devices) if devices is not None else current['devices'],
                 'sensors': clean(sensors) if sensors is not None else current['sensors'],
                 'buttons': clean(buttons) if buttons is not None else current['buttons']}
        if isinstance(groups, dict):
            order['groups'] = {str(k)[:80]: clean(v) for k, v in list(groups.items())[:100]}
        elif groups is not None and not groups:      # an empty PHP array arrives as [] - nothing to keep
            order['groups'] = {}
        else:
            order['groups'] = current.get('groups') or {}
        self.store.set_meta('overview_order', json.dumps(order))
        log('overview order saved: %d plug(s), %d card(s)' % (len(order['plugs']), len(order['devices'])))
        self.bump()
        return order

    # -- one file with everything the dashboard configured ------------------------
    def export_settings(self):
        aliases = {d['id']: d['alias'] for d in self.store.devices(include_removed=True) if d.get('alias')}
        return {'zigmon_export': __version__, 'exported_at': int(time.time()),
                'managed': self.managed(), 'bindings': self.bindings(), 'rules': self.rules(),
                'scenes': self.scenes(), 'schedules': self.schedules(), 'sequences': self.sequences(),
                'sequence_pos': self.sequence_positions(), 'order': self.overview_order(),
                'overview_layout': self.overview_layout(),
            'gateways': self.gateways_for_ui(),
                'people': self.people(), 'presence_triggers': self.presence_triggers(),
                'rooms': self.rooms(), 'room_of': self.room_map(), 'heating': self.heating_config(),
                'messages': self.alert_messages(),
            'alerts': self.active_alerts(),
            'holds': [dict(v, target=k, label=self.target_label(k))
                      for k, v in sorted(self.manual_holds().items())],
                'wifi': self.wifi_config(),
                'notify': self.notify_settings(), 'aliases': aliases}

    def import_settings(self, data):
        if not isinstance(data, dict) or 'zigmon_export' not in data:
            raise ValueError('this is not a zigmon export')
        counts = []
        if isinstance(data.get('managed'), dict):
            self.store.set_meta('managed', json.dumps(data['managed']))
            self.reload_devices()
            counts.append('%d device(s)' % (len(data['managed'].get('plugs') or []) + len(data['managed'].get('sensors') or [])))
        for key, label in (('bindings', 'binding(s)'), ('rules', 'rule(s)'), ('scenes', 'scene(s)'),
                           ('schedules', 'schedule(s)'), ('sequences', 'sequence(s)'),
                           ('people', 'person(s)'), ('presence_triggers', 'presence trigger(s)'),
                           ('rooms', 'room(s)'), ('messages', 'message(s)')):
            if isinstance(data.get(key), list):
                self.store.set_meta(key, json.dumps(data[key]))
                counts.append('%d %s' % (len(data[key]), label))
        if isinstance(data.get('order'), dict):
            self.store.set_meta('overview_order', json.dumps(data['order']))
        if isinstance(data.get('sequence_pos'), dict):
            self.store.set_meta('sequence_pos', json.dumps(data['sequence_pos']))
        if isinstance(data.get('overview_layout'), list):
            self.store.set_meta('overview_layout', json.dumps([str(x)[:80] for x in data['overview_layout']][:300]))
        if isinstance(data.get('room_of'), dict):
            self.store.set_meta('room_of', json.dumps({str(k): str(v) for k, v in data['room_of'].items()}))
        if isinstance(data.get('heating'), dict):
            self.store.set_meta('heating', json.dumps(data['heating']))
        if isinstance(data.get('notify'), dict):
            self.store.set_meta('notify', json.dumps(data['notify']))
        if isinstance(data.get('wifi'), dict):
            self.store.set_meta('wifi', json.dumps(data['wifi']))
            self._wifi_kick.set()
        for device_id, alias in (data.get('aliases') or {}).items():
            if self.store.device(device_id):
                self.store.set_alias(device_id, str(alias))
        self.rule_runtime.clear()
        self.store.add_event('control', 'settings imported: ' + (', '.join(counts) or 'nothing'))
        log('settings imported: %s' % (', '.join(counts) or 'nothing'))
        self.bump()
        return counts

    # -- energy: what each plug drank, and what it cost ---------------------------
    def energy_summary(self):
        now = time.time()
        lt = time.localtime(now)
        midnight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
        month_start = time.mktime((lt.tm_year, lt.tm_mon, 1, 0, 0, 0, 0, 0, -1))
        last_month_start = time.mktime((lt.tm_year - (1 if lt.tm_mon == 1 else 0),
                                        12 if lt.tm_mon == 1 else lt.tm_mon - 1, 1, 0, 0, 0, 0, 0, -1))
        year_start = time.mktime((lt.tm_year, 1, 1, 0, 0, 0, 0, 0, -1))
        last_year_start = time.mktime((lt.tm_year - 1, 1, 1, 0, 0, 0, 0, 0, -1))
        cached = self._energy_summary
        if cached and time.time() - cached[0] < 15:
            return cached[1]             # several tabs asking at once cost one pass
        price = numeric(CONFIG.get('price_per_kwh'))
        zero = self.energy_zero()
        out = []
        for p in self.plugs.values():
            base = zero.get(p.device_id) or 0

            def span(t0, t1, closed=False):
                if t1 <= base:
                    return 0.0
                start = max(t0, base)
                if not closed:
                    return self.store.counter_delta(p.device_id, 'switch.aenergy.total', start, t1)
                # yesterday, last month, last year: over and done with, and
                # answering them is most of the work in here
                key = (p.device_id, int(start), int(t1))
                if key not in self._energy_closed:
                    if len(self._energy_closed) > 4000:
                        self._energy_closed.clear()
                    self._energy_closed[key] = self.store.counter_delta(
                        p.device_id, 'switch.aenergy.total', start, t1)
                return self._energy_closed[key]
            row = {'name': p.name,
                   'role': str(p.cfg.get('role') or 'plug'),
                   'today_wh': span(midnight, now),
                   'yesterday_wh': span(midnight - 86400, midnight, True),
                   'month_wh': span(month_start, now),
                   'last_month_wh': span(last_month_start, month_start, True),
                   'year_wh': span(year_start, now),
                   'last_year_wh': span(last_year_start, year_start, True),
                   'zero_ts': int(base) or None}
            out.append(row)
        result = {'plugs': out, 'price_per_kwh': price, 'currency': CONFIG.get('currency') or ''}
        self._energy_summary = (time.time(), result)
        return result

    def energy_zero(self):
        try:
            data = json.loads(self.store.get_meta('energy_zero') or '{}')
        except ValueError:
            data = {}
        return {str(k): float(v) for k, v in data.items() if numeric(v)}

    def reset_energy_summary(self, plug_name):
        """Start the dashboard's energy sums from zero, now - for one plug or
        all of them. Recorded history and the plug's own meters stay."""
        zero = self.energy_zero()
        now = time.time()
        if plug_name == '*':
            names = []
            for p in self.plugs.values():
                zero[p.device_id] = now
                names.append(p.name)
            label = 'every plug' if names else 'nothing'
        else:
            p = self.plug_by_name(plug_name)
            if p is None:
                raise ValueError('unknown plug %r' % plug_name)
            zero[p.device_id] = now
            label = p.name
        self.store.set_meta('energy_zero', json.dumps(zero))
        self._energy_closed.clear()      # the periods are measured from a new zero
        self._energy_summary = None
        self.store.add_event('control', 'energy summary restarted from zero: %s' % label)
        log('energy summary zeroed: %s' % label)
        self.bump()
        return label

    # -- the curated Overview: any mix of plugs, sensors and buttons, freely chosen -
    def overview_layout(self):
        """None means "no custom layout yet" - the dashboard falls back to
        showing everything, so a fresh install looks exactly as before."""
        raw = self.store.get_meta('overview_layout')
        if raw is None:
            return None
        try:
            data = json.loads(raw)
        except ValueError:
            return None
        if not isinstance(data, list):
            return None
        return [str(x)[:80] for x in data][:300]

    def save_overview_layout(self, items):
        valid_ids = {d['id'] for d in self.store.devices()}
        out = []
        for x in items or []:
            x = str(x)[:80]
            if x and x in valid_ids and x not in out:
                out.append(x)
        self.store.set_meta('overview_layout', json.dumps(out))
        self.bump()
        return out

    # -- Zigbee gateways: read a SMLIGHT SLZB-06 (or similar) over the network --
    #
    # SLZB-06 / SLZB-OS exposes two documented, stable HTTP JSON endpoints
    # meant for exactly this kind of polling: /ha_info (identity, uptime,
    # network, socket state) and /ha_sensors (live sensor readings - board
    # temperature, RSSI, etc). Reference: smlight.tech/support/manuals ->
    # SLZB-OS -> "SLZB-OS API endpoints" -> "Home Assistant endpoints".
    # Field names below are the documented, intended-for-integration surface;
    # if a firmware version renames or adds fields, flatten() below still
    # captures them under their own key rather than dropping them, and
    # `zigmon gateway <name> dump` shows exactly what came back so a mismatch
    # is visible immediately rather than silently wrong.
    def managed_gateways(self):
        try:
            data = json.loads(self.store.get_meta('gateways') or '[]')
        except ValueError:
            data = []
        return [g for g in data if isinstance(g, dict)]

    def gateway_configs(self):
        """config.json entries first (read-only in the UI), then the ones
        added on the dashboard - same shape as plugs/sensors."""
        out, seen = [], set()
        for g in CONFIG.get('zigbee_gateways') or []:
            if isinstance(g, dict) and g.get('name') and g.get('host'):
                out.append(dict(g, source='config'))
                seen.add(str(g['name']))
        for g in self.managed_gateways():
            if g.get('name') and g.get('host') and str(g['name']) not in seen:
                out.append(dict(g, source='ui'))
                seen.add(str(g['name']))
        return out

    def gateways_for_ui(self):
        return [{'name': g['name'], 'host': g['host'], 'target': g.get('target') or 'coordinator',
                'username': g.get('username') or '', 'password_set': bool(g.get('password')),
                'model': g.get('model') or '', 'fw': g.get('fw') or '', 'kind': g.get('kind') or 'slzb',
                'source': g.get('source', 'ui')} for g in self.gateway_configs()]

    def save_managed_gateways(self, items):
        old = {str(g['name']): g for g in self.managed_gateways()}
        configured = {str(g.get('name')) for g in CONFIG.get('zigbee_gateways') or [] if isinstance(g, dict)}
        clean = []
        for index, g in enumerate(items or []):
            if not isinstance(g, dict):
                continue
            name = str(g.get('name') or '').strip()
            host = str(g.get('host') or '').strip()
            if not name or not host:
                raise ValueError('gateway %d needs a name and an address' % (index + 1))
            if name in configured:
                raise ValueError('%r is already in config.json - edit it there' % name)
            target = str(g.get('target') or 'coordinator').strip() or 'coordinator'
            username = str(g.get('username') or '').strip()
            password = g.get('password')
            if password is None or password == '':
                password = old.get(name, {}).get('password') or ''
            clean.append({'name': name[:80], 'host': host[:200], 'target': target[:80],
                          'username': username[:80], 'password': str(password)[:200],
                          'model': str(g.get('model') or old.get(name, {}).get('model') or '')[:60],
                          'fw': str(g.get('fw') or old.get(name, {}).get('fw') or '')[:40],
                          'kind': str(g.get('kind') or old.get(name, {}).get('kind') or 'slzb')[:20]})
        self.store.set_meta('gateways', json.dumps(clean))
        self.store.add_event('control', '%d Zigbee gateway(s) saved' % len(clean))
        self.bump()
        return clean

    def gateway_fetch(self, host, path, timeout=5.0, username='', password=''):
        import urllib.request, base64
        url = 'http://%s%s' % (host.rstrip('/'), path)
        headers = {'Accept': 'application/json'}
        if username or password:
            # SLZB-OS's optional "web server authentication" is plain HTTP
            # Basic Auth - the same credentials as its own web UI login.
            token = base64.b64encode(('%s:%s' % (username, password)).encode('utf-8')).decode('ascii')
            headers['Authorization'] = 'Basic ' + token
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8', 'replace')
        if path == '/metrics':
            return parse_prometheus_text(raw)
        return json.loads(raw)

    def detect_gateway(self, host, username='', password=''):
        """Say what sits at `host`: an SLZB-style box (HTTP JSON on /ha_info)
        or a Shelly Gen2+ device with its Zigbee component (JSON-RPC on /rpc,
        e.g. a Power Strip 4 Gen4 acting as a router) - tried in that order,
        since the SLZB path is a plain unauthenticated-by-default GET and the
        Shelly one always speaks first over a live socket either way."""
        host = str(host or '').strip()
        if not re.match(r'^[A-Za-z0-9.:\[\]-]+$', host):
            raise ValueError('not an address')
        try:
            return self._detect_gateway_slzb(host, username, password)
        except Exception as e_slzb:
            try:
                return self._detect_gateway_shelly(host, password)
            except Exception as e_shelly:
                # PlugError messages are already written to be read; prefer one
                # over a raw urllib/HTTP one when both paths came up empty
                if isinstance(e_shelly, PlugError) and not isinstance(e_slzb, PlugError):
                    raise e_shelly
                raise e_slzb

    def _detect_gateway_slzb(self, host, username, password):
        info = flatten(self.gateway_fetch(host, '/ha_info', username=username, password=password))
        try:
            sensors = flatten(self.gateway_fetch(host, '/ha_sensors', username=username, password=password))
        except Exception:
            sensors = {}
        def pick(*names):
            for n in names:
                for k, v in info.items():
                    if k.lower().endswith(n):
                        return v
            return None
        model = pick('model', 'hostname') or ''
        mode = pick('coord_mode', 'zb_type')
        radios = pick('radios')
        mode_text = ''
        if isinstance(radios, list) and radios and isinstance(radios[0], dict):
            zt = radios[0].get('zb_type')
            mode_text = {0: 'coordinator', 1: 'router', 2: 'thread'}.get(zt, '')
        if not mode_text and mode is not None:
            mode_text = 'coordinator' if str(mode) in ('1', 'True') else ''
        return {'host': host, 'kind': 'slzb', 'model': str(model), 'hostname': str(pick('hostname') or ''),
                'fw': str(pick('sw_version', 'fw_version') or ''), 'mac': str(pick('mac') or ''),
                'ip': str(pick('device_ip') or ''), 'zb_channel': pick('zb_channel'), 'zb_hw': str(pick('zb_hw') or ''),
                'mode': mode_text, 'uptime': pick('uptime'),
                'temp': next((v for k, v in sensors.items() if k.lower().endswith('esp32_temp')), None),
                'fields': len(info) + len(sensors)}

    def _detect_gateway_shelly(self, host, password):
        """A Shelly Gen2+ box with the Zigbee component: same local JSON-RPC
        API and digest auth already used for plugs (ShellyRPC), plus the
        Zigbee.GetConfig/GetStatus methods every such device answers."""
        rpc = ShellyRPC(host, password or '', 0, label='the device at %s' % host)
        info = rpc.call('Shelly.GetDeviceInfo') or {}
        zb_status, zb_config = {}, {}
        try:
            zb_status = rpc.call('Zigbee.GetStatus') or {}
        except PlugError:
            pass
        try:
            zb_config = rpc.call('Zigbee.GetConfig') or {}
        except PlugError:
            pass
        joined = str(zb_status.get('network_state') or '').lower() == 'joined'
        return {'host': host, 'kind': 'shelly', 'model': str(info.get('model') or info.get('app') or ''),
                'hostname': str(info.get('name') or info.get('id') or ''),
                'fw': str(info.get('ver') or info.get('fw_id') or ''), 'mac': str(info.get('mac') or ''),
                'ip': '', 'zb_channel': None, 'zb_hw': '',
                'mode': 'router' if joined else ('zigbee disabled' if zb_config and not zb_config.get('enable') else ''),
                'uptime': None, 'temp': None,
                'fields': len(info) + len(zb_status) + len(zb_config)}

    def poll_gateway_auth(self, g):
        return g.get('username') or '', g.get('password') or ''

    def gateway_device_id(self, g):
        """Where the gateway's readings land: an existing Zigbee device (by
        name - a router already visible on the mesh gets *extended*, never
        duplicated) or a synthetic 'coordinator' row when there is none."""
        target = str(g.get('target') or g['name'])
        if target.lower() == 'coordinator':
            return 'gw:coordinator'
        resolved = self.store.resolve(target)
        return resolved  # None if the named device hasn't been seen yet

    def poll_gateway(self, g):
        host = g['host']
        device_id = self.gateway_device_id(g)
        if device_id is None:
            log('gateway %s: no Zigbee device named %r yet, will retry' % (g['name'], g.get('target') or g['name']), 'debug')
            return
        merged = {}
        ok = False
        user, pw = self.poll_gateway_auth(g)
        kind = g.get('kind') or 'slzb'
        if kind == 'shelly':
            try:
                rpc = ShellyRPC(host, pw, 0, label='gateway %s' % g['name'])
                for method in ('Shelly.GetStatus', 'Zigbee.GetStatus'):
                    try:
                        merged.update(flatten(rpc.call(method) or {}, 'gw'))
                        ok = True
                    except PlugError as e:
                        log('gateway %s %s: %s' % (g['name'], method, e), 'debug')
            except Exception as e:
                log('gateway %s: %s' % (g['name'], e), 'debug')
        else:
            for path in ('/ha_info', '/ha_sensors', '/metrics'):
                try:
                    data = self.gateway_fetch(host, path, username=user, password=pw)
                    merged.update(flatten(data, 'gw'))
                    ok = True
                except Exception as e:
                    log('gateway %s %s: %s' % (g['name'], path, e), 'debug')
            if not ok:
                # never guessed a kind (an older config entry, or Detect was
                # never run): a Shelly box would fail every /ha_* path, so
                # try the RPC route once before giving up this round
                try:
                    rpc = ShellyRPC(host, pw, 0, label='gateway %s' % g['name'])
                    merged.update(flatten(rpc.call('Shelly.GetStatus') or {}, 'gw'))
                    merged.update(flatten(rpc.call('Zigbee.GetStatus') or {}, 'gw'))
                    ok = True
                except Exception as e:
                    log('gateway %s: not an SLZB-style or Shelly RPC gateway: %s' % (g['name'], e), 'debug')
        if not ok:
            # it did not answer this round; after a couple of missed rounds
            # its own API no longer vouches for it and the bridge's word
            # counts again (see set_availability)
            grace = 3 * int(CONFIG.get('gateway_poll_interval') or 30)
            since = self._gw_answered.get(device_id)
            if since and time.time() - since > grace:
                self._gw_answered.pop(device_id, None)
                log('gateway %s stopped answering; %s is back on what the bridge says'
                    % (g['name'], (self.store.device(device_id) or {}).get('name') or device_id))
            return
        if device_id == 'gw:coordinator':
            known = self.store.device('gw:coordinator') or {}
            # The firmware belongs to the gateway entry and is shown from
            # there, the same as for a router. Writing it into the stored
            # description too would leave the old one behind next to the new.
            self.store.upsert_device({
                'id': 'gw:coordinator', 'name': known.get('name') or g['name'], 'source': 'gateway',
                'kind': 'Coordinator', 'model': g.get('model') or known.get('model') or 'SLZB-06 (or compatible)',
                'vendor': 'SMLIGHT' if kind == 'slzb' else 'Shelly',
                'description': 'Zigbee coordinator',
                'last_seen': int(time.time())})
        now = int(time.time())
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': now})
        entry['payload'] = dict(entry.get('payload') or {}, **merged)
        entry['ts'] = now
        # It just answered on its own network API, so it is up whatever the
        # bridge says. Zigbee2MQTT marks the coordinator offline because it
        # does not answer availability pings like an end device - that used
        # to put the box on the dashboard as a red "reported offline by the
        # bridge" while it was sitting there routing the whole mesh.
        self._gw_answered[device_id] = time.time()
        if (self.live.get(device_id) or {}).get('availability') != 'online':
            entry['availability'] = 'online'
            self.store.store_snapshot(device_id, now, {}, 'online')
        self.store.touch_device(device_id, now)
        numeric_vals = {k: numeric(v) for k, v in merged.items()
                        if numeric(v) is not None and not NOISE_KEY.search(k)}
        # Record what moved. A gateway repeats well over a hundred readings
        # every poll and most of them never change; writing them all again
        # every thirty seconds buries the ones that matter.
        last = self._gw_last.setdefault(device_id, {})
        changed = {}
        for k, v in numeric_vals.items():
            seen = last.get(k)
            if seen is None or seen[0] != v or now - seen[1] >= GATEWAY_ANCHOR_S:
                changed[k] = v
                last[k] = (v, now)
        if changed:
            self.store.store_sample(device_id, now, changed)
        self.bump()

    def gateway_loop(self):
        while getattr(self, '_stop', None) is None:
            time.sleep(0.5)
        last = {}
        while not self._stop.wait(5):
            interval = int(CONFIG.get('gateway_poll_interval') or 30)
            now = time.time()
            for g in self.gateway_configs():
                if now - last.get(g['name'], 0) < interval:
                    continue
                last[g['name']] = now
                try:
                    self.poll_gateway(g)
                except Exception as e:
                    log('gateway %s: %s' % (g['name'], e), 'warn')

    # -- weekly schedules: "every Monday at 07:00 on, Wednesday 22:00 off" -------
    WEEKDAY_NAMES = ('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')

    def schedules(self):
        return self.store.meta_json('schedules')

    def save_schedules(self, items):
        clean = []
        seen_ids = set()
        for index, sch in enumerate(items or []):
            if not isinstance(sch, dict):
                continue
            target = self._valid_target(str(sch.get('target') or ''))
            if target is None:
                raise ValueError('schedule %d: unknown plug or switch' % (index + 1))
            do = str(sch.get('do') or 'on').strip()
            checked = valid_action(do)
            if not checked:
                raise ValueError('do must be one of %s, or set:<value>' % ', '.join(BINDING_ACTIONS))
            do = checked
            days = sch.get('days')
            if days in (None, '', 'all', '*'):
                days = list(range(7))
            elif isinstance(days, str):
                parsed = []
                for d in days.split(','):
                    d = d.strip()[:3].lower()
                    if d not in self.WEEKDAY_NAMES:
                        raise ValueError('schedule %d: unknown day %r (use mon,tue,...)' % (index + 1, d))
                    parsed.append(self.WEEKDAY_NAMES.index(d))
                days = parsed
            days = sorted({int(d) for d in (days or []) if 0 <= int(d) <= 6})
            if not days:
                raise ValueError('schedule %d: pick at least one day' % (index + 1))
            at = str(sch.get('at') or '').strip().lower()
            if re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', at):
                if CONFIG.get('latitude') is None or CONFIG.get('longitude') is None:
                    raise ValueError('sunrise/sunset need "latitude" and "longitude" in config.json')
            elif not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', at):
                raise ValueError('schedule %d: time must look like 07:00, sunset, or sunset-30' % (index + 1))
            else:
                at = '%02d:%s' % (int(at.split(':')[0]), at.split(':')[1])
            entry = {'id': str(sch.get('id') or '') or secrets.token_hex(4),
                     'target': target, 'days': days, 'at': at, 'do': do,
                     'enabled': bool(sch.get('enabled', True))}
            if do == 'pulse':
                ms = numeric(sch.get('pulse_ms'))
                entry['pulse_ms'] = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(ms or PULSE_MS_DEFAULT)))
            if entry['id'] in seen_ids:
                entry['id'] = secrets.token_hex(4)
            seen_ids.add(entry['id'])
            clean.append(entry)
        self.store.set_meta('schedules', json.dumps(clean))
        kept = {x['id'] for x in clean}
        for sid in list(self.schedule_runtime):
            if sid not in kept:
                del self.schedule_runtime[sid]
        self.store.add_event('control', '%d schedule(s) saved' % len(clean))
        self.bump()
        return clean

    def check_schedules(self):
        """Once a minute: has a schedule's day and time just arrived? Fires
        once per entry per day - a missed minute (daemon restart, a stalled
        tick) still fires within the same day, never twice."""
        now = time.time()
        t = time.localtime(now)
        weekday = t.tm_wday   # Monday = 0, matches WEEKDAY_NAMES
        today_key = time.strftime('%Y-%m-%d')
        current_minute = t.tm_hour * 60 + t.tm_min
        for sch in self.schedules():
            if not sch.get('enabled', True) or weekday not in (sch.get('days') or []):
                continue
            at = sch['at']
            m = re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', at)
            if m:
                if CONFIG.get('latitude') is None or CONFIG.get('longitude') is None:
                    continue
                base = sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude']), now, sunset=m.group(1) == 'sunset')
                if base is None:
                    continue
                target_minute = (base + int(m.group(2) or 0)) % 1440
            else:
                target_minute = int(at[:2]) * 60 + int(at[3:])
            if current_minute < target_minute or current_minute - target_minute > 4:
                continue                     # not due yet, or the window to catch up (4 min) has passed
            rt = self.schedule_runtime.setdefault(sch['id'], {'last_day': None})
            if rt['last_day'] == today_key:
                continue
            rt['last_day'] = today_key
            for target in self._binding_targets(sch['target']):
                pretty = self.target_label(sch['target'])
                origin = 'schedule: %s %s %s' % (self.WEEKDAY_NAMES[weekday], at, pretty)
                log('schedule fired: %s -> %s' % (origin, sch['do']))
                self.store.add_event('schedule', '%s -> %s' % (origin, sch['do']), 'info')
                self._fire_target(target, sch['do'], origin, sch.get('pulse_ms'),
                                  {'device': sch.get('name') or '', 'action': sch['do'],
                                   'target': self.target_label(sch['target'])}, honour_hold=True)

    # -- scenes: a named bundle of target actions --------------------------------
    def scenes(self):
        return self.store.meta_json('scenes')

    def save_scenes(self, items):
        clean = []
        for index, scene in enumerate(items or []):
            if not isinstance(scene, dict):
                continue
            name = str(scene.get('name') or '').strip()
            if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', name):
                raise ValueError('scene %d needs a sensible name' % (index + 1))
            if any(x['name'].lower() == name.lower() for x in clean):
                raise ValueError('two scenes called "%s"' % name)
            actions = []
            for a in scene.get('actions') or []:
                if not isinstance(a, dict):
                    continue
                target = self._valid_target(str(a.get('target') or ''))
                do = str(a.get('do') or 'on').strip()
                if target is None or target == '*' or target.startswith('scene:'):
                    raise ValueError('scene "%s": each line needs a plug or a switch' % name)
                checked = valid_action(do)
                if not checked:
                    raise ValueError('do must be one of %s, or set:<value>' % ', '.join(BINDING_ACTIONS))
                do = checked
                entry = {'target': target, 'do': do}
                if do == 'pulse':
                    entry['pulse_ms'] = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(numeric(a.get('pulse_ms')) or PULSE_MS_DEFAULT)))
                after = numeric(a.get('after_s'))
                if after is not None and after > 0:
                    if after > 3600:
                        raise ValueError('scene "%s": a step delay tops out at an hour' % name)
                    entry['after_s'] = round(float(after), 1)
                actions.append(entry)
            if not actions:
                raise ValueError('scene "%s" has no actions' % name)
            clean.append({'id': str(scene.get('id') or '') or secrets.token_hex(4), 'name': name, 'actions': actions})
        self.store.set_meta('scenes', json.dumps(clean))
        self.store.add_event('control', '%d scene(s) saved' % len(clean))
        self.bump()
        return clean

    def run_scene(self, scene_id, origin='the dashboard', hold_by=None):
        """hold_by: a button with "by hand" fired this scene - every light the
        scene touches is then taken over (or given back) one by one, exactly
        as if the button had been bound to each of them. Before this the
        hold was looked for on the scene itself, where no rule ever looks,
        so a motion sensor would switch the lights off again a minute later."""
        scene = next((x for x in self.scenes() if x['id'] == scene_id), None)
        if scene is None:
            return False, 'unknown scene'
        def fire(action):
            for target in self._binding_targets(action['target']):
                self._fire_target(target, action['do'], 'scene "%s"' % scene['name'], action.get('pulse_ms'),
                                  {'device': scene['name'], 'action': action['do'],
                                   'target': self.target_label(action['target'])}, hold_by=hold_by)
                if hold_by and target[0] in ('plug', 'zb'):
                    threading.Thread(target=self._settle_member, args=(target, action['do'], hold_by),
                                     name='hold', daemon=True).start()

        def delayed(action, wait_s):
            if not self._stop.wait(wait_s):
                fire(action)

        for a in scene['actions']:
            after = float(a.get('after_s') or 0)
            if after > 0:
                threading.Thread(target=delayed, args=(a, after), name='scene-step', daemon=True).start()
            else:
                fire(a)
        self.store.add_event('scene', 'scene "%s" from %s' % (scene['name'], origin))
        log('scene %s (%s): %d action(s)' % (scene['name'], origin, len(scene['actions'])))
        self.bump()
        return True, 'scene "%s": %d action(s) fired' % (scene['name'], len(scene['actions']))

    # -- sequences: press once -> step 1, press again (even days later) -> step 2,
    #    ... and around again. A second trigger can reset the cycle and run
    #    a "reset" scene (all off, say). Steps are scenes, so each step can
    #    drive many targets, at once or with delays.
    def sequences(self):
        return self.store.meta_json('sequences')

    def sequence_positions(self):
        try:
            return {str(k): int(v) for k, v in json.loads(self.store.get_meta('sequence_pos') or '{}').items()}
        except (ValueError, TypeError):
            return {}

    def save_sequences(self, items):
        scene_ids = {x['id'] for x in self.scenes()}
        clean = []
        for index, sq in enumerate(items or []):
            if not isinstance(sq, dict):
                continue
            name = str(sq.get('name') or '').strip()
            if not re.match(r'^[A-Za-z0-9][A-Za-z0-9 _.-]{0,40}$', name):
                raise ValueError('sequence %d needs a sensible name' % (index + 1))
            if any(x['name'].lower() == name.lower() for x in clean):
                raise ValueError('two sequences called "%s"' % name)
            steps = []
            for x in sq.get('steps') or []:
                x = str(x)
                if x in scene_ids:
                    steps.append(x)
                    continue
                if '|' in x:
                    target, do = x.split('|', 1)
                    target = self._valid_target(target.strip())
                    do = valid_action(do)
                    if target and do and target != '*':
                        steps.append(target + '|' + do)
            if not steps:
                raise ValueError('sequence "%s" needs at least one step (a scene, or a target with an action)' % name)
            reset_scene = str(sq.get('reset_scene') or '')
            if reset_scene and reset_scene not in scene_ids:
                # the same shape a step may take: "<target>|<do>"
                if '|' in reset_scene:
                    target, do = reset_scene.split('|', 1)
                    target = self._valid_target(target.strip())
                    do = valid_action(do)
                    reset_scene = (target + '|' + do) if target and do and target != '*' else ''
                else:
                    reset_scene = ''
            clean.append({'id': str(sq.get('id') or '') or secrets.token_hex(4), 'name': name,
                          'steps': steps[:50], 'reset_scene': reset_scene})
        self.store.set_meta('sequences', json.dumps(clean))
        positions = self.sequence_positions()
        kept = {x['id'] for x in clean}
        positions = {k: v for k, v in positions.items() if k in kept}
        self.store.set_meta('sequence_pos', json.dumps(positions))
        self.store.add_event('control', '%d sequence(s) saved' % len(clean))
        self.bump()
        return clean

    def sequence_by_id(self, sid):
        return next((x for x in self.sequences() if x['id'] == sid), None)

    def advance_sequence(self, sid, origin='the dashboard', hold_by=None):
        sq = self.sequence_by_id(sid)
        if sq is None:
            return False, 'unknown sequence'
        positions = self.sequence_positions()
        pos = positions.get(sid, 0) % len(sq['steps'])
        scene_id = sq['steps'][pos]
        scene = next((x for x in self.scenes() if x['id'] == scene_id), None)
        positions[sid] = (pos + 1) % len(sq['steps'])
        origin_step = 'sequence "%s" step %d' % (sq['name'], pos + 1)
        if scene:
            label = scene['name']
        elif '|' in scene_id:
            target_spec, do = scene_id.split('|', 1)
            label = '%s %s' % (self.target_label(target_spec), do)
        else:
            label = scene_id
        # the relay first, the paperwork after (same rule as bindings)
        self._run_step(scene_id, origin_step, sq['name'], hold_by)
        self.store.set_meta('sequence_pos', json.dumps(positions))
        self.store.add_event('sequence', 'sequence "%s" step %d/%d: %s (%s)'
                             % (sq['name'], pos + 1, len(sq['steps']), label, origin))
        log('sequence %s: step %d/%d -> scene %s (%s)' % (sq['name'], pos + 1, len(sq['steps']), label, origin))
        self.bump()
        return True, 'sequence "%s": step %d/%d, %s' % (sq['name'], pos + 1, len(sq['steps']), label)

    def _run_step(self, step, origin, seq_name, hold_by=None):
        """One step of a sequence, or its reset: a scene id, or "<target>|<do>"."""
        if not step:
            return
        if any(x['id'] == step for x in self.scenes()):
            self.run_scene(step, origin, hold_by=hold_by)
            return
        if '|' not in step:
            return
        target_spec, do = step.split('|', 1)
        for target in self._binding_targets(target_spec):
            self._fire_target(target, do, origin, None,
                              {'device': seq_name, 'action': do, 'target': self.target_label(target_spec)}, hold_by=hold_by)
            if hold_by and target[0] in ('plug', 'zb'):
                threading.Thread(target=self._settle_member, args=(target, do, hold_by), name='hold', daemon=True).start()

    def reset_sequence(self, sid, origin='the dashboard', hold_by=None):
        sq = self.sequence_by_id(sid)
        if sq is None:
            return False, 'unknown sequence'
        positions = self.sequence_positions()
        positions[sid] = 0
        self._run_step(sq.get('reset_scene'), 'sequence "%s" reset' % sq['name'], sq['name'], hold_by)
        self.store.set_meta('sequence_pos', json.dumps(positions))
        self.store.add_event('sequence', 'sequence "%s" reset to step 1 (%s)' % (sq['name'], origin))
        log('sequence %s: reset (%s)' % (sq['name'], origin))
        self.bump()
        return True, 'sequence "%s" back to step 1' % sq['name']

    # -- zigbee switches as targets: publish to <name>/set -----------------------
    ZB_STATE_RE = re.compile(r'^state(_[a-z0-9]+)?$')

    def heating_targets(self):
        """The rooms' temperatures as settable targets, so the editors offer
        to / up by / down by for them like they do for a valve."""
        out = []
        state = self.heating_state() if self.rooms() else {'rooms': []}
        for room in state['rooms']:
            if not room.get('heated', True):
                continue
            out.append({'value': 'heat:temp:%s' % room['id'], 'id': 'room:' + room['id'], 'key': 'temperature',
                        'name': 'temperature in ' + room['name'], 'kind': 'number', 'online': True,
                        'state': room.get('wanted_c'), 'unit': '\u00b0C', 'min': 5, 'max': 30})
        return out

    def zigbee_targets(self):
        """Everything a Zigbee device will let us set: an on/off state (a wall
        switch channel, a bulb, a relay), and on a thermostatic valve also its
        target temperature and its mode. Each is addressable as
        zb:<id>:<key>; a number or a mode is driven with "set:<value>"."""
        out = []
        for dev in self.store.devices():
            if dev['source'] != 'zigbee' or dev['id'].startswith('name:'):
                continue
            exposes = dev.get('exposes') or {}
            live = self.live.get(dev['id']) or {}
            online = (live.get('availability') or '') != 'offline'
            payload = live.get('payload') or {}
            for key, info in sorted(exposes.items()):
                info = info or {}
                access = info.get('access')
                settable = access is None or bool(access & 2)
                display = dev.get('alias') or dev['name']
                if self.ZB_STATE_RE.match(key):
                    if not settable:
                        continue                  # read-only state (a sensor, not a switch)
                    if key != 'state':
                        display += ' \u00b7 ' + key.replace('state_', '').upper()
                    out.append({'value': 'zb:%s:%s' % (dev['id'], key), 'id': dev['id'], 'key': key,
                                'name': display, 'kind': 'switch', 'online': online,
                                'state': payload.get(key)})
                    continue
                if not settable or key not in SETTABLE_KEYS:
                    continue
                if info.get('type') == 'enum' or info.get('values'):
                    kind = 'enum'
                elif info.get('type') == 'binary':
                    kind = 'enum'
                    info = dict(info, values=[v for v in (info.get('value_on'), info.get('value_off')) if v] or ['ON', 'OFF'])
                elif info.get('type') in ('numeric', '', None):
                    kind = 'number'
                else:
                    continue
                label = key_label(key)
                if label.lower() in ('state', 'value', 'mode') or not label:
                    label = key.replace('_', ' ').capitalize()
                out.append({'value': 'zb:%s:%s' % (dev['id'], key), 'id': dev['id'], 'key': key,
                            'name': display + ' \u00b7 ' + label,
                            'kind': kind, 'online': online, 'state': payload.get(key),
                            'unit': info.get('unit') or key_unit(key),
                            'values': info.get('values') or None,
                            'min': info.get('min'), 'max': info.get('max')})
        return out

    def _valid_target(self, spec):
        """Canonical form of a binding/rule target, or None: a plug name, '*',
        or zb:<device>:<state key>."""
        spec = str(spec or '').strip()
        if spec == '*':
            return '*'
        if spec == 'notify':
            return 'notify'
        if spec.startswith('notify:'):
            return spec if self.message_by_id(spec[7:]) else None
        if spec.startswith('scene:'):
            sid = spec[6:]
            return spec if any(x['id'] == sid for x in self.scenes()) else None
        if spec in ('heat:control', 'heat:away'):
            return spec
        if spec.startswith('heat:temp:'):
            rid = spec[10:]
            heated = (self.heating_config()['rooms'].get(rid) or {}).get('heated', True)
            return spec if heated and any(r['id'] == rid for r in self.rooms()) else None
        if spec.startswith('heat:room:') or spec.startswith('heat:control:'):
            rid = spec.split(':')[-1]
            heated = (self.heating_config()['rooms'].get(rid) or {}).get('heated', True)
            return spec if heated and any(r['id'] == rid for r in self.rooms()) else None
        if spec.startswith('seqreset:'):
            return spec if self.sequence_by_id(spec[9:]) else None
        if spec.startswith('seq:'):
            return spec if self.sequence_by_id(spec[4:]) else None
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            if len(pieces) < 3:
                return None
            key = pieces[-1]
            device = ':'.join(pieces[1:-1])
            resolved = self.store.resolve(device)
            if not resolved or not (self.ZB_STATE_RE.match(key) or key in SETTABLE_KEYS):
                return None
            dev = self.store.device(resolved)
            if not dev or dev['source'] != 'zigbee':
                return None
            return 'zb:%s:%s' % (resolved, key)
        canonical = next((n for n in self.plug_names_all() if n.lower() == spec.lower()), None)
        return canonical

    def target_label(self, spec):
        if spec == 'notify':
            return 'a notification'
        if spec.startswith('notify:'):
            message = self.message_by_id(spec[7:])
            return ('the message "%s"' % message['name']) if message else 'a message that is gone'
        if spec.startswith('seqreset:'):
            sq = self.sequence_by_id(spec[9:])
            return 'reset sequence ' + (sq['name'] if sq else '?')
        if spec.startswith('seq:'):
            sq = self.sequence_by_id(spec[4:])
            return 'sequence ' + (sq['name'] if sq else '?')
        if spec.startswith('scene:'):
            scene = next((x for x in self.scenes() if x['id'] == spec[6:]), None)
            return 'scene ' + (scene['name'] if scene else '?')
        if spec == 'heat:control':
            return 'heating control'
        if spec == 'heat:away':
            return 'heating away mode'
        if spec.startswith('heat:room:'):
            room = next((r for r in self.rooms() if r['id'] == spec[10:]), None)
            return 'heating in ' + (room['name'] if room else '?')
        if spec.startswith('heat:control:'):
            room = next((r for r in self.rooms() if r['id'] == spec[13:]), None)
            return 'heating control in ' + (room['name'] if room else '?')
        if spec.startswith('heat:temp:'):
            room = next((r for r in self.rooms() if r['id'] == spec[10:]), None)
            return 'temperature in ' + (room['name'] if room else '?')
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            dev = self.store.device(':'.join(pieces[1:-1]))
            if dev:
                label = dev.get('alias') or dev['name']
                key = pieces[-1]
                if key == 'state':
                    return label
                if key in SETTABLE_KEYS:           # a valve's target, a mode: say it in words
                    return label + ' \u00b7 ' + key_label(key).lower()
                return label + ' \u00b7 ' + key.replace('state_', '').upper()
        return spec

    def _binding_targets(self, spec):
        """('plug', PlugState) and ('zb', device_id, key) tuples for one target
        spec; '*' means every enabled plug (never the Zigbee switches)."""
        if spec == '*':
            return [('plug', p) for p in self.plugs.values() if not p.cfg.get('monitor_only')]
        if spec == 'notify':
            return [('notify', '')]
        if spec.startswith('notify:'):
            return [('notify', spec[7:])]
        if spec.startswith('scene:'):
            return [('scene', spec[6:])]
        if spec.startswith('heat:'):
            return [('heat', spec[5:])]
        if spec.startswith('seqreset:'):
            return [('seqreset', spec[9:])]
        if spec.startswith('seq:'):
            return [('seq', spec[4:])]
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            return [('zb', ':'.join(pieces[1:-1]), pieces[-1])]
        p = self.plug_by_name(spec)
        return [('plug', p)] if p is not None else []

    def _fire_target(self, target, do, origin, pulse_ms=None, facts=None, honour_hold=False, hold_by=None):
        if honour_hold:
            key = self.hold_key(target)
            held = self.target_held(key) if key else None
            if held:
                log('%s left alone: taken over by %s' % (self.target_label(key), held.get('by')), 'debug')
                return
        if target[0] == 'notify':
            # nothing is switched: the point is that someone hears about it
            self.send_message(target[1] if len(target) > 1 else '', origin, facts)
            return
        if target[0] == 'scene':
            threading.Thread(target=self.run_scene, args=(target[1], origin, hold_by), name='scene', daemon=True).start()
            return
        if target[0] == 'heat':
            threading.Thread(target=self.heat_target, args=(target[1], do, origin), name='heating', daemon=True).start()
            return
        if target[0] == 'seq':
            threading.Thread(target=self.advance_sequence, args=(target[1], origin, hold_by), name='sequence', daemon=True).start()
            return
        if target[0] == 'seqreset':
            threading.Thread(target=self.reset_sequence, args=(target[1], origin, hold_by), name='sequence', daemon=True).start()
            return
        if target[0] == 'plug':
            threading.Thread(target=self._run_binding, args=(target[1], do, origin, pulse_ms),
                             name='binding', daemon=True).start()
        else:
            threading.Thread(target=self._run_zigbee_switch, args=(target[1], target[2], do, origin, pulse_ms),
                             name='binding-zb', daemon=True).start()

    def _run_zigbee_switch(self, device_id, key, do, origin, pulse_ms=None):
        try:
            ok, message = self.zigbee_switch(device_id, key, do, origin, pulse_ms)
            if not ok:
                log('zigbee target failed: %s' % message, 'warn')
        except Exception as e:
            log('zigbee target failed: %s' % e, 'error')

    def mqtt_selftest(self):
        """Publish under the Zigbee2MQTT base topic and see whether it comes
        back on our own subscription. That separates 'the broker will not let
        us publish' from anything happening later in Zigbee2MQTT."""
        if not self.connected or not self.client:
            return {'ok': False, 'error': 'not connected to the broker'}
        topic = '%s/%s/set' % (CONFIG['base_topic'].rstrip('/'), SELFTEST_NAME)
        nonce = secrets.token_hex(8)
        self._mqtt_selftest_seen = None
        self._map_stamp = 0.0        # bumped whenever a network map lands
        info = self.client.publish(topic, json.dumps({'nonce': nonce}), qos=1)
        rc = getattr(info, 'rc', 0)
        acked = False
        try:
            info.wait_for_publish(3)         # the broker's PUBACK for this QoS 1 message
            acked = bool(info.is_published())
        except Exception:
            acked = False
        deadline = time.time() + 3
        echoed = False
        while time.time() < deadline:
            seen = self._mqtt_selftest_seen
            if isinstance(seen, dict) and seen.get('nonce') == nonce:
                echoed = True
                break
            time.sleep(0.05)
        out = {'ok': echoed, 'topic': topic, 'echoed': echoed, 'acked': acked, 'rc': rc}
        if echoed:
            out['message'] = 'the broker accepts what the daemon publishes'
        elif acked:
            # mosquitto acknowledges a message its ACL then throws away
            out['message'] = ('the broker acknowledged our message but never delivered it back - '
                              'its ACL is dropping what the daemon publishes; the MQTT user needs '
                              '"topic write %s/+/set" (mosquitto: /etc/mosquitto/acl, then reload)'
                              % CONFIG['base_topic'].rstrip('/'))
        elif rc != 0:
            out['message'] = 'the client could not queue the message (rc %s)' % rc
        else:
            out['message'] = ('the broker never acknowledged our message - the connection accepts '
                              'reads but not writes; the MQTT user needs "topic write %s/+/set"'
                              % CONFIG['base_topic'].rstrip('/'))
        return out

    def _verify_zigbee_set(self, device_id, key, value, label, topic, sent_at):
        """A publish the broker refuses (an ACL that does not allow writing to
        the Zigbee2MQTT topic) looks exactly like success from here, and the
        socket simply never moves. Watch for the device's own report and say
        so if it does not come."""
        name = (self.store.device(device_id) or {}).get('name') or ''

        def watch():
            deadline = sent_at + 6
            while time.time() < deadline:
                if self._stop.wait(0.25):
                    return
                seen = str((self.live.get(device_id, {}).get('payload') or {}).get(key) or '').upper()
                if seen == value:
                    return
            # We subscribe to the whole base topic, so a command the broker
            # accepted comes straight back to us. Whether it did tells the
            # two very different failures apart.
            echoed = self._zb_echo.get(name, 0) >= sent_at
            if echoed:
                detail = ('the broker delivered %s to %s but Zigbee2MQTT did not act on it '
                          '- check the Zigbee2MQTT log' % (value, topic))
            else:
                detail = ('%s never reached the broker at all (nothing came back on our own '
                          'subscription) - the daemon\'s MQTT user needs "topic write %s/+/set" '
                          'in the broker ACL; run "zigmon --check" to confirm'
                          % (value, CONFIG['base_topic'].rstrip('/')))
            self.store.add_event('switch', 'no confirmation: ' + detail, 'warn', device_id)
            log('%s: %s' % (label, detail), 'warn')
        threading.Thread(target=watch, name='zb-verify', daemon=True).start()

    def zigbee_switch(self, device_id, key, action, origin='the dashboard', pulse_ms=None):
        """Drive a Zigbee switch through Zigbee2MQTT: publish {key: ON/OFF/TOGGLE}
        to <name>/set. The device's own report comes back through the bridge
        and repaints the dashboard."""
        dev = self.store.device(device_id)
        if dev is None:
            return False, 'unknown device'
        if not self.connected or not self.client:
            return False, 'not connected to the broker'
        label = self.target_label('zb:%s:%s' % (device_id, key))
        topic = '%s/%s/set' % (CONFIG['base_topic'].rstrip('/'), dev['name'])

        def put(value):
            info = self.client.publish(topic, json.dumps({key: value}), qos=1)
            if hasattr(info, 'rc') and info.rc != 0:
                raise RuntimeError('publish failed (%s) - the broker ACL must allow writing %s' % (info.rc, topic))

        if action == 'pulse':
            ms = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(pulse_ms or PULSE_MS_DEFAULT)))
            current = str((self.live.get(device_id, {}).get('payload') or {}).get(key) or '').upper()
            if current in ('ON', 'OFF'):
                first, back = ('OFF', 'ON') if current == 'ON' else ('ON', 'OFF')
            else:
                first, back = 'TOGGLE', 'TOGGLE'   # state unknown; a blind flip both ways
            put(first)
            self.store.add_event('switch', 'pulse: %s for %.1f s from %s' % (first, ms / 1000.0, origin),
                                 'info', device_id)
            self._stop.wait(ms / 1000.0)
            put(back)
            self.store.add_event('switch', 'pulse: back %s' % back, 'info', device_id)
            log('%s pulsed %s for %d ms (%s)' % (label, first, ms, origin))
            self.bump()
            return True, '%s pulsed %s for %.1f s' % (label, first.lower(), ms / 1000.0)
        if str(action).lower().startswith('set:'):
            # a target temperature, a mode, an offset: published as it is (a
            # number as a number), and read back from the device's own report
            raw = str(action)[4:].strip()
            # "+0.5" / "-0.5" step from where it is (a knob); "=-2.5" is that
            # value outright, since a bare minus already means "down by"
            absolute = raw[:1] == '='
            if absolute:
                raw = raw[1:].strip()
            relative = not absolute and raw[:1] in ('+', '-') and raw[1:].replace('.', '', 1).isdigit()
            try:
                value = int(raw) if raw.lstrip('-+').isdigit() else float(raw)
            except ValueError:
                value = raw
            if relative:
                # A knob turned. Two things make a knob feel dead if done
                # naively: the valve is a sleeping device that reports its
                # new set point seconds to minutes later, so ten quick clicks
                # computed from the last REPORT all say "21.5 + 0.5 = 22"; and
                # ten separate messages queue up in Zigbee2MQTT and are
                # delivered one at a time when the head wakes. So the steps
                # accumulate on what we last sent (while that is fresher than
                # the report), the dashboard shows the result at once, and a
                # burst of clicks goes out as ONE message a moment after the
                # last click, with the final number.
                pend_key = (device_id, key)
                pending = self._pending_set.get(pend_key)
                reported = (self.live.get(device_id, {}).get('payload') or {}).get(key)
                reported_at = float(self.live.get(device_id, {}).get('ts') or 0)
                if pending and time.time() - pending['at'] < 300 and pending['at'] > reported_at:
                    current = pending['value']
                else:
                    current = reported
                if not isinstance(current, (int, float)):
                    return False, '%s: cannot step %s, its current value is unknown' % (label, key)
                value = round(float(current) + float(raw), 2)
                info = (dev.get('exposes') or {}).get(key) or {}
                if isinstance(info.get('min'), (int, float)):
                    value = max(float(info['min']), value)
                if isinstance(info.get('max'), (int, float)):
                    value = min(float(info['max']), value)
                if value == int(value):
                    value = int(value)
                entry = self.live.setdefault(device_id, {'payload': {}, 'ts': time.time()})
                entry['payload'] = dict(entry.get('payload') or {}, **{key: value})    # what the card shows, now
                timer = pending['timer'] if pending else None
                if timer is not None:
                    timer.cancel()
                def send(value=value):
                    self._pending_set[pend_key] = {'value': value, 'at': time.time(), 'timer': None}
                    try:
                        put(value)
                        self.store.add_event('switch', 'set %s to %s from %s' % (key, value, origin), 'info', device_id)
                        log('%s set to %s (%s)' % (label, value, origin))
                    except Exception as e:
                        log('%s: %s' % (label, e), 'warn')
                    self.bump()
                timer = threading.Timer(0.25, send)
                timer.daemon = True
                self._pending_set[pend_key] = {'value': value, 'at': time.time(), 'timer': timer}
                timer.start()
                self.bump()
                return True, '%s set to %s' % (label, value)
            put(value)
            self.store.add_event('switch', 'set %s to %s from %s' % (key, value, origin), 'info', device_id)
            log('%s set to %s (%s)' % (label, value, origin))
            self.bump()
            return True, '%s set to %s' % (label, value)
        if action == 'toggle':
            # Not every converter implements TOGGLE - the Zigbee2MQTT frontend
            # always sends the explicit state, and so do we when the last
            # report tells us what the channel is doing.
            current = str((self.live.get(device_id, {}).get('payload') or {}).get(key) or '').upper()
            value = {'ON': 'OFF', 'OFF': 'ON'}.get(current, 'TOGGLE')
        else:
            value = action.upper()
        sent_at = time.time()          # taken before the publish: the echo can beat us back
        put(value)
        if value in ('ON', 'OFF'):
            self._verify_zigbee_set(device_id, key, value, label, topic, sent_at)
        self.store.add_event('switch', 'set %s from %s' % (value, origin),
                             'info', device_id)
        log('%s set %s (%s)' % (label, value, origin))
        self.bump()
        return True, '%s set %s' % (label, value.lower())

    # -- button bindings -------------------------------------------------------
    def bindings(self):
        return self.store.meta_json('bindings')

    def save_bindings(self, items):
        clean = []
        for index, b in enumerate(items or []):
            if not isinstance(b, dict):
                continue
            device = str(b.get('device') or '').strip()
            action = str(b.get('action') or '').strip()
            plug = str(b.get('plug') or '').strip()
            do = str(b.get('do') or 'toggle').strip()
            if not device or not action or not plug:
                raise ValueError('binding %d needs a device, an action and a plug' % (index + 1))
            checked = valid_action(do)
            if not checked:
                raise ValueError('do must be one of %s, or set:<value>' % ', '.join(BINDING_ACTIONS))
            do = checked
            canonical = self._valid_target(plug)
            if canonical is None:
                raise ValueError('unknown plug or switch %r' % plug)
            resolved = self.store.resolve(device) or device
            entry = {'device': resolved, 'action': action,
                     'plug': canonical, 'hold': bool(b.get('hold')),
                     'do': do, 'enabled': bool(b.get('enabled', True))}
            if do == 'pulse':
                try:
                    ms = int(b.get('pulse_ms') or PULSE_MS_DEFAULT)
                except (TypeError, ValueError):
                    raise ValueError('pulse delay must be a number of milliseconds')
                if not PULSE_MS_MIN <= ms <= PULSE_MS_MAX:
                    raise ValueError('pulse delay must be between %d and %d ms' % (PULSE_MS_MIN, PULSE_MS_MAX))
                entry['pulse_ms'] = ms
            clean.append(entry)
        self.store.set_meta('bindings', json.dumps(clean))
        self.store.add_event('control', '%d button binding(s) saved' % len(clean))
        return clean

    # -- value rules: "when a reading crosses a line, drive a plug" -----------
    def rules(self):
        return self.store.meta_json('rules')

    def save_rules(self, items):
        clean = self._validate_rules(items)
        self.store.set_meta('rules', json.dumps(clean))
        kept_ids = {r['id'] for r in clean}
        for rid in list(self.rule_runtime):
            if rid not in kept_ids:
                del self.rule_runtime[rid]
        self.store.add_event('control', '%d rule(s) saved' % len(clean))
        self.bump()
        return clean

    def _validate_rules(self, items):
        clean = []
        kept = {r.get('id'): r for r in self.rules()}
        for index, r in enumerate(items or []):
            if not isinstance(r, dict):
                continue
            device = str(r.get('device') or '').strip()
            key = str(r.get('key') or '').strip()
            op = str(r.get('op') or '>=').strip()
            plug = str(r.get('plug') or '').strip()
            do = str(r.get('do') or 'on').strip()
            value = numeric(r.get('value'))
            if not device or not key or not plug:
                raise ValueError('rule %d needs a source, a value key and a plug' % (index + 1))
            if op not in RULE_OPS:
                raise ValueError('the comparison must be one of %s' % ', '.join(RULE_OPS))
            if value is None:
                raise ValueError('rule %d: the threshold must be a number' % (index + 1))
            checked = valid_action(do)
            if not checked:
                raise ValueError('do must be one of %s, or set:<value>' % ', '.join(BINDING_ACTIONS))
            do = checked
            canonical_rule = self._valid_target(plug)
            if canonical_rule is None:
                raise ValueError('unknown plug or switch %r' % plug)
            cooldown = numeric(r.get('cooldown_s'))
            def hhmm(value, what):
                value = str(value or '').strip().lower()
                if not value:
                    return ''
                if re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', value):
                    if CONFIG.get('latitude') is None or CONFIG.get('longitude') is None:
                        raise ValueError('sunrise/sunset need "latitude" and "longitude" in config.json')
                    return value
                if not re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', value):
                    raise ValueError('%s must look like 22:30, sunset, or sunset-30' % what)
                return '%02d:%s' % (int(value.split(':')[0]), value.split(':')[1])
            window_from = hhmm(r.get('from'), 'the window start')
            window_to = hhmm(r.get('to'), 'the window end')
            if bool(window_from) != bool(window_to):
                raise ValueError('give both ends of the time window, or neither')
            window_end = str(r.get('window_end') or '').strip().lower()
            if window_end not in ('', 'off', 'on'):
                raise ValueError('when the window closes, the plug can be left alone, switched off or on')
            for_s = numeric(r.get('for_s'))
            if for_s is not None and not 0 <= for_s <= 86400:
                raise ValueError('"must hold for" is seconds, up to a day')
            back = numeric(r.get('back'))
            if back is not None and do not in ('on', 'off'):
                raise ValueError('the way-back threshold only makes sense with switch on/off')
            mode = str(r.get('mode') or 'abs')
            if mode not in ('abs', 'delta24'):
                raise ValueError("compare must be 'abs' or 'delta24'")
            max_ph = int(numeric(r.get('max_per_hour')) or 0)
            if not 0 <= max_ph <= 1000:
                raise ValueError('max per hour is 0 (off) to 1000')
            entry = {'id': str(r.get('id') or '') or secrets.token_hex(4),
                     'device': self.store.resolve(device) or device, 'key': key, 'op': op, 'value': value,
                     'plug': canonical_rule, 'do': do,
                     'cooldown_s': int(cooldown) if cooldown is not None and cooldown >= 0 else RULE_COOLDOWN_DEFAULT,
                     'from': window_from, 'to': window_to, 'window_end': window_end,
                     'for_s': int(for_s or 0), 'back': back,
                     'mode': mode, 'max_per_hour': max_ph,
                     'when': self._valid_presence_gate(r.get('when')),
                     'enabled': bool(r.get('enabled', True))}
            device2 = str(r.get('device2') or '').strip()
            key2 = str(r.get('key2') or '').strip()
            combine = str(r.get('combine') or 'and').strip().lower()
            if combine not in ('and', 'or'):
                combine = 'and'
            if device2 and key2:
                op2 = str(r.get('op2') or '>=').strip()
                value2 = numeric(r.get('value2'))
                if op2 not in RULE_OPS:
                    raise ValueError('the second comparison must be one of %s' % ', '.join(RULE_OPS))
                if value2 is None:
                    raise ValueError('the second threshold must be a number')
                entry.update({'device2': self.store.resolve(device2) or device2, 'key2': key2, 'combine': combine,
                              'op2': op2, 'value2': value2})
            if do == 'pulse':
                try:
                    ms = int(r.get('pulse_ms') or PULSE_MS_DEFAULT)
                except (TypeError, ValueError):
                    raise ValueError('pulse delay must be a number of milliseconds')
                if not PULSE_MS_MIN <= ms <= PULSE_MS_MAX:
                    raise ValueError('pulse delay must be between %d and %d ms' % (PULSE_MS_MIN, PULSE_MS_MAX))
                entry['pulse_ms'] = ms
            if entry['id'] not in kept:
                self.rule_runtime.pop(entry['id'], None)
            clean.append(entry)
        return clean

    def avg24(self, device_id, key):
        """The rolling day average of one reading, cached ten minutes."""
        cache = getattr(self, '_avg24', None)
        if cache is None:
            cache = self._avg24 = {}
        hit = cache.get((device_id, key))
        now = time.time()
        if hit and now - hit[1] < 600:
            return hit[0]
        with self.store.lock:
            rows = self.store.db.execute(
                'SELECT AVG(value) v FROM samples WHERE device=? AND key=? AND ts>=?',
                (device_id, key, int(now - 86400))).fetchone()
            value = rows['v']
            if value is None:
                rows = self.store.db.execute(
                    'SELECT AVG(avg) v FROM samples_hourly WHERE device=? AND key=? AND ts>=?',
                    (device_id, key, int(now - 86400))).fetchone()
                value = rows['v']
        cache[(device_id, key)] = (value, now)
        return value

    def _effective_reading(self, r, reading):
        if r.get('mode') == 'delta24':
            base = self.avg24(r['device'], r['key'])
            return None if base is None else reading - base
        return reading

    def _rate_limited(self, r, rt):
        limit = int(r.get('max_per_hour') or 0)
        if not limit:
            return False
        now = time.time()
        fires = [t for t in rt.get('fire_log', []) if now - t < 3600]
        rt['fire_log'] = fires
        if len(fires) >= limit:
            if not rt.get('limited'):
                rt['limited'] = True
                self.store.add_event('rule', 'rate limit: %s %s %g hit %d/h, holding fire'
                                     % (r['key'], r['op'], r['value'], limit), 'warn', r['device'])
            return True
        rt['limited'] = False
        fires.append(now)
        return False

    def dryrun_rule(self, r, days=7):
        """Walk a week of recorded samples and answer: when would this rule
        have fired? Windows, edges, hold-for, cooldown and delta24 are
        honoured; the AND condition uses the other series' nearest value."""
        rules = self._validate_rules([dict(r, id='dryrun')])
        r = rules[0]
        now = time.time()
        with self.store.lock:
            rows = self.store.db.execute(
                'SELECT ts, value FROM samples WHERE device=? AND key=? AND ts>=? ORDER BY ts',
                (r['device'], r['key'], int(now - days * 86400))).fetchall()
            other = []
            if r.get('device2') and r.get('key2'):
                other = self.store.db.execute(
                    'SELECT ts, value FROM samples WHERE device=? AND key=? AND ts>=? ORDER BY ts',
                    (r['device2'], r['key2'], int(now - days * 86400))).fetchall()
        fires, holds_since, last_fire, prev_holds = [], None, -1e12, False
        oi = 0
        window = [x['value'] for x in rows[:48]]
        for row in rows:
            ts, reading = row['ts'], row['value']
            if reading is None or not self.rule_window_active(r, ts):
                prev_holds = False
                holds_since = None
                continue
            if r.get('mode') == 'delta24':
                window.append(reading)
                if len(window) > 1440:
                    window.pop(0)
                reading = reading - (sum(window) / len(window))
            holds = self._rule_holds(r['op'], reading, r['value'])
            if other:
                while oi + 1 < len(other) and other[oi + 1]['ts'] <= ts:
                    oi += 1
                second = other[oi]['value'] if other and other[oi]['ts'] <= ts else None
                second_holds = second is not None and self._rule_holds(r['op2'], second, r['value2'])
                holds = (holds or second_holds) if r.get('combine') == 'or' else (holds and second_holds)
            wait_s = int(r.get('for_s') or 0)
            if holds and not prev_holds:
                holds_since = ts
            if not holds:
                holds_since = None
            fire = False
            if holds:
                if wait_s:
                    fire = holds_since is not None and ts - holds_since >= wait_s and not any(
                        f >= holds_since for f in fires[-3:])
                else:
                    fire = not prev_holds
            if fire and ts - last_fire >= int(r.get('cooldown_s') or 0):
                fires.append(ts)
                last_fire = ts
            prev_holds = holds
        return {'days': days, 'samples': len(rows), 'fires': fires[-200:], 'count': len(fires)}

    def latest_value(self, device_id, key):
        """The device's last reported value for one key, as a number."""
        entry = self.live.get(device_id) or {}
        return numeric((entry.get('payload') or {}).get(key))

    @staticmethod
    def rule_window_active(r, now=None):
        """True when the rule's clock window is open. 22:00-06:00 crosses
        midnight and means exactly that; no window means always."""
        if not r.get('from') or not r.get('to'):
            return True
        t = time.localtime(now if now is not None else time.time())
        minutes = t.tm_hour * 60 + t.tm_min

        def spec_minutes(spec):
            m = re.match(r'^(sunrise|sunset)([+-]\d{1,3})?$', spec)
            if m:
                base = sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude']),
                                   now, sunset=m.group(1) == 'sunset')
                if base is None:
                    return None
                return (base + int(m.group(2) or 0)) % 1440
            return int(spec[:2]) * 60 + int(spec[3:])
        f = spec_minutes(r['from'])
        to = spec_minutes(r['to'])
        if f is None or to is None:
            return True                      # polar day/night: no astro edge, stay open
        if f == to:
            return True
        if f < to:
            return f <= minutes < to
        return minutes >= f or minutes < to

    @staticmethod
    def _rule_holds(op, reading, threshold):
        if op == '>=':
            return reading >= threshold
        if op == '<=':
            return reading <= threshold
        if op == '>':
            return reading > threshold
        if op == '==':
            # readings are floats: 21.0 from a sensor should match a 21 typed here
            return abs(reading - threshold) < 1e-9
        if op == '!=':
            return abs(reading - threshold) >= 1e-9
        return reading < threshold

    # -- messages people write themselves -------------------------------------
    def alert_messages(self):
        """The texts people wrote for themselves. Named apart from
        self.messages, which counts what MQTT has delivered."""
        rows = self.store.meta_json('messages') or []
        return rows if isinstance(rows, list) else []

    def message_by_id(self, mid):
        return next((m for m in self.alert_messages() if m['id'] == mid), None)

    def save_alert_messages(self, items):
        clean = []
        for index, m in enumerate(items or []):
            if not isinstance(m, dict):
                continue
            name = str(m.get('name') or '').strip()
            text = str(m.get('text') or '').strip()
            level = str(m.get('level') or 'warn').strip().lower()
            if not name:
                raise ValueError('message %d needs a name' % (index + 1))
            if not text:
                raise ValueError('message %r has nothing to say' % name)
            if level not in ('info', 'warn', 'crit'):
                raise ValueError('the level must be info, warn or crit')
            if len(text) > 500:
                raise ValueError('message %r is longer than a notification can carry' % name)
            quiet = numeric(m.get('quiet_s'))
            image = str(m.get('image') or '').strip()
            if image and not re.match(r'^https?://', image):
                raise ValueError('the picture for %r must be a http:// or https:// address' % name)
            clean.append({'id': str(m.get('id') or '') or secrets.token_hex(4),
                          'name': name, 'text': text, 'level': level,
                          'title': str(m.get('title') or '').strip()[:80],
                          'image': image[:500],
                          'quiet_s': int(quiet) if quiet is not None and 0 <= quiet <= 86400 else 900})
        self.store.set_meta('messages', json.dumps(clean))
        self.store.add_event('control', '%d message(s) saved' % len(clean))
        self.bump()
        return clean

    @staticmethod
    def _fact_text(value):
        if value is None:
            return ''
        if isinstance(value, bool):
            return 'yes' if value else 'no'
        if isinstance(value, float):
            return ('%.2f' % value).rstrip('0').rstrip('.')
        return str(value)

    def device_fact(self, spec):
        """{Device.key}: the current reading of ANY device, by name or alias.
        Keys are what All values shows (temperature, humidity, occupancy,
        switch.apower ...) plus a few conveniences: state (on/off of a plug
        or switch), age (how long since it last reported), model, battery,
        signal, name. Unknown -> None, so the placeholder disappears."""
        if '.' not in spec:
            return None
        who, key = spec.split('.', 1)
        key = key.strip()
        plug = self.plug_by_name(who) or next((p for p in self.plugs.values()
                                               if p.name.lower() == who.strip().lower()), None)
        if plug is not None:
            device_id, payload, ts = plug.device_id, dict(plug.flat or {}), plug.generated
            if not payload:
                # not answered since the restart: the last recorded reading,
                # exactly what the socket row shows greyed out
                entry = self.live.get(device_id) or {}
                payload = dict(entry.get('payload') or {})
                ts = entry.get('ts')
                if not payload:
                    cached = self.store._snap_cache.get(device_id)
                    if cached:
                        payload = dict(cached[0] or {})
            if key.lower() == 'state':
                if plug.unplugged:
                    return 'unplugged'
                if plug.output is not None:
                    return 'on' if plug.output else 'off'
        else:
            device_id = self.store.resolve(who.strip())
            if not device_id:
                return None
            entry = self.live.get(device_id) or {}
            payload = dict(entry.get('payload') or {})
            ts = entry.get('ts')
            if not payload:
                cached = self.store._snap_cache.get(device_id)
                if cached:
                    payload = dict(cached[0] or {})
        row = self.store.device(device_id) or {}
        lower = key.lower()
        if lower == 'name':
            return row.get('alias') or row.get('name') or who
        if lower == 'model':
            return row.get('model') or ''
        if lower == 'age':
            return human_age(time.time() - ts) if ts else 'never'
        if lower == 'battery':
            return payload.get('battery', payload.get('battery.percent'))
        if lower in ('signal', 'lqi'):
            return payload.get('linkquality', payload.get('wifi.rssi'))
        if lower == 'state':
            for k in ('state', 'switch.output', 'output'):
                if k in payload:
                    v = payload[k]
                    return v.lower() if isinstance(v, str) else ('on' if v else 'off')
            return None
        if key in payload:
            return payload[key]
        for k, v in payload.items():
            if k.lower() == lower:
                return v
        return None

    def fill_message(self, text, facts):
        """Put the facts of the moment into what someone wrote.

        {device}, {value}, {time} and the rest come from the moment itself;
        {Some-Device.key} reaches for the current reading of any device on
        the dashboard (the name as shown, then a dot, then the key from All
        values), so an alert can say what the outside thermometer reads or
        whether the UPS plug is on. Anything unknown is left as the empty
        string rather than the raw placeholder: a message reading "Motion in
        {room}" with no room is better than one reading "Motion in {room}"."""
        def swap(match):
            key = match.group(1).strip()
            value = facts.get(key.lower())
            if value is None and '.' in key:
                try:
                    value = self.device_fact(key)
                except Exception as e:
                    log('message fact %s: %s' % (key, e), 'debug')
                    value = None
            return self._fact_text(value)
        return re.sub(r'\{([A-Za-z0-9_][^{}]*)\}', swap, text).strip()

    def message_facts(self, origin, extra=None):
        now = datetime.now()
        state = self.presence_state()
        inside = [p['name'] for p in state['people'] if p['home'] and p.get('enabled', True)]
        outside = [p['name'] for p in state['people'] if not p['home'] and p.get('enabled', True)]
        facts = {'origin': origin, 'time': now.strftime('%H:%M'), 'date': now.strftime('%Y-%m-%d'),
                 'weekday': now.strftime('%A'),
                 'home': ', '.join(inside), 'away': ', '.join(outside),
                 'anyone_home': 'yes' if state['anyone_home'] else 'no',
                 'home_count': len(inside),
                 'device': '', 'value': '', 'key': '', 'target': '', 'action': '', 'person': '',
                 'unit': '', 'label': '', 'model': '', 'battery': '', 'signal': '',
                 'temperature': '', 'humidity': ''}
        # the sun, when the house has a position
        if CONFIG.get('latitude') is not None and CONFIG.get('longitude') is not None:
            try:
                lat, lon = float(CONFIG['latitude']), float(CONFIG['longitude'])
                rise, sset = sun_minutes(lat, lon), sun_minutes(lat, lon, sunset=True)
                minute = now.hour * 60 + now.minute
                facts['sunrise'] = '%02d:%02d' % divmod(int(rise), 60) if rise is not None else ''
                facts['sunset'] = '%02d:%02d' % divmod(int(sset), 60) if sset is not None else ''
                facts['daylight'] = 'day' if (rise is not None and sset is not None and rise <= minute < sset) else 'night'
            except Exception:
                pass
        # the house as a whole
        try:
            facts['alerts'] = len(self.active_alerts())
            attention = [d for d in self._last_devices_described() if d.get('level') in ('warn', 'crit')]
            facts['attention'] = len(attention)
            facts['attention_list'] = ', '.join(d['name'] for d in attention)
        except Exception:
            pass
        facts['uptime'] = human_age(time.time() - self.started)
        facts.update({k: v for k, v in (extra or {}).items() if v is not None})
        # more about the device that set it off, when there is one
        who = facts.get('device')
        if who:
            device_id = self.store.resolve(who)
            if device_id:
                row = self.store.device(device_id) or {}
                facts['model'] = row.get('model') or ''
                facts['alias'] = row.get('alias') or row.get('name') or who
                for k in ('battery', 'signal', 'temperature', 'humidity'):
                    v = self.device_fact('%s.%s' % (who, k))
                    if v is not None and facts.get(k) in ('', None):
                        facts[k] = v
                key = facts.get('key') or ''
                if key:
                    exposes = row.get('exposes') or {}
                    meta = exposes.get(key) if isinstance(exposes, dict) else None
                    facts['label'] = (meta or {}).get('label') or key_label(key)
                    facts['unit'] = (meta or {}).get('unit') or key_unit(key) or ''
        return facts

    def _last_devices_described(self):
        """The device list as status() last built it, without building it
        again on the message path."""
        cached = getattr(self, '_described_cache', None)
        if cached and time.time() - cached[0] < 30:
            return cached[1]
        devices = [self.describe(d, self.live.get(d['id'])) for d in self.store.devices()]
        self._described_cache = (time.time(), devices)
        return devices

    # -- taking something over by hand ----------------------------------------
    # A light on a motion rule is a nuisance the moment somebody wants it to
    # stay on: they press the switch, and the sensor turns it off again as
    # they walk past. So a button can take its target over - rules leave it
    # alone until the same button gives it back.
    def manual_holds(self):
        try:
            held = json.loads(self.store.get_meta('manual_holds') or '{}')
        except ValueError:
            return {}
        if not isinstance(held, dict):
            return {}
        now = time.time()
        alive = {k: v for k, v in held.items()
                 if not v.get('until') or v['until'] > now}
        if len(alive) != len(held):
            self.store.set_meta('manual_holds', json.dumps(alive), deferred=True)
        return alive

    def target_held(self, spec):
        """The hold that stands over this target, if any."""
        return self.manual_holds().get(str(spec or ''))

    def hold_target(self, spec, by, seconds=None):
        held = self.manual_holds()
        if seconds is None:
            seconds = numeric(CONFIG.get('manual_hold_s'))
            seconds = int(seconds) if seconds is not None else 14400
        held[str(spec)] = {'since': int(time.time()), 'by': by,
                           'until': (time.time() + seconds) if seconds else None}
        self.store.set_meta('manual_holds', json.dumps(held), deferred=True)
        self.store.add_event('control', '%s taken over by hand (%s)' % (self.target_label(spec), by))
        log('hold: %s is now on %s until it is given back' % (self.target_label(spec), by))
        self.bump()

    def release_target(self, spec=None):
        held = self.manual_holds()
        gone = []
        for key in list(held):
            if spec is None or key == str(spec):
                gone.append(key)
                del held[key]
        if gone:
            self.store.set_meta('manual_holds', json.dumps(held), deferred=True)
            for key in gone:
                self.store.add_event('control', '%s given back to its rules' % self.target_label(key))
                log('hold: %s is back under its rules' % self.target_label(key))
            self.bump()
        return len(gone)

    def hold_key(self, target):
        """The spec a resolved target is held under."""
        if target[0] == 'plug':
            return target[1].name
        if target[0] == 'zb':
            return 'zb:%s:%s' % (target[1], target[2])
        return None

    def active_alerts(self):
        """Critical alerts still standing. They are not a log: they sit on the
        page until someone says they have seen them."""
        rows = self.store.meta_json('active_alerts') or []
        return rows if isinstance(rows, list) else []

    def raise_alert(self, text, message_id=''):
        alerts = [a for a in self.active_alerts() if a.get('text') != text]
        alerts.append({'id': secrets.token_hex(4), 'ts': int(time.time()),
                       'text': text, 'message': message_id})
        self.store.set_meta('active_alerts', json.dumps(alerts[-30:]), deferred=True)
        self.bump()

    def clear_alerts(self, alert_id=None):
        before = self.active_alerts()
        kept = [a for a in before if alert_id and a['id'] != alert_id]
        self.store.set_meta('active_alerts', json.dumps(kept))
        gone = len(before) - len(kept)
        if gone:
            self.store.add_event('control', 'cleared %d standing alert(s)' % gone)
        self.bump()
        return gone

    def send_message(self, mid, origin, facts=None):
        message = self.message_by_id(mid) if mid else None
        if message is None:
            self.notify(origin, 'warn', dedup='alert|' + origin[:60])
            return origin
        text = self.fill_message(message['text'], self.message_facts(origin, facts)) or message['name']
        quiet = int(message.get('quiet_s') or 0)
        if quiet:
            # One decision for all three: the same words sent again inside the
            # window were suppressed as a notification but still piled up in
            # Events and on the band, so two rules pointing at one message
            # looked like the alert had fired twice.
            key = '%s|%s' % (message['id'], text)
            when = self._msg_last.get(key, 0)
            if time.time() - when < quiet:
                log('message "%s" held back: the same words %ds ago' % (message['name'], time.time() - when), 'debug')
                return text
            self._msg_last[key] = time.time()
            if len(self._msg_last) > 500:
                self._msg_last = {k: v for k, v in self._msg_last.items() if time.time() - v < 86400}
        facts_now = self.message_facts(origin, facts)
        self.notify(text, message['level'],
                    title=self.fill_message(message.get('title') or '', facts_now) or None,
                    image=message.get('image') or None)
        if message['level'] == 'crit':
            # A critical alert is the one somebody comes back to and reads, so
            # the log keeps the words themselves, in whatever language they
            # were written. What set it off is on the rule's own line just
            # above, so nothing is lost by not repeating it here.
            self.store.add_event('alert', text, 'crit')
            self.raise_alert(text, message['id'])
        else:
            # the quieter ones stay as the daemon describing itself
            self.store.add_event('alert', 'sent "%s": %s' % (message['name'], origin), message['level'])
        return text

    # -- Wi-Fi presence -------------------------------------------------------
    def wifi_config(self):
        # meta_json() is for the lists (rules, scenes...); this one is a single
        # object, so it is parsed here rather than filtered down to nothing
        try:
            cfg = json.loads(self.store.get_meta('wifi') or '{}')
        except ValueError:
            cfg = {}
        if not isinstance(cfg, dict):
            cfg = {}
        cfg.setdefault('enabled', False)
        cfg.setdefault('port', 443)
        cfg.setdefault('method', 'official')
        cfg.setdefault('verify_ssl', False)
        cfg.setdefault('site', 'default')
        cfg.setdefault('poll_s', WIFI_POLL_S)
        cfg.setdefault('grace_s', PRESENCE_GRACE_S)
        cfg.setdefault('detail_s', 180)
        cfg.setdefault('ssh_enabled', False)
        cfg.setdefault('ssh_user', 'admin')
        cfg.setdefault('ssh_auth', 'key')
        cfg.setdefault('ssh_port', 22)
        cfg.setdefault('presence_ntfy', '')
        return cfg

    def save_wifi_config(self, incoming):
        """Secrets are kept rather than echoed: the page sends back what it was
        shown, and it is never shown a key it did not type."""
        old = self.wifi_config()
        cfg = dict(old)
        url = incoming.get('presence_ntfy')
        if url is not None:
            url = str(url or '').strip()
            if url and not re.match(r'^https?://[A-Za-z0-9.:-]+/[A-Za-z0-9_-]{6,64}$', url.rstrip('/')):
                raise ValueError('the presence topic should look like https://ntfy.sh/<a-long-random-name>')
            cfg['presence_ntfy'] = url.rstrip('/')
        for field in ('host', 'site', 'username', 'method', 'ssh_user', 'ssh_auth'):
            if field in incoming:
                cfg[field] = str(incoming.get(field) or '').strip()
        if 'port' in incoming:
            try:
                cfg['port'] = max(1, min(65535, int(incoming.get('port') or 443)))
            except (TypeError, ValueError):
                raise ValueError('the port must be a number')
        for field in ('api_key', 'password', 'ssh_password'):
            value = incoming.get(field)
            if value:                     # blank means "leave what is stored"
                cfg[field] = str(value)
        for field in ('enabled', 'verify_ssl', 'ssh_enabled'):
            if field in incoming:
                cfg[field] = bool(incoming.get(field))
        for field, low, high in (('poll_s', 3, 900), ('grace_s', 0, 86400), ('detail_s', 0, 3600)):
            if field in incoming:
                value = numeric(incoming.get(field))
                if value is None or not low <= value <= high:
                    raise ValueError('%s must be between %d and %d seconds' % (field, low, high))
                cfg[field] = int(value)
        if 'ssh_port' in incoming:
            try:
                cfg['ssh_port'] = max(1, min(65535, int(incoming.get('ssh_port') or 22)))
            except (TypeError, ValueError):
                raise ValueError('the SSH port must be a number')
        if cfg.get('ssh_auth') not in ('key', 'password'):
            cfg['ssh_auth'] = 'key'
        if cfg.get('ssh_enabled'):
            if not cfg.get('ssh_user'):
                raise ValueError('reading the access points needs a username for them')
            if cfg['ssh_auth'] == 'key' and not cfg.get('ssh_key'):
                raise ValueError('no private key is stored yet - generate one or upload yours')
            if cfg['ssh_auth'] == 'password' and not cfg.get('ssh_password'):
                raise ValueError('reading the access points by password needs that password')
        if cfg.get('method') not in ('official', 'legacy', 'both'):
            cfg['method'] = 'official'
        if cfg.get('ssh_enabled') and cfg['method'] == 'both':
            # the points cover what signing in was for; leave the controller's
            # login counter alone
            cfg['method'] = 'official'
            self.store.add_event('control', 'the access points are read directly now, so the controller '
                                            'is only asked with its API key')
        if cfg['method'] == 'both' and not (cfg.get('username') and cfg.get('password')):
            raise ValueError('reading both ways needs a username and a password as well as the key')
        if cfg['method'] in ('legacy', 'both') and not cfg.get('username'):
            raise ValueError('signing in needs a username')
        if cfg.get('enabled') and not cfg.get('host'):
            raise ValueError('the controller needs an address')
        self._presence_cache = None
        self.store.set_meta('wifi', json.dumps(cfg))
        _UNIFI_SESSIONS.clear()          # new details deserve a fresh try
        self.store.add_event('control', 'Wi-Fi presence settings saved')
        self._wifi_kick.set()
        self.bump()
        return self.wifi_public(cfg)

    @staticmethod
    def wifi_public(cfg):
        """The settings as the page may see them: never the key or password,
        only whether one is stored."""
        out = {k: v for k, v in cfg.items() if k not in ('api_key', 'password', 'ssh_key', 'ssh_password')}
        out['has_api_key'] = bool(cfg.get('api_key'))
        out['has_password'] = bool(cfg.get('password'))
        out['has_ssh_key'] = bool(cfg.get('ssh_key'))
        out['has_ssh_password'] = bool(cfg.get('ssh_password'))
        out['ssh_public'] = cfg.get('ssh_public') or ''
        out['ssh_ready'] = ssh_available()
        return out

    def monthly_summary(self, force=False):
        """On the first of the month, what last month drank and who drank it."""
        lt = time.localtime()
        tag = time.strftime('%Y-%m', lt)
        if not force:
            if lt.tm_mday != 1 or lt.tm_hour < 9:
                return None
            if self._month_done == tag or self.store.get_meta('monthly_summary_sent') == tag:
                return None
        data = self.energy_summary()
        rows = sorted(data['plugs'], key=lambda r: -(r['last_month_wh'] or 0))
        total = sum(r['last_month_wh'] or 0 for r in rows) / 1000.0
        price = numeric(CONFIG.get('price_per_kwh'))
        cur = CONFIG.get('currency') or ''
        month_name = time.strftime('%B %Y', time.localtime(time.mktime(
            (lt.tm_year - (1 if lt.tm_mon == 1 else 0), 12 if lt.tm_mon == 1 else lt.tm_mon - 1, 1, 12, 0, 0, 0, 0, -1))))
        lines = ['%s: %.1f kWh' % (month_name, total) + (' \u00b7 %.0f %s' % (total * price, cur) if price else '')]
        rooms = {r['id']: r['name'] for r in self.rooms()}
        mapping = self.room_map()
        by_room = {}
        for row in rows:
            name = rooms.get(mapping.get(row['name']), '')
            if name:
                by_room[name] = by_room.get(name, 0) + (row['last_month_wh'] or 0)
        for row in rows[:5]:
            if not row['last_month_wh']:
                continue
            kwh = row['last_month_wh'] / 1000.0
            lines.append('%s %.1f kWh' % (row['name'], kwh) + (' \u00b7 %.0f %s' % (kwh * price, cur) if price else ''))
        if by_room:
            best = sorted(by_room.items(), key=lambda x: -x[1])[:3]
            lines.append('by room: ' + ', '.join('%s %.1f kWh' % (n, w / 1000.0) for n, w in best))
        text = '\n'.join(lines)
        if not force:
            self._month_done = tag
            self.store.set_meta('monthly_summary_sent', tag)
        self.store.add_event('energy', 'monthly summary: %s' % lines[0], 'info')
        if CONFIG.get('monthly_summary', True):
            self.notify(text, 'info', title='Energy \u2013 %s' % month_name)
        return text

    # ---- heating: rooms with a temperature to hold ------------------------------
    HEAT_LEVELS = ('comfort', 'eco', 'night', 'off')

    def heating_config(self):
        """Per room: the three temperatures, a weekly plan of which one
        applies when, and what to do while nobody is home."""
        try:
            cfg = json.loads(self.store.get_meta('heating') or '{}')
        except ValueError:
            cfg = {}
        if not isinstance(cfg, dict):
            cfg = {}
        cfg.setdefault('away', False)           # the holiday switch
        cfg.setdefault('away_c', 16.0)
        cfg.setdefault('enabled', True)
        rooms = cfg.get('rooms')
        cfg['rooms'] = rooms if isinstance(rooms, dict) else {}
        for rid, room in list(cfg['rooms'].items()):
            if not isinstance(room, dict):
                cfg['rooms'].pop(rid)
                continue
            room.setdefault('mode', 'plan')      # plan | comfort | eco | night | off
            room.setdefault('comfort_c', 21.0)
            room.setdefault('eco_c', 18.0)
            room.setdefault('night_c', 17.0)
            room.setdefault('window_stop', True)
            room.setdefault('heated', True)          # False: no heating in this room; it is left out of the Heating tab
            room.setdefault('control', True)         # False: heating exists, but zigmon keeps its hands off for now
            room.setdefault('hold_c', None)           # a temperature set by hand (a knob, a card) ...
            room.setdefault('hold_until', 0)          # ... good until this time, or until the plan's next step
            room.setdefault('hold_level', '')         # the plan level that was current when it was set
            room.setdefault('thermometer', '')      # a device id; empty = whatever is in the room
            windows = room.get('windows')
            room['windows'] = [str(w) for w in windows] if isinstance(windows, list) else []   # empty = every contact in the room
            plan = room.get('plan')
            room['plan'] = plan if isinstance(plan, list) else []
        return cfg

    def save_heating(self, incoming):
        cfg = self.heating_config()
        if 'away' in (incoming or {}):
            cfg['away'] = bool(incoming['away'])
        if 'enabled' in (incoming or {}):
            cfg['enabled'] = bool(incoming['enabled'])
        away_c = numeric((incoming or {}).get('away_c'))
        if away_c is not None:
            cfg['away_c'] = max(5.0, min(30.0, float(away_c)))
        rooms = (incoming or {}).get('rooms')
        if isinstance(rooms, dict):
            known = {r['id'] for r in self.rooms()}
            clean = {}
            for rid, room in rooms.items():
                if rid not in known or not isinstance(room, dict):
                    continue
                room = dict(cfg['rooms'].get(rid) or {}, **room)    # what is not sent is kept
                mode = str(room.get('mode') or 'plan').strip().lower()
                if mode not in ('plan',) + self.HEAT_LEVELS:
                    mode = 'plan'
                out = {'mode': mode, 'window_stop': bool(room.get('window_stop', True)),
                       'heated': bool(room.get('heated', True)), 'control': bool(room.get('control', True)),
                       'hold_c': room.get('hold_c') if isinstance(room.get('hold_c'), (int, float)) else None,
                       'hold_until': float(room.get('hold_until') or 0), 'hold_level': str(room.get('hold_level') or '')}
                thermo = str(room.get('thermometer') or '').strip()
                out['thermometer'] = thermo if thermo and self.store.device(self.store.resolve(thermo) or thermo) else ''
                out['windows'] = [str(w) for w in (room.get('windows') or [])
                                  if str(w).strip() and self.store.device(self.store.resolve(str(w)) or str(w))][:20]
                for field, low, high, fallback in (('comfort_c', 5, 35, 21.0), ('eco_c', 5, 35, 18.0),
                                                   ('night_c', 5, 35, 17.0)):
                    value = numeric(room.get(field))
                    out[field] = float(value) if value is not None and low <= value <= high else fallback
                plan = []
                for step in room.get('plan') or []:
                    if not isinstance(step, dict):
                        continue
                    at = str(step.get('at') or '').strip()
                    if not re.match(r'^([01]\d|2[0-3]):[0-5]\d$', at):
                        raise ValueError('a heating step is set for %r; it should look like 06:30' % at)
                    level = str(step.get('level') or 'comfort').strip().lower()
                    if level not in self.HEAT_LEVELS:
                        raise ValueError('%r is not one of %s' % (level, ', '.join(self.HEAT_LEVELS)))
                    days = [int(d) for d in (step.get('days') or []) if str(d).isdigit() and 0 <= int(d) <= 6]
                    plan.append({'at': at, 'level': level, 'days': sorted(set(days)) or [0, 1, 2, 3, 4, 5, 6]})
                    if len(plan) >= 24:
                        break
                out['plan'] = sorted(plan, key=lambda x: x['at'])
                clean[rid] = out
            cfg['rooms'] = clean
        self.store.set_meta('heating', json.dumps(cfg))
        if not (incoming or {}).get('_quiet'):
            self.store.add_event('control', 'heating settings saved')
        # NOT reset here: heating_apply compares each valve's wanted number
        # with what it was last SENT, so a changed wish goes out on the next
        # round by itself. Wiping the memory made every save - every knob
        # click, every preset - re-send every valve in the house its current
        # number, and sleeping heads then drained a queue of repeats.
        self.bump()
        return cfg

    def room_valves(self, rid):
        """(device row, the key its target sits under) for every valve in a room."""
        out = []
        members = set(self.room_member_ids(rid))
        for target in self.zigbee_targets():
            if target.get('kind') != 'number' or not target['key'].endswith('heating_setpoint'):
                continue
            if target['id'] in members:
                out.append(target)
        return out

    def _reading_of(self, device_id):
        entry = self.live.get(device_id) or {}
        payload = entry.get('payload') or {}
        if not payload:
            cached = self.store._snap_cache.get(device_id)
            payload = dict(cached[0] or {}) if cached else {}
        for key in ('temperature', 'local_temperature', 'tC'):
            if isinstance(payload.get(key), (int, float)):
                return float(payload[key])
        return None

    def room_temperature(self, rid, settings=None):
        """What the room reads: the thermometer chosen for it if one is, else
        its own thermometers averaged, else the valves' own measurement."""
        chosen = (settings or {}).get('thermometer') or ''
        if chosen:
            device_id = self.store.resolve(chosen) or chosen
            value = self._reading_of(device_id)
            if value is not None:
                return round(value, 1)
        own, fallback = [], []
        for device_id in self.room_member_ids(rid):
            entry = self.live.get(device_id) or {}
            payload = entry.get('payload') or {}
            if not payload:
                cached = self.store._snap_cache.get(device_id)
                payload = dict(cached[0] or {}) if cached else {}
            if isinstance(payload.get('temperature'), (int, float)):
                own.append(float(payload['temperature']))
            elif isinstance(payload.get('local_temperature'), (int, float)):
                fallback.append(float(payload['local_temperature']))
        pick = own or fallback
        return round(sum(pick) / len(pick), 1) if pick else None

    def next_plan_change(self, room, when=None):
        """When the plan next changes level - the natural end of a hand-set
        temperature. None when there is no plan to change."""
        plan = room.get('plan') or []
        if not plan or (room.get('mode') or 'plan') != 'plan':
            return None
        now = when or time.time()
        current = self.heating_level(room, now)
        # walk forward step by step for a week at most
        lt = time.localtime(now)
        day_start = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
        for day in range(0, 8):
            base = day_start + day * 86400
            wday = (time.localtime(base + 43200).tm_wday + 1) % 7
            for step in sorted(plan, key=lambda x: x['at']):
                if wday not in step['days']:
                    continue
                hh, mm = step['at'].split(':')
                at = base + int(hh) * 3600 + int(mm) * 60
                if at <= now:
                    continue
                if step['level'] != current:
                    return at
        return None

    def room_hold(self, room, when=None):
        """The hand-set temperature if it still applies, else None."""
        hold = room.get('hold_c')
        if not isinstance(hold, (int, float)):
            return None
        now = when or time.time()
        if float(room.get('hold_until') or 0) and now > float(room['hold_until']):
            return None
        if (room.get('mode') or 'plan') == 'plan' and room.get('hold_level') and self.heating_level(room, now) != room['hold_level']:
            return None                            # the plan moved on; the hand is lifted
        return float(hold)

    def heating_level(self, room, when=None):
        """Which of the three temperatures applies right now."""
        mode = room.get('mode') or 'plan'
        if mode != 'plan':
            return mode
        lt = time.localtime(when or time.time())
        minute = lt.tm_hour * 60 + lt.tm_min
        today = (lt.tm_wday + 1) % 7          # 0 = Sunday, as the schedules use
        best, best_at = None, -1
        for step in room.get('plan') or []:
            if today not in step['days']:
                continue
            hh, mm = step['at'].split(':')
            at = int(hh) * 60 + int(mm)
            if at <= minute and at > best_at:
                best, best_at = step['level'], at
        if best is not None:
            return best
        # nothing yet today: whatever the last step of the day before said
        yesterday = (today - 1) % 7
        last, last_at = None, -1
        for step in room.get('plan') or []:
            if yesterday not in step['days']:
                continue
            hh, mm = step['at'].split(':')
            at = int(hh) * 60 + int(mm)
            if at > last_at:
                last, last_at = step['level'], at
        return last or 'eco'

    def room_window_open(self, rid, settings=None):
        """Open if any of the room's window sensors says so - the chosen ones
        when some are chosen, otherwise every contact sensor in the room."""
        chosen = (settings or {}).get('windows') or []
        ids = [self.store.resolve(w) or w for w in chosen] if chosen else self.room_member_ids(rid)
        for device_id in ids:
            entry = self.live.get(device_id) or {}
            payload = entry.get('payload') or {}
            for key in ('contact', 'window', 'window_open', 'open_window'):
                if key in payload:
                    value = payload[key]
                    if key == 'contact':
                        return not bool(value)      # contact false = the window is open
                    if isinstance(value, str):
                        return value.upper() in ('ON', 'TRUE', 'OPEN')
                    if value:
                        return True
        return False

    def heating_state(self):
        """What the Heating screen shows, and what the loop below acts on."""
        cfg = self.heating_config()
        rooms = []
        for room in self.rooms():
            settings = cfg['rooms'].get(room['id']) or {'mode': 'plan', 'comfort_c': 21.0, 'eco_c': 18.0,
                                                        'night_c': 17.0, 'plan': [], 'window_stop': True}
            valves = self.room_valves(room['id'])
            level = self.heating_level(settings)
            hold = self.room_hold(settings)
            window = settings.get('window_stop', True) and self.room_window_open(room['id'], settings)
            if not settings.get('heated', True):
                wanted, why = None, 'no heating in this room'
            elif not cfg.get('enabled'):
                wanted, why = None, 'heating is switched off'
            elif not settings.get('control', True):
                wanted, why = None, 'control is off for this room'
            elif window:
                wanted, why = 5.0, 'a window is open'
            elif hold is not None:
                wanted, why = hold, 'by hand'
            elif cfg.get('away') and level != 'off':
                wanted, why = float(cfg.get('away_c') or 16.0), 'away'
            elif level == 'off':
                wanted, why = 5.0, 'off'
            else:
                wanted, why = float(settings.get(level + '_c') or 20.0), level
            rooms.append({
                'id': room['id'], 'name': room['name'],
                'heated': bool(settings.get('heated', True)),
                'control': bool(settings.get('control', True)),
                'hold_c': hold, 'hold_until': (settings.get('hold_until') if hold is not None else None),
                'thermometer': settings.get('thermometer') or '',
                'windows': settings.get('windows') or [],
                'mode': settings.get('mode', 'plan'), 'level': level,
                'comfort_c': settings.get('comfort_c'), 'eco_c': settings.get('eco_c'),
                'night_c': settings.get('night_c'), 'plan': settings.get('plan') or [],
                'window_stop': settings.get('window_stop', True), 'window_open': window,
                'wanted_c': wanted, 'why': why,
                'temperature': self.room_temperature(room['id'], settings),
                'valves': [self._valve_facts(v) for v in valves],
            })
        return {'enabled': bool(cfg.get('enabled')), 'away': bool(cfg.get('away')),
                'away_c': cfg.get('away_c'), 'rooms': rooms}

    def heat_target(self, what, do, origin, hold_s=None):
        """Heating driven like a switch: heat:control and heat:away take on /
        off / toggle; a room takes set:<level> (comfort, eco, night, off, or
        plan to hand it back to the plan), or on = plan, off = off."""
        do = str(do or '').strip()
        cfg = self.heating_config()
        low = do.lower()
        if what in ('control', 'away'):
            key = 'enabled' if what == 'control' else 'away'
            if low == 'toggle':
                value = not cfg.get(key)
            elif low in ('on', 'off'):
                value = low == 'on'
            elif low.startswith('set:'):
                value = low[4:].strip() in ('on', 'true', '1', 'yes')
            else:
                log('heating %s: %r is not on, off or toggle' % (what, do), 'warn')
                return
            self.save_heating({key: value, '_quiet': True})
            self.store.add_event('heating', 'heating %s %s (%s)' % ('control' if what == 'control' else 'away mode',
                                                                   'on' if value else 'off', origin), 'info')
            log('heating %s %s (%s)' % (what, 'on' if value else 'off', origin))
            self.heating_apply()
            return
        if what.startswith('temp:'):
            # the room's temperature turned by hand: to X, up by d, down by d;
            # it holds until the plan next changes level (or four hours when
            # there is no plan), then the plan has it back
            rid = what[5:]
            room = next((r for r in self.rooms() if r['id'] == rid), None)
            if room is None or not low.startswith('set:'):
                return
            raw = do[4:].strip()
            settings = dict(cfg['rooms'].get(rid) or {})
            state = next((r for r in self.heating_state()['rooms'] if r['id'] == rid), None)
            base = state['wanted_c'] if state and isinstance(state.get('wanted_c'), (int, float)) else None
            try:
                if raw[:1] in ('+', '-'):
                    if base is None:
                        base = float(settings.get(self.heating_level(settings) + '_c', 20) or 20) if self.heating_level(settings) != 'off' else 18.0
                    value = base + float(raw)
                else:
                    value = float(raw)
            except ValueError:
                log('temperature in %s: %r is not a number' % (room['name'], do), 'warn')
                return
            value = round(max(5.0, min(30.0, value)) * 2) / 2.0
            hold = numeric(hold_s)
            if hold is not None and hold > 0:
                # a chosen length: for that long, whatever the plan does meanwhile
                until, level_lock = time.time() + float(hold), ''
            else:
                # the natural end: the plan's next change of level, or four hours
                until, level_lock = self.next_plan_change(settings) or (time.time() + 4 * 3600), self.heating_level(settings)
            settings.update({'hold_c': value, 'hold_until': until, 'hold_level': level_lock})
            rooms = dict(cfg['rooms']); rooms[rid] = settings
            self.save_heating({'rooms': rooms, '_quiet': True})
            self.store.add_event('heating', '%s set to %g \u00b0C by hand (%s)' % (room['name'], value, origin), 'info')
            log('heating: %s -> %g by hand until %s (%s)' % (room['name'], value, time.strftime('%H:%M', time.localtime(until)), origin))
            # a knob's burst of clicks becomes one push to the valves, a
            # moment after the last click (the card is right at once either way)
            timer = getattr(self, '_heat_push_timer', None)
            if timer is not None:
                timer.cancel()
            timer = threading.Timer(0.3, self.heating_apply)
            timer.daemon = True
            self._heat_push_timer = timer
            timer.start()
            self.bump()
            return
        if what.startswith('control:'):
            rid = what[8:]
            room = next((r for r in self.rooms() if r['id'] == rid), None)
            if room is None:
                return
            current = dict(cfg['rooms'].get(rid) or {})
            if low == 'toggle':
                value = not current.get('control', True)
            elif low in ('on', 'off'):
                value = low == 'on'
            elif low.startswith('set:'):
                value = low[4:].strip() in ('on', 'true', '1', 'yes')
            else:
                log('heating control %s: %r is not on, off or toggle' % (room['name'], do), 'warn')
                return
            current['control'] = value
            rooms = dict(cfg['rooms']); rooms[rid] = current
            self.save_heating({'rooms': rooms, '_quiet': True})
            self.store.add_event('heating', 'control in %s %s (%s)' % (room['name'], 'on' if value else 'off', origin), 'info')
            log('heating control in %s %s (%s)' % (room['name'], 'on' if value else 'off', origin))
            self.heating_apply()
            return
        if what.startswith('room:'):
            rid = what[5:]
            room = next((r for r in self.rooms() if r['id'] == rid), None)
            if room is None:
                return
            if low == 'on':
                level = 'plan'
            elif low == 'off':
                level = 'off'
            elif low == 'toggle':
                level = 'off' if (cfg['rooms'].get(rid) or {}).get('mode') != 'off' else 'plan'
            elif low.startswith('set:'):
                level = low[4:].strip()
            else:
                level = ''
            if level == 'next':
                # one button cycling the presets: plan -> comfort -> eco -> night -> plan
                ring = ['plan', 'comfort', 'eco', 'night']
                now_mode = (cfg['rooms'].get(rid) or {}).get('mode') or 'plan'
                level = ring[(ring.index(now_mode) + 1) % len(ring)] if now_mode in ring else 'plan'
            if level not in ('plan',) + self.HEAT_LEVELS:
                log('heating %s: %r is not plan, comfort, eco, night or off' % (room['name'], do), 'warn')
                return
            rooms = dict(cfg['rooms'])
            current = dict(rooms.get(rid) or {})
            current['mode'] = level
            current['hold_c'] = None               # a level chosen outright ends a hand-set temperature
            rooms[rid] = current
            self.save_heating({'rooms': rooms, '_quiet': True})
            self.store.add_event('heating', '%s set to %s (%s)' % (room['name'], level, origin), 'info')
            log('heating: %s -> %s (%s)' % (room['name'], level, origin))
            self.heating_apply()

    def valve_take_over(self, device_id):
        """A head with a mind of its own has to be told to stop using it.

        A TuYa/Immax TS0601 head keeps a weekly programme, an away mode and a
        preset; while any of those is in charge, a set point we send is
        obeyed for a moment and then overwritten by its own schedule. So
        before driving one, put it in manual and clear away mode - once, and
        only when its own report says it is not already there."""
        dev = self.store.device(device_id)
        if not dev:
            return
        exposes = dev.get('exposes') or {}
        payload = (self.live.get(device_id) or {}).get('payload') or {}
        wants = {}
        def settable(key):
            info = exposes.get(key) or {}
            access = info.get('access')
            return key in exposes and (access is None or access & 2)
        if settable('preset'):
            values = [str(v) for v in ((exposes.get('preset') or {}).get('values') or [])]
            pick = next((v for v in values if v.lower() in ('manual', 'programming', 'comfort')), None)
            if pick and str(payload.get('preset') or '').lower() != pick.lower():
                wants['preset'] = pick
        if settable('system_mode'):
            values = [str(v) for v in ((exposes.get('system_mode') or {}).get('values') or [])]
            # On a TuYa TS0601 head "heat" means heat flat out without
            # regulating, and "auto" means hold the set point - the opposite
            # of what the words suggest. Those heads say so by also exposing
            # a preset, which is what decides schedule versus manual there.
            # A plain thermostat has no preset, and for it "heat" is right.
            if 'preset' in exposes:
                order = ('auto', 'manual', 'heat')
                good = ('auto', 'manual')
            else:
                order = ('heat', 'manual', 'auto')
                good = ('heat', 'manual')
            pick = next((v for want in order for v in values if v.lower() == want), None)
            if pick and str(payload.get('system_mode') or '').lower() not in good:
                wants['system_mode'] = pick
        if settable('away_mode') and str(payload.get('away_mode') or '').upper() == 'ON':
            wants['away_mode'] = 'OFF'
        # "force" pins the valve open or shut whatever the set point says; a
        # head left on "open" heats the room flat out and looks like it is
        # ignoring us
        if settable('force'):
            values = [str(v) for v in ((exposes.get('force') or {}).get('values') or [])]
            normal = next((v for v in values if v.lower() == 'normal'), None)
            if normal and str(payload.get('force') or '').lower() not in ('', 'normal'):
                wants['force'] = normal
        if not wants:
            return
        last = self._valve_mode.get(device_id)
        if last and time.time() - last[0] < 300 and last[1] == wants:
            return                              # already asked, and it has not reported back yet
        self._valve_mode[device_id] = (time.time(), dict(wants))
        for key, value in wants.items():
            ok, message = self.zigbee_switch(device_id, key, 'set:%s' % value,
                                             'heating: taking the valve off its own programme')
            if not ok:
                log('valve %s: %s' % (dev.get('name') or device_id, message), 'warn')

    def _valve_facts(self, target):
        """What a head is telling us about itself, for its room's card."""
        device_id = target['id']
        payload = (self.live.get(device_id) or {}).get('payload') or {}
        if not payload:
            cached = self.store._snap_cache.get(device_id)
            payload = dict(cached[0] or {}) if cached else {}
        def num(*keys):
            for k in keys:
                if isinstance(payload.get(k), (int, float)):
                    return float(payload[k])
            return None
        return {
            'target': target['value'], 'name': (self.store.device(device_id) or {}).get('name') or device_id,
            'setpoint': target.get('state'), 'min': target.get('min'), 'max': target.get('max'),
            'online': target.get('online', True),
            'local_c': num('local_temperature'),
            'position': num('position', 'pi_heating_demand', 'valve_position'),
            'running': str(payload.get('running_state') or '') or None,
            'battery': num('battery'),
            'battery_low': bool(payload.get('battery_low')),
            'calibration': num('local_temperature_calibration'),
            'can_calibrate': 'local_temperature_calibration' in (self.store.device(device_id) or {}).get('exposes', {}),
            'mode': str(payload.get('system_mode') or payload.get('preset') or '') or None,
            'force': str(payload.get('force') or '') or None,
        }

    def calibrate_valve(self, target_spec, origin='the dashboard'):
        """Teach a head what the room really reads. A head sits on the
        radiator, so its own thermometer runs warm; the offset it accepts
        (local_temperature_calibration) is exactly for this."""
        spec = self._valid_target(target_spec)
        if not spec or not spec.startswith('zb:'):
            return False, 'unknown valve'
        device_id = ':'.join(spec.split(':')[1:-1])
        rid = self.room_of(device_id) or self.room_of((self.store.device(device_id) or {}).get('name') or '')
        settings = self.heating_config()['rooms'].get(rid) or {} if rid else {}
        room_c = self.room_temperature(rid, settings) if rid else None
        payload = (self.live.get(device_id) or {}).get('payload') or {}
        head_c = payload.get('local_temperature')
        if room_c is None or not isinstance(head_c, (int, float)):
            return False, 'need both the room thermometer and the head to have reported'
        old = payload.get('local_temperature_calibration')
        old = float(old) if isinstance(old, (int, float)) else 0.0
        # the head reports head_c with the old offset already applied
        offset = round((old + (room_c - float(head_c))) * 2) / 2.0
        offset = max(-9.0, min(9.0, offset))
        ok, message = self.zigbee_switch(device_id, 'local_temperature_calibration', 'set:=%g' % offset,
                                         'calibrating to the room thermometer (%s)' % origin)
        if ok:
            self.store.add_event('heating', 'calibrated %s to %g \u00b0C (room reads %g, head read %g)'
                                 % ((self.store.device(device_id) or {}).get('name') or device_id, offset, room_c, head_c), 'info')
            return True, 'offset set to %+g \u00b0C' % offset
        return False, message

    def heating_apply(self):
        """Push each room's wish to its valves, and only when it has changed:
        a head is a sleeping device, and re-sending the same number every
        minute would keep it awake for nothing."""
        if not self.rooms():
            return
        state = self.heating_state()
        if not state['enabled']:
            return
        for room in state['rooms']:
            wanted = room['wanted_c']
            if wanted is None or not room['valves']:
                continue
            for valve in room['valves']:
                key = valve['target']
                low, high = valve.get('min'), valve.get('max')
                value = wanted
                if isinstance(low, (int, float)):
                    value = max(float(low), value)
                if isinstance(high, (int, float)):
                    value = min(float(high), value)
                last = self._heat_last.get(key)
                if last is not None and abs(last - value) < 0.05:
                    continue                     # already asked for this
                current = valve.get('setpoint')
                if last is None and isinstance(current, (int, float)) and abs(float(current) - value) < 0.05:
                    self._heat_last[key] = value
                    continue                     # the head is already holding it
                pieces = key.split(':')
                device_id = ':'.join(pieces[1:-1])
                # A room told to shut wants the valve SHUT, and a set point of
                # five does not do that on a head whose own thermometer sits on
                # the radiator and reads warmer than the room - it just keeps
                # regulating. Where the head has an "off" mode, use it; that is
                # what closes the valve.
                closing = room['why'] in ('off', 'a window is open')
                exposes = (self.store.device(device_id) or {}).get('exposes') or {}
                modes = [str(v) for v in ((exposes.get('system_mode') or {}).get('values') or [])]
                off_mode = next((v for v in modes if v.lower() == 'off'), None)
                if closing and off_mode:
                    if str(((self.live.get(device_id) or {}).get('payload') or {}).get('system_mode') or '').lower() != 'off':
                        ok, message = self.zigbee_switch(device_id, 'system_mode', 'set:%s' % off_mode,
                                                         'heating: %s is %s' % (room['name'], room['why']))
                        if not ok:
                            log('heating: %s' % message, 'warn')
                    self._heat_last[key] = value      # the number stands, the mode does the shutting
                    continue
                self.valve_take_over(device_id)   # its own programme must not fight ours
                ok, message = self.zigbee_switch(device_id, pieces[-1], 'set:%g' % value,
                                                 'heating: %s is %s' % (room['name'], room['why']))
                if ok:
                    self._heat_last[key] = value
                else:
                    log('heating: %s' % message, 'warn')

    # ---- rooms: the one bit of structure over a flat list of devices ------------
    def rooms(self):
        rows = self.store.meta_json('rooms') or []
        return [r for r in rows if r.get('id') and r.get('name')]

    def save_rooms(self, items):
        clean, seen = [], set()
        for index, room in enumerate(items or []):
            if not isinstance(room, dict):
                continue
            name = str(room.get('name') or '').strip()
            if not name:
                raise ValueError('room %d needs a name' % (index + 1))
            if len(name) > 40:
                raise ValueError('a room name is at most 40 characters')
            rid = str(room.get('id') or '').strip() or secrets.token_hex(3)
            if rid in seen:
                continue
            seen.add(rid)
            clean.append({'id': rid, 'name': name})
        self.store.set_meta('rooms', json.dumps(clean))
        # anything left pointing at a room that has gone is simply unassigned
        mapping = {k: v for k, v in self.room_map().items() if v in seen}
        self.store.set_meta('room_of', json.dumps(mapping))
        self.store.add_event('control', '%d room(s) saved' % len(clean))
        self.bump()
        return clean

    def reorder_rooms(self, order):
        """The Heating cards moved about: the rooms keep their names and what
        is in them, only the order changes."""
        rooms = self.rooms()
        by_id = {r['id']: r for r in rooms}
        out = [by_id.pop(rid) for rid in [str(x) for x in order] if rid in by_id]
        out += [r for r in rooms if r['id'] in by_id]        # anything not mentioned keeps its place at the end
        self.store.set_meta('rooms', json.dumps(out))
        self.bump()
        return [r['id'] for r in out]

    def room_map(self):
        try:
            rows = json.loads(self.store.get_meta('room_of') or '{}')
        except ValueError:
            rows = {}
        return {str(k): str(v) for k, v in rows.items()} if isinstance(rows, dict) else {}

    def save_room_map(self, mapping):
        known = {r['id'] for r in self.rooms()}
        clean = {}
        for key, rid in (mapping or {}).items():
            key, rid = str(key).strip(), str(rid or '').strip()
            if key and rid and rid in known:
                clean[key] = rid
        self.store.set_meta('room_of', json.dumps(clean))
        self.bump()
        return clean

    def room_of(self, key):
        return self.room_map().get(str(key))

    def room_members(self):
        """room id -> the keys in it, as they were assigned (a device id, or a
        plug's name)."""
        out = {}
        for key, rid in self.room_map().items():
            out.setdefault(rid, []).append(key)
        return out

    def room_member_ids(self, rid):
        """The same, resolved to device ids, so a room assigned by name and
        one assigned by address read alike."""
        out = []
        for key in self.room_members().get(rid) or []:
            resolved = self.store.resolve(key) or key
            if resolved not in out:
                out.append(resolved)
        return out

    def people(self):
        rows = self.store.meta_json('people') or []
        return rows if isinstance(rows, list) else []

    def save_people(self, items):
        clean = []
        seen_macs = {}
        for index, person in enumerate(items or []):
            if not isinstance(person, dict):
                continue
            name = str(person.get('name') or '').strip()
            if not name:
                raise ValueError('person %d needs a name' % (index + 1))
            macs = []
            for mac in person.get('macs') or []:
                mac = str(mac or '').strip()
                if mac.lower().startswith('name:'):
                    label = mac[5:].strip()
                    if not 1 <= len(label) <= 60:
                        raise ValueError('a device name must be 1-60 characters')
                    mac = 'name:' + label
                    if mac.lower() in seen_macs:
                        raise ValueError('%s is already assigned to %s' % (mac, seen_macs[mac.lower()]))
                    seen_macs[mac.lower()] = name
                    macs.append(mac)
                    continue
                mac = mac.lower()
                if not mac:
                    continue
                if not re.match(r'^([0-9a-f]{2}:){5}[0-9a-f]{2}$', mac):
                    raise ValueError('%r is not a MAC address' % mac)
                if mac in seen_macs:
                    raise ValueError('%s is already assigned to %s' % (mac, seen_macs[mac]))
                seen_macs[mac] = name
                macs.append(mac)
            grace = numeric(person.get('grace_s'))
            token = str(person.get('token') or '').strip()
            if token == 'new' or (person.get('phone_report') and not token):
                token = secrets.token_urlsafe(18)     # asked for one, or turned it on without one
            if token and not re.match(r'^[A-Za-z0-9_-]{16,64}$', token):
                raise ValueError('%s: the phone token must be 16-64 letters, digits, - or _' % name)
            clean.append({'id': str(person.get('id') or '') or secrets.token_hex(4),
                          'name': name, 'macs': macs,
                          'grace_s': int(grace) if grace is not None and 0 <= grace <= 86400 else None,
                          'notify': bool(person.get('notify', True)),
                          'phone_report': bool(person.get('phone_report')),
                          'token': token,
                          'enabled': bool(person.get('enabled', True))})
        self._presence_cache = None
        self.store.set_meta('people', json.dumps(clean))
        kept = {p['id'] for p in clean}
        for pid in list(self.presence):
            if pid not in kept:
                del self.presence[pid]
        self.store.add_event('control', '%d person(s) saved' % len(clean))
        self._wifi_kick.set()
        self.bump()
        return clean

    def presence_triggers(self):
        rows = self.store.meta_json('presence_triggers') or []
        return rows if isinstance(rows, list) else []

    def save_presence_triggers(self, items):
        clean = []
        for index, t in enumerate(items or []):
            if not isinstance(t, dict):
                continue
            who = str(t.get('who') or 'anyone').strip()
            event = str(t.get('event') or 'leave').strip().lower()
            plug = str(t.get('plug') or '').strip()
            do = str(t.get('do') or 'off').strip()
            if event not in ('arrive', 'leave', 'first_home', 'last_left'):
                raise ValueError('trigger %d: unknown event %r' % (index + 1, event))
            checked = valid_action(do)
            if not checked:
                raise ValueError('do must be one of %s, or set:<value>' % ', '.join(BINDING_ACTIONS))
            do = checked
            if not plug:
                raise ValueError('trigger %d needs something to switch' % (index + 1))
            target = self._valid_target(plug)
            if target is None:
                raise ValueError('unknown plug or switch %r' % plug)
            if who not in ('anyone', 'everyone') and not any(p['id'] == who for p in self.people()):
                raise ValueError('trigger %d refers to a person who is not on the list' % (index + 1))
            entry = {'id': str(t.get('id') or '') or secrets.token_hex(4),
                     'who': who, 'event': event, 'plug': target, 'do': do,
                     'enabled': bool(t.get('enabled', True))}
            if do == 'pulse':
                try:
                    entry['pulse_ms'] = max(PULSE_MS_MIN, min(PULSE_MS_MAX, int(t.get('pulse_ms') or PULSE_MS_DEFAULT)))
                except (TypeError, ValueError):
                    raise ValueError('pulse delay must be a number of milliseconds')
            clean.append(entry)
        self.store.set_meta('presence_triggers', json.dumps(clean))
        self.store.add_event('control', '%d presence trigger(s) saved' % len(clean))
        self.bump()
        return clean

    def _grace_for(self, person):
        """Seconds a person may be off the network before they count as out.
        Note the explicit None checks: a deliberate zero means "the moment the
        phone drops off", and `or` would quietly turn that into the default."""
        grace = person.get('grace_s')
        if grace is None:
            grace = self.wifi_config().get('grace_s')
        if grace is None:
            grace = PRESENCE_GRACE_S
        return int(grace)

    def presence_state(self):
        """Who is in, who is out, and how sure we are of it.

        Held for a moment: a gated rule asks this on every message it might
        match, and the answer can only change when the controller is asked
        again, which is seconds apart at best."""
        cached = self._presence_cache
        if cached and time.time() - cached[0] < 1.0:
            return cached[1]
        state = self._build_presence_state()
        self._presence_cache = (time.time(), state)
        return state

    def _build_presence_state(self):
        now = time.time()
        people = []
        for person in self.people():
            state = self.presence.get(person['id']) or {}
            grace = self._grace_for(person)
            last = state.get('last_seen')
            checked = self.wifi.get('checked')
            count = self.wifi.get('count')
            phone_fresh = time.time() - (state.get('phone_at') or 0) < self.PHONE_TRUST_S
            if self.wifi.get('ok') is not True and not (phone_fresh and state.get('phone')):
                reason = 'the controller is not answering, so nobody can be told in from out'
            elif self.wifi.get('ok') is not True:
                reason = ('their phone reported %s %s ago; the controller is not answering, so that is all there is'
                          % ('arriving' if state.get('phone') == 'home' else 'leaving',
                             human_age(time.time() - state['phone_at'])))
            elif state.get('on_wifi'):
                reason = '%s is on the network right now' % (state.get('device') or 'a device')
                if state.get('phone') == 'home' and time.time() - (state.get('phone_at') or 0) < self.PHONE_TRUST_S:
                    reason += ', and their phone reported arriving %s ago' % human_age(time.time() - state['phone_at'])
            elif state.get('phone') == 'home' and time.time() - (state.get('phone_at') or 0) < self.PHONE_TRUST_S:
                reason = ('their phone reported arriving %s ago; the controller has not listed it yet'
                          % human_age(time.time() - state['phone_at']))
            elif not person.get('macs'):
                reason = 'no device to look for'
            else:
                what = person['macs'][0] if len(person['macs']) == 1 else 'none of their %d devices' % len(person['macs'])
                listed = ('%s is not among the %s clients the controller listed %s ago'
                          % (what, count if count is not None else '?',
                             human_age(time.time() - checked) if checked else '?'))
                if last:
                    listed += '; last on the network %s ago (a person counts as out once off the network for %s)' % (
                        human_age(time.time() - last), human_age(grace))
                else:
                    listed += '; not seen once since the daemon started'
                reason = listed
            people.append({
                'id': person['id'], 'name': person['name'], 'macs': person['macs'],
                'enabled': person.get('enabled', True),
                'home': bool(state.get('home')),
                'on_wifi': bool(state.get('on_wifi')),
                'phone': state.get('phone') if time.time() - (state.get('phone_at') or 0) < self.PHONE_TRUST_S else None,
                'phone_at': state.get('phone_at'),
                'has_token': bool(person.get('token')),
                'phone_report': bool(person.get('phone_report')),
                'reason': reason,
                'last_seen': last,
                'since': state.get('since'),
                'device': state.get('device'),
                'leaving_in': (max(0, int(grace - (now - last))) if last and state.get('home')
                               and not state.get('on_wifi') else None),
            })
        watched = [p for p in people if p['enabled']]
        return {
            'people': people,
            'anyone_home': any(p['home'] for p in watched),
            'known': bool(watched) and self.wifi.get('ok') is True,
            'names': self.wifi.get('names') or {},
            'wifi': {'ok': self.wifi.get('ok'), 'error': self.wifi.get('error'),
                     'clients': self.wifi.get('count'), 'wifi_clients': self.wifi.get('wifi_count'),
                     'checked': self.wifi.get('checked'), 'enabled': bool(self.wifi_config().get('enabled'))},
        }

    def wifi_client_list(self):
        return sorted(self.wifi.get('clients_list') or [],
                      key=lambda c: (c.get('wired', False), (c.get('name') or c.get('mac') or '').lower()))

    def wifi_poll_once(self, cfg=None, force=False):
        """One round against the controller. Serialised, and the answer is
        held for a moment: the page can ask while the poller is mid-round, and
        several people looking at once must not become several rounds. Two
        threads deciding who just walked in would announce it twice, besides."""
        cfg = cfg or self.wifi_config()
        # a rule's quick look (UNIFI_QUICK.timeout set) must not sit behind a
        # regular poll that is waiting out a slow controller: it takes the
        # lock for at most its own timeout, then goes with the last answer
        quick = getattr(UNIFI_QUICK, 'timeout', None)
        if not self._wifi_fetch_lock.acquire(timeout=quick if quick else -1):
            log('presence: the controller is still being asked; using the last answer', 'debug')
            return self.wifi.get('clients_list') or []
        try:
            checked = self.wifi.get('checked')
            if not force and checked and time.time() - checked < 3 and self.wifi.get('ok'):
                return self.wifi.get('clients_list') or []
            clients = unifi_clients(cfg)
            with self._wifi_lock:
                return self._apply_clients(clients)
        finally:
            self._wifi_fetch_lock.release()

    def _apply_clients(self, clients):
        now = time.time()
        self._presence_cache = None
        names = dict(self.wifi.get('names') or {})
        for c in clients:
            if c.get('mac'):
                names[c['mac']] = c.get('name') or ''
        clients = self._merge_ap_clients(clients)
        self.wifi.update({'ok': True, 'error': None, 'checked': now,
                          'count': len(clients),
                          'wifi_count': sum(1 for c in clients if not c.get('wired')),
                          'clients_list': clients, 'names': names})
        self.store.set_meta('wifi_names', json.dumps(names), deferred=True)
        seen = {c['mac'] for c in clients if c.get('mac')}
        by_mac = {c['mac']: c for c in clients}
        people = self.people()
        watched = [p for p in people if p.get('enabled', True)]
        before = any((self.presence.get(p['id']) or {}).get('home') for p in watched)
        changes = []
        for person in people:
            moved = self._settle_presence(person, seen, by_mac, now)
            if moved:
                changes.append((person, moved))
        after = any((self.presence.get(p['id']) or {}).get('home') for p in watched)
        # The house as a whole changed state only once, whoever it was that
        # walked through the door last or first.
        house = ''
        if after and not before:
            house = 'first_home'
        elif before and not after:
            house = 'last_left'
        for person, moved in changes:
            events = ['arrive' if moved == 'arrive' else 'leave']
            if house and ((house == 'first_home') == (moved == 'arrive')):
                events.append(house)
                house = ''
            self._presence_changed(person, moved == 'arrive', events)
        return clients

    def people_public(self):
        """People as the dashboard sees them - without the phone tokens. That
        view can be public, and a token is a key to somebody's presence."""
        return [dict(p, token='', has_token=bool(p.get('token'))) for p in self.people()]

    PHONE_TRUST_S = 1800        # after this long unconfirmed, the Wi-Fi has the say again

    def presence_report_allowed(self, who):
        """A handful a minute is plenty for a geofence; a flood is somebody
        guessing tokens."""
        now = time.time()
        hits = self._report_hits.setdefault(who, [])
        hits[:] = [t for t in hits if now - t < 60]
        if len(hits) >= 20:
            return False
        hits.append(now)
        return True

    def presence_report_failed(self, who):
        self._report_hits.setdefault(who, []).extend([time.time()] * 4)   # a wrong token costs five tries

    def presence_report(self, token, state, origin='a phone'):
        """A phone saying where it is. The geofence on the handset trips
        while its owner is still down the street - a minute before the Wi-Fi
        could possibly know - so an arrival is taken at once. A departure is
        taken only if the controller cannot see them either: a geofence that
        wanders is common, a phone sitting on the home Wi-Fi is not a phone
        that has left."""
        token = str(token or '').strip()
        state = str(state or '').strip().lower()
        if state in ('1', 'true', 'in', 'arrive', 'arrived', 'here'):
            state = 'home'
        elif state in ('0', 'false', 'out', 'leave', 'left', 'gone'):
            state = 'away'
        if state not in ('home', 'away'):
            return False, 'state must be home or away'
        person = next((p for p in self.people() if p.get('token') and secrets.compare_digest(str(p['token']), token)), None)
        if person is None:
            log('presence report with an unknown token from %s' % origin, 'warn')
            return False, 'unknown token'
        if not person.get('enabled', True):
            return True, '%s is not being watched' % person['name']
        with self._wifi_lock:
            st = self.presence.setdefault(person['id'], {'home': None, 'last_seen': None, 'since': None,
                                                         'device': None, 'on_wifi': False})
            st['phone'] = state
            st['phone_at'] = time.time()
            on_wifi = st.get('on_wifi')
        if state == 'away' and on_wifi:
            # that flag is only as fresh as the last round, so before letting
            # it veto a departure, ask the controller once and quickly
            cfg = self.wifi_config()
            if cfg.get('enabled') and cfg.get('host') and time.time() - (self.wifi.get('checked') or 0) > 2:
                UNIFI_QUICK.timeout = 3.0
                try:
                    self.wifi_poll_once(cfg, force=True)
                except Exception as e:
                    log('presence: could not check the network before a reported departure (%s)' % e, 'debug')
                finally:
                    UNIFI_QUICK.timeout = None
        with self._wifi_lock:
            st = self.presence.setdefault(person['id'], st)
            if state == 'away' and st.get('on_wifi'):
                # still on the network: note it, but do not act on it yet
                log('%s: the phone says away while it is still on the Wi-Fi (%s)' % (person['name'], origin))
                self._presence_cache = None
                self.bump()
                return True, '%s noted - still on the network, so still home' % person['name']
            was = st.get('home')
            home = state == 'home'
            if home:
                st['last_seen'] = time.time()      # so the grace does not undo it on the next round
            if was == home:
                self._presence_cache = None
                self.bump()
                return True, '%s was already %s' % (person['name'], 'home' if home else 'out')
            st['home'] = home
            st['since'] = time.time()
        self.store.add_event('presence', '%s reported %s (%s)' % (person['name'], state, origin), 'info')
        if was is None:
            self.bump()
            return True, '%s is %s' % (person['name'], 'home' if home else 'out')
        # the same edges a Wi-Fi round would raise, including the house ones
        watched = [p for p in self.people() if p.get('enabled', True)]
        others = any((self.presence.get(p['id']) or {}).get('home') for p in watched if p['id'] != person['id'])
        events = ['arrive' if home else 'leave']
        if home and not others:
            events.append('first_home')
        elif not home and not others:
            events.append('last_left')
        self._presence_changed(person, home, events)
        return True, '%s is %s' % (person['name'], 'home' if home else 'out')

    def _settle_presence(self, person, seen, by_mac, now):
        state = self.presence.setdefault(person['id'], {'home': None, 'last_seen': None,
                                                        'since': None, 'device': None, 'on_wifi': False})
        grace = self._grace_for(person)
        # a device is listed by its MAC, or as name:<what the controller calls
        # it> - the way round a phone whose Wi-Fi address rotates (iOS and
        # Android both do this now; the name stays)
        by_name = {}
        for c in by_mac.values():
            for label in (c.get('name'), c.get('hostname')):
                if label:
                    by_name.setdefault(str(label).strip().lower(), c)
        here, matched = [], {}
        for m in person.get('macs') or []:
            if m.startswith('name:'):
                c = by_name.get(m[5:].strip().lower())
                if c and c.get('mac'):
                    here.append(m); matched[m] = c
            elif m in seen:
                here.append(m); matched[m] = by_mac.get(m) or {}
        state['on_wifi'] = bool(here)
        state['missing'] = [m for m in person.get('macs') or [] if m not in matched]
        if here:
            state['last_seen'] = now
            client = matched.get(here[0]) or {}
            state['device'] = client.get('name') or client.get('mac') or here[0]
        was = state['home']
        phone_at = state.get('phone_at') or 0
        phone_fresh = time.time() - phone_at < self.PHONE_TRUST_S
        if here:
            now_home = True
            if state.get('phone') == 'away' and phone_fresh:
                state['phone'] = None            # they are plainly back; the old word is spent
        elif phone_fresh and state.get('phone') == 'home':
            # the phone said it is here and the controller has not caught up
            # yet (or lost it for a moment); its word stands until it ages out
            now_home = True
        elif state['last_seen'] is None:
            now_home = False if was is None else was
        else:
            now_home = (now - state['last_seen']) < grace
        if now_home == was:
            return
        state['home'] = now_home
        state['since'] = now
        if not person.get('enabled', True) or was is None:
            return None                 # the first reading is not an arrival
        return 'arrive' if now_home else 'leave'

    def _presence_changed(self, person, home, events):
        self._presence_moved_at = time.time()
        word = 'arrived' if home else 'left'
        detail = person['name'] + ' ' + word
        if 'last_left' in events:
            detail += ' - nobody home now'
        elif 'first_home' in events:
            detail += ' - the house was empty'
        log(detail)
        self.store.add_event('presence', detail, 'info')
        if person.get('notify', True):
            self.notify(detail, 'info', dedup='presence|%s|%s' % (person['id'], home))
        self.fire_presence_triggers(person, events)

    def fire_presence_triggers(self, person, events):
        for t in self.presence_triggers():
            if not t.get('enabled', True) or t['event'] not in events:
                continue
            if t['who'] not in ('anyone', 'everyone', person['id']):
                continue
            if t['who'] == 'everyone' and t['event'] not in ('first_home', 'last_left'):
                continue
            origin = '%s %s' % (person['name'], 'arrived' if t['event'] in ('arrive', 'first_home') else 'left')
            for target in self._binding_targets(t['plug']):
                pretty = self.target_label(t['plug'])
                log('presence: %s -> %s %s' % (origin, pretty, t['do']))
                self.store.add_event('presence', '%s: %s %s' % (origin, pretty, t['do']))
                self._fire_target(target, t['do'], 'presence: ' + origin, t.get('pulse_ms'),
                                  {'person': person['name'], 'action': t['do'],
                                   'key': t['event'], 'target': pretty})

    def _valid_presence_gate(self, gate):
        gate = str(gate or '').strip()
        if not gate or gate in ('home', 'away'):
            return gate
        pieces = gate.split(':')
        if len(pieces) == 3 and pieces[0] == 'person' and pieces[2] in ('home', 'away'):
            if any(p['id'] == pieces[1] for p in self.people()):
                return gate
            raise ValueError('that rule is limited to a person who is not on the list')
        raise ValueError('unknown presence condition %r' % gate)

    def presence_allows(self, rule):
        """A rule can be limited to when the house is empty, or occupied, or to
        one person being in or out. With no one on the list, or the controller
        unreachable, a gated rule stays quiet rather than guessing."""
        gate = str(rule.get('when') or '').strip()
        if not gate:
            return True
        # Somebody walks in, the phone joins the Wi-Fi, the hall sensor trips
        # - and the "nobody home" alert fires because the last look at the
        # network is 25 s old. So a gated rule asks the controller afresh
        # when its answer is older than presence_fresh_s, with a short
        # timeout; the rule waits that long, nothing else does.
        fresh_s = numeric(CONFIG.get('presence_fresh_s'))
        fresh_s = 4.0 if fresh_s is None else float(fresh_s)
        cfg = self.wifi_config()
        checked = self.wifi.get('checked') or 0
        if fresh_s >= 0 and cfg.get('enabled') and cfg.get('host') and time.time() - checked > fresh_s:
            UNIFI_QUICK.timeout = 3.0
            try:
                # force=True: the answer is applied through _apply_clients, so
                # an arrival seen here also fires its presence triggers at once
                self.wifi_poll_once(cfg, force=True)
            except Exception as e:
                log('presence: fresh look failed (%s); using the last answer' % e, 'debug')
            finally:
                UNIFI_QUICK.timeout = None
        state = self.presence_state()
        if not state['known']:
            return False
        if gate == 'home':
            return state['anyone_home']
        if gate == 'away':
            return not state['anyone_home']
        if gate.startswith('person:'):
            pieces = gate.split(':')
            if len(pieces) != 3:
                return False
            who, want = pieces[1], pieces[2]
            for p in state['people']:
                if p['id'] == who:
                    return p['home'] if want == 'home' else not p['home']
            return False
        return True

    def wifi_detail_poll(self, cfg=None, force=False):
        """The slower round: what the network looks like, rather than who is on
        it. Kept apart from presence on purpose - this is for looking at, so it
        runs rarely and nothing waits on it."""
        cfg = cfg or self.wifi_config()
        # Somebody leaning on the refresh button, or several people looking at
        # once, should not turn into a burst against the controller.
        with self._wifi_detail_lock:
            return self._detail_round(cfg, force)

    def _detail_round(self, cfg, force):
        held = self.wifi.get('detail') or {}
        if not force and held.get('checked') and time.time() - held['checked'] < 5:
            return held
        detail = unifi_detail(cfg)
        now = int(time.time())
        seen = []
        for ap in detail.get('aps') or []:
            if not ap.get('mac'):
                continue
            device_id = 'wifi:' + ap['mac']
            seen.append(device_id)
            self.store.upsert_device({
                'id': device_id, 'name': ap['name'], 'source': 'wifi', 'kind': 'AccessPoint',
                'model': ap.get('model') or None, 'vendor': 'Ubiquiti',
                'description': 'Wi-Fi access point', 'last_seen': now,
                'exposes': {k: {'label': v[0], 'unit': v[1], 'description': v[2]} for k, v in {
                    'wifi.clients': ('Clients', '', 'devices joined to this access point'),
                    'wifi.cpu': ('CPU', '%', ''), 'wifi.memory': ('Memory', '%', ''),
                    'wifi.uptime': ('Uptime', 's', ''),
                    'wifi.tx': ('Sent', 'B', ''), 'wifi.rx': ('Received', 'B', ''),
                }.items()},
            })
            self.store.touch_device(device_id, now)
            payload = {'wifi.clients': numeric(ap.get('clients')), 'wifi.cpu': numeric(ap.get('cpu')),
                       'wifi.memory': numeric(ap.get('memory')), 'wifi.uptime': numeric(ap.get('uptime')),
                       'wifi.tx': numeric(ap.get('tx_bytes')), 'wifi.rx': numeric(ap.get('rx_bytes'))}
            for radio in ap.get('radios') or []:
                band = str(radio.get('band') or '?').replace('.', '_')
                for key, value in (('clients', radio.get('clients')), ('channel', radio.get('channel')),
                                   ('utilization', radio.get('utilization'))):
                    if numeric(value) is not None:
                        payload['wifi.%sg.%s' % (band, key)] = numeric(value)
            payload = {k: v for k, v in payload.items() if v is not None}
            entry = self.live.setdefault(device_id, {'payload': {}, 'ts': now})
            entry['payload'] = dict(entry.get('payload') or {}, **payload)
            entry['ts'] = now
            entry['availability'] = 'online' if ap.get('state') in ('online', 'connected', '') else 'offline'
            self.store.store_snapshot(device_id, now, entry['payload'], entry.get('availability'))
            last = self._gw_last.setdefault(device_id, {})
            changed = {}
            for key, value in payload.items():
                was = last.get(key)
                if was is None or was[0] != value or now - was[1] >= GATEWAY_ANCHOR_S:
                    changed[key] = value
                    last[key] = (value, now)
            if changed:
                self.store.store_sample(device_id, now, changed)
        # SSIDs the official API cannot list: take them from what is joined
        joined = {}
        knows_ssid = any(c.get('ssid') for c in self.wifi.get('clients_list') or [])
        for client in self.wifi.get('clients_list') or []:
            if client.get('ssid'):
                joined[client['ssid']] = joined.get(client['ssid'], 0) + 1
        if not detail.get('ssids') and knows_ssid:
            # no network list from the controller, but the clients name theirs
            detail['ssids'] = [{'name': n, 'enabled': True, 'clients': c, 'derived': True}
                               for n, c in sorted(joined.items())]
        else:
            for ssid in detail['ssids']:
                # None means nobody can say, which is not the same as nobody
                ssid['clients'] = joined.get(ssid['name']) if knows_ssid else None
        detail['knows_ssid'] = knows_ssid
        # Tie each client to the access point carrying it. The official API
        # names it by device id, the older one by MAC, so both are mapped.
        by_id = {ap.get('id'): ap for ap in detail.get('aps') or [] if ap.get('id')}
        by_mac = {ap['mac']: ap for ap in detail.get('aps') or [] if ap.get('mac')}
        per_ap = {}
        for client in self.wifi.get('clients_list') or []:
            ap = by_id.get(client.get('uplink_id')) or by_mac.get(client.get('ap') or '')
            if ap:
                client['ap_name'] = client.get('ap_name') or ap['name']
                client['ap_mac'] = ap['mac']
            elif client.get('ap_name') and client.get('ap'):
                client['ap_mac'] = client['ap']    # the controller named it for us
            if not client.get('wired') and client.get('ap_mac'):
                per_ap[client['ap_mac']] = per_ap.get(client['ap_mac'], 0) + 1
        for ap in detail.get('aps') or []:
            # the official statistics do not always carry a client count
            if ap.get('clients') is None and ap['mac'] in per_ap:
                ap['clients'] = per_ap[ap['mac']]
            ap['guests'] = sum(1 for c in (self.wifi.get('clients_list') or [])
                               if c.get('guest') and c.get('ap_mac') == ap['mac'])
        if cfg.get('ssh_enabled'):
            self._ask_the_access_points(cfg, detail)
        detail['checked'] = time.time()
        self.wifi['detail'] = detail
        self.bump()
        return detail

    def _wifi_order(self):
        try:
            rows = json.loads(self.store.get_meta('wifi_order') or '[]')
        except ValueError:
            return []
        return [str(x) for x in rows] if isinstance(rows, list) else []

    def _ask_the_access_points(self, cfg, detail):
        """The points know what the controller's key interface will not say.

        Each is asked in turn, on the thread that was already going to wait on
        the network; one that does not answer is noted and the rest carry on.
        Nothing is written to them."""
        found, trouble, per_ssid, neighbours = [], {}, {}, {}
        for ap in detail.get('aps') or []:
            host = ap.get('ip')
            if not host:
                continue
            try:
                seen = parse_mca_dump(ap_run(cfg, host, 'dump'))
            except Exception as e:
                trouble[ap.get('name') or host] = str(e)[:120]
                ap['ssh_error'] = str(e)[:120]
                continue
            ap['ssh'] = True
            ap.pop('ssh_error', None)
            for key in ('temperature', 'load', 'experience', 'serial', 'kernel', 'internet',
                        'uptime_text', 'wired', 'paths', 'wired_to', 'inform_url', 'adopted',
                        'last_trouble', 'boot_reason', 'ever_crashed', 'flash_wear',
                        'architecture', 'board', 'gateway', 'ipv6', 'six_ghz', 'antenna'):
                if seen.get(key) is not None:
                    ap[key] = seen[key]
            for key in ('cpu', 'memory', 'uptime'):
                if ap.get(key) is None and seen.get(key) is not None:
                    ap[key] = seen[key]
            if seen.get('radios'):
                by_band = {str(r.get('band')): r for r in ap.get('radios') or []}
                for radio in seen['radios']:
                    into = by_band.get(str(radio.get('band')))
                    if into is None:
                        ap.setdefault('radios', []).append(radio)
                        continue
                    for key in ('clients', 'utilization', 'tx_retries', 'power', 'temperature',
                                'chains', 'networks', 'quieter', 'interference', 'dfs',
                                'dfs_capable', 'min_power', 'max_power'):
                        if radio.get(key) is not None:
                            into[key] = radio[key]
                    for key in ('channel', 'width'):
                        if into.get(key) is None and radio.get(key) is not None:
                            into[key] = radio[key]
                    into['dfs'] = is_dfs_channel(into.get('band'), into.get('channel'))
            for client in seen.get('clients') or []:
                client['ap_name'] = ap.get('name')
                client['ap_mac'] = ap.get('mac')
                found.append(client)
            for other in seen.get('neighbours') or []:
                # the same network seen by two points is one network; keep the
                # nearest sighting and note who saw it
                key = (other.get('bssid') or '') + '|' + str(other.get('channel'))
                held = neighbours.get(key)
                if held is None or (other.get('signal') or -999) > (held.get('signal') or -999):
                    other = dict(other, seen_by=ap.get('name'))
                    neighbours[key] = other
                elif ap.get('name') and ap['name'] not in str(held.get('seen_by') or ''):
                    held['seen_by'] = '%s, %s' % (held.get('seen_by'), ap['name'])
            for net in seen.get('networks') or []:
                if net.get('clients'):
                    per_ssid[net['name']] = per_ssid.get(net['name'], 0) + int(net['clients'])
        for ssid in detail.get('ssids') or []:
            if ssid['name'] in per_ssid:
                ssid['clients'] = per_ssid[ssid['name']]
        if found:
            # what the points said replaces what the key interface guessed at:
            # it knows the network, the signal and the channel, and that is the
            # whole reason for asking them
            # Held so that every presence round can use it again: the points
            # are asked every few minutes, the controller every few seconds,
            # and without this the detail would appear and vanish in between.
            stamp = time.time()
            self.wifi['ap_clients'] = {c['mac']: dict(c, ap_seen_at=stamp) for c in found if c.get('mac')}
            self.wifi['clients_list'] = self._merge_ap_clients(self.wifi.get('clients_list') or [])
        # Our own networks are not neighbours. Matching by name misses the
        # hidden ones a point broadcasts, so the address is checked too: a
        # UniFi point derives every BSSID from its own MAC, varying only the
        # first octet, so the middle four identify the hardware.
        def spine(mac):
            bits = str(mac or '').lower().split(':')
            return ':'.join(bits[1:5]) if len(bits) == 6 else None

        ours = {str(x.get('name') or '').lower() for x in detail.get('ssids') or []}
        our_hardware = {spine(ap.get('mac')) for ap in detail.get('aps') or []} - {None}
        detail['neighbours'] = sorted(
            (dict(n, ours=(str(n.get('ssid') or '').lower() in ours
                           or spine(n.get('bssid')) in our_hardware))
             for n in neighbours.values()),
            key=lambda n: -(n.get('signal') or -999))
        detail['ssh'] = {'used': bool(found), 'clients': len(found), 'trouble': trouble,
                         'neighbours': len(detail['neighbours'])}
        return detail

    # A client's name comes from the controller when it has one: that is what
    # somebody typed and expects to see. The access point reports the real
    # hostname the device announced, which is kept alongside rather than over
    # the top of it.
    AP_KEEPS_ITS_OWN = ('name', 'ip', 'kind', 'wired', 'guest', 'since', 'uplink_id')

    def _merge_ap_clients(self, clients):
        """What the points said, folded into what the controller said.

        The points are asked every few minutes, the controller every few
        seconds. Their answer is kept in between to fill in the network, the
        signal and the channel - but only as *detail* on a client the
        controller still lists. Adding back everything the last point snapshot
        held would keep a phone that has already left on the network until the
        next probe: presence hung on for up to detail_s (three minutes by
        default), and so did every "when the last person leaves" trigger.
        A client the controller does not list is carried only while the
        snapshot is genuinely fresh."""
        richer = dict(self.wifi.get('ap_clients') or {})
        if not richer:
            return clients
        cfg = self.wifi_config()
        window = max(60.0, 2.0 * float(cfg.get('poll_s') or WIFI_POLL_S))
        now = time.time()
        merged = []
        for client in clients:
            extra = richer.pop(client.get('mac'), None)
            if not extra:
                merged.append(client)
                continue
            out = dict(client)
            for key, value in extra.items():
                if value in (None, ''):
                    continue
                if key in self.AP_KEEPS_ITS_OWN and out.get(key) not in (None, ''):
                    continue                     # the controller's answer stands
                out[key] = value
            if extra.get('name') and extra['name'] != out.get('name'):
                out['hostname'] = extra['name']  # what the device calls itself
            merged.append(out)
        # anything a point can see and the controller cannot - but only while
        # the snapshot it came from is still fresh
        for extra in richer.values():
            if now - float(extra.get('ap_seen_at') or 0) <= window:
                merged.append(extra)
        return merged

    def wifi_detail_state(self):
        detail = dict(self.wifi.get('detail') or {})
        detail.setdefault('aps', [])
        detail.setdefault('ssids', [])
        detail.setdefault('controller', {})
        clients = [c for c in (self.wifi.get('clients_list') or [])]
        detail['clients'] = clients
        signals = [c['signal'] for c in clients if isinstance(c.get('signal'), (int, float))]
        bands = {}
        for c in clients:
            if c.get('wired'):
                continue
            band = c.get('band') or unifi_band(c.get('radio'), c.get('channel'))
            if band:
                bands[str(band) + ' GHz'] = bands.get(str(band) + ' GHz', 0) + 1
        detail.setdefault('neighbours', [])
        detail['counts'] = {
            'clients': len(clients),
            'wifi': sum(1 for c in clients if not c.get('wired')),
            'wired': sum(1 for c in clients if c.get('wired')),
            'guests': sum(1 for c in clients if c.get('guest')),
            'vpn': sum(1 for c in clients if c.get('kind') in ('VPN', 'TELEPORT')),
            'aps': len(detail['aps']),
            'ssids': len(detail['ssids']),
            'neighbours': len([n for n in detail['neighbours'] if not n.get('ours')]),
            'worst_signal': min(signals) if signals else None,
            'bands': bands,
        }
        return detail

    def presence_ntfy_loop(self):
        """Listen on an ntfy topic for the same reports, so a phone can say
        where it is without anything here being reachable from the internet:
        the handset publishes to ntfy, we hold an outbound stream to it.
        The topic is public, which is why the token is inside the message and
        why nothing but 'name home' ever travels over it."""
        backoff = 2
        while not self._stop.is_set():
            url = str(CONFIG.get('presence_ntfy') or self.wifi_config().get('presence_ntfy') or '').strip()
            if not url:
                self._stop.wait(20)
                continue
            stream = url.rstrip('/') + '/json?since=' + str(int(time.time()))
            try:
                req = urllib.request.Request(stream, headers={'User-Agent': 'zigmon/%s' % __version__})
                # ntfy sends a keepalive frame every 45 s; a read that sees
                # nothing for two minutes means the link died quietly, and
                # a reconnect is the only way to find out. Without this the
                # listener could sit on a dead socket forever.
                with urllib.request.urlopen(req, timeout=120) as response:
                    backoff = 2
                    log('listening for presence reports on %s' % url)
                    for raw in response:
                        if self._stop.is_set():
                            break
                        raw = raw.decode('utf-8', 'replace').strip()
                        if not raw:
                            continue
                        try:
                            item = json.loads(raw)
                        except ValueError:
                            continue
                        if item.get('event') != 'message':
                            continue        # open/keepalive frames
                        if time.time() - float(item.get('time') or 0) > 300:
                            continue        # a replayed backlog is not news
                        parts = str(item.get('message') or '').split()
                        if len(parts) < 2:
                            continue
                        # "<state> <token>" or "<anything> <state> <token>"
                        token, state = parts[-1], parts[-2]
                        ok, message = self.presence_report(token, state, 'ntfy')
                        log('presence over ntfy: %s' % message, 'info' if ok else 'warn')
            except Exception as e:
                if not self._stop.is_set():
                    log('presence ntfy listener: %s' % e, 'debug')
            self._stop.wait(backoff)
            backoff = min(60, backoff * 2)

    def wifi_loop(self):
        """Ask the controller who is on the network, on its own thread.

        After somebody has just come or gone the next few looks are quicker:
        a controller often lists a phone a beat before it settles, and a
        second person walking in behind the first should not wait a full
        round."""
        while not self._stop.is_set():
            cfg = self.wifi_config()
            wait = max(3, int(cfg.get('poll_s') or WIFI_POLL_S))
            if time.time() - getattr(self, '_presence_moved_at', 0) < 60:
                wait = min(wait, 5)
            if cfg.get('enabled') and cfg.get('host'):
                try:
                    self.wifi_poll_once(cfg)
                    # the detail is for looking at, so it comes round rarely
                    every = int(numeric(cfg.get('detail_s')) or 180)
                    if every and time.time() - self._wifi_detail_at >= every:
                        self._wifi_detail_at = time.time()
                        try:
                            self.wifi_detail_poll(cfg)
                        except Exception as e:
                            log('wifi detail: %s' % e, 'debug')
                except Exception as e:
                    first = self.wifi.get('ok') is not False
                    self.wifi.update({'ok': False, 'error': str(e), 'checked': time.time()})
                    if first:
                        log('wifi presence: %s' % e, 'warn')
            else:
                self.wifi.update({'ok': None, 'error': None})
                wait = 30
            self._wifi_kick.wait(wait)
            self._wifi_kick.clear()

    def queue_rules(self, device_id, name, values):
        """Rules are evaluated on a worker of their own, in order. The broker
        thread hands the reading over and is free again in microseconds, so a
        rule that has to ask the Wi-Fi controller who is in (see
        presence_allows) delays nothing but itself - never a button, never a
        report."""
        self._rule_queue.append((device_id, name, values))
        self._rule_kick.set()
        self._rule_queue_gated.append((device_id, name, values))
        self._rule_kick_gated.set()

    def rule_worker(self, gated=False):
        """Two of these: plain rules (motion -> light) on one, presence-gated
        rules on the other, so a look at the Wi-Fi controller never holds a
        light back."""
        queue = self._rule_queue_gated if gated else self._rule_queue
        kick = self._rule_kick_gated if gated else self._rule_kick
        while not self._stop.is_set():
            kick.wait(1.0)
            kick.clear()
            while queue:
                device_id, name, values = queue.popleft()
                try:
                    if device_id == '__for__':
                        self.check_rule_for()
                    else:
                        self.fire_rules(device_id, name, values, gated=gated)
                except Exception as e:
                    log('rules for %s: %s' % (name, e), 'error')

    def fire_rules(self, device_id, name, values, gated=None):
        """Edge-triggered: a rule fires when its condition becomes true, not on
        every reading while it stays true; the cooldown guards against a value
        that dances around the line."""
        for r in self.rules():
            if not r.get('enabled', True):
                continue
            if gated is not None and bool(str(r.get('when') or '').strip()) != gated:
                continue                     # the other worker's rules
            mine = r['device'] in (device_id, name)
            second = bool(r.get('device2')) and r['device2'] in (device_id, name)
            if not mine and not second:
                continue
            if not self.rule_window_active(r):
                continue                     # outside its hours; the ticker handles the edges
            if not self.presence_allows(r):
                continue                     # someone is in, or out, and this rule is not for that
            reading = values.get(r['key']) if mine else self.latest_value(r['device'], r['key'])
            if reading is not None:
                reading = self._effective_reading(r, reading)
            paired = bool(r.get('device2')) and bool(r.get('key2'))
            if reading is None and not (paired and r.get('combine') == 'or'):
                continue                     # nothing to compare, and no other side to save it
            rt = self.rule_runtime.setdefault(r['id'], {'holds': None, 'fired': 0.0, 'reading': None})
            rt['reading'] = reading
            # the way back of a hysteresis pair folded into one rule
            if r.get('back') is not None and self._rule_holds(
                    {'>=': '<=', '<=': '>=', '>': '<', '<': '>'}[r['op']], reading, r['back']):
                if rt.get('back_done') is not True:
                    rt['back_done'] = True
                    rt['holds'] = False
                    rt.pop('since', None)
                    opposite = 'off' if r['do'] == 'on' else 'on'
                    origin = '%s %s %g back past %g' % (name, r['key'], reading, r['back'])
                    for target in self._binding_targets(r['plug']):
                        pretty = self.target_label(r['plug'])
                        log('rule back: %s -> %s %s' % (origin, pretty, opposite))
                        self.store.add_event('rule', '%s: %s %s' % (origin, pretty, opposite), 'info', device_id)
                        self._fire_target(target, opposite, 'rule: ' + origin, honour_hold=True)
                continue
            holds_first = reading is not None and self._rule_holds(r['op'], reading, r['value'])
            holds_second = None
            other = None
            if paired:
                other = values.get(r['key2']) if second else None
                if other is None:
                    other = self.latest_value(r['device2'], r['key2'])
                holds_second = other is not None and self._rule_holds(r['op2'], other, r['value2'])
                holds = (holds_first or holds_second) if r.get('combine') == 'or' else (holds_first and holds_second)
            else:
                holds = holds_first
            was = rt['holds']
            rt['holds'] = holds
            if not holds:
                rt.pop('since', None)
                rt['first'], rt['second'] = holds_first, holds_second
                continue
            # OR is two ways for the same thing to happen, and each of them is
            # its own event: two motion sensors covering a hallway should both
            # be heard, not only whichever tripped first while the other was
            # still occupied.
            if paired and r.get('combine') == 'or':
                fresh = (holds_first and not rt.get('first')) or (holds_second and not rt.get('second'))
            else:
                fresh = was is not True
            rt['first'], rt['second'] = holds_first, holds_second
            rt['back_done'] = False
            if fresh or 'since' not in rt:
                rt.setdefault('since', time.time())
            wait_s = int(r.get('for_s') or 0)
            if wait_s:
                if time.time() - rt['since'] < wait_s:
                    continue                 # not held long enough; the ticker finishes it
                if rt.get('for_fired') == rt['since']:
                    continue                 # this stretch already fired
            elif not fresh:
                continue
            now = time.time()
            if now - rt['fired'] < int(r.get('cooldown_s') or 0):
                continue
            if self._rate_limited(r, rt):
                continue
            rt['fired'] = now
            if wait_s:
                rt['for_fired'] = rt['since']
            if paired and second and not mine and holds_second:
                trip_key, trip_value, trip_op, trip_limit = r['key2'], other, r['op2'], r['value2']
            else:
                trip_key, trip_value, trip_op, trip_limit = r['key'], reading, r['op'], r['value']
            origin = '%s %s %s %s %g' % (name, trip_key,
                                         ('%g' % trip_value) if trip_value is not None else '?',
                                         trip_op, trip_limit)
            targets = self._binding_targets(r['plug'])
            if not targets and r['plug'] != '*':
                log('rule skipped: %s is disabled or gone' % r['plug'], 'debug')
            for target in targets:
                pretty = self.target_label(r['plug'])
                log('rule: %s -> %s %s' % (origin, pretty, r['do']))
                self.store.add_event('rule', '%s: %s %s' % (origin, pretty, r['do']), 'info', device_id)
                self._fire_target(target, r['do'], 'rule: ' + origin, r.get('pulse_ms'),
                                  {'device': name, 'key': trip_key, 'value': trip_value,
                                   'target': pretty, 'action': r['do']}, honour_hold=True)

    def fire_bindings(self, device_id, name, action):
        hits = [b for b in self.bindings()
                if b.get('enabled', True) and b['device'] in (device_id, name)
                and (b['action'] == action or b['action'] == '*')]
        for b in hits:
            origin = 'button %s (%s)' % (name, action)
            targets = self._binding_targets(b['plug'])
            if not targets and b['plug'] != '*':
                log('binding skipped: %s is disabled or gone' % b['plug'], 'debug')
            hold_by = None
            if b.get('hold'):
                hold_by = (b.get('device') and self.pretty_device(b['device'])) or origin
            for target in targets:
                log('binding: %s %s -> %s %s' % (name, action, self.target_label(b['plug']), b['do']))
                # a scene or sequence settles the hold on each light it touches
                # itself (see run_scene); a plug or switch is settled right here
                self._fire_target(target, b['do'], origin, b.get('pulse_ms'),
                                  {'device': name, 'action': b['do'], 'key': action,
                                   'target': self.target_label(b['plug'])}, hold_by=hold_by)
                if hold_by and target[0] in ('plug', 'zb'):
                    # Whether the press takes the target over or gives it back
                    # depends on where it ends up, which for a toggle is only
                    # known once the plug has answered.
                    threading.Thread(target=self._settle_member, args=(target, b['do'], hold_by),
                                     name='hold', daemon=True).start()

    def _settle_member(self, target, do, by):
        """On means the person wants it on and the rules should keep off; off
        means they are done with it."""
        key = self.hold_key(target)
        if not key:
            return
        if do == 'pulse':
            return                       # a pulse is not somebody taking over
        if do in ('on', 'off'):
            wanted_on = do == 'on'
        else:
            time.sleep(0.6)              # let the toggle land, then read it back
            wanted_on = bool(self.target_is_on(key))
        if wanted_on:
            self.hold_target(key, by)
        else:
            self.release_target(key)

    def pretty_device(self, device_id):
        row = self.store.device(device_id) or {}
        return row.get('alias') or row.get('name') or device_id

    def target_is_on(self, spec):
        """Whether a target is currently switched on, as far as we know."""
        spec = str(spec or '')
        if spec.startswith('zb:'):
            pieces = spec.split(':')
            entry = self.live.get(':'.join(pieces[1:-1])) or {}
            value = (entry.get('payload') or {}).get(pieces[-1])
            return str(value).upper() in ('ON', 'TRUE', '1')
        p = self.plug_by_name(spec)
        return bool(p.output) if p is not None else None

    def _run_binding(self, p, do, origin, pulse_ms=None):
        if str(do).lower().startswith('set:'):
            log('%s: "set" only works on a Zigbee device (a valve\'s target, a mode)' % p.name, 'warn')
            return
        try:
            if do == 'toggle':
                ok, message = self.toggle_plug(p, origin)
            elif do == 'pulse':
                ok, message = self.pulse_plug(p, pulse_ms, origin)
            else:
                ok, message = self.set_plug_output(p, do == 'on', origin)
            if not ok:
                log('binding failed: %s' % message, 'debug' if getattr(p, 'unplugged', False) else 'warn')
        except Exception as e:
            log('binding failed: %s' % e, 'debug' if getattr(p, 'unplugged', False) else 'error')


    # -- Shelly sensors polled over RPC, and pushed webhooks -----------------
    def setup_sensors(self):
        for entry in self.active_entries('sensors'):
            name = str(entry['name'])
            self.sensors[name] = PlugState(name, entry)
            self.sensors[name].device_id = 'sensor:' + name
            self.store.upsert_device({'id': 'sensor:' + name, 'name': name, 'source': 'shelly',
                                      'kind': 'wifi', 'vendor': 'Shelly', 'exposes': {}})

    def poll_sensor(self, s):
        """A battery H&T is asleep almost always, so failure here is not an error."""
        now = time.time()
        if now - s.last_poll < int(CONFIG.get('plug_poll_interval') or 15):
            return
        s.last_poll = now
        rpc = s.rpc()
        try:
            status = rpc.call('Shelly.GetStatus')
            if not s.info:
                s.info = rpc.device_info()
        except PlugError as e:
            s.failures += 1
            s.error = str(e)
            log('sensor %s: %s' % (s.name, e), 'debug')
            return
        if s.failures >= 3:
            log('sensor %s answers again' % s.name)
        s.failures = 0
        s.error = None
        flat = normalise_shelly_status(flatten(status))
        if not flat:
            return
        self.record(s.device_id, s.name, flat)
        info = s.info or {}
        self.store.upsert_device({'id': s.device_id, 'name': s.name, 'source': 'shelly', 'kind': 'wifi',
                                  'vendor': 'Shelly', 'model': info.get('model'),
                                  'description': ' '.join(x for x in (info.get('app'), info.get('ver')) if x) or None,
                                  'exposes': {}})

    def accept_push(self, fields, raw, client):
        """One webhook from a sleeping sensor. Returns True when something usable arrived."""
        source = str(fields.get('id') or fields.get('device') or fields.get('name') or client)
        values = {}
        aliases = {'tC': ('t', 'tC', 'temperature', 'temp'), 'rh': ('rh', 'humidity', 'h'),
                   'battery.V': ('bv', 'battery.V', 'V'), 'battery.percent': ('bp', 'battery.percent', 'percent', 'battery'),
                   'wifi.rssi': ('rssi', 'wifi.rssi'), 'lux': ('lux', 'illuminance')}
        for key, names in aliases.items():
            for n in names:
                if n in fields and numeric(fields[n]) is not None:
                    values[key] = numeric(fields[n])
                    break
        self.pushes_received += 1
        self.last_push_at = time.time()
        if not values:
            self.pushes_rejected += 1
            log('sensor push from %s carried nothing usable: %s' % (client, (raw or '')[:200]), 'warn')
            return False
        device_id = 'push:' + source
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': source, 'source': 'shelly', 'kind': 'wifi',
                                      'vendor': 'Shelly', 'description': 'webhook from %s' % client, 'exposes': {}})
            self.store.add_event('device', 'first push from %s' % client, 'info', device_id)
            log('first sensor push from %s (%s): %s' % (source, client, values))
        self.record(device_id, source, values)
        return True

    def serve_pushes(self):
        daemon = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def _answer(self, ok):
                self.send_response(200 if ok else 400)
                self.send_header('Content-Length', '0')
                self.end_headers()

            def do_GET(self):
                query = parse_qs(urlparse(self.path).query)
                fields = {k: v[0] for k, v in query.items() if v}
                self._answer(daemon.accept_push(fields, json.dumps(fields), self.client_address[0]))

            def do_POST(self):
                length = int(self.headers.get('Content-Length') or 0)
                raw = self.rfile.read(length).decode('utf-8', 'replace') if length else ''
                fields = {}
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        fields = flatten(parsed)
                except ValueError:
                    fields = {k: v[0] for k, v in parse_qs(raw).items() if v}
                short = {}
                for key, value in fields.items():
                    short[key.rsplit('.', 1)[-1]] = value
                short.update(fields)
                self._answer(daemon.accept_push(short, raw, self.client_address[0]))

        host, port = CONFIG['sensor_listen_host'] or '0.0.0.0', int(CONFIG['sensor_listen_port'])
        try:
            server = ThreadingHTTPServer((host, port), Handler)
        except OSError as e:
            log('cannot listen for sensor pushes on %s:%s - %s' % (host, port, e), 'error')
            return
        server.daemon_threads = True
        log('listening for sensor pushes on http://%s:%s/' % (host, port))
        server.serve_forever()

    # -- assessment ---------------------------------------------------------
    def describe(self, dev, snap):
        """One device for the API: identity, readings, verdict."""
        now = time.time()
        payload = (snap or {}).get('payload') or {}
        ts = (snap or {}).get('ts')
        availability = (snap or {}).get('availability')
        exposes = dev.get('exposes') or {}
        values = {}
        for key, value in payload.items():
            if key in IGNORE_KEYS:
                continue
            info = exposes.get(key) or {}
            values[key] = {
                'value': value,
                'label': info.get('label') or key_label(key),
                'unit': info.get('unit') or key_unit(key),
                'description': info.get('description') or '',
                'category': info.get('category') or '',
            }
            if info.get('values'):
                values[key]['options'] = list(info['values'])
        # What a button can send: the definition's list first, then anything
        # it has actually sent that the definition did not mention.
        declared = list((exposes.get('action') or {}).get('values') or [])
        actions = declared + [a for a in self.store.actions_seen(dev['id']) if a not in declared]
        display = dev.get('alias') or dev['name']
        via = None
        relation = getattr(self, 'parents', {}).get(dev['id'])
        if relation and dev['source'] == 'zigbee':
            parent_row = self.store.device(relation.get('parent') or '')
            parent_type = (relation.get('parent_type') or '').lower()
            via = {'id': relation.get('parent'),
                   'name': (parent_row.get('alias') or parent_row['name']) if parent_row
                           else ('coordinator' if parent_type == 'coordinator' else relation.get('parent')),
                   'type': relation.get('parent_type') or ('Coordinator' if parent_type == 'coordinator' else ''),
                   'lqi': relation.get('lqi'), 'ts': relation.get('ts'),
                   'relation': relation.get('relation') or 'parent'}
        reasons = []
        level = 'ok'

        def worst(new):
            nonlocal level
            order = ['ok', 'warn', 'crit']
            if order.index(new) > order.index(level):
                level = new

        age = (now - ts) if ts else None
        unplugged = False
        if dev['source'] == 'plug':
            plug = self.plugs.get(dev['name'])
            unplugged = bool(plug and plug.optional and availability == 'offline')
        if unplugged:
            reasons.append('unplugged (optional device)')       # expected: level stays as it is
        elif availability == 'offline':
            worst('crit')
            reasons.append('not answering' if dev['source'] == 'plug' else 'reported offline by the bridge')
        battery = numeric(payload.get('battery')) if 'battery' in payload else \
            numeric(payload.get('battery.percent')) if 'battery.percent' in payload else None
        if battery is not None:
            if battery <= CONFIG['battery_crit']:
                worst('crit')
                reasons.append('battery %d%%' % battery)
            elif battery <= CONFIG['battery_warn']:
                worst('warn')
                reasons.append('battery %d%%' % battery)
        lqi = numeric(payload.get('linkquality')) if 'linkquality' in payload else None
        if lqi is not None:
            if lqi <= CONFIG['lqi_crit']:
                worst('warn')
                reasons.append('very weak signal (%d)' % lqi)
            elif lqi <= CONFIG['lqi_warn']:
                worst('warn')
                reasons.append('weak signal (%d)' % lqi)
        temp = numeric(payload.get('temperature')) if 'temperature' in payload else \
            numeric(payload.get('tC')) if 'tC' in payload else None
        if temp is not None:
            if CONFIG.get('temperature_max') is not None and temp > CONFIG['temperature_max']:
                worst('warn')
                reasons.append('temperature %.1f above %.1f' % (temp, CONFIG['temperature_max']))
            if CONFIG.get('temperature_min') is not None and temp < CONFIG['temperature_min']:
                worst('warn')
                reasons.append('temperature %.1f below %.1f' % (temp, CONFIG['temperature_min']))
        hum = numeric(payload.get('humidity')) if 'humidity' in payload else \
            numeric(payload.get('rh')) if 'rh' in payload else None
        if hum is not None and CONFIG.get('humidity_max') is not None and hum > CONFIG['humidity_max']:
            worst('warn')
            reasons.append('humidity %.0f%% above %.0f%%' % (hum, CONFIG['humidity_max']))
        if payload.get('water_leak') in (True, 'true', 1):
            worst('crit')
            reasons.append('water leak')
        if payload.get('battery_low') in (True, 'true', 1):
            worst('warn')
            reasons.append('battery low flag')
        stale_warn = int(CONFIG.get('stale_warn_min') or 0) * 60
        stale_crit = int(CONFIG.get('stale_crit_min') or 0) * 60
        if dev['source'] == 'plug':
            stale_warn, stale_crit = 0, 0
        elif (declared or 'action' in exposes) and CONFIG.get('silence_alert_buttons', 1):
            # a button/remote only reports when pressed - "quiet for 6 hours"
            # is normal for it, not a fault, unless someone turns this off
            stale_warn, stale_crit = 0, 0
        if age is None:                 # never reported, or a timestamp of zero
            worst('warn')
            reasons.append('never reported')
        elif stale_crit and age > stale_crit:
            worst('crit')
            reasons.append('silent for %s' % human_age(age))
        elif stale_warn and age > stale_warn:
            worst('warn')
            reasons.append('silent for %s' % human_age(age))

        ranked = []
        for key, entry in values.items():
            if dev['source'] == 'plug':
                rank = PLUG_HEADLINE.index(key) if key in PLUG_HEADLINE else None
            else:
                rank = headline_rank(key)
            if dev.get('kind') == 'Router' and key in ('state', 'led_state'):
                continue        # a leftover on/off cluster in router firmware; it routes nothing
            if actions and key in ('voltage', 'battery', 'battery_low'):
                continue        # a remote's headline is what was pressed, not its cell
            if key.startswith('window_detection_params') or key in (
                    'min_temperature', 'max_temperature', 'away_preset_temperature',
                    'comfort_temperature', 'eco_temperature', 'holiday_temperature',
                    'boost_time', 'boost_heating_countdown', 'local_temperature_calibration'):
                continue        # settings a head carries, not what it is doing now
            if rank is not None and not key.endswith('.tF'):
                ranked.append((rank, key, entry))
        ranked.sort()
        headline = [dict(entry, key=key) for _, key, entry in ranked[:4]]
        if 'current_heating_setpoint' in values or 'occupied_heating_setpoint' in values:
            for entry in headline:      # on a radiator head "position" is how far it is open
                if entry.get('key') == 'position' and (entry.get('label') or '') == 'Position':
                    entry['label'] = 'Valve open'
        return {
            'id': dev['id'], 'name': display, 'topic_name': dev['name'],
            'alias': dev.get('alias') or None, 'source': dev['source'],
            'via': via,
            'kind': dev.get('kind'), 'model': dev.get('model'), 'vendor': dev.get('vendor'),
            'description': dev.get('description'),
            'first_seen': dev.get('first_seen'), 'last_seen': ts or dev.get('last_seen'),
            'age_s': int(age) if age is not None else None,
            'availability': availability,
            'online': availability != 'offline' and age is not None and not (stale_crit and age > stale_crit),
            'level': level, 'reasons': reasons, 'unplugged': unplugged,
            'battery': battery, 'linkquality': lqi, 'temperature': temp, 'humidity': hum,
            'headline': headline,
            'values': values,
            'actions': actions,
            'has_action': bool(actions) or 'action' in exposes,
            'zigbee_ts': (self.zigbee_seen.get(dev['id'])
                          if any(k.startswith('gw.') for k in payload) else None),
            'gateway': getattr(self, '_gw_info', {}).get(dev['id']),
            'last_action': self.store.last_action(dev['id']) if (actions or 'action' in exposes) else None,
        }

    def status(self):
        now = time.time()
        # what Detect learned about each gateway, so a device it extends can
        # show its firmware the way the coordinator does
        self._gw_info = {}
        for g in self.gateway_configs():
            described = ' \u00b7 '.join(x for x in (g.get('model'), g.get('fw')) if x)
            if not described:
                continue
            target = self.gateway_device_id(g)
            if target:
                self._gw_info[target] = {'model': g.get('model') or '', 'fw': g.get('fw') or '',
                                         'text': described}
        devices = [self.describe(d, self.live.get(d['id'])) for d in self.store.devices()]
        order = {'ok': 0, 'warn': 1, 'crit': 2}
        level = 'ok'
        for d in devices:
            if order[d['level']] > order[level]:
                level = d['level']
        if not self.connected:
            level = 'crit'
        elif self.bridge.get('state') == 'offline':
            level = 'crit'
        elif not devices:
            level = 'unknown'
        pj_end = self.bridge.get('permit_join_end')
        permit = bool(self.bridge.get('permit_join'))
        if permit and pj_end and pj_end / 1000.0 < now:
            permit = False
        return {
            'ok': True, 'ts': int(now), 'level': level,
            'connected': self.connected,
            'broker': '%s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port']),
            'bridge': dict(self.bridge, permit_join=permit),
            'devices': devices,
            'counts': {'devices': len(devices),
                       'online': sum(1 for d in devices if d['online']),
                       'ok': sum(1 for d in devices if d['level'] == 'ok'),
                       'warn': sum(1 for d in devices if d['level'] == 'warn'),
                       'crit': sum(1 for d in devices if d['level'] == 'crit')},
            'thresholds': {k: CONFIG[k] for k in ('battery_warn', 'battery_crit', 'lqi_warn',
                                                   'lqi_crit', 'stale_warn_min', 'stale_crit_min',
                                                   'temperature_min', 'temperature_max',
                                                   'humidity_max')},
            'seq': self.seq,
            'pin_required': bool(CONFIG.get('pin')),
            'unlocked_until': int(self.unlocked_until()) if self.unlocked_until() else None,
            'pin_length': len(str(CONFIG.get('pin') or '')),
            'pin_numeric': str(CONFIG.get('pin') or '').isdigit(),
            'plugs': [self.plug_snapshot(p) for p in self.plugs.values()],
            'bindings': self.bindings(),
            'rules': [dict(r, **{'holds': (self.rule_runtime.get(r['id']) or {}).get('holds'),
                                 'reading': (self.rule_runtime.get(r['id']) or {}).get('reading')})
                      for r in self.rules()],
            'rule_ops': RULE_OPS,
            'switch_targets': self.zigbee_targets() + self.heating_targets(),
            'presence': self.presence_state(),
            'messages': self.alert_messages(),
            'alerts': self.active_alerts(),
            'holds': [dict(v, target=k, label=self.target_label(k))
                      for k, v in sorted(self.manual_holds().items())],
            'rooms': self.rooms(),
            'room_of': self.room_map(),
            'heating': self.heating_state(),
            'people': self.people_public(),
            'presence_triggers': self.presence_triggers(),
            'wifi_config': self.wifi_public(self.wifi_config()),
            'wifi_detail': self.wifi_detail_state(),
            'wifi_order': self._wifi_order(),
            'wifi_probe_note': (self.wifi.get('detail') or {}).get('filtered') and
                               'the controller listed devices, but none of them looked like an access point' or
                               ((self.wifi.get('detail') or {}).get('error') or ''),
            'scenes': [{'id': x['id'], 'name': x['name'], 'actions': len(x['actions'])} for x in self.scenes()],
            'schedule_count': len(self.schedules()),
            'sequences': [{'id': x['id'], 'name': x['name'], 'steps': len(x['steps']),
                           'pos': self.sequence_positions().get(x['id'], 0) % max(1, len(x['steps']))}
                          for x in self.sequences()],
            'notify': {'channels': self.notify_channels(), 'settings': self.notify_settings()},
            'runtime_config': self.runtime_config(),
            'overview_layout': self.overview_layout(),
            'gateways': self.gateways_for_ui(),
            'db': {'bytes': (db_path().stat().st_size if db_path().exists() else 0),
                   'last_aggregate': self.store.get_meta('last_aggregate_ts')},
            'astro': ({'sunrise': sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude'])),
                       'sunset': sun_minutes(float(CONFIG['latitude']), float(CONFIG['longitude']), sunset=True)}
                      if CONFIG.get('latitude') is not None and CONFIG.get('longitude') is not None else None),
            'binding_actions': BINDING_ACTIONS,
            'pulse_ms': {'default': PULSE_MS_DEFAULT, 'min': PULSE_MS_MIN, 'max': PULSE_MS_MAX},
            'pulsing': [p.name for p in self.plugs.values() if p.pulsing],
            'managed': self.managed_for_ui(),
            'order': self.overview_order(),
        }

    def health(self):
        t0 = time.perf_counter()
        out = {
            'ok': True,
            'version': __version__,
            'uptime_s': int(time.time() - self.started),
            'connected': self.connected,
            'last_connect': int(self.last_connect) if self.last_connect else None,
            'last_disconnect': int(self.last_disconnect) if self.last_disconnect else None,
            'connect_failures': self.connect_failures,
            'last_error': self.last_error,
            'messages': self.messages,
            'last_message': int(self.last_message_at) if self.last_message_at else None,
            'bridge_state': self.bridge.get('state'),
            'subscriptions': [t for t, _ in self.topics()],
            'pushes': {'listening': bool(CONFIG.get('sensor_listen')),
                       'endpoint': 'http://%s:%s/' % (CONFIG['sensor_listen_host'], CONFIG['sensor_listen_port'])
                       if CONFIG.get('sensor_listen') else None,
                       'received': self.pushes_received, 'rejected': self.pushes_rejected,
                       'last': int(self.last_push_at) if self.last_push_at else None},
            'db': dict(self.store.stats(), **self.store.latency()),
            'last_aggregate': self.store.get_meta('last_aggregate_ts'),
            'config_notes': CONFIG_NOTES,
        }
        # how long the daemon itself needed to answer this (a status build is similar work)
        out['api_ms'] = round((time.perf_counter() - t0) * 1000, 2)
        return out

    # -- privileged actions -------------------------------------------------
    def session_valid(self, token):
        entry = self.sessions.get(str(token or ''))
        if not entry:
            return False
        if entry['until'] < time.time():
            self.sessions.pop(str(token), None)
            return False
        return True

    def unlocked_until(self):
        now = time.time()
        for token, entry in list(self.sessions.items()):
            if entry['until'] < now:
                del self.sessions[token]
        return max((e['until'] for e in self.sessions.values()), default=None)

    def unlock(self, pin, minutes, client=''):
        err = self.check_pin(pin)
        if err:
            return None, err
        minutes = max(1, min(720, int(minutes or 15)))
        token = secrets.token_urlsafe(24)
        self.store.add_event('audit', 'editing unlocked for %d min%s'
                             % (minutes, (' from ' + client) if client else ''))
        until = time.time() + minutes * 60
        self.sessions[token] = {'until': until, 'minutes': minutes, 'client': client, 'since': int(time.time())}
        self.store.add_event('security', 'editing unlocked for %d min' % minutes)
        log('dashboard editing unlocked for %d min' % minutes)
        return {'token': token, 'until': int(until), 'minutes': minutes}, None

    def lock_editing(self, token=None):
        if token and token in self.sessions:
            del self.sessions[token]
        else:
            self.sessions.clear()
        self.store.add_event('security', 'editing locked')
        log('dashboard editing locked')

    def check_pin(self, given, session=None):
        """None when allowed: a valid unlock session, no PIN configured, or the right PIN."""
        if session and self.session_valid(session):
            return None
        pin = str(CONFIG.get('pin') or '')
        if not pin:
            return None
        if session and not given:
            return 'the editing session has expired - unlock again'
        now = time.time()
        if now < self.pin_locked_until:
            return 'too many wrong PINs; try again in %ds' % (self.pin_locked_until - now)
        if not str(given or ''):
            # Nothing was offered, so nothing was guessed. Counting this as a
            # wrong PIN lets any stray request - a stale tab, a bug in the
            # page - lock the owner out of their own house.
            return 'this needs the PIN'
        if str(given) != pin:
            self.pin_failures += 1
            if self.pin_failures >= int(CONFIG.get('pin_attempts') or 5):
                self.pin_locked_until = now + int(CONFIG.get('pin_lockout_s') or 300)
                self.pin_failures = 0
                self.store.add_event('security', 'PIN locked after repeated failures', 'warn')
                return 'too many wrong PINs; locked for %ds' % int(CONFIG.get('pin_lockout_s') or 300)
            return 'wrong PIN'
        self.pin_failures = 0
        return None

    def permit_join(self, enable, seconds=254):
        if not self.connected or not self.client:
            raise RuntimeError('not connected to the broker')
        topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/permit_join'
        body = {'time': int(seconds) if enable else 0}
        info = self.client.publish(topic, json.dumps(body), qos=1)
        if hasattr(info, 'rc') and info.rc != 0:
            raise RuntimeError('publish failed (%s) - check the broker ACL for %s' % (info.rc, topic))
        self.bridge['permit_join'] = bool(enable)
        self.bridge['permit_join_end'] = int((time.time() + seconds) * 1000) if enable else None
        self.store.add_event('control', 'permit join %s' % ('enabled for %ds' % seconds if enable else 'disabled'))
        log('permit join %s' % ('on' if enable else 'off'))
        return body

    def reset(self, scope, device=None):
        device_id = self.store.resolve(device) if device else None
        if scope == 'device' and not device_id:
            raise ValueError('unknown device %r' % device)
        dropped = []
        if scope == 'device':
            row = self.store.device(device_id)
            dropped = self.forget_device_cleanup(device_id, (row.get('alias') or row['name']) if row else device_id)
        self.store.reset(scope, device_id)
        if scope in ('all',):
            self.live.clear()
            self.names.clear()
        elif scope == 'device':
            self.live.pop(device_id, None)
            for n, i in list(self.names.items()):
                if i == device_id:
                    del self.names[n]
        elif scope == 'history':
            pass
        self.store.add_event('control', 'recorded data erased: %s%s' % (scope, ' ' + device if device else ''),
                             'warn')
        log('data reset: %s %s' % (scope, device or ''))
        self.bump()
        return dropped

    # -- main loop ------------------------------------------------------------
    def run(self):
        for note in CONFIG_NOTES:
            log('config: ' + note, 'warn')
        try:
            server = ApiServer(self)
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                log('cannot listen on %s:%s - another zigmon is already running there '
                    '(systemctl status zigmon). Stop it first, or point --config at a file '
                    'with a different api_port.' % (CONFIG['api_host'], CONFIG['api_port']), 'error')
            else:
                log('cannot listen on %s:%s - %s' % (CONFIG['api_host'], CONFIG['api_port'], e), 'error')
            return 2
        self.connect()
        server.start()
        self._running = True
        # the clock side of rules and schedules runs whether or not there is
        # a plug to poll (before, a house with only Zigbee switches had no
        # schedules at all, since they rode on the plug poll loop)
        threading.Thread(target=self.timer_loop, name='timers', daemon=True).start()
        threading.Thread(target=self.rule_worker, name='rules', daemon=True).start()
        threading.Thread(target=self.rule_worker, args=(True,), name='rules-presence', daemon=True).start()
        if self.plugs or self.sensors:
            self._plug_thread = threading.Thread(target=self.plug_loop, name='plugs', daemon=True)
            self._plug_thread.start()
            log('polling %d plug(s) and %d sensor(s): %s' % (len(self.plugs), len(self.sensors),
                                                            ', '.join(list(self.plugs) + list(self.sensors))))
        if CONFIG.get('sensor_listen'):
            threading.Thread(target=self.serve_pushes, name='pushes', daemon=True).start()
        log('zigmon %s running; API on http://%s:%d' % (__version__, CONFIG['api_host'], CONFIG['api_port']))
        while not self._stop.is_set():
            self._stop.wait(30)
            ensure_log_current()
            now = time.time()
            if now - self.last_aggregate_at >= int(CONFIG.get('aggregate_interval') or 3600):
                self.last_aggregate_at = now
                self.store.set_meta('last_aggregate_ts', str(int(now)))
                try:
                    self.purge_per_device()
                except Exception as e:
                    log('per-device retention: %s' % e, 'warn')
                try:
                    n = self.store.aggregate()
                    if n:
                        log('rolled up %d hourly rows' % n, 'debug')
                except Exception as e:
                    log('aggregate: %s' % e, 'error')
                self.store.trim_wal()
        log('stopping')
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass
        if not self.store.flush(10.0):       # land whatever is still queued
            log('some recorded values were still queued at shutdown', 'warn')
        server.stop()
        return 0

    def stop(self, *_):
        self._stop.set()

    def reopen_log(self, *_):
        open_log()
        log('log file reopened')


# ---------------------------------------------------------------------------
# HTTP API
# ---------------------------------------------------------------------------
class ApiHandler(BaseHTTPRequestHandler):
    server_version = 'zigmon/' + __version__
    daemon = None

    def log_message(self, fmt, *args):
        log('api %s' % (fmt % args), 'debug')

    def _send(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _send_file(self, path, download_name):
        size = path.stat().st_size
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(size))
        self.send_header('Content-Disposition', 'attachment; filename="%s"' % download_name)
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            with open(path, 'rb') as fh:
                while True:
                    chunk = fh.read(256 * 1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _error(self, status, message):
        self._send(status, {'ok': False, 'error': message})

    def _query(self):
        url = urlparse(self.path)
        return url.path, {k: v[-1] for k, v in parse_qs(url.query).items()}

    def _body(self):
        length = int(self.headers.get('Content-Length') or 0)
        if length <= 0:
            return {}
        # a settings import or a backup piece may be big; everything else is tiny
        limit = 6 * 1024 * 1024 if self.path.split('?')[0] in ('/api/db/backup/upload', '/api/import') else 65536
        if length > limit:
            raise ValueError('body too large')
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise ValueError('body is not JSON')
        return data if isinstance(data, dict) else {}

    def _authorised(self):
        given = self.headers.get('X-Zigmon-Token') or ''
        return bool(given) and secrets.compare_digest(given, self.daemon.token)

    def do_GET(self):
        d = self.daemon
        path, q = self._query()
        try:
            if path == '/api/status':
                return self._send(200, d.status())
            if not CONFIG.get('public_view', True):
                token = self.headers.get('X-Zigmon-Session') or ''
                if path != '/api/health' and not d.session_valid(token):
                    return self._error(403, 'view locked - unlock with the PIN')
            if path == '/api/health':
                return self._send(200, d.health())
            if path == '/api/mqtt/selftest':
                return self._send(200, d.mqtt_selftest())
            if path == '/api/networkmap/refresh':
                return self._send(200, d.refresh_networkmap())
            if path == '/api/order/reset':
                if not self._authorised():
                    return self._error(403, 'this needs the API token')
                try:
                    done = d.reset_arrangement(str(q.get('what') or 'wifi'))
                except ValueError as e:
                    return self._send(200, {'ok': False, 'error': str(e),
                                            'choices': sorted(Daemon.ARRANGEMENTS)})
                return self._send(200, {'ok': True, 'reset': done})
            if path == '/api/wifi/order/reset':
                if not self._authorised():
                    return self._error(403, 'this needs the API token')
                d.reset_arrangement('wifi')
                return self._send(200, {'ok': True, 'order': []})
            if path == '/api/wifi/dump' and q.get('probe'):
                if not self._authorised():
                    return self._error(403, 'this needs the API token')
                cfg = d.wifi_config()
                out = {'ok': True}
                try:
                    out['probe'] = unifi_probe(cfg)
                except Exception as e:
                    out['probe'] = {'error': str(e)}
                if unifi_wants_legacy(cfg):
                    try:
                        out['signin'] = unifi_signin_probe(cfg)
                    except Exception as e:
                        out['signin'] = {'error': str(e)}
                elif cfg.get('username'):
                    out['signin'] = {'skipped': 'a username is stored but signing in is not being used; '
                                                'the access points answer the same questions over SSH'}
                if cfg.get('ssh_enabled'):
                    out['access_points'] = _probe_access_points(d, cfg)
                return self._send(200, out)
            if path == '/api/wifi/dump':
                # what `zigmon --wifi` reads: the token in the header is the
                # authority here, the same as the network map refresh
                if not self._authorised():
                    return self._error(403, 'this needs the API token')
                try:
                    d.wifi_poll_once()
                    d.wifi_detail_poll()
                except Exception as e:
                    return self._send(200, {'ok': False, 'error': str(e), 'wifi': d.wifi_detail_state(),
                                            'people': d.people()})
                return self._send(200, {'ok': True, 'wifi': d.wifi_detail_state(), 'people': d.people()})
            if path == '/api/log':
                # what the daemon is saying about itself, for the page that
                # just asked it to do something slow
                try:
                    lines = max(1, min(400, int(q.get('lines') or 60)))
                except ValueError:
                    lines = 60
                since = q.get('since') or ''
                path_log = CONFIG.get('log_file')
                out = []
                try:
                    if path_log and Path(path_log).exists():
                        # read the tail, not the file: a log grows for months and
                        # this is asked for every second while a job runs
                        with open(path_log, 'rb') as fh:
                            fh.seek(0, 2)
                            size = fh.tell()
                            chunk = min(size, 64 * 1024)
                            fh.seek(size - chunk)
                            tail = fh.read(chunk).decode('utf-8', 'replace')
                        out = tail.splitlines()[-lines:]
                        if chunk < size and out:
                            out = out[1:] if len(out) > 1 else out   # the first line may be cut
                except OSError as e:
                    return self._send(200, {'ok': False, 'error': str(e), 'lines': []})
                out = [x.rstrip('\n') for x in out]
                if since:
                    out = [x for x in out if x > since]
                return self._send(200, {'ok': True, 'lines': out, 'file': path_log})
            if path == '/api/db/backups':
                return self._send(200, {'ok': True, 'backups': d.db_backups(), 'dir': str(d.backup_dir())})
            if path == '/api/wifi/sshkey/download':
                # a download is a privileged read: the session token travels in the query
                err = d.check_pin(None, q.get('session'))
                if err:
                    return self._error(403, err)
                private = d.wifi_config().get('ssh_key') or ''
                if not private:
                    return self._error(404, 'no key is stored')
                raw = private.encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', 'attachment; filename="zigmon-ap-key"')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
            if path == '/api/db/backup/download':
                # a download is a privileged read: the session token travels in the query
                err = d.check_pin(None, q.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    fpath = d.db_backup_path(q.get('file') or '')
                except ValueError as e:
                    return self._error(400, str(e))
                if not fpath.exists():
                    return self._error(404, 'no such backup')
                return self._send_file(fpath, fpath.name)
            if path == '/api/devices':
                return self._send(200, {'ok': True, 'devices': d.status()['devices']})
            if path == '/api/device':
                device_id = d.store.resolve(q.get('id') or q.get('name') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                dev = d.store.device(device_id)
                out = d.describe(dev, d.live.get(device_id))
                out['keys'] = d.store.keys_for(device_id)
                out['exposes'] = dev.get('exposes') or {}
                return self._send(200, dict(out, ok=True))
            if path == '/api/history':
                device_id = d.store.resolve(q.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                seconds = parse_span(q.get('range', '24h'))
                points = max(20, min(5000, int(q.get('points', 600))))
                keys = [k for k in (q.get('keys') or '').split(',') if k]
                if not keys:
                    keys = [k for k in d.store.keys_for(device_id) if k != 'linkquality'][:4]
                rows = d.store.history(device_id, keys, seconds, points)
                return self._send(200, {'ok': True, 'device': device_id, 'keys': keys,
                                        'range_s': seconds, 'rows': rows})
            if path == '/api/message-preview':
                # what a message would read right now; nothing is sent and
                # nothing is changed, so no PIN - the editor asks on every keystroke
                facts = d.message_facts('rule: a test', {'device': 'PIR-Chodba', 'key': 'occupancy',
                                                         'value': 1, 'target': 'the hall light',
                                                         'action': 'on', 'person': 'you'})
                return self._send(200, {'ok': True, 'title': d.fill_message(str(q.get('title') or ''), facts),
                                        'text': d.fill_message(str(q.get('text') or ''), facts)})
            if path == '/api/history-multi':
                # items=<device>|<key>,<key>;<device>|<key>  - the Overview charts in one go
                seconds = parse_span(q.get('range', '24h'))
                points = max(20, min(2000, int(q.get('points', 400))))
                wanted = []
                for item in (q.get('items') or '').split(';'):
                    if '|' not in item:
                        continue
                    ident, keys = item.split('|', 1)
                    device_id = d.store.resolve(ident.strip())
                    keys = [k for k in keys.split(',') if k]
                    if device_id and keys:
                        wanted.append((device_id, keys))
                    if len(wanted) >= 200:
                        break
                return self._send(200, {'ok': True, 'range_s': seconds,
                                        'series': d.store.history_many(wanted, seconds, points)})
            if path == '/api/events':
                limit = max(1, min(1000, int(q.get('limit', 100))))
                device_id = d.store.resolve(q.get('device')) if q.get('device') else None
                rows = d.store.events(limit, device_id)
                names = {x['id']: x['name'] for x in d.store.devices(include_removed=True)}
                for r in rows:
                    r['device_name'] = names.get(r['device']) if r['device'] else None
                return self._send(200, {'ok': True, 'events': rows})
            if path == '/api/wait':
                since = int(numeric(q.get('seq')) or 0)
                timeout = float(numeric(q.get('timeout')) or 25.0)
                seq = d.wait_for_change(since, timeout)
                return self._send(200, {'ok': True, 'seq': seq})
            if path == '/api/plugs':
                return self._send(200, {'ok': True, 'plugs': [d.plug_snapshot(p) for p in d.plugs.values()]})
            if path == '/api/plug':
                p = d.plug_by_name(q.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                if q.get('refresh'):
                    d.poll_plug(p, force=True)
                return self._send(200, dict(d.plug_snapshot(p), ok=True))
            if path == '/api/bindings':
                return self._send(200, {'ok': True, 'bindings': d.bindings(), 'actions': BINDING_ACTIONS,
                                        'plugs': list(d.plugs)})
            if path == '/api/managed':
                return self._send(200, dict(d.managed_for_ui(), ok=True))
            if not CONFIG.get('public_view', True):
                token = self.headers.get('X-Zigmon-Session') or ''
                if path != '/api/health' and not d.session_valid(token):
                    return self._error(403, 'view locked - unlock with the PIN')
            if path == '/api/energy/daily':
                name = (parse_qs(urlparse(self.path).query).get('plug') or [''])[0]
                targets = list(d.plugs.values()) if name == '*' else [d.plug_by_name(name)]
                if not targets or targets[0] is None:
                    return self._error(404, 'unknown plug')
                now = time.time()
                lt = time.localtime(now)
                midnight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
                days = []
                for i in range(29, -1, -1):
                    t0 = midnight - i * 86400
                    t1 = min(t0 + 86400, now)
                    wh = sum(d.store.counter_delta(p.device_id, 'switch.aenergy.total', t0, t1) for p in targets)
                    days.append({'day': time.strftime('%m-%d', time.localtime(t0)), 'wh': round(wh, 2)})
                return self._send(200, {'ok': True, 'plug': 'All plugs' if name == '*' else targets[0].name, 'days': days})
            if path == '/api/health':
                return self._send(200, {'ok': True, 'version': __version__,
                                        'broker': bool(d.connected),
                                        'bridge': d.bridge.get('state') or 'unknown'})
            if path == '/api/rules':
                return self._send(200, {'ok': True, 'rules': d.rules(), 'ops': RULE_OPS})
            if path == '/api/scenes':
                return self._send(200, {'ok': True, 'scenes': d.scenes()})
            if path == '/api/schedules':
                return self._send(200, {'ok': True, 'schedules': d.schedules()})
            if path == '/api/sequences':
                return self._send(200, {'ok': True, 'sequences': d.sequences(), 'positions': d.sequence_positions()})
            if path == '/api/energy':
                return self._send(200, dict(d.energy_summary(), ok=True))
            if path == '/api/export':
                return self._send(200, dict(d.export_settings(), ok=True))
            if path == '/api/keys':
                device_id = d.store.resolve(q.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                return self._send(200, {'ok': True, 'keys': d.store.keys_for(device_id)})
            return self._error(404, 'no such endpoint')
        except ValueError as e:
            return self._error(400, str(e))
        except Exception as e:
            log('api %s: %s' % (path, e), 'error')
            return self._error(500, 'internal error: %s' % e)

    def do_POST(self):
        d = self.daemon
        path, _ = self._query()
        if not self._authorised():
            return self._error(403, 'missing or wrong API token')
        try:
            body = self._body()
        except ValueError as e:
            return self._error(400, str(e))
        try:
            if path == '/api/unlock':
                result, err = d.unlock(body.get('pin'), body.get('minutes'),
                                       str(self.headers.get('X-Zigmon-Client') or '')[:60])
                if err:
                    return self._error(403, err)
                return self._send(200, dict(result, ok=True))
            if path == '/api/lock':
                d.lock_editing(body.get('session'))
                return self._send(200, {'ok': True})
            if path == '/api/permit-join':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                enable = bool(body.get('enable', True))
                seconds = max(10, min(254, int(body.get('time', 254))))
                result = d.permit_join(enable, seconds)
                return self._send(200, {'ok': True, 'permit_join': enable, 'request': result})
            if path == '/api/plug/switch':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                p = d.plug_by_name(body.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                if body.get('pulse'):
                    ok, message = d.pulse_plug(p, body.get('ms'))
                elif body.get('toggle'):
                    ok, message = d.toggle_plug(p)
                else:
                    ok, message = d.set_plug_output(p, bool(body.get('on')))
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message,
                                                        'plug': d.plug_snapshot(p)})
            if path == '/api/rooms':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    rooms = d.save_rooms(body.get('rooms') or [])
                    if isinstance(body.get('room_of'), dict):
                        d.save_room_map(body['room_of'])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'rooms': rooms, 'room_of': d.room_map()})
            if path == '/api/heating/calibrate':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                ok, message = d.calibrate_valve(body.get('target') or '')
                return self._send(200 if ok else 400, {'ok': ok, 'message' if ok else 'error': message})
            if path == '/api/heating':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    d.save_heating(body)
                except ValueError as e:
                    return self._error(400, str(e))
                d.heating_apply()
                return self._send(200, {'ok': True, 'heating': d.heating_state()})
            if path == '/api/energy/monthly':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'text': d.monthly_summary(force=True)})
            if path == '/api/people/token':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                person = next((p for p in d.people() if p['id'] == str(body.get('id') or '')), None)
                if person is None:
                    return self._error(404, 'unknown person')
                if body.get('roll') or not person.get('token'):
                    people = d.people()
                    for p in people:
                        if p['id'] == person['id']:
                            p['token'] = 'new'
                            p['phone_report'] = True
                    d.save_people(people)
                    person = next(p for p in d.people() if p['id'] == person['id'])
                return self._send(200, {'ok': True, 'id': person['id'], 'name': person['name'],
                                        'token': person['token']})
            if path == '/api/presence/report':
                # A phone's own word on where it is. The token is the whole
                # credential (it is what sits in the handset's shortcut), so
                # no PIN - but a wrong one is counted and slowed down.
                who = self.client_address[0]
                if not d.presence_report_allowed(who):
                    return self._error(429, 'too many presence reports; slow down')
                ok, message = d.presence_report(body.get('token'), body.get('state'),
                                                'a phone at %s' % who)
                if not ok:
                    d.presence_report_failed(who)
                    return self._error(403 if 'token' in message else 400, message)
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/target/set':
                # Drive one Zigbee target straight from the dashboard: a wall
                # switch channel, or a valve's target temperature and mode.
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                target = d._valid_target(body.get('target') or '')
                if not target or not (target.startswith('zb:') or target.startswith('heat:')):
                    return self._error(404, 'unknown target')
                do = valid_action(body.get('do'))
                if not do:
                    return self._error(400, 'do must be on, off, toggle, pulse or set:<value>')
                if target.startswith('heat:'):
                    d.heat_target(target[5:], do, 'the dashboard', body.get('hold_s'))
                    return self._send(200, {'ok': True, 'message': '%s: %s' % (d.target_label(target), do)})
                pieces = target.split(':')
                ok, message = d.zigbee_switch(':'.join(pieces[1:-1]), pieces[-1], do,
                                              'the dashboard', body.get('ms'))
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message})
            if path == '/api/plug/reset':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                p = d.plug_by_name(body.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                types = body.get('types') if isinstance(body.get('types'), list) else []
                ok, message = d.reset_plug_counters(p, types)
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message,
                                                        'plug': d.plug_snapshot(p)})
            if path == '/api/bindings':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_bindings(body.get('bindings') or [])
                return self._send(200, {'ok': True, 'bindings': saved})
            if path == '/api/order':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_overview_order(body.get('plugs'), body.get('devices'), body.get('groups'),
                                              body.get('sensors'), body.get('buttons'))
                if body.get('rooms'):
                    saved['rooms'] = d.reorder_rooms(body['rooms'])
                return self._send(200, dict(saved, ok=True))
            if path == '/api/device/rename':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                device_id = d.store.resolve(body.get('id') or body.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                try:
                    message = d.rename_device(device_id, body.get('name'))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/scenes':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_scenes(body.get('scenes') or [])
                return self._send(200, {'ok': True, 'scenes': saved})
            if path == '/api/sequences':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    saved = d.save_sequences(body.get('sequences') or [])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'sequences': saved})
            if path in ('/api/sequence/advance', '/api/sequence/reset'):
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                fn = d.advance_sequence if path.endswith('advance') else d.reset_sequence
                ok, message = fn(str(body.get('id') or ''), 'the dashboard')
                if not ok:
                    return self._error(404, message)
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/schedules':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    saved = d.save_schedules(body.get('schedules') or [])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'schedules': saved})
            if path == '/api/scene/run':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                ok, message = d.run_scene(str(body.get('id') or ''), 'the dashboard')
                if not ok:
                    return self._error(404, message)
                return self._send(200, {'ok': True, 'message': message})
            if path == '/api/rule/dryrun':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    result = d.dryrun_rule(body.get('rule') or {}, int(numeric(body.get('days')) or 7))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, dict(result, ok=True))
            if path == '/api/sessions':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                now = time.time()
                out = [{'client': e.get('client') or '?', 'until': int(e['until']), 'since': e.get('since')}
                       for e in d.sessions.values() if e['until'] > now]
                return self._send(200, {'ok': True, 'sessions': out})
            if path == '/api/db/check':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                log('integrity check started (%s)' % human_size(d.store.stats().get('bytes') or 0))
                started = time.time()
                outcome = d.store.integrity_check()
                log('integrity check finished in %.1fs: %s'
                    % (time.time() - started, 'ok' if outcome.get('ok') else '; '.join(outcome.get('lines') or [])),
                    'info' if outcome.get('ok') else 'error')
                return self._send(200, dict(outcome, ok=True))
            if path == '/api/mqtt/ghosts':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'topics': d.ghost_topics()})
            if path == '/api/mqtt/ghosts/clear':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                log('clearing %d retained topic(s) the broker keeps for devices that are gone'
                    % len(d.ghost_topics()))
                out = d.clear_ghost_topics()
                log('retained topics: %d cleared, %d refused' % (len(out.get('cleared') or []), len(out.get('refused') or [])),
                    'info' if not out.get('refused') else 'warn')
                if out.get('cleared'):
                    d.store.add_event('control', 'cleared %d retained topic(s) left by removed devices'
                                      % len(out['cleared']))
                return self._send(200, out)
            if path == '/api/hold/release':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'released': d.release_target(body.get('target') or None),
                                        'holds': d.manual_holds()})
            if path == '/api/alerts/clear':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                gone = d.clear_alerts(body.get('id') or None)
                return self._send(200, {'ok': True, 'cleared': gone, 'alerts': d.active_alerts()})
            if path == '/api/messages':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                if body.get('preview') is not None:
                    facts = d.message_facts('rule: a test', {'device': 'PIR-Chodba', 'key': 'occupancy',
                                                             'value': 1, 'target': 'the hall light',
                                                             'action': 'on', 'person': 'you'})
                    return self._send(200, {'ok': True, 'preview': d.fill_message(str(body.get('preview')), facts)})
                if body.get('send'):
                    text = d.send_message(str(body.get('send')), 'a test from the dashboard',
                                          {'device': 'PIR-Chodba', 'key': 'occupancy', 'value': 1,
                                           'target': 'the hall light', 'action': 'on', 'person': 'you'})
                    return self._send(200, {'ok': True, 'sent': text})
                return self._send(200, {'ok': True, 'messages': d.save_alert_messages(body.get('messages') or [])})
            if path == '/api/wifi/config':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'wifi': d.save_wifi_config(body.get('wifi') or {})})
            if path == '/api/wifi/test':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                cfg = dict(d.wifi_config())
                for field in ('host', 'port', 'method', 'site', 'username', 'verify_ssl'):
                    if field in (body.get('wifi') or {}):
                        cfg[field] = (body['wifi'] or {})[field]
                for field in ('api_key', 'password'):
                    if (body.get('wifi') or {}).get(field):
                        cfg[field] = body['wifi'][field]
                try:
                    clients = unifi_clients(cfg)
                except Exception as e:
                    return self._send(200, {'ok': False, 'error': str(e)})
                return self._send(200, {'ok': True, 'clients': len(clients),
                                        'wifi_clients': sum(1 for c in clients if not c.get('wired'))})
            if path == '/api/wifi/order':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                ids = [str(x)[:80] for x in (body.get('order') or [])][:200]
                d.store.set_meta('wifi_order', json.dumps(ids))
                d.bump()
                return self._send(200, {'ok': True, 'order': ids})
            if path == '/api/wifi/sshkey':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                cfg = d.wifi_config()
                what = str(body.get('do') or '')
                if what == 'generate':
                    try:
                        private, public = generate_ssh_key('zigmon@%s' % (CONFIG.get('site_name') or 'zigmon'))
                    except Exception as e:
                        return self._send(200, {'ok': False, 'error': str(e)})
                    cfg['ssh_key'], cfg['ssh_public'] = private, public
                    d.store.set_meta('wifi', json.dumps(cfg))
                    d.store.add_event('control', 'a new SSH key was generated for the access points')
                    d.bump()
                    return self._send(200, {'ok': True, 'public': public})
                if what == 'upload':
                    private = str(body.get('key') or '').strip()
                    if 'PRIVATE KEY' not in private:
                        return self._send(200, {'ok': False, 'error': 'that does not look like a private key'})
                    public = ssh_public_from_private(private)
                    if not public:
                        return self._send(200, {'ok': False,
                                                'error': 'the key could not be read (is it protected by a passphrase?)'})
                    cfg['ssh_key'], cfg['ssh_public'] = private, public
                    d.store.set_meta('wifi', json.dumps(cfg))
                    d.store.add_event('control', 'an SSH key was uploaded for the access points')
                    d.bump()
                    return self._send(200, {'ok': True, 'public': public})
                if what == 'forget':
                    cfg.pop('ssh_key', None)
                    cfg.pop('ssh_public', None)
                    cfg['ssh_enabled'] = False
                    d.store.set_meta('wifi', json.dumps(cfg))
                    d.store.add_event('control', 'the SSH key for the access points was removed')
                    d.bump()
                    return self._send(200, {'ok': True, 'public': ''})
                if what == 'test':
                    out = {}
                    for ap in (d.wifi.get('detail') or {}).get('aps') or []:
                        if not ap.get('ip'):
                            continue
                        try:
                            info = parse_ap_info(ap_run(cfg, ap['ip'], 'info'))
                            out[ap.get('name') or ap['ip']] = {'ok': True, 'model': info.get('model'),
                                                               'version': info.get('version'),
                                                               'uptime': info.get('uptime')}
                        except Exception as e:
                            out[ap.get('name') or ap['ip']] = {'ok': False, 'error': str(e)[:140]}
                    if not out:
                        return self._send(200, {'ok': False,
                                                'error': 'no access point with an address is known yet - '
                                                         'ask the controller first'})
                    return self._send(200, {'ok': True, 'points': out})
                return self._error(400, 'unknown request')
            if path == '/api/wifi/probe':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                cfg = d.wifi_config()
                out = {'ok': True}
                try:
                    out['probe'] = unifi_probe(cfg)
                except Exception as e:
                    out['probe'] = {'error': str(e)}
                if unifi_wants_legacy(cfg):
                    try:
                        out['signin'] = unifi_signin_probe(cfg)
                    except Exception as e:
                        out['signin'] = {'error': str(e)}
                elif cfg.get('username'):
                    out['signin'] = {'skipped': 'a username is stored but signing in is not being used; '
                                                'the access points answer the same questions over SSH'}
                if cfg.get('ssh_enabled'):
                    out['access_points'] = _probe_access_points(d, cfg)
                return self._send(200, out)
            if path == '/api/wifi/detail':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    d.wifi_poll_once()
                    d.wifi_detail_poll()
                except Exception as e:
                    return self._send(200, {'ok': False, 'error': str(e), 'wifi': d.wifi_detail_state()})
                return self._send(200, {'ok': True, 'wifi': d.wifi_detail_state()})
            if path == '/api/wifi/clients':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                if body.get('refresh'):
                    try:
                        d.wifi_poll_once()
                    except Exception as e:
                        return self._send(200, {'ok': False, 'error': str(e), 'clients': d.wifi_client_list()})
                return self._send(200, {'ok': True, 'clients': d.wifi_client_list(),
                                        'checked': d.wifi.get('checked')})
            if path == '/api/people':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_people(body.get('people') or [])
                try:
                    if d.wifi_config().get('enabled'):
                        d.wifi_poll_once()
                except Exception:
                    pass
                return self._send(200, {'ok': True, 'people': saved, 'presence': d.presence_state()})
            if path == '/api/presence/triggers':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'triggers': d.save_presence_triggers(body.get('triggers') or [])})
            if path == '/api/db/stale':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, dict(d.store.stale_data(), ok=True))
            if path == '/api/db/stale/drop':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                only = body.get('device') or None
                log('erasing what is left of %s' % (only if only else 'every device that is gone'))
                out = d.store.drop_stale(only)
                log('erased %d rows from %d device(s): %s -> %s'
                    % (out['rows'], out['devices'], human_size(out['before_bytes']), human_size(out['after_bytes'])))
                d.store.add_event('control', 'erased data of %d device(s) that no longer exist: %d rows'
                                  % (out['devices'], out['rows']), 'warn')
                d.live.clear()
                return self._send(200, dict(out, ok=True))
            if path == '/api/db/prune':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                apply = bool(body.get('apply'))
                log('prune %s (%s)' % ('started' if apply else 'preview',
                                       human_size(d.store.stats().get('bytes') or 0)))
                out = d.store.prune(apply)
                log('prune %s: %s bookkeeping rows, %s repeated rows%s'
                    % ('removed' if apply else 'would remove', out['bookkeeping_rows'], out['repeated_rows'],
                       (', %s -> %s' % (human_size(out['before_bytes']), human_size(out['after_bytes']))) if apply else ''))
                if apply:
                    d.store.add_event('control', 'database pruned: %d + %d rows removed'
                                      % (out['bookkeeping_rows'], out['repeated_rows']))
                return self._send(200, dict(out, ok=True))
            if path == '/api/db/optimize':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                log('optimise started (%s); writes are paused while it runs'
                    % human_size(d.store.stats().get('bytes') or 0))
                result = d.store.optimize()
                log('optimise finished in %.1fs: %s -> %s'
                    % (result['seconds'], human_size(result['before_bytes']), human_size(result['after_bytes'])))
                d.store.add_event('control', 'database optimised: %.1f -> %.1f MB in %.1f s'
                                  % (result['before_bytes'] / 1048576.0, result['after_bytes'] / 1048576.0, result['seconds']))
                return self._send(200, dict(result, ok=True))
            if path == '/api/db/backup':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                log('backup started (%s)' % human_size(d.store.stats().get('bytes') or 0))
                made = d.db_backup_now()
                return self._send(200, dict(made, ok=True, backups=d.db_backups()))
            if path == '/api/db/backup/delete':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    name = d.db_backup_delete(str(body.get('file') or ''))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'deleted': name, 'backups': d.db_backups()})
            if path == '/api/db/backup/upload':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    result = d.db_backup_upload(body.get('name'), body.get('part') or 1, body.get('of') or 1,
                                                body.get('data'), body.get('upload_id'))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, dict(result, ok=True, backups=d.db_backups() if 'file' in result else None))
            if path == '/api/db/restore':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    result = d.db_restore(str(body.get('file') or ''))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, dict(result, ok=True))
            if path == '/api/backup/run':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                d.run_backup()
                return self._send(200, {'ok': True, 'message': 'Backup written to ' + str(d.backup_dir())
                                        + (' (the Zigbee2MQTT part arrives when the bridge answers)'
                                           if int(CONFIG.get('backup_zigbee') or 0) else '')})
            if path == '/api/lock-all':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                n = len(d.sessions)
                d.sessions.clear()
                d.store.add_event('audit', 'every editing session locked (%d)' % n)
                d.bump()
                return self._send(200, {'ok': True, 'message': '%d session(s) locked' % n})
            if path == '/api/config':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    changed = d.save_config_overrides(body)
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'changed': changed})
            if path == '/api/plug/detect':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    found = d.detect_plug(body.get('host'), body.get('password'), body.get('name'))
                except ValueError as e:
                    return self._error(400, str(e))
                except PlugError as e:
                    return self._error(502, str(e))
                return self._send(200, dict(found, ok=True))
            if path == '/api/gateway/detect':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                pw = body.get('password') or ''
                if not pw:                      # a saved gateway: use its stored password
                    for g in d.gateway_configs():
                        if str(g.get('host')) == str(body.get('host') or '').strip():
                            pw = g.get('password') or ''
                            break
                try:
                    found = d.detect_gateway(body.get('host'), body.get('username') or '', pw)
                except ValueError as e:
                    return self._error(400, str(e))
                except Exception as e:
                    msg = str(e)
                    if '401' in msg:
                        msg = 'the gateway wants a username and password (web server authentication is on)'
                    return self._error(502, msg)
                return self._send(200, dict(found, ok=True))
            if path == '/api/gateways':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    saved = d.save_managed_gateways(body.get('gateways') or [])
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'gateways': saved})
            if path == '/api/overview-layout':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_overview_layout(body.get('items'))
                return self._send(200, {'ok': True, 'items': saved})
            if path == '/api/energy/reset':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    label = d.reset_energy_summary(str(body.get('plug') or '*'))
                except ValueError as e:
                    return self._error(404, str(e))
                return self._send(200, {'ok': True, 'message': 'Energy summary starts from zero for ' + label})
            if path == '/api/notify':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                settings = {k: bool(body.get(k)) for k in ('crit', 'warn', 'rule', 'offline', 'switch')}
                devices = body.get('devices')
                if isinstance(devices, dict):
                    settings['devices'] = {str(k)[:80]: str(v)[:80] for k, v in list(devices.items())[:300]
                                           if notify_override_set(v) is not None}
                d.store.set_meta('notify', json.dumps(settings))
                d.bump()
                return self._send(200, dict(settings, ok=True))
            if path == '/api/notify/test':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                if not d.notify_channels():
                    return self._error(400, 'no channel configured - set notify_ntfy or the telegram pair in config.json')
                d.notify('A test message from the dashboard. If you can read this, it works.', 'info')
                return self._send(200, {'ok': True, 'channels': d.notify_channels()})
            if path == '/api/import':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                try:
                    counts = d.import_settings(body.get('data'))
                except ValueError as e:
                    return self._error(400, str(e))
                return self._send(200, {'ok': True, 'imported': counts})
            if path == '/api/rules':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_rules(body.get('rules') or [])
                return self._send(200, {'ok': True, 'rules': saved})
            if path == '/api/managed':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                saved = d.save_managed(body.get('plugs') or [], body.get('sensors') or [])
                return self._send(200, dict(saved, ok=True))
            if path == '/api/managed/test':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                host = str(body.get('host') or '').strip()
                if not host:
                    return self._error(400, 'no address')
                try:
                    return self._send(200, d.test_device(host, body.get('password') or ''))
                except PlugError as e:
                    return self._error(502, str(e))
            if path == '/api/managed/discover':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                return self._send(200, {'ok': True, 'devices': d.discover_devices(3.0)})
            if path == '/api/reset':
                err = d.check_pin(body.get('pin'), body.get('session'))
                if err:
                    return self._error(403, err)
                scope = str(body.get('scope') or 'history')
                if scope not in ('all', 'history', 'events', 'device'):
                    return self._error(400, 'scope must be all, history, events or device')
                target = body.get('device')
                before = d.store.stats().get('bytes') or 0
                log('erasing %s%s (%s); the file is compacted afterwards'
                    % (scope, ' ' + str(target) if target else '', human_size(before)))
                started = time.time()
                dropped = d.reset(scope, target)
                after = d.store.stats().get('bytes') or 0
                log('erase %s finished in %.1fs: %s -> %s'
                    % (scope, time.time() - started, human_size(before), human_size(after)))
                return self._send(200, {'ok': True, 'scope': scope, 'removed_with_it': dropped or [],
                                        'before_bytes': before, 'after_bytes': after})
            return self._error(404, 'no such endpoint')
        except (ValueError, RuntimeError) as e:
            return self._error(400, str(e))
        except Exception as e:
            log('api %s: %s' % (path, e), 'error')
            return self._error(500, 'internal error: %s' % e)


class ApiListener(ThreadingHTTPServer):
    # A page opening fires a dozen requests at once on top of the long polls
    # already parked; the default backlog of 5 lets the kernel drop the
    # overflow, and the browser retries a dropped connection a second later.
    request_queue_size = 64
    allow_reuse_address = True


class ApiServer(object):
    def __init__(self, daemon):
        handler = type('BoundHandler', (ApiHandler,), {'daemon': daemon})
        self.httpd = ApiListener((CONFIG['api_host'], int(CONFIG['api_port'])), handler)
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, name='api', daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------
class Palette(object):
    def __init__(self, enabled):
        self.on = enabled

    def _c(self, code, text):
        return '\033[%sm%s\033[0m' % (code, text) if self.on else str(text)

    def ok(self, t): return self._c('32', t)
    def warn(self, t): return self._c('33', t)
    def crit(self, t): return self._c('31', t)
    def dim(self, t): return self._c('2', t)
    def bold(self, t): return self._c('1', t)
    # the names the Shelly toolkit uses
    def title(self, t): return self._c('1;36', t)
    def rule(self, t): return self._c('36', t)
    def group(self, t): return self._c('1;35', t)
    def key(self, t): return self._c('37', t)
    def value(self, t): return self._c('1;33', t)
    def note(self, t): return self._c('2;37', t)
    def bad(self, t): return self._c('1;31', t)
    def info(self, t): return self._c('34', t)

    def level(self, level, text=None):
        text = level if text is None else text
        return {'ok': self.ok, 'warn': self.warn, 'crit': self.crit}.get(level, self.dim)(text)


def api_call(path, method='GET', payload=None, timeout=10.0, token=None):
    import urllib.request
    import urllib.error
    url = 'http://%s:%d%s' % (CONFIG['api_host'], int(CONFIG['api_port']), path)
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header('Accept', 'application/json')
    if data is not None:
        req.add_header('Content-Type', 'application/json')
    # A GET can be privileged too - the wifi dump is one - so a token handed
    # in explicitly is always sent; for anything that changes state it is
    # still looked up when the caller did not pass one.
    if token is None and method != 'GET':
        token = read_token()
    if token:
        req.add_header('X-Zigmon-Token', token)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode('utf-8'))
        except Exception:
            return e.code, {'ok': False, 'error': str(e)}
    except (urllib.error.URLError, OSError, ValueError) as e:
        return 0, {'ok': False, 'error': str(e)}


def read_token():
    try:
        return token_path().read_text().strip()
    except OSError:
        return None


def fmt_value(entry):
    v = entry.get('value')
    unit = entry.get('unit') or ''
    if isinstance(v, float):
        text = ('%.2f' % v).rstrip('0').rstrip('.')
    elif isinstance(v, bool):
        text = 'yes' if v else 'no'
    else:
        text = str(v)
    return (text + (' ' + unit if unit else '')).strip()


def cmd_status(args, pal):
    status_code, data = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    b = data['bridge']
    print(pal.bold('Broker    ') + data['broker'] + '  ' +
          (pal.ok('connected') if data['connected'] else pal.crit('disconnected')))
    print(pal.bold('Bridge    ') + '%s  %s  ch %s  %s' % (
        pal.level('ok' if b.get('state') == 'online' else 'crit', b.get('state') or '?'),
        b.get('version') or '', b.get('channel') or '?',
        pal.warn('PERMIT JOIN OPEN') if b.get('permit_join') else ''))
    print(pal.bold('Overall   ') + pal.level(data['level'], data['level']))
    print()
    devices = data['devices']
    if not devices:
        print(pal.dim('no devices recorded yet'))
        return 0
    width = max(len(d['name']) for d in devices)
    for d in devices:
        parts = [fmt_value(h) for h in d['headline']]
        extras = []
        if d.get('battery') is not None:
            extras.append('bat %d%%' % d['battery'])
        if d.get('linkquality') is not None:
            extras.append('lqi %d' % d['linkquality'])
        line = '%s  %-*s  %-6s %s  %s' % (
            pal.level(d['level'], '●'), width, d['name'], pal.level(d['level'], d['level']),
            '  '.join(parts), pal.dim(' '.join(extras)))
        print(line)
        print('   ' + pal.dim('%s %s · last %s ago%s' % (
            d.get('vendor') or '', d.get('model') or '', human_age(d['age_s']),
            (' · ' + '; '.join(d['reasons'])) if d['reasons'] else '')))
    return 0 if data['level'] in ('ok', 'unknown') else 1


def print_table(pal, headers, rows, colour=None, right=(), indent=0):
    """Columns as wide as the widest thing in them. Cutting a name or an id to
    fit a guessed width makes the output unusable for the one thing it is for:
    reading a value off the screen, or copying it into the next command."""
    plain = [[('' if c is None else str(c)) for c in row] for row in rows]
    width = [len(h) for h in headers]
    for row in plain:
        for i, cell in enumerate(row):
            if i < len(width):
                width[i] = max(width[i], len(cell))
    def line(cells, style=None, row_index=None):
        out = []
        for i, cell in enumerate(cells):
            pad = cell.rjust(width[i]) if i in right else cell.ljust(width[i])
            if i == len(cells) - 1:
                pad = pad.rstrip()          # nothing to align against past the last column
            if style:
                pad = style(i, pad, row_index)
            out.append(pad)
        return '  '.join(out).rstrip()
    lead = ' ' * indent
    print(lead + pal.bold(line(headers)))
    for n, row in enumerate(plain):
        print(lead + line(row, colour, n))


def cmd_devices(args, pal):
    status_code, data = api_call('/api/devices')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    rows = data['devices']
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    table = [[d['name'], d['id'], d['source'], d.get('kind') or '',
              ((d.get('vendor') or '') + ' ' + (d.get('model') or '')).strip(),
              d['level'],
              human_age(d['age_s']) + ' ago' if d['age_s'] is not None else 'never']
             for d in rows]
    levels = [d['level'] for d in rows]
    print_table(pal, ['NAME', 'ID', 'SOURCE', 'KIND', 'MODEL', 'LEVEL', 'LAST'], table,
                colour=lambda col, text, n: pal.level(levels[n], text) if col == 5 else text,
                right={6})
    return 0


def cmd_history(args, pal):
    span = args.range or '24h'
    query = '/api/history?device=%s&range=%s&points=%d' % (args.history, span, args.points)
    if args.keys:
        query += '&keys=' + args.keys
    status_code, data = api_call(query, timeout=60)
    if status_code != 200:
        print(pal.crit('error: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data, indent=2))
        return 0
    keys = data['keys']
    table = [[datetime.fromtimestamp(r['ts']).strftime('%Y-%m-%d %H:%M:%S')]
             + [('%.2f' % r[k]).rstrip('0').rstrip('.') if r.get(k) is not None else '-' for k in keys]
             for r in data['rows']]
    print_table(pal, ['TIME'] + list(keys), table, right=set(range(1, len(keys) + 1)))
    print(pal.dim('%d rows' % len(data['rows'])))
    return 0


def cmd_events(args, pal):
    status_code, data = api_call('/api/events?limit=%d' % args.limit)
    if status_code != 200:
        print(pal.crit('error: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data['events'], indent=2, ensure_ascii=False))
        return 0
    listed = list(reversed(data['events']))
    table = [[datetime.fromtimestamp(e['ts']).strftime('%Y-%m-%d %H:%M:%S'), '\u25cf',
              e['kind'], e.get('device_name') or e.get('device') or '', e.get('detail') or '']
             for e in listed]
    levels = [e.get('level') or 'info' for e in listed]
    print_table(pal, ['WHEN', ' ', 'KIND', 'DEVICE', 'DETAIL'], table,
                colour=lambda col, text, n: pal.level(levels[n], text) if col == 1 else text)
    return 0


def cmd_watch(args, pal):
    """Subscribe directly and print what arrives, without the daemon."""
    seen = {'n': 0}
    done = threading.Event()

    def on_connect(client, userdata, flags, rc, *rest):
        if rc_failed(rc):
            print(pal.crit('connect refused: %s' % reason_text(rc)))
            done.set()
            return
        topics = [(CONFIG['base_topic'].rstrip('/') + '/#', 0)]
        topics += [(t, 0) for t in CONFIG.get('extra_topics') or []]
        client.subscribe(topics)
        print(pal.dim('connected to %s:%s, watching %s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port'],
                                                             ', '.join(t for t, _ in topics))))

    def on_message(client, userdata, msg):
        seen['n'] += 1
        text = msg.payload.decode('utf-8', 'replace')
        if '/bridge/' in msg.topic and not args.bridge:
            return
        if len(text) > 400 and not args.raw:
            text = text[:400] + '…'
        print('%s  %s  %s' % (pal.dim(datetime.now().strftime('%H:%M:%S')), pal.bold(msg.topic), text))
        if args.count and seen['n'] >= args.count:
            done.set()

    client = make_mqtt_client('zigmon-watch-%d' % os.getpid())
    client.on_connect = on_connect
    client.on_message = on_message
    try:
        client.connect(CONFIG['mqtt_host'], int(CONFIG['mqtt_port']), 30)
    except OSError as e:
        print(pal.crit('cannot connect: %s' % e))
        return 2
    client.loop_start()
    try:
        done.wait(args.seconds if args.seconds else None)
    except KeyboardInterrupt:
        pass
    client.loop_stop()
    client.disconnect()
    return 0


def cmd_permit_join(args, pal):
    enable = args.permit_join.lower() in ('on', 'yes', '1', 'true', 'open')
    payload = {'enable': enable, 'time': 254}
    if CONFIG.get('pin'):
        payload['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/permit-join', 'POST', payload)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok('permit join is now %s' % ('open for 254 s' if enable else 'closed')))
    return 0


def cmd_reset(args, pal):
    scope = args.reset_data
    device = None
    if scope not in ('all', 'history', 'events'):
        device, scope = scope, 'device'
    if not args.yes:
        answer = input('Erase %s%s? This cannot be undone [y/N] ' % (scope, ' for ' + device if device else ''))
        if answer.strip().lower() not in ('y', 'yes'):
            print('nothing done')
            return 0
    payload = {'scope': scope}
    if device:
        payload['device'] = device
    if CONFIG.get('pin'):
        payload['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/reset', 'POST', payload, timeout=120)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok('erased: %s' % scope))
    return 0


def _plug_line(pal, snap):
    v = snap['values']
    state = pal.dim('unreachable') if not snap['online'] else (pal.ok('ON') if snap['output'] else pal.warn('OFF'))
    parts = []
    if v.get('power') is not None:
        parts.append('%.1f W' % v['power'])
    if v.get('voltage') is not None:
        parts.append('%.1f V' % v['voltage'])
    if v.get('current') is not None:
        parts.append('%.3f A' % v['current'])
    if v.get('energy') is not None:
        parts.append('%.3f kWh' % (v['energy'] / 1000.0))
    if v.get('temperature') is not None:
        parts.append('%.1f °C' % v['temperature'])
    return '%s  %s  %s' % (pal.bold('%-14s' % snap['name']), state, '  '.join(parts))


def cmd_plug(args, pal):
    status_code, data = api_call('/api/plugs')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    plugs = data['plugs']
    if args.json:
        print(json.dumps(plugs, indent=2, ensure_ascii=False))
        return 0
    if not plugs:
        print(pal.dim('no plugs configured (see "plugs" in %s)' % CONFIG_FILE))
        return 0
    for snap in plugs:
        if args.plug not in ('all', snap['name']):
            continue
        print(_plug_line(pal, snap))
        info = snap.get('info') or {}
        print('   ' + pal.dim('%s %s %s · %s · %s' % (
            info.get('model') or '', info.get('app') or '', info.get('ver') or '', snap['host'],
            (snap['error'] or ('stale, ' + human_age(snap['age']) + ' old')) if snap['stale']
            else 'read %s ago' % human_age(snap['age']))))
        for c in snap['counters']:
            if c['value'] is None:
                continue
            since = ('since ' if c['reset_exact'] else 'since at least ') + \
                datetime.fromtimestamp(c['reset_at']).strftime('%Y-%m-%d') if c['reset_at'] else 'no reset date'
            print('   %-20s %-14s %s' % (c['label'], '%g' % c['value'], pal.dim(since)))
    return 0


def cmd_plug_switch(args, pal):
    if args.plug_on:
        name, body = args.plug_on, {'on': True}
    elif args.plug_off:
        name, body = args.plug_off, {'on': False}
    elif args.plug_pulse:
        name, body = args.plug_pulse, {'pulse': True, 'ms': args.ms}
    else:
        name, body = args.plug_toggle, {'toggle': True}
    body['name'] = name
    if CONFIG.get('pin'):
        body['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/plug/switch', 'POST', body, timeout=30 + (args.ms / 1000.0 if args.plug_pulse else 0))
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok(data.get('message')))
    return 0


def cmd_plug_reset(args, pal):
    name = args.plug_reset
    types = [t for t in (args.types or '').split(',') if t]
    body = {'name': name, 'types': types}
    if CONFIG.get('pin'):
        body['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/plug/reset', 'POST', body, timeout=60)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok(data.get('message')))
    return 0


def cmd_bindings(args, pal):
    status_code, data = api_call('/api/bindings')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data['bindings'], indent=2))
        return 0
    if not data['bindings']:
        print(pal.dim('no bindings; add them on the Control tab of the dashboard'))
        return 0
    status_code, st = api_call('/api/status')
    names = {x['id']: x['name'] for x in st.get('devices', [])} if status_code == 200 else {}
    targets = {t['value']: t['name'] for t in st.get('switch_targets', [])} if status_code == 200 else {}
    for sc in (st.get('scenes', []) if status_code == 200 else []):
        targets['scene:' + sc['id']] = 'scene ' + sc['name']
    table = [['\u25cf' if b.get('enabled', True) else '\u25cb',
              names.get(b['device'], b['device']), b['action'], '\u2192',
              targets.get(b['plug'], b['plug']),
              b['do'] + (' %d ms' % b['pulse_ms'] if b['do'] == 'pulse' and b.get('pulse_ms') else '')]
             for b in data['bindings']]
    on = [b.get('enabled', True) for b in data['bindings']]
    def paint(col, text, n):
        if col == 0:
            return pal.ok(text) if on[n] else pal.dim(text)
        return pal.bold(text) if col == 5 else text
    print_table(pal, [' ', 'DEVICE', 'ACTION', ' ', 'TARGET', 'DOES'], table, colour=paint)
    return 0


def cmd_rules(args, pal):
    status_code, data = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    rules = data.get('rules') or []
    if args.json:
        print(json.dumps(rules, indent=2))
        return 0
    if not rules:
        print(pal.dim('no rules; add them on the Control tab of the dashboard'))
        return 0
    names = {x['id']: x['name'] for x in data.get('devices', [])}
    targets = {t['value']: t['name'] for t in data.get('switch_targets', [])}
    for sc in data.get('scenes', []):
        targets['scene:' + sc['id']] = 'scene ' + sc['name']
    table = [['\u25cf' if r.get('enabled', True) else '\u25cb',
              names.get(r['device'], r['device']),
              '%s %s %g' % (r['key'], r['op'], r['value']), '\u2192',
              targets.get(r['plug'], r['plug']),
              r['do'] + (' %d ms' % r['pulse_ms'] if r.get('pulse_ms') else ''),
              '?' if r.get('holds') is None else ('TRUE' if r['holds'] else 'false'),
              'now %g' % r['reading'] if r.get('reading') is not None else '']
             for r in rules]
    def paint(col, text, n):
        r = rules[n]
        if col == 0:
            return pal.ok(text) if r.get('enabled', True) else pal.dim(text)
        if col == 5:
            return pal.bold(text)
        if col == 6:
            return pal.dim(text) if r.get('holds') is None else (pal.warn(text) if r['holds'] else pal.ok(text))
        if col == 7:
            return pal.dim(text)
        return text
    print_table(pal, [' ', 'SOURCE', 'WHEN', ' ', 'TARGET', 'DOES', 'HOLDS', 'READING'], table, colour=paint)
    return 0


def cmd_check(args, pal):
    problems = 0

    def verdict(ok, text, detail=''):
        nonlocal problems
        if not ok:
            problems += 1
        print('  %s  %s%s' % (pal.ok('✔') if ok else pal.crit('✘'), text,
                              pal.dim('  ' + detail) if detail else ''))

    print(pal.bold('zigmon %s' % __version__))
    verdict(mqtt is not None, 'paho-mqtt importable', '' if mqtt else 'dnf install python3-paho-mqtt')
    verdict(not CONFIG_FATAL, 'configuration readable', '; '.join(CONFIG_FATAL))
    t0 = time.time()
    status_code, health = api_call('/api/health', timeout=5)
    ms = (time.time() - t0) * 1000
    verdict(status_code == 200, 'daemon API answering', '%.0f ms' % ms if status_code == 200 else health.get('error', ''))
    if status_code != 200:
        print(pal.dim('  is zigmon.service running?  journalctl -u zigmon -n 30'))
        return 1
    verdict(health['connected'], 'connected to the broker', health.get('last_error') or '')
    verdict(health.get('bridge_state') == 'online', 'Zigbee2MQTT bridge online',
            'state: %s' % health.get('bridge_state'))
    age = time.time() - health['last_message'] if health.get('last_message') else None
    verdict(age is not None and age < 3600, 'messages flowing',
            'last %s ago' % human_age(age) if age is not None else 'none since start')
    if health['connected']:
        # reading the broker and being allowed to write to it are two things:
        # without the second, every Zigbee switch command dies silently
        st_code, probe = api_call('/api/mqtt/selftest', timeout=8)
        verdict(st_code == 200 and probe.get('ok'), 'the broker accepts what we publish',
                (probe or {}).get('message') or 'no answer from the daemon')
    token = read_token()
    verdict(bool(token), 'API token readable by %s' % _whoami(), str(token_path()))
    status_code, status = api_call('/api/status', timeout=5)
    if status_code == 200:
        c = status['counts']
        verdict(c['devices'] > 0, '%d device(s): %d ok, %d warn, %d crit' % (
            c['devices'], c['ok'], c['warn'], c['crit']), '')
        for d in status['devices']:
            if d['level'] != 'ok':
                print('     %s %s: %s' % (pal.level(d['level'], '●'), d['name'], '; '.join(d['reasons'])))
    status_code, plugs = api_call('/api/plugs', timeout=5)
    if status_code == 200:
        # right after a (re)start the plugs have not been asked yet: give the
        # first poll a moment instead of reporting a failure that is not one
        pending = [snap for snap in plugs['plugs'] if not snap['online'] and snap['error'] == 'waiting for the first reading']
        if pending and (health.get('uptime_s') or 0) < 60:
            deadline = time.time() + 20
            while pending and time.time() < deadline:
                time.sleep(1.5)
                status_code, plugs = api_call('/api/plugs', timeout=5)
                if status_code != 200:
                    break
                pending = [snap for snap in plugs['plugs'] if not snap['online'] and snap['error'] == 'waiting for the first reading']
        for snap in plugs['plugs']:
            first = snap['error'] == 'waiting for the first reading'
            ok = snap['online'] and not snap['stale']
            if first:
                print('  %s  plug %s%s' % (pal.warn('◔'), snap['name'], pal.dim('  not polled yet (the daemon just started)')))
                continue
            verdict(ok, 'plug %s' % snap['name'],
                    snap['error'] or ('%s, %.1f W' % ('on' if snap['output'] else 'off', snap['values'].get('power') or 0)))
    db = health['db']
    verdict(True, 'database %s' % db['path'], '%s, %d samples, %d hourly, %d events' % (
        '%.1f MB' % (db['bytes'] / 1048576.0) if db.get('bytes') else '?', db['samples'],
        db['samples_hourly'], db['events']))
    return 1 if problems else 0


def cmd_diag(args, pal):
    print(pal.bold('Configuration in force (%s)' % CONFIG_FILE))
    for key in sorted(CONFIG):
        value = CONFIG[key]
        if key == 'mqtt_password' and value:
            value = '********'
        if key == 'pin' and value:
            value = '****'
        print('  %-24s %s' % (key, json.dumps(value)))
    for note in CONFIG_NOTES:
        print('  ' + pal.warn(note))
    for note in CONFIG_FATAL:
        print('  ' + pal.crit(note))
    print()
    for path in ('/api/health', '/api/status', '/api/events?limit=5'):
        t0 = time.time()
        status_code, data = api_call(path, timeout=5)
        print('  %-24s %s  %.0f ms' % (path, pal.ok(str(status_code)) if status_code == 200 else pal.crit(str(status_code)),
                                       (time.time() - t0) * 1000))
    status_code, health = api_call('/api/health', timeout=5)
    if status_code == 200:
        print()
        print(pal.bold('Daemon'))
        for key in ('version', 'uptime_s', 'connected', 'connect_failures', 'last_error', 'messages',
                    'bridge_state', 'subscriptions'):
            print('  %-24s %s' % (key, health.get(key)))
        print(pal.bold('Database'))
        for key, value in health['db'].items():
            if key == 'oldest' and value:
                value = datetime.fromtimestamp(value).strftime('%Y-%m-%d')
            if key == 'bytes' and value:
                value = '%.1f MB' % (value / 1048576.0)
            print('  %-24s %s' % (key, value))
    return 0


# ===========================================================================
# The Shelly toolkit - "zigmon shelly ..." - ported whole from upsmon
# ===========================================================================
def describe_plug_field(path):
    """A description for a status field, whichever component prefix it carries."""
    tail = re.sub(r'^[a-z_0-9]+:\d+\.', '', path)
    for candidate in (path, 'switch.' + tail, tail):
        if candidate in PLUG_DESCRIPTIONS:
            return PLUG_DESCRIPTIONS[candidate]
    return ''


RPC_METHODS = {
    # -- identity and housekeeping -----------------------------------------
    'Shelly.GetDeviceInfo': ('Model, name, firmware version and MAC.', None),
    'Shelly.GetStatus': ('Every component\'s current state in one reply.', None),
    'Shelly.GetConfig': ('Every component\'s configuration in one reply.', None),
    'Shelly.ListMethods': ('The list this command is built on.', None),
    'Shelly.GetComponents': ('Which components exist, with their keys.',
                             '{"offset":0}'),
    'Shelly.Reboot': ('Restart the device. Takes about ten seconds.', None),
    'Shelly.CheckForUpdate': ('Ask Shelly whether newer firmware exists.', None),
    'Shelly.Update': ('Install firmware. "stable" or "beta".',
                      '{"stage":"stable"}'),
    'Shelly.Identify': ('Flash the LED so you can tell which device it is.', None),
    'Shelly.DetectLocation': ('Set the timezone from the public IP address.', None),
    'Shelly.ListTimezones': ('Every timezone name the device accepts.', None),
    'Shelly.SetAuth': ('Set or clear the web password. The username is always '
                       'admin; a null password removes authentication.',
                       '{"user":"admin","realm":"shellyplug-xxxx","ha1":"..."}'),
    'Shelly.FactoryReset': ('Erase everything, including the Wi-Fi settings. '
                            'The device comes back as an access point.', None),
    'Shelly.ResetWiFiConfig': ('Forget the Wi-Fi settings only.', None),

    # -- the switch ---------------------------------------------------------
    'Switch.GetStatus': ('Power, voltage, current, energy, temperature and '
                         'relay state.', '{"id":0}'),
    'Switch.GetConfig': ('Name, auto-off timers, limits, initial state.',
                         '{"id":0}'),
    'Switch.SetConfig': ('Change any of those.',
                         '{"id":0,"config":{"auto_off":true,"auto_off_delay":300}}'),
    'Switch.Set': ('Switch the relay. "toggle_after" turns it back after N '
                   'seconds.', '{"id":0,"on":false}'),
    'Switch.Toggle': ('Flip the relay to the other state.', '{"id":0}'),
    'Switch.ResetCounters': ('Reset the running totals. Without "type", all of '
                             'them.', '{"id":0,"type":["aenergy"]}'),

    # -- system, network, radios -------------------------------------------
    'Sys.GetStatus': ('Uptime, free memory, filesystem, time, restart flag.', None),
    'Sys.GetConfig': ('Device name, timezone, location, debug settings.', None),
    'Sys.SetConfig': ('Change them.',
                      '{"config":{"device":{"name":"UPS socket"}}}'),
    'Sys.SetTime': ('Set the clock by hand, for a device with no internet.',
                    '{"unixtime":1788195638}'),
    'Wifi.GetStatus': ('Address, SSID, signal strength, connection state.', None),
    'Wifi.GetConfig': ('Both configured networks and the access point.', None),
    'Wifi.SetConfig': ('Change them. Getting this wrong takes the device off '
                       'the network.',
                       '{"config":{"sta":{"ssid":"net","pass":"secret","enable":true}}}'),
    'Wifi.Scan': ('List the networks the device can see.', None),
    'Wifi.ListAPClients': ('Who is connected to its own access point.', None),
    'Cloud.GetStatus': ('Whether it is talking to Shelly Cloud.', None),
    'Cloud.SetConfig': ('Turn the cloud connection on or off.',
                        '{"config":{"enable":false}}'),
    'Mqtt.GetStatus': ('Whether it is connected to an MQTT broker.', None),
    'Mqtt.SetConfig': ('Point it at a broker.',
                       '{"config":{"enable":true,"server":"10.0.0.2:1883"}}'),
    'BLE.GetConfig': ('Bluetooth radio and RPC-over-Bluetooth switches.', None),
    'BLE.SetConfig': ('Turn either on or off. Needs a reboot.',
                      '{"config":{"enable":true,"rpc":{"enable":true}}}'),
    'BLE.StartPairing': ('Accept a Bluetooth pairing for a while.', None),
    'BLE.ListPairedDevices': ('What is already paired.', None),
    'Matter.GetStatus': ('Whether Matter is on and commissionable.', None),
    'Matter.GetSetupCode': ('The pairing code a Matter controller needs.', None),
    'Matter.SetConfig': ('Turn Matter on or off. Needs a reboot.',
                         '{"config":{"enable":true}}'),
    'Matter.FactoryReset': ('Forget every Matter fabric it has joined.', None),
    'WS.GetConfig': ('Outbound websocket: where it connects out to.', None),
    'WS.SetConfig': ('Point it at a listener - what "shelly serve" accepts.',
                     '{"config":{"enable":true,"server":"ws://10.0.0.9:8089"}}'),

    # -- automation on the device itself -----------------------------------
    'Webhook.Create': ('Call a URL when something happens. This is how a '
                       'sleeping sensor reports.',
                       '{"cid":0,"enable":true,"event":"temperature.change",'
                       '"urls":["http://10.0.0.9:8088/?t=${ev.tC}"]}'),
    'Webhook.List': ('Every webhook currently set.', None),
    'Webhook.ListSupported': ('Which events this device can trigger on.', None),
    'Webhook.Delete': ('Remove one by id.', '{"id":1}'),
    'Webhook.DeleteAll': ('Remove all of them.', None),
    'Schedule.Create': ('Run something on a cron schedule, on the device.',
                        '{"enable":true,"timespec":"0 0 22 * * *",'
                        '"calls":[{"method":"Switch.Set","params":{"id":0,"on":false}}]}'),
    'Schedule.List': ('Every schedule currently set.', None),
    'Schedule.Delete': ('Remove one by id.', '{"id":1}'),
    'Script.List': ('Scripts stored on the device.', None),
    'Script.Create': ('Make an empty script slot.', '{"name":"watchdog"}'),
    'Script.PutCode': ('Upload JavaScript into a slot.',
                       '{"id":1,"code":"print(1);"}'),
    'Script.Start': ('Run it.', '{"id":1}'),
    'Script.Stop': ('Stop it.', '{"id":1}'),
    'KVS.Set': ('Store a value on the device, for scripts to read.',
                '{"key":"note","value":"UPS socket"}'),
    'KVS.Get': ('Read one back.', '{"key":"note"}'),
    'KVS.List': ('Every key stored.', None),
    'KVS.Delete': ('Remove one.', '{"key":"note"}'),
    'HTTP.GET': ('Make the device fetch a URL itself.',
                 '{"url":"http://10.0.0.9/ping"}'),
    'HTTP.POST': ('And post to one.',
                  '{"url":"http://10.0.0.9/hook","body":"{}"}'),
    'RPC.Ping': ('Check the device is answering at all.', None),
    'plugs_ui.GetConfig': ('The LED ring: colours, brightness, night mode.', None),
    'plugs_ui.SetConfig': ('Change them.',
                           '{"config":{"leds":{"mode":"power"}}}'),
}

# Components whose methods are all variations on a theme, so the group can be
# summarised rather than repeating a note against each entry.
RPC_COMPONENTS = {
    'Shelly': 'the device as a whole: identity, status, firmware, reboot',
    'Switch': 'the relay and its meter',
    'Sys': 'clock, name, timezone, memory',
    'Wifi': 'network settings and signal',
    'Cloud': 'the Shelly Cloud connection',
    'Mqtt': 'the MQTT broker connection',
    'BLE': 'the Bluetooth radio and RPC over Bluetooth',
    'Matter': 'Matter, for Apple Home and other controllers',
    'WS': 'the outbound websocket this tool can receive with "serve"',
    'Webhook': 'call a URL when something happens on the device',
    'Schedule': 'run something on a timer, on the device itself',
    'Script': 'JavaScript stored and run on the device',
    'KVS': 'a small key-value store for scripts',
    'HTTP': 'make the device fetch or post a URL itself',
    'OTA': 'firmware upload, used by Shelly.Update',
    'KNX': 'the KNX building-automation protocol',
    'BTHome': 'Bluetooth sensors reporting through this device',
    'BTHomeDevice': 'one such sensor',
    'BTHomeSensor': 'one measurement from such a sensor',
    'BTHomeControl': 'Bluetooth buttons and remotes',
    'Virtual': 'virtual components for scripts and the app UI',
    'Boolean': 'a virtual on/off value',
    'Number': 'a virtual number',
    'Text': 'a virtual string',
    'Enum': 'a virtual choice',
    'Group': 'a virtual group of components',
    'Button': 'a virtual button',
    'LNM': 'local network messaging between Shelly devices',
    'plugs_ui': 'the LED ring on the plug',
    'RPC': 'the RPC channel itself',
}



def shelly_targets():
    """Every device the configuration or the dashboard names: plugs first, then sensors."""
    out = {}
    for entry in CONFIG.get('plugs') or []:
        if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
            out[str(entry['name'])] = dict(entry, kind='plug')
    for entry in CONFIG.get('sensors') or []:
        if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
            out[str(entry['name'])] = dict(entry, kind='sensor')
    # what was added on the dashboard sits in the database
    try:
        db = sqlite3.connect('file:%s?mode=ro' % db_path(), uri=True, timeout=2)
        row = db.execute("SELECT value FROM meta WHERE key='managed'").fetchone()
        db.close()
        managed = json.loads(row[0]) if row and row[0] else {}
        for kind in ('plugs', 'sensors'):
            for entry in managed.get(kind) or []:
                if isinstance(entry, dict) and entry.get('name') and entry.get('host') \
                        and str(entry['name']) not in out:
                    out[str(entry['name'])] = dict(entry, kind=kind[:-1])
    except (sqlite3.Error, ValueError, OSError):
        pass
    return out


def shelly_for(role, args=None):
    """Build a client for a device named in the configuration, or an address given directly."""
    override_host = getattr(args, 'host', None) if args else None
    override_password = getattr(args, 'password', None) if args else None
    if override_host:
        return ShellyRPC(override_host, override_password or '', getattr(args, 'switch_id', 0) or 0,
                         label='the device at %s' % override_host)
    targets = shelly_targets()
    if not role:
        if not targets:
            raise PlugError('nothing configured - add a plug under "plugs" in %s, or give --host' % CONFIG_FILE)
        role = list(targets)[0]
    match = targets.get(role) or next((t for n, t in targets.items() if n.lower() == role.lower()), None)
    if match is None:
        raise PlugError('unknown device "%s" - configured: %s, or give --host'
                        % (role, ', '.join(targets) or 'none'))
    password = override_password if override_password is not None else (match.get('password') or '')
    return ShellyRPC(match['host'], password, match.get('switch_id') or 0,
                     label='%s %s' % (match['kind'], role))


SHELLY_COMPONENTS = ('Shelly.GetStatus', 'Shelly.GetConfig', 'Shelly.GetDeviceInfo',
                     'Sys.GetStatus', 'Wifi.GetStatus', 'Cloud.GetStatus',
                     'MQTT.GetStatus', 'BLE.GetConfig', 'Matter.GetStatus',
                     'Switch.GetStatus', 'Temperature.GetStatus',
                     'Humidity.GetStatus', 'DevicePower.GetStatus')


def shelly_everything(rpc):
    """Ask for every component the device might have; skip what it lacks."""
    out = {}
    for method in SHELLY_COMPONENTS:
        params = None
        if method.split('.')[0] in ('Switch', 'Temperature', 'Humidity', 'DevicePower'):
            params = {'id': rpc.switch_id
                      if method.startswith('Switch') else 0}
        try:
            result = rpc.call(method, params)
        except PlugError as e:
            if not is_missing_component(e):
                raise                # a rate limit or a dead network, not absence
            continue                 # not present on this model, which is normal
        if result is not None:
            out[method] = result
    return out


def shelly_print_flat(pal, flat, title=None):
    if title:
        print(pal.group(title))
    width = max([len(k) for k in flat] + [10])
    for key in sorted(flat):
        value = flat[key]
        if isinstance(value, list):
            value = ', '.join(str(v) for v in value)
        text = 'ON' if value is True else 'OFF' if value is False else str(value)
        painter = (pal.ok if value is True else pal.bad if value is False
                   else pal.note if value is None or value == '' else pal.value)
        print('  %s : %s' % (pal.key(key.ljust(width)), painter(text)))
        note = describe_plug_field(key)
        if note:
            print('  %s   %s' % (' ' * width, pal.note(note)))


# ---- mDNS discovery -------------------------------------------------------
def local_ipv4_addresses():
    """Every IPv4 address this machine holds, one per interface.

    A multi-homed host routes 224.0.0.251 out one interface only - whichever
    the default route uses. On a machine with several VLANs that is usually not
    the one the device or its proxy is on, so the query has to be sent out of
    each of them deliberately.
    """
    import fcntl
    import struct
    addresses = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        for _, name in socket.if_nameindex():
            try:
                packed = fcntl.ioctl(sock.fileno(), 0x8915,   # SIOCGIFADDR
                                     struct.pack('256s', name.encode()[:15]))
                address = socket.inet_ntoa(packed[20:24])
            except OSError:
                continue
            if not address.startswith('127.'):
                addresses.append((name, address))
    except (OSError, AttributeError):
        pass
    finally:
        sock.close()
    return addresses


def shelly_discover(pal, seconds=4.0):
    """Find Shelly devices by asking over multicast DNS.

    Two sockets, deliberately. Answers to a multicast query come back two ways:
    to the group on port 5353, and - when the question asks for it - by unicast
    to whatever port the query went out from.

    Binding 5353 alone is not enough and can be worse than useless: avahi-daemon
    usually holds it already, and with SO_REUSEPORT a unicast datagram to that
    port is delivered to exactly one of the sockets bound to it. That is as
    likely to be avahi as us. So the query is sent from a socket on a port
    nobody else has, which is where the unicast reply then arrives, while a
    second socket joins the group to catch the multicast one.
    """
    import struct

    def encode_name(name):
        out = b''
        for label in name.split('.'):
            if label:
                out += bytes([len(label)]) + label.encode('ascii')
        return out + b'\x00'

    def read_name(data, offset, depth=0):
        parts = []
        while offset < len(data) and depth < 20:
            length = data[offset]
            if length == 0:
                offset += 1
                break
            if length & 0xC0 == 0xC0:
                pointer = struct.unpack('!H', data[offset:offset + 2])[0] & 0x3FFF
                parts.append(read_name(data, pointer, depth + 1)[0])
                offset += 2
                break
            parts.append(data[offset + 1:offset + 1 + length].decode('ascii', 'replace'))
            offset += 1 + length
        return '.'.join(p for p in parts if p), offset

    services = ['_shelly._tcp.local', '_http._tcp.local',
                '_services._dns-sd._udp.local']

    # The querying socket, on a port of our own.
    asker = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
    asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
    asker.settimeout(0.2)
    try:
        asker.bind(('', 0))
    except OSError as e:
        print(pal.bad('cannot open a socket for the query: %s' % e))
        return {}

    # And a listener on the group, for replies sent the multicast way.
    listener = None
    try:
        listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, 'SO_REUSEPORT'):
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        listener.bind(('', 5353))
        listener.settimeout(0.2)
    except OSError:
        if listener:
            listener.close()
        listener = None

    interfaces = local_ipv4_addresses()

    # Join the group on each interface by name. INADDR_ANY leaves the choice to
    # the kernel, which picks one - on a host with several VLANs that is
    # usually not the one the answer arrives on.
    joined = 0
    if listener:
        targets = [address for _, address in interfaces] or ['0.0.0.0']
        for address in targets:
            try:
                listener.setsockopt(
                    socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                    struct.pack('4s4s', socket.inet_aton('224.0.0.251'),
                                socket.inet_aton(address)))
                joined += 1
            except OSError as e:
                log('could not join the multicast group on %s: %s' % (address, e),
                    'debug')
        if not joined:
            listener.close()
            listener = None
    shelly_discover.joined = joined
    shelly_discover.interfaces = interfaces
    shelly_discover.query_port = asker.getsockname()[1]

    sent = 0
    for service in services:
        # Two questions, differing only in the top bit of the class.
        #
        # 0x8001 asks for a unicast answer, which is what gets a reply back
        # through a router that will not carry multicast.
        #
        # 0x0001 asks for the ordinary multicast answer, and that is the one an
        # avahi reflector can work with: a reflector repeats multicast between
        # interfaces and does nothing at all with unicast replies. On a network
        # where the only path is a reflector, asking for unicast quietly
        # guarantees no answer.
        for qclass in (0x8001, 0x0001):
            query = (struct.pack('!HHHHHH', 0, 0, 1, 0, 0, 0)
                     + encode_name(service) + struct.pack('!HH', 12, qclass))
            # Out of every interface, not just whichever the default route picks.
            for name, address in (interfaces or [(None, None)]):
                try:
                    if address:
                        asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF,
                                         socket.inet_aton(address))
                    asker.sendto(query, ('224.0.0.251', 5353))
                    sent += 1
                except OSError as e:
                    log('mDNS query out of %s failed: %s'
                        % (name or 'default', e), 'debug')
    if not sent:
        print(pal.bad('could not send the query out of any interface'))
        asker.close()
        if listener:
            listener.close()
        return {}

    found = {}
    addresses = {}
    sockets = [s for s in (asker, listener) if s]
    deadline = time.time() + seconds
    while time.time() < deadline:
        ready, _, _ = select.select(sockets, [], [], 0.3)
        for sock in ready:
            try:
                data, addr = sock.recvfrom(9000)
            except (socket.timeout, OSError):
                continue

            names = []
            try:
                counts = struct.unpack('!HHHHHH', data[:12])
                offset = 12
                for _ in range(counts[2]):
                    _, offset = read_name(data, offset)
                    offset += 4
                for _ in range(counts[3] + counts[4] + counts[5]):
                    name, offset = read_name(data, offset)
                    rtype, _cls, _ttl, length = struct.unpack(
                        '!HHIH', data[offset:offset + 10])
                    offset += 10
                    body = data[offset:offset + length]
                    if rtype == 12:                   # PTR
                        target, _ = read_name(data, offset)
                        names.append(target)
                    elif rtype == 33 and length > 6:  # SRV
                        target, _ = read_name(data, offset + 6)
                        names.append(target)
                    elif rtype == 1 and length == 4:  # A
                        addresses[name.split('.')[0].lower()] = socket.inet_ntoa(body)
                    offset += length
            except (struct.error, IndexError):
                pass

            entry = found.setdefault(addr[0], {'ip': addr[0], 'names': set()})
            for name in names:
                short = name.split('.')[0]
                # A name beginning with an underscore is a service type, not a
                # device: enumerating _services._dns-sd._udp.local answers with
                # "_shelly._tcp.local", which is the question, not a device.
                if short.startswith('_'):
                    continue
                if 'shelly' in short.lower():
                    entry['names'].add(short)

    asker.close()
    if listener:
        listener.close()

    # Prefer the address a device published for itself over the packet's source,
    # which is the proxy when one is in the way.
    result = {}
    for entry in found.values():
        if not entry['names']:
            continue
        for name in entry['names']:
            ip = addresses.get(name.lower(), entry['ip'])
            record = result.setdefault(ip, {'ip': ip, 'names': {},
                                            'via': entry['ip'] if ip != entry['ip'] else None})
            # Devices answer with the same name in different case depending on
            # which record it came from; keep one of each, preferring the form
            # the device uses for its own hostname.
            record['names'].setdefault(name.lower(), name)
            if name.islower():
                record['names'][name.lower()] = name
    return {ip: {'ip': ip, 'names': sorted(r['names'].values()), 'via': r['via']}
            for ip, r in result.items()}


# ---- WebSocket, for live pushes -------------------------------------------
def _ws_send(sock, payload):
    """Send one masked text frame, as a client must."""
    import struct
    data = payload.encode('utf-8')
    header = bytes([0x81])
    mask = secrets.token_bytes(4)
    if len(data) < 126:
        header += bytes([0x80 | len(data)])
    elif len(data) < 65536:
        header += bytes([0x80 | 126]) + struct.pack('!H', len(data))
    else:
        header += bytes([0x80 | 127]) + struct.pack('!Q', len(data))
    masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    sock.sendall(header + mask + masked)


def _ws_frames(sock):
    """Yield the payload of each text frame arriving on an open socket."""
    import struct
    buffer = b''

    def need(count):
        nonlocal buffer
        while len(buffer) < count:
            chunk = sock.recv(65536)
            if not chunk:
                raise ConnectionError('the connection closed')
            buffer += chunk
        taken, buffer = buffer[:count], buffer[count:]
        return taken

    while True:
        first, second = need(2)
        opcode = first & 0x0F
        masked = second & 0x80
        length = second & 0x7F
        if length == 126:
            length = struct.unpack('!H', need(2))[0]
        elif length == 127:
            length = struct.unpack('!Q', need(8))[0]
        mask = need(4) if masked else None
        payload = need(length) if length else b''
        if mask:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        if opcode == 0x8:                       # close
            return
        if opcode == 0x9:                       # ping, answer with a pong
            sock.sendall(bytes([0x8A, 0x00]))
            continue
        if opcode in (0x1, 0x2) and payload:
            yield payload.decode('utf-8', 'replace')



def shelly_build_parser():
    """One subparser per command, so each has its own --help like any tool."""
    parser = argparse.ArgumentParser(
        prog='zigmon shelly',
        description='Talk to the Shelly devices named in the configuration over '
                    'their local RPC API. No pairing and no cloud: the device '
                    'answers on plain HTTP while it stays connected to the '
                    'Shelly app, the cloud and Apple Home over Matter.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
addressing a device
  zigmon shelly Lednice info         a plug or sensor by the name it has in the configuration
  zigmon shelly info                 with no name, the first configured plug is assumed
  zigmon shelly --host 10.0.0.5 info  something not in the configuration at all

commands at a glance
  reading        discover, info, dump, methods, poll, watch, listen, serve
  controlling    on, off, toggle, reset-counters, reboot
  configuring    config, matter, ble
  anything else  call

quoting JSON
  Linux and PowerShell:  call Switch.SetConfig '{"id":0,"config":{"power_limit":2900}}'
  cmd.exe:               call Switch.SetConfig "{\\"id\\":0,\\"config\\":{\\"power_limit\\":2900}}"

Run 'zigmon shelly COMMAND --help' for the options of one command.
""")
    # These are accepted before the command and after it, because insisting on
    # one position is exactly the kind of thing that makes a tool annoying.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--host', metavar='ADDR',
                        help='address of the device, overriding the configuration')
    common.add_argument('--password', metavar='PASS',
                        help='password if the device has one; the username is '
                             'always admin and cannot be changed')
    common.add_argument('--switch-id', dest='switch_id', type=int, default=0,
                        help='relay id on a multi-channel device (default 0)')
    common.add_argument('--no-color', action='store_true',
                        help='plain output with no colour codes')
    common.add_argument('--json', action='store_true',
                        help='machine-readable output where the command has any')
    for action in common._actions:
        parser._add_action(action)

    subs = parser.add_subparsers(dest='command', metavar='COMMAND')

    def add(name, help_text, description=None, epilog=None):
        return subs.add_parser(
            name, help=help_text, description=description or help_text,
            epilog=epilog, parents=[common],
            formatter_class=argparse.RawDescriptionHelpFormatter)

    found = add('discover', 'find Shelly devices on the network',
                'Ask the local network for Shelly devices over multicast DNS. '
                'This does not cross subnets, and some networks block it.')
    found.add_argument('--seconds', type=float, default=4.0,
                       help='how long to listen (default 4)')

    add('info', 'identity, firmware and auth state',
        'A short summary: model, name, firmware version, generation, and '
        'whether authentication and Matter are switched on.')

    add('dump', 'everything the device exposes, in one go',
        'Every component the device has, each with every field it reports. '
        'Use --json to get the replies exactly as the device sent them.')

    methods = add('methods', 'list every RPC method the device supports',
                  'Asks the device for its own method list, and explains the '
                  'ones worth knowing. Useful before reaching for "call": '
                  'whatever appears here can be invoked, and nothing else can.',
                  epilog="""
examples
  zigmon shelly plug methods                 everything, with notes
  zigmon shelly plug methods Switch          just one component
  zigmon shelly plug methods --examples      with a ready-made call for each
  zigmon shelly plug methods Webhook --examples --described
""")
    methods.add_argument('component', nargs='?',
                         help='only this component: Switch, Wifi, Webhook ...')
    methods.add_argument('--examples', action='store_true',
                         help='print a ready-made call under each method')
    methods.add_argument('--described', action='store_true',
                         help='hide methods there is nothing useful to say about')

    config = add('config', 'read or change a component configuration',
                 'With no arguments, the whole device configuration. With a '
                 'component, just that one. With a component and a JSON object, '
                 'the settings in that object are written.',
                 epilog="""
examples
  zigmon shelly plug config                       everything
  zigmon shelly plug config switch:0              one component
  zigmon shelly plug config sys                   the system section
  zigmon shelly plug config switch:0 '{"auto_off": true, "auto_off_delay": 60}'
  zigmon shelly plug config ble '{"enable": true}'

A write is checked by reading the value back, so a setting the firmware quietly
ignores is reported rather than assumed to have taken.
""")
    config.add_argument('component', nargs='?',
                        help='switch:0, sys, wifi, ble, matter, cloud, mqtt ...')
    config.add_argument('settings', nargs='?',
                        help='JSON object of settings to write')
    config.add_argument('--reboot', action='store_true',
                        help='restart the device afterwards, which some '
                             'settings need before they take effect')

    poll = add('poll', 'read the device on a timer, optionally to CSV',
               'A live table of the numbers the device reports. A sleeping '
               'battery device is retried rather than treated as an error.')
    poll.add_argument('--interval', type=float, default=5.0,
                      help='seconds between readings (default 5)')
    poll.add_argument('--count', type=int, help='stop after this many readings')
    poll.add_argument('--csv', metavar='FILE', help='append readings to a CSV file')

    add('watch', 'live push updates over websocket',
        'Subscribe to the device\'s own notifications instead of polling it. '
        'The websocket carries no authentication, so this does not work on a '
        'device with a password set - use poll there.')

    listen = add('listen', 'receive webhooks from a sleeping battery device',
                 'Print pushes as they arrive. Nothing is recorded; the daemon '
                 'stores them when sensor_listen is on.')
    listen.add_argument('--port', type=int, help='port to listen on')

    serve = add('serve', 'accept outbound websocket pushes from devices',
                'For a device configured to connect out to us rather than be '
                'polled.')
    serve.add_argument('--port', type=int, default=8089, help='port (default 8089)')

    add('on', 'switch the relay on')
    add('off', 'switch the relay off')
    add('toggle', 'flip the relay to the other state')

    reset = add('reset-counters', 'reset the plug\'s running totals',
                'With no type, every counter the device has. The values are '
                'read back afterwards, so a counter the firmware refuses to '
                'clear is reported rather than assumed reset.',
                epilog="""
counter types
  aenergy        active energy, the kilowatt-hour total
  ret_aenergy    energy returned to the grid
  on_time        total runtime, how long the relay has been on
  switch_on      switching cycles
  on_above_thr   active load runtime, time above the plug's threshold
""")
    reset.add_argument('types', nargs='*', help='which counters; none means all')

    reboot = add('reboot', 'restart the device')
    reboot.add_argument('--wait', action='store_true',
                        help='wait for it to come back and report the firmware')

    matter = add('matter', 'Matter on, off, status, or the pairing code',
                 'Matter has to be enabled before a controller can commission '
                 'the device, and the change needs a reboot.')
    matter.add_argument('action', nargs='?', default='status',
                        choices=['status', 'on', 'off', 'code'])
    matter.add_argument('--reboot', action='store_true',
                        help='restart afterwards so the change takes effect')

    ble = add('ble', 'Bluetooth radio and BLE RPC on, off or status',
              'The radio and the RPC-over-Bluetooth service are separate '
              'switches. Both need a reboot to take effect.')
    ble.add_argument('action', nargs='?', default='status',
                     choices=['status', 'on', 'off', 'rpc-on', 'rpc-off'])
    ble.add_argument('--reboot', action='store_true',
                     help='restart afterwards so the change takes effect')

    call = add('call', 'invoke any RPC method directly',
               'For anything the commands above do not cover. Run "methods" '
               'first to see what this device accepts.',
               epilog="""
examples
  zigmon shelly plug call Shelly.GetStatus
  zigmon shelly plug call Switch.GetStatus '{"id":0}'
  zigmon shelly plug call Switch.SetConfig '{"id":0,"config":{"power_limit":2900}}'
""")
    call.add_argument('method', help='for example Switch.GetStatus')
    call.add_argument('params', nargs='?', help='JSON object of parameters')

    return parser


def cmd_wifi_probe(args, pal):
    """What the controller says to each question, so a thin tab can be
    explained rather than guessed at."""
    status_code, st = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % st.get('error')))
        return 2
    code, answer = api_call('/api/wifi/dump?probe=1', timeout=90.0, token=read_token())
    if code != 200:
        print(pal.bad('the daemon refused: %s' % (answer.get('error') or code)))
        return 2
    if args.json:
        print(json.dumps(answer, indent=2, ensure_ascii=False))
        return 0
    probe = answer.get('probe') or {}
    signin = answer.get('signin')
    print()
    print(pal.group('  What it answers to the API key'))
    for name in ('prefix', 'site'):
        if probe.get(name):
            print('    %-12s %s' % (name, probe[name]))
    for name in ('info', 'devices', 'clients', 'statistics'):
        part = probe.get(name)
        if not isinstance(part, dict):
            continue
        line = 'HTTP %s' % part.get('status')
        if part.get('count') is not None:
            line += ', %s row(s)' % part['count']
        print('    %-12s %s' % (name, pal.ok(line) if str(part.get('status')).startswith('2') else pal.bad(line)))
        first = part.get('first') or part.get('shape') or part.get('body')
        if isinstance(first, dict):
            print(pal.dim('                 keys: %s' % ', '.join(list(first.keys())[:14])))
    if probe.get('error'):
        print('    ' + pal.bad(probe['error']))
    points = answer.get('access_points')
    if points:
        print()
        print(pal.group('  What the access points answer'))
        for name in sorted(points):
            part = points[name]
            if not isinstance(part, dict):
                continue
            if part.get('note'):
                print('    ' + pal.note(part['note']))
                continue
            if part.get('ok'):
                print('    %-14s %s' % (name, pal.ok('%s %s \u00b7 %s client(s), %s radio(s), %s network(s)%s'
                      % (part.get('model') or '', part.get('version') or '', part.get('clients'),
                         part.get('radios'), part.get('networks'),
                         (' \u00b7 %s C' % part['temperature']) if part.get('temperature') else ''))))
            else:
                print('    %-14s %s' % (name, pal.bad(part.get('error') or 'no answer')))
    if signin is not None and signin.get('skipped'):
        print()
        print(pal.note('  Signing in: ' + signin['skipped']))
    elif signin is not None:
        print()
        print(pal.group('  What it answers to signing in'))
        if signin.get('error'):
            print('    ' + pal.bad(signin['error']))
        if signin.get('waiting_for'):
            print('    ' + pal.warn('locked out for another %s (%s refusal(s) in a row)'
                                    % (human_age(signin['waiting_for']), signin.get('refusals_in_a_row'))))
        print('    %-12s %s' % ('user', signin.get('username')))
        for path in ('/api/auth/login', '/api/login'):
            part = signin.get(path)
            if not isinstance(part, dict):
                continue
            line = 'HTTP %s' % part.get('status')
            print('    %-12s %s' % (path, pal.ok(line) if str(part.get('status')).startswith('2') else pal.bad(line)))
            for name, value in part.items():
                if name != 'status':
                    print(pal.dim('                 %s: %s' % (name, value)))
        if isinstance(signin.get('clients_read'), dict):
            print('    %-12s HTTP %s, %s client(s)' % ('reading them', signin['clients_read'].get('status'),
                                                       signin['clients_read'].get('count')))
    print()
    return 0


def cmd_wifi(args, pal):
    """Everything the controller will say, on one screen."""
    status_code, first = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % first.get('error')))
        return 2
    cfg = first.get('wifi_config') or {}
    if not cfg.get('enabled'):
        print(pal.note('the controller is switched off; set it up under Control \u2192 Presence'))
        return 1
    print(pal.note('asking %s\u2026' % (cfg.get('host') or 'the controller')))
    token = read_token()
    code, answer = api_call('/api/wifi/dump', timeout=90.0, token=token)
    if code != 200:
        print(pal.bad('the daemon refused: %s' % (answer.get('error') or code)))
        return 2
    if not answer.get('ok'):
        print(pal.bad('the controller did not answer: %s' % (answer.get('error') or 'unknown')))
    wifi = answer.get('wifi') or {}
    if args.json:
        print(json.dumps(wifi, indent=2, ensure_ascii=False))
        return 0

    counts = wifi.get('counts') or {}
    controller = wifi.get('controller') or {}
    print()
    print(pal.title('  %s' % (cfg.get('host') or 'controller')) +
          pal.dim('   %s' % ' \u00b7 '.join(filter(None, [controller.get('name'),
                                                     'v' + controller['version'] if controller.get('version') else '',
                                                     {'key': 'read with an API key',
                                                      'signin': 'read by signing in'}.get(
                                                          wifi.get('read_with'), 'read with an API key')]))))
    summary = [('on Wi-Fi', counts.get('wifi')), ('on a cable', counts.get('wired')),
               ('guests', counts.get('guests')), ('over VPN', counts.get('vpn')),
               ('access points', counts.get('aps')), ('networks', counts.get('ssids')),
               ('others on the air', counts.get('neighbours'))]
    line = '   '.join('%s %s' % (pal.value(v), pal.dim(k)) for k, v in summary if v)
    print('  ' + line)
    if counts.get('bands'):
        print('  ' + '   '.join('%s %s' % (pal.value(v), pal.dim(b))
                                for b, v in sorted((counts.get('bands') or {}).items())))
    if counts.get('worst_signal') is not None:
        print('  ' + pal.dim('weakest client ') + signal_colour(pal, counts['worst_signal']))

    aps = wifi.get('aps') or []
    if aps:
        print()
        print(pal.group('  Access points'))
        rows = []
        for ap in aps:
            radios = ' '.join('%s/%s' % (r.get('band') or '?', r.get('channel') or '?')
                              for r in sorted(ap.get('radios') or [],
                                              key=lambda r: float(r.get('band') or 0)))
            ports = ap.get('ports') or {}
            rows.append([ap.get('name'), ap.get('model'), ap.get('ip'),
                         ap.get('clients'), ap.get('guests') or '', radios,
                         ('%s%%' % fmt_num(ap.get('cpu'))) if ap.get('cpu') is not None else '',
                         ('%s%%' % fmt_num(ap.get('memory'))) if ap.get('memory') is not None else '',
                         ('%s C' % fmt_num(ap.get('temperature'))) if ap.get('temperature') is not None else '',
                         human_age(ap['uptime']) if ap.get('uptime') else '',
                         _ports_text(ports), ap.get('uplink') or '',
                         ap.get('state') or ''])
        print_table(pal, ['NAME', 'MODEL', 'ADDRESS', 'CLIENTS', 'GUESTS', 'BAND/CH', 'CPU', 'MEM',
                          'TEMP', 'UPTIME', 'WIRED', 'THROUGH IT', 'STATE'],
                    rows, right=(3, 4, 6, 7, 8),
                    colour=lambda col, text, n: (pal.ok(text) if text != 'offline' else pal.bad(text)) if col == 12 else text)
        for ap in aps:
            radios = [r for r in sorted(ap.get('radios') or [], key=lambda r: float(r.get('band') or 0))
                      if r.get('utilization') is not None or r.get('width') is not None
                      or r.get('standard') or r.get('tx_retries') is not None]
            if not radios:
                continue
            print()
            bits = []
            if ap.get('board'):
                bits.append('board %s' % ap['board'])
            if ap.get('flash_wear') is not None:
                bits.append('flash worn %s%%' % ap['flash_wear'])
            if ap.get('boot_reason'):
                bits.append('last start %s' % str(ap['boot_reason']).lower().replace('_', ' '))
            if ap.get('ever_crashed'):
                bits.append('has crashed before')
            if ap.get('last_trouble'):
                bits.append('last trouble: %s' % ap['last_trouble'])
            print(pal.key('  %s' % ap.get('name')) + pal.dim('  ' + ' \u00b7 '.join(bits) if bits else '  radios'))
            print_table(pal, ['BAND', 'CHANNEL', 'WIDTH', 'CLIENTS', 'NETWORKS', 'AIRTIME',
                              'RETRIES', 'INTERFERENCE', 'TEMP', 'QUIETER GOING SPARE'],
                        [[('%s GHz' % r.get('band')) if r.get('band') else '',
                          ('%s%s' % (r.get('channel'), ' DFS' if r.get('dfs') else '')),
                          ('%s MHz' % r['width']) if r.get('width') else '',
                          r.get('clients'), r.get('networks'),
                          ('%s%%' % fmt_num(r['utilization'])) if r.get('utilization') is not None else '',
                          ('%s%%' % fmt_num(r['tx_retries'])) if r.get('tx_retries') is not None else '',
                          ('%s dBm' % fmt_num(r['interference'])) if r.get('interference') is not None else '',
                          ('%s C' % fmt_num(r['temperature'])) if r.get('temperature') is not None else '',
                          ', '.join('ch %s (%s%%)' % (q['channel'], fmt_num(q['busy']))
                                    for q in (r.get('quieter') or []))]
                         for r in radios], right=(3, 4, 5, 6, 8), indent=4,
                        colour=lambda col, text, n: (pal.warn(text) if 'DFS' in text else text)
                        if col == 1 else ((pal.ok(text) if text else text) if col == 9 else text))
            if any(r.get('dfs') for r in radios):
                print(pal.dim('    DFS: a radar channel. The point may be told to leave it without notice,'))
                print(pal.dim('    which takes the network with it and looks like a fault.'))

    ssids = wifi.get('ssids') or []
    if ssids:
        print()
        print(pal.group('  Networks'))
        print_table(pal, ['SSID', 'SECURITY', 'BANDS', 'ON', 'BROADCAST BY', 'JOINED', 'NOTES'],
                    [[x.get('name'), x.get('security') or '', (x.get('band') or '') and x['band'] + ' GHz',
                      (x.get('network') or '') + (' (VLAN %s)' % x['vlan'] if x.get('vlan') else ''),
                      x.get('on_aps') or '',
                      x.get('clients'),
                      ' '.join(filter(None, ['guest' if x.get('guest') else '',
                                             'hidden' if x.get('hidden') else '',
                                             'off' if x.get('enabled') is False else '',
                                             'seen on the air' if x.get('derived') else '']))]
                     for x in ssids], right=(5,))

    measured = [(ap, path) for ap in aps for path in (ap.get('paths') or [])]
    if measured:
        print()
        print(pal.group('  What the access points measure on their own way out'))
        print_table(pal, ['FROM', 'TO', 'ADDRESS', 'STATE', 'LATENCY', 'JITTER', 'LOSS'],
                    [[ap.get('name'), path.get('to'), (path.get('address') or '')[:34],
                      'reachable' if path.get('reachable') else 'unreachable',
                      ('%s ms' % path['latency_ms']) if path.get('latency_ms') is not None else '',
                      ('%s ms' % path['jitter_ms']) if path.get('jitter_ms') is not None else '',
                      ('%s%%' % path['loss_pct']) if path.get('loss_pct') is not None else '']
                     for ap, path in measured], right=(4, 5, 6),
                    colour=lambda col, text, n: (pal.ok(text) if text == 'reachable' else pal.warn(text))
                    if col == 3 else text)
        wired = [(ap, w) for ap in aps for w in (ap.get('wired_to') or []) if w.get('address')]
        if wired:
            print()
            print(pal.group('  What they are plugged into'))
            print_table(pal, ['ACCESS POINT', 'ITS PORT', 'NEIGHBOUR', 'ADDRESS'],
                        [[ap.get('name'), w.get('our_port'), w.get('mac'), w.get('address')]
                         for ap, w in wired])

    others = [n for n in (wifi.get('neighbours') or []) if not n.get('ours')]
    if others:
        print()
        print(pal.group('  Other networks on the air'))
        print_table(pal, ['SSID', 'BSSID', 'BAND', 'CH', 'WIDTH', 'SIGNAL', 'SECURITY', 'SEEN BY'],
                    [[n.get('ssid') or '(hidden)', n.get('bssid'),
                      ('%s GHz' % n['band']) if n.get('band') else '', n.get('channel'),
                      ('%s MHz' % n['width']) if n.get('width') else '',
                      n.get('signal'), (n.get('security') or '')[:28], n.get('seen_by') or '']
                     for n in others[:20]], right=(3, 5),
                    colour=lambda col, text, n: signal_colour(pal, numeric(text)) if col == 5 and text != '' else text)
        if len(others) > 20:
            print(pal.dim('    and %d more' % (len(others) - 20)))

    clients = wifi.get('clients') or []
    if clients:
        print()
        print(pal.group('  On the network'))
        people = {}
        for person in answer.get('people') or []:
            for mac in person.get('macs') or []:
                people[mac] = person['name']
        rows = []
        for c in sorted(clients, key=lambda c: (bool(c.get('wired')), str(c.get('name') or c.get('mac')).lower())):
            radio = ' '.join(filter(None, [c.get('technology') or '',
                                           ('%s GHz' % c['band']) if c.get('band') else '',
                                           ('ch %s' % c['channel']) if c.get('channel') else '']))
            if c.get('wired'):
                where = 'cable'
            elif c.get('kind') in ('VPN', 'TELEPORT'):
                where = str(c['kind']).lower()
            else:
                where = c.get('ssid') or 'Wi-Fi'
            if c.get('guest'):
                where += ' (guest)'
            # two names, two columns: the one somebody set, and the one the
            # device announces. Wedged together they made the column unreadable.
            shown = c.get('name') or c.get('hostname') or '(no name)'
            announced = c.get('hostname') if c.get('hostname') != c.get('name') else ''
            rows.append([shown, announced or '', c.get('mac'), c.get('ip'), where,
                         c.get('ap_name') or '', radio,
                         c.get('signal') if c.get('signal') is not None else '',
                         ('%s%%' % fmt_num(c['retry_pct'])) if c.get('retry_pct') is not None else '',
                         ('%ss' % int(c['idle'])) if c.get('idle') is not None else '',
                         human_age(c['uptime']) if c.get('uptime') else '',
                         people.get(c.get('mac'), '')])
        print_table(pal, ['DEVICE', 'CALLS ITSELF', 'MAC', 'ADDRESS', 'NETWORK', 'ACCESS POINT',
                          'RADIO', 'SIGNAL', 'RETRIES', 'IDLE', 'FOR', 'WHOSE'],
                    rows, right=(7, 8, 9),
                    colour=lambda col, text, n: (
                        pal.dim(text) if col == 1 else
                        (signal_colour(pal, numeric(text)) if col == 7 and text != '' else
                         (retry_colour(pal, text) if col == 8 and text != '' else
                          (pal.ok(text) if col == 11 and text else text)))))
    if wifi.get('fell_back'):
        print()
        print(pal.bad('  The sign-in failed, so this is the API key talking: %s' % wifi['fell_back']))
    ssh = wifi.get('ssh') or {}
    if ssh.get('trouble'):
        print()
        for name, why in sorted(ssh['trouble'].items()):
            print(pal.bad('  %s did not answer over SSH: %s' % (name, why)))
    if wifi.get('read_with') == 'key' and not wifi.get('knows_ssid') and not ssh.get('used'):
        print()
        print(pal.note('  An API key does not say which network a client is joined to, nor its'))
        print(pal.note('  signal or channel. Switch on "Read them over SSH" under Control \u2192 Presence'))
        print(pal.note('  and the access points will fill all of it in.'))
    print()
    return 0


def _ports_text(ports):
    """The wired side of an access point, in a few characters."""
    if not ports or not ports.get('count'):
        return ''
    speed = ports.get('speed') or ports.get('max_speed')
    text = ('%s Mbps' % speed) if speed else ('%d port%s' % (ports['count'], '' if ports['count'] == 1 else 's'))
    if ports.get('up') is not None and ports['count'] > 1:
        text += ' (%d/%d up)' % (ports['up'], ports['count'])
    return text


def retry_colour(pal, text):
    """How hard a client is working to be heard. Above a tenth of its frames
    going out twice is a client in trouble, whatever its signal says."""
    value = numeric(str(text).rstrip('%'))
    if value is None:
        return text
    if value >= 15:
        return pal.bad(text)
    return pal.warn(text) if value >= 8 else pal.ok(text)


def signal_colour(pal, dbm):
    if dbm is None:
        return ''
    text = '%s dBm' % int(dbm)
    if dbm >= -60:
        return pal.ok(text)
    return pal.warn(text) if dbm >= -75 else pal.bad(text)


def fmt_num(value):
    value = numeric(value)
    if value is None:
        return ''
    return ('%.1f' % value).rstrip('0').rstrip('.')


def cmd_monthly(args, pal):
    """What last month drank, and who drank it."""
    status_code, out = api_call('/api/energy/monthly', method='POST',
                                payload={'pin': CONFIG.get('pin') or ''})
    if status_code != 200:
        print(pal.crit('could not ask the daemon: %s' % out.get('error')))
        return 2
    print(out.get('text') or '(nothing to report)')
    return 0


def cmd_presence(args, pal):
    """Who is in, and the devices that say so."""
    status_code, st = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % st.get('error')))
        return 2
    pres = st.get('presence') or {}
    wifi = pres.get('wifi') or {}
    if args.json:
        print(json.dumps(pres, indent=2, ensure_ascii=False))
        return 0
    if not wifi.get('enabled'):
        print(pal.note('the controller is switched off; set it up under Control \u2192 Presence'))
    elif wifi.get('ok') is False:
        print(pal.bad('the controller is not answering: %s' % (wifi.get('error') or '')))
    else:
        print(pal.note('%s on Wi-Fi, %s clients in all, checked %s'
                       % (wifi.get('wifi_clients'), wifi.get('clients'),
                          human_age(time.time() - wifi['checked']) + ' ago' if wifi.get('checked') else 'never')))
    people = pres.get('people') or []
    if not people:
        print(pal.note('nobody set up yet'))
        return 0
    table = [[p['name'], 'in' if p['home'] else 'out',
              p.get('device') or '',
              human_age(time.time() - p['last_seen']) + ' ago' if p.get('last_seen') else 'never',
              ', '.join(p.get('macs') or [])] for p in people]
    print_table(pal, ['WHO', 'WHERE', 'SEEN AS', 'LAST SEEN', 'DEVICES'], table,
                colour=lambda col, text, n: (pal.ok(text) if people[n]['home'] else pal.warn(text)) if col == 1 else text)
    print()
    print(pal.bold('the house is %s' % ('occupied' if pres.get('anyone_home') else 'empty')))
    return 0


def cmd_map(args, pal):
    """Force a network-map scan and show the result."""
    print(pal.note('scanning the mesh - this walks every router, give it a moment'))
    status_code, out = api_call('/api/networkmap/refresh', timeout=120)
    if status_code != 200:
        print(pal.bad('the daemon did not answer (%s)' % status_code))
        return 1
    if not out.get('ok'):
        print(pal.warn(out.get('error') or 'the scan did not finish'))
    else:
        print(pal.ok('map updated in %.1fs' % out.get('seconds', 0)))
    status_code, status = api_call('/api/status')
    if status_code != 200:
        return 0 if out.get('ok') else 1
    children = {}
    for dev in status.get('devices') or []:
        via = dev.get('via') or {}
        if via.get('name'):
            children.setdefault(via['name'], []).append((dev['name'], via.get('lqi'), via.get('relation')))
    if not children:
        print(pal.note('no relations reported yet'))
    for parent in sorted(children):
        print('\n' + pal.title(parent))
        for name, lqi, relation in sorted(children[parent]):
            note = 'LQI %s' % (lqi if lqi is not None else '?')
            if relation == 'neighbour':
                note += ' (neighbour)'
            print('  %s %s  %s' % (pal.dim('\u2514'), name, pal.note(note)))
    return 0 if out.get('ok') else 1


def gateway_main(argv, pal):
    """zigmon gateway [name] <command> - read a Zigbee gateway (e.g. an
    SLZB-06) over the network: its own uptime, temperature, network and
    socket state, on top of what Zigbee2MQTT already reports about it."""
    import argparse as _argparse
    p = _argparse.ArgumentParser(prog='zigmon gateway', add_help=True,
        description='Poll a Zigbee gateway\'s own HTTP API (SLZB-06 / SLZB-OS: '
                    '/ha_info, /ha_sensors and /metrics) once and print what it returns.',
        epilog="""
examples
  zigmon gateway Router dump          both endpoints, raw JSON, as the device sent them
  zigmon gateway Router info          just /ha_info
  zigmon gateway Router sensors       just /ha_sensors
  zigmon gateway --host 192.168.1.51 dump   a device not (yet) in config.json

Run this after adding a "zigbee_gateways" entry to config.json to see exactly
what fields your firmware returns - field names can vary by version, and
zigmon keeps whatever it gets under a "gw." prefix regardless of the names.
""", formatter_class=_argparse.RawDescriptionHelpFormatter)
    p.add_argument('name', nargs='?', help='the gateway\'s "name" in config.json')
    p.add_argument('command', choices=['info', 'sensors', 'metrics', 'dump'], default='dump', nargs='?')
    p.add_argument('--host', metavar='ADDR', help='talk to this address instead of looking the name up')
    p.add_argument('--username', metavar='USER', help='HTTP Basic Auth user, if SLZB-OS "web server authentication" is on')
    p.add_argument('--password', metavar='PASS', help='HTTP Basic Auth password')
    p.add_argument('--json', action='store_true', help='raw JSON, no formatting')
    args = p.parse_args(argv)
    load_config()
    for problem in CONFIG_FATAL:
        sys.stderr.write('CONFIG: %s\n' % problem)
    host = args.host
    name = args.name
    username, password = args.username or '', args.password or ''
    if not host:
        # ask the running daemon first - it knows the config.json entries
        # AND anything added on the dashboard, with its stored password
        gateways = {}
        status_code, data = api_call('/api/status')
        if status_code == 200:
            for g in data.get('gateways') or []:
                gateways[g['name']] = g
        if name and name in gateways:
            host = gateways[name]['host']
            if not username:
                username = gateways[name].get('username') or ''
            if not password and gateways[name].get('password_set') and gateways[name].get('source') == 'ui':
                # the status API never returns a stored password (by design) -
                # for a dashboard-added gateway, read it straight from the
                # database the daemon already uses, on this same machine
                try:
                    store = Storage()
                    for g in json.loads(store.get_meta('gateways') or '[]'):
                        if isinstance(g, dict) and g.get('name') == name:
                            password = g.get('password') or ''
                            break
                except Exception:
                    pass
        else:
            configured = {g['name']: g for g in (CONFIG.get('zigbee_gateways') or []) if isinstance(g, dict)}
            if name and name in configured:
                host = configured[name]['host']
                username = username or configured[name].get('username') or ''
                password = password or configured[name].get('password') or ''
            elif not name and len(configured) == 1:
                host = list(configured.values())[0]['host']
                name = list(configured.keys())[0]
            else:
                known = sorted(set(gateways) | set(configured))
                sys.stderr.write('Name a configured gateway, or pass --host.\n'
                                 '  Configured: %s\n' % (', '.join(known) or '(none)'))
                return 2
    d = Daemon.__new__(Daemon)   # a bare instance: only gateway_fetch is used, nothing else touched
    # the SLZB and Shelly paths look nothing alike; ask the daemon which this
    # one is if it already knows (saved from a prior Detect), else try SLZB
    # first and fall back to Shelly RPC, same as the background poller does
    known_kind = ''
    status_code2, data2 = api_call('/api/status')
    if status_code2 == 200:
        for g in data2.get('gateways') or []:
            if g.get('name') == name or g.get('host') == host:
                known_kind = g.get('kind') or ''
                break
    slzb_paths = {'info': ['/ha_info'], 'sensors': ['/ha_sensors'], 'metrics': ['/metrics'],
                  'dump': ['/ha_info', '/ha_sensors', '/metrics']}[args.command]
    shelly_methods = {'info': ['Shelly.GetDeviceInfo'], 'sensors': ['Shelly.GetStatus'],
                      'metrics': ['Zigbee.GetStatus', 'Zigbee.GetConfig'],
                      'dump': ['Shelly.GetDeviceInfo', 'Shelly.GetStatus', 'Zigbee.GetStatus', 'Zigbee.GetConfig']}[args.command]
    ok_any = False
    header_shown = False

    def show(source_label, data):
        nonlocal header_shown
        if args.json:
            print(json.dumps({source_label: data}, indent=1))
            return
        if not header_shown:
            print(pal.title(name or host) + pal.note('  ' + host))
            header_shown = True
        flat = flatten(data)
        if not flat:
            return
        print('\n' + pal.group('-- %s ' % source_label) + pal.rule('-' * max(1, 74 - len(source_label))))
        shelly_print_flat(pal, flat)

    if known_kind == 'shelly':
        try:
            rpc = ShellyRPC(host, password, 0, label=name or host)
            for method in shelly_methods:
                try:
                    show(method, rpc.call(method) or {})
                    ok_any = True
                except PlugError as e:
                    print(pal.warn('%s: %s' % (method, e)))
        except Exception as e:
            print(pal.warn(str(e)))
        return 0 if ok_any else 1

    paths = slzb_paths
    ok_any = False
    for path in paths:
        try:
            data = Daemon.gateway_fetch(d, host, path, timeout=6.0, username=username, password=password)
        except Exception as e:
            print(pal.warn('%s: %s' % (path, e)))
            continue
        ok_any = True
        show(path, data)
    if not ok_any and not known_kind:
        # not an SLZB-style box after all - try it as a Shelly with the Zigbee component
        try:
            rpc = ShellyRPC(host, password, 0, label=name or host)
            for method in shelly_methods:
                try:
                    show(method, rpc.call(method) or {})
                    ok_any = True
                except PlugError as e:
                    print(pal.warn('%s: %s' % (method, e)))
        except Exception as e:
            print(pal.warn(str(e)))
    return 0 if ok_any else 1


def shelly_main(argv, pal):
    """zigmon shelly [name] <command> - the whole toolkit, addressed by name."""
    arguments = list(argv)

    # The global options are accepted anywhere. argparse lets a subcommand's
    # defaults overwrite what was given before it, so they are taken off by
    # hand first and put back after parsing.
    globals_ = {'host': None, 'password': None, 'switch_id': None, 'json': False, 'no_color': False}
    cleaned = []
    skip = False
    for index, value in enumerate(arguments):
        if skip:
            skip = False
            continue
        if value in ('--host', '--password', '--switch-id') and index + 1 < len(arguments):
            key = value.lstrip('-').replace('-', '_')
            globals_[key] = arguments[index + 1]
            skip = True
            continue
        if value.startswith('--host='):
            globals_['host'] = value.split('=', 1)[1]
            continue
        if value.startswith('--password='):
            globals_['password'] = value.split('=', 1)[1]
            continue
        if value == '--json':
            globals_['json'] = True
            continue
        if value == '--no-color':
            globals_['no_color'] = True
            continue
        cleaned.append(value)
    arguments = cleaned

    # The device name comes before the command, which subparsers cannot
    # express. Take it off the front first; everything after is ordinary.
    targets = shelly_targets()
    names = {n.lower(): n for n in targets}
    commands = ('discover', 'info', 'dump', 'methods', 'config', 'poll', 'watch', 'listen', 'serve',
                'on', 'off', 'toggle', 'reset-counters', 'reboot', 'matter', 'ble', 'call')
    role = None
    for index, value in enumerate(arguments):
        if value.startswith('-'):
            continue
        if value.lower() in names:
            role = names[value.lower()]
            arguments.pop(index)
        elif value not in commands and not globals_['host'] and value not in ('-h', '--help'):
            print(pal.bad('ERROR: ') + 'unknown device "%s"' % value, file=sys.stderr)
            print(pal.note('  configured: %s' % (', '.join(targets) or 'none')
                           + '; or give --host ADDR'), file=sys.stderr)
            return 2
        break
    if role is None and not globals_['host'] and targets:
        role = list(targets)[0]

    parser = shelly_build_parser()
    args = parser.parse_args(arguments)
    args.device = role
    args.host = globals_['host']
    args.password = globals_['password']
    args.switch_id = int(globals_['switch_id'] or 0)
    args.json = globals_['json']
    args.no_color = globals_['no_color']
    if not args.command:
        parser.print_help()
        return 0
    if args.no_color:
        pal = Palette(False)

    handler = {
        'discover': shelly_cmd_discover, 'info': shelly_cmd_info,
        'dump': shelly_cmd_dump, 'methods': shelly_cmd_methods,
        'config': shelly_cmd_config, 'poll': shelly_cmd_poll,
        'watch': shelly_cmd_watch, 'listen': shelly_cmd_listen,
        'serve': shelly_cmd_serve, 'on': shelly_cmd_switch,
        'off': shelly_cmd_switch, 'toggle': shelly_cmd_switch,
        'reset-counters': shelly_cmd_reset, 'call': shelly_cmd_call,
        'reboot': shelly_cmd_reboot, 'ble': shelly_cmd_radio,
        'matter': shelly_cmd_radio,
    }[args.command]

    try:
        return handler(args, pal)
    except PlugError as e:
        print(pal.bad('ERROR: ') + str(e), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print('\nstopped.')
        return 0


def shelly_cmd_discover(args, pal):
    print(pal.note('asking the network for Shelly devices, %.0fs...' % args.seconds))
    found = shelly_discover(pal, args.seconds)
    if args.json:
        print(json.dumps(list(found.values()), indent=2))
        return 0
    if not found:
        print(pal.warn('nothing answered'))
        for line in discovery_diagnosis(pal):
            print(line)
        print()
        print(pal.note('  Nothing here depends on discovery. Give the address '
                       'directly and everything else works:'))
        print(pal.note('    zigmon shelly --host 172.16.16.12 info'))
        print(pal.note('  or add it under "plugs" in %s.' % CONFIG_FILE))
        return 1
    for entry in sorted(found.values(), key=lambda e: e['ip']):
        line = '  %s  %s' % (pal.value(entry['ip'].ljust(15)),
                             pal.note(', '.join(entry['names'])))
        if entry.get('via'):
            line += pal.note('  (relayed by %s)' % entry['via'])
        print(line)
    print(pal.note('  %d device(s)' % len(found)))
    return 0


def discovery_diagnosis(pal):
    """Why an empty result is usually the local machine's own doing.

    On a stock AlmaLinux 9 the firewall drops inbound multicast DNS until the
    service is allowed, and a reply to a multicast query is not something
    connection tracking will let back in on its own. That is the first thing to
    check, and the tool can check it rather than leaving it to guesswork.
    """
    lines = []

    interfaces = getattr(shelly_discover, 'interfaces', [])
    if interfaces:
        lines.append(pal.note('  The query went out of %d interface(s): %s'
                              % (len(interfaces),
                                 ', '.join('%s (%s)' % (n, a) for n, a in interfaces))))
        if len(interfaces) == 1:
            lines.append(pal.note('    If the device is reached through a VLAN '
                                  'this machine has no address on, only a proxy '
                                  'can carry the query there.'))
    joined = getattr(shelly_discover, 'joined', 0)
    if not joined:
        lines.append(pal.warn('  Could not join the multicast group on port 5353.'))
        lines.append(pal.note('    Only a unicast reply can reach us, and an '
                              'avahi reflector does not forward those - it '
                              'repeats multicast between interfaces and nothing '
                              'else. Check what holds the port:'))
        lines.append(pal.key('      ss -lunp | grep 5353'))
    else:
        lines.append(pal.note('  Joined the multicast group on %d interface(s), '
                              'and asked for both a unicast and a multicast '
                              'answer.' % joined))
        lines.append(pal.note('    A reflector can only carry the multicast one, '
                              'so that path is covered.'))

    blocked = firewalld_blocks_mdns()
    if blocked is True:
        lines.append(pal.bad('  firewalld is running and mDNS is not allowed in '
                             'the active zone.'))
        lines.append(pal.note('    Replies to a multicast query are dropped, '
                              'because connection tracking has nothing to match '
                              'them against. Allow the service:'))
        lines.append(pal.key('      sudo firewall-cmd --permanent --add-service=mdns'))
        lines.append(pal.key('      sudo firewall-cmd --reload'))
    elif blocked is False:
        lines.append(pal.ok('  firewalld allows mDNS, so the firewall is not the '
                            'problem here.'))
    else:
        lines.extend(iptables_diagnosis(pal))

    lines.append(pal.note('  Multicast DNS does not cross subnets on its own. A '
                          'proxy or repeater between VLANs forwards it, but many '
                          'forward only the query and not the reply.'))
    if shutil.which('avahi-browse'):
        lines.append(pal.note('  avahi is installed here, so it can be asked the '
                              'same question independently:'))
        lines.append(pal.key('      avahi-browse -art | grep -i shelly'))
        lines.append(pal.note('    If that finds nothing either, the replies are '
                              'not reaching this machine at all and the cause is '
                              'in the network, not here.'))
    lines.append(pal.note('  Strict reverse-path filtering also drops replies '
                          'that arrive from another VLAN. Check with:'))
    lines.append(pal.key('      sysctl net.ipv4.conf.all.rp_filter'))
    lines.append(pal.note('    2 (loose) or 0 tolerates it; 1 (strict) will not.'))
    return lines


def iptables_diagnosis(pal):
    """The same question for a machine running iptables directly.

    Two rules are needed, not one. Answers arrive at port 5353 when we hold it,
    and at whatever port the query went out from when avahi already has 5353 -
    the unicast-response bit is what makes that second case work, and it needs
    a rule of its own because connection tracking will not match a reply to a
    multicast destination.
    """
    import subprocess
    lines = []
    try:
        rules = subprocess.run(['iptables', '-S', 'INPUT'],
                               capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return lines
    if rules.returncode != 0:
        if 'permission' in (rules.stderr or '').lower():
            lines.append(pal.note('  Run as root to have the firewall checked '
                                  'as well.'))
        return lines

    text = rules.stdout
    # A chain whose policy is ACCEPT but which ends in a catch-all REJECT is
    # every bit as closed as one with a DROP policy. Looking only at the policy
    # was wrong.
    policy_drops = any(line.startswith('-P INPUT') and 'ACCEPT' not in line
                       for line in text.split('\n'))
    catch_all = any(('-j REJECT' in line or '-j DROP' in line)
                    and '-p ' not in line and '--dport' not in line
                    for line in text.split('\n'))
    policy_drops = policy_drops or catch_all
    accepts_5353 = any('5353' in line and '-j ACCEPT' in line
                       for line in text.split('\n'))
    accepts_group = any('224.0.0.251' in line and '-j ACCEPT' in line
                        for line in text.split('\n'))

    if not policy_drops:
        lines.append(pal.ok('  iptables accepts by default, so the firewall is '
                            'not blocking this.'))
        return lines
    if accepts_5353:
        lines.append(pal.ok('  iptables already allows mDNS both ways, so the '
                            'firewall is not the problem.'))
        return lines

    if accepts_group:
        lines.append(pal.warn('  iptables allows the multicast group but not a '
                              'unicast reply.'))
        lines.append(pal.note('    A proxy answers from port 5353 to whatever '
                              'port the query went out from, which the existing '
                              'rule does not cover. Add:'))
        lines.append(pal.key('      iptables -I INPUT -p udp --sport 5353 -j ACCEPT'))
    else:
        lines.append(pal.bad('  iptables drops by default and nothing allows mDNS.'))
        lines.append(pal.note('    Two rules, because answers arrive two ways:'))
        lines.append(pal.key('      iptables -I INPUT -p udp --dport 5353 -j ACCEPT'))
        lines.append(pal.note('        replies to the multicast group, when we '
                              'hold port 5353'))
        lines.append(pal.key('      iptables -I INPUT -p udp --sport 5353 -j ACCEPT'))
        lines.append(pal.note('        unicast replies to a temporary port, which '
                              'is what a proxy sends and what avahi leaves us with'))

    lines.append(pal.note('    Then make it survive a reboot:'))
    lines.append(pal.key('      service iptables save'))
    lines.append(pal.note('        or iptables-save > /etc/sysconfig/iptables'))
    return lines


def firewalld_blocks_mdns():
    """True, False, or None when firewalld is not running or not installed."""
    import subprocess
    try:
        state = subprocess.run(['firewall-cmd', '--state'],
                               capture_output=True, text=True, timeout=5)
        if state.returncode != 0:
            return None
        allowed = subprocess.run(['firewall-cmd', '--query-service=mdns'],
                                 capture_output=True, text=True, timeout=5)
        if 'yes' in allowed.stdout:
            return False
        ports = subprocess.run(['firewall-cmd', '--list-ports'],
                               capture_output=True, text=True, timeout=5)
        return '5353/udp' not in ports.stdout
    except (OSError, subprocess.SubprocessError):
        return None


def shelly_cmd_info(args, pal):
    rpc = shelly_for(args.device, args)
    info = rpc.call('Shelly.GetDeviceInfo')
    if args.json:
        print(json.dumps(info, indent=2))
        return 0
    shelly_print_flat(pal, flatten(info), '  %s' % rpc.host)
    return 0


def shelly_cmd_dump(args, pal):
    rpc = shelly_for(args.device, args)
    everything = shelly_everything(rpc)
    if not everything:
        raise PlugError('the device answered nothing we recognise')
    if args.json:
        print(json.dumps(everything, indent=2))
        return 0
    info = everything.get('Shelly.GetDeviceInfo', {})
    bar = '=' * 78
    print(pal.rule(bar))
    print('  ' + pal.title('%s  %s' % (info.get('model', args.device or rpc.host),
                                       info.get('name', ''))))
    print('  ' + pal.note('zigmon v%s   |   %s   |   firmware %s   |   %s'
                          % (__version__, rpc.host, info.get('ver', '?'),
                             datetime.now().strftime('%Y-%m-%d %H:%M:%S'))))
    print(pal.rule(bar))
    for method in sorted(everything):
        flat = flatten(everything[method])
        if not flat:
            continue
        print('\n' + pal.group('-- %s ' % method)
              + pal.rule('-' * max(1, 74 - len(method))))
        shelly_print_flat(pal, flat)
    print('\n' + pal.rule(bar))
    return 0


# What a live table should show first. Timestamps and component ids are
# numbers too, and picking those over the actual measurements made the poll
# output useless.
POLL_PREFERRED = ['apower', 'voltage', 'current', 'pf', 'freq', 'aenergy.total',
                  'ret_aenergy.total', 'temperature.tC', 'tC', 'rh',
                  'battery.percent', 'battery.V', 'wifi.rssi', 'sys.uptime']
POLL_SKIP = re.compile(r'(_ts$|\.id$|^id$|minute_ts|\.0$|ram_|fs_)')


def shelly_numeric(flat):
    numeric = [k for k, v in flat.items()
               if isinstance(v, (int, float)) and not isinstance(v, bool)
               and not POLL_SKIP.search(k)]
    def rank(key):
        tail = re.sub(r'^[a-z_0-9]+:\d+\.', '', key)
        for index, wanted in enumerate(POLL_PREFERRED):
            if tail == wanted:
                return (0, index)
        return (1, key)
    return sorted(numeric, key=rank)


def shelly_cmd_methods(args, pal):
    """Everything this device will answer, straight from the device."""
    rpc = shelly_for(args.device, args)
    try:
        result = rpc.call('Shelly.ListMethods')
    except PlugError as e:
        if is_missing_component(e):
            raise PlugError('this device does not publish a method list; it is '
                            'probably older than Gen2 firmware 0.14')
        raise
    methods = sorted((result or {}).get('methods', []))
    if args.component:
        wanted = args.component.lower().rstrip('.')
        methods = [m for m in methods if m.split('.')[0].lower() == wanted]
        if not methods:
            print(pal.warn('no component called "%s" on this device'
                           % args.component))
            return 1

    if args.json:
        if args.described:
            print(json.dumps({m: {'description': RPC_METHODS[m][0],
                                  'example': RPC_METHODS[m][1]}
                              for m in methods if m in RPC_METHODS}, indent=2))
        else:
            print(json.dumps(methods, indent=2))
        return 0
    if not methods:
        print(pal.warn('the device returned an empty list'))
        return 1

    groups = {}
    for method in methods:
        groups.setdefault(method.split('.')[0], []).append(method)

    described = 0
    for component in sorted(groups):
        note = RPC_COMPONENTS.get(component, '')
        heading = '-- %s ' % component
        print('\n' + pal.group(heading) + pal.rule('-' * max(1, 70 - len(heading))))
        if note:
            print('  ' + pal.note(note))
        for method in groups[component]:
            entry = RPC_METHODS.get(method)
            if not entry and args.described:
                continue
            print('  ' + pal.value(method))
            if entry:
                described += 1
                print('      ' + pal.note(entry[0]))
                if entry[1] and args.examples:
                    print('      ' + pal.key('zigmon shelly %s call %s %s'
                                             % (args.device or 'NAME', method,
                                                shell_quote(entry[1]))))
                elif not entry[1] and args.examples:
                    print('      ' + pal.key('zigmon shelly %s call %s'
                                             % (args.device or 'NAME', method)))

    print('\n' + pal.rule('=' * 74))
    print(pal.note('  %d method(s) across %d component(s); %d of them described '
                   'here.' % (len(methods), len(groups), described)))
    if not args.examples:
        print(pal.note('  --examples adds a ready-made call for each one, '
                       '--described hides the rest.'))
    print(pal.note('  Anything listed can be used with "call", described or not.'))
    return 0


def shell_quote(text):
    """Quote a JSON argument for a shell, or leave it for cmd.exe to mangle."""
    if os.name == 'nt':
        return '"' + text.replace('"', '\\"') + '"'
    return "'" + text + "'"


def shelly_cmd_config(args, pal):
    """Read a configuration, or write one and check it took."""
    rpc = shelly_for(args.device, args)

    if not args.component:
        config = rpc.call('Shelly.GetConfig')
        if args.json:
            print(json.dumps(config, indent=2))
            return 0
        flat = flatten(config)
        for component in sorted({k.split('.')[0] for k in flat}):
            section = {k: v for k, v in flat.items()
                       if k == component or k.startswith(component + '.')}
            print('\n' + pal.group('-- %s ' % component)
                  + pal.rule('-' * max(1, 70 - len(component))))
            shelly_print_flat(pal, section)
        print('\n' + pal.note('  %d setting(s). Give a component to narrow it, '
                              'and a JSON object to change it.' % len(flat)))
        return 0

    # Reading one component: Switch.GetConfig wants an id, Sys.GetConfig does not.
    component = args.component
    name, _, index = component.partition(':')
    # Shelly method names are case-insensitive, but the canonical spelling
    # reads better in the output and some proxies are picky.
    canonical = {'ble': 'BLE', 'mqtt': 'MQTT', 'wifi': 'WiFi', 'kvs': 'KVS', 'ws': 'WS', 'http': 'HTTP',
                 'ui': 'UI', 'bthome': 'BTHome', 'pm1': 'PM1', 'em1': 'EM1', 'em': 'EM'}
    method_base = canonical.get(name.lower()) or (name[0].upper() + name[1:] if name.islower() else name)
    params = {'id': int(index)} if index.isdigit() else None

    if not args.settings:
        config = rpc.call('%s.GetConfig' % method_base, params)
        if args.json:
            print(json.dumps(config, indent=2))
            return 0
        shelly_print_flat(pal, flatten(config), '  %s' % component)
        return 0

    try:
        settings = json.loads(args.settings)
    except ValueError:
        raise PlugError('the settings must be a JSON object: %s' % args.settings)
    if not isinstance(settings, dict):
        raise PlugError('the settings must be a JSON object, not a %s'
                        % type(settings).__name__)

    before = flatten(rpc.call('%s.GetConfig' % method_base, params))
    write = dict(params or {})
    write['config'] = settings
    result = rpc.call('%s.SetConfig' % method_base, write)
    after = flatten(rpc.call('%s.GetConfig' % method_base, params))

    # Firmware accepts a whole config object and silently drops keys it does
    # not know, so say which ones actually changed rather than assuming.
    applied, ignored = [], []
    for key, wanted in flatten(settings).items():
        now = after.get(key)
        (applied if now == wanted else ignored).append(
            '%s=%s' % (key, now if now is not None else 'absent'))
    for key in applied:
        print(pal.ok('  set   ') + key)
    for key in ignored:
        print(pal.warn('  kept  ') + key
              + pal.note('  (the device did not take the new value)'))

    changed = [k for k in after if before.get(k) != after.get(k)]
    if not applied and not changed:
        print(pal.warn('  nothing changed'))
        return 1
    if (result or {}).get('restart_required') or args.reboot:
        if args.reboot:
            return shelly_cmd_reboot(args, pal)
        print(pal.note('  the device says a restart is needed: '
                       'zigmon shelly %s reboot --wait' % (args.device or 'NAME')))
    return 0


def shelly_cmd_poll(args, pal):
    rpc = shelly_for(args.device, args)
    import csv as csv_module
    handle = open(args.csv, 'a', newline='', encoding='utf-8') if args.csv else None
    writer = csv_module.writer(handle) if handle else None

    columns, printed, count = None, 0, 0
    try:
        while True:
            try:
                try:
                    status = rpc.call('Switch.GetStatus', {'id': rpc.switch_id})
                except PlugError as e:
                    if not is_missing_component(e):
                        raise
                    status = rpc.call('Shelly.GetStatus')
                flat = flatten(status)
            except PlugError as e:
                # A battery sensor is asleep most of the time; say so and retry
                # rather than giving up, which is what makes poll usable at all.
                print(pal.note('%s  %s' % (datetime.now().strftime('%H:%M:%S'), e)))
                time.sleep(args.interval)
                continue

            if columns is None:
                columns = shelly_numeric(flat)[:8]
                if writer and handle.tell() == 0:
                    writer.writerow(['timestamp'] + columns)
            if printed % 20 == 0:
                print(pal.group('  %-8s ' % 'time'
                                + ' '.join(c.rsplit('.', 1)[-1][:10].rjust(11)
                                           for c in columns)))
            print('  %-8s ' % datetime.now().strftime('%H:%M:%S')
                  + ' '.join(pal.value(('%g' % flat[c] if isinstance(flat.get(c), float)
                                        else str(flat.get(c, '-'))).rjust(11))
                             for c in columns))
            if writer:
                writer.writerow([datetime.now().isoformat(timespec='seconds')]
                                + [flat.get(c) for c in columns])
                handle.flush()
            printed += 1
            count += 1
            if args.count and count >= args.count:
                return 0
            time.sleep(args.interval)
    finally:
        if handle:
            handle.close()


def shelly_cmd_watch(args, pal):
    """Subscribe to the device's own notifications instead of polling."""
    import base64
    rpc = shelly_for(args.device, args)
    host = rpc.host.split(':')[0]
    port = int(rpc.host.split(':')[1]) if ':' in rpc.host else 80
    key = base64.b64encode(secrets.token_bytes(16)).decode()

    if rpc.password:
        print(pal.warn('this device has a password set. The websocket channel '
                       'does not carry that authentication - use poll instead.'))
        return 1

    try:
        sock = socket.create_connection((host, port), 10)
    except OSError as e:
        raise PlugError('cannot reach %s (%s)' % (rpc.host, e))
    request = ('GET /rpc HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\n'
               'Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n'
               'Sec-WebSocket-Version: 13\r\n\r\n' % (rpc.host, key))
    sock.sendall(request.encode())
    reply = b''
    while b'\r\n\r\n' not in reply:
        chunk = sock.recv(4096)
        if not chunk:
            raise PlugError('the device closed the connection during the handshake')
        reply += chunk
    if b'101' not in reply.split(b'\r\n')[0]:
        raise PlugError('the device refused the websocket upgrade')

    print(pal.note('connected to %s - press Ctrl+C to stop' % rpc.host))
    _ws_send(sock, json.dumps({'id': 1, 'src': 'zigmon',
                               'method': 'Shelly.GetStatus'}))
    try:
        for message in _ws_frames(sock):
            try:
                body = json.loads(message)
            except ValueError:
                continue
            payload = body.get('params') or body.get('result') or {}
            flat = flatten(payload)
            if not flat:
                continue
            stamp = datetime.now().strftime('%H:%M:%S')
            if args.json:
                print(json.dumps({'ts': stamp, 'data': payload}))
                continue
            print(pal.note('  ' + stamp) + '  ' + body.get('method', 'result'))
            shelly_print_flat(pal, flat)
    except (ConnectionError, OSError) as e:
        print(pal.warn('connection lost: %s' % e))
    finally:
        sock.close()
    return 0


def shelly_cmd_listen(args, pal):
    """Print webhook pushes as they arrive, without touching the database."""
    port = args.port or int(CONFIG['sensor_listen_port'])
    host = CONFIG['sensor_listen_host'] or '0.0.0.0'

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *ignored):
            pass

        def _show(self, payload):
            print('%s  %s  %s'
                  % (pal.note(datetime.now().strftime('%H:%M:%S')),
                     pal.info(self.client_address[0]), pal.value(payload)))
            self.send_response(200)
            self.send_header('Content-Length', '0')
            self.end_headers()

        def do_GET(self):
            query = parse_qs(urlparse(self.path).query)
            fields = {k: v[0] for k, v in query.items() if v}
            self._show(json.dumps(fields) if fields else self.path)

        def do_POST(self):
            length = int(self.headers.get('Content-Length') or 0)
            self._show(self.rfile.read(length).decode('utf-8', 'replace'))

    try:
        server = ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            running = 'the daemon is probably already listening there' \
                if port == int(CONFIG['sensor_listen_port']) \
                and CONFIG['sensor_listen'] else 'something else has that port'
            print(pal.bad('port %s on %s is already in use' % (port, host)))
            print(pal.note('  %s. Either stop it, or watch on a spare port and '
                           'point a webhook at that:' % running))
            print(pal.note('    zigmon shelly listen --port %d' % (port + 1)))
            return 1
        print(pal.bad('cannot listen on %s:%s - %s' % (host, port, e)))
        return 1
    print(pal.note('listening on http://%s:%s/ - point the sensor webhook here, '
                   'Ctrl+C to stop' % (host, port)))
    print(pal.note('nothing is recorded; this only shows what arrives. The daemon '
                   'stores pushes when sensor_listen is on.'))
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


def shelly_cmd_serve(args, pal):
    """Accept an outbound websocket from a device configured to call us."""
    import base64
    import hashlib
    port = args.port or 8089
    guid = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'

    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind(('0.0.0.0', port))
    except OSError as e:
        print(pal.bad('cannot listen on port %s - %s' % (port, e)))
        if e.errno == errno.EADDRINUSE:
            print(pal.note('  try another: zigmon shelly serve --port %d'
                           % (port + 1)))
        return 1
    listener.listen(4)
    print(pal.note('waiting for a device to connect to ws://<this-host>:%d/ - '
                   'Ctrl+C to stop' % port))
    try:
        while True:
            client, address = listener.accept()
            request = b''
            while b'\r\n\r\n' not in request:
                chunk = client.recv(4096)
                if not chunk:
                    break
                request += chunk
            match = re.search(rb'Sec-WebSocket-Key:\s*(\S+)', request, re.I)
            if not match:
                client.close()
                continue
            accept = base64.b64encode(
                hashlib.sha1(match.group(1) + guid.encode()).digest()).decode()
            client.sendall(('HTTP/1.1 101 Switching Protocols\r\n'
                            'Upgrade: websocket\r\nConnection: Upgrade\r\n'
                            'Sec-WebSocket-Accept: %s\r\n\r\n' % accept).encode())
            print(pal.ok('  connected: ') + address[0])
            try:
                for message in _ws_frames(client):
                    stamp = datetime.now().strftime('%H:%M:%S')
                    try:
                        body = json.loads(message)
                    except ValueError:
                        print('  %s  %s' % (pal.note(stamp), message))
                        continue
                    flat = flatten(body.get('params') or body)
                    print('  %s  %s' % (pal.note(stamp),
                                        body.get('method', 'message')))
                    shelly_print_flat(pal, flat)
            except (ConnectionError, OSError):
                pass
            finally:
                client.close()
                print(pal.note('  disconnected: %s' % address[0]))
    finally:
        listener.close()
    return 0


def shelly_cmd_switch(args, pal):
    rpc = shelly_for(args.device, args)
    switch_id = rpc.switch_id
    if args.command == 'toggle':
        rpc.call('Switch.Toggle', {'id': switch_id})
    else:
        rpc.call('Switch.Set', {'id': switch_id, 'on': args.command == 'on'})
    state = rpc.call('Switch.GetStatus', {'id': switch_id})
    on = bool(state.get('output'))
    print(pal.ok('  socket is ON') if on else pal.bad('  socket is OFF'))
    if state.get('apower') is not None:
        print(pal.note('  drawing %s W' % state['apower']))
    return 0


def shelly_cmd_reset(args, pal):
    """reset-counters [type ...] — no type means every counter the plug has."""
    rpc = shelly_for(args.device, args)
    switch_id = rpc.switch_id
    types = [t for arg in args.types for t in arg.split(',') if t]
    unknown = [t for t in types if t not in PLUG_COUNTER_TYPES]
    if unknown:
        print(pal.bad('  unknown counter: %s' % ', '.join(unknown)))
        print(pal.note('  choose from: %s' % ', '.join(PLUG_COUNTER_TYPES)))
        return 1

    rpc.reset_counters(types or None)
    state = rpc.call('Switch.GetStatus', {'id': switch_id})
    print(pal.ok('  reset %s' % (', '.join(types) if types else 'every counter')))
    flat = flatten(state)
    for key in ('aenergy.total', 'ret_aenergy.total', 'counts.on_time',
                'counts.switch_on', 'counts.on_above_thr'):
        if key in flat:
            print(pal.note('    %-22s %s' % (key, flat[key])))
    return 0


def shelly_cmd_call(args, pal):
    rpc = shelly_for(args.device, args)
    method = args.method
    params = None
    if args.params:
        try:
            params = json.loads(args.params)
        except ValueError:
            raise PlugError('the parameters must be JSON: %s' % args.params)
    result = rpc.call(method, params)
    if args.json or not isinstance(result, dict):
        print(json.dumps(result, indent=2))
        return 0
    shelly_print_flat(pal, flatten(result), '  %s' % method)
    return 0


def shelly_cmd_reboot(args, pal):
    rpc = shelly_for(args.device, args)
    rpc.call('Shelly.Reboot')
    print(pal.ok('  reboot requested'))
    # Called from ble/matter/config --reboot there is no --wait flag; those
    # want to check the result afterwards, so they wait.
    if not getattr(args, 'wait', True):
        return 0
    print(pal.note('  waiting for it to come back...'))
    deadline = time.time() + 60
    time.sleep(3)
    while time.time() < deadline:
        try:
            info = rpc.call('Shelly.GetDeviceInfo')
            print(pal.ok('  back after %ds' % int(60 - (deadline - time.time())))
                  + pal.note('  firmware %s' % info.get('ver')))
            return 0
        except PlugError:
            time.sleep(2)
    print(pal.warn('  it has not answered within 60s'))
    return 1


def is_missing_component(error):
    """Did the device say it does not have this, or did something else fail?"""
    text = str(error).lower()
    if 'rate limiting' in text or '429' in text or 'cannot reach' in text:
        return False
    return ('unknown method' in text or 'no handler' in text
            or '-105' in text or 'not found' in text or '404' in text)


def ble_report(rpc, pal):
    """Config and live status of the Bluetooth radio, with the reason it may still advertise."""
    config = rpc.call('BLE.GetConfig')
    enabled = bool(config.get('enable'))
    over_ble = bool((config.get('rpc') or {}).get('enable'))
    observer = (config.get('observer') or {}).get('enable')
    print('  %s is %s' % ('BLE', pal.ok('enabled') if enabled else pal.bad('disabled')))
    print('  %s is %s' % ('RPC over Bluetooth', pal.ok('enabled') if over_ble else pal.bad('disabled')))
    if observer is not None:
        print('  %s is %s' % ('BLE observer (BLU gateway)', pal.ok('enabled') if observer else pal.bad('disabled')))
    status = {}
    try:
        status = rpc.call('BLE.GetStatus') or {}
        shelly_print_flat(pal, flatten(status))
    except PlugError:
        pass
    flags = str(status.get('flags') or '')
    advertising = 'advertising' in flags
    if advertising and not enabled:
        print(pal.warn('  the radio is still advertising although BLE is disabled:'))
        # A change to ble.enable only takes effect after a restart.
        print(pal.note('    - the setting takes effect after a reboot: zigmon shelly %s reboot --wait'
                       % (getattr(rpc, 'role', None) or 'NAME')))
        # Matter commissioning keeps its own BLE beacon on until the device is
        # commissioned, whatever ble.enable says.
        try:
            mconf = rpc.call('Matter.GetConfig') or {}
            mstat = rpc.call('Matter.GetStatus') or {}
            if mconf.get('enable') and not (mstat.get('num_fabrics') or 0):
                print(pal.note('    - Matter is enabled and the device is not commissioned, so it keeps '
                               'advertising for a Matter controller regardless of the BLE switch.'))
                print(pal.note('      Turn it off too: zigmon shelly %s matter off --reboot'
                               % (getattr(rpc, 'role', None) or 'NAME')))
        except PlugError:
            pass
    return enabled, over_ble, advertising


def shelly_cmd_radio(args, pal):
    """ble and matter: status, on, off - both are a config flag plus a reboot."""
    rpc = shelly_for(args.device, args)
    rpc.role = args.device
    component = 'BLE' if args.command == 'ble' else 'Matter'
    action = (args.action or 'status').lower()

    if action == 'status':
        try:
            if component == 'BLE':
                ble_report(rpc, pal)
                return 0
            config = rpc.call('%s.GetConfig' % component)
        except PlugError as e:
            if is_missing_component(e):
                raise PlugError('%s is not available on this device' % component)
            raise
        enabled = bool(config.get('enable'))
        print('  %s is %s' % (component, pal.ok('enabled') if enabled else pal.bad('disabled')))
        try:
            shelly_print_flat(pal, flatten(rpc.call('%s.GetStatus' % component)))
        except PlugError:
            pass
        return 0

    if action == 'code':
        if component != 'Matter':
            raise PlugError('only matter has a pairing code')
        try:
            status = rpc.call('Matter.GetStatus')
        except PlugError as e:
            if is_missing_component(e):
                raise PlugError('this device does not support Matter')
            raise
        code = status.get('setup_code') or status.get('manual_pairing_code')
        payload = status.get('setup_payload') or status.get('qr_code')
        if not code and not payload:
            raise PlugError('the device did not return a pairing code. Matter has to be enabled '
                            'and the device not yet commissioned for one to exist.')
        if code:
            print('  manual pairing code : ' + pal.value(str(code)))
        if payload:
            print('  setup payload       : ' + pal.value(str(payload)))
        print(pal.note('  a controller needs one of these to commission the device'))
        return 0

    if action in ('rpc-on', 'rpc-off'):
        if component != 'BLE':
            raise PlugError('only ble has an rpc switch')
        rpc.call('BLE.SetConfig', {'config': {'rpc': {'enable': action == 'rpc-on'}}})
        config = rpc.call('BLE.GetConfig')
        settled = bool((config.get('rpc') or {}).get('enable'))
        if settled != (action == 'rpc-on'):
            print(pal.warn('  the device did not accept the change'))
            return 1
        print(pal.ok('  BLE RPC %s' % ('enabled' if settled else 'disabled')))
        if args.reboot:
            return shelly_cmd_reboot(args, pal)
        print(pal.note('  a reboot is needed for this to take effect: zigmon shelly %s reboot --wait'
                       % (args.device or 'NAME')))
        return 0

    if action not in ('on', 'off'):
        raise PlugError('use %s status, %s on or %s off' % (args.command, args.command, args.command))

    if component == 'BLE' and action == 'off':
        # Off means off: the radio, RPC over it, and the observer that scans
        # for BLU devices. Firmware without an observer ignores that key.
        rpc.call('BLE.SetConfig', {'config': {'enable': False, 'rpc': {'enable': False},
                                              'observer': {'enable': False}}})
    else:
        rpc.call('%s.SetConfig' % component, {'config': {'enable': action == 'on'}})
    config = rpc.call('%s.GetConfig' % component)
    settled = bool(config.get('enable'))
    if settled != (action == 'on'):
        print(pal.warn('  the device did not accept the change'))
        return 1
    print(pal.ok('  %s %s' % (component, 'enabled' if settled else 'disabled')))
    if args.reboot:
        rc = shelly_cmd_reboot(args, pal)
        if rc == 0 and component == 'BLE':
            print()
            _, _, advertising = ble_report(rpc, pal)
            if action == 'off' and advertising:
                return 1
        return rc
    print(pal.note('  a reboot is needed for this to take effect: zigmon shelly %s reboot --wait'
                   % (args.device or 'NAME')))
    if component == 'BLE' and action == 'off':
        try:
            mconf = rpc.call('Matter.GetConfig') or {}
            mstat = rpc.call('Matter.GetStatus') or {}
            if mconf.get('enable') and not (mstat.get('num_fabrics') or 0):
                print(pal.warn('  Matter is enabled and not commissioned: it will keep the BLE beacon on '
                               'even after the reboot. Turn it off too: zigmon shelly %s matter off --reboot'
                               % (args.device or 'NAME')))
        except PlugError:
            pass
    return 0


def build_parser():
    p = argparse.ArgumentParser(
        prog='zigmon',
        description='Zigbee2MQTT sensor monitor: daemon, history, localhost API (zigmon %s).' % __version__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Run with no arguments to start the daemon in the foreground - that is what the
systemd unit does. Everything else below is for testing and day-to-day use.

  zigmon --status                    every device with its latest readings
  zigmon --devices                   the device table (--json for machines)
  zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
  zigmon --events                    what the daemon has logged
  zigmon --watch                     live feed straight from the broker
  zigmon --watch --bridge --raw      including bridge/* topics, untruncated
  zigmon --permit-join on            open the Zigbee network for four minutes
  zigmon --plug                      every smart plug, live from the device
  zigmon --plug-on Lednice           switch a plug; also --plug-off, --plug-toggle
  zigmon --plug-pulse Lednice --ms 3000   flip it, hold 3 s, flip it back
  zigmon --plug-reset Lednice --types aenergy,switch_on
  zigmon --bindings                  which button action drives which plug
  zigmon --rules                     which reading drives which plug
  zigmon --check                     is the whole system healthy
  zigmon --diag                      settings, API latency, database size
  zigmon --aggregate                 roll old samples up now (daemon stopped)
  zigmon --reset-data history        erase: all, history, events, or a device name

Every command the standalone Shelly reader had is available under "shelly",
addressed by the name a device has in the configuration - the address and
password come from there:

  zigmon shelly Lednice info         identity and firmware
  zigmon shelly Lednice dump         every value the device reports
  zigmon shelly Lednice methods      every RPC method it supports (--examples)
  zigmon shelly Lednice config       the whole configuration
  zigmon shelly Lednice config switch:0 '{"auto_off": true}'
  zigmon shelly Lednice poll         a live table of the numbers (--csv FILE)
  zigmon shelly Lednice watch        the same, pushed rather than polled
  zigmon shelly Lednice on|off|toggle
  zigmon shelly Lednice reset-counters [aenergy ...]
  zigmon shelly Lednice reboot --wait
  zigmon shelly Lednice ble status|on|off|rpc-on|rpc-off [--reboot]
  zigmon shelly Lednice matter status|on|off|code [--reboot]
  zigmon shelly Lednice call Switch.GetStatus '{"id":0}'
  zigmon shelly HT-Sklep dump        a sensor, while it is awake
  zigmon shelly listen               show webhook pushes as they arrive
  zigmon shelly serve                accept an outbound websocket
  zigmon shelly discover             find Shelly devices on the LAN
  zigmon shelly --host 10.0.0.5 info a device not in the configuration
  zigmon shelly --help               the command list
  zigmon shelly config --help        the options of one command

A Zigbee gateway with its own network API (e.g. a SMLIGHT SLZB-06) is read
the same way, under "gateway" - set it up in config.json first under
"zigbee_gateways": [{"name": ..., "host": ..., "target": ...}], where
"target" is either "coordinator" or the name an existing Zigbee router
already has, so its readings extend that device instead of duplicating it:

  zigmon gateway Router dump         everything /ha_info, /ha_sensors and /metrics return
  zigmon gateway Router info         just /ha_info
  zigmon gateway Router sensors      just /ha_sensors
  zigmon gateway Router metrics      just /metrics (Prometheus text - heap, uptime, temps...)
  zigmon gateway --host 192.168.1.51 dump   a device not in config.json yet

Configuration lives in /etc/zigmon/config.json; every scalar key can also be
given as an environment variable with a ZIGMON_ prefix (ZIGMON_MQTT_HOST=...).
""")
    p.add_argument('--version', action='version', version='zigmon ' + __version__)
    p.add_argument('--config', metavar='FILE', help='configuration file (default %s)' % CONFIG_FILE)
    p.add_argument('--debug', action='store_true', help='verbose logging')
    p.add_argument('--json', action='store_true', help='machine-readable output where supported')
    p.add_argument('--no-color', action='store_true')
    p.add_argument('-y', '--yes', action='store_true', help='do not ask for confirmation')
    p.add_argument('--allow-root', action='store_true',
                   help='run the daemon as root anyway (only with a scratch --config)')
    a = p.add_argument_group('actions')
    a.add_argument('--status', action='store_true', help='every device with its latest readings')
    a.add_argument('--devices', action='store_true', help='the device table')
    a.add_argument('--history', metavar='DEVICE', help='recorded samples of one device')
    a.add_argument('--range', metavar='SPAN', help='for --history: 6h, 24h, 7d, 30d, 1y (default 24h)')
    a.add_argument('--keys', metavar='K1,K2', help='for --history: which readings')
    a.add_argument('--points', type=int, default=200, help='for --history: at most this many rows')
    a.add_argument('--events', action='store_true', help='the event log')
    a.add_argument('--limit', type=int, default=50, help='for --events')
    a.add_argument('--watch', action='store_true', help='live feed straight from the broker')
    a.add_argument('--seconds', type=float, default=0, help='for --watch: stop after this long')
    a.add_argument('--count', type=int, default=0, help='for --watch: stop after this many messages')
    a.add_argument('--bridge', action='store_true', help='for --watch: include bridge/* topics')
    a.add_argument('--raw', action='store_true', help='for --watch: do not shorten payloads')
    a.add_argument('--permit-join', metavar='on|off', help='open or close the Zigbee network')
    a.add_argument('--plug', metavar='NAME', nargs='?', const='all', help='the smart plug(s), live')
    a.add_argument('--plug-on', metavar='NAME', help='switch a plug on')
    a.add_argument('--plug-off', metavar='NAME', help='switch a plug off')
    a.add_argument('--plug-toggle', metavar='NAME', help='switch a plug to the other state')
    a.add_argument('--plug-pulse', metavar='NAME', help='flip a plug, wait --ms, flip it back')
    a.add_argument('--ms', type=int, default=PULSE_MS_DEFAULT, help='for --plug-pulse: the hold time in milliseconds')
    a.add_argument('--plug-reset', metavar='NAME', help='reset its counters (all, or --types a,b)')
    a.add_argument('--types', metavar='T1,T2', help='for --plug-reset: %s' % ', '.join(PLUG_COUNTER_TYPES))
    a.add_argument('--bindings', action='store_true', help='which button action drives which plug')
    a.add_argument('--rules', action='store_true', help='which reading drives which plug')
    a.add_argument('--reset-data', metavar='SCOPE', help='erase: all, history, events, or a device name')
    a.add_argument('--check', action='store_true', help='health check against the running daemon')
    a.add_argument('--diag', action='store_true', help='config, API latency, database size')
    a.add_argument('--map', dest='map_now', action='store_true',
                   help='scan the Zigbee network now and print who talks through whom')
    a.add_argument('--presence', action='store_true', help='who is at home, and what the controller sees')
    a.add_argument('--wifi', action='store_true',
                   help='ask the controller now and print everything it knows about the network')
    a.add_argument('--wifi-probe', dest='wifi_probe', action='store_true',
                   help='what the controller answers, field by field - for when the WiFi tab looks empty')
    a.add_argument('--wifi-order-reset', dest='wifi_order_reset', action='store_true',
                   help='forget how the WiFi cards are arranged (same as --reset-order wifi)')
    a.add_argument('--reset-order', dest='reset_order', metavar='WHAT',
                   help='forget how a set of cards is arranged: overview, wifi, plugs, sensors, '
                        'buttons, devices, groups, or all')
    a.add_argument('--monthly', action='store_true', help='print what last month drank and send the summary')
    a.add_argument('--aggregate', action='store_true', help='roll old samples up now (daemon must be stopped)')
    return p


def main(argv=None):
    global DEBUG, CONFIG_FILE
    arguments = list(sys.argv[1:] if argv is None else argv)

    # "zigmon gateway ..." reads a Zigbee gateway's own HTTP API (SLZB-06 etc).
    if arguments and arguments[0] == 'gateway':
        pal = Palette('--no-color' not in arguments and sys.stdout.isatty())
        return gateway_main(arguments[1:], pal)

    # "zigmon shelly ..." is a world of its own, with its own options.
    if arguments and arguments[0] == 'shelly':
        rest = []
        skip = False
        for index, value in enumerate(arguments[1:]):
            if skip:
                skip = False
                continue
            if value == '--config' and index + 2 < len(arguments):
                CONFIG_FILE = Path(arguments[index + 2])
                skip = True
                continue
            rest.append(value)
        load_config()
        for problem in CONFIG_FATAL:
            sys.stderr.write('CONFIG: %s\n' % problem)
        pal = Palette('--no-color' not in rest and sys.stdout.isatty())
        return shelly_main(rest, pal)

    args = build_parser().parse_args(arguments)
    if args.config:
        CONFIG_FILE = Path(args.config)
    DEBUG = args.debug
    load_config()
    pal = Palette(not args.no_color and sys.stdout.isatty())

    if CONFIG_FATAL and not (args.check or args.diag):
        for note in CONFIG_FATAL:
            sys.stderr.write('ERROR: %s\n' % note)
        return 2

    if args.status:
        return cmd_status(args, pal)
    if args.devices:
        return cmd_devices(args, pal)
    if args.history:
        return cmd_history(args, pal)
    if args.events:
        return cmd_events(args, pal)
    if args.watch:
        return cmd_watch(args, pal)
    if args.permit_join:
        return cmd_permit_join(args, pal)
    if args.plug:
        return cmd_plug(args, pal)
    if args.plug_on or args.plug_off or args.plug_toggle or args.plug_pulse:
        return cmd_plug_switch(args, pal)
    if args.plug_reset:
        return cmd_plug_reset(args, pal)
    if args.bindings:
        return cmd_bindings(args, pal)
    if args.rules:
        return cmd_rules(args, pal)
    if args.reset_data:
        return cmd_reset(args, pal)
    if args.check:
        return cmd_check(args, pal)
    if args.diag:
        return cmd_diag(args, pal)
    if args.map_now:
        return cmd_map(args, pal)
    if getattr(args, 'monthly', False):
        return cmd_monthly(args, pal)
    if args.presence:
        return cmd_presence(args, pal)
    if args.wifi:
        return cmd_wifi(args, pal)
    if args.wifi_probe:
        return cmd_wifi_probe(args, pal)
    if args.wifi_order_reset or args.reset_order:
        what = args.reset_order or 'wifi'
        if not re.match(r'^[a-z]+$', what):
            print(pal.crit('%r is not one of: %s, all' % (what, ', '.join(sorted(Daemon.ARRANGEMENTS)))))
            return 2
        code, answer = api_call('/api/order/reset?what=' + what, timeout=20.0, token=read_token())
        if code != 200 or not answer.get('ok'):
            print(pal.crit('the daemon refused: %s' % (answer.get('error') or code)))
            if answer.get('choices'):
                print(pal.note('  pick one of: %s, all' % ', '.join(answer['choices'])))
            return 2
        for name in answer.get('reset') or []:
            print(pal.ok('%s: back to the default arrangement' % name))
        return 0
    if args.aggregate:
        store = Storage()
        n = store.aggregate()
        print('rolled up %d hourly rows' % n)
        return 0

    if mqtt is None:
        sys.stderr.write('ERROR: python3-paho-mqtt is not installed (dnf install -y python3-paho-mqtt)\n')
        return 2

    # The daemon writes the database, its WAL and the token. Started as root
    # over the service's own files it leaves root-owned pieces behind that the
    # service cannot open on its next start.
    if os.geteuid() == 0 and not args.allow_root and str(db_path()).startswith(str(STATE_DIR)):
        try:
            import pwd
            pwd.getpwnam(SERVICE_USER)
            sys.stderr.write('ERROR: do not run the daemon as root over %s.\n'
                             '  installed service:   systemctl status zigmon\n'
                             '  foreground, as the service user:   sudo -u %s %s\n'
                             '  a scratch copy as root:   --config /tmp/test.json with db_file and api_port '
                             'of its own, plus --allow-root\n' % (STATE_DIR, SERVICE_USER, sys.argv[0]))
            return 2
        except KeyError:
            pass                        # no service user on this machine; a test box

    try:
        daemon = Daemon()
    except StorageError as e:
        sys.stderr.write('ERROR: %s\n' % e)
        return 2
    signal.signal(signal.SIGTERM, daemon.stop)
    signal.signal(signal.SIGINT, daemon.stop)
    signal.signal(signal.SIGHUP, daemon.reopen_log)
    return daemon.run()


if __name__ == '__main__':
    sys.exit(main())
