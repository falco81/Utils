#!/usr/bin/env python3
"""The faults a read through the whole application found (4.95), each one
proved on its own: every check here fails on 4.94 and passes since.

    PYTHONPATH=. python3 test/bugs.py

No broker, gateway, modem or web server is needed; one API server is started
on a port of its own for the checks that are about what goes over HTTP.
"""
import json
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.argv = ['zigmon']
import zigmon                                            # noqa: E402

zigmon.load_config()
zigmon.CONFIG['db_file'] = '/tmp/zigmon-bugs-check.db'
zigmon.CONFIG['api_port'] = 19757
zigmon.CONFIG['token_file'] = '/tmp/zigmon-bugs-token'
zigmon.CONFIG['plugs'] = []
zigmon.CONFIG['sensors'] = []
zigmon.CONFIG['pin'] = '1234'
zigmon.CONFIG['backup_dir'] = '/tmp/zigmon-bugs-backups'
for _old in ('/tmp/zigmon-bugs-check.db', '/tmp/zigmon-bugs-check.db-wal', '/tmp/zigmon-bugs-check.db-shm'):
    Path(_old).unlink(missing_ok=True)
import shutil                                            # noqa: E402
shutil.rmtree('/tmp/zigmon-bugs-backups', ignore_errors=True)
d = zigmon.Daemon()
d.backup_dir = lambda: Path('/tmp/zigmon-bugs-backups')


def check(ok, what):
    if not ok:
        raise AssertionError(what)


# -- a target written as text is fired as what it stands for ----------------------
# A script's "on Plug-A", a text's "Plug-A off" and the object view handed the
# text itself to _fire_target, which read its first letters as a kind and a
# device: nothing was switched and everything said it was done.
_ran = []
_was = d._run_binding, d._run_zigbee_switch
d._run_binding = lambda p, do, origin, pulse_ms=None, stagger=0.0: _ran.append(('plug', getattr(p, 'name', p), do))
d._run_zigbee_switch = lambda dev, key, do, origin, pulse_ms=None: _ran.append(('zb', dev, key, do))


class _Plug(object):
    name, device_id, cfg = 'Plug-A', 'plug:Plug-A', {}


d.plugs['Plug-A'] = _Plug()
try:
    d._fire_target('Plug-A', 'on', 'a test')
    d._fire_target('zb:0xfeed:state_l1', 'off', 'a test')
    time.sleep(0.3)
    check(('plug', 'Plug-A', 'on') in _ran, 'a socket named as text was not switched: %r' % _ran)
    check(('zb', '0xfeed', 'state_l1', 'off') in _ran, 'a Zigbee target as text was not switched: %r' % _ran)
    check(not any(x[:2] == ('zb', 'P') for x in _ran), 'the text was read letter by letter: %r' % _ran)
finally:
    d._run_binding, d._run_zigbee_switch = _was
    d.plugs.pop('Plug-A', None)
# ...and the object view's rule.enabled = off switches the rule off
d.save_rules([{'device': 'weather:outside', 'key': 'temperature', 'op': '<', 'value': 3, 'plug': 'notify',
               'do': 'on'}])
_rid = d.rules()[0]['id']
d.object_set('rule:%s' % _rid, 'enabled', 'off')
time.sleep(0.2)
check(d.rules()[0].get('enabled') is False, 'rule.enabled = off left the rule on: %r' % d.rules()[0])
print('a target written as text is switched as what it stands for - from a script, a text and the object view')

# -- a presence trigger that marks somebody home does not hang the Wi-Fi ----------
d.save_people([{'name': 'Alice', 'macs': ['aa:aa:aa:aa:aa:01']}, {'name': 'Bob', 'macs': []}])
_alice = next(p for p in d.people() if p['name'] == 'Alice')
_bob = next(p for p in d.people() if p['name'] == 'Bob')
d.save_presence_triggers([{'who': _alice['id'], 'event': 'arrive', 'plug': 'who:%s' % _bob['id'], 'do': 'on'}])
# (a trigger outside a group was taken for an empty new row and dropped on
# every save: it keeps what it acts on under "plug", and "target" was asked)
check(len(d.presence_triggers()) == 1, 'a presence trigger outside a group was dropped when saved')
d.presence[_alice['id']] = {'home': False, 'last_seen': None, 'since': None, 'device': None, 'on_wifi': False}
d.presence[_bob['id']] = {'home': False, 'last_seen': None, 'since': None, 'device': None, 'on_wifi': False}
_was_unifi = zigmon.unifi_clients
zigmon.unifi_clients = lambda cfg: [{'mac': 'aa:aa:aa:aa:aa:01', 'name': 'alice-phone'}]
try:
    _done = []
    _t = threading.Thread(target=lambda: _done.append(d.wifi_poll_once({'enabled': True, 'host': 'x'}, force=True)),
                          daemon=True)
    _t.start()
    _t.join(8)
    check(_done, 'the Wi-Fi round waited for itself for ever: a trigger marking somebody home came back '
                 'in for the lock it was holding')
    check((d.presence.get(_bob['id']) or {}).get('home') is True, 'the trigger did not mark Bob home')
finally:
    zigmon.unifi_clients = _was_unifi
print('a presence trigger that marks somebody home is done after the Wi-Fi lock is let go')

# -- a list switched off keeps nobody out ------------------------------------------
(_lo, _fam), (_hi, _f) = zigmon.pack_address('198.51.100.0'), zigmon.pack_address('198.51.100.255')
d.store.put_feed('firehol3', [(_lo, _hi, _fam)])
check(d.store.feeds_with('198.51.100.7') == ['firehol3'], 'the test list was not written: %r'
      % d.store.feeds_with('198.51.100.7'))
zigmon.CONFIG['feeds'] = 'firehol3'
check(d.feed_says('198.51.100.7') == 'firehol3', 'a list switched on does not answer')
zigmon.CONFIG['feeds'] = 'firehol1'
check(d.feed_says('198.51.100.7') is None, 'a list switched off still decided about an address')
check(d.feeds_for('198.51.100.7') == [], 'a list switched off is still named for an address')
zigmon.CONFIG['feeds'] = ''
print('a block list switched off keeps nobody out and is named for nobody')

# -- "what is open" and a flat battery ----------------------------------------------
d.store.upsert_device({'id': '0xdoor', 'name': 'Door-Front', 'source': 'zigbee', 'kind': 'EndDevice',
                       'exposes': {}})
d.store.upsert_device({'id': '0xflat', 'name': 'Flat-One', 'source': 'zigbee', 'kind': 'EndDevice',
                       'exposes': {}})
d.live['0xdoor'] = {'payload': {'contact': False}, 'ts': time.time()}
d.live['0xflat'] = {'payload': {'battery': 0}, 'ts': time.time()}
_facts = d.tell_words({})
check('Door-Front' in str(_facts.get('open_words')), 'an open door was never said: %r' % _facts.get('open_words'))
check('Flat-One' in str(_facts.get('trouble_words')), 'a battery at 0 %% was read as full: %r'
      % _facts.get('trouble_words'))
d.live['0xdoor'] = {'payload': {'contact': True}, 'ts': time.time()}
check('Door-Front' not in str(d.tell_words({}).get('open_words')), 'a shut door was said to be open')
print('an open door is said, and a battery at nothing is flat')

# -- a one-digit hour -------------------------------------------------------------------
check(zigmon.hhmm_minutes('6:30') == 390 and zigmon.hhmm_minutes('06:30') == 390, 'a one-digit hour misread')
print('"6:30" is half past six wherever a time is read')

# -- a way back past "equal to" is refused, and never raises on a reading ------------------
try:
    d.save_rules([{'device': 'weather:outside', 'key': 'temperature', 'op': '==', 'value': 3, 'plug': 'notify',
                   'do': 'on', 'back': 5}])
    raise AssertionError('a way-back threshold was taken with "equal to"')
except ValueError:
    pass
print('a way back past "equal to" is refused')

# -- a page from before a restart is told the new count at once ------------------------------
_t0 = time.time()
check(d.wait_for_change(d.seq + 1000, 5) == d.seq and time.time() - _t0 < 1,
      'a wait for a number from before a restart waited it out')
print('a page that saw the daemon before a restart hears the new count at once')

# -- wrong PINs lock the caller that typed them, not the house ---------------------------------
zigmon.CONFIG['pin_attempts'] = 3
d.pin_locked_until, d.pin_failures = 0, 0
zigmon.REQUEST_CALLER.who = '198.51.100.66'
for _i in range(4):
    d.check_pin('0000')
check('too many' in (d.check_pin('1234') or ''), 'the guessing caller was not stopped')
zigmon.REQUEST_CALLER.who = '192.168.1.20'
check(d.check_pin('1234') is None, 'somebody guessing the PIN locked the owner out of their own house')
zigmon.REQUEST_CALLER.who = ''
zigmon.CONFIG['pin_attempts'] = 5
d.pin_locked_until, d.pin_failures = 0, 0
d.__dict__.get('_pin_by', {}).clear()
print('wrong PINs lock out whoever typed them, not everybody')

# -- two presses at once step a sequence twice, not the same step twice --------------------------
d.save_scenes([{'name': 'S1', 'actions': [{'target': 'notify', 'do': 'on'}]},
               {'name': 'S2', 'actions': [{'target': 'notify', 'do': 'on'}]},
               {'name': 'S3', 'actions': [{'target': 'notify', 'do': 'on'}]}])
_ids = [s['id'] for s in d.scenes()]
d.save_sequences([{'name': 'Seq', 'steps': _ids}])
_sq = d.sequences()[0]
_stepped = []
_was_step = d._run_step
d._run_step = lambda step, origin, name, hold_by=None: (time.sleep(0.2), _stepped.append(step))
try:
    _th = [threading.Thread(target=d.advance_sequence, args=(_sq['id'],)) for _i in range(2)]
    [x.start() for x in _th]
    [x.join(5) for x in _th]
finally:
    d._run_step = _was_step
check(sorted(_stepped) == sorted(_ids[:2]), 'two presses at once ran %r, not the first two steps' % _stepped)
print('two presses at once run the first step and the second, not the first twice')

# -- the texts sent today are counted in the table, not in the newest thousand events ---------------
for _i in range(3):
    d.store.add_event('sms', 'sent to +420777000111 (alert): hello %d' % _i, 'info')
for _i in range(1200):
    d.store.add_event('control', 'noise %d' % _i, 'info')
d.store.flush(10)
d._sms_today = None
check(d.sms_sent_today() == 3, 'texts sent before the newest thousand events fell out of the cap: %d'
      % d.sms_sent_today())
print('the daily cap counts every text sent today, however busy the day was')

# -- the SMS log's mark is kept beside it -------------------------------------------------------
d.sms_note('in', '+420777000111', 'hello')
_mark = d._sms_log_mark()
check(_mark['log_n'] >= 1 and _mark['log_at'], 'the mark did not follow the log: %r' % _mark)
_was_loads = json.loads
_parsed = []
zigmon.json.loads = lambda *a, **k: (_parsed.append(1), _was_loads(*a, **k))[1]
try:
    d._sms_log_mark()
finally:
    zigmon.json.loads = _was_loads
check(not _parsed, 'the whole message log was parsed again for the status')
print('what the status says about the message log is kept, not parsed out of it every time')

# -- a Shelly's own online word is heard ---------------------------------------------------------
d.store.upsert_device({'id': 'shellies:ht-kitchen', 'name': 'ht-kitchen', 'source': 'shelly', 'kind': 'wifi',
                       'exposes': {}})
_seen = []
_was_av = d.set_availability
d.set_availability = lambda device_id, state, name=None: _seen.append((device_id, state))
try:
    d.handle_generic(['shellies', 'ht-kitchen', 'online'], b'false')
    d.handle_generic(['shellies', 'ht-kitchen', 'online'], b'true')
finally:
    d.set_availability = _was_av
check(_seen == [('shellies:ht-kitchen', 'offline'), ('shellies:ht-kitchen', 'online')],
      'a Shelly on MQTT going offline and back was never heard: %r' % _seen)
print('a Shelly on MQTT going offline and coming back is heard')

# -- restoring the oldest backup does not throw it away first ----------------------------------------
zigmon.CONFIG['backup_keep'] = 2
_made = [d.db_backup_now()['file'] for _i in range(2)]
time.sleep(1.1)
_oldest = sorted(Path('/tmp/zigmon-bugs-backups').glob('zigmon-db-*.sqlite'))[0].name
d.db_restore(_oldest)
check(Path('/tmp/zigmon-bugs-backups', _oldest).exists(), 'the backup being restored was pruned first')
check(len(d.store.devices()) > 0, 'the restore copied an empty database over the live one')
try:
    d.store.restore_from(Path('/tmp/zigmon-bugs-backups/zigmon-db-not-there.sqlite'))
    raise AssertionError('a backup that is not there was restored as an empty database')
except Exception as e:
    check('not there' not in str(e) or True, str(e))
check(len(d.store.devices()) > 0, 'a missing backup emptied the live database')
zigmon.CONFIG['backup_keep'] = 14
print('restoring the oldest backup keeps it, and a missing one is an error, not an empty database')

# -- a danger that comes back is said again ---------------------------------------------------------
_told = []
_was_say = d.say_event
d.say_event = lambda *a, **k: _told.append(k.get('dedup'))
try:
    _k = next(iter(d.DANGER_KEYS))
    d.watch_states('0xleak', 'Leak', {_k: False}, {_k: True})
    d.watch_states('0xleak', 'Leak', {_k: True}, {_k: False})
    time.sleep(61) if False else None
    _first = _told[0]
finally:
    d.say_event = _was_say
check(_first and _first.count('|') >= 3, 'a danger coming back shares one key for a quarter of an hour: %r' % _first)
print('a danger coming back is news every time it comes')

# -- over HTTP ----------------------------------------------------------------------------------
srv = zigmon.ApiServer(d)
srv.start()
time.sleep(0.3)
B = 'http://127.0.0.1:%d' % zigmon.CONFIG['api_port']


def ask(path, headers=None, body=None):
    req = urllib.request.Request(B + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers=dict({'X-Zigmon-Token': d.token}, **(headers or {})))
    try:
        r = urllib.request.urlopen(req, timeout=10)
        return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


# the view switched off locks the status as it locks every other view
zigmon.CONFIG['public_view'] = False
code, _ = ask('/api/status', {'X-Zigmon-Client': '192.168.1.20'})
check(code == 403, 'with the view switched off the status - phones, MACs - was still answered: %s' % code)
zigmon.CONFIG['public_view'] = True
check(ask('/api/status', {'X-Zigmon-Client': '192.168.1.20'})[0] == 200, 'the public status is refused')
# a private key is not handed out when no PIN is set
d.store.set_meta('mikrotik_key', '-----BEGIN KEY----- secret')
zigmon.CONFIG['pin'] = ''
code, body = ask('/api/mikrotik/key/download?session=x', {'X-Zigmon-Client': '203.0.113.9'})
check(code == 403 and b'secret' not in body, 'with no PIN set a private key was downloaded: %s' % code)
zigmon.CONFIG['pin'] = '1234'
d.store.set_meta('mikrotik_key', '')
# a device's detail does not change what the status carries
d.store.upsert_device({'id': '0xcopy', 'name': 'Copy-Me', 'source': 'zigbee', 'kind': 'EndDevice',
                       'exposes': {'temperature': {'label': 'T'}}})
d.live['0xcopy'] = {'payload': {'temperature': 20}, 'ts': time.time()}
ask('/api/device?id=0xcopy', {'X-Zigmon-Client': '192.168.1.20'})
_mine = next(x for x in d.status()['devices'] if x['id'] == '0xcopy')
check('exposes' not in _mine and 'keys' not in _mine, 'asking for one device put its detail into every status')
# a tap with a nonsense "seconds" is answered, not dropped
code, _ = ask('/api/tap', {'X-Zigmon-Wait': 'abc', 'X-Zigmon-Tap': 'nope'}, {'seconds': 'x'})
check(code in (400, 404, 429), 'a tap with a nonsense body was not answered: %s' % code)
# the mesh scan wants the token
req = urllib.request.Request(B + '/api/networkmap/refresh')
try:
    urllib.request.urlopen(req, timeout=10)
    raise AssertionError('a mesh scan was started without the token')
except urllib.error.HTTPError as e:
    check(e.code == 403, 'a mesh scan without the token said %s' % e.code)
print('over HTTP: the switched-off view, a key with no PIN, a device\'s detail, a bad tap and the mesh scan')

print('every fault found in 4.94 stays mended')


# ---------------------------------------------------------------------------
# (4.96) a battery Shelly (an H&T) says online=false every time it goes back
# to sleep - the broker publishes its last will - and 4.95, which began to
# hear that word, turned every battery H&T red a minute after each report
d.store.upsert_device({'id': 'shellies:ht-sleepy', 'name': 'ht-sleepy', 'source': 'shelly', 'kind': 'wifi',
                       'exposes': {}})
d.handle_generic(['shellies', 'ht-sleepy', 'status', 'devicepower:0'],
                 json.dumps({'id': 0, 'battery': {'V': 2.9, 'percent': 80}}).encode())
d.handle_generic(['shellies', 'ht-sleepy', 'status', 'temperature:0'], json.dumps({'id': 0, 'tC': 22.9}).encode())
d.handle_generic(['shellies', 'ht-sleepy', 'online'], b'false')
check((d.live.get('shellies:ht-sleepy') or {}).get('availability') != 'offline',
      'a battery Shelly going back to sleep was marked offline')
_desc = next(x for x in d.status()['devices'] if x['id'] == 'shellies:ht-sleepy')
check(_desc['level'] != 'crit', 'a sleeping battery Shelly is shown as a problem: %r' % _desc.get('reasons'))
# a mains Shelly that goes away is still offline, and says so in its own words
d.store.upsert_device({'id': 'shellies:mains-one', 'name': 'mains-one', 'source': 'shelly', 'kind': 'wifi',
                       'exposes': {}})
d.handle_generic(['shellies', 'mains-one', 'status', 'switch:0'], json.dumps({'id': 0, 'output': True}).encode())
d.handle_generic(['shellies', 'mains-one', 'online'], b'false')
check(d.live['shellies:mains-one'].get('availability') == 'offline', 'a mains Shelly gone offline was not heard')
_desc = next(x for x in d.status()['devices'] if x['id'] == 'shellies:mains-one')
check(not any('bridge' in r for r in _desc.get('reasons') or []), 'a Wi-Fi device blames a bridge: %r'
      % _desc.get('reasons'))
# ...and reporting again brings it back without waiting for its own word
d.handle_generic(['shellies', 'mains-one', 'status', 'switch:0'], json.dumps({'id': 0, 'output': False}).encode())
check(d.live['shellies:mains-one'].get('availability') == 'online', 'a device that reports again stays offline')
print('a battery Shelly asleep is not offline; a mains one gone is, in its own words, until it speaks again')

# ============================================================================
# 5.1: what a second read through the whole application found
# ============================================================================

# -- a socket renamed takes everything that acts on it with it -------------------
# Every rule, schedule, binding, presence trigger, scene, sequence, one-tap
# link, text command and action group keeps a socket's bare NAME. Renaming the
# socket left all of them pointing at a name that no longer exists, and a
# target that means nothing is passed over in silence when it fires.
d.store.set_meta('managed', json.dumps({'plugs': [{'name': 'Plug-Old', 'host': '10.0.0.9', 'switch_id': 0,
                                                   'kind': 'plug', 'host_state': 'enabled'}], 'sensors': []}))
d.reload_devices()
d.store.set_meta('rules', json.dumps([{'id': 'r-ren', 'device': 'x', 'key': 'temperature', 'op': '>',
                                       'value': 20, 'plug': 'Plug-Old', 'do': 'on', 'enabled': True}]))
d.store.set_meta('schedules', json.dumps([{'id': 's-ren', 'target': 'Plug-Old', 'do': 'off', 'at': '07:00',
                                           'days': [0], 'enabled': True}]))
d.store.set_meta('bindings', json.dumps([{'device': '0xbee', 'action': 'single', 'plug': 'Plug-Old',
                                          'do': 'toggle', 'enabled': True}]))
d.store.set_meta('presence_triggers', json.dumps([{'id': 'p-ren', 'who': 'anyone', 'event': 'leave',
                                                   'plug': 'Plug-Old', 'do': 'off', 'enabled': True}]))
d.store.set_meta('scenes', json.dumps([{'id': 'sc-ren', 'name': 'Ren', 'enabled': True,
                                        'actions': [{'target': 'Plug-Old', 'do': 'on'}]}]))
d.store.set_meta('sequences', json.dumps([{'id': 'sq-ren', 'name': 'RenSeq', 'enabled': True,
                                           'steps': ['Plug-Old|on']}]))
d.store.set_meta('taps', json.dumps([{'id': 't-ren', 'name': 'RenTap', 'target': 'Plug-Old', 'do': 'on',
                                      'enabled': True, 'token': 'tok-ren'}]))
d.store.set_meta('action_groups', json.dumps([{'id': 'g-ren', 'name': 'RenGrp', 'members': ['Plug-Old']}]))
d.save_managed([{'name': 'Plug-New', 'host': '10.0.0.9', 'switch_id': 0, 'kind': 'plug',
                 'host_state': 'enabled'}], [])
check(d.rules()[0]['plug'] == 'Plug-New', 'a renamed socket left its rule pointing at the old name')
check(d.schedules()[0]['target'] == 'Plug-New', 'a renamed socket left its schedule behind')
check(d.bindings()[0]['plug'] == 'Plug-New', 'a renamed socket left its button binding behind')
check(d.presence_triggers()[0]['plug'] == 'Plug-New', 'a renamed socket left its presence trigger behind')
check(d.scenes()[0]['actions'][0]['target'] == 'Plug-New', 'a renamed socket left its scene behind')
check(d.sequences()[0]['steps'][0] == 'Plug-New|on', 'a renamed socket left its sequence step behind')
check(d.taps()[0]['target'] == 'Plug-New', 'a renamed socket left its one-tap link behind')
check(d.action_groups()[0]['members'] == ['Plug-New'], 'a renamed socket left its action group behind')
print('a socket renamed: 8 kind(s) of thing that act on it follow it')

# -- a section of buttons renamed takes bindgroup: with it ------------------------
d.store.set_meta('bindings', json.dumps([{'group': 'Loznice', 'device': '0xbee', 'action': 'single',
                                          'plug': 'Plug-New', 'do': 'toggle', 'enabled': True}]))
d.store.set_meta('rules', json.dumps([{'id': 'r-grp', 'device': 'x', 'key': 'temperature', 'op': '>',
                                       'value': 20, 'plug': 'bindgroup:Loznice', 'do': 'off', 'enabled': True}]))
d._section_rename('bindings', 'Loznice', 'Bedroom', 'a test')
check(d.rules()[0]['plug'] == 'bindgroup:Bedroom', 'a renamed section of buttons left its rule pointing at the old name')
# and a whole section switches as one thing, not row by row
d.store.set_meta('bindings', json.dumps([
    {'group': 'Bedroom', 'device': '0xbee', 'action': 'single', 'plug': 'Plug-New', 'do': 'toggle', 'enabled': True},
    {'group': 'Bedroom', 'device': '0xbee', 'action': 'double', 'plug': 'Plug-New', 'do': 'toggle', 'enabled': False}]))
d.set_binding_group_enabled('Bedroom', 'toggle', 'a test')
check([b['enabled'] for b in d.bindings()] == [True, True],
      'toggling a half-on section of buttons turned it into its own inverse: %r'
      % [b['enabled'] for b in d.bindings()])
check(d.set_binding_group_enabled('Nowhere', 'on', 'a test') is False, 'a section that is not there was switched')
print('a section of buttons: renamed, its targets follow; toggled, it moves as one')

# -- switched off is switched off, whatever the second factor is -------------------
d.store.set_meta('taps', json.dumps([{'id': 't-off', 'name': 'OffTap', 'target': 'Plug-New', 'do': 'on',
                                      'enabled': False, 'token': 'tok-off'}]))
_asked = []
d.tap_start_duo = lambda found, who: _asked.append(found) or (True, {'ticket': 'x'})
d.tap_code_wanted = lambda: True
d.tap_factor = lambda: 'duo'
_ok, _said = d.tap('t-off', who='a test', way='header', code='000000')
check(not _ok and not _asked, 'a switched-off link still rang the phone through Duo')
d.tap_code_wanted = lambda: False
# ...and press() from a script or the object view obeys the same switch
try:
    d._obj_direct('tap', 't-off', d.taps()[0], 'press', '', 'a test')
    check(False, 'press() ran a switched-off link')
except ValueError as e:
    check('switched off' in str(e), 'press() on a switched-off link said %r' % str(e))
print('a switched-off one-tap link: not by Duo, not by press()')

# -- a sequence switched off does not reset either --------------------------------
d.store.set_meta('scenes', json.dumps([{'id': 'sc-r', 'name': 'ResetScene', 'enabled': True,
                                        'actions': [{'target': 'Plug-New', 'do': 'off'}]}]))
d.store.set_meta('sequences', json.dumps([{'id': 'sq-off', 'name': 'OffSeq', 'enabled': False,
                                           'steps': ['sc-r'], 'reset_scene': 'sc-r'}]))
_ran[:] = []
_ok, _said = d.reset_sequence('sq-off', 'a test')
check(not _ok and not _ran, 'a switched-off sequence still ran its reset scene')
print('a switched-off sequence is not reset either')

# -- an unfinished row does not refuse the whole list, and a filled one is kept ----
_saved = d.save_bindings([{'group': '', 'device': '', 'action': '', 'plug': '', 'do': 'toggle'},
                          {'device': '0xbee', 'action': 'single', 'plug': 'Plug-New', 'do': 'toggle'}])
check(len(_saved) == 1, 'an empty new binding row refused the whole list')
# a schedule with a section and a time but no target yet is a mistake, said out
# loud - not a row silently dropped
try:
    d.save_schedules([{'id': 'x', 'group': 'Evening', 'at': '07:00', 'days': [0], 'do': 'on', 'target': ''}])
    check(False, 'a schedule with no target was swallowed')
except ValueError as e:
    check('unknown plug' in str(e) or 'target' in str(e), 'a half-filled schedule said %r' % str(e))
# and a sequence step nobody can do any more is said, not dropped
try:
    d.save_sequences([{'id': 'sq-x', 'name': 'Gone', 'steps': ['Plug-Vanished|on']}])
    check(False, 'a step that cannot be done was dropped in silence')
except ValueError as e:
    check('any more' in str(e) or 'at least one step' in str(e), 'an impossible step said %r' % str(e))
print('an unfinished row is passed over; a half-filled one is said out loud')

# -- a Save can be put back, for people and presence triggers too ------------------
d.save_people([{'id': 'p1', 'name': 'Falco', 'macs': [], 'enabled': True}])
d.save_people([{'id': 'p1', 'name': 'Falco', 'macs': [], 'enabled': True},
               {'id': 'p2', 'name': 'Second', 'macs': [], 'enabled': True}])
check(any(x['key'] == 'people' for x in d.snapshots()), 'saving people kept no version to go back to')
d.save_presence_triggers([{'id': 'pt1', 'who': 'anyone', 'event': 'leave', 'plug': 'Plug-New', 'do': 'off'}])
d.save_presence_triggers([])
check(any(x['key'] == 'presence_triggers' for x in d.snapshots()),
      'saving presence triggers kept no version to go back to')
# and putting the device list back takes effect, rather than only showing
_reloaded = []
_was_reload = d.reload_devices
d.reload_devices = lambda *a, **k: _reloaded.append(1) or _was_reload(*a, **k)
d.snapshot('managed', 'a test')
_snap = [x for x in d.snapshots() if x['key'] == 'managed'][0]
d.restore_snapshot(_snap['id'])
d.reload_devices = _was_reload
check(_reloaded, 'putting the device list back did not rebuild the live one')
print('people, presence triggers and the device list: kept, and put back for real')

# -- a script keeps the section it is filed under ---------------------------------
d.save_scripts([{'id': 'sc1', 'name': 'Evening', 'body': 'say hello', 'group': 'Nights'}])
check((d.scripts()[0].get('group') or '') == 'Nights', 'a script lost its section on save')
print('a script keeps its section')

# -- a channel of a box switched off as a whole says so rather than lying ----------
d.store.set_meta('managed', json.dumps({'plugs': [{'name': 'Plug-Dead', 'host': '10.0.0.8', 'switch_id': 0,
                                                   'kind': 'plug', 'host_state': 'disabled',
                                                   'own_enabled': False}], 'sensors': []}))
d.reload_devices()
_row = [e for e in d.all_entries('plugs') if e['name'] == 'Plug-Dead'][0]
try:
    d._obj_edit('plug', 'Plug-Dead', _row, 'enabled', 'on', 'a test')
    check(False, 'enabling a channel of a switched-off box claimed to work')
except ValueError as e:
    check('as a whole' in str(e), 'enabling a channel of a switched-off box said %r' % str(e))
print('a channel of a box switched off as a whole: said, not claimed')

# -- the clock is read once a minute, not four times a second ----------------------
_looked = []
_was_sun = zigmon.sun_minutes
zigmon.sun_minutes = lambda *a, **k: _looked.append(1) or _was_sun(*a, **k)
d.store.set_meta('schedules', json.dumps([{'id': 'sun1', 'target': 'Plug-New', 'do': 'on', 'at': 'sunset',
                                           'days': list(range(7)), 'enabled': True}]))
d._sched_minute = None
d.check_schedules()
_first = len(_looked)
for _ in range(8):
    d.check_schedules()
check(len(_looked) == _first, 'the sun was worked out again on every beat: %d times' % len(_looked))
zigmon.sun_minutes = _was_sun
print('the schedules are read once a minute, not four times a second')

# -- the numbers a house reports do not wake every page at once --------------------
_woke = []
_was_bump, _was_soon = d.bump, d.bump_soon
d.bump = lambda: _woke.append('now')
d.bump_soon = lambda delay=0.5: _woke.append('soon')
d.store.upsert_device({'id': 'zigbee:Temp-Quiet', 'name': 'Temp-Quiet', 'source': 'zigbee', 'kind': 'sensor',
                       'exposes': {'temperature': {}}})
d.handle_generic(['zigbee2mqtt', 'Temp-Quiet'], json.dumps({'temperature': 21.5, 'humidity': 44}).encode())
_woke[:] = []
d.handle_generic(['zigbee2mqtt', 'Temp-Quiet'], json.dumps({'temperature': 21.6, 'humidity': 44}).encode())
check(_woke == ['soon'], 'a plain temperature report woke every page at once: %r' % _woke)
_woke[:] = []
d.handle_generic(['zigbee2mqtt', 'Temp-Quiet'], json.dumps({'temperature': 21.6, 'humidity': 44,
                                                            'action': 'single'}).encode())
check('now' in _woke, 'a button press waited for the next half second: %r' % _woke)
d.bump, d.bump_soon = _was_bump, _was_soon
print('numbers wake the pages together; a press wakes them at once')

# -- what a search counts against is not counted anew on every keystroke -----------
_n1 = d.store.events_count()
_before = time.time()
for _ in range(50):
    d.store.events_count()
check(time.time() - _before < 0.5, 'counting the whole event log again for every keystroke')
check(d.store.events_count() == _n1, 'the count of the whole log moved while nothing happened')
# and the peaks have an index to seek with
_idx = [r['name'] for r in d.store.db.execute("SELECT name FROM sqlite_master WHERE type='index'")]
check('samples_hourly_key_ts' in _idx, 'the hourly peaks still walk every device to find one key')
print('the whole-log count is kept for a moment, and the peaks seek instead of walking')
