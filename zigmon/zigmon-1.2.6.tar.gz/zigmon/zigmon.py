#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zigmon.py - monitoring daemon for every sensor published by Zigbee2MQTT (and,
optionally, by Shelly WiFi devices) over an MQTT broker.

One file. Python standard library plus paho-mqtt, which AlmaLinux 9 ships in
EPEL as python3-paho-mqtt.

It subscribes to the broker, keeps a long-term history in SQLite, and exposes
everything on a localhost HTTP API that the PHP dashboard reads. The two
actions that change something (opening the network for joining, erasing
history) are guarded by a token, so the web user never holds broker
credentials.

Runs as a systemd service, but every function is also available from the
command line for testing:

    zigmon --status              every device with its latest readings
    zigmon --devices             the device table
    zigmon --history DEV 24h     recorded samples of one device as a table
    zigmon --events              the event log
    zigmon --watch               live feed straight from the broker
    zigmon --permit-join on      open the Zigbee network for four minutes
    zigmon --plug                the smart plugs, live from the devices
    zigmon --plug-toggle NAME    switch a plug (also --plug-on, --plug-off)
    zigmon --bindings            which button does what
    zigmon --check               health check against the running daemon
    zigmon --diag                API latency, database size, config in force
    zigmon                       run the daemon in the foreground
"""

# Bumped by hand with every change to this file.
__version__ = '1.2.3'

import argparse
import errno
import json
import os
import re
import secrets
import select
import shutil
import signal
import socket
import sqlite3
import ssl
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

try:
    import paho.mqtt.client as mqtt
except ImportError:            # reported properly by preflight(), not here
    mqtt = None

# ---------------------------------------------------------------------------
# Paths and defaults
# ---------------------------------------------------------------------------
CONFIG_FILE = Path(os.environ.get('ZIGMON_CONFIG', '/etc/zigmon/config.json'))
STATE_DIR = Path('/var/lib/zigmon')
DB_FILE = STATE_DIR / 'history.db'
RUN_DIR = Path('/run/zigmon')
TOKEN_FILE = RUN_DIR / 'api-token'
SERVICE_USER = 'zigmon'

DEFAULTS = {
    # --- the broker ---------------------------------------------------------
    'mqtt_host': '127.0.0.1',
    'mqtt_port': 1883,
    'mqtt_username': '',
    'mqtt_password': '',
    'mqtt_tls': False,           # True for a TLS listener (usually port 8883)
    'mqtt_ca': '',               # CA file to verify the broker; empty = no verification
    'mqtt_client_id': 'zigmon',
    'mqtt_keepalive': 60,

    # --- what to listen to --------------------------------------------------
    'base_topic': 'zigbee2mqtt',
    # Additional topic filters. Shelly Gen2/Gen3 devices publishing their
    # status under a prefix (shellies/<name>/status/...) are understood; any
    # other topic carrying a JSON object is stored under the topic's second
    # element as the device name.
    'extra_topics': ['shellies/#'],

    # --- our own API --------------------------------------------------------
    'api_host': '127.0.0.1',
    'api_port': 9849,
    'token_file': '/run/zigmon/api-token',

    # --- timing (seconds) ---------------------------------------------------
    # A reading that arrives sooner than this after the previous stored one
    # replaces it instead of adding a row. 0 keeps every reading.
    'sample_interval': 30,
    'aggregate_interval': 3600,
    'db_file': '',               # empty = /var/lib/zigmon/history.db

    # --- retention ----------------------------------------------------------
    'retain_full_days': 14,
    'retain_hourly_days': 730,
    'retain_events_days': 730,

    # --- thresholds used for the health verdict -----------------------------
    'battery_warn': 30,
    'battery_crit': 15,
    'lqi_warn': 40,
    'lqi_crit': 20,
    # A device that has not reported for this long is flagged, whatever the
    # bridge says about its availability. 0 disables it.
    'stale_warn_min': 180,
    'stale_crit_min': 1500,
    # Temperature and humidity limits, applied to every device. null = off.
    'temperature_min': None,
    'temperature_max': None,
    'humidity_max': None,

    # --- logging ------------------------------------------------------------
    'log_file': '/var/log/zigmon/zigmon.log',
    'log_level': 'info',
    'log_to_journal': True,

    # --- Shelly smart plugs, read and controlled over local RPC -------------
    # [{"name": "Lednice", "host": "172.16.16.12", "password": "", "switch_id": 0,
    #   "mqtt_name": ""}]  - mqtt_name: the plug's shellies/<name> prefix, so the
    # same device is not also picked up from MQTT.
    'plugs': [],
    'plug_poll_interval': 15,
    'plug_sample_interval': 60,
    'plug_min_request_gap': 1.0,
    'plug_timeout': 5.0,
    # Shelly sensors with an address of their own (an H&T on USB power answers
    # RPC; on battery it sleeps, and the webhook below is what carries it).
    # [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}]
    'sensors': [],
    # Accept webhook pushes from battery sensors that cannot be polled:
    #   http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=HT-Sklep
    'sensor_listen': False,
    'sensor_listen_host': '0.0.0.0',
    'sensor_listen_port': 8088,

    # --- the dashboard's PIN for permit-join and erasing data ---------------
    'pin': '',                   # empty disables the PIN (the token still applies)
    'pin_attempts': 5,
    'pin_lockout_s': 300,
}

CONFIG = dict(DEFAULTS)
CONFIG_NOTES = []
CONFIG_FATAL = []
DEBUG = False
LOG_HANDLE = None
LOG_PATH = None


def token_path():
    return Path(CONFIG.get('token_file') or str(TOKEN_FILE))


def db_path():
    return Path(CONFIG.get('db_file') or str(DB_FILE))


def _whoami():
    try:
        import pwd
        return pwd.getpwuid(os.geteuid()).pw_name
    except Exception:
        return str(os.geteuid())


def _coerce(current, value):
    """Make a config value the same type as its default, where that is sane."""
    if current is None:
        if value in ('', None):
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return value
    if isinstance(current, bool):
        if isinstance(value, str):
            return value.strip().lower() in ('1', 'true', 'yes', 'on')
        return bool(value)
    if isinstance(current, int):
        try:
            return int(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, float):
        try:
            return float(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, list):
        if isinstance(value, str):
            return [v.strip() for v in value.split(',') if v.strip()]
        return list(value) if isinstance(value, (list, tuple)) else current
    return value if value is not None else current


def load_config():
    """File first, then ZIGMON_* environment variables, which win."""
    if CONFIG_FILE.is_file():
        try:
            raw = json.loads(CONFIG_FILE.read_text())
            if not isinstance(raw, dict):
                CONFIG_FATAL.append('%s is not a JSON object' % CONFIG_FILE)
            else:
                for key, value in raw.items():
                    if key not in DEFAULTS:
                        CONFIG_NOTES.append('unknown option "%s" ignored' % key)
                        continue
                    CONFIG[key] = _coerce(DEFAULTS[key], value)
        except PermissionError:
            CONFIG_FATAL.append(
                '%s exists but cannot be read as %s. Fix with:  '
                'sudo chown root:%s %s && sudo chmod 640 %s'
                % (CONFIG_FILE, _whoami(), SERVICE_USER, CONFIG_FILE, CONFIG_FILE))
        except ValueError as e:
            CONFIG_FATAL.append('%s is not valid JSON: %s' % (CONFIG_FILE, e))
        except OSError as e:
            CONFIG_FATAL.append('could not read %s: %s' % (CONFIG_FILE, e))

    for key in DEFAULTS:
        env = os.environ.get('ZIGMON_' + key.upper())
        if env is not None:
            CONFIG[key] = _coerce(DEFAULTS[key], env)
            CONFIG_NOTES.append('%s taken from the environment' % key)
    return CONFIG


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def open_log(path=None):
    """Open the log file for appending. Safe to call again to reopen it."""
    global LOG_HANDLE, LOG_PATH
    close_log()
    path = path if path is not None else CONFIG.get('log_file')
    if not path:
        return None
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        LOG_HANDLE = open(str(target), 'a', encoding='utf-8')
        LOG_PATH = target
    except OSError as e:
        LOG_HANDLE, LOG_PATH = None, None
        sys.stderr.write('cannot write the log file %s: %s\n' % (path, e))
    return LOG_HANDLE


def ensure_log_current():
    """Reopen if the file we hold is no longer the one at the configured path."""
    if not LOG_HANDLE or not LOG_PATH:
        return False
    try:
        same = os.stat(str(LOG_PATH)).st_ino == os.fstat(LOG_HANDLE.fileno()).st_ino
    except OSError:
        same = False
    if same:
        return False
    open_log()
    log('log file reopened - it was rotated without a signal reaching us')
    return True


def close_log():
    global LOG_HANDLE
    if LOG_HANDLE:
        try:
            LOG_HANDLE.close()
        except OSError:
            pass
    LOG_HANDLE = None


def log(msg, level='info'):
    if level == 'debug' and not (DEBUG or CONFIG.get('log_level') == 'debug'):
        return
    line = '%s  %-5s %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), level, msg)
    if LOG_HANDLE:
        try:
            LOG_HANDLE.write(line + '\n')
            LOG_HANDLE.flush()
        except (OSError, ValueError):
            try:
                open_log()
                if LOG_HANDLE:
                    LOG_HANDLE.write(line + '\n')
                    LOG_HANDLE.flush()
            except Exception:
                pass
    if CONFIG.get('log_to_journal', True) or not LOG_HANDLE:
        stream = sys.stderr if level in ('error', 'warn') else sys.stdout
        stream.write(line + '\n')
        stream.flush()


# ---------------------------------------------------------------------------
# Units, labels and what a payload key means
# ---------------------------------------------------------------------------
# Zigbee2MQTT tells us the unit and label of every property in the device's
# "exposes" definition; these are the fallbacks for keys that arrive without
# one, and for the Shelly devices, which describe nothing.
KEY_INFO = {
    'temperature':   ('Temperature', '°C'),
    'humidity':      ('Humidity', '%'),
    'battery':       ('Battery', '%'),
    'voltage':       ('Voltage', 'mV'),
    'linkquality':   ('Link quality', 'lqi'),
    'illuminance':   ('Illuminance', 'lx'),
    'illuminance_lux': ('Illuminance', 'lx'),
    'light_level':   ('Light level', ''),
    'pressure':      ('Pressure', 'hPa'),
    'co2':           ('CO₂', 'ppm'),
    'pm25':          ('PM2.5', 'µg/m³'),
    'voc':           ('VOC', 'ppb'),
    'power':         ('Power', 'W'),
    'energy':        ('Energy', 'kWh'),
    'current':       ('Current', 'A'),
    'contact':       ('Contact', ''),
    'occupancy':     ('Occupancy', ''),
    'water_leak':    ('Water leak', ''),
    'vibration':     ('Vibration', ''),
    'tamper':        ('Tamper', ''),
    'battery_low':   ('Battery low', ''),
    'action':        ('Action', ''),
    'state':         ('State', ''),
    'position':      ('Position', '%'),
    'brightness':    ('Brightness', ''),
    'device_temperature': ('Device temperature', '°C'),
    'soil_moisture': ('Soil moisture', '%'),
    # Shelly Gen2/3 component fields
    'tC':            ('Temperature', '°C'),
    'tF':            ('Temperature', '°F'),
    'rh':            ('Humidity', '%'),
    'apower':        ('Power', 'W'),
    'aenergy.total': ('Energy total', 'Wh'),
    'battery.V':     ('Battery voltage', 'V'),
    'battery.percent': ('Battery', '%'),
    'external.present': ('External power', ''),
    'lux':           ('Illuminance', 'lx'),
    'switch.output': ('Output', ''),
    'switch.apower': ('Power', 'W'),
    'switch.voltage': ('Voltage', 'V'),
    'switch.current': ('Current', 'A'),
    'switch.pf':     ('Power factor', ''),
    'switch.freq':   ('Frequency', 'Hz'),
    'switch.aenergy.total': ('Energy total', 'Wh'),
    'switch.temperature.tC': ('Device temperature', '°C'),
    'switch.temperature.tF': ('Device temperature', '°F'),
    'pm1.apower':    ('Power', 'W'),
    'pm1.voltage':   ('Voltage', 'V'),
    'pm1.current':   ('Current', 'A'),
    'pm1.aenergy.total': ('Energy total', 'Wh'),
    'wifi.rssi':     ('WiFi signal', 'dBm'),
    'sys.uptime':    ('Uptime', 's'),
}

# Keys that are bookkeeping rather than measurements.
IGNORE_KEYS = {'last_seen', 'elapsed', 'update', 'update_available', 'linkquality_raw',
               'id', 'ts', 'transaction', 'src', 'dst', 'method', 'params', 'result',
               'device_temperature_unit', 'ret_aenergy.total'}

# Keys that count as a "reading" for the overview cards, in display order.
HEADLINE_KEYS = ['temperature', 'tC', 'humidity', 'rh', 'illuminance', 'illuminance_lux',
                 'lux', 'light_level', 'pressure', 'co2', 'pm25', 'voc', 'apower', 'power',
                 'energy', 'aenergy.total', 'switch.output', 'voltage', 'contact', 'occupancy',
                 'water_leak', 'position', 'brightness', 'state']


def key_info(key):
    """Look the key up, then every shorter dotted suffix of it."""
    parts = key.split('.')
    for i in range(len(parts)):
        info = KEY_INFO.get('.'.join(parts[i:]))
        if info:
            return info
    return None


def key_base(key):
    parts = key.split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in KEY_INFO:
            return candidate
    return parts[-1]


def headline_rank(key):
    parts = key.split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in HEADLINE_KEYS:
            return HEADLINE_KEYS.index(candidate)
    return None


def key_label(key):
    info = key_info(key)
    if info:
        return info[0]
    return key.replace('_', ' ').replace('.', ' · ').capitalize()


def key_unit(key):
    info = key_info(key)
    return info[1] if info else ''


def flatten(obj, prefix=''):
    """{'battery': {'V': 2.9}} -> {'battery.V': 2.9}. Lists are kept as-is."""
    out = {}
    if not isinstance(obj, dict):
        return out
    for key, value in obj.items():
        name = ('%s.%s' % (prefix, key)) if prefix else str(key)
        if isinstance(value, dict):
            out.update(flatten(value, name))
        else:
            out[name] = value
    return out


SENSOR_COMPONENTS = ('temperature', 'humidity', 'devicepower', 'illuminance')


def normalise_shelly_status(flat):
    """Shelly.GetStatus flattened -> the keys the dashboard knows.

    temperature:0.tC becomes tC, devicepower:0.battery.V becomes battery.V;
    switch:0.apower becomes switch.apower; wifi.rssi and sys.uptime stay.
    """
    out = {}
    for key, value in flat.items():
        if isinstance(value, (dict, list)):
            continue
        m = re.match(r'^([a-z_]+):(\d+)\.(.+)$', key)
        if m:
            component, index, rest = m.group(1), m.group(2), m.group(3)
            if rest in ('id', 'source') or 'by_minute' in rest or 'minute_ts' in rest:
                continue
            if component in SENSOR_COMPONENTS:
                out[rest if index == '0' else '%s%s.%s' % (component, index, rest)] = value
            elif component in ('switch', 'pm1', 'cover', 'light', 'input'):
                out['%s%s.%s' % (component, '' if index == '0' else index, rest)] = value
        elif key in ('wifi.rssi', 'wifi.sta_ip', 'wifi.ssid', 'sys.uptime', 'sys.ram_free',
                     'cloud.connected', 'mqtt.connected'):
            out[key] = value
    return out


def numeric(value):
    """A float for anything worth charting, or None."""
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        v = value.strip().upper()
        if v in ('ON', 'OPEN', 'TRUE', 'OCCUPIED', 'YES'):
            return 1.0
        if v in ('OFF', 'CLOSE', 'CLOSED', 'FALSE', 'CLEAR', 'NO'):
            return 0.0
        try:
            return float(value)
        except ValueError:
            return None
    return None


def parse_span(text):
    """'6h', '24h', '7d', '30d', '1y', '90m' -> seconds."""
    m = re.match(r'^\s*(\d+(?:\.\d+)?)\s*([smhdwy])?\s*$', str(text or ''))
    if not m:
        raise ValueError('bad range %r (use e.g. 24h, 7d, 1y)' % text)
    n = float(m.group(1))
    unit = m.group(2) or 'h'
    mult = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400, 'w': 604800, 'y': 31557600}[unit]
    return int(n * mult)


def human_age(seconds):
    if seconds is None:
        return 'never'
    seconds = int(seconds)
    if seconds < 60:
        return '%ds' % seconds
    if seconds < 3600:
        return '%dm' % (seconds // 60)
    if seconds < 86400:
        return '%dh %dm' % (seconds // 3600, (seconds % 3600) // 60)
    return '%dd %dh' % (seconds // 86400, (seconds % 86400) // 3600)


def thin(rows, points):
    """Keep at most `points` rows, evenly spaced, always keeping the last one."""
    if points <= 0 or len(rows) <= points:
        return rows
    step = len(rows) / float(points)
    out = [rows[int(i * step)] for i in range(points)]
    if out[-1] is not rows[-1]:
        out.append(rows[-1])
    return out


# ---------------------------------------------------------------------------
# Shelly Gen2+ RPC (the smart plugs)
# ---------------------------------------------------------------------------
class PlugError(Exception):
    pass


class ShellyRPC(object):
    """Minimal JSON-RPC client for a Shelly Gen2+ device, standard library only.

    Shelly answers the first request with 401 and a challenge, and expects
    SHA-256 digest with qop=auth; urllib's own digest handler predates SHA-256
    on the Python AlmaLinux 9 ships, so it is done by hand. One challenge is
    reused for every later call with the nonce counter stepping on each time,
    because re-authenticating doubles the request count and a Gen3 plug
    answers 429 when that adds up.
    """
    _challenges = {}
    _last_request = {}
    _pace = threading.Lock()

    def __init__(self, host, password='', switch_id=0, label='the plug'):
        self.host = host
        self.password = password or ''
        self.switch_id = int(switch_id or 0)
        self.timeout = float(CONFIG.get('plug_timeout') or 5.0)
        self.retry_after = 0.0
        self.label = label

    @property
    def url(self):
        return 'http://%s/rpc' % self.host

    def call(self, method, params=None):
        if not self.host:
            raise PlugError('no host configured for %s' % self.label)
        payload = {'id': 1, 'method': method}
        if params:
            payload['params'] = params
        body = json.dumps(payload).encode('utf-8')
        known = self._challenges.get(self.host)
        auth = self._digest_header(known, 'POST', '/rpc') if known else None
        status, reply, headers = self._post(body, auth)
        if status == 401:
            challenge = headers.get('WWW-Authenticate', '')
            if not self.password:
                raise PlugError('%s requires a password; set it in the config' % self.label)
            self._challenges[self.host] = self._parse_challenge(challenge)
            status, reply, headers = self._post(
                body, self._digest_header(self._challenges[self.host], 'POST', '/rpc'))
            if status == 401:
                self._challenges.pop(self.host, None)
                raise PlugError('%s rejected the password' % self.label)
        if status == 429:
            retry = headers.get('Retry-After')
            self.retry_after = numeric(retry) or 0
            attempt = getattr(self, '_retries', 0)
            if attempt < 3:
                self._retries = attempt + 1
                delay = min(max(self.retry_after, 2.0) * (attempt + 1), 15.0)
                log('%s asked us to wait; retrying in %.0fs' % (self.label, delay), 'debug')
                time.sleep(delay)
                try:
                    return self.call(method, params)
                finally:
                    self._retries = attempt
            raise PlugError('%s is rate limiting us (HTTP 429)' % self.label)
        if status != 200:
            raise PlugError('%s answered HTTP %s' % (self.label, status))
        try:
            result = json.loads(reply.decode('utf-8'))
        except ValueError:
            raise PlugError('%s did not return JSON - is it a Gen2+ device?' % self.label)
        if 'error' in result:
            error = result['error']
            raise PlugError('RPC error %s: %s' % (error.get('code'), error.get('message')))
        return result.get('result')

    def _wait_turn(self):
        gap = float(CONFIG.get('plug_min_request_gap') or 0)
        if gap <= 0:
            return
        with self._pace:
            previous = self._last_request.get(self.host, 0.0)
            delay = previous + gap - time.time()
            if delay > 0:
                time.sleep(min(delay, gap))
            self._last_request[self.host] = time.time()

    def _post(self, body, auth=None):
        import urllib.request
        import urllib.error
        self._wait_turn()
        request = urllib.request.Request(self.url, data=body, method='POST')
        request.add_header('Content-Type', 'application/json')
        if auth:
            request.add_header('Authorization', auth)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return response.status, response.read(), dict(response.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)
        except OSError as e:
            raise PlugError('cannot reach %s at %s (%s)' % (self.label, self.host, e))

    @staticmethod
    def _parse_challenge(header):
        fields = dict(re.findall(r'(\w+)="?([^",]+)"?', header))
        fields['nc'] = 0
        return fields

    def _digest_header(self, fields, method, path):
        import hashlib
        algorithm = (fields.get('algorithm') or 'SHA-256').upper()
        digest = hashlib.sha256 if 'SHA-256' in algorithm else hashlib.md5

        def h(text):
            return digest(text.encode('utf-8')).hexdigest()

        realm = fields.get('realm', '')
        nonce = fields.get('nonce', '')
        fields['nc'] = int(fields.get('nc', 0)) + 1
        nc = '%08x' % fields['nc']
        cnonce = secrets.token_hex(8)
        ha1 = h('admin:%s:%s' % (realm, self.password))
        ha2 = h('%s:%s' % (method, path))
        response = h('%s:%s:%s:%s:auth:%s' % (ha1, nonce, nc, cnonce, ha2))
        return ('Digest username="admin", realm="%s", nonce="%s", uri="%s", '
                'algorithm=%s, qop=auth, nc=%s, cnonce="%s", response="%s"'
                % (realm, nonce, path, algorithm, nc, cnonce, response))

    # -- the calls this daemon makes ---------------------------------------
    def switch_status(self):
        return self.call('Switch.GetStatus', {'id': self.switch_id})

    def device_status(self):
        return self.call('Shelly.GetStatus')

    def device_info(self):
        return self.call('Shelly.GetDeviceInfo')

    def set_output(self, on):
        return self.call('Switch.Set', {'id': self.switch_id, 'on': bool(on)})

    def reset_counters(self, types=None):
        params = {'id': self.switch_id}
        if types:
            params['type'] = list(types)
        try:
            return self.call('Switch.ResetCounters', params)
        except PlugError:
            accepted = []
            for one in (types or PLUG_COUNTER_TYPES):
                try:
                    self.call('Switch.ResetCounters', {'id': self.switch_id, 'type': [one]})
                    accepted.append(one)
                except PlugError:
                    continue
            if not accepted:
                raise
            return {'reset': accepted}


# What Switch.ResetCounters accepts, in the order the plug's own web UI lists
# them. Sending no type at all resets everything.
PLUG_COUNTERS = [
    {'type': 'aenergy',      'label': 'Active energy',      'field': 'aenergy.total',
     'help': 'the energy consumed since the last reset'},
    {'type': 'ret_aenergy',  'label': 'Returned energy',    'field': 'ret_aenergy.total',
     'help': 'energy fed back to the grid; always zero on a plain socket'},
    {'type': 'on_time',      'label': 'Total runtime',      'field': 'counts.on_time',
     'help': 'how long the relay has been switched on, in total'},
    {'type': 'switch_on',    'label': 'Switching cycles',   'field': 'counts.switch_on',
     'help': 'how many times the relay has been switched on'},
    {'type': 'on_above_thr', 'label': 'Active load runtime', 'field': 'counts.on_above_thr',
     'help': 'time spent above the active load threshold set on the plug'},
]
PLUG_COUNTER_TYPES = [c['type'] for c in PLUG_COUNTERS]
PLUG_RESET_FIELDS = {
    'aenergy': 'aenergy.total_rst_ts', 'ret_aenergy': 'ret_aenergy.total_rst_ts',
    'on_time': 'counts.on_time_rst_ts', 'switch_on': 'counts.switch_on_rst_ts',
    'on_above_thr': 'counts.on_above_thr_rst_ts',
}

PLUG_DESCRIPTIONS = {
    'switch.output': 'Relay output',
    'switch.apower': 'Active power (W)',
    'switch.voltage': 'Voltage (V)',
    'switch.current': 'Current (A)',
    'switch.pf': 'Power factor',
    'switch.freq': 'Line frequency (Hz)',
    'switch.aenergy.total': 'Energy consumed since the counters were reset (Wh)',
    'switch.ret_aenergy.total': 'Energy returned to the grid (Wh)',
    'switch.temperature.tC': 'Plug temperature (°C)',
    'switch.counts.on_time': 'Total runtime - time the relay has been on (s)',
    'switch.counts.switch_on': 'Switching cycles - times the relay has been switched on',
    'switch.counts.on_above_thr': 'Active load runtime - time above the plug threshold (s)',
    'sys.uptime': 'Plug uptime (s)',
    'sys.ram_free': 'Free RAM (bytes)',
    'wifi.rssi': 'Wi-Fi signal (dBm)',
    'wifi.sta_ip': 'Plug IP address',
    'wifi.ssid': 'Wi-Fi network',
    'cloud.connected': 'Shelly Cloud',
    'mqtt.connected': 'MQTT broker',
}
BINDING_ACTIONS = ['toggle', 'on', 'off']
PLUG_HEADLINE = ['switch.apower', 'switch.aenergy.total', 'switch.output', 'switch.voltage']


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
# Readings are stored as (device, key, value) rows rather than in fixed
# columns, because what one sensor reports is not what the next one does.
# Full resolution is kept for a fortnight, hourly averages for two years; the
# latest complete payload of every device sits in `snapshots`.
SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    id          TEXT PRIMARY KEY,       -- IEEE address, or shelly:<name>
    name        TEXT NOT NULL,          -- friendly name (the MQTT topic)
    source      TEXT NOT NULL,          -- zigbee | shelly | mqtt
    kind        TEXT,                   -- EndDevice | Router | Coordinator | wifi
    model       TEXT,
    vendor      TEXT,
    description TEXT,
    exposes     TEXT,                   -- JSON: key -> {label, unit, description}
    first_seen  INTEGER,
    last_seen   INTEGER,
    removed     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS samples (
    ts      INTEGER NOT NULL,
    device  TEXT    NOT NULL,
    key     TEXT    NOT NULL,
    value   REAL,
    PRIMARY KEY (device, key, ts)
);
CREATE INDEX IF NOT EXISTS samples_ts ON samples (ts);

CREATE TABLE IF NOT EXISTS samples_hourly (
    ts      INTEGER NOT NULL,
    device  TEXT    NOT NULL,
    key     TEXT    NOT NULL,
    n       INTEGER,
    avg     REAL,
    min     REAL,
    max     REAL,
    PRIMARY KEY (device, key, ts)
);
CREATE INDEX IF NOT EXISTS samples_hourly_ts ON samples_hourly (ts);

CREATE TABLE IF NOT EXISTS snapshots (
    device  TEXT PRIMARY KEY,
    ts      INTEGER NOT NULL,
    payload TEXT NOT NULL,
    availability TEXT
);

CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      INTEGER NOT NULL,
    device  TEXT,
    kind    TEXT NOT NULL,
    level   TEXT,
    detail  TEXT
);
CREATE INDEX IF NOT EXISTS events_ts ON events (ts);

CREATE TABLE IF NOT EXISTS meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);
"""


class StorageError(Exception):
    pass


class Storage(object):
    def __init__(self, path=None):
        self.path = Path(path) if path else db_path()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        try:
            self.db = sqlite3.connect(str(self.path), check_same_thread=False,
                                      timeout=15, isolation_level=None)
        except sqlite3.OperationalError as e:
            raise StorageError('cannot open %s: %s' % (self.path, e))
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=NORMAL')
        self.db.executescript(SCHEMA)
        self.last_sample = {}     # (device, key) -> ts of the last row written

    # -- devices --------------------------------------------------------------
    def upsert_device(self, dev):
        now = int(time.time())
        with self.lock:
            row = self.db.execute('SELECT * FROM devices WHERE id=?', (dev['id'],)).fetchone()
            if row is None:
                self.db.execute(
                    'INSERT INTO devices (id,name,source,kind,model,vendor,description,'
                    'exposes,first_seen,last_seen,removed) VALUES (?,?,?,?,?,?,?,?,?,?,0)',
                    (dev['id'], dev['name'], dev['source'], dev.get('kind'), dev.get('model'),
                     dev.get('vendor'), dev.get('description'),
                     json.dumps(dev.get('exposes') or {}), now, dev.get('last_seen')))
                return 'new'
            changed = 'renamed' if row['name'] != dev['name'] else None
            self.db.execute(
                'UPDATE devices SET name=?,source=?,kind=COALESCE(?,kind),model=COALESCE(?,model),'
                'vendor=COALESCE(?,vendor),description=COALESCE(?,description),'
                'exposes=CASE WHEN ? THEN ? ELSE exposes END,removed=0 WHERE id=?',
                (dev['name'], dev['source'], dev.get('kind'), dev.get('model'), dev.get('vendor'),
                 dev.get('description'), 1 if dev.get('exposes') else 0,
                 json.dumps(dev.get('exposes') or {}), dev['id']))
            if changed:
                return changed
            return 'known'

    def mark_removed(self, device_id):
        with self.lock:
            self.db.execute('UPDATE devices SET removed=1 WHERE id=?', (device_id,))

    def touch_device(self, device_id, ts):
        with self.lock:
            self.db.execute('UPDATE devices SET last_seen=? WHERE id=?', (ts, device_id))

    def devices(self, include_removed=False):
        with self.lock:
            sql = 'SELECT * FROM devices' + ('' if include_removed else ' WHERE removed=0')
            rows = self.db.execute(sql + ' ORDER BY name COLLATE NOCASE').fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d['exposes'] = json.loads(d.get('exposes') or '{}')
            except ValueError:
                d['exposes'] = {}
            out.append(d)
        return out

    def device(self, device_id):
        with self.lock:
            r = self.db.execute('SELECT * FROM devices WHERE id=?', (device_id,)).fetchone()
        if r is None:
            return None
        d = dict(r)
        try:
            d['exposes'] = json.loads(d.get('exposes') or '{}')
        except ValueError:
            d['exposes'] = {}
        return d

    def resolve(self, name_or_id):
        """Accept an IEEE address, an id or a friendly name."""
        with self.lock:
            r = self.db.execute('SELECT id FROM devices WHERE id=? OR name=? COLLATE NOCASE',
                                (name_or_id, name_or_id)).fetchone()
        return r['id'] if r else None

    # -- readings -------------------------------------------------------------
    def store_sample(self, device_id, ts, values):
        """values: {key: float}. Honour sample_interval by replacing the row."""
        gap = int(CONFIG.get('sample_interval') or 0)
        with self.lock:
            for key, value in values.items():
                prev = self.last_sample.get((device_id, key))
                if prev is None:
                    r = self.db.execute('SELECT MAX(ts) AS ts FROM samples WHERE device=? AND key=?',
                                        (device_id, key)).fetchone()
                    prev = r['ts'] if r and r['ts'] is not None else 0
                if gap and prev and ts - prev < gap and prev != ts:
                    self.db.execute('UPDATE samples SET value=? WHERE device=? AND key=? AND ts=?',
                                    (value, device_id, key, prev))
                    continue
                self.db.execute('INSERT OR REPLACE INTO samples (ts,device,key,value) VALUES (?,?,?,?)',
                                (ts, device_id, key, value))
                self.last_sample[(device_id, key)] = ts

    def store_snapshot(self, device_id, ts, payload, availability=None):
        with self.lock:
            row = self.db.execute('SELECT payload, availability FROM snapshots WHERE device=?',
                                  (device_id,)).fetchone()
            merged = {}
            if row:
                try:
                    merged = json.loads(row['payload'])
                except ValueError:
                    merged = {}
                if availability is None:
                    availability = row['availability']
            merged.update(payload or {})
            self.db.execute('INSERT OR REPLACE INTO snapshots (device,ts,payload,availability) '
                            'VALUES (?,?,?,?)', (device_id, ts, json.dumps(merged), availability))
        return merged

    def snapshots(self):
        with self.lock:
            rows = self.db.execute('SELECT * FROM snapshots').fetchall()
        out = {}
        for r in rows:
            try:
                payload = json.loads(r['payload'])
            except ValueError:
                payload = {}
            out[r['device']] = {'ts': r['ts'], 'payload': payload,
                                'availability': r['availability']}
        return out

    def keys_for(self, device_id):
        with self.lock:
            a = self.db.execute('SELECT DISTINCT key FROM samples WHERE device=?', (device_id,)).fetchall()
            b = self.db.execute('SELECT DISTINCT key FROM samples_hourly WHERE device=?',
                                (device_id,)).fetchall()
        return sorted({r['key'] for r in a} | {r['key'] for r in b})

    def history(self, device_id, keys, seconds, points=600):
        """Rows of {ts, key1, key2, ...} mixing hourly data for the old part."""
        now = int(time.time())
        since = now - seconds
        full_from = now - int(CONFIG.get('retain_full_days', 14)) * 86400
        rows = {}
        with self.lock:
            for key in keys:
                if since < full_from:
                    for r in self.db.execute(
                            'SELECT ts, avg AS value, min, max FROM samples_hourly '
                            'WHERE device=? AND key=? AND ts>=? AND ts<? ORDER BY ts',
                            (device_id, key, since, full_from)):
                        rows.setdefault(r['ts'], {'ts': r['ts']})[key] = r['value']
                        rows[r['ts']][key + '_min'] = r['min']
                        rows[r['ts']][key + '_max'] = r['max']
                for r in self.db.execute(
                        'SELECT ts, value FROM samples WHERE device=? AND key=? AND ts>=? ORDER BY ts',
                        (device_id, key, max(since, full_from))):
                    rows.setdefault(r['ts'], {'ts': r['ts']})[key] = r['value']
        ordered = [rows[t] for t in sorted(rows)]
        return thin(ordered, points)

    # -- events ---------------------------------------------------------------
    def add_event(self, kind, detail='', level='info', device=None, ts=None):
        ts = ts or int(time.time())
        with self.lock:
            self.db.execute('INSERT INTO events (ts,device,kind,level,detail) VALUES (?,?,?,?,?)',
                            (ts, device, kind, level, detail))

    def events(self, limit=100, device=None):
        with self.lock:
            if device:
                rows = self.db.execute('SELECT * FROM events WHERE device=? ORDER BY ts DESC, id DESC '
                                       'LIMIT ?', (device, limit)).fetchall()
            else:
                rows = self.db.execute('SELECT * FROM events ORDER BY ts DESC, id DESC LIMIT ?',
                                       (limit,)).fetchall()
        return [dict(r) for r in rows]

    def actions_seen(self, device_id):
        """Every distinct action this device has ever reported, most recent first."""
        with self.lock:
            rows = self.db.execute("SELECT detail, MAX(ts) AS ts FROM events WHERE device=? AND kind='action' "
                                   "GROUP BY detail ORDER BY ts DESC", (device_id,)).fetchall()
        return [r['detail'] for r in rows if r['detail']]

    # -- meta -----------------------------------------------------------------
    def get_meta(self, key, default=None):
        with self.lock:
            r = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        return r['value'] if r else default

    def set_meta(self, key, value):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO meta (key,value) VALUES (?,?)', (key, str(value)))

    # -- housekeeping ---------------------------------------------------------
    def aggregate(self):
        """Roll full-resolution rows older than two hours into hourly buckets."""
        now = int(time.time())
        cutoff = (now // 3600) * 3600 - 7200
        done = 0
        with self.lock:
            r = self.db.execute("SELECT value FROM meta WHERE key='aggregated_to'").fetchone()
            start = int(r['value']) if r else 0
            if start >= cutoff:
                return 0
            self.db.execute('BEGIN')
            try:
                cur = self.db.execute(
                    'INSERT OR REPLACE INTO samples_hourly (ts,device,key,n,avg,min,max) '
                    'SELECT (ts/3600)*3600, device, key, COUNT(*), AVG(value), MIN(value), MAX(value) '
                    'FROM samples WHERE ts>=? AND ts<? GROUP BY device, key, ts/3600',
                    (start, cutoff))
                done = cur.rowcount if cur.rowcount is not None else 0
                self.db.execute("INSERT OR REPLACE INTO meta (key,value) VALUES ('aggregated_to',?)",
                                (str(cutoff),))
                full_days = int(CONFIG.get('retain_full_days', 14))
                hourly_days = int(CONFIG.get('retain_hourly_days', 730))
                event_days = int(CONFIG.get('retain_events_days', 730))
                self.db.execute('DELETE FROM samples WHERE ts<?', (now - full_days * 86400,))
                self.db.execute('DELETE FROM samples_hourly WHERE ts<?', (now - hourly_days * 86400,))
                self.db.execute('DELETE FROM events WHERE ts<?', (now - event_days * 86400,))
                self.db.execute('COMMIT')
            except Exception:
                self.db.execute('ROLLBACK')
                raise
        return done

    def reset(self, scope, device_id=None):
        """Erase recorded data. scope: all, history, events, device."""
        with self.lock:
            if scope == 'all':
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    self.db.execute('DELETE FROM %s' % table)
                self.db.execute("DELETE FROM meta WHERE key NOT IN ('bindings')")
                self.db.execute('DELETE FROM devices')
            elif scope == 'history':
                for table in ('samples', 'samples_hourly'):
                    self.db.execute('DELETE FROM %s' % table)
                self.db.execute("DELETE FROM meta WHERE key='aggregated_to'")
            elif scope == 'events':
                self.db.execute('DELETE FROM events')
            elif scope == 'device' and device_id:
                for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                    self.db.execute('DELETE FROM %s WHERE device=?' % table, (device_id,))
                self.db.execute('DELETE FROM devices WHERE id=?', (device_id,))
            else:
                raise ValueError('unknown scope %r' % scope)
            self.last_sample.clear()
        try:
            self.db.execute('VACUUM')
        except sqlite3.OperationalError:
            pass

    def stats(self):
        with self.lock:
            out = {}
            for table in ('devices', 'samples', 'samples_hourly', 'events', 'snapshots'):
                out[table] = self.db.execute('SELECT COUNT(*) AS n FROM %s' % table).fetchone()['n']
            r = self.db.execute('SELECT MIN(ts) AS a FROM samples_hourly').fetchone()
            r2 = self.db.execute('SELECT MIN(ts) AS a FROM samples').fetchone()
            oldest = [x for x in (r['a'], r2['a']) if x]
            out['oldest'] = min(oldest) if oldest else None
        try:
            size = self.path.stat().st_size
            wal = self.path.with_name(self.path.name + '-wal')
            if wal.exists():
                size += wal.stat().st_size
            out['bytes'] = size
        except OSError:
            out['bytes'] = None
        out['path'] = str(self.path)
        return out


# ---------------------------------------------------------------------------
# MQTT
# ---------------------------------------------------------------------------
def make_mqtt_client(client_id, clean=True):
    """A paho client that works with both the 1.x and the 2.x API."""
    if mqtt is None:
        raise RuntimeError('python3-paho-mqtt is not installed')
    if hasattr(mqtt, 'CallbackAPIVersion'):
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id,
                             clean_session=clean)
    else:
        client = mqtt.Client(client_id=client_id, clean_session=clean)
    if CONFIG.get('mqtt_username'):
        client.username_pw_set(CONFIG['mqtt_username'], CONFIG.get('mqtt_password') or None)
    if CONFIG.get('mqtt_tls'):
        ca = CONFIG.get('mqtt_ca') or None
        if ca:
            client.tls_set(ca_certs=ca, cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)
        else:
            client.tls_set(cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLS_CLIENT)
            client.tls_insecure_set(True)
    client.reconnect_delay_set(min_delay=2, max_delay=60)
    return client


def reason_text(rc):
    """paho 1.x gives an int, 2.x a ReasonCode; both print sensibly."""
    try:
        if hasattr(rc, 'is_failure'):
            return str(rc)
        return mqtt.connack_string(rc) if mqtt else str(rc)
    except Exception:
        return str(rc)


def rc_failed(rc):
    if hasattr(rc, 'is_failure'):
        return rc.is_failure
    return int(rc) != 0


def exposes_map(definition):
    """Zigbee2MQTT's exposes tree -> {property: {label, unit, description, type}}."""
    out = {}

    def walk(items, prefix=''):
        for item in items or []:
            if not isinstance(item, dict):
                continue
            prop = item.get('property')
            if prop:
                name = (prefix + prop) if prefix else prop
                out[name] = {
                    'label': item.get('label') or key_label(name),
                    'unit': item.get('unit') or key_unit(name),
                    'description': item.get('description') or '',
                    'type': item.get('type') or '',
                    'category': item.get('category') or '',
                    'values': item.get('values') or None,
                    'min': item.get('value_min'),
                    'max': item.get('value_max'),
                }
            if item.get('features'):
                sub = (prefix + prop + '.') if prop else prefix
                walk(item['features'], sub)

    if isinstance(definition, dict):
        walk(definition.get('exposes'))
    return out


class PlugState(object):
    """Everything the daemon remembers about one configured plug."""

    def __init__(self, name, cfg):
        self.name = name
        self.cfg = cfg
        self.device_id = 'plug:' + name
        self.info = None
        self.device_status = None
        self.last_device_status = 0.0
        self.last_poll = 0.0
        self.last_sample = 0.0
        self.backoff_until = 0.0
        self.failures = 0
        self.error = None
        self.output = None
        self.flat = {}
        self.generated = None

    def rpc(self):
        return ShellyRPC(self.cfg.get('host'), self.cfg.get('password') or '',
                         self.cfg.get('switch_id') or 0, label='plug %s' % self.name)


# ---------------------------------------------------------------------------
# The daemon
# ---------------------------------------------------------------------------
class Daemon(object):
    def __init__(self, storage=None):
        open_log()
        self.store = storage or Storage()
        self.lock = threading.Lock()
        self.token = self._ensure_token()
        self.started = time.time()
        self.connected = False
        self.last_connect = None
        self.last_disconnect = None
        self.connect_failures = 0
        self.last_error = None
        self.messages = 0
        self.last_message_at = None
        self.last_aggregate_at = 0.0
        self.bridge = {'state': None, 'version': None, 'coordinator': None,
                       'permit_join': None, 'permit_join_end': None, 'channel': None,
                       'pan_id': None, 'log_level': None, 'updated': None}
        self.names = {}          # friendly name -> device id (zigbee)
        self.live = {}           # device id -> {'payload', 'ts', 'availability'}
        self.pin_failures = 0
        self.pin_locked_until = 0.0
        self.client = None
        self._stop = threading.Event()
        self.plugs = {}          # name -> PlugState
        self.sensors = {}        # name -> PlugState, for Shelly sensors polled over RPC
        self.pushes_received = 0
        self.pushes_rejected = 0
        self.last_push_at = None
        self._plug_lock = threading.Lock()
        self.setup_plugs()
        self.setup_sensors()
        # What was recorded before the restart is the starting point, so the
        # dashboard is never blank while waiting for sleepy devices to report.
        for dev in self.store.devices():
            if dev['source'] == 'zigbee':
                self.names[dev['name']] = dev['id']
        for device_id, snap in self.store.snapshots().items():
            self.live[device_id] = snap

    # -- API token ----------------------------------------------------------
    def _ensure_token(self):
        token = None
        try:
            token = TOKEN_FILE.read_text().strip() or None
        except OSError:
            pass
        token = token or secrets.token_urlsafe(32)
        path = token_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(token)
            path.chmod(0o640)
            import grp
            import pwd
            info = path.stat()
            log('API token at %s (owner %s, group %s, mode %o)'
                % (path, pwd.getpwuid(info.st_uid).pw_name,
                   grp.getgrgid(info.st_gid).gr_name, info.st_mode & 0o777))
        except OSError as e:
            log('cannot write the API token to %s: %s - the privileged '
                'endpoints will refuse every request' % (path, e), 'error')
        return token

    # -- MQTT plumbing ------------------------------------------------------
    def connect(self):
        self.client = make_mqtt_client(CONFIG.get('mqtt_client_id') or 'zigmon')
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        if hasattr(self.client, 'on_connect_fail'):
            self.client.on_connect_fail = self._on_connect_fail
        host, port = CONFIG['mqtt_host'], int(CONFIG['mqtt_port'])
        log('connecting to mqtt://%s:%d as %s' % (host, port, CONFIG.get('mqtt_username') or 'anonymous'))
        try:
            self.client.connect_async(host, port, int(CONFIG.get('mqtt_keepalive') or 60))
        except (OSError, ValueError) as e:
            self.last_error = str(e)
            log('connect: %s' % e, 'error')
        self.client.loop_start()

    def topics(self):
        base = CONFIG['base_topic'].rstrip('/')
        wanted = [(base + '/#', 0)]
        for extra in CONFIG.get('extra_topics') or []:
            if extra and extra.rstrip('/') != base:
                wanted.append((extra, 0))
        return wanted

    def _on_connect(self, client, userdata, flags, rc, *rest):
        if rc_failed(rc):
            self.connect_failures += 1
            self.last_error = 'connect refused: %s' % reason_text(rc)
            log(self.last_error, 'error')
            return
        self.connected = True
        self.last_connect = time.time()
        self.last_error = None
        client.subscribe(self.topics())
        log('connected; subscribed to %s' % ', '.join(t for t, _ in self.topics()))
        self.store.add_event('broker', 'connected to %s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port']))

    def _on_connect_fail(self, client, userdata, *rest):
        self.connect_failures += 1
        self.last_error = 'cannot reach the broker at %s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port'])
        # paho retries by itself; one line per minute is enough noise.
        if self.connect_failures in (1, 2) or self.connect_failures % 30 == 0:
            log(self.last_error + ' (attempt %d)' % self.connect_failures, 'warn')

    def _on_disconnect(self, client, userdata, *rest):
        # paho 2.x: (client, userdata, flags, reason_code, properties); 1.x: (client, userdata, rc)
        rc = rest[1] if len(rest) >= 2 else (rest[0] if rest else 0)
        was = self.connected
        self.connected = False
        self.last_disconnect = time.time()
        if was and not self._stop.is_set():
            self.last_error = 'broker connection lost (%s)' % reason_text(rc)
            log(self.last_error, 'warn')
            self.store.add_event('broker', 'connection lost', 'warn')

    def _on_message(self, client, userdata, msg):
        self.messages += 1
        self.last_message_at = time.time()
        try:
            self.handle(msg.topic, msg.payload)
        except Exception as e:      # one bad payload must never stop the feed
            log('handling %s: %s' % (msg.topic, e), 'error')

    # -- message routing ----------------------------------------------------
    def handle(self, topic, raw):
        base = CONFIG['base_topic'].rstrip('/')
        if topic == base or topic.startswith(base + '/'):
            rest = topic[len(base) + 1:] if topic != base else ''
            self.handle_zigbee(rest, raw)
            return
        parts = topic.split('/')
        if len(parts) >= 2:
            self.handle_generic(parts, raw)

    @staticmethod
    def decode(raw):
        text = raw.decode('utf-8', 'replace').strip() if isinstance(raw, bytes) else str(raw)
        if not text:
            return None
        if text[0] in '{[':
            try:
                return json.loads(text)
            except ValueError:
                return text
        return text

    def handle_zigbee(self, rest, raw):
        parts = rest.split('/')
        if not parts or not parts[0]:
            return
        if parts[0] == 'bridge':
            self.handle_bridge(parts[1:], raw)
            return
        name = parts[0]
        sub = parts[1] if len(parts) > 1 else ''
        if sub in ('set', 'get'):
            return
        payload = self.decode(raw)
        device_id = self.names.get(name)
        if sub == 'availability':
            state = payload.get('state') if isinstance(payload, dict) else payload
            if isinstance(state, str):
                self.set_availability(device_id or self.adopt_unknown(name), state.lower(), name)
            return
        if sub:
            return          # some other sub-topic we do not care about
        if not isinstance(payload, dict):
            return
        if device_id is None:
            device_id = self.adopt_unknown(name)
        self.record(device_id, name, payload)

    def adopt_unknown(self, name):
        """A device the bridge list has not told us about yet."""
        device_id = 'name:' + name
        self.names[name] = device_id
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'zigbee',
                                      'kind': None, 'exposes': {}})
            log('device "%s" seen before the bridge listed it' % name)
        return device_id

    def handle_bridge(self, parts, raw):
        what = parts[0] if parts else ''
        payload = self.decode(raw)
        now = int(time.time())
        if what == 'state':
            state = payload.get('state') if isinstance(payload, dict) else payload
            state = str(state).lower() if state is not None else None
            old = self.bridge['state']
            self.bridge['state'] = state
            self.bridge['updated'] = now
            if old != state:
                log('bridge is %s' % state)
                if old is not None or state != 'online':
                    self.store.add_event('bridge', 'Zigbee2MQTT is %s' % state,
                                         'info' if state == 'online' else 'crit')
        elif what == 'info' and isinstance(payload, dict):
            coord = payload.get('coordinator') or {}
            meta = coord.get('meta') or {}
            net = payload.get('network') or {}
            self.bridge.update({
                'version': payload.get('version'),
                'coordinator': ('%s %s' % (coord.get('type') or '', meta.get('revision') or '')).strip() or None,
                'coordinator_ieee': coord.get('ieee_address'),
                'permit_join': payload.get('permit_join'),
                'permit_join_end': payload.get('permit_join_end'),
                'channel': net.get('channel'),
                'pan_id': net.get('pan_id'),
                'log_level': payload.get('log_level'),
                'updated': now,
            })
        elif what == 'devices' and isinstance(payload, list):
            self.sync_devices(payload)
        elif what == 'event' and isinstance(payload, dict):
            self.bridge_event(payload)
        elif what == 'logging' and isinstance(payload, dict):
            level = str(payload.get('level') or '').lower()
            if level in ('error',):
                self.store.add_event('bridge', str(payload.get('message') or '')[:300], 'warn')
        # request/response/definitions/groups/extensions: nothing to record

    def sync_devices(self, devices):
        seen = set()
        for d in devices:
            if not isinstance(d, dict):
                continue
            ieee = d.get('ieee_address')
            name = d.get('friendly_name') or ieee
            if not ieee or not name:
                continue
            if d.get('type') == 'Coordinator':
                self.bridge['coordinator_name'] = name
                continue
            definition = d.get('definition') or {}
            dev = {
                'id': ieee, 'name': name, 'source': 'zigbee',
                'kind': d.get('type'),
                'model': definition.get('model') or d.get('model_id'),
                'vendor': definition.get('vendor') or d.get('manufacturer'),
                'description': definition.get('description'),
                'exposes': exposes_map(definition),
                'power_source': d.get('power_source'),
            }
            seen.add(ieee)
            # A device that reported before the list arrived was filed under
            # its name; move that history across now that we know its address.
            placeholder = 'name:' + name
            if self.store.device(placeholder) and not self.store.device(ieee):
                self.migrate(placeholder, ieee)
            old_name = None
            for n, i in list(self.names.items()):
                if i == ieee and n != name:
                    old_name = n
                    del self.names[n]
            self.names[name] = ieee
            outcome = self.store.upsert_device(dev)
            if outcome == 'new':
                log('new device: %s (%s %s)' % (name, dev['vendor'] or '', dev['model'] or ''))
                self.store.add_event('device', 'added: %s %s' % (dev['vendor'] or '', dev['model'] or ''),
                                     'info', ieee)
            elif outcome == 'renamed':
                log('device renamed: %s -> %s' % (old_name or '?', name))
                self.store.add_event('device', 'renamed from "%s" to "%s"' % (old_name or '?', name),
                                     'info', ieee)
        for dev in self.store.devices():
            if dev['source'] == 'zigbee' and dev['id'] not in seen and not dev['id'].startswith('name:'):
                self.store.mark_removed(dev['id'])
                self.names.pop(dev['name'], None)
                log('device left: %s' % dev['name'])
                self.store.add_event('device', 'removed from the network', 'warn', dev['id'])

    def migrate(self, old_id, new_id):
        with self.store.lock:
            for table in ('samples', 'samples_hourly', 'events', 'snapshots'):
                self.store.db.execute('UPDATE OR REPLACE %s SET device=? WHERE device=?' % table,
                                      (new_id, old_id))
            self.store.db.execute('UPDATE OR REPLACE devices SET id=? WHERE id=?', (new_id, old_id))
            self.store.last_sample.clear()
        if old_id in self.live:
            self.live[new_id] = self.live.pop(old_id)
        log('history recorded under "%s" now belongs to %s' % (old_id[5:], new_id))

    def bridge_event(self, payload):
        kind = payload.get('type') or ''
        data = payload.get('data') or {}
        name = data.get('friendly_name') or data.get('ieee_address')
        ieee = data.get('ieee_address')
        if kind == 'device_joined':
            self.store.add_event('device', 'joined the network', 'info', ieee)
            log('device joined: %s' % name)
        elif kind == 'device_leave':
            self.store.add_event('device', 'left the network', 'warn', ieee)
            log('device left: %s' % name)
        elif kind == 'device_interview':
            status = data.get('status')
            if status == 'successful':
                d = data.get('definition') or {}
                self.store.add_event('device', 'interviewed: %s %s' % (d.get('vendor') or '',
                                     d.get('model') or ''), 'info', ieee)
            elif status == 'failed':
                self.store.add_event('device', 'interview failed', 'warn', ieee)
        elif kind == 'device_announce':
            self.store.add_event('device', 'announced itself', 'info', ieee)

    def set_availability(self, device_id, state, name):
        prev = (self.live.get(device_id) or {}).get('availability')
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': None, 'availability': None})
        entry['availability'] = state
        self.store.store_snapshot(device_id, entry['ts'] or int(time.time()), {}, state)
        if prev != state and prev is not None:
            level = 'warn' if state == 'offline' else 'info'
            self.store.add_event('availability', state, level, device_id)
            log('%s is %s' % (name, state))

    def record(self, device_id, name, payload):
        now = int(time.time())
        flat = flatten(payload)
        values = {}
        for key, value in flat.items():
            if key in IGNORE_KEYS or key.startswith('update'):
                continue
            if key == 'action':
                if value not in (None, ''):
                    self.store.add_event('action', str(value), 'info', device_id, now)
                    log('%s: %s' % (name, value), 'debug')
                    self.fire_bindings(device_id, name, str(value))
                continue
            v = numeric(value)
            if v is not None:
                values[key] = v
        if values:
            self.store.store_sample(device_id, now, values)
        clean = {k: v for k, v in flat.items() if not k.startswith('update')}
        merged = self.store.store_snapshot(device_id, now, clean)
        self.store.touch_device(device_id, now)
        entry = self.live.setdefault(device_id, {'payload': {}, 'ts': None, 'availability': None})
        entry['payload'] = merged
        entry['ts'] = now
        # A device that reports is by definition reachable.
        if entry.get('availability') == 'offline':
            self.set_availability(device_id, 'online', name)
        log('%s: %s' % (name, ', '.join('%s=%s' % kv for kv in sorted(values.items()))), 'debug')

    def handle_generic(self, parts, raw):
        """shellies/<name>/status/<component> and similar: a WiFi device."""
        payload = self.decode(raw)
        if not isinstance(payload, dict):
            return
        prefix, name = parts[0], parts[1]
        rest = parts[2:]
        if name in self.plug_mqtt_names():
            return          # polled over RPC; the MQTT copy would only duplicate it
        if rest and rest[0] == 'status' and len(rest) >= 2:
            component = rest[1]              # temperature:0, switch:0, devicepower:0
            comp_name = component.split(':')[0]
            multiple = component.split(':')[1] if ':' in component and component.split(':')[1] != '0' else ''
            keyed = {}
            for k, v in flatten(payload).items():
                if k in ('id',):
                    continue
                key = k if comp_name in ('temperature', 'humidity', 'devicepower', 'illuminance') \
                    else '%s.%s' % (comp_name, k)
                if multiple:
                    key = '%s%s.%s' % (comp_name, multiple, k)
                keyed[key] = v
            payload = keyed
        elif rest and rest[0] in ('events', 'rpc', 'online', 'command'):
            if rest[0] == 'online':
                state = 'online' if str(payload).lower() in ('true', '1', 'online') else 'offline'
                device_id = '%s:%s' % (prefix, name)
                if self.store.device(device_id):
                    self.set_availability(device_id, state, name)
            return
        elif rest:
            return
        device_id = '%s:%s' % (prefix, name)
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'shelly'
                                      if prefix == 'shellies' else 'mqtt', 'kind': 'wifi',
                                      'vendor': 'Shelly' if prefix == 'shellies' else None,
                                      'exposes': {}})
            log('new device: %s (%s)' % (name, prefix))
            self.store.add_event('device', 'first seen on %s/%s' % (prefix, name), 'info', device_id)
        self.record(device_id, name, payload)


    # -- smart plugs ---------------------------------------------------------
    def setup_plugs(self):
        """One PlugState per configured plug; stale rows for plugs that are gone."""
        configured = set()
        for entry in CONFIG.get('plugs') or []:
            if not isinstance(entry, dict) or not entry.get('name') or not entry.get('host'):
                CONFIG_NOTES.append('a plug entry without name or host was ignored')
                continue
            name = str(entry['name'])
            configured.add(name)
            self.plugs[name] = PlugState(name, entry)
            device_id = 'plug:' + name
            self.store.upsert_device({'id': device_id, 'name': name, 'source': 'plug', 'kind': 'wifi',
                                      'vendor': 'Shelly', 'exposes': {}})
            remembered = self.store.get_meta('plug_info_' + name)
            if remembered:
                try:
                    self.plugs[name].info = json.loads(remembered)
                except ValueError:
                    pass
        for dev in self.store.devices():
            if dev['source'] == 'plug' and dev['name'] not in configured:
                self.store.mark_removed(dev['id'])

    def plug_mqtt_names(self):
        names = set()
        for p in self.plugs.values():
            if p.cfg.get('mqtt_name'):
                names.add(p.cfg['mqtt_name'])
            if p.info and p.info.get('id'):
                names.add(p.info['id'])
        return names

    def plug_loop(self):
        while not self._stop.is_set():
            for p in list(self.plugs.values()):
                if self._stop.is_set():
                    break
                try:
                    self.poll_plug(p)
                except Exception as e:      # never let one plug stop the others
                    log('plug %s: %s' % (p.name, e), 'error')
            for s in list(self.sensors.values()):
                if self._stop.is_set():
                    break
                try:
                    self.poll_sensor(s)
                except Exception as e:
                    log('sensor %s: %s' % (s.name, e), 'error')
            self._stop.wait(max(2, int(CONFIG.get('plug_poll_interval') or 15)))

    def poll_plug(self, p, force=False):
        """Read one plug and record it."""
        now = time.time()
        if not force and (now - p.last_poll < int(CONFIG.get('plug_poll_interval') or 15)
                          or now < p.backoff_until):
            return p
        p.last_poll = now
        rpc = p.rpc()
        try:
            switch = rpc.switch_status()
            # System, Wi-Fi and cloud sections change slowly and cost a whole
            # extra request; a Gen3 plug answers 429 when asked too often.
            if now - p.last_device_status >= 60 or not p.device_status:
                p.device_status = rpc.device_status()
                p.last_device_status = now
            if not p.info:
                p.info = rpc.device_info()
                self.store.set_meta('plug_info_' + p.name, json.dumps(p.info))
        except PlugError as e:
            p.failures += 1
            p.error = str(e)
            if p.failures == 3:
                self.store.add_event('plug', 'lost contact: %s' % e, 'warn', p.device_id)
                self.store.store_snapshot(p.device_id, int(now), {}, 'offline')
            if '429' in str(e):
                p.backoff_until = now + max(getattr(rpc, 'retry_after', 0) or 0, 60)
                log('%s is rate limiting; backing off for %ds' % (p.name, int(p.backoff_until - now)),
                    'warn' if p.failures == 3 else 'debug')
            else:
                log('plug %s poll failed: %s' % (p.name, e), 'warn' if p.failures <= 3 else 'debug')
            return p
        if p.failures >= 3:
            self.store.add_event('plug', 'contact restored', 'info', p.device_id)
        p.failures = 0
        p.error = None
        p.backoff_until = 0.0

        flat = {}
        for k, v in flatten(switch).items():
            if k in ('id', 'source') or k.startswith('aenergy.by_minute') or k.startswith('ret_aenergy.by_minute'):
                continue
            flat['switch.' + k] = v
        dev = flatten(p.device_status)
        for k in ('wifi.rssi', 'wifi.sta_ip', 'wifi.ssid', 'sys.uptime', 'sys.ram_free',
                  'cloud.connected', 'mqtt.connected'):
            if k in dev:
                flat[k] = dev[k]
        output = 1 if switch.get('output') else 0
        if p.output is not None and output != p.output:
            self.store.add_event('plug', 'switched %s' % ('on' if output else 'off'),
                                 'info' if output else 'warn', p.device_id)
        p.output = output
        p.flat = flat
        p.generated = int(now)

        values = {}
        for k in ('switch.output', 'switch.apower', 'switch.voltage', 'switch.current', 'switch.pf',
                  'switch.freq', 'switch.aenergy.total', 'switch.ret_aenergy.total',
                  'switch.temperature.tC', 'switch.counts.on_time', 'switch.counts.switch_on',
                  'switch.counts.on_above_thr', 'wifi.rssi', 'sys.uptime'):
            v = numeric(flat.get(k)) if k in flat else None
            if v is not None:
                values[k] = v
        if values and now - p.last_sample >= int(CONFIG.get('plug_sample_interval') or 60):
            self.store.store_sample(p.device_id, int(now), values)
            p.last_sample = now
        self.store.store_snapshot(p.device_id, int(now), flat, 'online')
        self.store.touch_device(p.device_id, int(now))
        info = p.info or {}
        self.store.upsert_device({
            'id': p.device_id, 'name': p.name, 'source': 'plug', 'kind': 'wifi', 'vendor': 'Shelly',
            'model': info.get('model'),
            'description': ' '.join(x for x in (info.get('app'), info.get('ver')) if x) or None,
            'exposes': {k: {'label': key_label(k), 'unit': key_unit(k), 'description': PLUG_DESCRIPTIONS.get(k, '')}
                        for k in flat},
        })
        self.live[p.device_id] = {'payload': flat, 'ts': int(now), 'availability': 'online'}
        return p

    def plug_snapshot(self, p):
        """What the dashboard needs about one plug."""
        now = time.time()
        stale = p.error is not None
        flat = p.flat
        if not flat:
            snap = self.live.get(p.device_id) or {}
            flat = snap.get('payload') or {}
            generated = snap.get('ts')
        else:
            generated = p.generated
        counters = []
        for c in PLUG_COUNTERS:
            value = numeric(flat.get('switch.' + c['field'])) if ('switch.' + c['field']) in flat else None
            reset_at, exact = self._counter_reset_at(p, flat, c['type'])
            counters.append(dict(c, value=value, reset_at=reset_at, reset_exact=exact))
        return {
            'name': p.name, 'id': p.device_id, 'host': p.cfg.get('host'),
            'online': bool(flat), 'stale': stale or not p.flat,
            'error': p.error if stale else (None if p.flat else 'waiting for the first reading'),
            'generated': generated, 'age': int(now - generated) if generated else None,
            'retry_in': int(p.backoff_until - now) if p.backoff_until > now else None,
            'output': (1 if flat.get('switch.output') else 0) if 'switch.output' in flat else None,
            'values': {
                'power': numeric(flat.get('switch.apower')) if 'switch.apower' in flat else None,
                'voltage': numeric(flat.get('switch.voltage')) if 'switch.voltage' in flat else None,
                'current': numeric(flat.get('switch.current')) if 'switch.current' in flat else None,
                'pf': numeric(flat.get('switch.pf')) if 'switch.pf' in flat else None,
                'freq': numeric(flat.get('switch.freq')) if 'switch.freq' in flat else None,
                'energy': numeric(flat.get('switch.aenergy.total')) if 'switch.aenergy.total' in flat else None,
                'temperature': numeric(flat.get('switch.temperature.tC')) if 'switch.temperature.tC' in flat else None,
                'on_time': numeric(flat.get('switch.counts.on_time')) if 'switch.counts.on_time' in flat else None,
                'switch_on': numeric(flat.get('switch.counts.switch_on')) if 'switch.counts.switch_on' in flat else None,
                'rssi': numeric(flat.get('wifi.rssi')) if 'wifi.rssi' in flat else None,
                'uptime': numeric(flat.get('sys.uptime')) if 'sys.uptime' in flat else None,
            },
            'info': p.info or {},
            'counters': counters,
        }

    def _counter_reset_at(self, p, flat, counter):
        reported = numeric(flat.get('switch.' + PLUG_RESET_FIELDS[counter], None)) \
            if ('switch.' + PLUG_RESET_FIELDS[counter]) in flat else None
        if reported and reported > 1000000000:
            return int(reported), True
        remembered = self.store.get_meta('plug_reset_%s_%s' % (p.name, counter))
        if remembered:
            return int(float(remembered)), True
        return None, False

    def plug_by_name(self, name):
        p = self.plugs.get(str(name or ''))
        if p is None:
            for candidate in self.plugs.values():
                if candidate.device_id == name or candidate.name.lower() == str(name or '').lower():
                    return candidate
        return p

    def set_plug_output(self, p, on, origin='the dashboard'):
        try:
            p.rpc().set_output(on)
        except PlugError as e:
            self.store.add_event('plug', 'switch %s failed: %s' % ('on' if on else 'off', e), 'warn', p.device_id)
            return False, str(e)
        p.output = 1 if on else 0           # so the next poll does not log it again
        self.poll_plug(p, force=True)
        self.store.add_event('plug', 'switched %s from %s' % ('on' if on else 'off', origin),
                             'info' if on else 'warn', p.device_id)
        log('%s switched %s (%s)' % (p.name, 'on' if on else 'off', origin))
        return True, '%s switched %s' % (p.name, 'on' if on else 'off')

    def toggle_plug(self, p, origin='the dashboard'):
        try:
            state = p.rpc().switch_status()
        except PlugError as e:
            return False, str(e)
        return self.set_plug_output(p, not state.get('output'), origin)

    def read_plug_counters(self, p, attempts=2):
        last = None
        for _ in range(attempts):
            try:
                flat = flatten(p.rpc().switch_status())
                break
            except PlugError as e:
                last = e
                time.sleep(1.5)
        else:
            raise last or PlugError('could not read the counters')
        return {c['type']: numeric(flat.get(c['field'])) if c['field'] in flat else None
                for c in PLUG_COUNTERS}

    def reset_plug_counters(self, p, types=None):
        """Reset counters and check they actually moved - the plug says OK regardless."""
        wanted = [t for t in (types or []) if t in PLUG_COUNTER_TYPES]
        try:
            before = self.read_plug_counters(p)
        except PlugError as e:
            return False, 'could not read the counters first: %s' % e
        try:
            p.rpc().reset_counters(wanted or None)
        except PlugError as e:
            return False, str(e)
        time.sleep(1.0)
        try:
            after = self.read_plug_counters(p)
        except PlugError as e:
            self.store.add_event('plug', 'reset requested but the result could not be checked: %s' % e,
                                 'warn', p.device_id)
            return True, 'the reset was sent, but the plug did not answer when asked to confirm it'
        checked = wanted or PLUG_COUNTER_TYPES
        labels = {c['type']: c['label'] for c in PLUG_COUNTERS}
        cleared, unchanged, already = [], [], []
        for counter in checked:
            was, now = before.get(counter), after.get(counter)
            if was is None and now is None:
                continue
            if now is not None and now == 0:
                (already if was in (0, None) else cleared).append(labels[counter])
            elif was is not None and now is not None and now < was:
                cleared.append(labels[counter])
            else:
                unchanged.append(labels[counter])
        stamped = int(time.time())
        for counter in checked:
            if labels[counter] in cleared:
                self.store.set_meta('plug_reset_%s_%s' % (p.name, counter), stamped)
        self.poll_plug(p, force=True)
        if cleared:
            message = 'reset ' + ', '.join(c.lower() for c in cleared)
            if unchanged:
                message += '; the plug did not clear ' + ', '.join(u.lower() for u in unchanged)
            self.store.add_event('plug', message, 'info', p.device_id)
            return True, message
        if already and not unchanged:
            return True, ', '.join(a.lower() for a in already) + ' was already at zero'
        message = ('the plug accepted the request but nothing changed: '
                   + ', '.join(u.lower() for u in unchanged or checked)
                   + '. This firmware may not support resetting those.')
        self.store.add_event('plug', message, 'warn', p.device_id)
        return False, message

    # -- button bindings -------------------------------------------------------
    def bindings(self):
        raw = self.store.get_meta('bindings')
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except ValueError:
            return []
        return [b for b in data if isinstance(b, dict)]

    def save_bindings(self, items):
        clean = []
        for b in items or []:
            if not isinstance(b, dict):
                continue
            device = str(b.get('device') or '').strip()
            action = str(b.get('action') or '').strip()
            plug = str(b.get('plug') or '').strip()
            do = str(b.get('do') or 'toggle').strip().lower()
            if not device or not action or not plug:
                raise ValueError('a binding needs device, action and plug')
            if do not in BINDING_ACTIONS:
                raise ValueError('do must be one of %s' % ', '.join(BINDING_ACTIONS))
            if self.plug_by_name(plug) is None:
                raise ValueError('unknown plug %r' % plug)
            resolved = self.store.resolve(device) or device
            clean.append({'device': resolved, 'action': action, 'plug': self.plug_by_name(plug).name,
                          'do': do, 'enabled': bool(b.get('enabled', True))})
        self.store.set_meta('bindings', json.dumps(clean))
        self.store.add_event('control', '%d button binding(s) saved' % len(clean))
        return clean

    def fire_bindings(self, device_id, name, action):
        hits = [b for b in self.bindings()
                if b.get('enabled', True) and b['device'] in (device_id, name)
                and (b['action'] == action or b['action'] == '*')]
        for b in hits:
            p = self.plug_by_name(b['plug'])
            if p is None:
                continue
            origin = 'button %s (%s)' % (name, action)
            log('binding: %s %s -> %s %s' % (name, action, p.name, b['do']))
            threading.Thread(target=self._run_binding, args=(p, b['do'], origin),
                             name='binding', daemon=True).start()

    def _run_binding(self, p, do, origin):
        try:
            if do == 'toggle':
                ok, message = self.toggle_plug(p, origin)
            else:
                ok, message = self.set_plug_output(p, do == 'on', origin)
            if not ok:
                log('binding failed: %s' % message, 'warn')
        except Exception as e:
            log('binding failed: %s' % e, 'error')


    # -- Shelly sensors polled over RPC, and pushed webhooks -----------------
    def setup_sensors(self):
        for entry in CONFIG.get('sensors') or []:
            if not isinstance(entry, dict) or not entry.get('name') or not entry.get('host'):
                CONFIG_NOTES.append('a sensor entry without name or host was ignored')
                continue
            name = str(entry['name'])
            self.sensors[name] = PlugState(name, entry)
            self.sensors[name].device_id = 'sensor:' + name
            self.store.upsert_device({'id': 'sensor:' + name, 'name': name, 'source': 'shelly',
                                      'kind': 'wifi', 'vendor': 'Shelly', 'exposes': {}})

    def poll_sensor(self, s):
        """A battery H&T is asleep almost always, so failure here is not an error."""
        now = time.time()
        if now - s.last_poll < int(CONFIG.get('plug_poll_interval') or 15):
            return
        s.last_poll = now
        rpc = s.rpc()
        try:
            status = rpc.call('Shelly.GetStatus')
            if not s.info:
                s.info = rpc.device_info()
        except PlugError as e:
            s.failures += 1
            s.error = str(e)
            log('sensor %s: %s' % (s.name, e), 'debug')
            return
        if s.failures >= 3:
            log('sensor %s answers again' % s.name)
        s.failures = 0
        s.error = None
        flat = normalise_shelly_status(flatten(status))
        if not flat:
            return
        self.record(s.device_id, s.name, flat)
        info = s.info or {}
        self.store.upsert_device({'id': s.device_id, 'name': s.name, 'source': 'shelly', 'kind': 'wifi',
                                  'vendor': 'Shelly', 'model': info.get('model'),
                                  'description': ' '.join(x for x in (info.get('app'), info.get('ver')) if x) or None,
                                  'exposes': {}})

    def accept_push(self, fields, raw, client):
        """One webhook from a sleeping sensor. Returns True when something usable arrived."""
        source = str(fields.get('id') or fields.get('device') or fields.get('name') or client)
        values = {}
        aliases = {'tC': ('t', 'tC', 'temperature', 'temp'), 'rh': ('rh', 'humidity', 'h'),
                   'battery.V': ('bv', 'battery.V', 'V'), 'battery.percent': ('bp', 'battery.percent', 'percent', 'battery'),
                   'wifi.rssi': ('rssi', 'wifi.rssi'), 'lux': ('lux', 'illuminance')}
        for key, names in aliases.items():
            for n in names:
                if n in fields and numeric(fields[n]) is not None:
                    values[key] = numeric(fields[n])
                    break
        self.pushes_received += 1
        self.last_push_at = time.time()
        if not values:
            self.pushes_rejected += 1
            log('sensor push from %s carried nothing usable: %s' % (client, (raw or '')[:200]), 'warn')
            return False
        device_id = 'push:' + source
        if self.store.device(device_id) is None:
            self.store.upsert_device({'id': device_id, 'name': source, 'source': 'shelly', 'kind': 'wifi',
                                      'vendor': 'Shelly', 'description': 'webhook from %s' % client, 'exposes': {}})
            self.store.add_event('device', 'first push from %s' % client, 'info', device_id)
            log('first sensor push from %s (%s): %s' % (source, client, values))
        self.record(device_id, source, values)
        return True

    def serve_pushes(self):
        daemon = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def _answer(self, ok):
                self.send_response(200 if ok else 400)
                self.send_header('Content-Length', '0')
                self.end_headers()

            def do_GET(self):
                query = parse_qs(urlparse(self.path).query)
                fields = {k: v[0] for k, v in query.items() if v}
                self._answer(daemon.accept_push(fields, json.dumps(fields), self.client_address[0]))

            def do_POST(self):
                length = int(self.headers.get('Content-Length') or 0)
                raw = self.rfile.read(length).decode('utf-8', 'replace') if length else ''
                fields = {}
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        fields = flatten(parsed)
                except ValueError:
                    fields = {k: v[0] for k, v in parse_qs(raw).items() if v}
                short = {}
                for key, value in fields.items():
                    short[key.rsplit('.', 1)[-1]] = value
                short.update(fields)
                self._answer(daemon.accept_push(short, raw, self.client_address[0]))

        host, port = CONFIG['sensor_listen_host'] or '0.0.0.0', int(CONFIG['sensor_listen_port'])
        try:
            server = ThreadingHTTPServer((host, port), Handler)
        except OSError as e:
            log('cannot listen for sensor pushes on %s:%s - %s' % (host, port, e), 'error')
            return
        server.daemon_threads = True
        log('listening for sensor pushes on http://%s:%s/' % (host, port))
        server.serve_forever()

    # -- assessment ---------------------------------------------------------
    def describe(self, dev, snap):
        """One device for the API: identity, readings, verdict."""
        now = time.time()
        payload = (snap or {}).get('payload') or {}
        ts = (snap or {}).get('ts')
        availability = (snap or {}).get('availability')
        exposes = dev.get('exposes') or {}
        values = {}
        for key, value in payload.items():
            if key in IGNORE_KEYS:
                continue
            info = exposes.get(key) or {}
            values[key] = {
                'value': value,
                'label': info.get('label') or key_label(key),
                'unit': info.get('unit') or key_unit(key),
                'description': info.get('description') or '',
                'category': info.get('category') or '',
            }
            if info.get('values'):
                values[key]['options'] = list(info['values'])
        # What a button can send: the definition's list first, then anything
        # it has actually sent that the definition did not mention.
        declared = list((exposes.get('action') or {}).get('values') or [])
        actions = declared + [a for a in self.store.actions_seen(dev['id']) if a not in declared]
        reasons = []
        level = 'ok'

        def worst(new):
            nonlocal level
            order = ['ok', 'warn', 'crit']
            if order.index(new) > order.index(level):
                level = new

        age = (now - ts) if ts else None
        if availability == 'offline':
            worst('crit')
            reasons.append('not answering' if dev['source'] == 'plug' else 'reported offline by the bridge')
        battery = numeric(payload.get('battery')) if 'battery' in payload else \
            numeric(payload.get('battery.percent')) if 'battery.percent' in payload else None
        if battery is not None:
            if battery <= CONFIG['battery_crit']:
                worst('crit')
                reasons.append('battery %d%%' % battery)
            elif battery <= CONFIG['battery_warn']:
                worst('warn')
                reasons.append('battery %d%%' % battery)
        lqi = numeric(payload.get('linkquality')) if 'linkquality' in payload else None
        if lqi is not None:
            if lqi <= CONFIG['lqi_crit']:
                worst('warn')
                reasons.append('very weak signal (%d)' % lqi)
            elif lqi <= CONFIG['lqi_warn']:
                worst('warn')
                reasons.append('weak signal (%d)' % lqi)
        temp = numeric(payload.get('temperature')) if 'temperature' in payload else \
            numeric(payload.get('tC')) if 'tC' in payload else None
        if temp is not None:
            if CONFIG.get('temperature_max') is not None and temp > CONFIG['temperature_max']:
                worst('warn')
                reasons.append('temperature %.1f above %.1f' % (temp, CONFIG['temperature_max']))
            if CONFIG.get('temperature_min') is not None and temp < CONFIG['temperature_min']:
                worst('warn')
                reasons.append('temperature %.1f below %.1f' % (temp, CONFIG['temperature_min']))
        hum = numeric(payload.get('humidity')) if 'humidity' in payload else \
            numeric(payload.get('rh')) if 'rh' in payload else None
        if hum is not None and CONFIG.get('humidity_max') is not None and hum > CONFIG['humidity_max']:
            worst('warn')
            reasons.append('humidity %.0f%% above %.0f%%' % (hum, CONFIG['humidity_max']))
        if payload.get('water_leak') in (True, 'true', 1):
            worst('crit')
            reasons.append('water leak')
        if payload.get('battery_low') in (True, 'true', 1):
            worst('warn')
            reasons.append('battery low flag')
        stale_warn = int(CONFIG.get('stale_warn_min') or 0) * 60
        stale_crit = int(CONFIG.get('stale_crit_min') or 0) * 60
        if dev['source'] == 'plug':
            stale_warn, stale_crit = 0, 0
        if ts is None:
            worst('warn')
            reasons.append('never reported')
        elif stale_crit and age > stale_crit:
            worst('crit')
            reasons.append('silent for %s' % human_age(age))
        elif stale_warn and age > stale_warn:
            worst('warn')
            reasons.append('silent for %s' % human_age(age))

        ranked = []
        for key, entry in values.items():
            if dev['source'] == 'plug':
                rank = PLUG_HEADLINE.index(key) if key in PLUG_HEADLINE else None
            else:
                rank = headline_rank(key)
            if rank is not None and not key.endswith('.tF'):
                ranked.append((rank, key, entry))
        ranked.sort()
        headline = [dict(entry, key=key) for _, key, entry in ranked[:4]]
        return {
            'id': dev['id'], 'name': dev['name'], 'source': dev['source'],
            'kind': dev.get('kind'), 'model': dev.get('model'), 'vendor': dev.get('vendor'),
            'description': dev.get('description'),
            'first_seen': dev.get('first_seen'), 'last_seen': ts or dev.get('last_seen'),
            'age_s': int(age) if age is not None else None,
            'availability': availability,
            'online': availability != 'offline' and ts is not None and not (stale_crit and age > stale_crit),
            'level': level, 'reasons': reasons,
            'battery': battery, 'linkquality': lqi, 'temperature': temp, 'humidity': hum,
            'headline': headline,
            'values': values,
            'actions': actions,
            'has_action': bool(actions) or 'action' in exposes,
        }

    def status(self):
        now = time.time()
        devices = [self.describe(d, self.live.get(d['id'])) for d in self.store.devices()]
        order = {'ok': 0, 'warn': 1, 'crit': 2}
        level = 'ok'
        for d in devices:
            if order[d['level']] > order[level]:
                level = d['level']
        if not self.connected:
            level = 'crit'
        elif self.bridge.get('state') == 'offline':
            level = 'crit'
        elif not devices:
            level = 'unknown'
        pj_end = self.bridge.get('permit_join_end')
        permit = bool(self.bridge.get('permit_join'))
        if permit and pj_end and pj_end / 1000.0 < now:
            permit = False
        return {
            'ok': True, 'ts': int(now), 'level': level,
            'connected': self.connected,
            'broker': '%s:%s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port']),
            'bridge': dict(self.bridge, permit_join=permit),
            'devices': devices,
            'counts': {'devices': len(devices),
                       'online': sum(1 for d in devices if d['online']),
                       'ok': sum(1 for d in devices if d['level'] == 'ok'),
                       'warn': sum(1 for d in devices if d['level'] == 'warn'),
                       'crit': sum(1 for d in devices if d['level'] == 'crit')},
            'thresholds': {k: CONFIG[k] for k in ('battery_warn', 'battery_crit', 'lqi_warn',
                                                   'lqi_crit', 'stale_warn_min', 'stale_crit_min',
                                                   'temperature_min', 'temperature_max',
                                                   'humidity_max')},
            'pin_required': bool(CONFIG.get('pin')),
            'pin_length': len(str(CONFIG.get('pin') or '')),
            'pin_numeric': str(CONFIG.get('pin') or '').isdigit(),
            'plugs': [self.plug_snapshot(p) for p in self.plugs.values()],
            'bindings': self.bindings(),
            'binding_actions': BINDING_ACTIONS,
        }

    def health(self):
        return {
            'ok': True,
            'version': __version__,
            'uptime_s': int(time.time() - self.started),
            'connected': self.connected,
            'last_connect': int(self.last_connect) if self.last_connect else None,
            'last_disconnect': int(self.last_disconnect) if self.last_disconnect else None,
            'connect_failures': self.connect_failures,
            'last_error': self.last_error,
            'messages': self.messages,
            'last_message': int(self.last_message_at) if self.last_message_at else None,
            'bridge_state': self.bridge.get('state'),
            'subscriptions': [t for t, _ in self.topics()],
            'pushes': {'listening': bool(CONFIG.get('sensor_listen')),
                       'endpoint': 'http://%s:%s/' % (CONFIG['sensor_listen_host'], CONFIG['sensor_listen_port'])
                       if CONFIG.get('sensor_listen') else None,
                       'received': self.pushes_received, 'rejected': self.pushes_rejected,
                       'last': int(self.last_push_at) if self.last_push_at else None},
            'db': self.store.stats(),
            'config_notes': CONFIG_NOTES,
        }

    # -- privileged actions -------------------------------------------------
    def check_pin(self, given):
        pin = str(CONFIG.get('pin') or '')
        if not pin:
            return None
        now = time.time()
        if now < self.pin_locked_until:
            return 'too many wrong PINs; try again in %ds' % (self.pin_locked_until - now)
        if str(given or '') != pin:
            self.pin_failures += 1
            if self.pin_failures >= int(CONFIG.get('pin_attempts') or 5):
                self.pin_locked_until = now + int(CONFIG.get('pin_lockout_s') or 300)
                self.pin_failures = 0
                self.store.add_event('security', 'PIN locked after repeated failures', 'warn')
                return 'too many wrong PINs; locked for %ds' % int(CONFIG.get('pin_lockout_s') or 300)
            return 'wrong PIN'
        self.pin_failures = 0
        return None

    def permit_join(self, enable, seconds=254):
        if not self.connected or not self.client:
            raise RuntimeError('not connected to the broker')
        topic = CONFIG['base_topic'].rstrip('/') + '/bridge/request/permit_join'
        body = {'time': int(seconds) if enable else 0}
        info = self.client.publish(topic, json.dumps(body), qos=1)
        if hasattr(info, 'rc') and info.rc != 0:
            raise RuntimeError('publish failed (%s) - check the broker ACL for %s' % (info.rc, topic))
        self.bridge['permit_join'] = bool(enable)
        self.bridge['permit_join_end'] = int((time.time() + seconds) * 1000) if enable else None
        self.store.add_event('control', 'permit join %s' % ('enabled for %ds' % seconds if enable else 'disabled'))
        log('permit join %s' % ('on' if enable else 'off'))
        return body

    def reset(self, scope, device=None):
        device_id = self.store.resolve(device) if device else None
        if scope == 'device' and not device_id:
            raise ValueError('unknown device %r' % device)
        self.store.reset(scope, device_id)
        if scope in ('all',):
            self.live.clear()
            self.names.clear()
        elif scope == 'device':
            self.live.pop(device_id, None)
            for n, i in list(self.names.items()):
                if i == device_id:
                    del self.names[n]
        elif scope == 'history':
            pass
        self.store.add_event('control', 'recorded data erased: %s%s' % (scope, ' ' + device if device else ''),
                             'warn')
        log('data reset: %s %s' % (scope, device or ''))

    # -- main loop ------------------------------------------------------------
    def run(self):
        for note in CONFIG_NOTES:
            log('config: ' + note, 'warn')
        try:
            server = ApiServer(self)
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                log('cannot listen on %s:%s - another zigmon is already running there '
                    '(systemctl status zigmon). Stop it first, or point --config at a file '
                    'with a different api_port.' % (CONFIG['api_host'], CONFIG['api_port']), 'error')
            else:
                log('cannot listen on %s:%s - %s' % (CONFIG['api_host'], CONFIG['api_port'], e), 'error')
            return 2
        self.connect()
        server.start()
        if self.plugs or self.sensors:
            threading.Thread(target=self.plug_loop, name='plugs', daemon=True).start()
            log('polling %d plug(s) and %d sensor(s): %s' % (len(self.plugs), len(self.sensors),
                                                            ', '.join(list(self.plugs) + list(self.sensors))))
        if CONFIG.get('sensor_listen'):
            threading.Thread(target=self.serve_pushes, name='pushes', daemon=True).start()
        log('zigmon %s running; API on http://%s:%d' % (__version__, CONFIG['api_host'], CONFIG['api_port']))
        while not self._stop.is_set():
            self._stop.wait(30)
            ensure_log_current()
            now = time.time()
            if now - self.last_aggregate_at >= int(CONFIG.get('aggregate_interval') or 3600):
                self.last_aggregate_at = now
                try:
                    n = self.store.aggregate()
                    if n:
                        log('rolled up %d hourly rows' % n, 'debug')
                except Exception as e:
                    log('aggregate: %s' % e, 'error')
        log('stopping')
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass
        server.stop()
        return 0

    def stop(self, *_):
        self._stop.set()

    def reopen_log(self, *_):
        open_log()
        log('log file reopened')


# ---------------------------------------------------------------------------
# HTTP API
# ---------------------------------------------------------------------------
class ApiHandler(BaseHTTPRequestHandler):
    server_version = 'zigmon/' + __version__
    daemon = None

    def log_message(self, fmt, *args):
        log('api %s' % (fmt % args), 'debug')

    def _send(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _error(self, status, message):
        self._send(status, {'ok': False, 'error': message})

    def _query(self):
        url = urlparse(self.path)
        return url.path, {k: v[-1] for k, v in parse_qs(url.query).items()}

    def _body(self):
        length = int(self.headers.get('Content-Length') or 0)
        if length <= 0:
            return {}
        if length > 65536:
            raise ValueError('body too large')
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise ValueError('body is not JSON')
        return data if isinstance(data, dict) else {}

    def _authorised(self):
        given = self.headers.get('X-Zigmon-Token') or ''
        return bool(given) and secrets.compare_digest(given, self.daemon.token)

    def do_GET(self):
        d = self.daemon
        path, q = self._query()
        try:
            if path == '/api/status':
                return self._send(200, d.status())
            if path == '/api/health':
                return self._send(200, d.health())
            if path == '/api/devices':
                return self._send(200, {'ok': True, 'devices': d.status()['devices']})
            if path == '/api/device':
                device_id = d.store.resolve(q.get('id') or q.get('name') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                dev = d.store.device(device_id)
                out = d.describe(dev, d.live.get(device_id))
                out['keys'] = d.store.keys_for(device_id)
                out['exposes'] = dev.get('exposes') or {}
                return self._send(200, dict(out, ok=True))
            if path == '/api/history':
                device_id = d.store.resolve(q.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                seconds = parse_span(q.get('range', '24h'))
                points = max(20, min(5000, int(q.get('points', 600))))
                keys = [k for k in (q.get('keys') or '').split(',') if k]
                if not keys:
                    keys = [k for k in d.store.keys_for(device_id) if k != 'linkquality'][:4]
                rows = d.store.history(device_id, keys, seconds, points)
                return self._send(200, {'ok': True, 'device': device_id, 'keys': keys,
                                        'range_s': seconds, 'rows': rows})
            if path == '/api/events':
                limit = max(1, min(1000, int(q.get('limit', 100))))
                device_id = d.store.resolve(q.get('device')) if q.get('device') else None
                rows = d.store.events(limit, device_id)
                names = {x['id']: x['name'] for x in d.store.devices(include_removed=True)}
                for r in rows:
                    r['device_name'] = names.get(r['device']) if r['device'] else None
                return self._send(200, {'ok': True, 'events': rows})
            if path == '/api/plugs':
                return self._send(200, {'ok': True, 'plugs': [d.plug_snapshot(p) for p in d.plugs.values()]})
            if path == '/api/plug':
                p = d.plug_by_name(q.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                if q.get('refresh'):
                    d.poll_plug(p, force=True)
                return self._send(200, dict(d.plug_snapshot(p), ok=True))
            if path == '/api/bindings':
                return self._send(200, {'ok': True, 'bindings': d.bindings(), 'actions': BINDING_ACTIONS,
                                        'plugs': list(d.plugs)})
            if path == '/api/keys':
                device_id = d.store.resolve(q.get('device') or '')
                if not device_id:
                    return self._error(404, 'unknown device')
                return self._send(200, {'ok': True, 'keys': d.store.keys_for(device_id)})
            return self._error(404, 'no such endpoint')
        except ValueError as e:
            return self._error(400, str(e))
        except Exception as e:
            log('api %s: %s' % (path, e), 'error')
            return self._error(500, 'internal error: %s' % e)

    def do_POST(self):
        d = self.daemon
        path, _ = self._query()
        if not self._authorised():
            return self._error(403, 'missing or wrong API token')
        try:
            body = self._body()
        except ValueError as e:
            return self._error(400, str(e))
        try:
            if path == '/api/permit-join':
                err = d.check_pin(body.get('pin'))
                if err:
                    return self._error(403, err)
                enable = bool(body.get('enable', True))
                seconds = max(10, min(254, int(body.get('time', 254))))
                result = d.permit_join(enable, seconds)
                return self._send(200, {'ok': True, 'permit_join': enable, 'request': result})
            if path == '/api/plug/switch':
                err = d.check_pin(body.get('pin'))
                if err:
                    return self._error(403, err)
                p = d.plug_by_name(body.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                if body.get('toggle'):
                    ok, message = d.toggle_plug(p)
                else:
                    ok, message = d.set_plug_output(p, bool(body.get('on')))
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message,
                                                        'plug': d.plug_snapshot(p)})
            if path == '/api/plug/reset':
                err = d.check_pin(body.get('pin'))
                if err:
                    return self._error(403, err)
                p = d.plug_by_name(body.get('name') or '')
                if p is None:
                    return self._error(404, 'unknown plug')
                types = body.get('types') if isinstance(body.get('types'), list) else []
                ok, message = d.reset_plug_counters(p, types)
                return self._send(200 if ok else 502, {'ok': ok, 'message' if ok else 'error': message,
                                                        'plug': d.plug_snapshot(p)})
            if path == '/api/bindings':
                err = d.check_pin(body.get('pin'))
                if err:
                    return self._error(403, err)
                saved = d.save_bindings(body.get('bindings') or [])
                return self._send(200, {'ok': True, 'bindings': saved})
            if path == '/api/reset':
                err = d.check_pin(body.get('pin'))
                if err:
                    return self._error(403, err)
                scope = str(body.get('scope') or 'history')
                if scope not in ('all', 'history', 'events', 'device'):
                    return self._error(400, 'scope must be all, history, events or device')
                d.reset(scope, body.get('device'))
                return self._send(200, {'ok': True, 'scope': scope})
            return self._error(404, 'no such endpoint')
        except (ValueError, RuntimeError) as e:
            return self._error(400, str(e))
        except Exception as e:
            log('api %s: %s' % (path, e), 'error')
            return self._error(500, 'internal error: %s' % e)


class ApiServer(object):
    def __init__(self, daemon):
        handler = type('BoundHandler', (ApiHandler,), {'daemon': daemon})
        self.httpd = ThreadingHTTPServer((CONFIG['api_host'], int(CONFIG['api_port'])), handler)
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, name='api', daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------
class Palette(object):
    def __init__(self, enabled):
        self.on = enabled

    def _c(self, code, text):
        return '\033[%sm%s\033[0m' % (code, text) if self.on else str(text)

    def ok(self, t): return self._c('32', t)
    def warn(self, t): return self._c('33', t)
    def crit(self, t): return self._c('31', t)
    def dim(self, t): return self._c('2', t)
    def bold(self, t): return self._c('1', t)
    # the names the Shelly toolkit uses
    def title(self, t): return self._c('1;36', t)
    def rule(self, t): return self._c('36', t)
    def group(self, t): return self._c('1;35', t)
    def key(self, t): return self._c('37', t)
    def value(self, t): return self._c('1;33', t)
    def note(self, t): return self._c('2;37', t)
    def bad(self, t): return self._c('1;31', t)
    def info(self, t): return self._c('34', t)

    def level(self, level, text=None):
        text = level if text is None else text
        return {'ok': self.ok, 'warn': self.warn, 'crit': self.crit}.get(level, self.dim)(text)


def api_call(path, method='GET', payload=None, timeout=10.0, token=None):
    import urllib.request
    import urllib.error
    url = 'http://%s:%d%s' % (CONFIG['api_host'], int(CONFIG['api_port']), path)
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header('Accept', 'application/json')
    if data is not None:
        req.add_header('Content-Type', 'application/json')
    if method != 'GET':
        token = token or read_token()
        if token:
            req.add_header('X-Zigmon-Token', token)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode('utf-8'))
        except Exception:
            return e.code, {'ok': False, 'error': str(e)}
    except (urllib.error.URLError, OSError, ValueError) as e:
        return 0, {'ok': False, 'error': str(e)}


def read_token():
    try:
        return token_path().read_text().strip()
    except OSError:
        return None


def fmt_value(entry):
    v = entry.get('value')
    unit = entry.get('unit') or ''
    if isinstance(v, float):
        text = ('%.2f' % v).rstrip('0').rstrip('.')
    elif isinstance(v, bool):
        text = 'yes' if v else 'no'
    else:
        text = str(v)
    return (text + (' ' + unit if unit else '')).strip()


def cmd_status(args, pal):
    status_code, data = api_call('/api/status')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    b = data['bridge']
    print(pal.bold('Broker    ') + data['broker'] + '  ' +
          (pal.ok('connected') if data['connected'] else pal.crit('disconnected')))
    print(pal.bold('Bridge    ') + '%s  %s  ch %s  %s' % (
        pal.level('ok' if b.get('state') == 'online' else 'crit', b.get('state') or '?'),
        b.get('version') or '', b.get('channel') or '?',
        pal.warn('PERMIT JOIN OPEN') if b.get('permit_join') else ''))
    print(pal.bold('Overall   ') + pal.level(data['level'], data['level']))
    print()
    devices = data['devices']
    if not devices:
        print(pal.dim('no devices recorded yet'))
        return 0
    width = max(len(d['name']) for d in devices)
    for d in devices:
        parts = [fmt_value(h) for h in d['headline']]
        extras = []
        if d.get('battery') is not None:
            extras.append('bat %d%%' % d['battery'])
        if d.get('linkquality') is not None:
            extras.append('lqi %d' % d['linkquality'])
        line = '%s  %-*s  %-6s %s  %s' % (
            pal.level(d['level'], '●'), width, d['name'], pal.level(d['level'], d['level']),
            '  '.join(parts), pal.dim(' '.join(extras)))
        print(line)
        print('   ' + pal.dim('%s %s · last %s ago%s' % (
            d.get('vendor') or '', d.get('model') or '', human_age(d['age_s']),
            (' · ' + '; '.join(d['reasons'])) if d['reasons'] else '')))
    return 0 if data['level'] in ('ok', 'unknown') else 1


def cmd_devices(args, pal):
    status_code, data = api_call('/api/devices')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    rows = data['devices']
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    print('%-22s %-20s %-10s %-12s %-24s %-8s %s' % ('NAME', 'ID', 'SOURCE', 'KIND', 'MODEL', 'LEVEL', 'LAST'))
    for d in rows:
        print('%-22s %-20s %-10s %-12s %-24s %-8s %s' % (
            d['name'][:22], d['id'][:20], d['source'], d.get('kind') or '',
            ((d.get('vendor') or '') + ' ' + (d.get('model') or '')).strip()[:24],
            pal.level(d['level'], d['level']), human_age(d['age_s']) + ' ago' if d['age_s'] is not None else 'never'))
    return 0


def cmd_history(args, pal):
    span = args.range or '24h'
    query = '/api/history?device=%s&range=%s&points=%d' % (args.history, span, args.points)
    if args.keys:
        query += '&keys=' + args.keys
    status_code, data = api_call(query, timeout=60)
    if status_code != 200:
        print(pal.crit('error: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data, indent=2))
        return 0
    keys = data['keys']
    print('%-19s ' % 'TIME' + ' '.join('%12s' % k[:12] for k in keys))
    for r in data['rows']:
        stamp = datetime.fromtimestamp(r['ts']).strftime('%Y-%m-%d %H:%M:%S')
        print('%-19s ' % stamp + ' '.join(
            '%12s' % (('%.2f' % r[k]).rstrip('0').rstrip('.') if r.get(k) is not None else '-') for k in keys))
    print(pal.dim('%d rows' % len(data['rows'])))
    return 0


def cmd_events(args, pal):
    status_code, data = api_call('/api/events?limit=%d' % args.limit)
    if status_code != 200:
        print(pal.crit('error: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data['events'], indent=2, ensure_ascii=False))
        return 0
    for e in reversed(data['events']):
        stamp = datetime.fromtimestamp(e['ts']).strftime('%Y-%m-%d %H:%M:%S')
        who = e.get('device_name') or e.get('device') or ''
        print('%s  %s  %-12s %-18s %s' % (stamp, pal.level(e.get('level') or 'info', '●'),
                                          e['kind'], who[:18], e.get('detail') or ''))
    return 0


def cmd_watch(args, pal):
    """Subscribe directly and print what arrives, without the daemon."""
    seen = {'n': 0}
    done = threading.Event()

    def on_connect(client, userdata, flags, rc, *rest):
        if rc_failed(rc):
            print(pal.crit('connect refused: %s' % reason_text(rc)))
            done.set()
            return
        topics = [(CONFIG['base_topic'].rstrip('/') + '/#', 0)]
        topics += [(t, 0) for t in CONFIG.get('extra_topics') or []]
        client.subscribe(topics)
        print(pal.dim('connected to %s:%s, watching %s' % (CONFIG['mqtt_host'], CONFIG['mqtt_port'],
                                                             ', '.join(t for t, _ in topics))))

    def on_message(client, userdata, msg):
        seen['n'] += 1
        text = msg.payload.decode('utf-8', 'replace')
        if '/bridge/' in msg.topic and not args.bridge:
            return
        if len(text) > 400 and not args.raw:
            text = text[:400] + '…'
        print('%s  %s  %s' % (pal.dim(datetime.now().strftime('%H:%M:%S')), pal.bold(msg.topic), text))
        if args.count and seen['n'] >= args.count:
            done.set()

    client = make_mqtt_client('zigmon-watch-%d' % os.getpid())
    client.on_connect = on_connect
    client.on_message = on_message
    try:
        client.connect(CONFIG['mqtt_host'], int(CONFIG['mqtt_port']), 30)
    except OSError as e:
        print(pal.crit('cannot connect: %s' % e))
        return 2
    client.loop_start()
    try:
        done.wait(args.seconds if args.seconds else None)
    except KeyboardInterrupt:
        pass
    client.loop_stop()
    client.disconnect()
    return 0


def cmd_permit_join(args, pal):
    enable = args.permit_join.lower() in ('on', 'yes', '1', 'true', 'open')
    payload = {'enable': enable, 'time': 254}
    if CONFIG.get('pin'):
        payload['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/permit-join', 'POST', payload)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok('permit join is now %s' % ('open for 254 s' if enable else 'closed')))
    return 0


def cmd_reset(args, pal):
    scope = args.reset_data
    device = None
    if scope not in ('all', 'history', 'events'):
        device, scope = scope, 'device'
    if not args.yes:
        answer = input('Erase %s%s? This cannot be undone [y/N] ' % (scope, ' for ' + device if device else ''))
        if answer.strip().lower() not in ('y', 'yes'):
            print('nothing done')
            return 0
    payload = {'scope': scope}
    if device:
        payload['device'] = device
    if CONFIG.get('pin'):
        payload['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/reset', 'POST', payload, timeout=120)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok('erased: %s' % scope))
    return 0


def _plug_line(pal, snap):
    v = snap['values']
    state = pal.dim('unreachable') if not snap['online'] else (pal.ok('ON') if snap['output'] else pal.warn('OFF'))
    parts = []
    if v.get('power') is not None:
        parts.append('%.1f W' % v['power'])
    if v.get('voltage') is not None:
        parts.append('%.1f V' % v['voltage'])
    if v.get('current') is not None:
        parts.append('%.3f A' % v['current'])
    if v.get('energy') is not None:
        parts.append('%.3f kWh' % (v['energy'] / 1000.0))
    if v.get('temperature') is not None:
        parts.append('%.1f °C' % v['temperature'])
    return '%s  %s  %s' % (pal.bold('%-14s' % snap['name']), state, '  '.join(parts))


def cmd_plug(args, pal):
    status_code, data = api_call('/api/plugs')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    plugs = data['plugs']
    if args.json:
        print(json.dumps(plugs, indent=2, ensure_ascii=False))
        return 0
    if not plugs:
        print(pal.dim('no plugs configured (see "plugs" in %s)' % CONFIG_FILE))
        return 0
    for snap in plugs:
        if args.plug not in ('all', snap['name']):
            continue
        print(_plug_line(pal, snap))
        info = snap.get('info') or {}
        print('   ' + pal.dim('%s %s %s · %s · %s' % (
            info.get('model') or '', info.get('app') or '', info.get('ver') or '', snap['host'],
            (snap['error'] or ('stale, ' + human_age(snap['age']) + ' old')) if snap['stale']
            else 'read %s ago' % human_age(snap['age']))))
        for c in snap['counters']:
            if c['value'] is None:
                continue
            since = ('since ' if c['reset_exact'] else 'since at least ') + \
                datetime.fromtimestamp(c['reset_at']).strftime('%Y-%m-%d') if c['reset_at'] else 'no reset date'
            print('   %-20s %-14s %s' % (c['label'], '%g' % c['value'], pal.dim(since)))
    return 0


def cmd_plug_switch(args, pal):
    if args.plug_on:
        name, body = args.plug_on, {'on': True}
    elif args.plug_off:
        name, body = args.plug_off, {'on': False}
    else:
        name, body = args.plug_toggle, {'toggle': True}
    body['name'] = name
    if CONFIG.get('pin'):
        body['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/plug/switch', 'POST', body, timeout=30)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok(data.get('message')))
    return 0


def cmd_plug_reset(args, pal):
    name = args.plug_reset
    types = [t for t in (args.types or '').split(',') if t]
    body = {'name': name, 'types': types}
    if CONFIG.get('pin'):
        body['pin'] = CONFIG['pin']
    status_code, data = api_call('/api/plug/reset', 'POST', body, timeout=60)
    if status_code != 200:
        print(pal.crit('failed: %s' % data.get('error')))
        return 2
    print(pal.ok(data.get('message')))
    return 0


def cmd_bindings(args, pal):
    status_code, data = api_call('/api/bindings')
    if status_code != 200:
        print(pal.crit('daemon not reachable: %s' % data.get('error')))
        return 2
    if args.json:
        print(json.dumps(data['bindings'], indent=2))
        return 0
    if not data['bindings']:
        print(pal.dim('no bindings; add them on the Control tab of the dashboard'))
        return 0
    status_code, st = api_call('/api/status')
    names = {x['id']: x['name'] for x in st.get('devices', [])} if status_code == 200 else {}
    for b in data['bindings']:
        print('%s %-18s %-10s -> %-14s %s' % (
            pal.ok('●') if b.get('enabled', True) else pal.dim('○'),
            names.get(b['device'], b['device']), b['action'], b['plug'], pal.bold(b['do'])))
    return 0


def cmd_check(args, pal):
    problems = 0

    def verdict(ok, text, detail=''):
        nonlocal problems
        if not ok:
            problems += 1
        print('  %s  %s%s' % (pal.ok('✔') if ok else pal.crit('✘'), text,
                              pal.dim('  ' + detail) if detail else ''))

    print(pal.bold('zigmon %s' % __version__))
    verdict(mqtt is not None, 'paho-mqtt importable', '' if mqtt else 'dnf install python3-paho-mqtt')
    verdict(not CONFIG_FATAL, 'configuration readable', '; '.join(CONFIG_FATAL))
    t0 = time.time()
    status_code, health = api_call('/api/health', timeout=5)
    ms = (time.time() - t0) * 1000
    verdict(status_code == 200, 'daemon API answering', '%.0f ms' % ms if status_code == 200 else health.get('error', ''))
    if status_code != 200:
        print(pal.dim('  is zigmon.service running?  journalctl -u zigmon -n 30'))
        return 1
    verdict(health['connected'], 'connected to the broker', health.get('last_error') or '')
    verdict(health.get('bridge_state') == 'online', 'Zigbee2MQTT bridge online',
            'state: %s' % health.get('bridge_state'))
    age = time.time() - health['last_message'] if health.get('last_message') else None
    verdict(age is not None and age < 3600, 'messages flowing',
            'last %s ago' % human_age(age) if age is not None else 'none since start')
    token = read_token()
    verdict(bool(token), 'API token readable by %s' % _whoami(), str(token_path()))
    status_code, status = api_call('/api/status', timeout=5)
    if status_code == 200:
        c = status['counts']
        verdict(c['devices'] > 0, '%d device(s): %d ok, %d warn, %d crit' % (
            c['devices'], c['ok'], c['warn'], c['crit']), '')
        for d in status['devices']:
            if d['level'] != 'ok':
                print('     %s %s: %s' % (pal.level(d['level'], '●'), d['name'], '; '.join(d['reasons'])))
    status_code, plugs = api_call('/api/plugs', timeout=5)
    if status_code == 200:
        for snap in plugs['plugs']:
            verdict(snap['online'] and not snap['stale'], 'plug %s' % snap['name'],
                    snap['error'] or ('%s, %.1f W' % ('on' if snap['output'] else 'off', snap['values'].get('power') or 0)))
    db = health['db']
    verdict(True, 'database %s' % db['path'], '%s, %d samples, %d hourly, %d events' % (
        '%.1f MB' % (db['bytes'] / 1048576.0) if db.get('bytes') else '?', db['samples'],
        db['samples_hourly'], db['events']))
    return 1 if problems else 0


def cmd_diag(args, pal):
    print(pal.bold('Configuration in force (%s)' % CONFIG_FILE))
    for key in sorted(CONFIG):
        value = CONFIG[key]
        if key == 'mqtt_password' and value:
            value = '********'
        if key == 'pin' and value:
            value = '****'
        print('  %-24s %s' % (key, json.dumps(value)))
    for note in CONFIG_NOTES:
        print('  ' + pal.warn(note))
    for note in CONFIG_FATAL:
        print('  ' + pal.crit(note))
    print()
    for path in ('/api/health', '/api/status', '/api/events?limit=5'):
        t0 = time.time()
        status_code, data = api_call(path, timeout=5)
        print('  %-24s %s  %.0f ms' % (path, pal.ok(str(status_code)) if status_code == 200 else pal.crit(str(status_code)),
                                       (time.time() - t0) * 1000))
    status_code, health = api_call('/api/health', timeout=5)
    if status_code == 200:
        print()
        print(pal.bold('Daemon'))
        for key in ('version', 'uptime_s', 'connected', 'connect_failures', 'last_error', 'messages',
                    'bridge_state', 'subscriptions'):
            print('  %-24s %s' % (key, health.get(key)))
        print(pal.bold('Database'))
        for key, value in health['db'].items():
            if key == 'oldest' and value:
                value = datetime.fromtimestamp(value).strftime('%Y-%m-%d')
            if key == 'bytes' and value:
                value = '%.1f MB' % (value / 1048576.0)
            print('  %-24s %s' % (key, value))
    return 0


# ===========================================================================
# The Shelly toolkit - "zigmon shelly ..." - ported whole from upsmon
# ===========================================================================
def describe_plug_field(path):
    """A description for a status field, whichever component prefix it carries."""
    tail = re.sub(r'^[a-z_0-9]+:\d+\.', '', path)
    for candidate in (path, 'switch.' + tail, tail):
        if candidate in PLUG_DESCRIPTIONS:
            return PLUG_DESCRIPTIONS[candidate]
    return ''


RPC_METHODS = {
    # -- identity and housekeeping -----------------------------------------
    'Shelly.GetDeviceInfo': ('Model, name, firmware version and MAC.', None),
    'Shelly.GetStatus': ('Every component\'s current state in one reply.', None),
    'Shelly.GetConfig': ('Every component\'s configuration in one reply.', None),
    'Shelly.ListMethods': ('The list this command is built on.', None),
    'Shelly.GetComponents': ('Which components exist, with their keys.',
                             '{"offset":0}'),
    'Shelly.Reboot': ('Restart the device. Takes about ten seconds.', None),
    'Shelly.CheckForUpdate': ('Ask Shelly whether newer firmware exists.', None),
    'Shelly.Update': ('Install firmware. "stable" or "beta".',
                      '{"stage":"stable"}'),
    'Shelly.Identify': ('Flash the LED so you can tell which device it is.', None),
    'Shelly.DetectLocation': ('Set the timezone from the public IP address.', None),
    'Shelly.ListTimezones': ('Every timezone name the device accepts.', None),
    'Shelly.SetAuth': ('Set or clear the web password. The username is always '
                       'admin; a null password removes authentication.',
                       '{"user":"admin","realm":"shellyplug-xxxx","ha1":"..."}'),
    'Shelly.FactoryReset': ('Erase everything, including the Wi-Fi settings. '
                            'The device comes back as an access point.', None),
    'Shelly.ResetWiFiConfig': ('Forget the Wi-Fi settings only.', None),

    # -- the switch ---------------------------------------------------------
    'Switch.GetStatus': ('Power, voltage, current, energy, temperature and '
                         'relay state.', '{"id":0}'),
    'Switch.GetConfig': ('Name, auto-off timers, limits, initial state.',
                         '{"id":0}'),
    'Switch.SetConfig': ('Change any of those.',
                         '{"id":0,"config":{"auto_off":true,"auto_off_delay":300}}'),
    'Switch.Set': ('Switch the relay. "toggle_after" turns it back after N '
                   'seconds.', '{"id":0,"on":false}'),
    'Switch.Toggle': ('Flip the relay to the other state.', '{"id":0}'),
    'Switch.ResetCounters': ('Reset the running totals. Without "type", all of '
                             'them.', '{"id":0,"type":["aenergy"]}'),

    # -- system, network, radios -------------------------------------------
    'Sys.GetStatus': ('Uptime, free memory, filesystem, time, restart flag.', None),
    'Sys.GetConfig': ('Device name, timezone, location, debug settings.', None),
    'Sys.SetConfig': ('Change them.',
                      '{"config":{"device":{"name":"UPS socket"}}}'),
    'Sys.SetTime': ('Set the clock by hand, for a device with no internet.',
                    '{"unixtime":1788195638}'),
    'Wifi.GetStatus': ('Address, SSID, signal strength, connection state.', None),
    'Wifi.GetConfig': ('Both configured networks and the access point.', None),
    'Wifi.SetConfig': ('Change them. Getting this wrong takes the device off '
                       'the network.',
                       '{"config":{"sta":{"ssid":"net","pass":"secret","enable":true}}}'),
    'Wifi.Scan': ('List the networks the device can see.', None),
    'Wifi.ListAPClients': ('Who is connected to its own access point.', None),
    'Cloud.GetStatus': ('Whether it is talking to Shelly Cloud.', None),
    'Cloud.SetConfig': ('Turn the cloud connection on or off.',
                        '{"config":{"enable":false}}'),
    'Mqtt.GetStatus': ('Whether it is connected to an MQTT broker.', None),
    'Mqtt.SetConfig': ('Point it at a broker.',
                       '{"config":{"enable":true,"server":"10.0.0.2:1883"}}'),
    'BLE.GetConfig': ('Bluetooth radio and RPC-over-Bluetooth switches.', None),
    'BLE.SetConfig': ('Turn either on or off. Needs a reboot.',
                      '{"config":{"enable":true,"rpc":{"enable":true}}}'),
    'BLE.StartPairing': ('Accept a Bluetooth pairing for a while.', None),
    'BLE.ListPairedDevices': ('What is already paired.', None),
    'Matter.GetStatus': ('Whether Matter is on and commissionable.', None),
    'Matter.GetSetupCode': ('The pairing code a Matter controller needs.', None),
    'Matter.SetConfig': ('Turn Matter on or off. Needs a reboot.',
                         '{"config":{"enable":true}}'),
    'Matter.FactoryReset': ('Forget every Matter fabric it has joined.', None),
    'WS.GetConfig': ('Outbound websocket: where it connects out to.', None),
    'WS.SetConfig': ('Point it at a listener - what "shelly serve" accepts.',
                     '{"config":{"enable":true,"server":"ws://10.0.0.9:8089"}}'),

    # -- automation on the device itself -----------------------------------
    'Webhook.Create': ('Call a URL when something happens. This is how a '
                       'sleeping sensor reports.',
                       '{"cid":0,"enable":true,"event":"temperature.change",'
                       '"urls":["http://10.0.0.9:8088/?t=${ev.tC}"]}'),
    'Webhook.List': ('Every webhook currently set.', None),
    'Webhook.ListSupported': ('Which events this device can trigger on.', None),
    'Webhook.Delete': ('Remove one by id.', '{"id":1}'),
    'Webhook.DeleteAll': ('Remove all of them.', None),
    'Schedule.Create': ('Run something on a cron schedule, on the device.',
                        '{"enable":true,"timespec":"0 0 22 * * *",'
                        '"calls":[{"method":"Switch.Set","params":{"id":0,"on":false}}]}'),
    'Schedule.List': ('Every schedule currently set.', None),
    'Schedule.Delete': ('Remove one by id.', '{"id":1}'),
    'Script.List': ('Scripts stored on the device.', None),
    'Script.Create': ('Make an empty script slot.', '{"name":"watchdog"}'),
    'Script.PutCode': ('Upload JavaScript into a slot.',
                       '{"id":1,"code":"print(1);"}'),
    'Script.Start': ('Run it.', '{"id":1}'),
    'Script.Stop': ('Stop it.', '{"id":1}'),
    'KVS.Set': ('Store a value on the device, for scripts to read.',
                '{"key":"note","value":"UPS socket"}'),
    'KVS.Get': ('Read one back.', '{"key":"note"}'),
    'KVS.List': ('Every key stored.', None),
    'KVS.Delete': ('Remove one.', '{"key":"note"}'),
    'HTTP.GET': ('Make the device fetch a URL itself.',
                 '{"url":"http://10.0.0.9/ping"}'),
    'HTTP.POST': ('And post to one.',
                  '{"url":"http://10.0.0.9/hook","body":"{}"}'),
    'RPC.Ping': ('Check the device is answering at all.', None),
    'plugs_ui.GetConfig': ('The LED ring: colours, brightness, night mode.', None),
    'plugs_ui.SetConfig': ('Change them.',
                           '{"config":{"leds":{"mode":"power"}}}'),
}

# Components whose methods are all variations on a theme, so the group can be
# summarised rather than repeating a note against each entry.
RPC_COMPONENTS = {
    'Shelly': 'the device as a whole: identity, status, firmware, reboot',
    'Switch': 'the relay and its meter',
    'Sys': 'clock, name, timezone, memory',
    'Wifi': 'network settings and signal',
    'Cloud': 'the Shelly Cloud connection',
    'Mqtt': 'the MQTT broker connection',
    'BLE': 'the Bluetooth radio and RPC over Bluetooth',
    'Matter': 'Matter, for Apple Home and other controllers',
    'WS': 'the outbound websocket this tool can receive with "serve"',
    'Webhook': 'call a URL when something happens on the device',
    'Schedule': 'run something on a timer, on the device itself',
    'Script': 'JavaScript stored and run on the device',
    'KVS': 'a small key-value store for scripts',
    'HTTP': 'make the device fetch or post a URL itself',
    'OTA': 'firmware upload, used by Shelly.Update',
    'KNX': 'the KNX building-automation protocol',
    'BTHome': 'Bluetooth sensors reporting through this device',
    'BTHomeDevice': 'one such sensor',
    'BTHomeSensor': 'one measurement from such a sensor',
    'BTHomeControl': 'Bluetooth buttons and remotes',
    'Virtual': 'virtual components for scripts and the app UI',
    'Boolean': 'a virtual on/off value',
    'Number': 'a virtual number',
    'Text': 'a virtual string',
    'Enum': 'a virtual choice',
    'Group': 'a virtual group of components',
    'Button': 'a virtual button',
    'LNM': 'local network messaging between Shelly devices',
    'plugs_ui': 'the LED ring on the plug',
    'RPC': 'the RPC channel itself',
}



def shelly_targets():
    """Every device the configuration names: plugs first, then sensors."""
    out = {}
    for entry in CONFIG.get('plugs') or []:
        if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
            out[str(entry['name'])] = dict(entry, kind='plug')
    for entry in CONFIG.get('sensors') or []:
        if isinstance(entry, dict) and entry.get('name') and entry.get('host'):
            out[str(entry['name'])] = dict(entry, kind='sensor')
    return out


def shelly_for(role, args=None):
    """Build a client for a device named in the configuration, or an address given directly."""
    override_host = getattr(args, 'host', None) if args else None
    override_password = getattr(args, 'password', None) if args else None
    if override_host:
        return ShellyRPC(override_host, override_password or '', getattr(args, 'switch_id', 0) or 0,
                         label='the device at %s' % override_host)
    targets = shelly_targets()
    if not role:
        if not targets:
            raise PlugError('nothing configured - add a plug under "plugs" in %s, or give --host' % CONFIG_FILE)
        role = list(targets)[0]
    match = targets.get(role) or next((t for n, t in targets.items() if n.lower() == role.lower()), None)
    if match is None:
        raise PlugError('unknown device "%s" - configured: %s, or give --host'
                        % (role, ', '.join(targets) or 'none'))
    password = override_password if override_password is not None else (match.get('password') or '')
    return ShellyRPC(match['host'], password, match.get('switch_id') or 0,
                     label='%s %s' % (match['kind'], role))


SHELLY_COMPONENTS = ('Shelly.GetStatus', 'Shelly.GetConfig', 'Shelly.GetDeviceInfo',
                     'Sys.GetStatus', 'Wifi.GetStatus', 'Cloud.GetStatus',
                     'MQTT.GetStatus', 'BLE.GetConfig', 'Matter.GetStatus',
                     'Switch.GetStatus', 'Temperature.GetStatus',
                     'Humidity.GetStatus', 'DevicePower.GetStatus')


def shelly_everything(rpc):
    """Ask for every component the device might have; skip what it lacks."""
    out = {}
    for method in SHELLY_COMPONENTS:
        params = None
        if method.split('.')[0] in ('Switch', 'Temperature', 'Humidity', 'DevicePower'):
            params = {'id': rpc.switch_id
                      if method.startswith('Switch') else 0}
        try:
            result = rpc.call(method, params)
        except PlugError as e:
            if not is_missing_component(e):
                raise                # a rate limit or a dead network, not absence
            continue                 # not present on this model, which is normal
        if result is not None:
            out[method] = result
    return out


def shelly_print_flat(pal, flat, title=None):
    if title:
        print(pal.group(title))
    width = max([len(k) for k in flat] + [10])
    for key in sorted(flat):
        value = flat[key]
        if isinstance(value, list):
            value = ', '.join(str(v) for v in value)
        text = 'ON' if value is True else 'OFF' if value is False else str(value)
        painter = (pal.ok if value is True else pal.bad if value is False
                   else pal.note if value is None or value == '' else pal.value)
        print('  %s : %s' % (pal.key(key.ljust(width)), painter(text)))
        note = describe_plug_field(key)
        if note:
            print('  %s   %s' % (' ' * width, pal.note(note)))


# ---- mDNS discovery -------------------------------------------------------
def local_ipv4_addresses():
    """Every IPv4 address this machine holds, one per interface.

    A multi-homed host routes 224.0.0.251 out one interface only - whichever
    the default route uses. On a machine with several VLANs that is usually not
    the one the device or its proxy is on, so the query has to be sent out of
    each of them deliberately.
    """
    import fcntl
    import struct
    addresses = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        for _, name in socket.if_nameindex():
            try:
                packed = fcntl.ioctl(sock.fileno(), 0x8915,   # SIOCGIFADDR
                                     struct.pack('256s', name.encode()[:15]))
                address = socket.inet_ntoa(packed[20:24])
            except OSError:
                continue
            if not address.startswith('127.'):
                addresses.append((name, address))
    except (OSError, AttributeError):
        pass
    finally:
        sock.close()
    return addresses


def shelly_discover(pal, seconds=4.0):
    """Find Shelly devices by asking over multicast DNS.

    Two sockets, deliberately. Answers to a multicast query come back two ways:
    to the group on port 5353, and - when the question asks for it - by unicast
    to whatever port the query went out from.

    Binding 5353 alone is not enough and can be worse than useless: avahi-daemon
    usually holds it already, and with SO_REUSEPORT a unicast datagram to that
    port is delivered to exactly one of the sockets bound to it. That is as
    likely to be avahi as us. So the query is sent from a socket on a port
    nobody else has, which is where the unicast reply then arrives, while a
    second socket joins the group to catch the multicast one.
    """
    import struct

    def encode_name(name):
        out = b''
        for label in name.split('.'):
            if label:
                out += bytes([len(label)]) + label.encode('ascii')
        return out + b'\x00'

    def read_name(data, offset, depth=0):
        parts = []
        while offset < len(data) and depth < 20:
            length = data[offset]
            if length == 0:
                offset += 1
                break
            if length & 0xC0 == 0xC0:
                pointer = struct.unpack('!H', data[offset:offset + 2])[0] & 0x3FFF
                parts.append(read_name(data, pointer, depth + 1)[0])
                offset += 2
                break
            parts.append(data[offset + 1:offset + 1 + length].decode('ascii', 'replace'))
            offset += 1 + length
        return '.'.join(p for p in parts if p), offset

    services = ['_shelly._tcp.local', '_http._tcp.local',
                '_services._dns-sd._udp.local']

    # The querying socket, on a port of our own.
    asker = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
    asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
    asker.settimeout(0.2)
    try:
        asker.bind(('', 0))
    except OSError as e:
        print(pal.bad('cannot open a socket for the query: %s' % e))
        return {}

    # And a listener on the group, for replies sent the multicast way.
    listener = None
    try:
        listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, 'SO_REUSEPORT'):
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        listener.bind(('', 5353))
        listener.settimeout(0.2)
    except OSError:
        if listener:
            listener.close()
        listener = None

    interfaces = local_ipv4_addresses()

    # Join the group on each interface by name. INADDR_ANY leaves the choice to
    # the kernel, which picks one - on a host with several VLANs that is
    # usually not the one the answer arrives on.
    joined = 0
    if listener:
        targets = [address for _, address in interfaces] or ['0.0.0.0']
        for address in targets:
            try:
                listener.setsockopt(
                    socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                    struct.pack('4s4s', socket.inet_aton('224.0.0.251'),
                                socket.inet_aton(address)))
                joined += 1
            except OSError as e:
                log('could not join the multicast group on %s: %s' % (address, e),
                    'debug')
        if not joined:
            listener.close()
            listener = None
    shelly_discover.joined = joined
    shelly_discover.interfaces = interfaces
    shelly_discover.query_port = asker.getsockname()[1]

    sent = 0
    for service in services:
        # Two questions, differing only in the top bit of the class.
        #
        # 0x8001 asks for a unicast answer, which is what gets a reply back
        # through a router that will not carry multicast.
        #
        # 0x0001 asks for the ordinary multicast answer, and that is the one an
        # avahi reflector can work with: a reflector repeats multicast between
        # interfaces and does nothing at all with unicast replies. On a network
        # where the only path is a reflector, asking for unicast quietly
        # guarantees no answer.
        for qclass in (0x8001, 0x0001):
            query = (struct.pack('!HHHHHH', 0, 0, 1, 0, 0, 0)
                     + encode_name(service) + struct.pack('!HH', 12, qclass))
            # Out of every interface, not just whichever the default route picks.
            for name, address in (interfaces or [(None, None)]):
                try:
                    if address:
                        asker.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF,
                                         socket.inet_aton(address))
                    asker.sendto(query, ('224.0.0.251', 5353))
                    sent += 1
                except OSError as e:
                    log('mDNS query out of %s failed: %s'
                        % (name or 'default', e), 'debug')
    if not sent:
        print(pal.bad('could not send the query out of any interface'))
        asker.close()
        if listener:
            listener.close()
        return {}

    found = {}
    addresses = {}
    sockets = [s for s in (asker, listener) if s]
    deadline = time.time() + seconds
    while time.time() < deadline:
        ready, _, _ = select.select(sockets, [], [], 0.3)
        for sock in ready:
            try:
                data, addr = sock.recvfrom(9000)
            except (socket.timeout, OSError):
                continue

            names = []
            try:
                counts = struct.unpack('!HHHHHH', data[:12])
                offset = 12
                for _ in range(counts[2]):
                    _, offset = read_name(data, offset)
                    offset += 4
                for _ in range(counts[3] + counts[4] + counts[5]):
                    name, offset = read_name(data, offset)
                    rtype, _cls, _ttl, length = struct.unpack(
                        '!HHIH', data[offset:offset + 10])
                    offset += 10
                    body = data[offset:offset + length]
                    if rtype == 12:                   # PTR
                        target, _ = read_name(data, offset)
                        names.append(target)
                    elif rtype == 33 and length > 6:  # SRV
                        target, _ = read_name(data, offset + 6)
                        names.append(target)
                    elif rtype == 1 and length == 4:  # A
                        addresses[name.split('.')[0].lower()] = socket.inet_ntoa(body)
                    offset += length
            except (struct.error, IndexError):
                pass

            entry = found.setdefault(addr[0], {'ip': addr[0], 'names': set()})
            for name in names:
                short = name.split('.')[0]
                # A name beginning with an underscore is a service type, not a
                # device: enumerating _services._dns-sd._udp.local answers with
                # "_shelly._tcp.local", which is the question, not a device.
                if short.startswith('_'):
                    continue
                if 'shelly' in short.lower():
                    entry['names'].add(short)

    asker.close()
    if listener:
        listener.close()

    # Prefer the address a device published for itself over the packet's source,
    # which is the proxy when one is in the way.
    result = {}
    for entry in found.values():
        if not entry['names']:
            continue
        for name in entry['names']:
            ip = addresses.get(name.lower(), entry['ip'])
            record = result.setdefault(ip, {'ip': ip, 'names': {},
                                            'via': entry['ip'] if ip != entry['ip'] else None})
            # Devices answer with the same name in different case depending on
            # which record it came from; keep one of each, preferring the form
            # the device uses for its own hostname.
            record['names'].setdefault(name.lower(), name)
            if name.islower():
                record['names'][name.lower()] = name
    return {ip: {'ip': ip, 'names': sorted(r['names'].values()), 'via': r['via']}
            for ip, r in result.items()}


# ---- WebSocket, for live pushes -------------------------------------------
def _ws_send(sock, payload):
    """Send one masked text frame, as a client must."""
    import struct
    data = payload.encode('utf-8')
    header = bytes([0x81])
    mask = secrets.token_bytes(4)
    if len(data) < 126:
        header += bytes([0x80 | len(data)])
    elif len(data) < 65536:
        header += bytes([0x80 | 126]) + struct.pack('!H', len(data))
    else:
        header += bytes([0x80 | 127]) + struct.pack('!Q', len(data))
    masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    sock.sendall(header + mask + masked)


def _ws_frames(sock):
    """Yield the payload of each text frame arriving on an open socket."""
    import struct
    buffer = b''

    def need(count):
        nonlocal buffer
        while len(buffer) < count:
            chunk = sock.recv(65536)
            if not chunk:
                raise ConnectionError('the connection closed')
            buffer += chunk
        taken, buffer = buffer[:count], buffer[count:]
        return taken

    while True:
        first, second = need(2)
        opcode = first & 0x0F
        masked = second & 0x80
        length = second & 0x7F
        if length == 126:
            length = struct.unpack('!H', need(2))[0]
        elif length == 127:
            length = struct.unpack('!Q', need(8))[0]
        mask = need(4) if masked else None
        payload = need(length) if length else b''
        if mask:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        if opcode == 0x8:                       # close
            return
        if opcode == 0x9:                       # ping, answer with a pong
            sock.sendall(bytes([0x8A, 0x00]))
            continue
        if opcode in (0x1, 0x2) and payload:
            yield payload.decode('utf-8', 'replace')



def shelly_build_parser():
    """One subparser per command, so each has its own --help like any tool."""
    parser = argparse.ArgumentParser(
        prog='zigmon shelly',
        description='Talk to the Shelly devices named in the configuration over '
                    'their local RPC API. No pairing and no cloud: the device '
                    'answers on plain HTTP while it stays connected to the '
                    'Shelly app, the cloud and Apple Home over Matter.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
addressing a device
  zigmon shelly Lednice info         a plug or sensor by the name it has in the configuration
  zigmon shelly info                 with no name, the first configured plug is assumed
  zigmon shelly --host 10.0.0.5 info  something not in the configuration at all

commands at a glance
  reading        discover, info, dump, methods, poll, watch, listen, serve
  controlling    on, off, toggle, reset-counters, reboot
  configuring    config, matter, ble
  anything else  call

quoting JSON
  Linux and PowerShell:  call Switch.SetConfig '{"id":0,"config":{"power_limit":2900}}'
  cmd.exe:               call Switch.SetConfig "{\\"id\\":0,\\"config\\":{\\"power_limit\\":2900}}"

Run 'zigmon shelly COMMAND --help' for the options of one command.
""")
    # These are accepted before the command and after it, because insisting on
    # one position is exactly the kind of thing that makes a tool annoying.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--host', metavar='ADDR',
                        help='address of the device, overriding the configuration')
    common.add_argument('--password', metavar='PASS',
                        help='password if the device has one; the username is '
                             'always admin and cannot be changed')
    common.add_argument('--switch-id', dest='switch_id', type=int, default=0,
                        help='relay id on a multi-channel device (default 0)')
    common.add_argument('--no-color', action='store_true',
                        help='plain output with no colour codes')
    common.add_argument('--json', action='store_true',
                        help='machine-readable output where the command has any')
    for action in common._actions:
        parser._add_action(action)

    subs = parser.add_subparsers(dest='command', metavar='COMMAND')

    def add(name, help_text, description=None, epilog=None):
        return subs.add_parser(
            name, help=help_text, description=description or help_text,
            epilog=epilog, parents=[common],
            formatter_class=argparse.RawDescriptionHelpFormatter)

    found = add('discover', 'find Shelly devices on the network',
                'Ask the local network for Shelly devices over multicast DNS. '
                'This does not cross subnets, and some networks block it.')
    found.add_argument('--seconds', type=float, default=4.0,
                       help='how long to listen (default 4)')

    add('info', 'identity, firmware and auth state',
        'A short summary: model, name, firmware version, generation, and '
        'whether authentication and Matter are switched on.')

    add('dump', 'everything the device exposes, in one go',
        'Every component the device has, each with every field it reports. '
        'Use --json to get the replies exactly as the device sent them.')

    methods = add('methods', 'list every RPC method the device supports',
                  'Asks the device for its own method list, and explains the '
                  'ones worth knowing. Useful before reaching for "call": '
                  'whatever appears here can be invoked, and nothing else can.',
                  epilog="""
examples
  zigmon shelly plug methods                 everything, with notes
  zigmon shelly plug methods Switch          just one component
  zigmon shelly plug methods --examples      with a ready-made call for each
  zigmon shelly plug methods Webhook --examples --described
""")
    methods.add_argument('component', nargs='?',
                         help='only this component: Switch, Wifi, Webhook ...')
    methods.add_argument('--examples', action='store_true',
                         help='print a ready-made call under each method')
    methods.add_argument('--described', action='store_true',
                         help='hide methods there is nothing useful to say about')

    config = add('config', 'read or change a component configuration',
                 'With no arguments, the whole device configuration. With a '
                 'component, just that one. With a component and a JSON object, '
                 'the settings in that object are written.',
                 epilog="""
examples
  zigmon shelly plug config                       everything
  zigmon shelly plug config switch:0              one component
  zigmon shelly plug config sys                   the system section
  zigmon shelly plug config switch:0 '{"auto_off": true, "auto_off_delay": 60}'
  zigmon shelly plug config ble '{"enable": true}'

A write is checked by reading the value back, so a setting the firmware quietly
ignores is reported rather than assumed to have taken.
""")
    config.add_argument('component', nargs='?',
                        help='switch:0, sys, wifi, ble, matter, cloud, mqtt ...')
    config.add_argument('settings', nargs='?',
                        help='JSON object of settings to write')
    config.add_argument('--reboot', action='store_true',
                        help='restart the device afterwards, which some '
                             'settings need before they take effect')

    poll = add('poll', 'read the device on a timer, optionally to CSV',
               'A live table of the numbers the device reports. A sleeping '
               'battery device is retried rather than treated as an error.')
    poll.add_argument('--interval', type=float, default=5.0,
                      help='seconds between readings (default 5)')
    poll.add_argument('--count', type=int, help='stop after this many readings')
    poll.add_argument('--csv', metavar='FILE', help='append readings to a CSV file')

    add('watch', 'live push updates over websocket',
        'Subscribe to the device\'s own notifications instead of polling it. '
        'The websocket carries no authentication, so this does not work on a '
        'device with a password set - use poll there.')

    listen = add('listen', 'receive webhooks from a sleeping battery device',
                 'Print pushes as they arrive. Nothing is recorded; the daemon '
                 'stores them when sensor_listen is on.')
    listen.add_argument('--port', type=int, help='port to listen on')

    serve = add('serve', 'accept outbound websocket pushes from devices',
                'For a device configured to connect out to us rather than be '
                'polled.')
    serve.add_argument('--port', type=int, default=8089, help='port (default 8089)')

    add('on', 'switch the relay on')
    add('off', 'switch the relay off')
    add('toggle', 'flip the relay to the other state')

    reset = add('reset-counters', 'reset the plug\'s running totals',
                'With no type, every counter the device has. The values are '
                'read back afterwards, so a counter the firmware refuses to '
                'clear is reported rather than assumed reset.',
                epilog="""
counter types
  aenergy        active energy, the kilowatt-hour total
  ret_aenergy    energy returned to the grid
  on_time        total runtime, how long the relay has been on
  switch_on      switching cycles
  on_above_thr   active load runtime, time above the plug's threshold
""")
    reset.add_argument('types', nargs='*', help='which counters; none means all')

    reboot = add('reboot', 'restart the device')
    reboot.add_argument('--wait', action='store_true',
                        help='wait for it to come back and report the firmware')

    matter = add('matter', 'Matter on, off, status, or the pairing code',
                 'Matter has to be enabled before a controller can commission '
                 'the device, and the change needs a reboot.')
    matter.add_argument('action', nargs='?', default='status',
                        choices=['status', 'on', 'off', 'code'])
    matter.add_argument('--reboot', action='store_true',
                        help='restart afterwards so the change takes effect')

    ble = add('ble', 'Bluetooth radio and BLE RPC on, off or status',
              'The radio and the RPC-over-Bluetooth service are separate '
              'switches. Both need a reboot to take effect.')
    ble.add_argument('action', nargs='?', default='status',
                     choices=['status', 'on', 'off', 'rpc-on', 'rpc-off'])
    ble.add_argument('--reboot', action='store_true',
                     help='restart afterwards so the change takes effect')

    call = add('call', 'invoke any RPC method directly',
               'For anything the commands above do not cover. Run "methods" '
               'first to see what this device accepts.',
               epilog="""
examples
  zigmon shelly plug call Shelly.GetStatus
  zigmon shelly plug call Switch.GetStatus '{"id":0}'
  zigmon shelly plug call Switch.SetConfig '{"id":0,"config":{"power_limit":2900}}'
""")
    call.add_argument('method', help='for example Switch.GetStatus')
    call.add_argument('params', nargs='?', help='JSON object of parameters')

    return parser


def shelly_main(argv, pal):
    """zigmon shelly [name] <command> - the whole toolkit, addressed by name."""
    arguments = list(argv)

    # The global options are accepted anywhere. argparse lets a subcommand's
    # defaults overwrite what was given before it, so they are taken off by
    # hand first and put back after parsing.
    globals_ = {'host': None, 'password': None, 'switch_id': None, 'json': False, 'no_color': False}
    cleaned = []
    skip = False
    for index, value in enumerate(arguments):
        if skip:
            skip = False
            continue
        if value in ('--host', '--password', '--switch-id') and index + 1 < len(arguments):
            key = value.lstrip('-').replace('-', '_')
            globals_[key] = arguments[index + 1]
            skip = True
            continue
        if value.startswith('--host='):
            globals_['host'] = value.split('=', 1)[1]
            continue
        if value.startswith('--password='):
            globals_['password'] = value.split('=', 1)[1]
            continue
        if value == '--json':
            globals_['json'] = True
            continue
        if value == '--no-color':
            globals_['no_color'] = True
            continue
        cleaned.append(value)
    arguments = cleaned

    # The device name comes before the command, which subparsers cannot
    # express. Take it off the front first; everything after is ordinary.
    targets = shelly_targets()
    names = {n.lower(): n for n in targets}
    commands = ('discover', 'info', 'dump', 'methods', 'config', 'poll', 'watch', 'listen', 'serve',
                'on', 'off', 'toggle', 'reset-counters', 'reboot', 'matter', 'ble', 'call')
    role = None
    for index, value in enumerate(arguments):
        if value.startswith('-'):
            continue
        if value.lower() in names:
            role = names[value.lower()]
            arguments.pop(index)
        elif value not in commands and not globals_['host'] and value not in ('-h', '--help'):
            print(pal.bad('ERROR: ') + 'unknown device "%s"' % value, file=sys.stderr)
            print(pal.note('  configured: %s' % (', '.join(targets) or 'none')
                           + '; or give --host ADDR'), file=sys.stderr)
            return 2
        break
    if role is None and not globals_['host'] and targets:
        role = list(targets)[0]

    parser = shelly_build_parser()
    args = parser.parse_args(arguments)
    args.device = role
    args.host = globals_['host']
    args.password = globals_['password']
    args.switch_id = int(globals_['switch_id'] or 0)
    args.json = globals_['json']
    args.no_color = globals_['no_color']
    if not args.command:
        parser.print_help()
        return 0
    if args.no_color:
        pal = Palette(False)

    handler = {
        'discover': shelly_cmd_discover, 'info': shelly_cmd_info,
        'dump': shelly_cmd_dump, 'methods': shelly_cmd_methods,
        'config': shelly_cmd_config, 'poll': shelly_cmd_poll,
        'watch': shelly_cmd_watch, 'listen': shelly_cmd_listen,
        'serve': shelly_cmd_serve, 'on': shelly_cmd_switch,
        'off': shelly_cmd_switch, 'toggle': shelly_cmd_switch,
        'reset-counters': shelly_cmd_reset, 'call': shelly_cmd_call,
        'reboot': shelly_cmd_reboot, 'ble': shelly_cmd_radio,
        'matter': shelly_cmd_radio,
    }[args.command]

    try:
        return handler(args, pal)
    except PlugError as e:
        print(pal.bad('ERROR: ') + str(e), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print('\nstopped.')
        return 0


def shelly_cmd_discover(args, pal):
    print(pal.note('asking the network for Shelly devices, %.0fs...' % args.seconds))
    found = shelly_discover(pal, args.seconds)
    if args.json:
        print(json.dumps(list(found.values()), indent=2))
        return 0
    if not found:
        print(pal.warn('nothing answered'))
        for line in discovery_diagnosis(pal):
            print(line)
        print()
        print(pal.note('  Nothing here depends on discovery. Give the address '
                       'directly and everything else works:'))
        print(pal.note('    zigmon shelly --host 172.16.16.12 info'))
        print(pal.note('  or add it under "plugs" in %s.' % CONFIG_FILE))
        return 1
    for entry in sorted(found.values(), key=lambda e: e['ip']):
        line = '  %s  %s' % (pal.value(entry['ip'].ljust(15)),
                             pal.note(', '.join(entry['names'])))
        if entry.get('via'):
            line += pal.note('  (relayed by %s)' % entry['via'])
        print(line)
    print(pal.note('  %d device(s)' % len(found)))
    return 0


def discovery_diagnosis(pal):
    """Why an empty result is usually the local machine's own doing.

    On a stock AlmaLinux 9 the firewall drops inbound multicast DNS until the
    service is allowed, and a reply to a multicast query is not something
    connection tracking will let back in on its own. That is the first thing to
    check, and the tool can check it rather than leaving it to guesswork.
    """
    lines = []

    interfaces = getattr(shelly_discover, 'interfaces', [])
    if interfaces:
        lines.append(pal.note('  The query went out of %d interface(s): %s'
                              % (len(interfaces),
                                 ', '.join('%s (%s)' % (n, a) for n, a in interfaces))))
        if len(interfaces) == 1:
            lines.append(pal.note('    If the device is reached through a VLAN '
                                  'this machine has no address on, only a proxy '
                                  'can carry the query there.'))
    joined = getattr(shelly_discover, 'joined', 0)
    if not joined:
        lines.append(pal.warn('  Could not join the multicast group on port 5353.'))
        lines.append(pal.note('    Only a unicast reply can reach us, and an '
                              'avahi reflector does not forward those - it '
                              'repeats multicast between interfaces and nothing '
                              'else. Check what holds the port:'))
        lines.append(pal.key('      ss -lunp | grep 5353'))
    else:
        lines.append(pal.note('  Joined the multicast group on %d interface(s), '
                              'and asked for both a unicast and a multicast '
                              'answer.' % joined))
        lines.append(pal.note('    A reflector can only carry the multicast one, '
                              'so that path is covered.'))

    blocked = firewalld_blocks_mdns()
    if blocked is True:
        lines.append(pal.bad('  firewalld is running and mDNS is not allowed in '
                             'the active zone.'))
        lines.append(pal.note('    Replies to a multicast query are dropped, '
                              'because connection tracking has nothing to match '
                              'them against. Allow the service:'))
        lines.append(pal.key('      sudo firewall-cmd --permanent --add-service=mdns'))
        lines.append(pal.key('      sudo firewall-cmd --reload'))
    elif blocked is False:
        lines.append(pal.ok('  firewalld allows mDNS, so the firewall is not the '
                            'problem here.'))
    else:
        lines.extend(iptables_diagnosis(pal))

    lines.append(pal.note('  Multicast DNS does not cross subnets on its own. A '
                          'proxy or repeater between VLANs forwards it, but many '
                          'forward only the query and not the reply.'))
    if shutil.which('avahi-browse'):
        lines.append(pal.note('  avahi is installed here, so it can be asked the '
                              'same question independently:'))
        lines.append(pal.key('      avahi-browse -art | grep -i shelly'))
        lines.append(pal.note('    If that finds nothing either, the replies are '
                              'not reaching this machine at all and the cause is '
                              'in the network, not here.'))
    lines.append(pal.note('  Strict reverse-path filtering also drops replies '
                          'that arrive from another VLAN. Check with:'))
    lines.append(pal.key('      sysctl net.ipv4.conf.all.rp_filter'))
    lines.append(pal.note('    2 (loose) or 0 tolerates it; 1 (strict) will not.'))
    return lines


def iptables_diagnosis(pal):
    """The same question for a machine running iptables directly.

    Two rules are needed, not one. Answers arrive at port 5353 when we hold it,
    and at whatever port the query went out from when avahi already has 5353 -
    the unicast-response bit is what makes that second case work, and it needs
    a rule of its own because connection tracking will not match a reply to a
    multicast destination.
    """
    import subprocess
    lines = []
    try:
        rules = subprocess.run(['iptables', '-S', 'INPUT'],
                               capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return lines
    if rules.returncode != 0:
        if 'permission' in (rules.stderr or '').lower():
            lines.append(pal.note('  Run as root to have the firewall checked '
                                  'as well.'))
        return lines

    text = rules.stdout
    # A chain whose policy is ACCEPT but which ends in a catch-all REJECT is
    # every bit as closed as one with a DROP policy. Looking only at the policy
    # was wrong.
    policy_drops = any(line.startswith('-P INPUT') and 'ACCEPT' not in line
                       for line in text.split('\n'))
    catch_all = any(('-j REJECT' in line or '-j DROP' in line)
                    and '-p ' not in line and '--dport' not in line
                    for line in text.split('\n'))
    policy_drops = policy_drops or catch_all
    accepts_5353 = any('5353' in line and '-j ACCEPT' in line
                       for line in text.split('\n'))
    accepts_group = any('224.0.0.251' in line and '-j ACCEPT' in line
                        for line in text.split('\n'))

    if not policy_drops:
        lines.append(pal.ok('  iptables accepts by default, so the firewall is '
                            'not blocking this.'))
        return lines
    if accepts_5353:
        lines.append(pal.ok('  iptables already allows mDNS both ways, so the '
                            'firewall is not the problem.'))
        return lines

    if accepts_group:
        lines.append(pal.warn('  iptables allows the multicast group but not a '
                              'unicast reply.'))
        lines.append(pal.note('    A proxy answers from port 5353 to whatever '
                              'port the query went out from, which the existing '
                              'rule does not cover. Add:'))
        lines.append(pal.key('      iptables -I INPUT -p udp --sport 5353 -j ACCEPT'))
    else:
        lines.append(pal.bad('  iptables drops by default and nothing allows mDNS.'))
        lines.append(pal.note('    Two rules, because answers arrive two ways:'))
        lines.append(pal.key('      iptables -I INPUT -p udp --dport 5353 -j ACCEPT'))
        lines.append(pal.note('        replies to the multicast group, when we '
                              'hold port 5353'))
        lines.append(pal.key('      iptables -I INPUT -p udp --sport 5353 -j ACCEPT'))
        lines.append(pal.note('        unicast replies to a temporary port, which '
                              'is what a proxy sends and what avahi leaves us with'))

    lines.append(pal.note('    Then make it survive a reboot:'))
    lines.append(pal.key('      service iptables save'))
    lines.append(pal.note('        or iptables-save > /etc/sysconfig/iptables'))
    return lines


def firewalld_blocks_mdns():
    """True, False, or None when firewalld is not running or not installed."""
    import subprocess
    try:
        state = subprocess.run(['firewall-cmd', '--state'],
                               capture_output=True, text=True, timeout=5)
        if state.returncode != 0:
            return None
        allowed = subprocess.run(['firewall-cmd', '--query-service=mdns'],
                                 capture_output=True, text=True, timeout=5)
        if 'yes' in allowed.stdout:
            return False
        ports = subprocess.run(['firewall-cmd', '--list-ports'],
                               capture_output=True, text=True, timeout=5)
        return '5353/udp' not in ports.stdout
    except (OSError, subprocess.SubprocessError):
        return None


def shelly_cmd_info(args, pal):
    rpc = shelly_for(args.device, args)
    info = rpc.call('Shelly.GetDeviceInfo')
    if args.json:
        print(json.dumps(info, indent=2))
        return 0
    shelly_print_flat(pal, flatten(info), '  %s' % rpc.host)
    return 0


def shelly_cmd_dump(args, pal):
    rpc = shelly_for(args.device, args)
    everything = shelly_everything(rpc)
    if not everything:
        raise PlugError('the device answered nothing we recognise')
    if args.json:
        print(json.dumps(everything, indent=2))
        return 0
    info = everything.get('Shelly.GetDeviceInfo', {})
    bar = '=' * 78
    print(pal.rule(bar))
    print('  ' + pal.title('%s  %s' % (info.get('model', args.device or rpc.host),
                                       info.get('name', ''))))
    print('  ' + pal.note('zigmon v%s   |   %s   |   firmware %s   |   %s'
                          % (__version__, rpc.host, info.get('ver', '?'),
                             datetime.now().strftime('%Y-%m-%d %H:%M:%S'))))
    print(pal.rule(bar))
    for method in sorted(everything):
        flat = flatten(everything[method])
        if not flat:
            continue
        print('\n' + pal.group('-- %s ' % method)
              + pal.rule('-' * max(1, 74 - len(method))))
        shelly_print_flat(pal, flat)
    print('\n' + pal.rule(bar))
    return 0


# What a live table should show first. Timestamps and component ids are
# numbers too, and picking those over the actual measurements made the poll
# output useless.
POLL_PREFERRED = ['apower', 'voltage', 'current', 'pf', 'freq', 'aenergy.total',
                  'ret_aenergy.total', 'temperature.tC', 'tC', 'rh',
                  'battery.percent', 'battery.V', 'wifi.rssi', 'sys.uptime']
POLL_SKIP = re.compile(r'(_ts$|\.id$|^id$|minute_ts|\.0$|ram_|fs_)')


def shelly_numeric(flat):
    numeric = [k for k, v in flat.items()
               if isinstance(v, (int, float)) and not isinstance(v, bool)
               and not POLL_SKIP.search(k)]
    def rank(key):
        tail = re.sub(r'^[a-z_0-9]+:\d+\.', '', key)
        for index, wanted in enumerate(POLL_PREFERRED):
            if tail == wanted:
                return (0, index)
        return (1, key)
    return sorted(numeric, key=rank)


def shelly_cmd_methods(args, pal):
    """Everything this device will answer, straight from the device."""
    rpc = shelly_for(args.device, args)
    try:
        result = rpc.call('Shelly.ListMethods')
    except PlugError as e:
        if is_missing_component(e):
            raise PlugError('this device does not publish a method list; it is '
                            'probably older than Gen2 firmware 0.14')
        raise
    methods = sorted((result or {}).get('methods', []))
    if args.component:
        wanted = args.component.lower().rstrip('.')
        methods = [m for m in methods if m.split('.')[0].lower() == wanted]
        if not methods:
            print(pal.warn('no component called "%s" on this device'
                           % args.component))
            return 1

    if args.json:
        if args.described:
            print(json.dumps({m: {'description': RPC_METHODS[m][0],
                                  'example': RPC_METHODS[m][1]}
                              for m in methods if m in RPC_METHODS}, indent=2))
        else:
            print(json.dumps(methods, indent=2))
        return 0
    if not methods:
        print(pal.warn('the device returned an empty list'))
        return 1

    groups = {}
    for method in methods:
        groups.setdefault(method.split('.')[0], []).append(method)

    described = 0
    for component in sorted(groups):
        note = RPC_COMPONENTS.get(component, '')
        heading = '-- %s ' % component
        print('\n' + pal.group(heading) + pal.rule('-' * max(1, 70 - len(heading))))
        if note:
            print('  ' + pal.note(note))
        for method in groups[component]:
            entry = RPC_METHODS.get(method)
            if not entry and args.described:
                continue
            print('  ' + pal.value(method))
            if entry:
                described += 1
                print('      ' + pal.note(entry[0]))
                if entry[1] and args.examples:
                    print('      ' + pal.key('zigmon shelly %s call %s %s'
                                             % (args.device or 'NAME', method,
                                                shell_quote(entry[1]))))
                elif not entry[1] and args.examples:
                    print('      ' + pal.key('zigmon shelly %s call %s'
                                             % (args.device or 'NAME', method)))

    print('\n' + pal.rule('=' * 74))
    print(pal.note('  %d method(s) across %d component(s); %d of them described '
                   'here.' % (len(methods), len(groups), described)))
    if not args.examples:
        print(pal.note('  --examples adds a ready-made call for each one, '
                       '--described hides the rest.'))
    print(pal.note('  Anything listed can be used with "call", described or not.'))
    return 0


def shell_quote(text):
    """Quote a JSON argument for a shell, or leave it for cmd.exe to mangle."""
    if os.name == 'nt':
        return '"' + text.replace('"', '\\"') + '"'
    return "'" + text + "'"


def shelly_cmd_config(args, pal):
    """Read a configuration, or write one and check it took."""
    rpc = shelly_for(args.device, args)

    if not args.component:
        config = rpc.call('Shelly.GetConfig')
        if args.json:
            print(json.dumps(config, indent=2))
            return 0
        flat = flatten(config)
        for component in sorted({k.split('.')[0] for k in flat}):
            section = {k: v for k, v in flat.items()
                       if k == component or k.startswith(component + '.')}
            print('\n' + pal.group('-- %s ' % component)
                  + pal.rule('-' * max(1, 70 - len(component))))
            shelly_print_flat(pal, section)
        print('\n' + pal.note('  %d setting(s). Give a component to narrow it, '
                              'and a JSON object to change it.' % len(flat)))
        return 0

    # Reading one component: Switch.GetConfig wants an id, Sys.GetConfig does not.
    component = args.component
    name, _, index = component.partition(':')
    # Shelly method names are case-insensitive, but the canonical spelling
    # reads better in the output and some proxies are picky.
    canonical = {'ble': 'BLE', 'mqtt': 'MQTT', 'wifi': 'WiFi', 'kvs': 'KVS', 'ws': 'WS', 'http': 'HTTP',
                 'ui': 'UI', 'bthome': 'BTHome', 'pm1': 'PM1', 'em1': 'EM1', 'em': 'EM'}
    method_base = canonical.get(name.lower()) or (name[0].upper() + name[1:] if name.islower() else name)
    params = {'id': int(index)} if index.isdigit() else None

    if not args.settings:
        config = rpc.call('%s.GetConfig' % method_base, params)
        if args.json:
            print(json.dumps(config, indent=2))
            return 0
        shelly_print_flat(pal, flatten(config), '  %s' % component)
        return 0

    try:
        settings = json.loads(args.settings)
    except ValueError:
        raise PlugError('the settings must be a JSON object: %s' % args.settings)
    if not isinstance(settings, dict):
        raise PlugError('the settings must be a JSON object, not a %s'
                        % type(settings).__name__)

    before = flatten(rpc.call('%s.GetConfig' % method_base, params))
    write = dict(params or {})
    write['config'] = settings
    result = rpc.call('%s.SetConfig' % method_base, write)
    after = flatten(rpc.call('%s.GetConfig' % method_base, params))

    # Firmware accepts a whole config object and silently drops keys it does
    # not know, so say which ones actually changed rather than assuming.
    applied, ignored = [], []
    for key, wanted in flatten(settings).items():
        now = after.get(key)
        (applied if now == wanted else ignored).append(
            '%s=%s' % (key, now if now is not None else 'absent'))
    for key in applied:
        print(pal.ok('  set   ') + key)
    for key in ignored:
        print(pal.warn('  kept  ') + key
              + pal.note('  (the device did not take the new value)'))

    changed = [k for k in after if before.get(k) != after.get(k)]
    if not applied and not changed:
        print(pal.warn('  nothing changed'))
        return 1
    if (result or {}).get('restart_required') or args.reboot:
        if args.reboot:
            return shelly_cmd_reboot(args, pal)
        print(pal.note('  the device says a restart is needed: '
                       'zigmon shelly %s reboot --wait' % (args.device or 'NAME')))
    return 0


def shelly_cmd_poll(args, pal):
    rpc = shelly_for(args.device, args)
    import csv as csv_module
    handle = open(args.csv, 'a', newline='', encoding='utf-8') if args.csv else None
    writer = csv_module.writer(handle) if handle else None

    columns, printed, count = None, 0, 0
    try:
        while True:
            try:
                try:
                    status = rpc.call('Switch.GetStatus', {'id': rpc.switch_id})
                except PlugError as e:
                    if not is_missing_component(e):
                        raise
                    status = rpc.call('Shelly.GetStatus')
                flat = flatten(status)
            except PlugError as e:
                # A battery sensor is asleep most of the time; say so and retry
                # rather than giving up, which is what makes poll usable at all.
                print(pal.note('%s  %s' % (datetime.now().strftime('%H:%M:%S'), e)))
                time.sleep(args.interval)
                continue

            if columns is None:
                columns = shelly_numeric(flat)[:8]
                if writer and handle.tell() == 0:
                    writer.writerow(['timestamp'] + columns)
            if printed % 20 == 0:
                print(pal.group('  %-8s ' % 'time'
                                + ' '.join(c.rsplit('.', 1)[-1][:10].rjust(11)
                                           for c in columns)))
            print('  %-8s ' % datetime.now().strftime('%H:%M:%S')
                  + ' '.join(pal.value(('%g' % flat[c] if isinstance(flat.get(c), float)
                                        else str(flat.get(c, '-'))).rjust(11))
                             for c in columns))
            if writer:
                writer.writerow([datetime.now().isoformat(timespec='seconds')]
                                + [flat.get(c) for c in columns])
                handle.flush()
            printed += 1
            count += 1
            if args.count and count >= args.count:
                return 0
            time.sleep(args.interval)
    finally:
        if handle:
            handle.close()


def shelly_cmd_watch(args, pal):
    """Subscribe to the device's own notifications instead of polling."""
    import base64
    rpc = shelly_for(args.device, args)
    host = rpc.host.split(':')[0]
    port = int(rpc.host.split(':')[1]) if ':' in rpc.host else 80
    key = base64.b64encode(secrets.token_bytes(16)).decode()

    if rpc.password:
        print(pal.warn('this device has a password set. The websocket channel '
                       'does not carry that authentication - use poll instead.'))
        return 1

    try:
        sock = socket.create_connection((host, port), 10)
    except OSError as e:
        raise PlugError('cannot reach %s (%s)' % (rpc.host, e))
    request = ('GET /rpc HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\n'
               'Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n'
               'Sec-WebSocket-Version: 13\r\n\r\n' % (rpc.host, key))
    sock.sendall(request.encode())
    reply = b''
    while b'\r\n\r\n' not in reply:
        chunk = sock.recv(4096)
        if not chunk:
            raise PlugError('the device closed the connection during the handshake')
        reply += chunk
    if b'101' not in reply.split(b'\r\n')[0]:
        raise PlugError('the device refused the websocket upgrade')

    print(pal.note('connected to %s - press Ctrl+C to stop' % rpc.host))
    _ws_send(sock, json.dumps({'id': 1, 'src': 'zigmon',
                               'method': 'Shelly.GetStatus'}))
    try:
        for message in _ws_frames(sock):
            try:
                body = json.loads(message)
            except ValueError:
                continue
            payload = body.get('params') or body.get('result') or {}
            flat = flatten(payload)
            if not flat:
                continue
            stamp = datetime.now().strftime('%H:%M:%S')
            if args.json:
                print(json.dumps({'ts': stamp, 'data': payload}))
                continue
            print(pal.note('  ' + stamp) + '  ' + body.get('method', 'result'))
            shelly_print_flat(pal, flat)
    except (ConnectionError, OSError) as e:
        print(pal.warn('connection lost: %s' % e))
    finally:
        sock.close()
    return 0


def shelly_cmd_listen(args, pal):
    """Print webhook pushes as they arrive, without touching the database."""
    port = args.port or int(CONFIG['sensor_listen_port'])
    host = CONFIG['sensor_listen_host'] or '0.0.0.0'

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *ignored):
            pass

        def _show(self, payload):
            print('%s  %s  %s'
                  % (pal.note(datetime.now().strftime('%H:%M:%S')),
                     pal.info(self.client_address[0]), pal.value(payload)))
            self.send_response(200)
            self.send_header('Content-Length', '0')
            self.end_headers()

        def do_GET(self):
            query = parse_qs(urlparse(self.path).query)
            fields = {k: v[0] for k, v in query.items() if v}
            self._show(json.dumps(fields) if fields else self.path)

        def do_POST(self):
            length = int(self.headers.get('Content-Length') or 0)
            self._show(self.rfile.read(length).decode('utf-8', 'replace'))

    try:
        server = ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            running = 'the daemon is probably already listening there' \
                if port == int(CONFIG['sensor_listen_port']) \
                and CONFIG['sensor_listen'] else 'something else has that port'
            print(pal.bad('port %s on %s is already in use' % (port, host)))
            print(pal.note('  %s. Either stop it, or watch on a spare port and '
                           'point a webhook at that:' % running))
            print(pal.note('    zigmon shelly listen --port %d' % (port + 1)))
            return 1
        print(pal.bad('cannot listen on %s:%s - %s' % (host, port, e)))
        return 1
    print(pal.note('listening on http://%s:%s/ - point the sensor webhook here, '
                   'Ctrl+C to stop' % (host, port)))
    print(pal.note('nothing is recorded; this only shows what arrives. The daemon '
                   'stores pushes when sensor_listen is on.'))
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


def shelly_cmd_serve(args, pal):
    """Accept an outbound websocket from a device configured to call us."""
    import base64
    import hashlib
    port = args.port or 8089
    guid = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'

    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind(('0.0.0.0', port))
    except OSError as e:
        print(pal.bad('cannot listen on port %s - %s' % (port, e)))
        if e.errno == errno.EADDRINUSE:
            print(pal.note('  try another: zigmon shelly serve --port %d'
                           % (port + 1)))
        return 1
    listener.listen(4)
    print(pal.note('waiting for a device to connect to ws://<this-host>:%d/ - '
                   'Ctrl+C to stop' % port))
    try:
        while True:
            client, address = listener.accept()
            request = b''
            while b'\r\n\r\n' not in request:
                chunk = client.recv(4096)
                if not chunk:
                    break
                request += chunk
            match = re.search(rb'Sec-WebSocket-Key:\s*(\S+)', request, re.I)
            if not match:
                client.close()
                continue
            accept = base64.b64encode(
                hashlib.sha1(match.group(1) + guid.encode()).digest()).decode()
            client.sendall(('HTTP/1.1 101 Switching Protocols\r\n'
                            'Upgrade: websocket\r\nConnection: Upgrade\r\n'
                            'Sec-WebSocket-Accept: %s\r\n\r\n' % accept).encode())
            print(pal.ok('  connected: ') + address[0])
            try:
                for message in _ws_frames(client):
                    stamp = datetime.now().strftime('%H:%M:%S')
                    try:
                        body = json.loads(message)
                    except ValueError:
                        print('  %s  %s' % (pal.note(stamp), message))
                        continue
                    flat = flatten(body.get('params') or body)
                    print('  %s  %s' % (pal.note(stamp),
                                        body.get('method', 'message')))
                    shelly_print_flat(pal, flat)
            except (ConnectionError, OSError):
                pass
            finally:
                client.close()
                print(pal.note('  disconnected: %s' % address[0]))
    finally:
        listener.close()
    return 0


def shelly_cmd_switch(args, pal):
    rpc = shelly_for(args.device, args)
    switch_id = rpc.switch_id
    if args.command == 'toggle':
        rpc.call('Switch.Toggle', {'id': switch_id})
    else:
        rpc.call('Switch.Set', {'id': switch_id, 'on': args.command == 'on'})
    state = rpc.call('Switch.GetStatus', {'id': switch_id})
    on = bool(state.get('output'))
    print(pal.ok('  socket is ON') if on else pal.bad('  socket is OFF'))
    if state.get('apower') is not None:
        print(pal.note('  drawing %s W' % state['apower']))
    return 0


def shelly_cmd_reset(args, pal):
    """reset-counters [type ...] — no type means every counter the plug has."""
    rpc = shelly_for(args.device, args)
    switch_id = rpc.switch_id
    types = [t for arg in args.types for t in arg.split(',') if t]
    unknown = [t for t in types if t not in PLUG_COUNTER_TYPES]
    if unknown:
        print(pal.bad('  unknown counter: %s' % ', '.join(unknown)))
        print(pal.note('  choose from: %s' % ', '.join(PLUG_COUNTER_TYPES)))
        return 1

    rpc.reset_counters(types or None)
    state = rpc.call('Switch.GetStatus', {'id': switch_id})
    print(pal.ok('  reset %s' % (', '.join(types) if types else 'every counter')))
    flat = flatten(state)
    for key in ('aenergy.total', 'ret_aenergy.total', 'counts.on_time',
                'counts.switch_on', 'counts.on_above_thr'):
        if key in flat:
            print(pal.note('    %-22s %s' % (key, flat[key])))
    return 0


def shelly_cmd_call(args, pal):
    rpc = shelly_for(args.device, args)
    method = args.method
    params = None
    if args.params:
        try:
            params = json.loads(args.params)
        except ValueError:
            raise PlugError('the parameters must be JSON: %s' % args.params)
    result = rpc.call(method, params)
    if args.json or not isinstance(result, dict):
        print(json.dumps(result, indent=2))
        return 0
    shelly_print_flat(pal, flatten(result), '  %s' % method)
    return 0


def shelly_cmd_reboot(args, pal):
    rpc = shelly_for(args.device, args)
    rpc.call('Shelly.Reboot')
    print(pal.ok('  reboot requested'))
    # Called from ble/matter/config --reboot there is no --wait flag; those
    # want to check the result afterwards, so they wait.
    if not getattr(args, 'wait', True):
        return 0
    print(pal.note('  waiting for it to come back...'))
    deadline = time.time() + 60
    time.sleep(3)
    while time.time() < deadline:
        try:
            info = rpc.call('Shelly.GetDeviceInfo')
            print(pal.ok('  back after %ds' % int(60 - (deadline - time.time())))
                  + pal.note('  firmware %s' % info.get('ver')))
            return 0
        except PlugError:
            time.sleep(2)
    print(pal.warn('  it has not answered within 60s'))
    return 1


def is_missing_component(error):
    """Did the device say it does not have this, or did something else fail?"""
    text = str(error).lower()
    if 'rate limiting' in text or '429' in text or 'cannot reach' in text:
        return False
    return ('unknown method' in text or 'no handler' in text
            or '-105' in text or 'not found' in text or '404' in text)


def ble_report(rpc, pal):
    """Config and live status of the Bluetooth radio, with the reason it may still advertise."""
    config = rpc.call('BLE.GetConfig')
    enabled = bool(config.get('enable'))
    over_ble = bool((config.get('rpc') or {}).get('enable'))
    observer = (config.get('observer') or {}).get('enable')
    print('  %s is %s' % ('BLE', pal.ok('enabled') if enabled else pal.bad('disabled')))
    print('  %s is %s' % ('RPC over Bluetooth', pal.ok('enabled') if over_ble else pal.bad('disabled')))
    if observer is not None:
        print('  %s is %s' % ('BLE observer (BLU gateway)', pal.ok('enabled') if observer else pal.bad('disabled')))
    status = {}
    try:
        status = rpc.call('BLE.GetStatus') or {}
        shelly_print_flat(pal, flatten(status))
    except PlugError:
        pass
    flags = str(status.get('flags') or '')
    advertising = 'advertising' in flags
    if advertising and not enabled:
        print(pal.warn('  the radio is still advertising although BLE is disabled:'))
        # A change to ble.enable only takes effect after a restart.
        print(pal.note('    - the setting takes effect after a reboot: zigmon shelly %s reboot --wait'
                       % (getattr(rpc, 'role', None) or 'NAME')))
        # Matter commissioning keeps its own BLE beacon on until the device is
        # commissioned, whatever ble.enable says.
        try:
            mconf = rpc.call('Matter.GetConfig') or {}
            mstat = rpc.call('Matter.GetStatus') or {}
            if mconf.get('enable') and not (mstat.get('num_fabrics') or 0):
                print(pal.note('    - Matter is enabled and the device is not commissioned, so it keeps '
                               'advertising for a Matter controller regardless of the BLE switch.'))
                print(pal.note('      Turn it off too: zigmon shelly %s matter off --reboot'
                               % (getattr(rpc, 'role', None) or 'NAME')))
        except PlugError:
            pass
    return enabled, over_ble, advertising


def shelly_cmd_radio(args, pal):
    """ble and matter: status, on, off - both are a config flag plus a reboot."""
    rpc = shelly_for(args.device, args)
    rpc.role = args.device
    component = 'BLE' if args.command == 'ble' else 'Matter'
    action = (args.action or 'status').lower()

    if action == 'status':
        try:
            if component == 'BLE':
                ble_report(rpc, pal)
                return 0
            config = rpc.call('%s.GetConfig' % component)
        except PlugError as e:
            if is_missing_component(e):
                raise PlugError('%s is not available on this device' % component)
            raise
        enabled = bool(config.get('enable'))
        print('  %s is %s' % (component, pal.ok('enabled') if enabled else pal.bad('disabled')))
        try:
            shelly_print_flat(pal, flatten(rpc.call('%s.GetStatus' % component)))
        except PlugError:
            pass
        return 0

    if action == 'code':
        if component != 'Matter':
            raise PlugError('only matter has a pairing code')
        try:
            status = rpc.call('Matter.GetStatus')
        except PlugError as e:
            if is_missing_component(e):
                raise PlugError('this device does not support Matter')
            raise
        code = status.get('setup_code') or status.get('manual_pairing_code')
        payload = status.get('setup_payload') or status.get('qr_code')
        if not code and not payload:
            raise PlugError('the device did not return a pairing code. Matter has to be enabled '
                            'and the device not yet commissioned for one to exist.')
        if code:
            print('  manual pairing code : ' + pal.value(str(code)))
        if payload:
            print('  setup payload       : ' + pal.value(str(payload)))
        print(pal.note('  a controller needs one of these to commission the device'))
        return 0

    if action in ('rpc-on', 'rpc-off'):
        if component != 'BLE':
            raise PlugError('only ble has an rpc switch')
        rpc.call('BLE.SetConfig', {'config': {'rpc': {'enable': action == 'rpc-on'}}})
        config = rpc.call('BLE.GetConfig')
        settled = bool((config.get('rpc') or {}).get('enable'))
        if settled != (action == 'rpc-on'):
            print(pal.warn('  the device did not accept the change'))
            return 1
        print(pal.ok('  BLE RPC %s' % ('enabled' if settled else 'disabled')))
        if args.reboot:
            return shelly_cmd_reboot(args, pal)
        print(pal.note('  a reboot is needed for this to take effect: zigmon shelly %s reboot --wait'
                       % (args.device or 'NAME')))
        return 0

    if action not in ('on', 'off'):
        raise PlugError('use %s status, %s on or %s off' % (args.command, args.command, args.command))

    if component == 'BLE' and action == 'off':
        # Off means off: the radio, RPC over it, and the observer that scans
        # for BLU devices. Firmware without an observer ignores that key.
        rpc.call('BLE.SetConfig', {'config': {'enable': False, 'rpc': {'enable': False},
                                              'observer': {'enable': False}}})
    else:
        rpc.call('%s.SetConfig' % component, {'config': {'enable': action == 'on'}})
    config = rpc.call('%s.GetConfig' % component)
    settled = bool(config.get('enable'))
    if settled != (action == 'on'):
        print(pal.warn('  the device did not accept the change'))
        return 1
    print(pal.ok('  %s %s' % (component, 'enabled' if settled else 'disabled')))
    if args.reboot:
        rc = shelly_cmd_reboot(args, pal)
        if rc == 0 and component == 'BLE':
            print()
            _, _, advertising = ble_report(rpc, pal)
            if action == 'off' and advertising:
                return 1
        return rc
    print(pal.note('  a reboot is needed for this to take effect: zigmon shelly %s reboot --wait'
                   % (args.device or 'NAME')))
    if component == 'BLE' and action == 'off':
        try:
            mconf = rpc.call('Matter.GetConfig') or {}
            mstat = rpc.call('Matter.GetStatus') or {}
            if mconf.get('enable') and not (mstat.get('num_fabrics') or 0):
                print(pal.warn('  Matter is enabled and not commissioned: it will keep the BLE beacon on '
                               'even after the reboot. Turn it off too: zigmon shelly %s matter off --reboot'
                               % (args.device or 'NAME')))
        except PlugError:
            pass
    return 0


def build_parser():
    p = argparse.ArgumentParser(
        prog='zigmon',
        description='Zigbee2MQTT sensor monitor: daemon, history, localhost API (zigmon %s).' % __version__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Run with no arguments to start the daemon in the foreground - that is what the
systemd unit does. Everything else below is for testing and day-to-day use.

  zigmon --status                    every device with its latest readings
  zigmon --devices                   the device table (--json for machines)
  zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
  zigmon --events                    what the daemon has logged
  zigmon --watch                     live feed straight from the broker
  zigmon --watch --bridge --raw      including bridge/* topics, untruncated
  zigmon --permit-join on            open the Zigbee network for four minutes
  zigmon --plug                      every smart plug, live from the device
  zigmon --plug-on Lednice           switch a plug; also --plug-off, --plug-toggle
  zigmon --plug-reset Lednice --types aenergy,switch_on
  zigmon --bindings                  which button action drives which plug
  zigmon --check                     is the whole system healthy
  zigmon --diag                      settings, API latency, database size
  zigmon --aggregate                 roll old samples up now (daemon stopped)
  zigmon --reset-data history        erase: all, history, events, or a device name

Every command the standalone Shelly reader had is available under "shelly",
addressed by the name a device has in the configuration - the address and
password come from there:

  zigmon shelly Lednice info         identity and firmware
  zigmon shelly Lednice dump         every value the device reports
  zigmon shelly Lednice methods      every RPC method it supports (--examples)
  zigmon shelly Lednice config       the whole configuration
  zigmon shelly Lednice config switch:0 '{"auto_off": true}'
  zigmon shelly Lednice poll         a live table of the numbers (--csv FILE)
  zigmon shelly Lednice watch        the same, pushed rather than polled
  zigmon shelly Lednice on|off|toggle
  zigmon shelly Lednice reset-counters [aenergy ...]
  zigmon shelly Lednice reboot --wait
  zigmon shelly Lednice ble status|on|off|rpc-on|rpc-off [--reboot]
  zigmon shelly Lednice matter status|on|off|code [--reboot]
  zigmon shelly Lednice call Switch.GetStatus '{"id":0}'
  zigmon shelly HT-Sklep dump        a sensor, while it is awake
  zigmon shelly listen               show webhook pushes as they arrive
  zigmon shelly serve                accept an outbound websocket
  zigmon shelly discover             find Shelly devices on the LAN
  zigmon shelly --host 10.0.0.5 info a device not in the configuration
  zigmon shelly --help               the command list
  zigmon shelly config --help        the options of one command

Configuration lives in /etc/zigmon/config.json; every scalar key can also be
given as an environment variable with a ZIGMON_ prefix (ZIGMON_MQTT_HOST=...).
""")
    p.add_argument('--version', action='version', version='zigmon ' + __version__)
    p.add_argument('--config', metavar='FILE', help='configuration file (default %s)' % CONFIG_FILE)
    p.add_argument('--debug', action='store_true', help='verbose logging')
    p.add_argument('--json', action='store_true', help='machine-readable output where supported')
    p.add_argument('--no-color', action='store_true')
    p.add_argument('-y', '--yes', action='store_true', help='do not ask for confirmation')
    p.add_argument('--allow-root', action='store_true',
                   help='run the daemon as root anyway (only with a scratch --config)')
    a = p.add_argument_group('actions')
    a.add_argument('--status', action='store_true', help='every device with its latest readings')
    a.add_argument('--devices', action='store_true', help='the device table')
    a.add_argument('--history', metavar='DEVICE', help='recorded samples of one device')
    a.add_argument('--range', metavar='SPAN', help='for --history: 6h, 24h, 7d, 30d, 1y (default 24h)')
    a.add_argument('--keys', metavar='K1,K2', help='for --history: which readings')
    a.add_argument('--points', type=int, default=200, help='for --history: at most this many rows')
    a.add_argument('--events', action='store_true', help='the event log')
    a.add_argument('--limit', type=int, default=50, help='for --events')
    a.add_argument('--watch', action='store_true', help='live feed straight from the broker')
    a.add_argument('--seconds', type=float, default=0, help='for --watch: stop after this long')
    a.add_argument('--count', type=int, default=0, help='for --watch: stop after this many messages')
    a.add_argument('--bridge', action='store_true', help='for --watch: include bridge/* topics')
    a.add_argument('--raw', action='store_true', help='for --watch: do not shorten payloads')
    a.add_argument('--permit-join', metavar='on|off', help='open or close the Zigbee network')
    a.add_argument('--plug', metavar='NAME', nargs='?', const='all', help='the smart plug(s), live')
    a.add_argument('--plug-on', metavar='NAME', help='switch a plug on')
    a.add_argument('--plug-off', metavar='NAME', help='switch a plug off')
    a.add_argument('--plug-toggle', metavar='NAME', help='switch a plug to the other state')
    a.add_argument('--plug-reset', metavar='NAME', help='reset its counters (all, or --types a,b)')
    a.add_argument('--types', metavar='T1,T2', help='for --plug-reset: %s' % ', '.join(PLUG_COUNTER_TYPES))
    a.add_argument('--bindings', action='store_true', help='which button action drives which plug')
    a.add_argument('--reset-data', metavar='SCOPE', help='erase: all, history, events, or a device name')
    a.add_argument('--check', action='store_true', help='health check against the running daemon')
    a.add_argument('--diag', action='store_true', help='config, API latency, database size')
    a.add_argument('--aggregate', action='store_true', help='roll old samples up now (daemon must be stopped)')
    return p


def main(argv=None):
    global DEBUG, CONFIG_FILE
    arguments = list(sys.argv[1:] if argv is None else argv)

    # "zigmon shelly ..." is a world of its own, with its own options.
    if arguments and arguments[0] == 'shelly':
        rest = []
        skip = False
        for index, value in enumerate(arguments[1:]):
            if skip:
                skip = False
                continue
            if value == '--config' and index + 2 < len(arguments):
                CONFIG_FILE = Path(arguments[index + 2])
                skip = True
                continue
            rest.append(value)
        load_config()
        for problem in CONFIG_FATAL:
            sys.stderr.write('CONFIG: %s\n' % problem)
        pal = Palette('--no-color' not in rest and sys.stdout.isatty())
        return shelly_main(rest, pal)

    args = build_parser().parse_args(arguments)
    if args.config:
        CONFIG_FILE = Path(args.config)
    DEBUG = args.debug
    load_config()
    pal = Palette(not args.no_color and sys.stdout.isatty())

    if CONFIG_FATAL and not (args.check or args.diag):
        for note in CONFIG_FATAL:
            sys.stderr.write('ERROR: %s\n' % note)
        return 2

    if args.status:
        return cmd_status(args, pal)
    if args.devices:
        return cmd_devices(args, pal)
    if args.history:
        return cmd_history(args, pal)
    if args.events:
        return cmd_events(args, pal)
    if args.watch:
        return cmd_watch(args, pal)
    if args.permit_join:
        return cmd_permit_join(args, pal)
    if args.plug:
        return cmd_plug(args, pal)
    if args.plug_on or args.plug_off or args.plug_toggle:
        return cmd_plug_switch(args, pal)
    if args.plug_reset:
        return cmd_plug_reset(args, pal)
    if args.bindings:
        return cmd_bindings(args, pal)
    if args.reset_data:
        return cmd_reset(args, pal)
    if args.check:
        return cmd_check(args, pal)
    if args.diag:
        return cmd_diag(args, pal)
    if args.aggregate:
        store = Storage()
        n = store.aggregate()
        print('rolled up %d hourly rows' % n)
        return 0

    if mqtt is None:
        sys.stderr.write('ERROR: python3-paho-mqtt is not installed (dnf install -y python3-paho-mqtt)\n')
        return 2

    # The daemon writes the database, its WAL and the token. Started as root
    # over the service's own files it leaves root-owned pieces behind that the
    # service cannot open on its next start.
    if os.geteuid() == 0 and not args.allow_root and str(db_path()).startswith(str(STATE_DIR)):
        try:
            import pwd
            pwd.getpwnam(SERVICE_USER)
            sys.stderr.write('ERROR: do not run the daemon as root over %s.\n'
                             '  installed service:   systemctl status zigmon\n'
                             '  foreground, as the service user:   sudo -u %s %s\n'
                             '  a scratch copy as root:   --config /tmp/test.json with db_file and api_port '
                             'of its own, plus --allow-root\n' % (STATE_DIR, SERVICE_USER, sys.argv[0]))
            return 2
        except KeyError:
            pass                        # no service user on this machine; a test box

    try:
        daemon = Daemon()
    except StorageError as e:
        sys.stderr.write('ERROR: %s\n' % e)
        return 2
    signal.signal(signal.SIGTERM, daemon.stop)
    signal.signal(signal.SIGINT, daemon.stop)
    signal.signal(signal.SIGHUP, daemon.reopen_log)
    return daemon.run()


if __name__ == '__main__':
    sys.exit(main())
