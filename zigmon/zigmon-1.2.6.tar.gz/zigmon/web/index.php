<?php
/**
 * index.php — sensor dashboard.
 *
 * Renders from the daemon's snapshot and refreshes itself over the small JSON
 * endpoints below. It does nothing privileged: no shell, no broker
 * credentials, no direct access to MQTT.
 */
declare(strict_types=1);

require_once __DIR__ . '/zigmon-api.php';

/**
 * PHP falls back to UTC when date.timezone isn't set, which makes every
 * timestamp here disagree with the server's own clock. Follow the system zone.
 */
function use_system_timezone(): void
{
    $set = (string) ini_get('date.timezone');
    if ($set !== '' && strcasecmp($set, 'UTC') !== 0) {
        return;
    }
    $tz = '';
    if (is_readable('/etc/timezone')) {
        $tz = trim((string) @file_get_contents('/etc/timezone'));
    }
    if ($tz === '' && is_link('/etc/localtime')) {
        $target = (string) @readlink('/etc/localtime');
        if (preg_match('#zoneinfo/(.+)$#', $target, $m)) {
            $tz = $m[1];
        }
    }
    if ($tz !== '' && in_array($tz, timezone_identifiers_list(), true)) {
        date_default_timezone_set($tz);
    }
}
use_system_timezone();

// ---- JSON endpoints the page polls ---------------------------------------
if (isset($_GET['api'])) {
    $what = (string) $_GET['api'];

    if ($what === 'status') {
        zigmon_relay('/api/status');
        exit;
    }
    if ($what === 'health') {
        zigmon_relay('/api/health');
        exit;
    }
    if ($what === 'device') {
        $id = (string) ($_GET['id'] ?? '');
        zigmon_relay('/api/device?id=' . rawurlencode($id));
        exit;
    }
    if ($what === 'history') {
        $device = (string) ($_GET['device'] ?? '');
        $range  = preg_replace('/[^0-9smhdwy.]/', '', (string) ($_GET['range'] ?? '24h'));
        $points = max(50, min(3000, (int) ($_GET['points'] ?? 600)));
        $keys   = preg_replace('/[^A-Za-z0-9_.,:-]/', '', (string) ($_GET['keys'] ?? ''));
        zigmon_relay('/api/history?device=' . rawurlencode($device) . '&range=' . rawurlencode($range)
                     . '&points=' . $points . ($keys !== '' ? '&keys=' . rawurlencode($keys) : ''),
                     'GET', null, 30.0);
        exit;
    }
    if ($what === 'events') {
        $limit = max(1, min(1000, (int) ($_GET['limit'] ?? 200)));
        $device = (string) ($_GET['device'] ?? '');
        zigmon_relay('/api/events?limit=' . $limit
                     . ($device !== '' ? '&device=' . rawurlencode($device) : ''));
        exit;
    }
    if ($what === 'plugs') {
        zigmon_relay('/api/plugs');
        exit;
    }
    if ($what === 'plug') {
        $name = (string) ($_GET['name'] ?? '');
        zigmon_relay('/api/plug?name=' . rawurlencode($name) . (!empty($_GET['refresh']) ? '&refresh=1' : ''), 'GET', null, 20.0);
        exit;
    }
    if ($what === 'bindings') {
        zigmon_relay('/api/bindings');
        exit;
    }
    if ($what === 'plug-switch' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['name' => (string) ($in['name'] ?? '')];
        if (!empty($in['toggle'])) {
            $body['toggle'] = true;
        } else {
            $body['on'] = !empty($in['on']);
        }
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        zigmon_relay('/api/plug/switch', 'POST', $body, 30.0);
        exit;
    }
    if ($what === 'plug-reset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['name' => (string) ($in['name'] ?? '')];
        $allowed = ['aenergy', 'ret_aenergy', 'on_time', 'switch_on', 'on_above_thr'];
        $body['types'] = (is_array($in) && isset($in['types']) && is_array($in['types']))
            ? array_values(array_intersect($in['types'], $allowed)) : [];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        zigmon_relay('/api/plug/reset', 'POST', $body, 60.0);
        exit;
    }
    if ($what === 'bindings-save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $clean = [];
        foreach ((is_array($in) && isset($in['bindings']) && is_array($in['bindings'])) ? $in['bindings'] : [] as $b) {
            if (!is_array($b)) {
                continue;
            }
            $clean[] = [
                'device'  => (string) ($b['device'] ?? ''),
                'action'  => (string) ($b['action'] ?? ''),
                'plug'    => (string) ($b['plug'] ?? ''),
                'do'      => (string) ($b['do'] ?? 'toggle'),
                'enabled' => !isset($b['enabled']) || !empty($b['enabled']),
            ];
        }
        $body = ['bindings' => $clean];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        zigmon_relay('/api/bindings', 'POST', $body, 20.0);
        exit;
    }
    if ($what === 'permit-join' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $body = ['enable' => !empty($in['enable']), 'time' => 254];
        if (is_array($in) && isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        zigmon_relay('/api/permit-join', 'POST', $body, 15.0);
        exit;
    }
    if ($what === 'reset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true);
        $scope = (string) ($in['scope'] ?? '');
        if (!in_array($scope, ['all', 'history', 'events', 'device'], true)) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad scope']);
            exit;
        }
        $body = ['scope' => $scope];
        if (isset($in['device'])) {
            $body['device'] = (string) $in['device'];
        }
        if (isset($in['pin'])) {
            $body['pin'] = (string) $in['pin'];
        }
        zigmon_relay('/api/reset', 'POST', $body, 120.0);
        exit;
    }
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'unknown endpoint']);
    exit;
}

// ---- The page ------------------------------------------------------------
$status  = zigmon_get('/api/status', 5.0);
$initial = $status ? json_encode($status, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) : 'null';
$host    = (string) ($_SERVER['HTTP_HOST'] ?? php_uname('n'));

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="dark">
<title>Sensors — <?= h($host) ?></title>
<link rel="icon" href="favicon.svg" type="image/svg+xml" id="favicon">
<meta name="theme-color" content="#161b22">
<style>
  :root{
    --bg:#0d1117; --panel:#161b22; --panel2:#1c222b; --line:#262c37;
    --tx:#e6e9ef; --tx-dim:#8b94a3; --tx-mut:#5b6472;
    --ok:#3fb950; --warn:#d29922; --crit:#f85149; --info:#58a6ff;
    --batt:#a371f7; --load:#f0883e; --sleep:#6e7681;
    --ok-bg:rgba(63,185,80,.12); --warn-bg:rgba(210,153,34,.12);
    --crit-bg:rgba(248,81,73,.13); --info-bg:rgba(88,166,255,.12);
    --r:14px;
  }
  *{box-sizing:border-box}
  html{-webkit-text-size-adjust:100%}
  body{margin:0;background:var(--bg);color:var(--tx);
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    -webkit-font-smoothing:antialiased;
    padding:26px max(16px,env(safe-area-inset-left)) 56px}
  .wrap{max-width:1280px;margin:0 auto}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}

  header{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:16px}
  header h1{font-size:20px;margin:0;font-weight:650;letter-spacing:.2px}
  header .host{color:var(--tx-dim);font-weight:400}
  .spacer{flex:1}
  .updated{color:var(--tx-mut);font-size:13px;text-align:right;line-height:1.35;cursor:pointer;user-select:none}
  .updated b{color:var(--tx-dim);font-weight:600}
  .updated.paused b{color:var(--warn)}

  .tabs{display:flex;gap:4px;margin-bottom:20px;border-bottom:1px solid var(--line);flex-wrap:wrap}
  .tabs button{appearance:none;background:none;border:0;border-bottom:2px solid transparent;
    color:var(--tx-dim);font:inherit;font-weight:600;font-size:14px;padding:9px 15px;
    cursor:pointer;border-radius:8px 8px 0 0;transition:color .15s,border-color .15s}
  .tabs button:hover{color:var(--tx)}
  .tabs button[aria-selected="true"]{color:var(--info);border-bottom-color:var(--info)}
  .panel[hidden]{display:none}

  .pill{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:999px;
        font-weight:600;font-size:14px;border:1px solid transparent}
  .pill .dot{width:9px;height:9px;border-radius:50%;flex:0 0 auto}
  .pill.ok{background:var(--ok-bg);color:var(--ok);border-color:rgba(63,185,80,.3)}
  .pill.warn{background:var(--warn-bg);color:var(--warn);border-color:rgba(210,153,34,.3)}
  .pill.crit{background:var(--crit-bg);color:var(--crit);border-color:rgba(248,81,73,.3)}
  .pill.unknown{background:var(--panel2);color:var(--tx-dim)}
  .pill.ok .dot{background:var(--ok)} .pill.warn .dot{background:var(--warn)}
  .pill.crit .dot{background:var(--crit);animation:pulse 1.4s infinite}
  .pill.unknown .dot{background:var(--tx-mut)}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}

  .grid{display:grid;gap:14px}
  .top{grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}
  .devices{grid-template-columns:repeat(auto-fill,minmax(270px,1fr))}
  .charts{grid-template-columns:repeat(auto-fit,minmax(460px,1fr))}
  .full{grid-column:1/-1}
  @media (max-width:560px){.charts{grid-template-columns:1fr}}

  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:17px 19px}
  .card h2{margin:0 0 13px;font-size:12px;font-weight:700;letter-spacing:.7px;
           text-transform:uppercase;color:var(--tx-mut)}
  .card h2 .right{float:right;font-weight:600;letter-spacing:0;text-transform:none;color:var(--tx-dim)}

  .metric .label{font-size:12px;font-weight:700;letter-spacing:.7px;text-transform:uppercase;
                 color:var(--tx-mut);margin-bottom:9px}
  .metric .value{font-size:30px;font-weight:680;line-height:1.05;letter-spacing:-.5px}
  .metric .value .unit{font-size:16px;font-weight:600;color:var(--tx-dim);margin-left:3px}
  .metric .sub{color:var(--tx-dim);font-size:13px;margin-top:6px}
  .metric.ok .value{color:var(--ok)} .metric.warn .value{color:var(--warn)}
  .metric.crit .value{color:var(--crit)}

  .dev{display:flex;flex-direction:column;gap:10px;cursor:pointer;transition:border-color .15s}
  .dev:hover{border-color:var(--info)}
  .dev.crit{border-color:rgba(248,81,73,.45)} .dev.warn{border-color:rgba(210,153,34,.4)}
  .dev .head{display:flex;align-items:flex-start;gap:10px}
  .dev .name{font-weight:650;font-size:16px;line-height:1.25}
  .dev .model{color:var(--tx-dim);font-size:12.5px}
  .dev .readings{display:flex;flex-wrap:wrap;gap:6px 18px;align-items:baseline}
  .dev .reading .v{font-size:28px;font-weight:680;letter-spacing:-.5px;line-height:1.05}
  .dev .reading .v .unit{font-size:14px;font-weight:600;color:var(--tx-dim);margin-left:2px}
  .dev .reading .l{font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .dev .reading.small .v{font-size:19px}
  .dev .foot{display:flex;flex-wrap:wrap;gap:6px 12px;font-size:12.5px;color:var(--tx-dim);align-items:center}
  .dev .foot .reason{color:var(--warn)}
  .dev.crit .foot .reason{color:var(--crit)}
  .dev.stale .reading .v{color:var(--tx-dim)}

  .bar{height:6px;border-radius:99px;background:var(--panel2);overflow:hidden;flex:1;min-width:60px}
  .bar span{display:block;height:100%;border-radius:99px;transition:width .4s ease}
  .batt{display:flex;align-items:center;gap:8px;min-width:120px}

  .kv{display:flex;justify-content:space-between;align-items:baseline;padding:5px 0;
      font-size:14px;gap:12px;border-bottom:1px solid rgba(38,44,55,.5)}
  .kv:last-child{border-bottom:0}
  .kv .k{color:var(--tx-dim)} .kv .v{font-weight:600;text-align:right}
  .kv .d{display:block;color:var(--tx-mut);font-size:12px;font-weight:400}

  table{width:100%;border-collapse:collapse;font-size:13.5px}
  th{text-align:left;font-size:11px;letter-spacing:.7px;text-transform:uppercase;
     color:var(--tx-mut);font-weight:700;padding:6px 10px 6px 0;border-bottom:1px solid var(--line)}
  td{padding:7px 10px 7px 0;border-bottom:1px solid rgba(38,44,55,.55);vertical-align:top}
  tr:last-child td{border-bottom:0}
  td.num{text-align:right;font-family:ui-monospace,Menlo,Consolas,monospace}
  .scroll{overflow-x:auto}

  .tag{display:inline-block;padding:1px 7px;border-radius:6px;font-size:11px;font-weight:700;
       letter-spacing:.4px;text-transform:uppercase;white-space:nowrap}
  .tag.ok{background:var(--ok-bg);color:var(--ok)}
  .tag.warn{background:var(--warn-bg);color:var(--warn)}
  .tag.crit{background:var(--crit-bg);color:var(--crit)}
  .tag.info{background:var(--info-bg);color:var(--info)}
  .tag.dim{background:var(--panel2);color:var(--tx-dim)}
  .tag.zb{background:rgba(163,113,247,.14);color:var(--batt)}

  .btn{appearance:none;border:1px solid var(--line);background:var(--panel2);color:var(--tx);
       font:inherit;font-weight:600;font-size:13.5px;padding:9px 15px;border-radius:10px;
       cursor:pointer;transition:border-color .15s,background .15s,transform .05s}
  .btn:hover:not(:disabled){border-color:var(--info);color:var(--info)}
  .btn:active:not(:disabled){transform:translateY(1px)}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn.danger:hover:not(:disabled){border-color:var(--crit);color:var(--crit)}
  .btn.primary{background:var(--info-bg);border-color:rgba(88,166,255,.35);color:var(--info)}
  .btn.small{padding:5px 10px;font-size:12.5px;border-radius:8px}
  .btn.on{background:var(--info-bg);border-color:var(--info);color:var(--info)}
  .btn.busy{opacity:.6;cursor:progress}
  .btnrow{display:flex;gap:9px;flex-wrap:wrap}
  .btn.cmd{display:inline-flex;align-items:center;gap:9px;padding:10px 16px}
  .btn.cmd.small{padding:6px 12px;gap:7px}
  .btn.cmd svg{flex:0 0 auto;opacity:.85}
  .btn.cmd:hover:not(:disabled) svg{opacity:1}
  .btnhelp{color:var(--tx-mut);font-size:12.5px;margin:6px 0 16px}
  .hint{position:fixed;z-index:200;max-width:min(340px,88vw);
    background:linear-gradient(160deg,#1b2230 0%,#141922 100%);
    border:1px solid #2b3444;border-radius:12px;padding:11px 14px;
    font-size:12.5px;line-height:1.5;color:var(--tx-dim);
    box-shadow:0 14px 40px rgba(0,0,0,.55);
    opacity:0;transform:translateY(4px);transition:opacity .14s,transform .14s;
    pointer-events:none}
  .hint.show{opacity:1;transform:none}
  .hint b{color:var(--tx);font-weight:600;font-family:ui-monospace,Menlo,Consolas,monospace}
  .hint em{color:var(--crit);font-style:normal}
  .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
  select{appearance:none;background:var(--panel2);color:var(--tx);border:1px solid var(--line);
         font:inherit;font-size:13.5px;font-weight:600;padding:8px 32px 8px 12px;border-radius:10px;
         background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='%238b94a3' d='M4 6l4 4 4-4'/%3E%3C/svg%3E");
         background-repeat:no-repeat;background-position:right 10px center;background-size:14px}

  .chart{position:relative;width:100%;height:240px}
  .chart svg{width:100%;height:100%;display:block}
  .chart .empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
                color:var(--tx-mut);font-size:13.5px}
  .chart .tip{position:absolute;pointer-events:none;background:#0d1117ee;border:1px solid var(--line);
              border-radius:9px;padding:7px 10px;font-size:12.5px;line-height:1.4;white-space:nowrap;
              display:none;z-index:2;box-shadow:0 6px 20px rgba(0,0,0,.35)}
  .chart .tip b{font-weight:650}
  .chart .tip .sw{display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:6px;vertical-align:middle}
  .legend{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12.5px;color:var(--tx-dim);margin-top:6px}
  .legend .sw{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}

  /* the socket panel: state on the left, live figures on the right */
  .sockets{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));margin-bottom:14px}
  @media (max-width:560px){.sockets{grid-template-columns:1fr}}
  .card.socket{display:flex;align-items:center;gap:22px;flex-wrap:wrap;padding:18px 20px}
  .socket-state{display:flex;align-items:center;gap:14px;min-width:200px}
  .socket-toggle{appearance:none;cursor:pointer;width:58px;height:58px;border-radius:50%;display:grid;place-items:center;
    flex:0 0 auto;border:2px solid var(--line);background:var(--panel2);color:var(--tx-mut);
    transition:color .2s,border-color .2s,background .2s,box-shadow .2s}
  .socket-toggle:hover:not(:disabled){border-color:var(--tx-dim)}
  .socket-toggle:disabled{cursor:progress;opacity:.6}
  .card.socket.on .socket-toggle{color:var(--ok);border-color:rgba(63,185,80,.55);background:rgba(63,185,80,.12);box-shadow:0 0 0 6px rgba(63,185,80,.07)}
  .card.socket.off .socket-toggle{color:var(--tx-mut)}
  .card.socket.stale .socket-figures{opacity:.45}
  .card.socket.stale .socket-label{color:var(--warn)}
  .card.socket.stale .socket-toggle{color:var(--warn);border-color:rgba(210,153,34,.45);background:rgba(210,153,34,.10);box-shadow:none}
  .socket-label{font-size:19px;font-weight:680;letter-spacing:-.2px}
  .card.socket.on .socket-label{color:var(--ok)} .card.socket.off .socket-label{color:var(--tx-dim)}
  .socket-sub{font-size:12.5px;margin-top:2px;color:var(--tx-dim)}
  .socket-figures{display:flex;gap:20px;flex-wrap:wrap;flex:1}
  .socket-figures div{min-width:70px}
  .socket-figures .k{font-size:11px;letter-spacing:.7px;text-transform:uppercase;color:var(--tx-mut);font-weight:700}
  .socket-figures .v{font-size:18px;font-weight:650;margin-top:2px}
  .bind-row{display:grid;grid-template-columns:1.4fr 1fr 1.2fr 1fr auto;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(38,44,55,.5)}
  .bind-row input{font:inherit;font-size:13.5px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:8px 12px;width:100%}
  .bind-row input:focus,select:focus{outline:none;border-color:var(--info)}
  .bind-row select{width:100%}
  .bind-head{color:var(--tx-mut);font-size:11px;letter-spacing:.7px;text-transform:uppercase;font-weight:700;border-bottom:1px solid var(--line)}
  @media (max-width:700px){.bind-row{grid-template-columns:1fr 1fr;} .bind-head{display:none}}

  .muted{color:var(--tx-dim)} .small{font-size:13px} .center{text-align:center;color:var(--tx-mut);padding:26px 0}
  .note{color:var(--tx-dim);font-size:13px;margin:0 0 12px}
  code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;background:var(--panel2);
       padding:1px 6px;border-radius:6px}

  .toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(20px);opacity:0;
         background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:11px 18px;
         font-size:14px;font-weight:600;transition:opacity .2s,transform .2s;z-index:10;pointer-events:none;
         box-shadow:0 8px 30px rgba(0,0,0,.4)}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .toast.ok{border-color:rgba(63,185,80,.4);color:var(--ok)} .toast.bad{border-color:rgba(248,81,73,.4);color:var(--crit)}

  /* ---- PIN dialog, as in upsmon ---- */
  .backdrop{position:fixed;inset:0;z-index:100;display:flex;align-items:center;
    justify-content:center;background:rgba(2,5,10,.72);backdrop-filter:blur(3px);
    padding:20px;animation:fade .16s ease}
  .backdrop[hidden]{display:none}
  @keyframes fade{from{opacity:0}to{opacity:1}}
  .pinbox{width:min(380px,94vw);border-radius:20px;padding:28px 26px 22px;text-align:center;
    background:linear-gradient(160deg,#1b2230 0%,#141922 60%,#11151d 100%);
    border:1px solid #2b3444;
    box-shadow:0 24px 70px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.03) inset;
    animation:rise .2s cubic-bezier(.2,.9,.3,1)}
  @keyframes rise{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
  .pinicon{width:52px;height:52px;margin:0 auto 14px;border-radius:50%;
    display:flex;align-items:center;justify-content:center;color:var(--info);
    background:radial-gradient(circle at 50% 35%,rgba(88,166,255,.28),rgba(88,166,255,.07));
    border:1px solid rgba(88,166,255,.34)}
  .pinicon.danger{color:var(--crit);
    background:radial-gradient(circle at 50% 35%,rgba(248,81,73,.26),rgba(248,81,73,.07));
    border-color:rgba(248,81,73,.34)}
  .pinbox h3{margin:0 0 5px;font-size:18px;font-weight:650;letter-spacing:.2px}
  .pinwhat{margin:0 0 20px;color:var(--tx-dim);font-size:13.5px;line-height:1.45;word-break:break-word}
  .pinwhat b{color:var(--tx);font-weight:600}
  .pindigits{display:flex;gap:11px;justify-content:center;margin-bottom:6px}
  .pindigits[hidden]{display:none}
  .pindigits input{width:54px;height:64px;text-align:center;font-size:26px;font-weight:650;
    color:var(--tx);background:#0d1117;border:1.5px solid #2b3444;border-radius:13px;
    caret-color:var(--info);transition:border-color .14s,box-shadow .14s,transform .08s}
  .pindigits.wide input{width:min(260px,80vw);font-size:22px;letter-spacing:6px}
  .pindigits input:focus{outline:none;border-color:var(--info);box-shadow:0 0 0 3.5px rgba(88,166,255,.16)}
  .pindigits input.filled{border-color:#3d4a5f;background:#111823}
  .pindigits.bad input{border-color:var(--crit);box-shadow:0 0 0 3.5px rgba(248,81,73,.13)}
  .pindigits.bad{animation:shake .32s}
  @keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}
    40%{transform:translateX(7px)}60%{transform:translateX(-4px)}80%{transform:translateX(3px)}}
  .pinerr{min-height:19px;margin:8px 0 16px;font-size:13px;color:var(--crit)}
  .pinrow{display:flex;gap:10px;justify-content:center}
  .pinrow .btn{min-width:108px;justify-content:center}
  .btn.primary.danger{background:var(--crit-bg);border-color:rgba(248,81,73,.45);color:var(--crit)}
  .btn.primary.danger:hover:not(:disabled){background:rgba(248,81,73,.2);border-color:var(--crit)}
  .btn.primary:hover:not(:disabled){background:rgba(88,166,255,.2);border-color:var(--info)}
</style>
</head>
<body>
<div class="wrap">

<header>
  <h1>Sensors <span class="host">· <?= h($host) ?></span></h1>
  <span class="pill unknown" id="pill"><span class="dot"></span><span id="pill-text">Connecting…</span></span>
  <span class="spacer"></span>
  <div class="updated" id="updated" title="Click to pause or resume refreshing">
    <b id="updated-label">Loading</b><br><span id="updated-time">—</span>
  </div>
</header>

<div class="tabs" role="tablist">
  <button role="tab" aria-selected="true"  data-tab="overview">Overview</button>
  <button role="tab" aria-selected="false" data-tab="history">History</button>
  <button role="tab" aria-selected="false" data-tab="devices">Devices</button>
  <button role="tab" aria-selected="false" data-tab="events">Events</button>
  <button role="tab" aria-selected="false" data-tab="control">Control</button>
  <button role="tab" aria-selected="false" data-tab="all">All values</button>
</div>

<section class="panel" id="tab-overview">
  <div class="grid top" style="margin-bottom:14px">
    <div class="card metric"><div class="label">Devices</div><div class="value" id="m-devices">–</div><div class="sub" id="m-devices-sub">&nbsp;</div></div>
    <div class="card metric" id="m-online-card"><div class="label">Online</div><div class="value" id="m-online">–</div><div class="sub" id="m-online-sub">&nbsp;</div></div>
    <div class="card metric" id="m-attn-card"><div class="label">Needs attention</div><div class="value" id="m-attn">–</div><div class="sub" id="m-attn-sub">&nbsp;</div></div>
    <div class="card metric" id="m-bridge-card"><div class="label">Zigbee2MQTT</div><div class="value" id="m-bridge">–</div><div class="sub" id="m-bridge-sub">&nbsp;</div></div>
    <div class="card metric" id="m-join-card"><div class="label">Permit join</div><div class="value" id="m-join">–</div><div class="sub" id="m-join-sub">&nbsp;</div></div>
  </div>
  <div class="sockets" id="sockets" hidden></div>
  <div class="grid devices" id="device-cards" style="margin-bottom:14px"></div>
  <div class="grid charts">
    <div class="card">
      <h2>Temperature <span class="right" id="ov-temp-range">24h</span></h2>
      <div class="chart" id="ov-temp"></div><div class="legend" id="ov-temp-legend"></div>
    </div>
    <div class="card">
      <h2>Humidity <span class="right" id="ov-hum-range">24h</span></h2>
      <div class="chart" id="ov-hum"></div><div class="legend" id="ov-hum-legend"></div>
    </div>
  </div>
  <div class="row" style="margin-top:12px" id="ov-ranges"></div>
</section>

<section class="panel" id="tab-history" hidden>
  <div class="row" style="margin-bottom:14px">
    <select id="h-device"></select>
    <span id="h-ranges" class="row"></span>
    <span class="spacer"></span>
    <span class="muted small" id="h-note"></span>
  </div>
  <div class="grid charts" id="h-charts"></div>
</section>

<section class="panel" id="tab-devices" hidden>
  <div class="card scroll"><table id="devices-table"><thead><tr>
    <th>Name</th><th>Model</th><th>Source</th><th>Address</th><th>Status</th><th>Battery</th><th>Signal</th><th>Last report</th><th>First seen</th>
  </tr></thead><tbody></tbody></table></div>
</section>

<section class="panel" id="tab-events" hidden>
  <div class="card scroll">
    <h2>Last 200 events</h2>
    <table id="events-table"><thead><tr><th>When</th><th></th><th>Kind</th><th>Device</th><th>Detail</th></tr></thead><tbody></tbody></table>
    <div class="center" id="events-empty" hidden>Nothing recorded yet</div>
  </div>
</section>

<section class="panel" id="tab-control" hidden>
  <div class="grid charts">
    <div class="card">
      <h2>Pairing</h2>
      <p class="note">Opening the network lets new Zigbee devices join for four minutes. On a Shelly BLU device press the button five times quickly; on most other devices hold the button until the LED blinks.</p>
      <div class="btnrow">
        <button class="btn cmd primary" id="join-open">Open network (254 s)</button>
        <button class="btn cmd" id="join-close">Close network</button>
        <span class="muted small" id="join-state" style="align-self:center"></span>
      </div>
    </div>
    <div class="card">
      <h2>Recorded data</h2>
      <p class="note">Erasing cannot be undone. Devices stay known to Zigbee2MQTT; only what this dashboard recorded is removed.</p>
      <div class="btnrow">
        <button class="btn cmd danger" data-reset="history">Erase history</button>
        <button class="btn cmd danger" data-reset="events">Erase events</button>
        <button class="btn cmd danger" data-reset="all">Erase everything</button>
      </div>
      <div class="btnrow" style="margin-top:10px">
        <select id="reset-device"></select>
        <button class="btn cmd danger" id="reset-device-btn">Forget this device</button>
      </div>
    </div>
    <div class="card full" id="plug-control" hidden>
      <h2>Smart plugs</h2>
      <p class="note">Switching a socket cuts power to whatever is plugged into it. The counters are the plug's own running totals; resetting one starts it from zero, the history recorded here is untouched.</p>
      <div id="plug-control-list"></div>
    </div>
    <div class="card full" id="bindings-card" hidden>
      <h2>Button bindings</h2>
      <p class="note">When a Zigbee button reports an action, the daemon switches the plug. <code>*</code> matches any action. Saved behind the PIN; takes effect immediately.</p>
      <div id="bindings-list"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="binding-add">Add binding</button>
        <button class="btn cmd primary" id="binding-save">Save bindings</button>
        <span class="muted small" id="binding-note" style="align-self:center"></span>
      </div>
    </div>
    <div class="card full">
      <h2>Daemon</h2>
      <div id="health-kv"></div>
    </div>
  </div>
</section>

<section class="panel" id="tab-all" hidden>
  <div class="grid charts" id="all-values"></div>
</section>

</div>

<div class="toast" id="toast"></div>

<!-- PIN dialog -->
<div class="backdrop" id="pinback" hidden>
  <div class="pinbox" role="dialog" aria-modal="true" aria-labelledby="pintitle">
    <div class="pinicon" id="pinicon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor"
           stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="10.5" width="16" height="10" rx="2.5"/>
        <path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>
      </svg>
    </div>
    <h3 id="pintitle">Enter PIN</h3>
    <p class="pinwhat" id="pinwhat"></p>
    <div class="pindigits" id="pindigits"></div>
    <p class="pinerr" id="pinerr"></p>
    <div class="pinrow">
      <button class="btn" id="pincancel">Cancel</button>
      <button class="btn primary" id="pinok" disabled>Confirm</button>
    </div>
  </div>
</div>

<script>
'use strict';
var INITIAL = <?= $initial ?>;
var REFRESH_MS = 5000;
var COLORS = ['#58a6ff','#3fb950','#f0883e','#a371f7','#d29922','#f85149','#39d2c0','#e2a9f5','#79c0ff','#ffa657'];
var STATE = { status: null, paused: false, tab: 'overview', ovRange: '24h', hRange: '24h',
              hDevice: null, timer: null, busy: false, charts: {} };

// ---- small helpers --------------------------------------------------------
function $(id) { return document.getElementById(id); }
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) {
  return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function isNum(v) { return typeof v === 'number' && isFinite(v); }
function fmt(v, digits) {
  if (v === null || v === undefined) return '–';
  if (typeof v === 'boolean') return v ? 'yes' : 'no';
  if (!isNum(v)) return String(v);
  if (digits === undefined) digits = Math.abs(v) >= 100 ? 0 : (Math.abs(v) >= 10 ? 1 : 2);
  var s = v.toFixed(digits);
  return s.indexOf('.') >= 0 ? s.replace(/\.?0+$/, '') : s;
}
function ago(ts) {
  if (!ts) return 'never';
  var s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (s < 60) return s + ' s ago';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ' + Math.floor((s % 3600) / 60) + ' min ago';
  return Math.floor(s / 86400) + ' d ' + Math.floor((s % 86400) / 3600) + ' h ago';
}
function pad(n) { return (n < 10 ? '0' : '') + n; }
function stamp(ts) {
  if (!ts) return '–';
  var d = new Date(ts * 1000);
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}
function shortStamp(ts, spanS) {
  var d = new Date(ts * 1000);
  if (spanS > 3 * 86400) return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.';
  if (spanS > 36 * 3600) return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':00';
  return pad(d.getHours()) + ':' + pad(d.getMinutes());
}
function toast(message, ok) {
  var t = $('toast');
  t.textContent = message;
  t.className = 'toast show ' + (ok ? 'ok' : 'bad');
  clearTimeout(t._h);
  t._h = setTimeout(function () { t.className = 'toast'; }, 3200);
}
function api(what, options) {
  return fetch('?api=' + what, options).then(function (r) {
    return r.json().then(function (data) {
      if (!r.ok && data && data.error) throw new Error(data.error);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return data;
    });
  });
}
function post(what, body) {
  return api(what, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {}) });
}
function levelWord(level) {
  return {ok: 'All good', warn: 'Needs attention', crit: 'Problem', unknown: 'No data'}[level] || level;
}
function deviceById(id) {
  var devs = (STATE.status && STATE.status.devices) || [];
  for (var i = 0; i < devs.length; i++) if (devs[i].id === id) return devs[i];
  return null;
}
function tempKey(d) { return d.values.temperature ? 'temperature' : (d.values.tC ? 'tC' : null); }
function humKey(d)  { return d.values.humidity ? 'humidity' : (d.values.rh ? 'rh' : null); }

// ---- favicon ---------------------------------------------------------------
function setFavicon(level) {
  var color = {ok: '#3fb950', warn: '#d29922', crit: '#f85149'}[level] || '#6e7681';
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    + '<rect x="18" y="4" width="28" height="44" rx="14" fill="none" stroke="' + color + '" stroke-width="6"/>'
    + '<circle cx="32" cy="46" r="10" fill="' + color + '"/><rect x="29" y="18" width="6" height="26" fill="' + color + '"/></svg>';
  $('favicon').href = 'data:image/svg+xml,' + encodeURIComponent(svg);
}

// ---- charts ----------------------------------------------------------------
// series: [{name, color, unit, points: [[ts, value], ...]}]
function drawChart(container, series, opts) {
  opts = opts || {};
  container.innerHTML = '';
  STATE.charts[container.id] = {series: series, opts: opts};
  var W = Math.max(280, container.clientWidth || 600), H = container.clientHeight || 240;
  var padL = 46, padR = 12, padT = 12, padB = 26;
  var plotW = W - padL - padR, plotH = H - padT - padB;
  var all = [], t0 = Infinity, t1 = -Infinity;
  series.forEach(function (s) { s.points.forEach(function (p) {
    if (!isNum(p[1])) return;
    all.push(p[1]); if (p[0] < t0) t0 = p[0]; if (p[0] > t1) t1 = p[0]; }); });
  if (!all.length) {
    container.appendChild(el('div', 'empty', opts.empty || 'No data for this range yet'));
    return;
  }
  var now = Math.floor(Date.now() / 1000);
  if (opts.spanS) { t1 = Math.max(t1, now); t0 = Math.min(t0, now - opts.spanS); }
  if (t1 - t0 < 60) { t0 -= 30; t1 += 30; }
  var lo = Math.min.apply(null, all), hi = Math.max.apply(null, all);
  if (opts.min !== undefined && opts.min < lo) lo = opts.min;
  if (opts.max !== undefined && opts.max > hi) hi = opts.max;
  if (hi - lo < 1e-9) { lo -= 1; hi += 1; }
  var padY = (hi - lo) * 0.08; lo -= padY; hi += padY;
  function px(ts) { return padL + (ts - t0) / (t1 - t0) * plotW; }
  function py(v) { return padT + plotH - (v - lo) / (hi - lo) * plotH; }

  var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none">';
  // y grid
  var yTicks = 4;
  for (var i = 0; i <= yTicks; i++) {
    var v = lo + (hi - lo) * i / yTicks, y = py(v);
    svg += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y + '" y2="' + y + '" stroke="#262c37" stroke-width="1"/>';
    svg += '<text x="' + (padL - 6) + '" y="' + (y + 4) + '" text-anchor="end" font-size="11" fill="#5b6472">' + fmt(v, Math.abs(hi - lo) < 5 ? 1 : 0) + '</text>';
  }
  // x labels
  var span = t1 - t0, xTicks = Math.max(2, Math.min(8, Math.floor(plotW / 90)));
  for (var j = 0; j <= xTicks; j++) {
    var ts = t0 + span * j / xTicks, x = px(ts);
    svg += '<text x="' + x + '" y="' + (H - 8) + '" text-anchor="' + (j === 0 ? 'start' : (j === xTicks ? 'end' : 'middle')) + '" font-size="11" fill="#5b6472">' + shortStamp(ts, span) + '</text>';
  }
  series.forEach(function (s) {
    var d = '', prev = null;
    s.points.forEach(function (p) {
      if (!isNum(p[1])) { prev = null; return; }
      var x = px(p[0]), y = py(p[1]);
      // a gap longer than a tenth of the range breaks the line
      d += (prev === null || p[0] - prev > Math.max(span / 10, 7200) ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1) + ' ';
      prev = p[0];
    });
    svg += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>';
    if (s.points.length < 60) {
      s.points.forEach(function (p) {
        if (isNum(p[1])) svg += '<circle cx="' + px(p[0]).toFixed(1) + '" cy="' + py(p[1]).toFixed(1) + '" r="2.2" fill="' + s.color + '"/>';
      });
    }
  });
  svg += '<line id="' + container.id + '-cursor" x1="0" x2="0" y1="' + padT + '" y2="' + (padT + plotH) + '" stroke="#8b94a3" stroke-width="1" stroke-dasharray="3 3" style="display:none"/>';
  svg += '</svg>';
  container.innerHTML = svg;
  var tip = el('div', 'tip');
  container.appendChild(tip);

  var cursor = container.querySelector('#' + container.id + '-cursor');
  function move(clientX, clientY) {
    var rect = container.getBoundingClientRect();
    var ts = t0 + ((clientX - rect.left) / rect.width * W - padL) / plotW * (t1 - t0);
    if (ts < t0 || ts > t1) { hide(); return; }
    var html = '<b>' + stamp(Math.round(ts)) + '</b>', any = false;
    series.forEach(function (s) {
      var best = null, bd = Infinity;
      s.points.forEach(function (p) { var dd = Math.abs(p[0] - ts); if (dd < bd && isNum(p[1])) { bd = dd; best = p; } });
      if (best && bd < Math.max(span / 40, 900)) {
        any = true;
        html += '<br><span class="sw" style="background:' + s.color + '"></span>' + esc(s.name) + ': <b>' + fmt(best[1]) + (s.unit ? ' ' + s.unit : '') + '</b>';
      }
    });
    if (!any) { hide(); return; }
    tip.innerHTML = html;
    tip.style.display = 'block';
    var x = clientX - rect.left, y = clientY - rect.top;
    var tw = tip.offsetWidth, th = tip.offsetHeight;
    tip.style.left = Math.min(rect.width - tw - 4, Math.max(0, x + 14)) + 'px';
    tip.style.top = Math.max(0, Math.min(rect.height - th, y - th - 10)) + 'px';
    var cx = px(ts);
    cursor.setAttribute('x1', cx); cursor.setAttribute('x2', cx); cursor.style.display = '';
  }
  function hide() { tip.style.display = 'none'; cursor.style.display = 'none'; }
  container.onmousemove = function (e) { move(e.clientX, e.clientY); };
  container.onmouseleave = hide;
  container.ontouchstart = container.ontouchmove = function (e) {
    if (e.touches.length === 1) { move(e.touches[0].clientX, e.touches[0].clientY); e.preventDefault(); }
  };
  container.ontouchend = hide;
}
function redrawCharts() {
  Object.keys(STATE.charts).forEach(function (id) {
    var c = $(id), spec = STATE.charts[id];
    if (c && spec && c.offsetParent !== null) drawChart(c, spec.series, spec.opts);
  });
}
function legend(host, series) {
  host.innerHTML = '';
  series.forEach(function (s) {
    var item = el('span');
    item.innerHTML = '<span class="sw" style="background:' + s.color + '"></span>' + esc(s.name);
    host.appendChild(item);
  });
}
window.addEventListener('resize', function () { clearTimeout(window._rt); window._rt = setTimeout(redrawCharts, 150); });

// ---- overview ----------------------------------------------------------------
function renderOverview(st) {
  var c = st.counts || {devices: 0, online: 0, ok: 0, warn: 0, crit: 0};
  $('m-devices').textContent = c.devices;
  $('m-devices-sub').textContent = c.devices ? (c.ok + ' ok · ' + c.warn + ' warn · ' + c.crit + ' crit') : 'none paired yet';
  $('m-online').textContent = c.online;
  $('m-online-sub').textContent = c.devices ? 'of ' + c.devices : '';
  $('m-online-card').className = 'card metric ' + (c.devices && c.online < c.devices ? 'warn' : '');
  var attn = c.warn + c.crit;
  $('m-attn').textContent = attn;
  $('m-attn-card').className = 'card metric ' + (c.crit ? 'crit' : (c.warn ? 'warn' : 'ok'));
  $('m-attn-sub').textContent = attn ? 'see the cards below' : 'everything reporting';
  var b = st.bridge || {};
  var bstate = st.connected ? (b.state || 'unknown') : 'broker down';
  $('m-bridge').textContent = bstate;
  $('m-bridge-card').className = 'card metric ' + (st.connected && b.state === 'online' ? 'ok' : 'crit');
  $('m-bridge-sub').textContent = (b.version ? 'v' + b.version : '') + (b.channel ? ' · channel ' + b.channel : '') + (b.coordinator ? ' · ' + b.coordinator : '');
  $('m-join').textContent = b.permit_join ? 'OPEN' : 'closed';
  $('m-join-card').className = 'card metric ' + (b.permit_join ? 'warn' : '');
  $('m-join-sub').textContent = b.permit_join ? 'new devices may join' : 'network locked';
  $('join-state').textContent = b.permit_join ? 'The network is open for joining.' : 'The network is closed.';

  renderSockets(st);
  var host = $('device-cards');
  host.innerHTML = '';
  if (!st.devices.length) {
    var empty = el('div', 'card center', 'No devices yet. Open the network under Control and pair a sensor.');
    empty.style.gridColumn = '1/-1';
    host.appendChild(empty);
  }
  st.devices.forEach(function (d) {
    if (d.source === 'plug') return;      // shown as a socket above
    var stale = !d.online;
    var card = el('div', 'card dev ' + d.level + (stale ? ' stale' : ''));
    card.onclick = function () { STATE.hDevice = d.id; showTab('history'); };
    var head = el('div', 'head');
    var nm = el('div');
    nm.appendChild(el('div', 'name', d.name));
    nm.appendChild(el('div', 'model', [d.vendor, d.model].filter(Boolean).join(' ') + (d.description ? ' · ' + d.description : '')));
    head.appendChild(nm);
    head.appendChild(el('span', 'spacer'));
    head.appendChild(el('span', 'tag ' + (d.availability === 'offline' ? 'crit' : (stale ? 'warn' : (d.level === 'ok' ? 'ok' : d.level))),
                        d.availability === 'offline' ? 'offline' : (stale ? 'silent' : (d.level === 'ok' ? 'online' : d.level))));
    card.appendChild(head);
    var readings = el('div', 'readings');
    if (!d.headline.length) {
      readings.appendChild(el('span', 'muted small', d.age_s === null ? 'Waiting for the first report'
        : (d.actions && d.actions.length ? 'Actions: ' + d.actions.join(', ') : 'No measurements — see All values')));
    }
    d.headline.forEach(function (hd, i) {
      var r = el('div', 'reading' + (i > 1 ? ' small' : ''));
      var v = el('div', 'v');
      v.innerHTML = esc(fmt(hd.value)) + (hd.unit ? '<span class="unit">' + esc(hd.unit) + '</span>' : '');
      r.appendChild(v);
      r.appendChild(el('div', 'l', hd.label));
      readings.appendChild(r);
    });
    card.appendChild(readings);
    var foot = el('div', 'foot');
    if (isNum(d.battery)) {
      var bw = el('span', 'batt');
      var bar = el('span', 'bar'); var fill = el('span');
      var bl = d.battery <= st.thresholds.battery_crit ? 'var(--crit)' : (d.battery <= st.thresholds.battery_warn ? 'var(--warn)' : 'var(--ok)');
      fill.style.width = Math.max(0, Math.min(100, d.battery)) + '%'; fill.style.background = bl;
      bar.appendChild(fill);
      bw.appendChild(el('span', '', 'Battery ' + fmt(d.battery, 0) + '%'));
      bw.appendChild(bar);
      foot.appendChild(bw);
    }
    if (isNum(d.linkquality)) foot.appendChild(el('span', '', 'LQI ' + fmt(d.linkquality, 0)));
    foot.appendChild(el('span', '', ago(d.last_seen)));
    if (d.reasons.length) foot.appendChild(el('span', 'reason', d.reasons.join('; ')));
    card.appendChild(foot);
    host.appendChild(card);
  });
}

function loadOverviewCharts() {
  var st = STATE.status;
  if (!st) return;
  var spanS = spanSeconds(STATE.ovRange);
  var jobs = [];
  st.devices.forEach(function (d) {
    var tk = tempKey(d), hk = humKey(d);
    if (!tk && !hk) return;
    var keys = [tk, hk].filter(Boolean).join(',');
    jobs.push(api('history&device=' + encodeURIComponent(d.id) + '&keys=' + keys + '&range=' + STATE.ovRange + '&points=400')
      .then(function (r) { return {dev: d, tk: tk, hk: hk, rows: r.rows}; }, function () { return null; }));
  });
  $('ov-temp-range').textContent = STATE.ovRange; $('ov-hum-range').textContent = STATE.ovRange;
  Promise.all(jobs).then(function (results) {
    var temps = [], hums = [];
    results.forEach(function (r, i) {
      if (!r) return;
      var color = COLORS[i % COLORS.length];
      if (r.tk) temps.push({name: r.dev.name, color: color, unit: '°C', points: r.rows.map(function (x) { return [x.ts, x[r.tk]]; })});
      if (r.hk) hums.push({name: r.dev.name, color: color, unit: '%', points: r.rows.map(function (x) { return [x.ts, x[r.hk]]; })});
    });
    drawChart($('ov-temp'), temps, {spanS: spanS}); legend($('ov-temp-legend'), temps);
    drawChart($('ov-hum'), hums, {spanS: spanS}); legend($('ov-hum-legend'), hums);
  });
}
function spanSeconds(range) {
  var m = /^(\d+)([smhdwy])$/.exec(range); if (!m) return 86400;
  return parseInt(m[1], 10) * {s: 1, m: 60, h: 3600, d: 86400, w: 604800, y: 31557600}[m[2]];
}
function rangeButtons(host, ranges, current, onpick) {
  host.innerHTML = '';
  ranges.forEach(function (r) {
    var b = el('button', 'btn small' + (r === current ? ' on' : ''), r);
    b.onclick = function () { onpick(r); };
    host.appendChild(b);
  });
}

// ---- history ------------------------------------------------------------------
function renderHistoryControls() {
  var st = STATE.status; if (!st) return;
  var sel = $('h-device');
  var current = STATE.hDevice || (sel.value || (st.devices[0] && st.devices[0].id));
  sel.innerHTML = '';
  st.devices.forEach(function (d) {
    var o = el('option', '', d.name + ' — ' + [d.vendor, d.model].filter(Boolean).join(' '));
    o.value = d.id; sel.appendChild(o);
  });
  if (current && deviceById(current)) sel.value = current;
  STATE.hDevice = sel.value || null;
  sel.onchange = function () { STATE.hDevice = sel.value; loadHistory(); };
  rangeButtons($('h-ranges'), ['6h', '24h', '7d', '30d', '1y'], STATE.hRange, function (r) { STATE.hRange = r; renderHistoryControls(); loadHistory(); });
}
function loadHistory() {
  var id = STATE.hDevice, host = $('h-charts');
  if (!id) { host.innerHTML = '<div class="card center full">No device selected</div>'; return; }
  var d = deviceById(id);
  $('h-note').textContent = 'Loading…';
  api('device&id=' + encodeURIComponent(id)).then(function (info) {
    var keys = (info.keys || []).filter(function (k) { return k !== 'linkquality'; });
    if (info.keys && info.keys.indexOf('linkquality') >= 0) keys.push('linkquality');
    if (!keys.length) { host.innerHTML = '<div class="card center full">Nothing numeric recorded for this device yet</div>'; $('h-note').textContent = ''; return; }
    return api('history&device=' + encodeURIComponent(id) + '&keys=' + keys.join(',') + '&range=' + STATE.hRange + '&points=700').then(function (r) {
      host.innerHTML = '';
      var spanS = spanSeconds(STATE.hRange);
      keys.forEach(function (k, i) {
        var meta = (info.values && info.values[k]) || {};
        var card = el('div', 'card');
        var h2 = el('h2'); h2.innerHTML = esc(meta.label || k) + (meta.unit ? ' <span class="right">' + esc(meta.unit) + '</span>' : '');
        card.appendChild(h2);
        var box = el('div', 'chart'); box.id = 'h-chart-' + i;
        card.appendChild(box);
        host.appendChild(card);
        var pts = r.rows.map(function (x) { return [x.ts, x[k]]; }).filter(function (p) { return p[1] !== undefined; });
        var opts = {spanS: spanS};
        if (k === 'battery' || k === 'humidity' || k === 'rh') { opts.min = 0; opts.max = 100; }
        drawChart(box, [{name: (d ? d.name : id), color: COLORS[i % COLORS.length], unit: meta.unit || '', points: pts}], opts);
      });
      $('h-note').textContent = r.rows.length + ' points' + (spanS > 14 * 86400 ? ' · older than two weeks is hourly average' : '');
    });
  }).catch(function (e) { $('h-note').textContent = 'Error: ' + e.message; });
}

// ---- devices table --------------------------------------------------------------
function renderDevices(st) {
  var tb = $('devices-table').querySelector('tbody');
  tb.innerHTML = '';
  st.devices.forEach(function (d) {
    var tr = el('tr');
    tr.innerHTML = '<td><b>' + esc(d.name) + '</b>' + (d.description ? '<br><span class="muted small">' + esc(d.description) + '</span>' : '') + '</td>'
      + '<td>' + esc([d.vendor, d.model].filter(Boolean).join(' ') || '–') + '</td>'
      + '<td><span class="tag ' + (d.source === 'zigbee' ? 'zb' : 'info') + '">' + esc(d.source) + '</span> <span class="muted small">' + esc(d.kind || '') + '</span></td>'
      + '<td class="mono small">' + esc(d.id) + '</td>'
      + '<td><span class="tag ' + d.level + '">' + esc(d.level) + '</span>' + (d.reasons.length ? '<br><span class="muted small">' + esc(d.reasons.join('; ')) + '</span>' : '') + '</td>'
      + '<td class="num">' + (isNum(d.battery) ? fmt(d.battery, 0) + ' %' : '–') + '</td>'
      + '<td class="num">' + (isNum(d.linkquality) ? fmt(d.linkquality, 0) : '–') + '</td>'
      + '<td>' + esc(ago(d.last_seen)) + '<br><span class="muted small">' + esc(stamp(d.last_seen)) + '</span></td>'
      + '<td class="small">' + esc(stamp(d.first_seen)) + '</td>';
    tb.appendChild(tr);
  });
  var sel = $('reset-device'), cur = sel.value;
  sel.innerHTML = '';
  st.devices.forEach(function (d) { var o = el('option', '', d.name); o.value = d.id; sel.appendChild(o); });
  if (cur) sel.value = cur;
}

// ---- events ----------------------------------------------------------------------
function loadEvents() {
  api('events&limit=200').then(function (r) {
    var tb = $('events-table').querySelector('tbody');
    tb.innerHTML = '';
    $('events-empty').hidden = r.events.length > 0;
    r.events.forEach(function (e) {
      var tr = el('tr');
      tr.innerHTML = '<td class="small" style="white-space:nowrap">' + esc(stamp(e.ts)) + '</td>'
        + '<td><span class="tag ' + esc(e.level || 'info') + '">' + esc(e.level || 'info') + '</span></td>'
        + '<td>' + esc(e.kind) + '</td>'
        + '<td>' + esc(e.device_name || e.device || '') + '</td>'
        + '<td>' + esc(e.detail || '') + '</td>';
      tb.appendChild(tr);
    });
  }).catch(function (e) { toast('Events: ' + e.message, false); });
}

// ---- all values ------------------------------------------------------------------
function renderAll(st) {
  var host = $('all-values');
  host.innerHTML = '';
  st.devices.forEach(function (d) {
    var card = el('div', 'card');
    var h2 = el('h2'); h2.innerHTML = esc(d.name) + ' <span class="right">' + esc([d.vendor, d.model].filter(Boolean).join(' ')) + '</span>';
    card.appendChild(h2);
    var keys = Object.keys(d.values).sort();
    if (!keys.length) card.appendChild(el('div', 'muted small', 'Nothing reported yet'));
    keys.forEach(function (k) {
      var v = d.values[k];
      var row = el('div', 'kv');
      var kk = el('span', 'k'); kk.innerHTML = esc(v.label || k) + '<span class="d">' + esc(k) + (v.description ? ' — ' + esc(v.description) : '') + '</span>';
      var vv = el('span', 'v', fmt(v.value) + (v.unit ? ' ' + v.unit : ''));
      if (v.options && v.options.length) { var o = el('span', 'd', 'one of: ' + v.options.join(', ')); o.style.display = 'block'; o.style.color = 'var(--tx-mut)'; o.style.fontSize = '12px'; o.style.fontWeight = '400'; vv.appendChild(o); }
      row.appendChild(kk); row.appendChild(vv);
      card.appendChild(row);
    });
    var meta = el('div', 'kv');
    meta.innerHTML = '<span class="k">Last report</span><span class="v">' + esc(stamp(d.last_seen)) + '</span>';
    card.appendChild(meta);
    host.appendChild(card);
  });
}

// ---- control --------------------------------------------------------------------
function loadHealth() {
  api('health').then(function (h) {
    var pairs = [
      ['Version', h.version], ['Uptime', ago(Math.floor(Date.now() / 1000) - h.uptime_s).replace(' ago', '')],
      ['Broker', h.connected ? 'connected' : 'disconnected' + (h.last_error ? ' — ' + h.last_error : '')],
      ['Bridge', h.bridge_state || 'unknown'], ['Messages received', h.messages],
      ['Last message', h.last_message ? ago(h.last_message) : 'none'],
      ['Subscriptions', (h.subscriptions || []).join(', ')],
      ['Database', h.db.path + ' — ' + (h.db.bytes ? (h.db.bytes / 1048576).toFixed(1) + ' MB' : '?') + ', ' + h.db.samples + ' samples, ' + h.db.samples_hourly + ' hourly, ' + h.db.events + ' events'],
      ['Oldest data', h.db.oldest ? stamp(h.db.oldest) : '–'],
    ];
    if (h.pushes && h.pushes.listening) {
      pairs.push(['Webhook listener', h.pushes.endpoint + ' — ' + h.pushes.received + ' received, ' + h.pushes.rejected + ' rejected' + (h.pushes.last ? ', last ' + ago(h.pushes.last) : '')]);
    }
    var host = $('health-kv'); host.innerHTML = '';
    pairs.forEach(function (p) {
      var row = el('div', 'kv'); row.appendChild(el('span', 'k', p[0])); row.appendChild(el('span', 'v', String(p[1])));
      host.appendChild(row);
    });
  }).catch(function (e) { $('health-kv').textContent = 'Daemon not reachable: ' + e.message; });
}

var PIN = { resolve: null, length: 4 };
function pinInputs() { return Array.prototype.slice.call($('pindigits').querySelectorAll('input')); }
function pinNeeded() { return !!(STATE.status && STATE.status.pin_required); }

// One box per digit for a numeric PIN of 4–8, a single field for anything else.
function buildPinBoxes() {
  var st = STATE.status || {};
  var host = $('pindigits');
  var length = st.pin_length || 4, boxes = st.pin_numeric !== false && length >= 4 && length <= 8;
  var want = boxes ? 'boxes' + length : 'wide';
  if (host.getAttribute('data-kind') === want) return;
  host.setAttribute('data-kind', want);
  host.innerHTML = '';
  host.classList.toggle('wide', !boxes);
  PIN.length = boxes ? length : 0;
  var n = boxes ? length : 1;
  for (var i = 0; i < n; i++) {
    var input = el('input');
    input.type = 'password'; input.autocomplete = 'off';
    input.setAttribute('inputmode', boxes ? 'numeric' : 'text');
    if (boxes) input.maxLength = 1;
    input.setAttribute('aria-label', boxes ? 'digit ' + (i + 1) : 'PIN');
    host.appendChild(input);
  }
  wirePinInputs();
}
function pinValue() { return pinInputs().map(function (i) { return i.value; }).join(''); }
function pinComplete() { return PIN.length ? pinValue().length === PIN.length : pinValue().length > 0; }

function askPin(title, text, danger) {
  // Resolves with the PIN, '' when none is configured, or null if the person backed out.
  return new Promise(function (resolve) {
    PIN.resolve = resolve;
    var needed = pinNeeded();
    buildPinBoxes();
    $('pintitle').textContent = title;
    $('pinwhat').innerHTML = text;
    $('pinerr').textContent = '';
    $('pindigits').classList.remove('bad');
    $('pindigits').hidden = !needed;
    $('pinicon').className = 'pinicon' + (danger ? ' danger' : '');
    $('pinok').className = 'btn primary' + (danger ? ' danger' : '');
    pinInputs().forEach(function (input) { input.value = ''; input.classList.remove('filled'); });
    $('pinok').disabled = needed;
    $('pinback').hidden = false;
    setTimeout(function () { (needed ? pinInputs()[0] : $('pinok')).focus(); }, 40);
  });
}
function closePin(value) {
  $('pinback').hidden = true;
  var resolve = PIN.resolve;
  PIN.resolve = null;
  if (resolve) resolve(value);
}
function pinShake(message) {
  $('pinerr').textContent = message;
  var box = $('pindigits');
  box.classList.add('bad');
  setTimeout(function () { box.classList.remove('bad'); }, 400);
  pinInputs().forEach(function (input) { input.value = ''; input.classList.remove('filled'); });
  $('pinok').disabled = true;
  pinInputs()[0].focus();
}
function wirePinInputs() {
  var inputs = pinInputs();
  inputs.forEach(function (input, index) {
    input.addEventListener('input', function () {
      if (PIN.length) {
        input.value = input.value.replace(/\D/g, '').slice(-1);
        input.classList.toggle('filled', input.value !== '');
        if (input.value && index < inputs.length - 1) inputs[index + 1].focus();
      }
      $('pinok').disabled = !pinComplete();
      if (PIN.length && pinComplete()) $('pinok').focus();
    });
    input.addEventListener('keydown', function (e) {
      if (PIN.length && e.key === 'Backspace' && !input.value && index > 0) {
        inputs[index - 1].focus(); inputs[index - 1].value = ''; inputs[index - 1].classList.remove('filled');
        e.preventDefault();
      } else if (PIN.length && e.key === 'ArrowLeft' && index > 0) {
        inputs[index - 1].focus();
      } else if (PIN.length && e.key === 'ArrowRight' && index < inputs.length - 1) {
        inputs[index + 1].focus();
      } else if (e.key === 'Enter' && pinComplete()) {
        closePin(pinValue());
      } else if (e.key === 'Escape') {
        closePin(null);
      }
    });
    input.addEventListener('paste', function (e) {
      if (!PIN.length) return;
      var text = (e.clipboardData || window.clipboardData).getData('text') || '';
      var digits = text.replace(/\D/g, '').slice(0, PIN.length);
      if (!digits) return;
      e.preventDefault();
      inputs.forEach(function (box, n) { box.value = digits[n] || ''; box.classList.toggle('filled', !!digits[n]); });
      $('pinok').disabled = digits.length !== PIN.length;
      inputs[Math.min(digits.length, PIN.length - 1)].focus();
    });
  });
}
$('pinok').onclick = function () { if (!pinNeeded() || pinComplete()) closePin(pinNeeded() ? pinValue() : ''); };
$('pincancel').onclick = function () { closePin(null); };
$('pinback').addEventListener('mousedown', function (e) { if (e.target === $('pinback')) closePin(null); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('pinback').hidden) closePin(null); });

// Run something that needs the PIN, re-asking in the same dialog while the
// daemon says it was wrong; a lockout closes it with a toast.
function withPin(title, text, action, danger) {
  askPin(title, text, danger).then(function run(pin) {
    if (pin === null) return;
    action(pin).then(function (msg) { toast(msg, true); tick(true); }, function (e) {
      var message = e.message || String(e);
      if (/PIN/i.test(message) && !/locked|too many/i.test(message) && pinNeeded()) {
        $('pinback').hidden = false;
        pinShake(message);
        PIN.resolve = run;
        return;
      }
      toast(message, false);
    });
  });
}
$('join-open').onclick = function () {
  withPin('Open the Zigbee network', 'New devices will be able to join for 254 seconds.', function (pin) {
    return post('permit-join', {enable: true, pin: pin}).then(function () { return 'Network open — pair your device now'; });
  });
};
$('join-close').onclick = function () {
  withPin('Close the Zigbee network', 'Joining will be disabled.', function (pin) {
    return post('permit-join', {enable: false, pin: pin}).then(function () { return 'Network closed'; });
  });
};
Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) {
  b.onclick = function () {
    var scope = b.getAttribute('data-reset');
    var what = {history: 'all recorded samples', events: 'the event log', all: 'everything this dashboard has recorded'}[scope];
    withPin('Erase ' + what, '<b>This cannot be undone.</b>', function (pin) {
      return post('reset', {scope: scope, pin: pin}).then(function () { return 'Erased ' + what; });
    }, true);
  };
});
$('reset-device-btn').onclick = function () {
  var id = $('reset-device').value, d = deviceById(id);
  if (!d) return;
  withPin('Forget ' + d.name, 'Its history is erased. It reappears when it next reports.', function (pin) {
    return post('reset', {scope: 'device', device: id, pin: pin}).then(function () { return 'Forgot ' + d.name; });
  }, true);
};


// ---- icons and hints, as in upsmon -------------------------------------------------
var ICONS = {
  power: '<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  reset: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
  reboot: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
  cancel: '<circle cx="12" cy="12" r="9"/><path d="M15 9l-6 6M9 9l6 6"/>',
  trash: '<path d="M4 7h16"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13"/><path d="M10 11v6M14 11v6"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  plug: '<path d="M9 3v6M15 3v6"/><path d="M6 9h12v3a6 6 0 0 1-12 0z"/><path d="M12 18v3"/>',
  join: '<path d="M12 20V10"/><path d="M8.5 13.5a5 5 0 0 1 7 0"/><path d="M5.6 10.6a9 9 0 0 1 12.8 0"/><path d="M2.8 7.8a13 13 0 0 1 18.4 0"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  add: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  link: '<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
  forget: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M9 11l6 6M15 11l-6 6"/>'
};
function iconMarkup(key, size) {
  return '<svg viewBox="0 0 24 24" width="' + (size || 17) + '" height="' + (size || 17)
    + '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
    + (ICONS[key] || '') + '</svg>';
}
function setButtonIcon(button, key, label) {
  button.innerHTML = iconMarkup(key) + '<span>' + esc(label !== undefined ? label : button.textContent) + '</span>';
  return button;
}
function cmdButton(label, key, cls) {
  var b = el('button', 'btn cmd' + (cls ? ' ' + cls : ''));
  b.type = 'button';
  return setButtonIcon(b, key, label);
}

// Resting the pointer on a button for a while reveals what it really does.
var HINT_DELAY_MS = 5000;
var HINT = { timer: null, node: null };
function attachHint(element, html) {
  element.addEventListener('mouseenter', function () {
    clearTimeout(HINT.timer);
    HINT.timer = setTimeout(function () { showHint(element, html); }, HINT_DELAY_MS);
  });
  element.addEventListener('mouseleave', hideHint);
  element.addEventListener('blur', hideHint);
  element.addEventListener('touchstart', function () {
    clearTimeout(HINT.timer);
    HINT.timer = setTimeout(function () { showHint(element, html); }, 600);
  }, { passive: true });
  element.addEventListener('touchend', hideHint);
}
function showHint(element, html) {
  hideHint();
  var tip = el('div', 'hint');
  tip.innerHTML = html;
  document.body.appendChild(tip);
  var box = element.getBoundingClientRect();
  var width = tip.offsetWidth, height = tip.offsetHeight;
  var left = box.left + box.width / 2 - width / 2;
  left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
  var top = box.top - height - 10;
  if (top < 8) top = box.bottom + 10;
  tip.style.left = Math.round(left) + 'px';
  tip.style.top = Math.round(top) + 'px';
  requestAnimationFrame(function () { tip.classList.add('show'); });
  HINT.node = tip;
}
function hideHint() {
  clearTimeout(HINT.timer);
  if (HINT.node && HINT.node.parentNode) HINT.node.parentNode.removeChild(HINT.node);
  HINT.node = null;
}
window.addEventListener('scroll', hideHint, true);

// The buttons that live in the markup get their icons and hints once.
(function decorateStaticButtons() {
  setButtonIcon($('join-open'), 'join');
  attachHint($('join-open'), '<b>bridge/request/permit_join</b> {"time": 254}<br>Lets new devices join for four minutes. Asks for the PIN.');
  setButtonIcon($('join-close'), 'lock');
  attachHint($('join-close'), '<b>bridge/request/permit_join</b> {"time": 0}<br>Closes the network to new devices.');
  var resetHints = {
    history: '<b>POST /api/reset</b> {"scope": "history"}<br>Every recorded sample, full and hourly. Devices and events stay.',
    events: '<b>POST /api/reset</b> {"scope": "events"}<br>The event log only.',
    all: '<b>POST /api/reset</b> {"scope": "all"}<br><em>Everything</em> this dashboard recorded. Button bindings are kept.'
  };
  Array.prototype.forEach.call(document.querySelectorAll('[data-reset]'), function (b) {
    setButtonIcon(b, 'trash');
    attachHint(b, resetHints[b.getAttribute('data-reset')] || '');
  });
  setButtonIcon($('reset-device-btn'), 'forget');
  attachHint($('reset-device-btn'), '<b>POST /api/reset</b> {"scope": "device"}<br>Removes the device and its history from here. Zigbee2MQTT still knows it; it comes back with its next report.');
  setButtonIcon($('binding-add'), 'add');
  setButtonIcon($('binding-save'), 'save');
  attachHint($('binding-save'), '<b>POST /api/bindings</b><br>Replaces the whole list. The daemon applies it at once, no restart.');
})();

// ---- smart plugs -----------------------------------------------------------------
function powerIcon() {
  return '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/></svg>';
}
function runtimeText(seconds) {
  if (!isNum(seconds)) return '–';
  var d = Math.floor(seconds / 86400), h = Math.floor((seconds % 86400) / 3600), m = Math.floor((seconds % 3600) / 60);
  if (d) return d + 'd ' + h + 'h';
  if (h) return h + 'h ' + m + 'm';
  return m + 'm';
}
function counterSince(counter) {
  if (!counter || !counter.reset_at) return 'the plug does not say since when';
  return (counter.reset_exact ? 'since ' : 'counting since at least ') + stamp(counter.reset_at) + ' · ' + ago(counter.reset_at);
}
function counterText(type, value) {
  if (type === 'aenergy' || type === 'ret_aenergy') return value >= 1000 ? fmt(value / 1000, 2) + ' kWh' : fmt(value, 1) + ' Wh';
  if (type === 'switch_on') return fmt(value, 0) + '×';
  return runtimeText(value);
}
function plugByName(name) {
  var plugs = (STATE.status && STATE.status.plugs) || [];
  for (var i = 0; i < plugs.length; i++) if (plugs[i].name === name) return plugs[i];
  return null;
}
function renderSockets(st) {
  var host = $('sockets');
  var plugs = st.plugs || [];
  host.hidden = !plugs.length;
  host.innerHTML = '';
  plugs.forEach(function (plug) {
    var v = plug.values || {};
    var on = plug.output === 1;
    var card = el('div', 'card socket ' + (plug.online ? (on ? 'on' : 'off') : 'off') + (plug.stale ? ' stale' : ''));
    var state = el('div', 'socket-state');
    var btn = el('button', 'socket-toggle'); btn.type = 'button'; btn.innerHTML = powerIcon();
    btn.title = 'Switch ' + plug.name + (on ? ' off' : ' on');
    btn.disabled = !plug.online || plug.stale;
    btn.onclick = function () { switchPlug(plug, !on, btn); };
    state.appendChild(btn);
    var txt = el('div');
    txt.appendChild(el('div', 'socket-label', !plug.online ? plug.name + ' unreachable' : plug.name + (on ? ' on' : ' off')));
    var info = plug.info || {};
    var sub = plug.stale
      ? 'last answer ' + ago(plug.generated) + ' — ' + (plug.error || 'no answer') + (plug.retry_in ? ', retrying in ' + plug.retry_in + ' s' : '')
      : [info.model, info.app ? info.app + ' ' + (info.ver || '') : '', plug.host].filter(Boolean).join(' · ');
    txt.appendChild(el('div', 'socket-sub', sub));
    state.appendChild(txt);
    card.appendChild(state);
    var figures = el('div', 'socket-figures');
    var pairs = [
      ['Power', isNum(v.power) ? fmt(v.power, 1) + ' W' : '–'],
      ['Voltage', isNum(v.voltage) ? fmt(v.voltage, 1) + ' V' : '–'],
      ['Current', isNum(v.current) ? fmt(v.current, 3) + ' A' : '–'],
      ['Energy', isNum(v.energy) ? fmt(v.energy / 1000, 3) + ' kWh' : '–'],
      ['Plug temp', isNum(v.temperature) ? fmt(v.temperature, 1) + ' °C' : '–'],
    ];
    if (isNum(v.on_time)) pairs.push(['On time', runtimeText(v.on_time)]);
    if (isNum(v.switch_on)) pairs.push(['Switched', fmt(v.switch_on, 0) + '×']);
    if (isNum(v.rssi)) pairs.push(['Wi-Fi', fmt(v.rssi, 0) + ' dBm']);
    pairs.forEach(function (pr) {
      var box = el('div'); box.appendChild(el('div', 'k', pr[0])); box.appendChild(el('div', 'v', pr[1])); figures.appendChild(box);
    });
    card.appendChild(figures);
    host.appendChild(card);
  });
}
function switchPlug(plug, on, button) {
  if (button) { button.disabled = true; button.classList.add('busy'); }
  withPin('Switch ' + plug.name + ' ' + (on ? 'on' : 'off'), on ? 'Restores power to the socket.' : '<b>Everything plugged into it loses power.</b>', function (pin) {
    return post('plug-switch', {name: plug.name, on: on, pin: pin}).then(function (r) { return r.message || 'done'; });
  }, !on);
  setTimeout(function () { if (button) { button.disabled = false; button.classList.remove('busy'); } }, 3000);
}
function resetPlugCounters(plug, types, what, button) {
  if (button) { button.disabled = true; button.classList.add('busy'); }
  withPin('Reset ' + what + ' on ' + plug.name, 'That running total starts again from zero. Readings already recorded here are kept.', function (pin) {
    return post('plug-reset', {name: plug.name, types: types, pin: pin}).then(function (r) { return r.message || 'done'; });
  }, true);
  setTimeout(function () { if (button) { button.disabled = false; button.classList.remove('busy'); } renderPlugControls(STATE.status); }, 3000);
}
function renderPlugControls(st) {
  var card = $('plug-control'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  var host = $('plug-control-list'); host.innerHTML = '';
  plugs.forEach(function (plug) {
    var on = plug.output === 1, online = plug.online && !plug.stale;
    var info = plug.info || {};
    var block = el('div'); block.style.cssText = 'padding:12px 0;border-bottom:1px solid var(--line)';
    var head = el('div', 'row');
    head.appendChild(el('b', '', plug.name));
    head.appendChild(el('span', 'tag ' + (online ? (on ? 'ok' : 'dim') : 'crit'), online ? (on ? 'on' : 'off') : 'unreachable'));
    block.appendChild(head);
    block.appendChild(el('p', 'btnhelp', plug.stale
      ? 'The plug last answered ' + ago(plug.generated) + ': ' + (plug.error || 'no answer') + '. Controls are disabled until it responds.'
      : online ? [info.model, info.app ? info.app + ' ' + (info.ver || '') : '', plug.host].filter(Boolean).join(' · ') + ' — switching the socket cuts power to whatever is plugged into it.'
              : 'The plug is not answering: ' + (plug.error || 'unknown reason')));
    var row = el('div', 'btnrow');
    var toggle = cmdButton(on ? 'Switch the socket off' : 'Switch the socket on', 'power', on ? 'danger' : 'primary');
    toggle.disabled = !online;
    attachHint(toggle, '<b>Switch.Set ' + (on ? 'off' : 'on') + '</b><br>' + (on ? 'Cuts power to everything plugged into this socket.' : 'Restores power to the socket.') + '<br>Asks for the PIN.');
    toggle.onclick = function () { switchPlug(plug, !on, toggle); };
    row.appendChild(toggle);
    block.appendChild(row);

    var counters = (plug.counters || []).filter(function (c) { return c.value !== null && c.value !== undefined; });
    if (counters.length && online) {
      var heading = el('h3', '', 'Reset a counter');
      heading.style.cssText = 'font-size:12px;letter-spacing:.8px;text-transform:uppercase;color:var(--tx-mut);margin:18px 0 6px';
      block.appendChild(heading);
      block.appendChild(el('p', 'btnhelp', "These are the plug's own running totals, the same ones its web interface lists. Resetting one starts it from zero; the history recorded here is untouched."));
      var crow = el('div', 'btnrow');
      counters.forEach(function (c) {
        var b = cmdButton(c.label + ' · ' + counterText(c.type, c.value), 'reset');
        b.disabled = c.value === 0;
        attachHint(b, '<b>Switch.ResetCounters</b> {"type": ["' + c.type + '"]}<br>' + c.help + '.<br>'
          + (c.reset_at ? counterSince(c).replace(/^./, function (x) { return x.toUpperCase(); }) : 'Never reset from here, and the plug does not say when it was.')
          + (c.value === 0 ? '<br><em>Already at zero.</em>' : ''));
        b.onclick = function () { resetPlugCounters(plug, [c.type], c.label.toLowerCase(), b); };
        crow.appendChild(b);
      });
      var all = cmdButton('All counters', 'trash', 'danger');
      attachHint(all, '<b>Switch.ResetCounters</b><br>Every counter above, back to zero in one go.');
      all.onclick = function () { resetPlugCounters(plug, [], 'every counter', all); };
      crow.appendChild(all);
      block.appendChild(crow);
    }
    host.appendChild(block);
  });
}

// ---- button bindings --------------------------------------------------------------
var BINDINGS = {rows: null, dirty: false};
function bindingDevices(st) {
  // Only devices that can send an action - a button, a remote, a contact with
  // a click - plus anything a saved binding still points at.
  var list = st.devices.filter(function (d) { return d.has_action; });
  var ids = list.map(function (d) { return d.id; });
  (BINDINGS.rows || []).forEach(function (b) {
    var d = b.device && deviceById(b.device);
    if (d && ids.indexOf(d.id) < 0) { list.push(d); ids.push(d.id); }
  });
  return list;
}
function actionOptions(device, current) {
  var opts = device && device.actions ? device.actions.slice() : [];
  if (!opts.length) opts = ['single', 'double', 'triple', 'long', 'hold', 'release'];
  if (current && current !== '*' && opts.indexOf(current) < 0) opts.push(current);
  opts.push('*');
  return opts;
}
function fillSelect(select, options, current) {
  select.innerHTML = '';
  options.forEach(function (o) {
    var opt = el('option', '', typeof o === 'string' ? o : o[1]);
    opt.value = typeof o === 'string' ? o : o[0];
    select.appendChild(opt);
  });
  if (current !== undefined && current !== null && Array.prototype.some.call(select.options, function (o) { return o.value === String(current); })) select.value = current;
  return select.value;
}
function renderBindings(st) {
  var card = $('bindings-card'), plugs = (st && st.plugs) || [];
  card.hidden = !plugs.length;
  if (!plugs.length) return;
  if (BINDINGS.rows === null || !BINDINGS.dirty) BINDINGS.rows = (st.bindings || []).map(function (b) { return Object.assign({}, b); });
  var host = $('bindings-list'); host.innerHTML = '';
  var head = el('div', 'bind-row bind-head');
  ['Device', 'Action', 'Plug', 'Do', ''].forEach(function (t) { head.appendChild(el('span', '', t)); });
  host.appendChild(head);
  var devices = bindingDevices(st);
  if (!BINDINGS.rows.length) host.appendChild(el('div', 'muted small', devices.length ? 'No bindings yet.' : 'No device that sends actions has been seen yet. Pair a button and press it once.'));
  BINDINGS.rows.forEach(function (b, i) {
    var row = el('div', 'bind-row');
    var dev = el('select'), act = el('select'), plug = el('select'), doSel = el('select');
    b.device = fillSelect(dev, devices.map(function (d) { return [d.id, d.name + (d.actions && d.actions.length ? ' (' + d.actions.length + ' actions)' : '')]; }), b.device);
    function refillActions() {
      b.action = fillSelect(act, actionOptions(deviceById(b.device), b.action), b.action || 'single');
    }
    refillActions();
    dev.onchange = function () { b.device = dev.value; b.action = null; refillActions(); BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    act.onchange = function () { b.action = act.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    b.plug = fillSelect(plug, plugs.map(function (p) { return [p.name, p.name + (p.online ? '' : ' (unreachable)')]; }), b.plug);
    plug.onchange = function () { b.plug = plug.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    b.do = fillSelect(doSel, (st.binding_actions || ['toggle', 'on', 'off']).map(function (a) {
      return [a, {toggle: 'toggle', on: 'switch on', off: 'switch off'}[a] || a]; }), b.do || 'toggle');
    doSel.onchange = function () { b.do = doSel.value; BINDINGS.dirty = true; $('binding-note').textContent = 'Unsaved changes'; };
    var del = cmdButton('Remove', 'cancel', 'small danger');
    del.onclick = function () { BINDINGS.rows.splice(i, 1); BINDINGS.dirty = true; renderBindings(STATE.status); };
    [dev, act, plug, doSel, del].forEach(function (x) { row.appendChild(x); });
    host.appendChild(row);
  });
  $('binding-note').textContent = BINDINGS.dirty ? 'Unsaved changes' : '';
}
$('binding-add').onclick = function () {
  BINDINGS.rows = BINDINGS.rows || [];
  BINDINGS.rows.push({device: '', action: null, plug: '', do: 'toggle', enabled: true});
  BINDINGS.dirty = true;
  renderBindings(STATE.status);
};
$('binding-save').onclick = function () {
  withPin('Save button bindings', 'Confirm with the dashboard PIN.', function (pin) {
    return post('bindings-save', {bindings: BINDINGS.rows || [], pin: pin}).then(function (r) {
      BINDINGS.dirty = false; BINDINGS.rows = null;
      return (r.bindings || []).length + ' binding(s) saved';
    });
  });
};

// ---- refresh loop ------------------------------------------------------------------
function applyStatus(st) {
  STATE.status = st;
  var pill = $('pill');
  pill.className = 'pill ' + st.level;
  $('pill-text').textContent = levelWord(st.level) + (st.connected ? '' : ' — broker unreachable');
  setFavicon(st.level);
  document.title = (st.level === 'ok' ? '' : (st.level === 'crit' ? '⚠ ' : '● ')) + 'Sensors — ' + st.counts.devices + ' devices';
  renderOverview(st);
  renderHistoryControls();
  renderDevices(st);
  renderAll(st);
  renderPlugControls(st);
  if (!BINDINGS.dirty) renderBindings(st);   // never redraw under someone's typing
  $('updated-time').textContent = stamp(st.ts);
}
function tick(force) {
  if ((STATE.paused || document.hidden) && !force) return;
  if (STATE.busy) return;
  STATE.busy = true;
  api('status').then(function (st) {
    applyStatus(st);
    $('updated-label').textContent = STATE.paused ? 'Paused' : 'Live';
    if (STATE.tab === 'overview' && (force || !STATE._ovLoaded || (Date.now() - STATE._ovLoaded) > 60000)) { loadOverviewCharts(); STATE._ovLoaded = Date.now(); }
    if (STATE.tab === 'events' && force) loadEvents();
    if (STATE.tab === 'control') loadHealth();
  }).catch(function (e) {
    $('pill').className = 'pill crit'; $('pill-text').textContent = 'Dashboard offline';
    $('updated-label').textContent = 'Error';
    $('updated-time').textContent = e.message;
    setFavicon('crit');
  }).then(function () { STATE.busy = false; });
}
function showTab(name) {
  STATE.tab = name;
  Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
    b.setAttribute('aria-selected', b.getAttribute('data-tab') === name ? 'true' : 'false');
  });
  Array.prototype.forEach.call(document.querySelectorAll('.panel'), function (p) { p.hidden = p.id !== 'tab-' + name; });
  if (name === 'history') { renderHistoryControls(); loadHistory(); }
  if (name === 'events') loadEvents();
  if (name === 'control') loadHealth();
  if (name === 'overview') { redrawCharts(); if (!STATE._ovLoaded) { loadOverviewCharts(); STATE._ovLoaded = Date.now(); } }
  try { history.replaceState(null, '', '#' + name); } catch (e) {}
}
Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
  b.onclick = function () { showTab(b.getAttribute('data-tab')); };
});
$('updated').onclick = function () {
  STATE.paused = !STATE.paused;
  $('updated').classList.toggle('paused', STATE.paused);
  $('updated-label').textContent = STATE.paused ? 'Paused' : 'Live';
  if (!STATE.paused) tick(true);
};
document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(true); });
function pickOverviewRange(r) {
  STATE.ovRange = r; rangeButtons($('ov-ranges'), ['6h', '24h', '7d'], r, pickOverviewRange); loadOverviewCharts();
}
rangeButtons($('ov-ranges'), ['6h', '24h', '7d'], STATE.ovRange, pickOverviewRange);

if (INITIAL) applyStatus(INITIAL);
var wanted = (location.hash || '#overview').substring(1);
showTab(['overview', 'history', 'devices', 'events', 'control', 'all'].indexOf(wanted) >= 0 ? wanted : 'overview');
tick(true);
STATE.timer = setInterval(function () { tick(false); }, REFRESH_MS);
</script>
</body>
</html>
