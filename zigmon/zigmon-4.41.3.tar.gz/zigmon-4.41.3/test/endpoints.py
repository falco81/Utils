#!/usr/bin/env python3
"""Every path the web relay forwards must be one the daemon actually serves.

Run before a release. It reads both files rather than the running daemon, so
it needs nothing set up, and it catches the mistake that shipped in 2.90.0:
an endpoint written into the daemon's read branch while the page posts to it.
"""
import re
import sys
from pathlib import Path

here = Path(__file__).resolve().parent.parent
php = (here / 'web' / 'index.php').read_text()
py = (here / 'zigmon.py').read_text()

relayed = set(re.findall(r"zigmon_relay\('(/api/[a-z0-9/_-]+)", php))
relayed |= set(re.findall(r"=> '(/api/[a-z0-9/_-]+)'", php))

served = set(re.findall(r"path == '(/api/[a-z0-9/_-]+)'", py))
for group in re.findall(r"path in \(([^)]+)\)", py):
    served |= set(re.findall(r"'(/api/[a-z0-9/_-]+)'", group))

# a path the daemon answers by its opening rather than in full, such as a
# one-tap link, where the rest of the path is the link's own secret
starts = re.findall(r"path\.startswith\('(/api/[a-z0-9/_-]+)'\)", py)
missing = sorted(p for p in relayed - served
                 if not any(p.startswith(x) for x in starts))
if missing:
    print('the relay forwards paths the daemon does not serve:')
    for p in missing:
        print('   ', p)
    sys.exit(1)
print('%d relayed path(s), all served' % len(relayed))


# Every name the page calls must be one the relay serves. It caught a save
# that used a button's id as a path and answered "unknown endpoint".
import re as _re
_src = (here / 'web' / 'index.php').read_text() if 'here' in dir() else open(str(__file__).rsplit('/', 2)[0] + '/web/index.php').read()
_js = _re.search(r'<script>(.*?)</script>', _src, _re.S).group(1)
_called = set(_re.findall(r"post\('([a-z0-9-]+)'", _js)) | set(_re.findall(r"api\('([a-z0-9-]+)", _js))
_allow = set(_re.findall(r"'([a-z0-9-]+)'", _re.search(r"if \(in_array\(\$what, \[(.*?)\], true\)", _src, _re.S).group(1)))
_gets = set(_re.findall(r"\$what === '([a-z0-9-]+)'", _src))
_paths = set(_re.findall(r"'([a-z0-9-]+)' => '/api", _src))
_missing = sorted(_called - _allow - _gets - _paths)
if _missing:
    print('the page calls names the relay does not serve:')
    for _name in _missing:
        print('   %s' % _name)
    raise SystemExit(1)
print('%d name(s) the page calls, all of them served' % len(_called))

# ?ask has to survive every hop. It is dropped in two ways that look like
# nothing at all: an nginx rewrite whose replacement holds a ? throws the
# original query away, and a relay that rebuilds the path leaves it behind.
# Either way, asking how things stand quietly becomes switching them.
php = (Path(__file__).resolve().parent.parent / 'web' / 'index.php').read_text()
conf = (Path(__file__).resolve().parent.parent / 'deploy' / 'nginx-zigmon.conf').read_text()
lost = []
for line in php.split('\n'):
    if "'/api/tap/'" in line and 'relay' in line and 'ask' not in line:
        lost.append('the relay drops ?ask: %s' % line.strip()[:70])
for line in conf.split('\n'):
    if line.strip().startswith('rewrite') and '?' in line and '$args' not in line:
        lost.append('this rewrite throws the query away: %s' % line.strip()[:70])
if lost:
    print('?ask would not arrive:')
    for line in lost:
        print('   ' + line)
    sys.exit(1)
print('?ask survives the relay and the rewrite')


# Some answers are not a view of the house but the whole of how it is set up:
# the sockets' password, the router's password and its ssh key, every person's
# phone number and MAC address, a person's own token. Those went out to
# whoever could reach the page, because public_view means anybody may watch
# the house and was taken to mean anybody may read its keys. They ask for the
# PIN whatever public_view says, and this holds the daemon to that list.
sys.path.insert(0, str(here))
sys.argv = ['zigmon']
import zigmon                                             # noqa: E402
_locked = set(zigmon.ApiHandler.ALWAYS_LOCKED)
for _must in ('/api/export', '/api/log', '/api/managed', '/api/sms/log', '/api/mqtt/acl'):
    assert _must in _locked, '%s is readable by anybody' % _must
_words = (Path(__file__).resolve().parent.parent / 'zigmon.py').read_text()
_where = _words.index('if path in self.ALWAYS_LOCKED:')
_before = _words[:_where]
assert "if not CONFIG.get('public_view', True):" not in _before.rsplit('def do_GET', 1)[-1], \
    'the lock is applied after the public_view gate, so it never runs for a public view'
print('%d read(s) hold the PIN in front of them whatever the view is set to' % len(_locked))


# A name that is read with a GET and worked with by a POST is written twice in
# the relay: once as a branch of its own, once in the map of POST names. The
# branch stands first, so without a method on it every press went out as a GET
# - refused, because a GET of these wants the PIN in a session rather than in
# a body - and the page asked for the PIN again, and again.
_posted = set(re.findall(r"'([a-z0-9-]+)' => '/api/", php))
_branches = re.findall(r"if \(\$what === '([a-z0-9-]+)'([^)]*)\) \{", php)
_both = [(name, rest) for name, rest in _branches if name in _posted]
_loose = [name for name, rest in _both if 'REQUEST_METHOD' not in rest]
if _loose:
    print('these are read and written under one name, and the reading branch takes both:')
    for name in _loose:
        print('   %s' % name)
    raise SystemExit(1)
print('%d name(s) serve a GET and a POST, each branch saying which it takes' % len(_both))


# The reads that hold the PIN in front of them are let through to a tool on
# the machine itself - the command line, which can read the database directly
# anyway - and that has to mean a tool holding the API token. Without the
# token, anything able to open a socket to the daemon could read the export,
# passwords and all: the web server's own worker most of all, which is the
# very thing an attacker would be trying to subvert.
_daemon_src = open(str(__file__).rsplit('/', 2)[0] + '/zigmon.py').read()
_where = _daemon_src.index('local = (self.client_address[0]')
_lines = _daemon_src[_where:_where + 400]
if '_authorised()' not in _lines:
    print('the local road into the locked reads does not ask for the API token')
    raise SystemExit(1)
if 'X-Zigmon-Client' not in _lines:
    print('the local road does not refuse a browser coming by the relay')
    raise SystemExit(1)
print('the locked reads open only to a local tool holding the token')

# ...and the command line has to send one on a read, or the road it was opened
# for is a road it cannot take.
if "if token is None:\n        token = read_token()" not in _daemon_src:
    print('the command line does not send its token on a read, so the locked reads refuse it')
    raise SystemExit(1)
print('the command line sends its token on reads as well as on writes')

# With no PIN set at all, check_pin has nothing to check and lets everything
# through - and these reads hold passwords, people and their MAC addresses. A
# house that never set one was handing them to anybody who could reach the
# dashboard, with the whole of the locking machinery in place and doing
# nothing.
if "not str(CONFIG.get('pin') or '').strip()" not in _daemon_src[_where - 600:_where + 1200]:
    print('with no PIN set, the locked reads are open to every browser')
    raise SystemExit(1)
print('with no PIN set the locked reads are refused rather than opened')


# A secret travels in an address under more than one name, and the debug log
# writes addresses out. session was not among the names it blotted - and the
# page puts one on every request it makes, so with debug on the log filled
# with working keys; a PIN written into a query was written into the log
# beside it.
_at = _daemon_src.index('SECRET_IN_PATH = re.compile')
_pattern = _daemon_src[_at:_at + 400]
for _name in ('session', 'pin', 'token', 'secret', 'password', 'code'):
    if _name not in _pattern:
        print('a %s= in an address is written out in the log' % _name)
        raise SystemExit(1)
print('a secret in an address is blotted whatever name it travels under')


# A request that names no valid session locks nothing. /api/lock asks for no
# PIN - the page uses it to lock its own session - and it used to clear every
# session when handed a token it did not know, so one request with a made-up
# token from anything that could reach the relay logged every editor out.
import zigmon as _zz
_zz.load_config()
_zz.CONFIG['pin'] = '4321'
_dd = _zz.Daemon()
_one, _ = _dd.unlock('4321', 5, 'a phone')
_two, _ = _dd.unlock('4321', 5, 'a laptop')
assert len(_dd.sessions) == 2
_dd.lock_editing('made-up-token')
assert len(_dd.sessions) == 2, 'a token nobody issued locked %d session(s)' % (2 - len(_dd.sessions))
_dd.lock_editing(_one['token'])
assert len(_dd.sessions) == 1 and _two['token'] in _dd.sessions, 'locking one session touched the other'
print('a token nobody issued locks nothing; a real one locks only itself')

# ...and the proxy's read is configuration like the router's, behind the PIN
if "'/api/proxy'" not in _daemon_src[_daemon_src.index('ALWAYS_LOCKED = ('):_daemon_src.index('ALWAYS_LOCKED = (') + 900]:
    print('/api/proxy is open to every browser while /api/mikrotik is not')
    raise SystemExit(1)
print('the proxy and the router are behind the same PIN')


# Every command the help offers has to exist, and every command that exists
# should be findable in the help: a flag nobody lists is a flag nobody uses,
# and a line in the help for a flag that is gone is worse.
import re as _re2
_flags = set(_re2.findall(r"a\.add_argument\('(--[a-z-]+)'", _daemon_src))
_listed = set(_re2.findall(r"'zigmon (--[a-z-]+)", _daemon_src))
_missing = sorted(f for f in _listed if f not in _flags)
if _missing:
    print('the help offers flag(s) the command line does not have: %s' % ', '.join(_missing))
    raise SystemExit(1)
# ...and every command is findable in it, whether as an example of its own or
# named in the words beside another. The modifiers - the ones that only make
# sense after a command - are in the option list above and not repeated here.
_modifiers = {'--bridge', '--count', '--keys', '--limit', '--ms', '--number', '--pin', '--points',
              '--range', '--raw', '--seconds', '--text', '--types', '--json', '--no-color',
              '--force', '--secret', '--test', '--version', '--config', '--debug', '--allow-root'}
_help_block = _daemon_src[_daemon_src.index('HELP_LINES = ['):_daemon_src.index("\n]\n\n\ndef help_text")]
_nowhere = sorted(f for f in _flags
                  if f not in _modifiers and f not in _listed and f not in _help_block)
if _nowhere:
    print('command(s) the help never names at all: %s' % ', '.join(_nowhere))
    raise SystemExit(1)
# and the help is in sections rather than one long list
if _daemon_src.count("('#', '") < 4:
    print('the help is one long list again, with no headings in it')
    raise SystemExit(1)
print('every command in the help exists, and the help is in sections')


# The daemon never sends a secret's value, only whether there is one - so the
# command line must not print that answer as though it were the secret. It
# printed the word True.
_at = _daemon_src.index('def cmd_settings')
_body = _daemon_src[_at:_at + 2000]
if "kind') == 'secret'" not in _body:
    print('zigmon --settings does not treat a secret as a secret')
    raise SystemExit(1)
if "'\\u2026' + str(value)" in _body:
    print('zigmon --settings prints the last letters of something that is not the secret')
    raise SystemExit(1)
print('the command line says whether a secret is set, never what it is')


# A private ntfy is the ordinary case for a server of one's own, and urllib
# does nothing with the user and password in a URL - it leaves them there, so
# the server sees a token in the address and no credentials at all.
_plain, _none = _zz.ntfy_address('https://ntfy.sh/a-topic')
assert _plain == 'https://ntfy.sh/a-topic' and _none is None, 'a plain topic URL was meddled with'
_where, _auth = _zz.ntfy_address('https://:tk_abc123@ntfy.example.net:8443/house')
assert _where == 'https://ntfy.example.net:8443/house', 'the token stayed in the address: %s' % _where
assert _auth == 'Bearer tk_abc123', 'a token is not sent as a bearer: %r' % _auth
_where, _auth = _zz.ntfy_address('https://falco:a%40b@ntfy.example.net/house')
assert _where == 'https://ntfy.example.net/house', 'the name stayed in the address: %s' % _where
import base64 as _b64
assert _auth == 'Basic ' + _b64.b64encode(b'falco:a@b').decode(), \
    'a password with an at-sign in it was not unescaped: %r' % _auth
print('a token or a name in an ntfy address is sent as credentials, not left in the address')

# ...and where such an address turns up in a log, the part in front of the
# host goes. A token is a secret; so is the name beside it, since knowing
# which account is half of guessing it.
_hidden = _zz.ApiHandler.hide_secrets(
    'POST https://:tk_7327tbrh4064fw8g8t8@ntfy.example.net/zigmon-house')
assert 'tk_7327' not in _hidden, 'a token in an address is written into the log: %s' % _hidden
assert 'ntfy.example.net/zigmon-house' in _hidden, 'the whole address went, not just the secret'
_hidden = _zz.ApiHandler.hide_secrets('https://falco:hunter2@ntfy.example.net/x')
assert 'hunter2' not in _hidden and 'falco' not in _hidden, \
    'a name and password in an address are written into the log: %s' % _hidden
assert _zz.ApiHandler.hide_secrets('https://ntfy.sh/a-topic') == 'https://ntfy.sh/a-topic', \
    'an address with no secret in it was meddled with'
print('an address that carries a name or a token is blotted where it is written down')


# No address is ever spared by the program itself. Who is let by is the
# house's business, written in never_block and nowhere else; the only thing
# the code may recognise on its own is the machine it is running on.
import re as _re4
_allowed = {'127.0.0.1', '::1', '0.0.0.0'}
_bad = []
for _m in _re4.finditer(r"in \((?:'[^']*',?\s*)+\)", _daemon_src):
    _addresses = _re4.findall(r"'((?:\d{1,3}\.){3}\d{1,3}(?:/\d+)?|::1|[0-9a-f:]{4,}(?:/\d+)?)'", _m.group(0))
    for _one in _addresses:
        if _one not in _allowed:
            _bad.append(_one)
if _bad:
    print('the program spares addresses of its own: %s' % ', '.join(sorted(set(_bad))))
    print('who is let by belongs in never_block, which is the house\'s to write')
    raise SystemExit(1)
print('no address is spared by the program; only the machine it runs on is recognised')


# Every road that ACTS asks for the PIN. The daemon is asked rather than the
# source read: a POST with no PIN must be refused. Locking a session is the
# one road allowed through, because taking your own key away is not an act
# anybody needs protecting from.
import json as _json5
import re as _re5
import threading as _th5
import urllib.error as _ue5
import urllib.request as _ur5

_zz.CONFIG.update({"pin": "1234", "api_port": 19931})
_ask_daemon = _zz.Daemon()
_server = _zz.ApiServer(_ask_daemon)
_server.start()
_time5 = __import__('time')
_time5.sleep(0.5)


def _post_raw(road, body):
    _req = _ur5.Request('http://127.0.0.1:19931' + road, data=_json5.dumps(body).encode(),
                        headers={'Content-Type': 'application/json',
                                 'X-Zigmon-Client': '1.2.3.4',
                                 'X-Zigmon-Token': _ask_daemon.token}, method='POST')
    try:
        return _ur5.urlopen(_req, timeout=8).status
    except _ue5.HTTPError as _e:
        return _e.code
    except Exception:
        return 0


_roads = sorted(set(_re5.findall(r"if path == '(/api/[a-z0-9/_-]+)':", _daemon_src)))
_open_by_design = {'/api/lock'}
_acted = []
for _road in _roads:
    if _road in _open_by_design:
        continue
    _code = _post_raw(_road, {})
    if _code not in (0, 400, 403, 404, 405, 409, 500):
        _acted.append((_road, _code))
if _acted:
    print('%d POST road(s) answered without a PIN:' % len(_acted))
    for _r, _c in _acted[:8]:
        print('   %-28s %s' % (_r, _c))
    raise SystemExit(1)
print('%d road(s) that act, every one of them behind the PIN' % len(_roads))
