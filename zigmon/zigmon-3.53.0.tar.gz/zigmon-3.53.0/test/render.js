const { JSDOM } = require('jsdom');
(async () => {
  const base = 'http://127.0.0.1:8099/';
  const html = await (await fetch(base + 'index.php')).text();
  const errors = [];
  const dom = new JSDOM(html, { url: base + 'index.php', runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true,
    beforeParse(window) {
      window.fetch = (url, opts) => fetch(new URL(url, base).href, opts);
      window.confirm = () => true;
      window.addEventListener('error', e => errors.push(e.message));
      window.console.error = (...a) => errors.push(a.join(' '));
      Object.defineProperty(window.HTMLElement.prototype, 'clientWidth', { get() { return 600; } });
      Object.defineProperty(window.HTMLElement.prototype, 'clientHeight', { get() { return 240; } });
      Object.defineProperty(window.HTMLElement.prototype, 'offsetParent', { get() { return this.parentNode; } });
    }});
  const w = dom.window, d = w.document;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  await wait(1500);
  const txt = id => (d.getElementById(id) || {}).textContent;
  console.log('pill:', txt('pill-text'), '| devices:', txt('m-devices'), '| cards:', d.querySelectorAll('#device-cards .dev').length);
  console.log('ov-temp svg paths:', d.querySelectorAll('#ov-temp path').length, 'legend:', txt('ov-temp-legend'));
  for (const tab of ['history','devices','events','control','all']) {
    d.querySelector('.tabs button[data-tab="'+tab+'"]').click();
    await wait(1200);
  }
  console.log('history charts:', d.querySelectorAll('#h-charts .card').length, '| note:', txt('h-note'));
  console.log('devices rows:', d.querySelectorAll('#devices-table tbody tr').length);
  console.log('events rows:', d.querySelectorAll('#events-table tbody tr').length);
  console.log('health rows:', d.querySelectorAll('#health-kv .kv').length);
  console.log('all cards:', d.querySelectorAll('#all-values .card').length);
  // control: reset events with PIN flow
  d.querySelector('.tabs button[data-tab="control"]').click(); await wait(300);
  d.querySelector('[data-reset="events"]').click(); await wait(200);
  console.log('modal shown:', !d.getElementById('pinback').hidden);
  // the PIN is one box per digit since 2.x
  Array.from(d.getElementById('pindigits').querySelectorAll('input')).forEach((i, n) => { i.value = '1234'[n] || ''; i.dispatchEvent(new w.Event('input', {bubbles: true})); });
  d.getElementById('pinok').click(); await wait(1200);
  console.log('toast:', txt('toast'));
  // hover a chart
  d.querySelector('.tabs button[data-tab="overview"]').click(); await wait(800);
  const c = d.getElementById('ov-temp');
  c.dispatchEvent(new w.MouseEvent('mousemove', {clientX: 300, clientY: 100, bubbles: true}));
  console.log('tip:', (c.querySelector('.tip')||{}).style && c.querySelector('.tip').style.display, (c.querySelector('.tip')||{}).textContent);
  // A rule dragged by its handle must survive the house reporting while the
  // pointer is down: the guard against redrawing under a drag knew only about
  // the cards, so in a busy house every drag was undone by the next report.
  try {
    const r2 = await (await fetch(base + 'index.php?api=unlock', {method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({pin: '1234', minutes: 30})})).json();
    if (r2 && r2.token) {
      w.LOCK.token = r2.token; w.LOCK.until = r2.until; w.SIGS = {}; w.tick(true);
      d.querySelector('.tabs button[data-tab="control"]').click(); await wait(400);
      w.showControlSection('automation'); await wait(2500);
      const packs = Array.from(d.querySelectorAll('#rules-list .rule-pack'));
      if (packs.length > 1) {
        const a = packs[0], b = packs[1], parent = a.parentNode;
        const dt = {effectAllowed: '', setData() {}, getData() { return 'row'; }};
        a.querySelector('.rowgrab').dispatchEvent(new w.MouseEvent('mousedown', {bubbles: true}));
        a.dispatchEvent(Object.assign(new w.Event('dragstart', {bubbles: true}), {dataTransfer: dt}));
        // exactly what a report from the house does, and what used to rebuild
        // the list out from under the pointer
        w.SIGS = {}; w.tick(true); await wait(1800);
        if (!d.body.contains(a)) errors.push('the row being dragged was rebuilt out from under the pointer');
        b.dispatchEvent(Object.assign(new w.Event('dragover', {bubbles: true, cancelable: true}), {dataTransfer: dt}));
        const moved = Array.prototype.indexOf.call(parent.children, a)
                    > Array.prototype.indexOf.call(parent.children, b);
        a.dispatchEvent(new w.Event('dragend', {bubbles: true}));
        await wait(400);
        console.log('a rule dragged through a redraw moves:', moved);
        if (!moved) errors.push('a rule could not be dragged while the house was reporting');
      }
    }
  } catch (e) { errors.push('the drag check itself failed: ' + e.message); }

  // Every way in must lead somewhere, and everything meant for a section must
  // be reachable from it. A card filed under a section with no button, or a
  // tab with no panel, is invisible however right the code behind it is.
  try {
    const tabs = Array.from(d.querySelectorAll('.tabs button[data-tab]')).map(b => b.dataset.tab);
    const panels = Array.from(d.querySelectorAll('section.panel[id^="tab-"]')).map(s => s.id.slice(4));
    tabs.forEach(t => { if (panels.indexOf(t) < 0) errors.push('the ' + t + ' tab has no panel'); });
    panels.forEach(p => { if (tabs.indexOf(p) < 0) errors.push('the ' + p + ' panel has no tab button'); });
    const navSecs = Array.from(d.querySelectorAll('#control-nav button[data-sec]')).map(b => b.dataset.sec);
    const cardSecs = Array.from(d.querySelectorAll('#tab-control [data-sec]'))
      .filter(x => x.tagName !== 'BUTTON').map(x => x.dataset.sec);
    cardSecs.forEach(s2 => {
      if (navSecs.indexOf(s2) < 0) errors.push('a card is filed under "' + s2 + '", which has no button');
    });
    navSecs.forEach(s2 => {
      if (cardSecs.indexOf(s2) < 0) errors.push('the "' + s2 + '" button leads to nothing');
    });
    console.log('ways in: %d tab(s), %d section(s), all of them leading somewhere',
                tabs.length, navSecs.length);
  } catch (e) { errors.push('the reachability check itself failed: ' + e.message); }

  // Every column header against the rows it names. Two faults kept appearing
  // one editor at a time: a header without the indent its rows get for the
  // drag handle, so every name sits one notch left of its column; and a
  // header that inherits its row's rounded corners, which lifts the ends of
  // its underline off the line.
  try {
    // The gateways are only there to measure when one is configured, and a
    // check that says nothing when there are none is how their header was
    // wrong three times over. Plant one for the measurement and take it away.
    var plantedGateway = false;
    if (!d.querySelector('.gw-row:not(.gw-head)')) {
      var gwSave = await (await fetch(base + 'index.php?api=gateways-save', {method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({pin: '1234', gateways: [{name: 'Measure-Me', host: '127.0.0.1', kind: 'slzb'}]})})).json();
      if (gwSave && gwSave.ok) { plantedGateway = true; w.SIGS = {}; w.tick(true); await wait(1500); }
      else errors.push('no gateway on the page and none could be planted to measure the header');
    }
    // every card has to be drawn before its header can be measured
    for (var si = 0; si < ['devices', 'automation', 'presence', 'alerts', 'system'].length; si++) {
      w.showControlSection(['devices', 'automation', 'presence', 'alerts', 'system'][si]);
      await wait(1500);
    }
    await wait(800);
    var headTrouble = [];
    // Every column header on the page, measured the way the eye measures it:
    // the header stands above the folds and the boxes it names sit inside
    // them, so a fold's own inset moves the boxes and not the names. Some
    // editors fold their rows and some do not, and the header has to follow
    // whichever it is - calling the difference "the fold rather than a
    // misalignment" is how this was waved away twice.
    var headsSeen = 0;
    Array.prototype.forEach.call(d.querySelectorAll('[class*="-head"]'), function (head) {
      var kind = (String(head.className).match(/([a-z0-9]+)-head/) || [])[1];
      if (!kind) return;
      var card = head.closest('.card') || d;
      var rows = Array.prototype.filter.call(card.querySelectorAll('.' + kind + '-row'),
        function (x) { return !x.classList.contains(kind + '-head'); });
      if (!rows.length) return;
      var reach = function (node) {
        var total = 0;
        while (node && node !== card) {
          total += parseFloat(w.getComputedStyle(node).paddingLeft) || 0;
          node = node.parentElement;
        }
        return total;
      };
      headsSeen++;
      // every row, not the first: the gateways mix rows from config.json,
      // which cannot be dragged, with rows made on the page, which can, and
      // a header can only line up with all of them if they agree
      var nameAt = reach(head);
      var offRows = rows.map(function (row) { return reach(row); })
        .filter(function (at) { return at !== nameAt; });
      if (offRows.length) {
        headTrouble.push(kind + ': the names start at ' + nameAt + 'px and ' + offRows.length + ' of '
          + rows.length + ' row(s) start at ' + offRows[0] + 'px'
          + (rows[0].closest('.section-body') ? ' (its rows are in a fold)' : ''));
      }
      // Only a header drawn as a row of its table can curve away from its own
      // underline; a plain caption above a list is not that and has nothing
      // to line up with.
      var hs = w.getComputedStyle(head);
      if (head.classList.contains(kind + '-row')
          && hs.borderRadius !== '0px' && hs.borderBottomWidth !== '0px') {
        headTrouble.push(kind + ': rounded header with an underline, which lifts at the ends');
      }
    });
    headTrouble.forEach(function (t) { errors.push('column header - ' + t); });
    if (!d.querySelector('.gw-row:not(.gw-head)')) errors.push('the gateway header was never measured');
    if (plantedGateway) {
      await fetch(base + 'index.php?api=gateways-save', {method: 'POST',
        headers: {'Content-Type': 'application/json'}, body: JSON.stringify({pin: '1234', gateways: []})});
    }
    console.log('column headers: %d measured, %s', headsSeen,
      headTrouble.length ? 'some out of line' : 'every name over its box');
  } catch (e) { errors.push('the column header check itself failed: ' + e.message); }

  // A link telling something of its own has the same writing desk an alert
  // has: the symbol picker, the fact picker, the completer, and a preview
  // that says what the watch would read out.
  try {
    w.showControlSection('automation');
    await wait(1800);
    var tapRow = d.querySelector('#taps-list .tap-row:not(.tap-head)');
    if (tapRow && (w.TAPS.rows || []).length) {
      var theTap = w.TAPS.rows[0];
      theTap.target = 'tell'; theTap.do = 'own';
      theTap.text = 'Inside {inside_c} and outside {outside_c}.';
      w.TAPS.dirty = true; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
      await wait(300);
      var desk = d.querySelector('.tap-storybox');
      if (!desk || desk.hidden) errors.push('a link of your own has no writing desk');
      else {
        if (!desk.querySelector('textarea')) errors.push('the writing desk has no text area');
        var deskBtns = Array.prototype.map.call(desk.querySelectorAll('button'),
          function (b) { return b.textContent; }).join(' ');
        if (deskBtns.indexOf('Emoji') < 0) errors.push('the writing desk has no symbol picker');
        if (deskBtns.indexOf('Facts') < 0) errors.push('the writing desk has no fact picker');
        // the section sweep above leaves another section showing, so come
        // back to the links before looking for their preview
        w.showControlSection('automation');
        await wait(1200);
        w.scheduleTellPreview();
        var shown = null;
        for (var pw = 0; pw < 12; pw++) {
          shown = d.querySelector('.tap-preview[data-tap="' + theTap.id + '"]');
          if (shown && (shown.textContent || '').match(/[0-9]/)) break;
          await wait(300);
        }
        if (!shown || !(shown.textContent || '').match(/[0-9]/)) {
          errors.push('the preview says nothing about what the watch would read');
        }
      }
      // the row above the desk keeps its shape whatever the link is doing:
      // a switch, a prepared report, or a sentence of your own
      var shapes = [];
      var trials = [['Probe-Plug', 'toggle'], ['tell', 'house'], ['tell', 'own']];
      for (var ti = 0; ti < trials.length; ti++) {
        var pair = trials[ti];
        theTap.target = pair[0]; theTap.do = pair[1];
        w.TAPS.dirty = true; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
        var again = d.querySelector('#taps-list .tap-row:not(.tap-head)');
        var onLine = Array.prototype.filter.call(again.children, function (c) {
          return !c.classList.contains('rowgrab') && !c.classList.contains('tap-storybox');
        }).length;
        var area = again.querySelector('.tap-story');
        var tools = again.querySelector('.tap-storytools');
        shapes.push(onLine);
        if (area && tools && area.hidden !== tools.hidden) {
          errors.push('the text box and its buttons do not come and go together');
        }
        // What is on the screen, not what the script believes: display:flex
        // beats the hidden attribute, and that is how the pickers stayed
        // visible however carefully they were hidden.
        var seen = function (node) { return node && w.getComputedStyle(node).display !== 'none'; };
        var own = pair[0] === 'tell' && pair[1] === 'own';
        var telling = pair[0] === 'tell';
        if (seen(tools) !== own) {
          errors.push('the pickers are ' + (own ? 'not shown for' : 'shown outside') + ' a sentence of your own');
        }
        if (seen(area) !== own) {
          errors.push('the text box is ' + (own ? 'not shown for' : 'shown outside') + ' a sentence of your own');
        }
        // an empty preview is hidden by its own rule, so wait for the answer
        // rather than for the element
        var preBox = again.querySelector('.tap-preview');
        if (telling) {
          w.scheduleTellPreview();
          for (var tries = 0; tries < 12 && !(preBox.textContent || '').trim(); tries++) await wait(300);
          if (!(preBox.textContent || '').trim()) errors.push('no preview on a ' + pair[1] + ' link');
        } else if (seen(preBox)) {
          errors.push('a switching link shows a preview of something that has not happened');
        }
      }
      var headCells = d.querySelector('.tap-head').children.length;
      if (shapes.some(function (n) { return n !== headCells; })) {
        errors.push('the link row changes shape: ' + shapes.join(', ') + ' against ' + headCells + ' headings');
      }
      // A link that was already there, edited through the controls rather than
      // by setting the model: a redraw replaces the rows, and a handler that
      // held on to the object it was built with writes into a discarded one.
      // That is why a new link behaved and an old one did not.
      theTap.target = 'Probe-Plug'; theTap.do = 'toggle';
      w.TAPS.dirty = false; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
      await wait(200);
      var liveRow = d.querySelector('#taps-list .tap-row:not(.tap-head)');
      var targetSel = liveRow.querySelectorAll('select')[0];
      if (targetSel) {
        targetSel.value = 'tell';
        targetSel.onchange();
        await wait(150);
        if ((w.TAPS.rows[0] || {}).target !== 'tell') {
          errors.push('editing a link that was already there does not take');
        }
      }
      // A new row must start with nothing chosen, not with whatever happens
      // to be first in the list: that had it showing "tell me something" with
      // "toggle" beside it, a pair that cannot be, until it was clicked away
      // and back again.
      d.getElementById('tap-add').onclick();
      await wait(400);
      var made = Array.prototype.slice.call(d.querySelectorAll('#taps-list .tap-row'))
        .filter(function (x) { return !x.classList.contains('tap-head'); });
      var fresh = made[made.length - 1];
      var freshModel = w.TAPS.rows[w.TAPS.rows.length - 1];
      // A new row may come filled in, but the two lists must agree: it used
      // to offer "tell me something" with "toggle" beside it, a pair that
      // cannot be, until it was clicked away and back again.
      var freshSels = fresh.querySelectorAll('select');
      var offered = Array.prototype.map.call(freshSels[1].options, function (o) { return o.value; });
      if (offered.indexOf(freshModel.do) < 0) {
        errors.push('a new link offers ' + JSON.stringify(freshModel.do) + ' which is not one of its own actions');
      }
      if (freshSels[0].value !== freshModel.target || freshSels[1].value !== freshModel.do) {
        errors.push('a new link shows something other than what it holds');
      }
      w.TAPS.rows.pop(); w.TAPS.dirty = false;

      // and asking the house something belongs to the links alone
      var elsewhere = [];
      ['#bindings-list select', '#rules-list select', '#scenes-list select'].forEach(function (sel) {
        Array.prototype.forEach.call(d.querySelectorAll(sel), function (x) {
          if (Array.prototype.some.call(x.options, function (o) { return o.value === 'tell'; })) {
            elsewhere.push(sel);
          }
        });
      });
      if (elsewhere.length) errors.push('"tell me something" is offered in ' + elsewhere[0]);

      // The preview reads the row as it stands on the screen; until it is
      // saved, the link itself still does the old thing. Both places have to
      // say so, or a preview is just a confident wrong answer.
      theTap.target = 'tell'; theTap.do = 'house';
      w.TAPS.dirty = true; w.forgetSig('taps'); w.renderTaps(w.STATE.status);
      await wait(200);
      w.scheduleTellPreview();
      for (var pt = 0; pt < 12; pt++) {
        var lbl = d.querySelector('.tap-preview .lbl');
        if (lbl && lbl.textContent) break;
        await wait(300);
      }
      var label = d.querySelector('.tap-preview .lbl');
      if (!label || label.textContent.indexOf('saved') < 0) {
        errors.push('with changes unsaved the preview does not say so: '
          + JSON.stringify(label && label.textContent));
      }
      var told = null;
      var keepToast = w.toast;
      w.toast = function (m) { told = m; };
      w.showTapSetup(theTap);
      await wait(200);
      w.toast = keepToast;
      if (!told || String(told).indexOf('Save') < 0) {
        errors.push('the setup dialog hands out an address that does not match the screen');
      }
      w.TAPS.dirty = false;
      console.log('a telling link: writing desk, pickers and preview all there');
    }
  } catch (e) { errors.push('the telling-link check itself failed: ' + e.message); }

  // Renaming a section that has rows in it must move the rows, not leave them
  // behind under the old name with an empty section beside it. A row holds the
  // object it was built with, and a redraw replaces those with fresh copies -
  // so writing through the row's own copy renamed something already discarded.
  try {
    var storesWithSections = [['taps', w.TAPS], ['messages', w.MESSAGES], ['ptrig', w.PTRIG],
                              ['bindings', w.BINDINGS]];
    var regroupTrouble = [];
    storesWithSections.forEach(function (pair) {
      var store = pair[1];
      if (!store || !(store.rows || []).length) return;
      var was = store.rows[0].group || '';
      var mine = store.rows.filter(function (r) { return (r.group || '') === was; }).length;
      var moved = w.regroupRows(store, was, 'A-New-Name');
      if (moved !== mine) {
        regroupTrouble.push(pair[0] + ': renaming moved ' + moved + ' of ' + mine + ' row(s)');
      }
      var left = store.rows.filter(function (r) { return (r.group || '') === was; }).length;
      if (left) regroupTrouble.push(pair[0] + ': ' + left + ' row(s) stayed under the old name');
      w.regroupRows(store, 'A-New-Name', was);          // put it back
    });
    regroupTrouble.forEach(function (t) { errors.push('renaming a section - ' + t); });
    console.log('renaming a section: %d editor(s) checked, rows follow their section',
      storesWithSections.filter(function (p) { return p[1] && (p[1].rows || []).length; }).length);
  } catch (e) { errors.push('the section-rename check itself failed: ' + e.message); }

  // A scene or a sequence runs its own steps and the daemon takes no notice of
  // what is asked of it, so offering on, off and toggle beside one offers a
  // choice that does not exist. Two editors said so in a note beside the list
  // and the rest quietly did not; it is decided in one place now, so every
  // editor that fills an action list gets it.
  try {
    var st = w.STATE.status || {};
    var runners = [];
    ((st.scenes || [])[0] ? [['a scene', 'scene:' + st.scenes[0].id]] : [])
      .concat((st.sequences || [])[0] ? [['a sequence', 'sequence:' + st.sequences[0].id]] : [])
      .forEach(function (pair) {
        var opts = w.doOptionsFor(st, pair[1], 'on');
        if (opts.length !== 1) {
          errors.push(pair[0] + ' offers ' + opts.length + ' actions, and it has only one: its own steps');
        } else if (opts[0][1].indexOf('own steps') < 0) {
          errors.push(pair[0] + ' does not say that it runs its own steps: ' + JSON.stringify(opts[0][1]));
        }
        runners.push(pair[0]);
      });
    // and a socket must still have its full set, or the rule above is too keen
    var plugName = ((st.plugs || [])[0] || {}).name;
    if (plugName && w.doOptionsFor(st, plugName, 'on').length < 3) {
      errors.push('a socket lost its actions');
    }
    // and it must be a plain line, not a list with one thing in it: nobody
    // should be given a menu to choose from when there is nothing to choose
    var seenAt = w.getComputedStyle.bind(w);
    var shownBeside = [];
    Array.prototype.forEach.call(d.querySelectorAll('select'), function (sel) {
      if (seenAt(sel).display === 'none') return;
      var prev = sel.previousElementSibling;
      if (prev && prev.tagName === 'SELECT' && String(prev.value).indexOf('scene:') === 0) {
        shownBeside.push(((sel.closest('.card') || {}).id || 'a card'));
      }
    });
    if (shownBeside.length) {
      errors.push('a list of actions is still offered beside a scene in ' + shownBeside[0]);
    }
    // The line has to be where the list was, not an extra cell beside it: in a
    // row laid out as a grid an extra cell shifts every column after it, which
    // is how choosing a scene resized the name box next to it.
    Array.prototype.forEach.call(d.querySelectorAll('.tap-row:not(.tap-head)'), function (row) {
      var note = row.querySelector('.scene-note');
      if (!note || seenAt(note).display === 'none') return;
      var onLine = Array.prototype.filter.call(row.children, function (c) {
        return !c.classList.contains('rowgrab') && !c.classList.contains('tap-storybox');
      }).length;
      var headings = (d.querySelector('.tap-head') || {children: []}).children.length;
      if (onLine !== headings) {
        errors.push('a link showing the plain line has ' + onLine + ' cells against ' + headings + ' headings');
      }
      if (!note.closest('.tap-act')) {
        errors.push('the plain line sits outside the cell the list was in, so it moves the columns');
      }
    });
    var plainLines = Array.prototype.filter.call(d.querySelectorAll('.scene-note'),
      function (n) { return seenAt(n).display !== 'none'; });
    console.log('what runs its own steps: %s, said as a plain line in %d place(s)',
      runners.join(' and ') || 'nothing', plainLines.length);
  } catch (e) { errors.push('the own-steps check itself failed: ' + e.message); }

  console.log('errors:', errors.length ? errors : 'none');
  w.close(); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
