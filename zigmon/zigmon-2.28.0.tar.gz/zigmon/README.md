# zigmon

Monitoring, history and control for every sensor that reaches an MQTT broker
through Zigbee2MQTT — and, optionally, for Shelly WiFi devices publishing to
the same broker. The same shape as `upsmon`: a Python daemon that owns the
data, SQLite for history, and a PHP dashboard behind nginx that only relays
JSON.

* `install.sh` — sets the whole thing up on AlmaLinux 9, and can upgrade or remove it
* `zigmon.py` — the daemon and the command-line tool, one file (standard library + paho-mqtt)
* `web/index.php`, `web/zigmon-api.php` — the dashboard and its thin API client
* `deploy/` — systemd unit, logrotate rules, sample configuration, nginx server block
* `INSTALL.md` — the AlmaLinux 9 walkthrough, by hand

## Installing

```bash
sudo ./install.sh
```

Packages, service user, configuration, the broker account, systemd unit, log
rotation, nginx with TLS, php-fpm, SELinux, firewall, and a check that it all
works. `--dry-run` shows what it would do, `--upgrade` replaces the program
files, `--uninstall` removes it while keeping the recorded history. Every
question has a command-line option; `--help` lists them.

## How the pieces fit

```
Zigbee sensors ──► SLZB-06 ──► Zigbee2MQTT ──┐
                                             │      AlmaLinux 9
Shelly WiFi (H&T, Plug) ─────────────────────┤   ┌────────────────────────────────────────┐
                                             ▼   │ zigmon.service   (user "zigmon")       │
                                        mosquitto│   subscribes to zigbee2mqtt/#, shellies/#│
                                       1883/8883 │   writes /var/lib/zigmon/history.db    │
                                             ────►   serves 127.0.0.1:9849, token-guarded │
                                                 │        ↑                               │
                                                 │ php-fpm ← nginx :443 ← browser         │
                                                 └────────────────────────────────────────┘
```

The daemon is the only thing that talks to the broker. PHP relays JSON and
holds no credentials; the two endpoints that change something (opening the
network for joining, erasing history) send a token read from a file the
browser never sees, and are guarded by a PIN on top. Nothing in the chain
needs root.

## What it watches

**Every device Zigbee2MQTT knows.** The bridge's device list gives the model,
vendor, description and — through the "exposes" definition — the label and
unit of every value the device reports. Nothing is specific to a model: a
temperature sensor, a button, a contact, a plug with power metering all land
in the same tables and on the same dashboard. New devices appear by
themselves the moment they pair.

**Shelly smart plugs**, optionally, over local RPC exactly as upsmon does it:
the watts actually being drawn, voltage, current, power factor, frequency,
the plug's own temperature, the energy total and the runtime and switching
counters. Any number of plugs; each can be switched and its counters reset
from the dashboard, and **a Zigbee button can be bound to it** — single press
toggles the fridge, long press switches it off, whatever you set up on the
Control tab. The editor offers only devices that can send an action, and for
each one the exact actions its Zigbee2MQTT definition declares (plus any it
has actually sent), so nothing has to be typed or guessed.

**Shelly WiFi sensors**, three ways, all optional: over MQTT (anything under
`shellies/<name>/status/…`), polled over RPC when the sensor has an address
and answers (an H&T on USB power), or **pushed by webhook** from a battery
sensor that sleeps and cannot be polled — the daemon can listen for those
on a port of its own, exactly as upsmon did.

**The bridge itself**: online/offline, version, channel, whether the network
is open for joining, and the events it publishes (join, leave, interview,
rename).

## Why it is built this way

**Readings are rows, not columns.** `(device, key, value)` rather than a fixed
schema, because what one sensor reports is not what the next one does, and a
device added next month should need no code change.

**History is keyed by address, not by name.** Renaming a device in
Zigbee2MQTT keeps its history; the rename shows up as an event. A device that
reports before the bridge has listed it is filed under its name and moved
across when the address arrives.

**SQLite in two layers.** Full-resolution samples for a fortnight, hourly
averages with min and max for two years. A year of history for a dozen
sensors is a few megabytes, and a year-long chart costs a few hundred rows.

**A bursty device does not flood the table.** Readings arriving within
`sample_interval` of the previous one replace it rather than adding a row —
some devices send four messages for one measurement.

**Availability is inferred as well as reported.** Zigbee2MQTT publishes
`availability` when that feature is on; when it is not, a device that has
been silent longer than a battery sensor's reporting interval is flagged
anyway. A device that reports is by definition reachable, whatever the last
availability message said.

**Button presses are events, not readings.** `action` values go to the event
log with a timestamp; there is nothing to chart in a press.

**Button bindings run in the daemon, not the browser.** A press arrives over
MQTT, the daemon looks the binding up and talks to the plug over RPC; nothing
depends on a dashboard being open. Each switch is an event with the button
and the action that caused it.

**A plug reset is verified, not assumed.** The plug answers
`Switch.ResetCounters` with success whether or not it understood the counter
name, so the values are read back and compared.

**Requests to a plug are paced.** Gen3 firmware with authentication answers
429 when requests arrive closer together than about a second, and the digest
challenge is reused rather than renegotiated on every call.

**A missed reading does not blank the panel.** The last values stay on screen,
greyed out and dated, and after a restart they come from the recorded
snapshots until a fresh reading lands.

**The daemon never gives up.** paho reconnects to the broker by itself with
backoff; the systemd unit restarts the daemon without limit if it ever
crashes; a broker that is down for an hour simply means an hour without data.

**An error inside an endpoint answers rather than raises.** The dashboard
polls every five seconds; one bad payload from one device must not stop the
feed or bury the journal.

## The dashboard

Six tabs. **Overview**: counts, bridge state, permit-join state, a socket
panel per plug with a switch and its live figures, a card per sensor with its
main readings, battery, signal and last report — a button's card shows the
**last press, big**, with which button and how long ago, glowing green for a
moment when it lands (live, under a second), and its gestures as small
chips; a multi-button remote is folded to "4 buttons" plus each gesture
once instead of a 28-item list — and 6h/24h/7d charts of
temperature and humidity across all devices. **History**: pick a
device, pick 6 hours to a year, one chart per value it reports. **Devices**:
the table. **Events**: joins, leaves, renames, availability changes, button
presses, bridge state. **Control**: open or close the Zigbee network, switch each plug and reset
its counters, edit the button bindings, erase recorded data, forget a device
— all behind the PIN. **All values**: everything
every device reports, with the description Zigbee2MQTT gives for it.

**The overview can be rearranged.** While editing is unlocked, drag any
socket row or device card where you want it; the order is saved the moment
you drop it (`POST /api/order`), lives in the daemon, and every browser sees
the same layout. Newly added devices go to the end. While locked, dragging
is off.

Every Zigbee device also shows **which router or coordinator it talks
through** — "via Router" on its Overview card (hover for the link quality
and how fresh the information is) and a "Connected through" line on All
values. The daemon asks Zigbee2MQTT for the raw network map every
`networkmap_interval` seconds (default 300, `0` turns it off; the answer
also survives a restart), so after moving a device or adding a router give
it a few minutes to reflect re-parenting.

Charts read each series' own rhythm: a thermometer that wakes every four
hours draws an unbroken line, and lines are always continuous, start to finish, whatever a source's
rhythm. Shading real outages on top — where a normally chatty source went
quiet for a while — is an opt-in setting (`chart_outages` in
config.json, or Settings on the dashboard); off by default, it applies to
every chart at once.

**Three more tabs join Plugs: Sensors and Buttons.** Every non-plug device
that reports measurements lives on Sensors; every button/remote lives on
Buttons. Both are full catalogs, unlocked-editable and reorderable by drag,
independent of Overview.

**Overview is yours to design.** While unlocked, an "Add to Overview" row
lets you place any plug, sensor, or button onto Overview; a small × on each
card removes it, and dragging reorders freely — plugs and sensor/button
tiles can sit in any order together. A fresh install shows everything (the
same combined view as before), so nothing looks empty until you start
customizing; from the first add or remove, Overview remembers your own
layout in the daemon, shared across every browser. It has nothing to do
with the Plugs/Sensors/Buttons tabs, which always show the full catalog.

**Zigbee gateways** now cover two kinds of hardware: a SMLIGHT SLZB-06 or
similar (plain HTTP JSON on `/ha_info`/`/ha_sensors`) and a **Shelly device
with the Zigbee component acting as a router** — e.g. a Power Strip 4
Gen4 — read over the same local JSON-RPC API (`/rpc`, digest auth) already
used for Shelly plugs, via `Shelly.GetStatus`, `Zigbee.GetStatus` and
`Zigbee.GetConfig`. **Detect** tries the SLZB path first and falls back to
the Shelly one automatically, remembers which one answered (`kind` in
`config.json`), and — for a router — offers the matching device on the
mesh as the target if there is exactly one, or one whose model matches
what Detect read. `zigmon gateway <name> dump` and the background poller
follow the same two-protocol logic, so a Shelly-based gateway needs no
extra setup once Detect has run once.

**Zigbee gateways** (a SMLIGHT SLZB-06 or similar) can be read over the
network for their own health — uptime, board temperature, Wi-Fi/Ethernet
and socket state — on top of what Zigbee2MQTT reports. Add one on the
Control tab, in **Zigbee gateways** (name, address, and — if the device's
"web server authentication" is switched on — a username and password sent
as HTTP Basic Auth), or in `config.json` for a read-only entry:

```json
"zigbee_gateways": [
  {"name": "Router", "host": "192.168.1.51", "target": "Router",
   "username": "admin", "password": "..."}
]
```

`target` is either the name an existing Zigbee router already has (its
readings *extend* that device — nothing is duplicated) or the literal
string `"coordinator"` for the local coordinator, which has no device row
of its own and gets a small synthetic one. `username`/`password` are
optional and only needed when the gateway's own web login is enabled.
Polled every `gateway_poll_interval` seconds (default 30) from the
documented `/ha_info` and `/ha_sensors` endpoints, plus `/metrics` (the
device's own Prometheus output — free heap, board temperature, Wi-Fi RSSI
and whatever else the firmware exposes, parsed generically since the
format is self-describing). Whatever comes back lands under a `gw.` prefix
in All values and gets recorded to history too — free heap over time is
often the earliest sign of a coordinator that is about to lock up. **Detect** on the row does the
same from the dashboard: it reads model, firmware, radio and mode, fills
the name if empty and suggests the target (coordinator, or the one router
on the mesh). Run
`zigmon gateway <name> dump` (or `--host <ip> dump` for one not yet in
config.json) to see exactly what your firmware returns before relying on
any particular field.

**A multi-relay strip reads as one box.** Its header carries what is the
box's — model, firmware, address, mains voltage and frequency, box
temperature, total power, Wi-Fi — and each channel row underneath shows
only its own power, current, energy, on-time and switch count, with the
same full-size switch button a single plug has. **Find Shelly devices → Add**
runs Detect on the spot, so a found box arrives with the right kind,
its relays and their names.

**Plugs are added as devices, not as relays.** In Plugs and sensors one
block is one box: address, password and a *device state* entered once.
**Detect** asks the box what it is (model, MAC, firmware) and how many
relays it has, and lays out one channel row per relay with the names the
device itself uses — a Pro 4PM becomes four channels in one click. The
device state wins: *monitor only* or *disabled* there applies to every
channel and locks their selects; *enabled* lets each channel keep its own
choice (a single channel can still be monitor-only or disabled). Passwords,
addresses and the device state are stored once per channel underneath, so
bindings, rules, history and the strip ordering on the Plugs tab work
exactly as before (the whole strip is dragged; channels reorder inside it).
In `config.json` the same is `"host_state": "enabled|monitor|disabled"`
on each channel entry.

**Silence quiet-alerts for buttons** (Settings → Alert thresholds, on by
default) — a button or remote only reports when pressed, so going quiet for
hours or days is normal for it, not a fault. With this on, buttons never
turn WARN/CRIT or count toward "needs attention" just for being silent;
switch it off to get the old behavior back. Plugs were already exempt.

**On/off is a switch, everywhere.** One iOS-style toggle is used for every
enable/disable in the dashboard: the boolean settings (outage shading,
chart icons, daily backup, Zigbee2MQTT in the backup), the notification
categories and per-device custom picks, and — new — an enabled switch at
the start of every binding, rule and schedule row: off keeps the row but
the daemon ignores it (dimmed in the list). Backup time is a time picker,
tokens are masked, numbers have sensible steps.

**The way to a device's charts** is always the same small chart icon in
the top-right corner of its card or row, shown on hover — never the name,
never the whole card (a plug's row has the switch on it). It is on by
default and can be switched off per kind under Settings → Charts or in
`config.json` (`link_plugs`, `link_sensors`, `link_buttons`).

**Click the status pill** (or the Needs-attention card) for the details
behind it: a dialog listing every problem in one place — broker or bridge
down, each device flagged by a threshold with the reason and its last
report, every unreachable plug with the error — worst first; a device name
opens its History. When all is well it says so, with a one-line summary.

**A tick paints only the tab you are looking at**, and only the parts
whose data actually changed (each grid and editor keeps a signature of its
slice of state; "x min ago" texts repaint once a minute). A hidden tab is
painted the moment it is shown. With a few dozen devices a refresh costs a
few milliseconds instead of hundreds, so a click on a socket repaints in
~30 ms even on a big mesh.

**Recording never makes anyone wait.** Everything the daemon writes while
handling a message — samples, snapshots, events, last-seen — goes onto a
queue drained by one background thread, and the config lists that decide
what to fire (bindings, rules, scenes, sequences, schedules) are held in
memory. So the automation path touches no database lock at all: a VACUUM
or an online backup, which hold SQLite for as long as they take, can no
longer stall a button press or back up the MQTT client thread. Maintenance
flushes the queue first, so a backup still captures everything.

**Switching is close to instant, and stays that way under load.** Per-host
pacing (so one relay is never hammered) used to sit behind one lock shared
by every plug — a slow background poll on any device could stall a click
on an unrelated one by up to a second. Pacing is now per host, so devices
never wait on each other. A command that meets a device's own HTTP 429
(rate limited) also fails fast — one short retry instead of the patient
multi-attempt backoff that suits an unattended background poll.

**Switching is close to instant.** A command to a plug takes a priority
lane past the polling pace (`plug_command_gap`, default 0.05 s, vs.
`plug_min_request_gap` for background polls), a toggle is a single
`Switch.Toggle` round trip, and the dashboard repaints the moment the relay
confirms — the power and energy figures follow from a background poll a
second later, so nobody waits for them. Click-to-repaint is typically
~100 ms on a LAN; a Zigbee button or a motion sensor reaches the relay
within a few milliseconds of its MQTT message (the relay is driven before
the event is even written to disk). Both gaps are tunable under
Settings → Polling.

It updates **live**: besides the five-second refresh, the page keeps one
long-poll request open (`/api/wait`) that the daemon answers the moment
anything visible changes — a report arriving, a plug switching, a binding or
rule firing, the bridge going up or down. A button press shows on every open
dashboard in well under a second; the five-second tick stays as the safety
net, and if the wait endpoint is unreachable the page simply behaves as
before. Each open tab holds one php-fpm worker for up to 25 s at a time,
which the default pool of dozens absorbs without noticing. Refreshing pauses
when the tab is hidden and can be paused by hand from the indicator in the
corner. Control buttons carry a
plain label and an icon; resting the pointer on one for five seconds
reveals the exact request behind it and what it does.

**The Control tab is locked by default.** Nothing there that changes
something works until editing is unlocked with the PIN for a chosen time
(5 min to 4 h) — from the lock pill in the header, the Editing card on the
tab, or simply by clicking any action, which offers to unlock first. The
socket buttons on the Overview follow the same mode: while editing is
unlocked they switch at once; while locked, each click asks for the PIN on
its own, without unlocking anything. While unlocked
nothing asks for the PIN again; the header counts the time down, and it
locks itself when the time is up or when you click *Lock now*. The daemon
issues a session token for the period and forgets it at the end, so an
expired session cannot be replayed; another tab, a restart of the daemon or
its own timer all relock the page. There are no browser pop-ups — the PIN
dialogue is the only one, the same as upsmon's: one box per digit, a wrong
PIN shakes and clears the boxes and asks again in place.

**Every chart pans and zooms**, as in upsmon: drag to move the window,
wheel to zoom around the pointer, pinch on a touch screen, double-click or
the *reset view* button to return. The view survives the five-second
refresh while it is zoomed. Nothing is re-fetched while panning. The tab icon is coloured by
the overall verdict.

## Command line

```bash
zigmon --status                       # every device with its latest readings
zigmon --devices                      # the device table
zigmon --history Temp-Balkon --range 7d --keys temperature,humidity
zigmon --events                       # the event log
zigmon --watch                        # live feed straight from the broker
zigmon --watch --bridge --raw         # including bridge/* topics, untruncated
zigmon --permit-join on               # open the network for four minutes
zigmon --plug                         # every plug, live from the device
zigmon --plug-on Lednice              # switch a plug; also --plug-off, --plug-toggle
zigmon --plug-pulse Lednice --ms 3000 # flip, hold 3 s, flip back
zigmon --plug-reset Lednice --types aenergy,switch_on
zigmon --bindings                     # which button action drives which plug
zigmon shelly Lednice dump            # the Shelly toolkit, see below
zigmon --reset-data history           # erase: all, history, events, or a device name
zigmon --check                        # is the whole system healthy
zigmon --diag                         # settings, API latency, database size
zigmon                                # run the daemon in the foreground
```

## The full Shelly toolkit

Everything the standalone Shelly reader in upsmon could do, ported whole and
addressed by the name a device has in the configuration — the address and
password come from there. Each command has its own `--help`.

```
zigmon shelly [NAME] <command> [options]
```

| reading | |
|---|---|
| `discover` | find Shelly devices on the LAN over multicast DNS, with a diagnosis when nothing answers |
| `info` | identity, firmware, auth and Matter state |
| `dump` | every value the device exposes, every component |
| `methods [COMPONENT] [--examples]` | every RPC method it supports, with a note on what each is for |
| `poll` | a live table. `--interval`, `--count`, `--csv FILE` |
| `watch` | the same, pushed over the device's websocket |
| `listen`, `serve` | receive webhooks, or an outbound websocket |

| controlling | |
|---|---|
| `on`, `off`, `toggle` | switch the relay |
| `reset-counters [type…]` | no type means every counter |
| `reboot [--wait]` | restart, optionally waiting for it to come back |

| configuring | |
|---|---|
| `config [COMPONENT] ['{JSON}']` | read or write a component's settings — a write is read back and the keys the firmware dropped are listed |
| `matter status\|on\|off\|code` | Matter, and the pairing code |
| `ble status\|on\|off\|rpc-on\|rpc-off` | radio and RPC over Bluetooth |
| `call METHOD ['{JSON}']` | anything the above does not cover |

```bash
zigmon shelly Lednice dump
zigmon shelly Lednice config switch:0 '{"auto_off": true, "auto_off_delay": 300}'
zigmon shelly Lednice ble on --reboot
zigmon shelly Lednice methods Switch --examples
zigmon shelly --host 172.16.16.13 --password secret info
zigmon shelly discover
```

`--host`, `--password`, `--switch-id`, `--json` and `--no-color` work
anywhere, before the command or after it. With no name, the first
configured plug is assumed. `watch` needs a device without a password, the
websocket carrying no authentication. `discover` does not cross subnets.
`ble` and `matter` take effect after a reboot, which `--reboot` will do.

## Sensors over RPC and webhooks

```json
"sensors": [{"name": "HT-Sklep", "host": "172.16.16.13", "password": ""}],
"sensor_listen": true,
"sensor_listen_host": "0.0.0.0",
"sensor_listen_port": 8088
```

A sensor with an address is polled like a plug; while it sleeps the poll
simply fails quietly. A battery sensor pushes instead — point its webhook at
`http://<this-host>:8088/?t=${ev.tC}&rh=${ev.rh}&id=NAME` (`bp` for battery
percent, `bv` for volts, `rssi`). JSON bodies are accepted as well. Each
source becomes a device like any other; `zigmon shelly listen` shows what
arrives without recording it, and the Control tab's daemon card counts the
pushes.

## API

Read endpoints are open on the loopback; the two that change something
require `X-Zigmon-Token` and, when configured, the PIN.

| endpoint | returns |
|---|---|
| `GET /api/status` | every device: identity, latest values with labels and units, verdict and reasons; the bridge; counts |
| `GET /api/health` | daemon uptime, broker connection, message count, database statistics |
| `GET /api/devices` | the device list (same shape as in status) |
| `GET /api/device?id=NAME` | one device, plus the keys it has history for and the full exposes map |
| `GET /api/history?device=NAME&keys=temperature,humidity&range=24h&points=600` | rows of `{ts, key…}`, hourly beyond two weeks |
| `GET /api/events?limit=100&device=NAME` | the event log |
| `GET /api/keys?device=NAME` | which values have history |
| `POST /api/permit-join` | `{"enable": true, "time": 254, "pin": "…"}` |
| `POST /api/unlock` | `{"pin": "…", "minutes": 15}` → `{"token", "until"}`; the token then replaces the PIN as `session` in every other POST |
| `POST /api/lock` | `{"session": "…"}` ends it early |
| `POST /api/reset` | `{"scope": "all|history|events|device", "device": "…", "pin": "…"}` |

The plugs:

| endpoint | returns |
|---|---|
| `GET /api/plugs` | every plug: state, live figures, each counter with its value and the date it started from |
| `GET /api/plug?name=Lednice&refresh=1` | one plug, optionally read again first |
| `POST /api/plug/switch` | `{"name": "Lednice", "on": false}`, `{"name": "…", "toggle": true}` or `{"name": "…", "pulse": true, "ms": 5000}` — needs the PIN |
| `POST /api/plug/reset` | `{"name": "Lednice", "types": ["aenergy"]}`, or `[]` for every counter — needs the PIN |
| `GET /api/bindings` | the button bindings |
| `POST /api/bindings` | `{"bindings": [{"device": "Button", "action": "single", "plug": "Lednice", "do": "toggle"}]}` — replaces the list, needs the PIN. `do` is `toggle`, `on`, `off` or `pulse` with `pulse_ms`; `plug` may be `*` for every plug, and the same button and action may drive any number of rows — all matching rows fire in parallel |

**Devices can be renamed and deleted from the Devices tab.** Renaming a
Zigbee device goes through Zigbee2MQTT itself (`bridge/request/device/rename`),
so the friendly name — and the MQTT topic — change everywhere, permanently;
history stays, because everything is keyed by the IEEE address. A Shelly
seen over MQTT or a webhook gets a dashboard alias instead (the topic cannot
be renamed from here); the table then shows the alias with the topic
underneath. Plugs and sensors added on the Control tab are named there.
Deleting a device erases every reading, event and snapshot recorded for it,
and takes out any binding or rule that used it as the source (each removal
is logged); a plug used as the *target* of other rules stays, since the plug
itself was not deleted. If the device reports again it simply reappears,
fresh, under its default name. Bindings and rules store the device id, not
the name, so renaming breaks nothing. `POST /api/device/rename`.

**Zigbee switches are targets too.** Anything in the network with a
settable on/off state — a SONOFF ZBM5 wall-switch channel, a bulb, a relay
module — appears in the binding and rule editors marked ⚡ alongside the
Shelly plugs, one entry per channel (`Svetla · L1`). The daemon drives them
by publishing `{"state_l1": "ON"|"OFF"|"TOGGLE"}` to
`zigbee2mqtt/<name>/set`; toggle and pulse work (a pulse with an unknown
current state falls back to a blind double TOGGLE), the switch's own report
comes back through the bridge and repaints the dashboard, and every command
is logged as an event with its origin. `*` (all plugs) deliberately never
includes them. The daemon's broker account must be allowed to **write**
`zigbee2mqtt/+/set` — if commands vanish silently, that is the mosquitto
ACL (`topic readwrite zigbee2mqtt/#` for the zigmon user covers it).

**Notifications.** Configure a channel in `config.json` — `notify_ntfy`
(a topic URL such as `https://ntfy.sh/moje-tajne-slovo`; subscribe to the
same topic in the ntfy app) and/or `notify_telegram_token` +
`notify_telegram_chat` — and pick on the Control tab what is worth a push:
critical problems, warnings, devices going quiet, every rule that fires.
The same story repeats at most once per 15 minutes; there is a test button.
Below the global choices sits a per-device list: any plug or sensor can be
set to **mute** (nothing about it, ever), **critical only**, or
**everything about it** (warnings, going quiet, rules touching it) —
overriding the global choices for that one device.

**Scenes** are named bundles of actions ("Vecer": lamp on, chandelier off,
TV plug on) edited on the Control tab, runnable from there and available as
🎬 targets for button bindings and rules. A step can carry **after N s**
(from the scene start, fractions allowed): steps without it fire at once,
together, so `0 / 2 / 5` makes a small cascade.

**Rules: AND or OR between the two conditions.** The second condition
(already there for "occupancy AND temperature", say) now has an AND/OR
choice. Two PIRs covering one room: one rule `occupancy ≥ 1 OR occupancy ≥ 1`
(the two sensors) → on; a second `occupancy ≤ 0 AND occupancy ≤ 0` → off,
so the light turns on the moment either one sees motion and off only once
both have gone quiet — two rules instead of four. Applies to both live
firing and Dry run.

**Sequences** turn one button into a cycle: the first press runs step 1,
the next press — minutes or days later — step 2, and so on, then around
again; the position is remembered across restarts. Each step is a scene,
so a step can drive many targets at once or with delays. Bind a button to
the 🔁 entry to advance; bind another button (or the same button's long
press) to the ↺ entry to run the optional *reset scene* — all off, say —
and start over. Edited on the Control tab, with Advance/Reset buttons and
a "next press: step N — scene" line.

**Rules grew up.** Besides the clock window: an optional **AND** condition
against any second reading (`occupancy ≥ 1 AND illuminance ≤ 50`), a
**must-hold-for** time in seconds (no motion for 600 s, a washer under 5 W
for 180 s — the stretch completes even if the source goes quiet), a
**way-back threshold** folding a hysteresis pair into one rule (`≥ 65 → on,
back at 55` switches off past 55), and windows that take **sunrise/sunset**
with minute offsets (`sunset-30`–`23:30`; set `latitude` and `longitude`
in `config.json`).

**Energy** on the Overview: today / yesterday / this month / last month /
this year / last year per plug, with an **All plugs** total row at the
bottom when there is more than one — click its name for the same 30-day
bar chart as any single plug, summed across all of them, computed reset-proof from the meters' own counters; set
`price_per_kwh` (and `currency`) to see money next to the kWh. On the
Control tab, an **Energy summary** card restarts those sums from zero, now,
per plug or for all — a baseline marker, not a data wipe: history and the
plug's own meters stay, and a restarted plug carries ↺ next to its name.

**Settings on the dashboard.** The safe-to-change slice of `config.json`
lives in a Settings card on Control: alert thresholds, polling intervals,
price/currency, latitude/longitude, notification channels. Saved values are
stored in the daemon's database, apply immediately (no restart) and win
over the file; putting a value back to what the file says drops the
override, and overridden fields carry a blue edge with the file's value in
the tooltip. Connection, ports, paths and the PIN stay file-only.

**Database card** (Control): the file's size and row counts, the last
roll-up, **DB latency** (a trivial read and write, measured by the daemon)
and **app latency** (browser → daemon → back, plus the daemon's own time to
answer), with four buttons — **Check integrity** (SQLite's own check),
**Optimise** (ANALYZE + VACUUM; pauses writes while it runs), **Back up
database now** (a consistent copy via SQLite's online backup, into the
backups folder, kept `backup_keep` deep) and a **list of the backups on the server**,
each with **Download** (the file itself, to keep off-site), **Restore**
(replaces the live contents; the state right before is saved as its own
backup first, so a mistaken restore can be undone) and **Delete**; plus
**Upload a backup** to put a file back into the list — it travels in pieces
of a few MB and is checked to be a healthy zigmon database before it is
accepted. (Uploads need `client_max_body_size 6m` in nginx; the upgrade
raises it from the old 16k.)

**Backup**: one button downloads every dashboard-made setting (devices with
passwords, bindings, rules, scenes, layout, aliases, notification choices)
as a JSON file; import replaces them wholesale. The dashboard also carries
a PWA manifest, so "Add to home screen" gives it an icon and a standalone
window on a phone.

**Sensor rules** drive a plug from any numeric reading, not just a button:
source device, value, comparison (≥ ≤ > <), threshold, plug (or all plugs)
and the action, including pulse. Any device with numbers works as a source —
a thermometer, a plug's own power draw, Wi-Fi signal, battery. Rules are
edge-triggered: one fires when its condition **becomes** true, not on every
report while it stays true, and a per-rule cooldown (default 300 s) stops a
value dancing on the line from hammering the relay. Two rules make a
thermostat with a dead band: `temperature ≥ 30 → on`, `temperature ≤ 27 →
off`. Each rule can be limited to a **clock window** (`from`/`to`, `22:00`–`06:00`
crosses midnight; empty means around the clock) and can name a **safe state
for when the window closes** (`window_end`: `off` or `on`) — a
motion-driven light is switched off when its night window ends, whether or
not anyone walked past at that moment, and the rule re-arms freshly when
the window opens again. Outside its hours a rule does not fire at all.
Yes/no readings — occupancy, contact, ON/OFF states — count as 1 and 0, so
`occupancy ≥ 1 → on` with the sensor's own clear-timeout makes a motion
light. Edited on the Control tab, which shows each rule's current reading
and whether it holds; `GET/POST /api/rules`; `zigmon --rules` on the
command line.

A **pulse** flips the socket and flips it back after the delay: off → wait
→ on when the plug is on (a power-cycle for whatever is plugged in), on →
wait → off when it is off. The way back is retried three times and, if it
still fails, logged as a critical event; a second pulse while one is running
is refused.

Plugs and sensors are managed on the **Control tab** — add, test, remove,
save behind the PIN; the daemon starts polling at once, no restart. *Test*
asks the device who it is and fills in whether it is a plug or a sensor;
*Find Shelly devices* runs a multicast DNS query from the server and offers
what answered on this subnet. Passwords are kept in the daemon's database
(readable by the daemon alone) and never sent back to the browser — the
field shows "(kept)" and stays blank. The same endpoints:

| endpoint | |
|---|---|
| `GET /api/managed` | plugs and sensors, without passwords |
| `POST /api/managed` | `{"plugs": [...], "sensors": [...]}` — replaces the dashboard-managed list; omit `password` to keep it, `clear_password: true` to drop it |
| `POST /api/managed/test` | `{"host": "…", "password": "…"}` → model, firmware, whether it has a switch |
| `POST /api/managed/discover` | what mDNS finds in three seconds |

Every entry can be **disabled without deleting it** — the State column on
the tab, or `"enabled": false` on the entry in `config.json` or in the
`POST /api/managed` body. A disabled plug or sensor is not polled, cannot be
switched and disappears from the lists, but its history stays, and bindings
and rules that point at it are kept (they simply do not fire, and the plug
shows as "(disabled)" in their editors) — enable it again and everything
carries on where it left off.

`config.json` still works and wins: entries under `"plugs"` and `"sensors"`
there are shown on the tab as read-only and cannot be duplicated from the
dashboard. `mqtt_name` is the device's own MQTT prefix (whatever its *MQTT prefix*
setting says — `plugtst`, `shellies/xxx`, …). Fill it in and two things
happen: the daemon does not record the device twice, and it **subscribes to
that prefix and learns about relay changes the instant they happen** — a
press of the button on the plug, its web page, the Shelly app. Without it,
an outside change waits for the next poll (up to `plug_poll_interval`,
15 s). With it, the dashboard repaints in well under a second, with the
source in the event ("switched on (button)"). A plug shows up as a
device like any other, so History and All values cover it too, and `zigmon
shelly NAME …` addresses both kinds of entry.

`device` and `id` accept the friendly name or the IEEE address.

## Broker account

The daemon needs a broker login with these rights (the installer can create
it in a local mosquitto):

```
user zigmon
topic read zigbee2mqtt/#
topic write zigbee2mqtt/bridge/request/#
topic read shellies/#
```

## What was verified

Without a broker in the build environment, against replayed messages from a
real Zigbee2MQTT 2.13 with Shelly BLU H&T ZB, BLU Button Tough ZB, a Shelly
H&T Gen3 and a Plug M Gen3 over `shellies/`:

* device discovery from `bridge/devices`, readings before the list arrives,
  rename, removal, availability, button actions, bridge events
* every API endpoint, token and PIN handling, erasing by scope
* the plugs against a mock Shelly Plug M Gen3 with SHA-256 digest
  authentication: polling, switching, per-counter resets including ones the
  firmware only pretends to clear, and a button press toggling the plug
  through a binding
* the dashboard driven in a headless browser through every tab, chart
  rendering, the PIN dialogue and a reset
* the whole Shelly toolkit against the same mock: info, dump, methods,
  config read and write with keys the firmware drops, ble and matter
  switches, on/off/toggle, counter resets, call, poll to CSV, reboot --wait,
  and the discovery diagnosis on a network with no answer
* a polled sensor, GET and POST webhook pushes, and a push carrying nothing usable
* the installer's dry run

Current version: **2.28.0**
